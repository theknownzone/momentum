package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.util.PrintSound
import com.momentum.focus.ui.util.Receipt
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * A deliberately long 20-second premium unlock sequence.
 *
 * This is not a generic "premium" splash. It behaves like a tiny product
 * reveal: boot -> calibrate -> print -> colour pass -> verify -> settle.
 * The receipt is physically fed out while a scan beam and printer indicators
 * track the same playhead. The result is longer, but every second has a job.
 */
private const val RUN_MS = 20_000L
private const val FEED_START = 0.15f
private const val FEED_END = 0.62f

@Composable
fun UnlockReceipt(data: AppData, onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val context = LocalContext.current
    val progress = remember { Animatable(0f) }
    val lift = remember { Animatable(1f) }
    var saved by remember { mutableStateOf<String?>(null) }
    var savedShown by remember { mutableStateOf(false) }
    var skipRequested by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        PrintSound.init(context)
        haptics.unlock()
        launch {
            // Beat map follows the 20s visual timeline. There is a clear
            // cadence at calibration, print milestones, colour verification
            // and the final unlock. Haptics are state changes, not a constant
            // buzz.
            val beats = listOf(
                850L to false, 1700L to false, 2650L to true,
                4300L to false, 6000L to false, 7800L to false,
                9500L to false, 11200L to true, 12800L to false,
                14500L to false, 16000L to true, 17200L to false,
                18400L to false, 19300L to true,
            )
            var elapsed = 0L
            for ((at, heavy) in beats) {
                delay((at - elapsed).coerceAtLeast(0L))
                if (heavy) haptics.press() else haptics.tick()
                elapsed = at
            }
            haptics.sessionComplete()
        }

        launch {
            // Slaved directly to the same progress value the paper reads
            // below, via snapshotFlow — not a second independent delay()
            // timer running alongside progress.animateTo(). Two clocks that
            // use the same nominal numbers can still drift apart:
            // animateTo() rides the frame clock, delay() rides a plain
            // coroutine timer, and any dropped frames, system jank, or the
            // skip path pulled them out of step — the motor kept humming for
            // a beat after the paper had already left the screen. Reading
            // progress.value directly means there is only one clock, so the
            // sound cannot outlive what is actually on screen.
            snapshotFlow { progress.value }.first { it >= FEED_START }
            PrintSound.play(loop = true)
            snapshotFlow { progress.value }.first { it >= FEED_END }
            PrintSound.stop()
        }
        progress.animateTo(1f, tween(RUN_MS.toInt(), easing = LinearEasing))
        if (saved == null) {
            saved = Receipt.saveToDownloads(context, data)
            savedShown = true
        }
        delay(900)
        lift.animateTo(0f, tween(620, easing = FastOutSlowInEasing))
        onDone()
    }

    LaunchedEffect(skipRequested) {
        if (!skipRequested) return@LaunchedEffect
        PrintSound.stop()
        if (saved == null) {
            saved = Receipt.saveToDownloads(context, data)
            savedShown = true
        }
        onDone()
    }

    DisposableEffect(Unit) {
        onDispose { PrintSound.stop() }
    }

    val p = progress.value
    val feed = ((p - FEED_START) / (FEED_END - FEED_START)).coerceIn(0f, 1f)
    val status = when {
        p < 0.06f -> "POWERING PRINTER"
        p < 0.15f -> "CALIBRATING HEAD"
        p < 0.62f -> "PRINTING YOUR RECEIPT"
        p < 0.75f -> "COLOUR PASS"
        p < 0.88f -> "VERIFYING PURCHASE"
        else -> "PREMIUM UNLOCKED"
    }

    Box(
        Modifier
            .fillMaxSize()
            .alpha(lift.value)
            .background(Color(0xFF090A10))
            .drawBehind { drawUnlockAtmosphere(p) },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 22.dp),
        ) {
            Text(
                "MOMENTUM / PREMIUM",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = GoldNeon.copy(alpha = 0.86f),
                letterSpacing = 1.8.sp,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                status,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.72f),
            )
            Spacer(Modifier.height(18.dp))

            Box(
                Modifier
                    .width(316.dp)
                    .height(560.dp)
                    // The slip is allowed to move through the printer bay,
                    // never outside the bay onto the top of the screen.
                    .clipToBounds(),
                contentAlignment = Alignment.TopCenter,
            ) {
                // Moving chromatic light around the printer gives the scene a
                // premium "glass hardware" feel without requiring API-31 blur.
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                        .drawBehind {
                            val sweep = (p * 1.7f) % 1f
                            val cx = size.width * (0.18f + sweep * 0.64f)
                            val r = size.width * 0.78f
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        GoldNeon.copy(alpha = 0.22f),
                                        Sky.accent.copy(alpha = 0.12f),
                                        Lilac.accent.copy(alpha = 0.08f),
                                        Color.Transparent,
                                    ),
                                    center = Offset(cx, size.height * 0.55f),
                                    radius = r,
                                ),
                                radius = r,
                                center = Offset(cx, size.height * 0.55f),
                            )
                        },
                )

                // The paper itself is the hero. The slot remains in front so
                // the slip genuinely emerges from a machine rather than from
                // an ordinary card transition.
                Box(
                    Modifier
                        .padding(top = 36.dp)
                        .graphicsLayer {
                            // Start fully inside the clipped printer bay and
                            // feed downward to the final receipt position.
                            // The old negative translation was allowed to
                            // escape the parent, which is why a white sheet
                            // could visibly appear from above the printer.
                            translationY = -size.height * (1f - feed) + 72.dp.toPx()
                            alpha = if (feed > 0.01f) 1f else 0f
                        },
                ) {
                    Slip(data, feed)
                }

                // Printer body and slot lip. The small lights react to the
                // playhead, making the machine look alive while the paper moves.
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(74.dp)
                        .align(Alignment.TopCenter)
                        .clip(RoundedCornerShape(24.dp))
                        .drawBehind {
                            drawRoundRect(
                                brush = Brush.verticalGradient(
                                    listOf(Color(0xFF30323B), Color(0xFF111218)),
                                ),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(24.dp.toPx()),
                            )
                            drawRoundRect(
                                color = Color.White.copy(alpha = 0.10f),
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.2.dp.toPx()),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(24.dp.toPx()),
                            )
                            val head = size.width * (0.18f + feed * 0.64f)
                            drawCircle(GoldNeon.copy(alpha = 0.8f), 4.dp.toPx(), Offset(head, 22.dp.toPx()))
                            drawCircle(Mint.fill.copy(alpha = 0.8f), 3.dp.toPx(), Offset(head + 18.dp.toPx(), 22.dp.toPx()))
                            drawRect(
                                color = Color.Black.copy(alpha = 0.72f),
                                topLeft = Offset(size.width * 0.10f, size.height * 0.54f),
                                size = Size(size.width * 0.80f, 18.dp.toPx()),
                            )
                            // The scan beam used to run on its own clock —
                            // (p * 7f) % 1f, a flicker with no relationship
                            // to how much of the receipt had actually
                            // printed. It looked like a light scanning
                            // across the slot while the paper underneath it
                            // printed at a completely different pace, which
                            // is the "text doesn't match" feeling: the one
                            // piece of motion inside the printer housing
                            // wasn't slaved to the same progress everything
                            // else on this screen already reads from. Tied
                            // to `feed` now, the same value driving both the
                            // paper's position and its own content reveal.
                            val beamY = size.height * (0.54f + 0.06f * feed)
                            drawRect(
                                brush = Brush.horizontalGradient(
                                    listOf(Color.Transparent, Sky.fill.copy(alpha = 0.48f), Lilac.fill.copy(alpha = 0.34f), Color.Transparent),
                                ),
                                topLeft = Offset(size.width * 0.12f, beamY),
                                size = Size(size.width * 0.76f, 2.dp.toPx()),
                            )
                        },
                )
            }

            Spacer(Modifier.height(8.dp))
            Text(
                if (savedShown && saved != null) "Receipt saved · ${saved!!.takeLast(12)}"
                else "Printer online · ${((p * 100).toInt()).coerceIn(0, 100)}%",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.50f),
            )
            Spacer(Modifier.height(18.dp))

            // Progress is intentionally a thin machine-like rail, not a
            // generic Material progress indicator.
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.08f))
                    .drawBehind {
                        drawRoundRect(
                            brush = Brush.horizontalGradient(
                                listOf(Tang.fill, GoldNeon, Sky.fill, Lilac.fill, Mint.fill),
                            ),
                            size = Size(size.width * p.coerceIn(0f, 1f), size.height),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx()),
                        )
                    },
            )
            Spacer(Modifier.height(16.dp))

            if (p < 0.88f) {
                Text(
                    "20s unlock sequence · tap to skip",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = Color.White.copy(alpha = 0.35f),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.06f))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .then(
                            Modifier.clickableNoRipple(
                                remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            ) { skipRequested = true },
                        ),
                )
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawUnlockAtmosphere(p: Float) {
    val pulse = 0.55f + 0.45f * kotlin.math.sin(p * kotlin.math.PI.toFloat() * 12f).let { (it + 1f) / 2f }
    val r = size.minDimension * (0.25f + 0.16f * pulse)
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                GoldNeon.copy(alpha = 0.08f + 0.05f * pulse),
                Sky.fill.copy(alpha = 0.045f),
                Color.Transparent,
            ),
            center = Offset(size.width * 0.50f, size.height * 0.44f),
            radius = r,
        ),
        radius = r,
        center = Offset(size.width * 0.50f, size.height * 0.44f),
    )
    // End burst: sparse rays instead of a particle storm, so the receipt stays
    // readable and the final beat still feels expensive rather than noisy.
    if (p > 0.88f) {
        val q = ((p - 0.88f) / 0.12f).coerceIn(0f, 1f)
        val cx = size.width / 2f
        val cy = size.height * 0.44f
        repeat(18) { i ->
            val a = i / 18f * kotlin.math.PI.toFloat() * 2f
            val inner = size.minDimension * (0.12f + 0.04f * q)
            val outer = inner + size.minDimension * 0.11f * q
            drawLine(
                color = listOf(GoldNeon, Sky.fill, Lilac.fill, Mint.fill, Tang.fill)[i % 5].copy(alpha = 0.72f * (1f - q * 0.35f)),
                start = Offset(cx + kotlin.math.cos(a) * inner, cy + kotlin.math.sin(a) * inner),
                end = Offset(cx + kotlin.math.cos(a) * outer, cy + kotlin.math.sin(a) * outer),
                strokeWidth = 2.dp.toPx(),
            )
        }
    }
}

/**
 * The slip itself. Monospace and dotted rules, matching the saved PNG.
 *
 * [printed] is the same feed value driving the outer translation. Slip masks
 * its own lower portion in white while printed < 1, so the paper is not just
 * sliding into frame already finished -- each line's turn to appear tracks
 * the same motor pulse the haptics are ticking to.
 */
@Composable
private fun Slip(data: AppData, printed: Float) {
    val stamp = remember {
        LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy · HH:mm"))
    }
    // The app's own paper, not thermal-till white.
    //
    // Plain black-on-white was the honest thermal reference, and it was also
    // the one screen in the whole app with none of its colour language on
    // it -- every card elsewhere is cream with a coloured header band and one
    // accent doing the talking. A Tang header and a Sky-tinted key box are
    // the same move Plans and Home already make; this just brings the
    // receipt in line with them instead of leaving it looking imported.
    Column(
        Modifier
            .width(272.dp)
            .clip(RoundedCornerShape(10.dp))
            .drawWithContent {
                drawContent()
                if (printed < 0.999f) {
                    // The unprinted portion, covered in whichever background
                    // that band actually is -- Tang behind the header, cream
                    // everywhere else -- so the reveal never flashes the
                    // wrong colour over a region it has not reached yet.
                    val cut = (size.height * (printed + 0.06f)).coerceAtMost(size.height)
                    val headerPx = 64.dp.toPx()
                    if (cut < headerPx) {
                        drawRect(
                            color = Tang.fill,
                            topLeft = Offset(0f, cut),
                            size = Size(size.width, headerPx - cut),
                        )
                        drawRect(
                            color = CreamCard,
                            topLeft = Offset(0f, headerPx),
                            size = Size(size.width, size.height - headerPx),
                        )
                    } else {
                        drawRect(
                            color = CreamCard,
                            topLeft = Offset(0f, cut),
                            size = Size(size.width, size.height - cut),
                        )
                    }
                    // The moving edge itself, drawn right where the mask
                    // above stops -- a thin warm line sitting exactly on
                    // the boundary between printed and not-yet-printed, so
                    // there is one clear place the eye can watch new lines
                    // arrive from rather than reading the reveal as a flat
                    // curtain dropping.
                    drawRect(
                        color = Tang.accent.copy(alpha = 0.55f),
                        topLeft = Offset(0f, (cut - 1.5.dp.toPx()).coerceAtLeast(0f)),
                        size = Size(size.width, 1.5.dp.toPx()),
                    )
                }
            },
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Tang.fill)
                .padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "MOMENTUM",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = Ink,
            )
            Text(
                "focus, banked",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Ink.copy(alpha = 0.75f),
            )
        }

        Column(
            Modifier
                .background(CreamCard)
                .padding(horizontal = 18.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(stamp, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = InkMid)

            Spacer(Modifier.height(12.dp))
            DottedRule()
            Spacer(Modifier.height(12.dp))

            Text(
                "LICENCE KEY",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = InkMid,
            )
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Sky.fill.copy(alpha = 0.30f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            ) {
                Text(
                    License.pretty(data.licenseKey),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Ink,
                )
            }

            Spacer(Modifier.height(14.dp))
            DottedRule()
            Spacer(Modifier.height(12.dp))

            SlipRow("Item", "Lifetime")
            SlipRow("Holder", data.userName.ifBlank { "friend" })
            SlipRow("Focused", "${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m")
            // PAID in Mint -- the same colour this app already reaches for
            // whenever something is confirmed and settled.
            SlipRow("Status", "PAID", valueColor = Mint.accent)

            Spacer(Modifier.height(12.dp))
            DottedRule()
            Spacer(Modifier.height(10.dp))
            Text(
                "Blocking stays free. Always.",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = InkMid,
            )
        }
    }
}

@Composable
private fun SlipRow(label: String, value: String, valueColor: Color = Ink) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = InkMid)
        Text(
            value,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = valueColor,
        )
    }
}

@Composable
private fun DottedRule() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(1.dp)
            .drawBehind {
                var x = 0f
                while (x < size.width) {
                    drawRect(
                        color = Ink.copy(alpha = 0.45f),
                        topLeft = Offset(x, 0f),
                        size = androidx.compose.ui.geometry.Size(3f, size.height),
                    )
                    x += 7f
                }
            },
    )
}
