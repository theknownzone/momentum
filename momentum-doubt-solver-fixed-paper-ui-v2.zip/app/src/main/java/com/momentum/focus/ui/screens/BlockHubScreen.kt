package com.momentum.focus.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileCard
import com.momentum.focus.ui.components.TileObject
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

/**
 * Everything that blocks something, in one place.
 *
 * These controls were scattered by accident rather than design: the app list
 * opened from a Home card, per-app caps were buried inside that list, feeds
 * had their own Home card, profiles and class hours sat in a long settings
 * column next to avatars and exam dates. Four related answers to one question
 * — what is switched off — in four unrelated places.
 *
 * The hub does not own any of them. Each row still opens the screen that does
 * the work, so nothing was rewritten to build this; what changed is that there
 * is now one obvious place to look.
 */
@Composable
fun BlockHubScreen(
    data: AppData,
    onApps: () -> Unit,
    onFeeds: () -> Unit,
    onProfiles: () -> Unit,
    onSchedule: () -> Unit,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 24.dp),
    ) {
        Text("BLOCK", style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Text(
            "Kya band hai",
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            "Rokne wali har cheez yahan hai. Apps, feeds, limits, aur kab lagu ho.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp),
        )

        Spacer(Modifier.height(20.dp))

        HubRow(
            title = "Apps",
            detail = if (data.blockedPackages.isEmpty()) "Koi app band nahi"
            else "${data.blockedPackages.size} apps band" +
                if (data.dailyCapMinutes.isEmpty()) ""
                else " · ${data.dailyCapMinutes.size} pe daily limit",
            sticker = Tang,
            art = TileArt.Apps,
            imageRes = com.momentum.focus.R.drawable.block_apps_art,
        ) { haptics.tap(); onApps() }

        HubRow(
            title = "Feeds",
            detail = if (data.blockedSurfaces.isEmpty()) "Shorts aur Reels chalu hain"
            else "${data.blockedSurfaces.size} feeds band · app khuli rehti hai",
            sticker = Mint,
            art = TileArt.Feed,
            imageRes = null,
        ) { haptics.tap(); onFeeds() }

        HubRow(
            title = "Profiles",
            detail = data.profiles.firstOrNull { it.id == data.activeProfileId }?.let {
                "${it.name} chalu hai"
            } ?: if (data.profiles.isEmpty()) "Koi profile nahi"
            else "${data.profiles.size} saved",
            sticker = Sky,
            art = TileArt.Person,
            imageRes = com.momentum.focus.R.drawable.block_profile_art,
        ) { haptics.tap(); onProfiles() }

        HubRow(
            title = "Kab lagu ho",
            detail = if (!data.classHoursOn) "Class hours off"
            else "${data.classStartHour}:00–${data.classEndHour}:00 · " +
                "hafte mein ${data.classDays.size} din",
            sticker = Butter,
            art = TileArt.Calendar,
            imageRes = com.momentum.focus.R.drawable.block_schedule_art,
        ) { haptics.tap(); onSchedule() }

        Spacer(Modifier.height(20.dp))

        Text(
            "Pact ke dauran in sab ko sirf kas sakte ho — dheela nahi kar sakte.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(20.dp))

        SquishButton(
            label = "Done",
            sticker = Emerald,
            modifier = Modifier.fillMaxWidth(),
        ) { haptics.confirm(); onDone() }
    }
}

@Composable
private fun HubRow(
    title: String,
    detail: String,
    sticker: Sticker,
    art: TileArt,
    imageRes: Int?,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(28.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .clip(shape)
            .background(
                Brush.horizontalGradient(
                    listOf(
                        sticker.fill.copy(alpha = 0.98f),
                        sticker.fill.copy(alpha = 0.88f),
                        Color(0xFF10202C).copy(alpha = 0.94f),
                    )
                )
            )
            .border(2.dp, sticker.accent.copy(alpha = 0.95f), shape)
            .clickableNoRipple(remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { onClick() }
            .height(116.dp)
    ) {
        // The reference cards are illustration-led, not icon-led. Keep the
        // artwork on the right and let the left side carry the readable copy.
        if (imageRes != null) {
            Image(
                painter = painterResource(imageRes),
                contentDescription = null,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .width(160.dp)
                    .clip(RoundedCornerShape(topStart = 54.dp, bottomStart = 54.dp))
                    .drawBehind {
                        drawRect(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.42f))
                            )
                        )
                    },
            )
        } else {
            FeedArtwork(Modifier.align(Alignment.CenterEnd))
        }

        Column(
            Modifier
                .align(Alignment.CenterStart)
                .padding(start = 22.dp, end = 150.dp),
        ) {
            Text(
                title,
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                detail,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.86f),
                maxLines = 2,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                when (art) {
                    TileArt.Apps -> "FOCUS MODE ON"
                    TileArt.Feed -> "SCROLL LESS. LIVE MORE."
                    TileArt.Person -> "STAY PRIVATE. STAY FOCUSED."
                    else -> "DISCIPLINE BUILDS FREEDOM."
                },
                style = MaterialTheme.typography.labelSmall,
                color = sticker.accent,
                letterSpacing = 1.5.sp,
            )
        }

        Text(
            "›",
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 18.dp),
            style = MaterialTheme.typography.displayMedium,
            color = Color.White.copy(alpha = 0.95f),
        )
    }
}

@Composable
private fun FeedArtwork(modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier.size(width = 156.dp, height = 112.dp)) {
        val cards = listOf(
            "SHORTS" to Color(0xFF8C6CFF),
            "REELS" to Color(0xFFFF5E8C),
            "STORIES" to Color(0xFFFFB83D),
        )
        cards.forEachIndexed { i, pair ->
            val y = 12.dp.toPx() + i * 29.dp.toPx()
            drawRoundRect(
                color = Color(0xFF0B1825).copy(alpha = 0.94f),
                topLeft = androidx.compose.ui.geometry.Offset(20.dp.toPx(), y),
                size = androidx.compose.ui.geometry.Size(112.dp.toPx(), 24.dp.toPx()),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8.dp.toPx()),
            )
            drawCircle(pair.second, 5.dp.toPx(), androidx.compose.ui.geometry.Offset(34.dp.toPx(), y + 12.dp.toPx()))
        }
        drawCircle(Color(0xFFFF9F1C).copy(alpha = 0.92f), 22.dp.toPx(), androidx.compose.ui.geometry.Offset(108.dp.toPx(), 57.dp.toPx()))
        drawLine(Color(0xFF102132), androidx.compose.ui.geometry.Offset(97.dp.toPx(), 46.dp.toPx()), androidx.compose.ui.geometry.Offset(119.dp.toPx(), 68.dp.toPx()), 4.dp.toPx())
        drawLine(Color(0xFF102132), androidx.compose.ui.geometry.Offset(119.dp.toPx(), 46.dp.toPx()), androidx.compose.ui.geometry.Offset(97.dp.toPx(), 68.dp.toPx()), 4.dp.toPx())
    }
}
