package com.momentum.focus.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.components.Avatar3D
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * The payoff moment.
 *
 * Everything fires at once on purpose — haptic, sound, confetti, a shape
 * punching in with overshoot. Reward has to be loud and immediate or it does
 * not register as reward at all. This is the only screen in the app allowed to
 * shout, which is exactly why it works.
 */
@Composable
fun CelebrationScreen(
    kicker: String,
    title: String,
    body: String,
    colorIndex: Int,
    shapeIndex: Int,
    // Optional content between the body text and the button — the streak
    // celebration uses it for the week's tick row. Nothing else passes it,
    // so every existing call site is unaffected.
    //
    // Placed before onDone, not after. A trailing lambda always fills
    // whichever parameter is *last* in the signature, regardless of name —
    // with extra last, a call site that names extra explicitly and still
    // uses a trailing lambda for onDone (the streak screen does exactly
    // this) has the trailing lambda try to fill extra a second time, and
    // onDone is left with nothing. Keeping onDone last is what every other
    // call site's `{ ... }` is actually relying on.
    extra: (@Composable () -> Unit)? = null,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()
    val pop = remember { Animatable(0.2f) }
    val confetti = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        haptics.celebrate()
        pop.animateTo(
            1f,
            spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        )
    }
    LaunchedEffect(Unit) {
        confetti.animateTo(1f, tween(5200, easing = LinearEasing))
    }

    // Premium's welcome is a transition, not a dead-end screen. Keep the
    // button available, but automatically continue after the celebration has
    // had time to register. This also prevents the post-purchase flow from
    // appearing frozen when the user does not tap immediately.
    LaunchedEffect(kicker) {
        if (kicker == "PREMIUM") {
            kotlinx.coroutines.delay(6500)
            onDone()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Ink),
        contentAlignment = Alignment.Center,
    ) {
        if (kicker == "PREMIUM") PremiumBottomHorizon()
        Confetti(confetti.value)

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 40.dp, bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(1f))

            Box(Modifier.scale(pop.value)) {
                if (kicker == "PREMIUM") {
                    PremiumCelebrationVisual()
                } else {
                    Avatar3D(colorIndex = colorIndex, shapeIndex = shapeIndex, size = 150.dp)
                }
            }

            Spacer(Modifier.height(if (kicker == "PREMIUM") 18.dp else 28.dp))

            Text(
                kicker,
                style = MaterialTheme.typography.labelSmall,
                color = stickerFor(colorIndex).fill,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                title,
                style = MaterialTheme.typography.displayMedium,
                color = CreamCard,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                body,
                style = MaterialTheme.typography.bodyLarge,
                color = InkLow,
                textAlign = TextAlign.Center,
            )

            if (extra != null) {
                Spacer(Modifier.height(20.dp))
                extra()
            }

            Spacer(Modifier.weight(1f))

            SquishButton(
                label = "Keep going",
                sticker = stickerFor(colorIndex),
                modifier = Modifier.fillMaxWidth(),
                onClick = onDone,
            )
        }
    }
}

/**
 * Premium-only celebration visual.
 *
 * The old Avatar3D was a static vector-like object that could read as a random
 * cube/shape after a premium unlock. This is deliberately drawn in Canvas:
 * luminous glass core, breathing halo, rotating orbit lines and a sharp
 * highlight. No bitmap/vector asset can stall or fail to render here.
 */
@Composable
private fun PremiumCelebrationVisual() {
    val infinite = rememberInfiniteTransition(label = "premium-celebration")
    val breath by infinite.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.10f,
        animationSpec = infiniteRepeatable(
            animation = tween(1700, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "premium-breath",
    )
    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(5200, easing = LinearEasing),
        ),
        label = "premium-orbit",
    )

    Canvas(
        Modifier.size(250.dp),
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = size.minDimension * 0.31f * breath

        // Wide breathing atmosphere.
        drawCircle(
            brush = Brush.radialGradient(
                colorStops = arrayOf(
                    0f to GoldNeon.copy(alpha = 0.34f),
                    0.35f to Lilac.fill.copy(alpha = 0.16f),
                    0.72f to Sky.fill.copy(alpha = 0.06f),
                    1f to Color.Transparent,
                ),
                center = Offset(cx, cy),
                radius = r * 3.1f,
            ),
            radius = r * 3.1f,
            center = Offset(cx, cy),
        )

        // Rotating orbital rings.
        repeat(4) { i ->
            val rr = r * (1.38f + i * 0.34f)
            drawOval(
                brush = Brush.linearGradient(
                    listOf(
                        Color.Transparent,
                        Sky.fill.copy(alpha = 0.65f - i * 0.12f),
                        Lilac.fill.copy(alpha = 0.55f - i * 0.10f),
                        Color.Transparent,
                    ),
                ),
                topLeft = Offset(cx - rr, cy - rr * 0.46f),
                size = Size(rr * 2f, rr * 0.92f),
                style = Stroke(
                    width = (2.2f - i * 0.35f).dp.toPx(),
                ),
                alpha = 0.85f,
            )
        }

        // Glass core.
        drawCircle(
            brush = Brush.radialGradient(
                colorStops = arrayOf(
                    0f to Color(0xFFFFFFFF),
                    0.16f to Color(0xFFEAF6FF),
                    0.42f to Sky.fill.copy(alpha = 0.95f),
                    0.72f to Lilac.fill.copy(alpha = 0.72f),
                    1f to Color(0xFF080B16),
                ),
                center = Offset(cx - r * 0.20f, cy - r * 0.22f),
                radius = r * 1.25f,
            ),
            radius = r,
            center = Offset(cx, cy),
        )

        // Lower glass horizon.
        drawArc(
            brush = Brush.linearGradient(
                listOf(
                    Color.Transparent,
                    Sky.fill,
                    GoldNeon,
                    Color.Transparent,
                ),
            ),
            startAngle = 15f,
            sweepAngle = 150f,
            useCenter = false,
            topLeft = Offset(cx - r, cy - r),
            size = Size(r * 2f, r * 2f),
            style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round),
        )

        // Moving specular point.
        val a = rotation * Math.PI.toFloat() / 180f
        val sx = cx + cos(a) * r * 0.70f
        val sy = cy + sin(a) * r * 0.45f
        drawCircle(
            color = Color.White.copy(alpha = 0.9f),
            radius = 3.5.dp.toPx(),
            center = Offset(sx, sy),
        )
        drawCircle(
            color = Sky.fill.copy(alpha = 0.28f),
            radius = 12.dp.toPx(),
            center = Offset(sx, sy),
        )
    }
}

@Composable
private fun PremiumBottomHorizon() {
    val infinite = rememberInfiniteTransition(label = "premium-horizon")
    val pulse by infinite.animateFloat(
        initialValue = 0.72f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "premium-horizon-pulse",
    )
    Canvas(
        Modifier
            .fillMaxSize()
            .alpha(0.95f)
    ) {
        val y = size.height * 0.91f
        val center = Offset(size.width * 0.50f, y)
        val radius = size.width * (0.72f + pulse * 0.08f)
        drawCircle(
            brush = Brush.radialGradient(
                colorStops = arrayOf(
                    0f to Sky.fill.copy(alpha = 0.24f * pulse),
                    0.30f to Lilac.fill.copy(alpha = 0.12f * pulse),
                    0.60f to Color.White.copy(alpha = 0.055f),
                    1f to Color.Transparent,
                ),
                center = center,
                radius = radius,
            ),
            radius = radius,
            center = center,
        )
        drawArc(
            brush = Brush.horizontalGradient(
                listOf(Color.Transparent, Sky.fill.copy(alpha = 0.72f), Color.White.copy(alpha = 0.92f), Sky.fill.copy(alpha = 0.72f), Color.Transparent)
            ),
            startAngle = 196f,
            sweepAngle = 148f,
            useCenter = false,
            topLeft = Offset(size.width * 0.05f, y - size.width * 0.23f),
            size = Size(size.width * 0.90f, size.width * 0.46f),
            style = Stroke(width = 2.6.dp.toPx()),
        )
    }
}

/**
 * Confetti as plain rectangles falling on sine paths.
 *
 * A particle system would be overkill: at this size the eye reads colour and
 * motion, not shape, so fifty rectangles with different phases is enough and
 * costs nothing.
 */
@Composable
private fun Confetti(progress: Float) {
    val pieces = remember {
        val rng = Random(9)
        List(72) {
            ConfettiPiece(
                x = rng.nextFloat(),
                delay = rng.nextFloat() * 0.35f,
                speed = 0.7f + rng.nextFloat() * 0.6f,
                drift = (rng.nextFloat() - 0.5f) * 0.18f,
                width = 6f + rng.nextFloat() * 8f,
                height = 10f + rng.nextFloat() * 12f,
                color = StickerCycle[rng.nextInt(StickerCycle.size)].fill,
                phase = rng.nextFloat() * 6.28f,
            )
        }
    }

    Canvas(Modifier.fillMaxSize()) {
        pieces.forEach { p ->
            val t = ((progress - p.delay) * p.speed).coerceIn(0f, 1f)
            if (t <= 0f) return@forEach
            val y = t * (size.height + 120f) - 60f
            val x = p.x * size.width + sin(t * 6f + p.phase) * size.width * p.drift
            drawRect(
                color = p.color.copy(alpha = (1f - t * 0.65f).coerceIn(0f, 1f)),
                topLeft = Offset(x, y),
                size = Size(p.width, p.height),
            )
        }
    }
}

private data class ConfettiPiece(
    val x: Float,
    val delay: Float,
    val speed: Float,
    val drift: Float,
    val width: Float,
    val height: Float,
    val color: Color,
    val phase: Float,
)
