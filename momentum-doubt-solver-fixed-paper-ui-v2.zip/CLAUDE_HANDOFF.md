# Momentum premium / MyAI update

Implemented in this source package:

- Fixed `AiZomatoReveal.kt` Float/Double math compile errors.
- Kept the cinematic MyAI orb: dark glass sphere, iridescent refraction, connected aura ribbons, specular highlight, bright lower rim/horizon and bottom bloom, with the existing sound/haptic beat integration.
- Pricing screen:
  - Monthly display: ₹49/mo
  - Yearly display: ₹399/yr
  - Monthly/Yearly control responds to taps and horizontal swipes.
  - Added animated bottom halogen-style breathing light.
  - Added oversized atmospheric PRICING / AI ghost typography and connector-node network inspired by the supplied references.
- Premium welcome:
  - Removed the old Avatar3D/vector-style visual for the Premium celebration.
  - Replaced it with a Canvas-rendered luminous glass orb/orbit celebration with breathing glow and moving specular point.
  - Confetti duration extended.
  - Premium welcome auto-advances after 6.5 seconds so it cannot appear frozen, while the Keep going button remains available.
- Permissions:
  - Android 13+ Notifications now uses the native runtime Allow / Don't allow dialog directly from the notification card.
  - Other special permissions continue to use their required system settings screens.

Important: the app's existing purchase/redeem implementation is still lifetime-key based. The ₹49/₹399 monthly/yearly selector is currently presentation/UI only unless a real Play Billing subscription backend is added.
