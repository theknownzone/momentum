package com.momentum.focus.data

import kotlinx.serialization.Serializable
import java.time.LocalDate
import java.time.LocalDateTime

@Serializable
data class FocusSession(
    val startedAtEpochDay: Long,
    val minutes: Int,
    val subject: String,
    val completed: Boolean,
)

@Serializable
data class UrgeEvent(
    val epochDay: Long,
    val hour: Int,
    val survived: Boolean,
    val note: String = "",
)

@Serializable
data class JournalEntry(
    val epochDay: Long,
    val mood: Int,          // 1..5
    val text: String,
    val trigger: String = "",
)

@Serializable
data class AppData(
    val userName: String = "friend",
    val streakStartEpochDay: Long = LocalDate.now().toEpochDay(),
    val bestStreak: Int = 0,
    val streakGoal: Int = 90,
    val sessions: List<FocusSession> = emptyList(),
    val urges: List<UrgeEvent> = emptyList(),
    val journal: List<JournalEntry> = emptyList(),
    val subjects: List<String> = listOf("Physics", "Maths", "Chemistry", "Revision"),
    val onboarded: Boolean = false,
    val spentMinutes: Int = 0,
    val blockedPackages: Set<String> = emptySet(),
    val shieldOn: Boolean = false,
    val avatarSymbol: String = "",
    val avatarColor: Int = 3,
    val lastSeenVersion: String = "",
    /** Minutes of study needed to earn one minute of distraction. */
    val earnRatio: Int = 8,
    val crownMode: Boolean = false,
    val studyPackages: Set<String> = emptySet(),
    val studyXp: Int = 0,
) {
    val streakDays: Int
        get() = (LocalDate.now().toEpochDay() - streakStartEpochDay).toInt().coerceAtLeast(0)

    fun minutesOn(day: Long): Int =
        sessions.filter { it.startedAtEpochDay == day && it.completed }.sumOf { it.minutes }

    val minutesToday: Int get() = minutesOn(LocalDate.now().toEpochDay())

    val sessionsToday: Int
        get() = sessions.count {
            it.startedAtEpochDay == LocalDate.now().toEpochDay() && it.completed
        }

    /** Minutes per day for the last [days] days, oldest first. */
    fun recentMinutes(days: Int): List<Int> {
        val today = LocalDate.now().toEpochDay()
        return (days - 1 downTo 0).map { minutesOn(today - it) }
    }

    val urgesSurvived: Int get() = urges.count { it.survived }

    /** Every completed minute of focus is earned currency. */
    val earnedMinutes: Int get() = sessions.filter { it.completed }.sumOf { it.minutes }

    /**
     * What is left to spend on distraction.
     *
     * Earned minutes are divided by the ratio, so eight minutes of study buys
     * one minute of scrolling by default. A one-to-one trade would let anyone
     * bank a morning and lose the afternoon.
     */
    val balanceMinutes: Int
        get() = ((earnedMinutes / earnRatio.coerceAtLeast(1)) - spentMinutes).coerceAtLeast(0)

    val level: Int get() = 1 + (studyXp / 600)
    val xpIntoLevel: Int get() = studyXp % 600

    val todayJournal: JournalEntry?
        get() = journal.firstOrNull { it.epochDay == LocalDate.now().toEpochDay() }
}

fun nowHour(): Int = LocalDateTime.now().hour
