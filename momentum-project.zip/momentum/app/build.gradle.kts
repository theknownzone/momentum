plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.momentum.focus"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.momentum.focus"
        minSdk = 26
        targetSdk = 35
        // CI supplies the run number so every build is a higher version than
        // the last, which is what the in-app updater compares against.
        val run = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionCode = run
        versionName = "1.0.$run"
    }

    // A fixed signing key, checked into the project on purpose.
    //
    // CI generates a brand new debug keystore on every run, so each build was
    // signed by a different key and Android refused to update over the last
    // install ("package conflicts"). Pinning one key makes every build an
    // upgrade of the previous one.
    signingConfigs {
        create("shared") {
            // The committed keystore is a convenience, not a good one. Its
            // password is in the repo, so anyone can sign an APK that Android
            // will happily install over this app as an update. Play Protect
            // treats a widely-known signing key as a risk signal on top of
            // everything else the app declares.
            //
            // If MOMENTUM_KEYSTORE_B64 and the two passwords are set as
            // repository secrets, the workflow writes the private key to
            // release.jks and this picks it up. Nothing changes for anyone who
            // has not set them up yet.
            val privateKey = file("release.jks")
            val committed = file("momentum.jks")
            when {
                privateKey.exists() && System.getenv("MOMENTUM_KEY_PASSWORD") != null -> {
                    storeFile = privateKey
                    storePassword = System.getenv("MOMENTUM_STORE_PASSWORD")
                    keyAlias = System.getenv("MOMENTUM_KEY_ALIAS") ?: "momentum"
                    keyPassword = System.getenv("MOMENTUM_KEY_PASSWORD")
                }
                committed.exists() -> {
                    storeFile = committed
                    storePassword = "momentum123"
                    keyAlias = "momentum"
                    keyPassword = "momentum123"
                }
                // Neither key is present. Left unset on purpose so the build
                // falls through to Android's own debug key rather than failing.
                //
                // It used to point at momentum.jks unconditionally, so removing
                // that file — which is exactly what you must do before selling
                // anything — broke every build with "Keystore file not found".
                // The one step on the path to doing this properly was the step
                // that stopped the project compiling.
                //
                // The cost is that builds made this way are signed by a key
                // that differs per machine, so Android will refuse to update
                // over an install signed by a different one. Set the secrets
                // and that stops being true.
                else -> Unit
            }
        }
    }

    // Only attached when a key was actually found. An empty signing config
    // fails validation just as hard as a missing file, so the check has to
    // happen here too, not only where the config is built.
    val sharedKey = signingConfigs.getByName("shared").takeIf { it.storeFile != null }

    buildTypes {
        getByName("debug") {
            // Only overwritten when a real key exists. Assigning null here does
            // not fall back to anything — it removes the default debug signing
            // config that AGP already put on this build type, and the APK comes
            // out unsigned. An unsigned APK is what Android reports as "package
            // appears to be invalid", which is a confusing way to say nobody
            // signed it.
            if (sharedKey != null) signingConfig = sharedKey
            // The APK people actually install is this one, built by CI and
            // sideloaded. AGP marks debug builds android:debuggable, and a
            // sideloaded app that is debuggable AND declares an accessibility
            // service reads to Play Protect exactly like a trojan. Turning it
            // off costs nothing here — nobody attaches a debugger to the
            // release APK — and removes the worst signal in the profile.
            isDebuggable = false
        }
        release {
            isMinifyEnabled = false
            // Release has no default of its own, so it borrows the debug key
            // when no private one is configured. Not fit to publish, but it
            // produces an APK that installs instead of one that cannot.
            signingConfig = sharedKey ?: signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.4")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")

    implementation(platform("androidx.compose:compose-bom:2024.11.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
