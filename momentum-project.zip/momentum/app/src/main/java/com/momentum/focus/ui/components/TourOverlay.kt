package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Sticker
import com.momentum.focus.ui.theme.Tang

private data class TourStep(
    val kicker: String,
    val title: String,
    val body: String,
    val sticker: Sticker,
)

private val steps = listOf(
    TourStep(
        "1 / 5", "Padho, phir kamao",
        "Focus tab pe timer chalao. Jitne minute padhoge, utne ₹ wallet mein aayenge. " +
            "Bina padhe kuch nahi milta — yahi poori app ka niyam hai.",
        Mint,
    ),
    TourStep(
        "2 / 5", "Shield apps rokta hai",
        "Jo apps tum chuno, unpe shield lag jaata hai. Khologe to block screen aayegi. " +
            "Wallet se time khareed sakte ho, par apni hi daily limit se aage nahi.",
        Sky,
    ),
    TourStep(
        "3 / 5", "Feeds alag se rukti hain",
        "Shorts, Reels, Stories band ho sakti hain jabki baaki app chalti rahe. " +
            "YouTube pe lecture chalega, Shorts nahi. Iske liye Accessibility on karni padegi.",
        Tang,
    ),
    TourStep(
        "4 / 5", "Pact sirf sakht hota hai",
        "Pact laga do to level girana, shield band karna ya limit dheeli karna band. " +
            "Sirf badha sakte ho. Jo khud se decide kiya, wo kamzor pal mein badla nahi ja sakta.",
        Butter,
    ),
    TourStep(
        "5 / 5", "Numbers sach hote hain",
        "Streak tabhi badhega jab sach mein padhoge. Ginti tabhi shuru hogi jab data hoga. " +
            "Jo yahan dikhega wo kamaya hua hoga, banaya hua nahi.",
        Mint,
    ),
)

/**
 * The one-time walkthrough a new install gets.
 *
 * Five things have to land before any of the screens make sense: minutes turn
 * into money, the shield exists, feeds are separate from apps, a pact only
 * tightens, and the numbers are real. Someone who opens the app cold and finds
 * a wallet with ₹0 and a locked toggle has no way to work that out.
 *
 * Deliberately not a spotlight over the live UI. Anchoring cut-outs to real
 * composables means measuring their coordinates, and a wrong measurement puts
 * the hole over empty space — worse than no tour at all.
 */
@Composable
fun TourOverlay(onDone: () -> Unit) {
    var index by remember { mutableStateOf(0) }
    val step = steps[index]

    // Reset per step, so each card scales up on arrival. Animating straight to
    // 1f from a state that already holds 1f produces no motion at all — the
    // value has to start below the target for every step, not just the first.
    var settled by remember(index) { mutableStateOf(false) }
    LaunchedEffect(index) { settled = true }
    val pop by animateFloatAsState(
        targetValue = if (settled) 1f else 0.88f,
        animationSpec = tween(260),
        label = "pop",
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Ink.copy(alpha = 0.55f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .scale(pop)
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(step.sticker.fill)
                    .border(2.dp, Ink, RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
            ) {
                Text(
                    step.kicker,
                    style = MaterialTheme.typography.labelSmall,
                    color = step.sticker.on,
                )
            }

            Spacer(Modifier.height(14.dp))
            Text(
                step.title,
                style = MaterialTheme.typography.headlineSmall,
                color = Ink,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(10.dp))
            Text(
                step.body,
                style = MaterialTheme.typography.bodyLarge,
                color = InkMid,
                textAlign = TextAlign.Center,
            )

            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                steps.indices.forEach { i ->
                    Box(
                        Modifier
                            .size(if (i == index) 10.dp else 7.dp)
                            .clip(CircleShape)
                            .background(if (i == index) Ink else InkMid.copy(alpha = 0.4f))
                    )
                }
            }

            Spacer(Modifier.height(18.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(step.sticker.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        if (index < steps.lastIndex) index++ else onDone()
                    }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (index < steps.lastIndex) "Aage" else "Shuru karo",
                    style = MaterialTheme.typography.titleMedium,
                    color = step.sticker.on,
                )
            }

            if (index < steps.lastIndex) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Chhod do",
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                    modifier = Modifier
                        .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onDone)
                        .padding(6.dp),
                )
            }
        }
    }
}
