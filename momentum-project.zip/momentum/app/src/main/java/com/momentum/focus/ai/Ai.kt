package com.momentum.focus.ai

import com.momentum.focus.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * The one place the app talks to a model.
 *
 * HttpURLConnection and org.json, matching [com.momentum.focus.ui.util.Updater],
 * so this adds no dependency. Nothing here is on the blocking path of anything
 * — both callers treat a failure as "no answer this time" and carry on.
 *
 * ## The key
 * [BuildConfig.AI_KEY] comes from local.properties or CHUTES_API_KEY at build
 * time. When it is blank [enabled] is false and every entry point in the app
 * hides itself. A build made without the secret has no AI in it at all, which
 * is the only guarantee worth having: an APK cannot leak a key it never held.
 *
 * This is not a substitute for a server. Anyone holding an APK that *was*
 * built with a key can pull it out — so a key must never go into a build that
 * is handed to strangers, and this must not ship in the version that is sold.
 */
object Ai {

    private const val URL_CHAT = "https://llm.chutes.ai/v1/chat/completions"

    /**
     * Chutes' own guidance is to read the live catalogue rather than pin an id,
     * because their line-up moves. This is the fallback for when that read
     * fails; [modelOverride] lets a debug screen point at something else
     * without a rebuild.
     */
    private const val DEFAULT_MODEL = "deepseek-ai/DeepSeek-V3.2"

    @Volatile
    var modelOverride: String? = null

    val enabled: Boolean get() = BuildConfig.AI_ENABLED && BuildConfig.AI_KEY.isNotBlank()

    /** A failure that the UI can show without pretending it was an answer. */
    class AiError(message: String) : Exception(message)

    /**
     * One round trip. Returns the assistant's text.
     *
     * [json] asks the model to reply with an object and nothing else, which is
     * what the coach needs and the chat does not.
     */
    suspend fun ask(
        system: String,
        user: String,
        maxTokens: Int = 900,
        temperature: Double = 0.4,
        json: Boolean = false,
    ): String = withContext(Dispatchers.IO) {
        if (!enabled) throw AiError("No API key in this build.")

        val body = JSONObject().apply {
            put("model", modelOverride ?: DEFAULT_MODEL)
            put("max_tokens", maxTokens)
            put("temperature", temperature)
            put("stream", false)
            put(
                "messages",
                JSONArray().apply {
                    put(JSONObject().put("role", "system").put("content", system))
                    put(JSONObject().put("role", "user").put("content", user))
                },
            )
            if (json) put("response_format", JSONObject().put("type", "json_object"))
        }.toString()

        val conn = (URL(URL_CHAT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            // Generous: a cold model can take a while to answer, and the
            // alternative is a timeout the user reads as a broken feature.
            readTimeout = 60_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer ${BuildConfig.AI_KEY}")
            setRequestProperty("Content-Type", "application/json")
        }

        try {
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            if (code !in 200..299) {
                // The error stream carries the reason — a bad key, a spent cap,
                // an unknown model. Swallowing it would leave nothing to debug.
                val detail = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw AiError(shortReason(code, detail))
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            JSONObject(text)
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
                .trim()
        } finally {
            conn.disconnect()
        }
    }

    /** Turns a status code into something worth putting on a screen. */
    private fun shortReason(code: Int, detail: String): String = when (code) {
        401, 403 -> "Key rejected. Check chutes.key in local.properties."
        402 -> "Chutes credits are spent."
        404 -> "That model id isn't on Chutes any more."
        429 -> "Rate limit or cap hit. Try again later."
        in 500..599 -> "Chutes is having trouble. Try again."
        else -> "Request failed ($code). ${detail.take(120)}"
    }

    /**
     * Strips the code fence some models wrap JSON in, so the caller can parse
     * without caring which model answered.
     */
    fun unfence(raw: String): String = raw
        .removePrefix("```json").removePrefix("```")
        .removeSuffix("```")
        .trim()
}
