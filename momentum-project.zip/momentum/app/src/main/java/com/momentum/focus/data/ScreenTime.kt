package com.momentum.focus.data

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.getSystemService
import java.util.Calendar
import java.util.concurrent.TimeUnit

data class AppUsage(
    val pkg: String,
    val label: String,
    val minutes: Int,
)

data class ScreenTimeReport(
    val dailyMinutes: List<Int>,      // last 7 days, oldest first
    val averageMinutes: Int,
    val longestDayIndex: Int,
    val longestDayMinutes: Int,
    val pickups: Int,
    val topApps: List<AppUsage>,
) {
    /**
     * Hours per day projected across thirty years, expressed in years.
     *
     * This is the number that lands. "Nine hours a day" is abstract; "twelve
     * years of your life" is not, and it is the same fact.
     */
    val yearsOverThirty: Double
        get() = (averageMinutes / 60.0) * 365 * 30 / (24 * 365)

    val hasData: Boolean get() = dailyMinutes.any { it > 0 }
}

/**
 * Real numbers from UsageStats — never estimates.
 *
 * The whole onboarding rests on the gap between what someone guesses and what
 * is actually true, so a fabricated figure would destroy the only thing that
 * makes the screen work.
 */
object ScreenTime {

    fun report(context: Context, days: Int = 7): ScreenTimeReport {
        val usage = context.getSystemService<UsageStatsManager>()
            ?: return empty(days)
        val pm = context.packageManager

        val daily = mutableListOf<Int>()
        val perApp = mutableMapOf<String, Long>()

        for (back in (days - 1) downTo 0) {
            val (start, end) = dayRange(back)
            val stats = runCatching {
                usage.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
            }.getOrNull().orEmpty()

            var dayTotal = 0L
            stats.forEach { s ->
                if (s.totalTimeInForeground <= 0) return@forEach
                // Launcher and system UI are always "in foreground" and would
                // swamp the totals, so they are dropped.
                if (isSystemNoise(s.packageName)) return@forEach
                dayTotal += s.totalTimeInForeground
                perApp[s.packageName] = (perApp[s.packageName] ?: 0) + s.totalTimeInForeground
            }
            daily += TimeUnit.MILLISECONDS.toMinutes(dayTotal).toInt()
        }

        val average = if (daily.isEmpty()) 0 else daily.sum() / daily.size
        val longest = daily.indices.maxByOrNull { daily[it] } ?: 0

        val top = perApp.entries
            .sortedByDescending { it.value }
            .take(6)
            .map { (pkg, ms) ->
                AppUsage(
                    pkg = pkg,
                    label = label(pm, pkg),
                    minutes = TimeUnit.MILLISECONDS.toMinutes(ms).toInt(),
                )
            }

        return ScreenTimeReport(
            dailyMinutes = daily,
            averageMinutes = average,
            longestDayIndex = longest,
            longestDayMinutes = daily.getOrElse(longest) { 0 },
            pickups = pickupsYesterday(context),
            topApps = top,
        )
    }

    /**
     * A pickup is the screen becoming interactive, not an app opening. Counting
     * app launches would triple the number every time someone switches tabs.
     */
    private fun pickupsYesterday(context: Context): Int {
        val usage = context.getSystemService<UsageStatsManager>() ?: return 0
        val (start, end) = dayRange(0)
        val events = runCatching { usage.queryEvents(start, end) }.getOrNull() ?: return 0
        val event = UsageEvents.Event()
        var count = 0
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.SCREEN_INTERACTIVE) count++
        }
        return count
    }

    private fun dayRange(daysBack: Int): Pair<Long, Long> {
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -daysBack)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val start = cal.timeInMillis
        return start to (start + TimeUnit.DAYS.toMillis(1))
    }

    private fun isSystemNoise(pkg: String): Boolean =
        pkg.contains("launcher", true) ||
            pkg.startsWith("com.android.systemui") ||
            pkg.startsWith("com.android.settings") ||
            pkg.startsWith("com.miui.home")

    private fun label(pm: PackageManager, pkg: String): String = runCatching {
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    private fun empty(days: Int) = ScreenTimeReport(
        dailyMinutes = List(days) { 0 },
        averageMinutes = 0,
        longestDayIndex = 0,
        longestDayMinutes = 0,
        pickups = 0,
        topApps = emptyList(),
    )
}
