package com.momentum.focus.data

import android.content.Context
import com.momentum.focus.ui.theme.Skin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class Holiday(
    val date: LocalDate,
    val name: String,
    val skin: Skin,
) {
    fun daysFrom(today: LocalDate = LocalDate.now()): Long =
        ChronoUnit.DAYS.between(today, date)

    val headline: String
        get() = when (val d = daysFrom()) {
            0L -> "Aaj $name hai"
            1L -> "Kal $name hai"
            in 2L..7L -> "$name in $d days"
            else -> name
        }
}

object HolidayCalendar {

    private const val REMOTE =
        "https://raw.githubusercontent.com/theknownzone/momentum/main/holidays.json"

    @Volatile
    private var cached: List<Holiday> = emptyList()

    fun bundled(context: Context): List<Holiday> {
        if (cached.isNotEmpty()) return cached
        val text = runCatching {
            context.assets.open("holidays.json").bufferedReader().use { it.readText() }
        }.getOrDefault("[]")
        cached = parse(text)
        return cached
    }

    suspend fun refresh(context: Context): List<Holiday> = withContext(Dispatchers.IO) {
        val local = bundled(context)
        val remote = runCatching {
            val conn = (URL(REMOTE).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
            }
            if (conn.responseCode != 200) return@runCatching null
            parse(conn.inputStream.bufferedReader().use { it.readText() })
        }.getOrNull()
        if (!remote.isNullOrEmpty()) {
            cached = remote
            remote
        } else local
    }

    /** The next holiday within a week, for the calendar note. Nearest wins. */
    fun upcoming(list: List<Holiday>, today: LocalDate = LocalDate.now()): Holiday? =
        list.filter { it.daysFrom(today) in 0L..7L }.minByOrNull { it.daysFrom(today) }
            ?: list.filter { it.daysFrom(today) >= 0 }.minByOrNull { it.daysFrom(today) }

    /**
     * The holiday whose skin should actually be on the Home hero.
     *
     * The window used to be three days wide, so the card announced "Kal Rakhi
     * hai" while the theme was already running and the line underneath it
     * promised the theme unlocks on the day. All three could not be true. A
     * festival skin now starts on the festival, which is the only reading that
     * matches what the card says.
     *
     * Both lookups take the nearest date. Rakhi used to be hardcoded to win,
     * which meant a Diwali tomorrow lost to a Rakhi next week.
     */
    fun inSeason(list: List<Holiday>, today: LocalDate = LocalDate.now()): Holiday? =
        list.firstOrNull { it.daysFrom(today) == 0L }

    private fun parse(text: String): List<Holiday> = runCatching {
        val arr = JSONArray(text)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val date = runCatching { LocalDate.parse(o.optString("date")) }.getOrNull()
                ?: return@mapNotNull null
            val skin = runCatching {
                Skin.valueOf(o.optString("skin", "SAKURA"))
            }.getOrDefault(Skin.SAKURA)
            Holiday(date = date, name = o.optString("name"), skin = skin)
        }.sortedBy { it.date }
    }.getOrDefault(emptyList())
}
