package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.delay
import java.time.LocalTime

/**
 * Greeting that types itself, once per app launch.
 *
 * The cursor blink and per-character delay are what make it read as being
 * addressed rather than labelled. Repeating it on every recomposition would
 * turn a nice touch into a stutter, so the animation is keyed to the name and
 * runs a single time.
 */
@Composable
fun TypedGreeting(
    name: String,
    modifier: Modifier = Modifier,
    nameColor: Color = MaterialTheme.colorScheme.onBackground,
    labelColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
) {
    val greeting = remember {
        when (LocalTime.now().hour) {
            in 5..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            in 17..20 -> "Good evening"
            else -> "Good night"
        }
    }

    val full = remember(name, greeting) { "$greeting, $name" }
    var shown by remember(full) { mutableIntStateOf(0) }
    var done by remember(full) { mutableStateOf(false) }

    LaunchedEffect(full) {
        shown = 0
        done = false
        // A short lead-in so the text is not already typing before the screen
        // has settled into place.
        delay(220)
        while (shown < full.length) {
            delay(38)
            shown++
        }
        delay(400)
        done = true
    }

    val cursor by animateFloatAsState(
        targetValue = if (done) 0f else 1f,
        animationSpec = tween(300),
        label = "cursor",
    )

    Column(modifier) {
        Text(
            full.take(shown) + if (done) "" else "|",
            style = MaterialTheme.typography.headlineSmall,
            color = nameColor,
            modifier = Modifier.alpha(1f - cursor * 0f),
        )
    }
}
