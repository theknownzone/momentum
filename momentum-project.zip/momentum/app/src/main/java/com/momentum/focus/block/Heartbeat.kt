package com.momentum.focus.block

import android.content.Context

/**
 * A kill by MIUI, ColorOS or Funtouch is silent. The process is torn down
 * without onDestroy(), so no code of ours runs at the moment it happens and
 * there is nothing to catch in the act.
 *
 * The only honest signal is a gap. While the service is alive it stamps the
 * clock every few seconds; if the app later opens and finds the shield was
 * supposed to be on but the last stamp is minutes old, the service was killed
 * and the user was unprotected for that whole window.
 *
 * This is deliberately not DataStore. The write happens inside the 350ms poll
 * loop and must not allocate a coroutine or touch a flow on every beat.
 */
object Heartbeat {

    private const val FILE = "momentum_heartbeat"
    private const val KEY_BEAT = "last_beat"
    private const val KEY_ARMED = "armed"
    private const val KEY_REPORTED = "reported_gap"

    /** A gap wider than this cannot be normal scheduling jitter. */
    private const val DEAD_AFTER_MS = 3 * 60 * 1000L

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** Called from the poll loop. Cheap, synchronous, no coroutine. */
    fun beat(context: Context) {
        prefs(context).edit()
            .putLong(KEY_BEAT, System.currentTimeMillis())
            .putBoolean(KEY_ARMED, true)
            .apply()
    }

    /** Called when the user turns the shield off on purpose. Gaps after this are expected. */
    fun disarm(context: Context) {
        prefs(context).edit()
            .putBoolean(KEY_ARMED, false)
            .remove(KEY_REPORTED)
            .apply()
    }

    /**
     * Minutes the shield was down without the user asking for it, or 0 when
     * nothing went wrong. Only meaningful while the shield is meant to be on.
     */
    fun deadMinutes(context: Context): Int {
        val p = prefs(context)
        if (!p.getBoolean(KEY_ARMED, false)) return 0
        val last = p.getLong(KEY_BEAT, 0L)
        if (last <= 0L) return 0
        val gap = System.currentTimeMillis() - last
        // A clock moved backwards produces a negative gap, which is not a kill.
        if (gap < DEAD_AFTER_MS) return 0
        return (gap / 60000L).toInt().coerceAtLeast(1)
    }

    /** True once per outage, so the warning is not shown again for the same gap. */
    fun shouldWarn(context: Context): Boolean {
        val minutes = deadMinutes(context)
        if (minutes == 0) return false
        val p = prefs(context)
        val last = p.getLong(KEY_BEAT, 0L)
        if (p.getLong(KEY_REPORTED, 0L) == last) return false
        p.edit().putLong(KEY_REPORTED, last).apply()
        return true
    }
}
