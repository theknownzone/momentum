package com.momentum.focus.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Build

/**
 * What an installed app is for.
 *
 * Worth being blunt about how much Android actually helps here, because the
 * gap decides the design:
 *
 * `ApplicationInfo.category` exists from API 26 and is genuinely useful for
 * GAME, SOCIAL, VIDEO, AUDIO and NEWS. Two catches. It is set by the app's own
 * developer via `android:appCategory`, and most never bother, so the honest
 * answer for a large share of any phone is UNDEFINED. And there is no
 * education constant at all — Android has never had one, and the Play Store
 * category is not exposed to other apps in any form.
 *
 * So study cannot be detected, only recognised from a list. That is also what
 * every blocker on the store does, including the one being copied. Everything
 * else falls back to the system category, and only then to unknown.
 */
enum class AppKind(val label: String) {
    STUDY("Study"),
    SOCIAL("Social"),
    VIDEO("Video"),
    GAME("Games"),
    MUSIC("Music"),
    NEWS("News"),
    BROWSER("Browser"),
    MESSAGING("Messaging"),
    SHOPPING("Shopping"),
    TOOL("Tools"),
    OTHER("Other"),
}

data class CataloguedApp(
    val pkg: String,
    val label: String,
    val kind: AppKind,
    val minutes: Int,
) {
    /** The kinds that cost people their evening. Used to preselect a blocklist. */
    val isDistraction: Boolean
        get() = kind == AppKind.SOCIAL || kind == AppKind.VIDEO ||
            kind == AppKind.GAME || kind == AppKind.NEWS
}

object AppCatalog {

    // Prefix rules come first because they are certain, and because the system
    // category is wrong or missing on exactly these apps often enough to
    // matter — several browsers report PRODUCTIVITY, WhatsApp reports nothing.
    private val RULES: List<Pair<AppKind, List<String>>> = listOf(
        AppKind.SOCIAL to listOf(
            "com.instagram", "com.facebook", "com.snapchat", "com.twitter",
            "com.x.", "com.reddit", "in.mohalla.sharechat", "com.linkedin",
            "com.pinterest", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        ),
        AppKind.VIDEO to listOf(
            "com.google.android.youtube", "com.netflix", "com.hotstar",
            "in.startv.hotstar", "com.amazon.avod", "com.mxtech",
            "com.jio.jiogames", "tv.twitch",
        ),
        AppKind.MESSAGING to listOf(
            "com.whatsapp", "org.telegram", "com.discord", "com.snap.messaging",
            "com.google.android.apps.messaging", "com.microsoft.teams",
        ),
        AppKind.BROWSER to listOf(
            "com.android.chrome", "com.brave.browser", "com.opera",
            "org.mozilla", "com.microsoft.emmx", "com.duckduckgo",
        ),
        AppKind.MUSIC to listOf(
            "com.spotify", "com.gaana", "com.jio.media.jiobeats",
            "com.google.android.apps.youtube.music", "com.soundcloud",
        ),
        AppKind.SHOPPING to listOf(
            "com.flipkart", "in.amazon.mShop", "com.amazon.mShop",
            "com.myntra", "com.meesho", "com.grofers", "com.application.zomato",
            "in.swiggy",
        ),
        AppKind.NEWS to listOf(
            "com.inshorts", "com.dailyhunt", "com.ndtv", "com.google.android.apps.magazines",
        ),
    )

    fun classify(pkg: String, info: ApplicationInfo?): AppKind {
        // A study app the user has told us about wins over everything, so a
        // lecture app that also declares itself VIDEO is not filed as video.
        if (StudyApps.looksLikeStudy(pkg)) return AppKind.STUDY

        RULES.forEach { (kind, prefixes) ->
            if (prefixes.any { pkg.startsWith(it, ignoreCase = true) }) return kind
        }

        if (info != null && Build.VERSION.SDK_INT >= 26) {
            when (info.category) {
                ApplicationInfo.CATEGORY_GAME -> return AppKind.GAME
                ApplicationInfo.CATEGORY_SOCIAL -> return AppKind.SOCIAL
                ApplicationInfo.CATEGORY_VIDEO -> return AppKind.VIDEO
                ApplicationInfo.CATEGORY_AUDIO -> return AppKind.MUSIC
                ApplicationInfo.CATEGORY_NEWS -> return AppKind.NEWS
                ApplicationInfo.CATEGORY_PRODUCTIVITY -> return AppKind.TOOL
                ApplicationInfo.CATEGORY_MAPS -> return AppKind.TOOL
                else -> Unit
            }
        }
        return AppKind.OTHER
    }

    /**
     * Every launchable app on the phone, classified, with this week's minutes.
     * Blocking is meaningless for apps with no launcher icon, and listing them
     * buries the handful anyone actually cares about.
     */
    fun scan(context: Context): List<CataloguedApp> {
        val pm = context.packageManager
        val usage = runCatching {
            ScreenTime.report(context).topApps.associate { it.pkg to it.minutes }
        }.getOrDefault(emptyMap())

        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .mapNotNull { it.activityInfo?.applicationInfo }
            .filter { it.packageName != context.packageName }
            .distinctBy { it.packageName }
            .map { info ->
                CataloguedApp(
                    pkg = info.packageName,
                    label = runCatching { pm.getApplicationLabel(info).toString() }
                        .getOrDefault(info.packageName),
                    kind = classify(info.packageName, info),
                    minutes = usage[info.packageName] ?: 0,
                )
            }
            .sortedWith(
                compareByDescending<CataloguedApp> { it.minutes }
                    .thenBy { it.label.lowercase() }
            )
    }

    /** Study apps actually present on this phone. Empty is a real answer. */
    fun installedStudyApps(context: Context): List<CataloguedApp> =
        scan(context).filter { it.kind == AppKind.STUDY }
}
