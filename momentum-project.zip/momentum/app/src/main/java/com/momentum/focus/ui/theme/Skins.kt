package com.momentum.focus.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Skins are earned, never bought or given.
 *
 * A cosmetic that unlocks at a level is the cheapest honest reward there is:
 * it costs nothing to run, it is visible every single time the app opens, and
 * it cannot be faked. Handing them all out at install would remove the only
 * thing that makes them worth anything.
 */
enum class Skin(
    val label: String,
    val unlockLevel: Int,
    val petal: Color,
    val heroTop: Color,
    val heroBottom: Color,
    val accent: Color,
    val blurb: String,
) {
    SAKURA(
        label = "Sakura",
        unlockLevel = 1,
        petal = Color(0xFFFFB7C5),
        heroTop = Color(0xFF1A1A1A),
        heroBottom = Color(0xFF241A1E),
        accent = Color(0xFF3FE28F),
        blurb = "Where everyone starts.",
    ),
    MONSOON(
        label = "Monsoon",
        unlockLevel = 3,
        petal = Color(0xFF9FD8FF),
        heroTop = Color(0xFF10171F),
        heroBottom = Color(0xFF0B1119),
        accent = Color(0xFF7FD4FF),
        blurb = "Rain on the window, nothing else to do.",
    ),
    EMBER(
        label = "Ember",
        unlockLevel = 6,
        petal = Color(0xFFFFA24B),
        heroTop = Color(0xFF1F1310),
        heroBottom = Color(0xFF140B09),
        accent = Color(0xFFFF8A5C),
        blurb = "For the last hour before an exam.",
    ),
    MIDNIGHT(
        label = "Midnight",
        unlockLevel = 10,
        petal = Color(0xFFB9A7FF),
        heroTop = Color(0xFF14121F),
        heroBottom = Color(0xFF0A0912),
        accent = Color(0xFFB9A7FF),
        blurb = "Earned by people who study after everyone sleeps.",
    ),
    GOLD(
        label = "Gold",
        unlockLevel = 15,
        petal = Color(0xFFFFD84D),
        heroTop = Color(0xFF1E1808),
        heroBottom = Color(0xFF120E04),
        accent = Color(0xFFFFD84D),
        blurb = "Rare on purpose.",
    ),
    RAKHI(
        label = "Rakhi",
        unlockLevel = 1,
        petal = Color(0xFFFF8FB1),
        heroTop = Color(0xFF2A1218),
        heroBottom = Color(0xFF1A0B10),
        accent = Color(0xFFFF5D8F),
        blurb = "Seasonal. Thread and promise.",
    ),
    DIWALI(
        label = "Diwali",
        unlockLevel = 1,
        petal = Color(0xFFFFD84D),
        heroTop = Color(0xFF2A1A08),
        heroBottom = Color(0xFF140C04),
        accent = Color(0xFFFFB703),
        blurb = "Seasonal. Light the house, then sit down.",
    ),
    HOLI(
        label = "Holi",
        unlockLevel = 1,
        petal = Color(0xFFFF9EC4),
        heroTop = Color(0xFF1A1020),
        heroBottom = Color(0xFF0E0814),
        accent = Color(0xFFFF6B9D),
        blurb = "Seasonal. Colour first, phone later.",
    ),
    TIRANGA(
        label = "Tiranga",
        unlockLevel = 1,
        petal = Color(0xFFFF9933),
        heroTop = Color(0xFF0B1F14),
        heroBottom = Color(0xFF07140D),
        accent = Color(0xFF138808),
        blurb = "Seasonal. 15 Aug and 26 Jan.",
    );

    fun unlockedAt(level: Int): Boolean = level >= unlockLevel
}

fun skinFor(index: Int): Skin = Skin.entries[Math.floorMod(index, Skin.entries.size)]
