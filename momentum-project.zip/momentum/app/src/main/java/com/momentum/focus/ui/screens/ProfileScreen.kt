package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.achievements
import com.momentum.focus.data.AppData
import com.momentum.focus.data.ExamCatalog
import com.momentum.focus.data.ExamEntry
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.ui.components.FeedDebugDialog
import com.momentum.focus.ui.components.GlassSection
import com.momentum.focus.ui.components.Locked
import com.momentum.focus.ui.components.PactBanner
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.AVATAR_COUNT
import com.momentum.focus.ui.components.Avatar3D
import com.momentum.focus.ui.components.StickerCard
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.theme.*
import com.momentum.focus.block.Admin
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.ShareCard
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.rememberHaptics

@Composable
fun ProfileScreen(
    data: AppData,
    onCrown: (Boolean) -> Unit,
    onExam: (String, Long) -> Unit,
    onWeekend: (Boolean) -> Unit,
    onRatio: (Int) -> Unit,
    onAvatar: (Int, Int) -> Unit,
    onSkin: (Int) -> Unit,
    onName: (String) -> Unit,
    onGoal: (Int) -> Unit,
    onPermissions: () -> Unit,
    onPlans: () -> Unit,
    onChangelog: () -> Unit,
    onSupport: () -> Unit,
    onBlockList: () -> Unit,
    onShield: (Boolean) -> Unit,
    onSubjects: (List<String>) -> Unit = {},
    onClassHours: (Boolean, Int, Int) -> Unit = { _, _, _ -> },
    onClassDay: (Int) -> Unit = {},
) {
    val haptics = rememberHaptics()
    val context = LocalContext.current
    var name by remember(data.userName) { mutableStateOf(data.userName) }
    var sound by remember { mutableStateOf(Sfx.enabled) }
    var feedDebug by remember { mutableStateOf(false) }
    // The glass takes its tint from the skin, so choosing one changes the very
    // screen you chose it on instead of a single card two screens away.
    val skinNow = LocalSkin.current

    // Device admin is granted on a system screen, so the only honest way to
    // know whether it stuck is to re-read it every time this screen resumes.
    val owner = LocalLifecycleOwner.current
    var adminRefresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) adminRefresh++
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    val adminOn = remember(adminRefresh) { Admin.isActive(context) }
    // The switch used to flip the moment it was touched and only then ask for
    // admin. Cancel the system dialog, or have it fail to open at all, and the
    // app claimed the app could not be uninstalled while nothing was stopping
    // it. Crown mode is now whatever the system actually granted.
    LaunchedEffect(adminOn) {
        if (!adminOn && data.crownMode && !data.pactLive) onCrown(false)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        PlayerCard(data)

        Spacer(Modifier.height(18.dp))

        PactBanner(data.lockUntilEpochMs, Modifier.fillMaxWidth())

        Spacer(Modifier.height(Paper.Gap))

        // Was buried inside the App section, which is collapsed by default —
        // reaching it meant scrolling to the bottom of a very long screen and
        // opening a drawer first. Nobody was ever going to find it there.
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(if (data.premium) Butter.fill else CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .clickableNoRipple(remember { MutableInteractionSource() }) {
                    haptics.tap(); onPlans()
                }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (data.premium) "LIFETIME" else "PLANS",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (data.premium) Butter.on.copy(alpha = 0.7f) else InkMid,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    if (data.premium) "Unlocked. Thank you." else "Blocking stays free",
                    style = MaterialTheme.typography.titleMedium,
                    color = if (data.premium) Butter.on else Ink,
                )
            }
            Text(
                "\u203A",
                style = MaterialTheme.typography.headlineSmall,
                color = if (data.premium) Butter.on else InkMid,
            )
        }

        Spacer(Modifier.height(10.dp))

        // One card, four columns — the shape the reference uses, and the reason
        // it works: an icon row scans in a glance where stacked text rows have
        // to be read. These four used to be rows inside a section that stays
        // collapsed, which is how Plans stayed invisible for a whole release.
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            val permsOk = Perms.allRequiredGranted(context)
            ActionTile(
                Icons.Filled.Shield,
                "Block",
                "${data.blockedPackages.size + data.blockedSurfaces.size}",
                Mint,
                Modifier.weight(1f),
            ) { haptics.tap(); onBlockList() }
            ActionTile(
                Icons.Filled.VerifiedUser,
                "Perms",
                if (permsOk) "OK" else "Fix",
                if (permsOk) Sky else Tang,
                Modifier.weight(1f),
            ) { haptics.tap(); onPermissions() }
            ActionTile(
                Icons.Filled.ChatBubble,
                "Help",
                "Likho",
                Lilac,
                Modifier.weight(1f),
            ) { haptics.tap(); onSupport() }
            ActionTile(
                Icons.Filled.BugReport,
                "Feed IDs",
                "Debug",
                Butter,
                Modifier.weight(1f),
            ) { haptics.tap(); feedDebug = true }
        }


        GlassSection("Tum", "Naam, avatar, theme", tint = skinNow.petal, initiallyOpen = true) {

            // ---- avatar ----
            Text(
                "AVATAR",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(6) { i ->
                    val sticker = stickerFor(i)
                    val on = data.avatarColor == i
                    Box(
                        Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clip(CircleShape)
                            .background(sticker.fill)
                            .border(if (on) Paper.Outline else 1.dp, Ink, CircleShape)
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick(); onAvatar(data.avatarShape, i)
                            }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // One row of six, matching the colour row above it. It used to
                // split five and one, and with the shape list trimmed that
                // left a single avatar stretched across the full width.
                repeat(AVATAR_COUNT) { shape ->
                    val on = data.avatarShape == shape
                    Box(
                        Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (on) Sunk else CreamCard)
                            .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(12.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick(); onAvatar(shape, data.avatarColor)
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Avatar3D(
                            colorIndex = data.avatarColor,
                            shapeIndex = shape,
                            size = 40.dp,
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            // ---- themes ----
            Text("THEMES", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "Unlocked by levelling up",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(10.dp))
            Skin.entries.filter { it.ordinal < Skin.RAKHI.ordinal }.forEach { skin ->
                val i = skin.ordinal
                val open = skin.unlockedAt(data.level)
                val on = data.skin == i
                // Frosted rather than merely labelled: a locked theme that
                // looks identical to an unlocked one except for a word at the
                // end reads as available, and people tap it and get nothing.
                Locked(
                    locked = !open,
                    label = "LEVEL ${skin.unlockLevel}",
                    modifier = Modifier.fillMaxWidth(),
                ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Sunk else CreamCard)
                        .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            if (open) { haptics.confirm(); onSkin(i) } else haptics.reject()
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (open) skin.petal else Sunk)
                            .border(2.dp, Ink, RoundedCornerShape(10.dp))
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            skin.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (open) Ink else InkLow,
                        )
                        Text(
                            when {
                                !open -> "Unlocks at level ${skin.unlockLevel}"
                                skin.unlockLevel == 1 && skin.ordinal >= Skin.RAKHI.ordinal ->
                                    "Seasonal · ${skin.blurb}"
                                else -> skin.blurb
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMid,
                        )
                    }
                    if (on) {
                        Text("IN USE", style = MaterialTheme.typography.labelSmall, color = Mint.accent)
                    }
                }
                }
            }

            Spacer(Modifier.height(20.dp))

            // ---- lifetime numbers ----
            StickerCard(sticker = Emerald, modifier = Modifier.fillMaxWidth()) {
                Text("LIFETIME", style = MaterialTheme.typography.labelSmall, color = Mint.on.copy(alpha = 0.75f))
                Spacer(Modifier.height(12.dp))
                // Every line uses the card's own dark-on-hue colour. Giving each
                // row its own accent looked like confetti and was unreadable.
                StatLine("Focused", "${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m")
                StatLine("Spent on distraction", "${data.spentMinutes}m")
                StatLine("Sessions finished", "${data.sessions.count { it.completed }}")
                StatLine("Urges beaten", "${data.urgesSurvived}")
                StatLine("Best streak", "${maxOf(data.bestStreak, data.streakDays)} days")
            }

            Spacer(Modifier.height(Paper.Gap))

            // ---- editable name ----
            Text(
                "NAME",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(18); onName(it.trim()) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            )

        }

        GlassSection("Target", "Kitna padhna hai aur kis liye", tint = skinNow.accent, initiallyOpen = true) {

            // ---- streak goal ----
            Text(
                "STREAK GOAL",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 60, 90, 180).forEach { days ->
                    val on = data.streakGoal == days
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (on) Butter.fill
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick(); onGoal(days)
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            "$days",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (on) Butter.on
                                    else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // ---- exam ----
            Text("EXAM", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            var examName by remember(data.examName) { mutableStateOf(data.examName) }
            var catalog by remember { mutableStateOf(ExamCatalog.bundled(context)) }
            LaunchedEffect(Unit) {
                catalog = ExamCatalog.refresh(context)
            }
            OutlinedTextField(
                value = examName,
                onValueChange = { examName = it.take(32) },
                placeholder = { Text("Search JEE, NEET, SSC…") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )
            val hits = remember(examName, catalog) { ExamCatalog.search(catalog, examName) }
            if (hits.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                hits.forEach { exam: ExamEntry ->
                    val selected = examName.equals(exam.name, ignoreCase = true)
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (selected) Tang.fill
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .border(2.dp, Ink, RoundedCornerShape(12.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick()
                                examName = exam.name
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                    ) {
                        Text(
                            "${exam.name}  ·  ${exam.region}",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (selected) Tang.on
                            else MaterialTheme.colorScheme.onBackground,
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 60, 90, 180).forEach { days ->
                    val target = java.time.LocalDate.now().plusDays(days.toLong()).toEpochDay()
                    val on = data.examEpochDay == target
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (on) Tang.fill else MaterialTheme.colorScheme.surfaceVariant)
                            .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick(); onExam(examName, target)
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            "${days}d",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (on) Tang.on else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            data.daysToExam?.let {
                if (it >= 0) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "$it days left · Crown switches on inside ${data.examCrownDays} days",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Text("3 SUBJECTS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "Exam pack start. Apna naam likh — PCM forced nahi.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            var sub0 by remember(data.subjects) { mutableStateOf(data.subjects.getOrElse(0) { "" }) }
            var sub1 by remember(data.subjects) { mutableStateOf(data.subjects.getOrElse(1) { "" }) }
            var sub2 by remember(data.subjects) { mutableStateOf(data.subjects.getOrElse(2) { "" }) }
            listOf(0 to sub0, 1 to sub1, 2 to sub2).forEach { (i, _) ->
                val value = when (i) { 0 -> sub0; 1 -> sub1; else -> sub2 }
                OutlinedTextField(
                    value = value,
                    onValueChange = {
                        val v = it.take(18)
                        when (i) { 0 -> sub0 = v; 1 -> sub1 = v; else -> sub2 = v }
                        onSubjects(listOf(sub0, sub1, sub2).map { s -> s.ifBlank { "Paper ${it}" } }.let { cur ->
                            listOf(if (i==0) v else sub0, if (i==1) v else sub1, if (i==2) v else sub2)
                        })
                    },
                    singleLine = true,
                    placeholder = { Text("Subject ${i + 1}") },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                )
            }

        }

        GlassSection("Rules", "Kab shield lage aur ₹ kaise mile", tint = skinNow.petal) {

            // ---- earn ratio ----
            Text(
                "EARN RATE",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "${data.earnRatio} min of study buys 1 min of scrolling",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(4, 6, 8, 12).forEach { r ->
                    val on = data.earnRatio == r
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (on) Mint.fill else MaterialTheme.colorScheme.surfaceVariant)
                            .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick(); onRatio(r)
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            "${r}:1",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (on) Mint.on else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // ---- crown mode ----
            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Crown mode",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        if (adminOn && data.crownMode)
                            "On. Uninstall ke liye pehle Settings se device admin " +
                                "band karna padega."
                        else
                            "Device admin maangega. Uske bina ye on nahi hoga.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = data.crownMode && adminOn,
                    onCheckedChange = { on ->
                        haptics.tick()
                        if (on) {
                            if (adminOn) {
                                onCrown(true)
                            } else {
                                // Not flipped here on purpose. The resume check
                                // above turns it on only if admin was granted.
                                runCatching {
                                    context.startActivity(Admin.requestIntent(context))
                                }
                            }
                        } else if (!data.pactLive) {
                            onCrown(false)
                            if (adminOn) Admin.deactivate(context)
                        }
                    },
                )
            }

            // ---- weekend ----
            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Easier weekends",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        "Halves the earn rate on Sat and Sun",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = data.weekendRelaxed,
                    onCheckedChange = { onWeekend(it); haptics.tick() },
                )
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Class hours",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        "${data.classStartHour}:00–${data.classEndHour}:00 · L2+ pe Shield khud ON",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (data.classHoursOn) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("M", "T", "W", "T", "F", "S", "S")
                                .forEachIndexed { i, letter ->
                                    val day = i + 1
                                    val on = day in data.classDays
                                    Box(
                                        Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(if (on) Sky.fill else CreamCard)
                                            .border(2.dp, Ink, CircleShape)
                                            .clickableNoRipple(
                                                remember { MutableInteractionSource() }
                                            ) { haptics.tick(); onClassDay(day) },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Text(
                                            letter,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (on) Sky.on else InkMid,
                                        )
                                    }
                                }
                        }
                    }
                }
                Switch(
                    checked = data.classHoursOn,
                    onCheckedChange = {
                        onClassHours(it, data.classStartHour, data.classEndHour)
                        haptics.tick()
                    },
                )
            }

            // Profiles and the app list used to sit here, one row below avatars
            // and exam dates. They are blocking controls, not identity, and they
            // now live together in the Block hub — one row that goes there beats
            // three unrelated ones scattered down this column.
        }

        GlassSection("App", "Blocking aur permissions", tint = skinNow.accent) {

            // ---- toggles ----
            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Sound effects",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        "Silent mode always wins",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = sound,
                    onCheckedChange = { sound = it; Sfx.enabled = it; haptics.tick() },
                )
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Shield",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        "Blocks your chosen apps in the background",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = data.shieldOn,
                    onCheckedChange = { onShield(it); haptics.tick() },
                )
            }

        }

        Spacer(Modifier.height(40.dp))

        // The full stop at the bottom of the scroll: oversized, low contrast,
        // with the version underneath. Reaching it should feel like the end of
        // something made rather than a list running out.
        Column(
            Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "momentum",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontFamily = FontFamily.Serif,
                ),
                color = InkLow.copy(alpha = 0.45f),
            )
            Text(
                "v${Updater.currentVersion(context)}",
                style = MaterialTheme.typography.bodyLarge,
                color = InkLow.copy(alpha = 0.55f),
                modifier = Modifier
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.tap(); onChangelog()
                    }
                    .padding(6.dp),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Earned, not claimed.",
                style = MaterialTheme.typography.bodyMedium,
                color = InkLow.copy(alpha = 0.45f),
            )
        }
        Spacer(Modifier.height(24.dp))
    }

    if (feedDebug) FeedDebugDialog { feedDebug = false }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyLarge,
            color = Mint.on.copy(alpha = 0.72f),
            modifier = Modifier.weight(1f),
        )
        Text(value, style = MaterialTheme.typography.titleMedium, color = Mint.on)
    }
}



/** Rank names by level. Numbers alone are a scoreboard; names are an identity. */
private fun rankFor(level: Int): String = when {
    level >= 20 -> "Untouchable"
    level >= 15 -> "Locked in"
    level >= 10 -> "Relentless"
    level >= 6 -> "Consistent"
    level >= 3 -> "Warming up"
    else -> "Rookie"
}

/**
 * The player card. Level ring, rank, XP to next level, and the badges already
 * earned — the things a game shows first, because progress you can see is the
 * only kind that pulls anyone back tomorrow.
 */
@Composable
private fun PlayerCard(data: AppData) {
    val sticker = stickerFor(data.avatarColor)
    // Premium's only visible reward inside the app itself. Everything else the
    // unlock buys is capacity — more profiles, longer history — which is felt
    // rather than seen, so the card someone looks at every day gets the halo.
    val glow = data.premium
    val progress by animateFloatAsState(
        data.xpIntoLevel / 600f, Motion.settle(), label = "xp"
    )
    val unlocked = data.achievements().filter { it.unlocked }

    Aura(
        color = if (glow) sticker.fill else Color.Transparent,
        strength = if (glow) 0.38f else 0f,
        modifier = Modifier.fillMaxWidth(),
    ) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(Ink)
            .border(
                if (glow) Paper.Outline else 0.dp,
                if (glow) sticker.fill else Color.Transparent,
                RoundedCornerShape(Paper.CardRadius),
            )
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(76.dp)) {
                    val stroke = 7.dp.toPx()
                    val arc = Size(size.width - stroke, size.height - stroke)
                    val tl = Offset(stroke / 2, stroke / 2)
                    drawArc(
                        InkLow.copy(alpha = 0.3f), -90f, 360f, false, tl, arc,
                        style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                    drawArc(
                        sticker.fill, -90f, 360f * progress, false, tl, arc,
                        style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                }
                Avatar3D(
                    colorIndex = data.avatarColor,
                    shapeIndex = data.avatarShape,
                    size = 48.dp,
                )
            }

            Spacer(Modifier.width(16.dp))

            Column(Modifier.weight(1f)) {
                Text(
                    "LEVEL ${data.level} · ${rankFor(data.level).uppercase()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = sticker.fill,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    data.userName,
                    style = MaterialTheme.typography.headlineSmall,
                    color = CreamCard,
                )
                Text(
                    "${600 - data.xpIntoLevel} xp to level ${data.level + 1}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkLow,
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("${data.streakDays}d streak", Butter)
            Chip("${data.earnedMinutes / 60}h focused", Mint)
            Chip("${unlocked.size} badges", Lilac)
        }

        // The chips are three totals with no sense of direction — "14h focused"
        // reads the same whether this week was the best one yet or the first in
        // a fortnight. Seven bars answer that without adding a number to read.
        val today = remember { java.time.LocalDate.now().toEpochDay() }
        val week = remember(data.sessions, today) {
            val b = IntArray(7)
            data.sessions.filter { it.completed }.forEach { s ->
                val ago = (today - s.startedAtEpochDay).toInt()
                if (ago in 0..6) b[6 - ago] += s.minutes
            }
            b.toList()
        }
        if (week.any { it > 0 }) {
            Spacer(Modifier.height(14.dp))
            val peak = week.max().coerceAtLeast(1)
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(38.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                week.forEachIndexed { i, m ->
                    // An empty day still gets a sliver, so the row reads as
                    // seven days rather than as however many were studied.
                    val frac = (m.toFloat() / peak).coerceAtLeast(0.08f)
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight(frac)
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                if (i == 6) sticker.fill
                                else CreamCard.copy(alpha = if (m > 0) 0.55f else 0.18f)
                            )
                    )
                }
            }
        }

        if (unlocked.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                unlocked.take(6).forEachIndexed { i, _ ->
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(stickerFor(i).fill)
                    )
                }
            }
        }
    }
    }
}

@Composable
private fun Chip(text: String, sticker: Sticker) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(sticker.fill.copy(alpha = 0.18f))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text, style = MaterialTheme.typography.bodyMedium, color = sticker.fill)
    }
}

/**
 * One column in the Profile action row.
 *
 * The badge under the icon carries live state — how many things are blocked,
 * whether permissions still need fixing — so the row answers "is anything
 * wrong" without opening anything. A Fix badge turns the tile orange, which is
 * the only reason it is coloured at all.
 */
@Composable
private fun ActionTile(
    icon: ImageVector,
    title: String,
    badge: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Column(
        modifier
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(sticker.fill)
                .border(Paper.Outline, Ink, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = sticker.on,
                modifier = Modifier.size(22.dp),
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(title, style = MaterialTheme.typography.labelSmall, color = Ink)
        Text(badge, style = MaterialTheme.typography.labelSmall, color = InkMid)
    }
}
