package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.StickerCard
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.rememberHaptics

@Composable
fun ProfileScreen(
    data: AppData,
    onName: (String) -> Unit,
    onGoal: (Int) -> Unit,
    onPermissions: () -> Unit,
) {
    val haptics = rememberHaptics()
    val context = LocalContext.current
    var name by remember(data.userName) { mutableStateOf(data.userName) }
    var sound by remember { mutableStateOf(Sfx.enabled) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Lilac.fill)
                    .border(Paper.Outline, Ink, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    data.userName.trim().firstOrNull()?.uppercase() ?: "?",
                    style = MaterialTheme.typography.displayMedium,
                    color = Lilac.on,
                )
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    "PROFILE",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    data.userName,
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
        }

        Spacer(Modifier.height(22.dp))

        // ---- lifetime numbers ----
        StickerCard(sticker = Emerald, modifier = Modifier.fillMaxWidth()) {
            Text("LIFETIME", style = MaterialTheme.typography.labelSmall, color = Mint.on.copy(alpha = 0.75f))
            Spacer(Modifier.height(12.dp))
            // Every line uses the card's own dark-on-hue colour. Giving each
            // row its own accent looked like confetti and was unreadable.
            StatLine("Focused", "${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m")
            StatLine("Spent on distraction", "${data.spentMinutes}m")
            StatLine("Sessions finished", "${data.sessions.count { it.completed }}")
            StatLine("Urges beaten", "${data.urgesSurvived}")
            StatLine("Best streak", "${maxOf(data.bestStreak, data.streakDays)} days")
        }

        Spacer(Modifier.height(Paper.Gap))

        // ---- editable name ----
        Text(
            "NAME",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(18); onName(it.trim()) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(20.dp))

        // ---- streak goal ----
        Text(
            "STREAK GOAL",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(30, 60, 90, 180).forEach { days ->
                val on = data.streakGoal == days
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (on) Butter.fill
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onGoal(days)
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "$days",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (on) Butter.on
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // ---- toggles ----
        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Sound effects",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    "Silent mode always wins",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = sound,
                onCheckedChange = { sound = it; Sfx.enabled = it; haptics.tick() },
            )
        }

        SettingRow(
            title = "Permissions",
            value = if (Perms.allRequiredGranted(context)) "All granted" else "Needs setup",
            onClick = { haptics.tap(); onPermissions() },
        )

        SettingRow(
            title = "Version",
            value = Updater.currentVersion(context),
            onClick = null,
        )
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyLarge,
            color = Mint.on.copy(alpha = 0.72f),
            modifier = Modifier.weight(1f),
        )
        Text(value, style = MaterialTheme.typography.titleMedium, color = Mint.on)
    }
}

@Composable
private fun SettingRow(title: String, value: String, onClick: (() -> Unit)?) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .then(
                if (onClick != null)
                    Modifier.clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
                else Modifier
            )
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.weight(1f),
        )
        Text(
            value,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
