package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.achievements
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.Avatar3D
import com.momentum.focus.ui.components.StickerCard
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.theme.*
import com.momentum.focus.block.Admin
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.ShareCard
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.rememberHaptics

@Composable
fun ProfileScreen(
    data: AppData,
    onCrown: (Boolean) -> Unit,
    onExam: (String, Long) -> Unit,
    onWeekend: (Boolean) -> Unit,
    onRatio: (Int) -> Unit,
    onAvatar: (Int, Int) -> Unit,
    onName: (String) -> Unit,
    onGoal: (Int) -> Unit,
    onPermissions: () -> Unit,
    onBlockList: () -> Unit,
    onShield: (Boolean) -> Unit,
) {
    val haptics = rememberHaptics()
    val context = LocalContext.current
    var name by remember(data.userName) { mutableStateOf(data.userName) }
    var sound by remember { mutableStateOf(Sfx.enabled) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        PlayerCard(data)

        Spacer(Modifier.height(18.dp))

        // ---- avatar ----
        Text(
            "AVATAR",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(6) { i ->
                val sticker = stickerFor(i)
                val on = data.avatarColor == i
                Box(
                    Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .clip(CircleShape)
                        .background(sticker.fill)
                        .border(if (on) Paper.Outline else 1.dp, Ink, CircleShape)
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onAvatar(data.avatarShape, i)
                        }
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(6) { shape ->
                val on = data.avatarShape == shape
                Box(
                    Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (on) Sunk else CreamCard)
                        .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(12.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onAvatar(shape, data.avatarColor)
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Avatar3D(
                        colorIndex = data.avatarColor,
                        shapeIndex = shape,
                        size = 40.dp,
                    )
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // ---- lifetime numbers ----
        StickerCard(sticker = Emerald, modifier = Modifier.fillMaxWidth()) {
            Text("LIFETIME", style = MaterialTheme.typography.labelSmall, color = Mint.on.copy(alpha = 0.75f))
            Spacer(Modifier.height(12.dp))
            // Every line uses the card's own dark-on-hue colour. Giving each
            // row its own accent looked like confetti and was unreadable.
            StatLine("Focused", "${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m")
            StatLine("Spent on distraction", "${data.spentMinutes}m")
            StatLine("Sessions finished", "${data.sessions.count { it.completed }}")
            StatLine("Urges beaten", "${data.urgesSurvived}")
            StatLine("Best streak", "${maxOf(data.bestStreak, data.streakDays)} days")
        }

        Spacer(Modifier.height(Paper.Gap))

        // ---- editable name ----
        Text(
            "NAME",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(18); onName(it.trim()) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(20.dp))

        // ---- streak goal ----
        Text(
            "STREAK GOAL",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(30, 60, 90, 180).forEach { days ->
                val on = data.streakGoal == days
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (on) Butter.fill
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onGoal(days)
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "$days",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (on) Butter.on
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // ---- toggles ----
        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Sound effects",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    "Silent mode always wins",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = sound,
                onCheckedChange = { sound = it; Sfx.enabled = it; haptics.tick() },
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Shield",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    "Blocks your chosen apps in the background",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = data.shieldOn,
                onCheckedChange = { onShield(it); haptics.tick() },
            )
        }

        // ---- crown mode ----
        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Crown mode",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    if (Admin.isActive(context))
                        "Hardest mode. No buying in, app cannot be uninstalled."
                    else
                        "Hardest mode. Needs device admin to stop uninstalls.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = data.crownMode,
                onCheckedChange = { on ->
                    haptics.tick()
                    onCrown(on)
                    if (on && !Admin.isActive(context)) {
                        runCatching { context.startActivity(Admin.requestIntent(context)) }
                    } else if (!on && Admin.isActive(context)) {
                        Admin.deactivate(context)
                    }
                },
            )
        }

        Spacer(Modifier.height(14.dp))

        // ---- earn ratio ----
        Text(
            "EARN RATE",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            "${data.earnRatio} min of study buys 1 min of scrolling",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(4, 6, 8, 12).forEach { r ->
                val on = data.earnRatio == r
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Mint.fill else MaterialTheme.colorScheme.surfaceVariant)
                        .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onRatio(r)
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "${r}:1",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (on) Mint.on else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // ---- exam ----
        Text("EXAM", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        var examName by remember(data.examName) { mutableStateOf(data.examName) }
        OutlinedTextField(
            value = examName,
            onValueChange = { examName = it.take(24) },
            placeholder = { Text("Boards, JEE, finals…") },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(30, 60, 90, 180).forEach { days ->
                val target = java.time.LocalDate.now().plusDays(days.toLong()).toEpochDay()
                val on = data.examEpochDay == target
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Tang.fill else MaterialTheme.colorScheme.surfaceVariant)
                        .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onExam(examName, target)
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "${days}d",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (on) Tang.on else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        data.daysToExam?.let {
            if (it >= 0) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "$it days left · Crown switches on inside ${data.examCrownDays} days",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // ---- weekend ----
        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Easier weekends",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    "Halves the earn rate on Sat and Sun",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = data.weekendRelaxed,
                onCheckedChange = { onWeekend(it); haptics.tick() },
            )
        }

        SettingRow(
            title = "Share progress",
            value = "poster",
            onClick = {
                haptics.confirm()
                ShareCard.share(context, data, (data.baselineMinutes - data.minutesToday).coerceAtLeast(0))
            },
        )

        SettingRow(
            title = "Invite a friend",
            value = "send link",
            onClick = {
                haptics.tap()
                runCatching {
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(
                            android.content.Intent.EXTRA_TEXT,
                            "I'm using Momentum to stop wasting my day. " +
                                "github.com/theknownzone/momentum/releases",
                        )
                    }
                    context.startActivity(android.content.Intent.createChooser(intent, "Invite"))
                }
            },
        )

        SettingRow(
            title = "Blocked apps",
            value = "${data.blockedPackages.size} chosen",
            onClick = { haptics.tap(); onBlockList() },
        )

        SettingRow(
            title = "Permissions",
            value = if (Perms.allRequiredGranted(context)) "All granted" else "Needs setup",
            onClick = { haptics.tap(); onPermissions() },
        )

        SettingRow(
            title = "Version",
            value = Updater.currentVersion(context),
            onClick = null,
        )
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyLarge,
            color = Mint.on.copy(alpha = 0.72f),
            modifier = Modifier.weight(1f),
        )
        Text(value, style = MaterialTheme.typography.titleMedium, color = Mint.on)
    }
}

@Composable
private fun SettingRow(title: String, value: String, onClick: (() -> Unit)?) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .then(
                if (onClick != null)
                    Modifier.clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
                else Modifier
            )
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.weight(1f),
        )
        Text(
            value,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}


/** Rank names by level. Numbers alone are a scoreboard; names are an identity. */
private fun rankFor(level: Int): String = when {
    level >= 20 -> "Untouchable"
    level >= 15 -> "Locked in"
    level >= 10 -> "Relentless"
    level >= 6 -> "Consistent"
    level >= 3 -> "Warming up"
    else -> "Rookie"
}

/**
 * The player card. Level ring, rank, XP to next level, and the badges already
 * earned — the things a game shows first, because progress you can see is the
 * only kind that pulls anyone back tomorrow.
 */
@Composable
private fun PlayerCard(data: AppData) {
    val sticker = stickerFor(data.avatarColor)
    val progress by animateFloatAsState(
        data.xpIntoLevel / 600f, Motion.settle(), label = "xp"
    )
    val unlocked = data.achievements().filter { it.unlocked }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(Ink)
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(76.dp)) {
                    val stroke = 7.dp.toPx()
                    val arc = Size(size.width - stroke, size.height - stroke)
                    val tl = Offset(stroke / 2, stroke / 2)
                    drawArc(
                        InkLow.copy(alpha = 0.3f), -90f, 360f, false, tl, arc,
                        style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                    drawArc(
                        sticker.fill, -90f, 360f * progress, false, tl, arc,
                        style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                }
                Avatar3D(
                    colorIndex = data.avatarColor,
                    shapeIndex = data.avatarShape,
                    size = 48.dp,
                )
            }

            Spacer(Modifier.width(16.dp))

            Column(Modifier.weight(1f)) {
                Text(
                    "LEVEL ${data.level} · ${rankFor(data.level).uppercase()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = sticker.fill,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    data.userName,
                    style = MaterialTheme.typography.headlineSmall,
                    color = CreamCard,
                )
                Text(
                    "${600 - data.xpIntoLevel} xp to level ${data.level + 1}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkLow,
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("${data.streakDays}d streak", Butter)
            Chip("${data.earnedMinutes / 60}h focused", Mint)
            Chip("${unlocked.size} badges", Lilac)
        }

        if (unlocked.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                unlocked.take(6).forEachIndexed { i, _ ->
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(stickerFor(i).fill)
                    )
                }
            }
        }
    }
}

@Composable
private fun Chip(text: String, sticker: Sticker) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(sticker.fill.copy(alpha = 0.18f))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text, style = MaterialTheme.typography.bodyMedium, color = sticker.fill)
    }
}
