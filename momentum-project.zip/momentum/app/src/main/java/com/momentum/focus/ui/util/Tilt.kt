package com.momentum.focus.ui.util

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer

/**
 * Reads the accelerometer and reports how the phone is tilted, as x/y in
 * roughly -1..1.
 *
 * Raw sensor values are jittery enough to make a card vibrate, so each sample
 * is low-pass filtered: keep 88% of the old value, take 12% of the new one.
 * The result is the slow, liquid movement that reads as expensive rather than
 * twitchy.
 */
@Composable
fun rememberTilt(): State<Offset> {
    val context = LocalContext.current
    val tilt = remember { mutableStateOf(Offset.Zero) }

    DisposableEffect(Unit) {
        val manager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = manager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        if (manager == null || sensor == null) {
            onDispose { }
        } else {
            val listener = object : SensorEventListener {
                override fun onSensorChanged(event: SensorEvent) {
                    // Gravity is about 9.8 on the axis facing down. Dividing by
                    // 6 gives a comfortable range before clamping.
                    val nx = (-event.values[0] / 6f).coerceIn(-1f, 1f)
                    val ny = (event.values[1] / 6f).coerceIn(-1f, 1f)
                    val old = tilt.value
                    tilt.value = Offset(
                        x = old.x * 0.88f + nx * 0.12f,
                        y = old.y * 0.88f + ny * 0.12f,
                    )
                }

                override fun onAccuracyChanged(s: Sensor?, accuracy: Int) = Unit
            }
            manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
            onDispose { manager.unregisterListener(listener) }
        }
    }
    return tilt
}

/**
 * Rotates a composable in 3D space to match the phone's tilt. cameraDistance
 * has to be raised well above the default or the perspective looks like a
 * fish-eye lens instead of a solid object.
 */
fun Modifier.tilt3d(tilt: Offset, strength: Float = 7f) = this.graphicsLayer {
    rotationX = -tilt.y * strength
    rotationY = tilt.x * strength
    cameraDistance = 16f * density
}
