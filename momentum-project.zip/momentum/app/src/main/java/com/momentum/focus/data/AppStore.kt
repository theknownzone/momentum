package com.momentum.focus.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json

private val Context.dataStore by preferencesDataStore(name = "momentum")
private val KEY = stringPreferencesKey("app_data")

/**
 * The whole app state lives as one JSON blob. For a single-user app with a few
 * thousand rows this is simpler and faster than a database, and it makes
 * backup/export a one-liner. Swap in Room only if you outgrow it.
 */
class AppStore(private val context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    val data: Flow<AppData> = context.dataStore.data
        .catch { emit(androidx.datastore.preferences.core.emptyPreferences()) }
        .map { prefs ->
            prefs[KEY]?.let {
                runCatching { json.decodeFromString<AppData>(it) }.getOrNull()
            } ?: AppData()
        }

    suspend fun update(transform: (AppData) -> AppData) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY]?.let {
                runCatching { json.decodeFromString<AppData>(it) }.getOrNull()
            } ?: AppData()
            prefs[KEY] = json.encodeToString(transform(current))
        }
    }

    /** For the export/backup button in settings. */
    fun serialize(d: AppData): String = json.encodeToString(d)
}
