package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.SolidColor
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

/**
 * Saved rule sets.
 *
 * Deliberately snapshots rather than templates: what gets saved is whatever is
 * switched on at that moment, so there is no separate editor to keep in sync
 * and no way for a profile to describe a state the app cannot actually be in.
 */
@Composable
fun ProfilesScreen(
    data: AppData,
    onSave: (String) -> Unit,
    onApply: (String) -> Unit,
    onDelete: (String) -> Unit,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()
    var name by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 24.dp),
    ) {
        Text("PROFILES", style = MaterialTheme.typography.labelSmall, color = Sky.accent)
        Text(
            "Alag din, alag rules",
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            "Abhi jo bhi on hai — blocked apps, caps, feeds, class hours — sab ek naam " +
                "ke neeche save ho jaata hai. Baad mein ek tap mein wapas.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp),
        )

        Spacer(Modifier.height(18.dp))

        if (data.pactLive) {
            Text(
                "Pact chal raha hai — profile switch nahi kar sakte. Naya save kar sakte ho.",
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.accent,
            )
            Spacer(Modifier.height(12.dp))
        }

        Text("ABHI KA SETUP SAVE KARO", style = MaterialTheme.typography.labelSmall, color = InkMid)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(CreamCard)
                    .border(2.dp, Ink, RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 14.dp),
            ) {
                if (name.isBlank()) {
                    Text(
                        "Raat, Weekend, Exam week…",
                        style = MaterialTheme.typography.bodyLarge,
                        color = InkMid,
                    )
                }
                BasicTextField(
                    value = name,
                    onValueChange = { name = it.take(24) },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = Ink),
                    cursorBrush = SolidColor(Ink),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.width(10.dp))
            SquishButton(label = "Save", sticker = Sky) {
                if (name.isNotBlank()) {
                    haptics.confirm(); onSave(name); name = ""
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        if (data.profiles.isEmpty()) {
            Text(
                "Abhi koi profile nahi. Apps aur feeds set karke yahan naam de do — " +
                    "jaise \"Raat\" jisme WhatsApp bhi band ho.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            data.profiles.forEach { p ->
                val active = p.id == data.activeProfileId
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .clip(RoundedCornerShape(Paper.CardRadius))
                        .background(if (active) Mint.fill else CreamCard)
                        .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                        .padding(16.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                p.name,
                                style = MaterialTheme.typography.headlineSmall,
                                color = if (active) Mint.on else Ink,
                            )
                            Text(
                                "${p.blockedPackages.size} apps · ${p.blockedSurfaces.size} feeds · " +
                                    "${p.dailyCapMinutes.size} caps",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (active) Mint.on.copy(alpha = 0.75f) else InkMid,
                            )
                            Text(
                                if (p.classHoursOn)
                                    "${p.classStartHour}:00–${p.classEndHour}:00 · ${p.classDays.size} din"
                                else "Class hours off",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (active) Mint.on.copy(alpha = 0.75f) else InkMid,
                            )
                        }
                        if (active) {
                            Text(
                                "CHALU",
                                style = MaterialTheme.typography.labelSmall,
                                color = Mint.on,
                            )
                        }
                    }
                    if (!active && !data.pactLive) {
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SquishButton(label = "Lagao", sticker = Emerald) {
                                haptics.confirm(); onApply(p.id)
                            }
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(2.dp, Ink, RoundedCornerShape(14.dp))
                                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                                        haptics.tick(); onDelete(p.id)
                                    }
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                            ) {
                                Text(
                                    "Hatao",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = InkMid,
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        SquishButton(
            label = "Done",
            sticker = Emerald,
            modifier = Modifier.fillMaxWidth(),
        ) { haptics.confirm(); onDone() }
    }
}
