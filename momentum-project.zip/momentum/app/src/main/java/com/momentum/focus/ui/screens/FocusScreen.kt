package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import com.momentum.focus.ui.components.FrostScrim
import com.momentum.focus.ui.components.FrostSheet
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.Currency
import com.momentum.focus.ui.TimerState
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

@Composable
fun FocusScreen(
    data: AppData,
    timer: TimerState,
    onToggle: () -> Unit,
    onAbandon: () -> Unit,
    onDuration: (Int) -> Unit,
    onSubject: (String) -> Unit,
) {
    val haptics = rememberHaptics()
    var confirmStop by remember { mutableStateOf(false) }
    var customOpen by rememberSaveable { mutableStateOf(false) }
    var customMins by rememberSaveable { mutableIntStateOf(40) }
    var why by rememberSaveable { mutableStateOf("") }
    val split = remember(data.sessions, data.subjects) { data.subjectSplit() }
    val minsNow = (timer.totalSeconds / 60).coerceAtLeast(1)
    val earn = (minsNow / data.effectiveRatio.coerceAtLeast(1))
    val presets = listOf(25, 50, 90)
    val isCustom = timer.totalSeconds / 60 !in presets

    // A tick on every whole minute boundary. Frequent enough to feel present,
    // rare enough that it never becomes noise.
    LaunchedEffect(timer.remaining) {
        if (timer.running && timer.remaining > 0 && timer.remaining % 60 == 0) {
            haptics.tick()
        }
    }

    Box(Modifier.fillMaxSize()) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 28.dp, bottom = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "FOCUS",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            buildString {
                append(timer.subject)
                if (why.isNotBlank()) append(" · ").append(why)
            },
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )

        Spacer(Modifier.height(28.dp))

        TimerRing(progress = timer.progress, label = timer.label, running = timer.running)

        Spacer(Modifier.height(28.dp))

        if (!timer.running) {
            Text(
                "$minsNow min → ${Currency.format(earn)} in the wallet",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { mins ->
                    Chip(
                        text = "${mins}m",
                        selected = !isCustom && timer.totalSeconds == mins * 60,
                        sticker = Cobalt,
                    ) {
                        haptics.tick()
                        customOpen = false
                        onDuration(mins)
                    }
                }
                Chip(
                    text = if (isCustom) "${minsNow}m" else "Set",
                    selected = isCustom || customOpen,
                    sticker = Lilac,
                ) {
                    haptics.tick()
                    customOpen = !customOpen
                }
            }
            if (customOpen) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "${customMins} minutes",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Slider(
                    value = customMins.toFloat(),
                    onValueChange = { customMins = it.toInt().coerceIn(15, 180) },
                    valueRange = 15f..180f,
                    steps = 32,
                    colors = SliderDefaults.colors(
                        thumbColor = Lilac.fill,
                        activeTrackColor = Lilac.fill,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
                SquishButton(
                    label = "Use ${customMins}m",
                    sticker = Lilac,
                    modifier = Modifier.fillMaxWidth(0.6f),
                ) {
                    onDuration(customMins)
                    customOpen = false
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                data.subjects.take(3).forEach { s ->
                    Chip(text = s, selected = timer.subject == s, sticker = Marigold) {
                        haptics.tick(); onSubject(s)
                    }
                }
            }
            val subMins = split.firstOrNull { it.first == timer.subject }?.second ?: 0
            val untouched = split.filter { it.second == 0 }.map { it.first }
            Spacer(Modifier.height(8.dp))
            Text(
                if (subMins == 0) "${timer.subject} untouched in 30 days"
                else "${timer.subject} · ${subMins}m in 30 days",
                style = MaterialTheme.typography.bodyMedium,
                color = if (subMins == 0) Tang.accent else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (untouched.isNotEmpty() && timer.subject !in untouched) {
                Text(
                    "Still 0: ${untouched.take(3).joinToString()}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Exam", "Lecture", "Revision").forEach { w ->
                    Chip(text = w, selected = why == w, sticker = Sky) {
                        haptics.tick()
                        why = if (why == w) "" else w
                    }
                }
            }
        }

        Spacer(Modifier.weight(1f))

        SquishButton(
            label = if (timer.running) "Pause" else "Begin",
            sticker = if (timer.running) Marigold else Jade,
            modifier = Modifier.fillMaxWidth(0.7f),
            onClick = onToggle,
        )

        if (timer.remaining < timer.totalSeconds) {
            Spacer(Modifier.height(10.dp))
            Text(
                "Give up — log partial time",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.reject(); confirmStop = true
                    }
                    .padding(10.dp),
            )
        }
    }

    if (confirmStop) {
        FrostScrim {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = Paper.ScreenPad),
                contentAlignment = Alignment.Center,
            ) {
                FrostSheet {
                    Column(
                        Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            "Stop this session?",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Partial time still gets banked.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(16.dp))
                        SquishButton(
                            label = "Stop and bank",
                            sticker = Tang,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            confirmStop = false
                            onAbandon()
                        }
                        Spacer(Modifier.height(10.dp))
                        SquishButton(
                            label = "Keep going",
                            sticker = Mint,
                            modifier = Modifier.fillMaxWidth(),
                        ) { confirmStop = false }
                    }
                }
            }
        }
    }
}
}

@Composable
private fun TimerRing(progress: Float, label: String, running: Boolean) {
    val animated by animateFloatAsState(progress, Motion.settle(), label = "p")
    val track = MaterialTheme.colorScheme.surfaceVariant

    Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 22.dp.toPx()
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(stroke / 2, stroke / 2)
            drawArc(track, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(Ink, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke + 6f, cap = StrokeCap.Round))
            drawArc(track, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(Ink, -90f, 360f * animated, false, topLeft, arcSize,
                style = Stroke(stroke + 6f, cap = StrokeCap.Round))
            drawArc(Sky.fill, -90f, 360f * animated, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                label,
                style = MaterialTheme.typography.displayMedium,
                color = Ink,
            )
            Text(
                if (running) "IN SESSION" else "READY",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun Chip(
    text: String,
    selected: Boolean,
    sticker: Sticker,
    onClick: () -> Unit,
) {
    val bg = if (selected) sticker.fill else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (selected) sticker.on else MaterialTheme.colorScheme.onSurfaceVariant
    Box(
        Modifier
            .clip(RoundedCornerShape(Paper.ChipRadius))
            .background(bg)
            .border(2.dp, Ink, RoundedCornerShape(Paper.ChipRadius))
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        Text(text, style = MaterialTheme.typography.titleMedium, color = fg)
    }
}
