package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import com.momentum.focus.ui.components.FrostScrim
import com.momentum.focus.ui.components.FrostSheet
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.Currency
import com.momentum.focus.ui.TimerState
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import androidx.compose.ui.platform.LocalContext
import com.momentum.focus.data.AppCatalog
import com.momentum.focus.data.CataloguedApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay

@Composable
fun FocusScreen(
    data: AppData,
    timer: TimerState,
    onToggle: () -> Unit,
    onAbandon: () -> Unit,
    onDuration: (Int) -> Unit,
    onSubject: (String) -> Unit,
    onFocusLevel: (Int) -> Unit = {},
    onToggleStudy: (String) -> Unit = {},
    onExtendPact: (Int) -> Unit = {},
) {
    val haptics = rememberHaptics()
    var confirmStop by remember { mutableStateOf(false) }
    var customOpen by rememberSaveable { mutableStateOf(false) }
    var customMins by rememberSaveable { mutableIntStateOf(40) }
    // Defaults to subject mode when a subject is already set, so returning to
    // the screen does not silently drop the label off the next session.
    var justFocus by rememberSaveable { mutableStateOf(false) }
    val split = remember(data.sessions, data.subjects) { data.subjectSplit() }
    val minsNow = (timer.totalSeconds / 60).coerceAtLeast(1)
    val earn = (minsNow / data.effectiveRatio.coerceAtLeast(1))
    val presets = listOf(25, 50, 90)
    val isCustom = timer.totalSeconds / 60 !in presets

    // A tick on every whole minute boundary. Frequent enough to feel present,
    // rare enough that it never becomes noise.
    LaunchedEffect(timer.remaining) {
        if (timer.running && timer.remaining > 0 && timer.remaining % 60 == 0) {
            haptics.tick()
        }
    }

    Box(Modifier.fillMaxSize()) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 28.dp, bottom = 88.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "FOCUS",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            timer.subject,
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1 to "L1", 2 to "L2", 3 to "L3", 4 to "Crown").forEach { (lv, label) ->
                Chip(
                    text = label,
                    selected = data.focusLevel == lv,
                    sticker = if (lv == 4) Tang else Cobalt,
                ) { haptics.tick(); onFocusLevel(lv) }
            }
        }
        Text(
            // The rate here used to be written into the label by hand, so it
            // could disagree with the line right below it and with Profile.
            // One source now: effectiveRatio.
            when (data.focusLevel) {
                1 -> "Soft — block off"
                2 -> "Shield on"
                3 -> "Hard — sab band"
                else -> "Crown — Shield + uninstall lock"
            } + " · ${data.effectiveRatio} min = ₹1",
        )
        // pactLive is derived from the wall clock, so nothing in the store
        // changes when it runs out. Without this tick the countdown froze at
        // whatever it read on the last recomposition and the screen went on
        // claiming to be locked long after the pact had ended.
        var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
        LaunchedEffect(Unit) {
            while (true) {
                delay(1_000)
                nowMs = System.currentTimeMillis()
            }
        }
        val pactLive = data.lockUntilEpochMs > nowMs

        if (pactLive) {
            val leftMs = data.lockUntilEpochMs - nowMs
            val h = leftMs / 3_600_000L
            val m = (leftMs % 3_600_000L) / 60_000L
            Text(
                if (h > 0) "PACT ${h}h ${m}m · level gira nahi sakte"
                else "PACT ${m.coerceAtLeast(1)} min · level gira nahi sakte",
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.accent,
            )
            // Extending is only offered once a pact exists. These used to sit
            // here permanently, so tapping one at Soft armed a lock from
            // nothing that could not then be undone.
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 3, 6).forEach { hrs ->
                    Chip(text = "+${hrs}h lock", selected = false, sticker = Tang) {
                        haptics.tick(); onExtendPact(hrs)
                    }
                }
            }
        }

        Spacer(Modifier.height(28.dp))

        TimerRing(progress = timer.progress, label = timer.label, running = timer.running)

        Spacer(Modifier.height(28.dp))

        if (!timer.running) {
            Text(
                "$minsNow min → ${Currency.format(earn)} in the wallet",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { mins ->
                    Chip(
                        text = "${mins}m",
                        selected = !isCustom && timer.totalSeconds == mins * 60,
                        sticker = Cobalt,
                    ) {
                        haptics.tick()
                        customOpen = false
                        onDuration(mins)
                    }
                }
                Chip(
                    text = if (isCustom) "${minsNow}m" else "Set",
                    selected = isCustom || customOpen,
                    sticker = Lilac,
                ) {
                    haptics.tick()
                    customOpen = !customOpen
                }
            }
            if (customOpen) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "${customMins} minutes",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Slider(
                    value = customMins.toFloat(),
                    onValueChange = {
                        val next = it.toInt().coerceIn(15, 180)
                        if (next != customMins) haptics.tick()
                        customMins = next
                    },
                    onValueChangeFinished = { haptics.confirm() },
                    valueRange = 15f..180f,
                    steps = 32,
                    colors = SliderDefaults.colors(
                        thumbColor = Lilac.fill,
                        activeTrackColor = Lilac.fill,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
                SquishButton(
                    label = "Use ${customMins}m",
                    sticker = Lilac,
                    modifier = Modifier.fillMaxWidth(0.6f),
                ) {
                    haptics.confirm()
                    onDuration(customMins)
                    customOpen = false
                }
            }
            Spacer(Modifier.height(16.dp))

            // Two ways in, asked before anything else, because they want
            // different things from this screen. Someone revising Physics
            // wants the subject on the record so the breakdown means
            // something. Someone who just needs the phone to leave them alone
            // for an hour was previously forced to label it Physics anyway,
            // which quietly poisoned the by-subject stats with sessions that
            // had nothing to do with Physics.
            Text(
                "KAISE PADHNA HAI",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(
                    text = "Subject ke saath",
                    selected = !justFocus,
                    sticker = Marigold,
                ) { haptics.tick(); justFocus = false }
                Chip(
                    text = "Bas focus",
                    selected = justFocus,
                    sticker = Cobalt,
                ) {
                    haptics.tick()
                    justFocus = true
                    // Nothing gets filed under a subject the user did not pick.
                    onSubject("")
                }
            }

            Spacer(Modifier.height(12.dp))
            if (justFocus) {
                Text(
                    "Koi subject nahi. Time chalega, ₹ milega, stats mein " +
                        "\"General\" ke neeche jaayega.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
            } else if (data.examName.isNotBlank()) {
                Text(
                    data.daysToExam?.let { "${data.examName} · ${it}d left" } ?: data.examName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
                Spacer(Modifier.height(8.dp))
            }
            if (!justFocus) {
                if (data.subjects.isEmpty()) {
                    // Nothing named yet. Saying so beats showing three chips
                    // the user never chose.
                    Text(
                        "Abhi koi subject nahi. Profile mein apne subject likh do — " +
                            "ya \"Bas focus\" chuno.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        data.subjects.take(3).forEach { s ->
                            Chip(text = s, selected = timer.subject == s, sticker = Marigold) {
                                haptics.tick(); onSubject(s)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            Text(
                "STUDY APP — ₹ tabhi jab yeh open ho",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            // These used to be the first six entries of a hardcoded list, shown
            // whether or not the phone had them. Tapping one added a package
            // that was not installed, so the timer waited for an app that could
            // never come to the foreground and no rupees were ever paid.
            val context = LocalContext.current
            val studyFound by produceState(initialValue = emptyList<CataloguedApp>()) {
                value = withContext(Dispatchers.IO) {
                    runCatching { AppCatalog.installedStudyApps(context) }.getOrDefault(emptyList())
                }
            }
            if (studyFound.isEmpty()) {
                Text(
                    "Koi study app nahi mili. Focus ke andar se apni app choose karo.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                // Chunked rows rather than FlowRow: that one is still behind
                // ExperimentalLayoutApi, so using it is a compile error without
                // an opt-in, and the opt-in is not worth taking on for a list
                // that is almost always two or three chips long.
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    studyFound.chunked(2).forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            row.forEach { app ->
                                Box(Modifier.weight(1f)) {
                                    Chip(
                                        text = app.label,
                                        selected = app.pkg in data.studyPackages,
                                        sticker = Mint,
                                    ) { haptics.tick(); onToggleStudy(app.pkg) }
                                }
                            }
                            // Keeps a lone chip on the last row at half width
                            // instead of stretching it across the screen.
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
            if (data.studyPackages.isEmpty()) {
                Text(
                    "Bina study app timer ₹ nahi dega.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }
            val subMins = split.firstOrNull { it.first == timer.subject }?.second ?: 0
            val untouched = split.filter { it.second == 0 }.map { it.first }
            // With no subject chosen there is nothing to report on, and
            // "untouched in 30 days" about a blank name is just a reproach for
            // not doing something nobody asked for.
            if (!justFocus && timer.subject.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(
                if (subMins == 0) "${timer.subject} untouched in 30 days"
                else "${timer.subject} · ${subMins}m in 30 days",
                style = MaterialTheme.typography.bodyMedium,
                color = if (subMins == 0) Tang.accent else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (untouched.isNotEmpty() && timer.subject !in untouched) {
                Text(
                    "Still 0: ${untouched.take(3).joinToString()}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            }
                    }

        Spacer(Modifier.height(24.dp))

        SquishButton(
            label = if (timer.running) "Pause" else "Begin",
            sticker = if (timer.running) Marigold else Jade,
            modifier = Modifier.fillMaxWidth(0.7f),
            onClick = onToggle,
        )

        if (timer.remaining < timer.totalSeconds) {
            Spacer(Modifier.height(10.dp))
            Text(
                "Give up — log partial time",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.reject(); confirmStop = true
                    }
                    .padding(10.dp),
            )
        }
    }

    if (confirmStop) {
        FrostScrim {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = Paper.ScreenPad),
                contentAlignment = Alignment.Center,
            ) {
                FrostSheet {
                    Column(
                        Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            "Stop this session?",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Partial time still gets banked.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(16.dp))
                        SquishButton(
                            label = "Stop and bank",
                            sticker = Tang,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            confirmStop = false
                            onAbandon()
                        }
                        Spacer(Modifier.height(10.dp))
                        SquishButton(
                            label = "Keep going",
                            sticker = Mint,
                            modifier = Modifier.fillMaxWidth(),
                        ) { confirmStop = false }
                    }
                }
            }
        }
    }
}
}

@Composable
private fun TimerRing(progress: Float, label: String, running: Boolean) {
    val animated by animateFloatAsState(progress, Motion.settle(), label = "p")
    val track = MaterialTheme.colorScheme.surfaceVariant

    Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 22.dp.toPx()
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(stroke / 2, stroke / 2)
            drawArc(track, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(Ink, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke + 6f, cap = StrokeCap.Round))
            drawArc(track, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(Ink, -90f, 360f * animated, false, topLeft, arcSize,
                style = Stroke(stroke + 6f, cap = StrokeCap.Round))
            drawArc(Sky.fill, -90f, 360f * animated, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                label,
                style = MaterialTheme.typography.displayMedium,
                color = Ink,
            )
            Text(
                if (running) "IN SESSION" else "READY",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun Chip(
    text: String,
    selected: Boolean,
    sticker: Sticker,
    onClick: () -> Unit,
) {
    val bg = if (selected) sticker.fill else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (selected) sticker.on else MaterialTheme.colorScheme.onSurfaceVariant
    Box(
        Modifier
            .clip(RoundedCornerShape(Paper.ChipRadius))
            .background(bg)
            .border(2.dp, Ink, RoundedCornerShape(Paper.ChipRadius))
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        Text(text, style = MaterialTheme.typography.titleMedium, color = fg)
    }
}
