package com.momentum.focus.ui.i18n

interface WalletStrings {
    val yourBalance: String
    val nothingBanked: String
    fun balancePaidFor(hours: Int, minutes: Int): String
    val earnMore: String
    val earned: String
    val spent: String
    val exchangeRate: String
    fun rateLine(minutes: Int, oneUnit: String): String
    val weekendRate: String
    val transactions: String
    val noTransactions: String
    fun studied(subject: String): String
    val unlockedAnApp: String
}

object WalletHi : WalletStrings {
    override val yourBalance = "TUMHARA BALANCE"
    override val nothingBanked = "Abhi kuch jama nahi. Ek session poora karo."
    override fun balancePaidFor(hours: Int, minutes: Int) =
        "${hours}h ${minutes}m screen time, pehle se kamaya hua."
    override val earnMore = "Aur kamao"
    override val earned = "KAMAYA"
    override val spent = "KHARCH"
    override val exchangeRate = "RATE"
    override fun rateLine(minutes: Int, oneUnit: String) = "$minutes min padhai = $oneUnit"
    override val weekendRate = "Weekend rate, aadhi keemat."
    override val transactions = "HISAAB"
    override val noTransactions = "Abhi koi entry nahi."
    override fun studied(subject: String) = "$subject padha"
    override val unlockedAnApp = "App unlock kiya"
}

object WalletEn : WalletStrings {
    override val yourBalance = "YOUR BALANCE"
    override val nothingBanked = "Nothing banked. Finish a session to earn."
    override fun balancePaidFor(hours: Int, minutes: Int) =
        "${hours}h ${minutes}m of screen time, already paid for."
    override val earnMore = "Earn more"
    override val earned = "EARNED"
    override val spent = "SPENT"
    override val exchangeRate = "EXCHANGE RATE"
    override fun rateLine(minutes: Int, oneUnit: String) = "$minutes min studied = $oneUnit"
    override val weekendRate = "Weekend rate, half price."
    override val transactions = "TRANSACTIONS"
    override val noTransactions = "No transactions yet."
    override fun studied(subject: String) = "Studied $subject"
    override val unlockedAnApp = "Unlocked an app"
}
