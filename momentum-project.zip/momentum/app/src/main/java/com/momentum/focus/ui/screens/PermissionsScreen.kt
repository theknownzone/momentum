package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import android.content.Intent
import android.provider.Settings
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.StickerCard
import com.momentum.focus.ui.theme.*
import com.momentum.focus.block.Admin
import com.momentum.focus.data.AppStore
import com.momentum.focus.ui.util.OemStartup
import com.momentum.focus.ui.util.Perm
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.rememberHaptics

@Composable
fun PermissionsScreen(onDone: () -> Unit) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val owner = LocalLifecycleOwner.current
    val store = remember { AppStore(context) }

    // Grants happen in system settings, outside this app. The only way to know
    // the result is to re-read every status when the screen resumes.
    var refresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refresh++
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    val statuses = remember(refresh) {
        Perm.entries.associateWith { Perms.granted(context, it) }
    }
    val readyToGo = remember(refresh) { Perms.allRequiredGranted(context) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 40.dp, bottom = 28.dp),
    ) {
        Text(
            "SETUP",
            style = MaterialTheme.typography.labelSmall,
            color = Mint.on,
        )
        Text(
            "Give it control",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            "Blocking apps needs real permissions. Nothing leaves your phone — there is no server.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp),
        )

        Spacer(Modifier.height(24.dp))

        Perm.entries.forEachIndexed { i, perm ->
            val on = statuses[perm] == true
            val sticker = if (on) Emerald else stickerFor(i + 1)

            StickerCard(
                sticker = sticker,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = Paper.Gap),
                onClick = if (on) null else {
                    {
                        Perms.intentFor(context, perm)?.let {
                            runCatching { context.startActivity(it) }
                        }
                    }
                },
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (perm.required) "REQUIRED" else "OPTIONAL",
                            style = MaterialTheme.typography.labelSmall,
                            color = sticker.on,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            perm.title,
                            style = MaterialTheme.typography.headlineSmall,
                            color = sticker.on,
                        )
                        Text(
                            perm.why,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Box(
                        Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(
                                if (on) Mint.fill
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        val guardOn = remember(refresh) { Perms.isShortsGuardOn(context) }
        // Above Hard the pact leans on two grants that are optional at lower
        // levels. Nothing here is force-granted — the screen just stops calling
        // them optional once the user has picked a level that needs them.
        val data by store.data.collectAsStateWithLifecycle(initialValue = null)
        val hardLevel = (data?.focusLevel ?: 0) >= 3 || data?.crownMode == true
        val adminOn = remember(refresh) { Admin.isActive(context) }

        if (hardLevel) {
            Text(
                "HARD / CROWN — ye do bhi chahiye",
                style = MaterialTheme.typography.labelSmall,
                color = Tang.accent,
            )
            Spacer(Modifier.height(8.dp))
            StickerCard(
                sticker = if (adminOn) Emerald else Violet,
                modifier = Modifier.fillMaxWidth().padding(bottom = Paper.Gap),
                onClick = if (adminOn) null else {
                    { runCatching { context.startActivity(Admin.requestIntent(context)) } }
                },
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (adminOn) "ON" else "REQUIRED FOR CROWN",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (adminOn) Emerald.on else Violet.on,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Device admin",
                            style = MaterialTheme.typography.headlineSmall,
                            color = if (adminOn) Emerald.on else Violet.on,
                        )
                        Text(
                            "Crown ke dauran app uninstall nahi hoti. Factory reset phir bhi " +
                                "kaam karta hai — ye owner-level lock nahi hai.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Box(
                        Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(
                                if (adminOn) Mint.fill
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                    )
                }
            }
        }

        StickerCard(
            sticker = if (guardOn) Emerald else Lilac,
            modifier = Modifier.fillMaxWidth().padding(bottom = Paper.Gap),
            onClick = {
                runCatching {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            },
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (guardOn) "ON" else "OPTIONAL",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (guardOn) Emerald.on else Lilac.on,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Shorts / Reels guard",
                        style = MaterialTheme.typography.headlineSmall,
                        color = if (guardOn) Emerald.on else Lilac.on,
                    )
                    Text(
                        "Accessibility ON = Shorts/Reels band, lecture video chalti. Pact ke dauran.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Box(
                    Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(
                            if (guardOn) Mint.fill
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                )
            }
        }

        // Autostart is the one thing on this screen the app genuinely cannot
        // verify. There is no API for it, so the card never claims a state —
        // it opens the vendor screen and spells out the path in words.
        if (OemStartup.isAffected) {
            Text(
                "THIS PHONE KILLS BACKGROUND APPS",
                style = MaterialTheme.typography.labelSmall,
                color = Tang.accent,
            )
            Spacer(Modifier.height(8.dp))
            StickerCard(
                sticker = Tang,
                modifier = Modifier.fillMaxWidth().padding(bottom = Paper.Gap),
                onClick = { OemStartup.open(context) },
            ) {
                Text("Autostart", style = MaterialTheme.typography.headlineSmall, color = Tang.on)
                Text(
                    OemStartup.path,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.on,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Iske bina Shield raat mein chup ho jaati hai. Android is switch ko " +
                        "padhne nahi deta, isliye app confirm nahi kar sakta — khud check karna.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        SquishButton(
            label = if (readyToGo) "Start" else "Grant required first",
            sticker = if (readyToGo) Emerald else Violet,
            modifier = Modifier.fillMaxWidth(),
        ) {
            if (!readyToGo) {
                haptics.reject()
                return@SquishButton
            }
            haptics.confirm()
            onDone()
        }

        if (!readyToGo) {
            Spacer(Modifier.height(10.dp))
            Text(
                "Usage + overlay + battery — teeno must. Tab tak aage nahi.",
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.accent,
            )
        }
    }
}
