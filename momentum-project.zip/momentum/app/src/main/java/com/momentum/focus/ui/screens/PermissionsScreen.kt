package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.StickerCard
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Perm
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.rememberHaptics

@Composable
fun PermissionsScreen(onDone: () -> Unit) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val owner = LocalLifecycleOwner.current

    // Grants happen in system settings, outside this app. The only way to know
    // the result is to re-read every status when the screen resumes.
    var refresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refresh++
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    val statuses = remember(refresh) {
        Perm.entries.associateWith { Perms.granted(context, it) }
    }
    val readyToGo = remember(refresh) { Perms.allRequiredGranted(context) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 40.dp, bottom = 28.dp),
    ) {
        Text(
            "SETUP",
            style = MaterialTheme.typography.labelSmall,
            color = Emerald.accent,
        )
        Text(
            "Give it control",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            "Blocking apps needs real permissions. Nothing leaves your phone — there is no server.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp),
        )

        Spacer(Modifier.height(24.dp))

        Perm.entries.forEachIndexed { i, perm ->
            val on = statuses[perm] == true
            val sticker = if (on) Emerald else stickerFor(i + 1)

            StickerCard(
                sticker = sticker,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = Paper.Gap),
                onClick = if (on) null else {
                    {
                        Perms.intentFor(context, perm)?.let {
                            runCatching { context.startActivity(it) }
                        }
                    }
                },
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (perm.required) "REQUIRED" else "OPTIONAL",
                            style = MaterialTheme.typography.labelSmall,
                            color = sticker.accent,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            perm.title,
                            style = MaterialTheme.typography.headlineSmall,
                            color = sticker.on,
                        )
                        Text(
                            perm.why,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Box(
                        Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(
                                if (on) Emerald.accent
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        SquishButton(
            label = if (readyToGo) "Start" else "Skip for now",
            sticker = if (readyToGo) Emerald else Violet,
            modifier = Modifier.fillMaxWidth(),
        ) { haptics.confirm(); onDone() }

        if (!readyToGo) {
            Spacer(Modifier.height(10.dp))
            Text(
                "Blocking stays off until the required ones are granted. You can come back from Settings.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
