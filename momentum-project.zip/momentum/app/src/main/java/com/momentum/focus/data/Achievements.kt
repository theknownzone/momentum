package com.momentum.focus.data

/**
 * Achievements are computed from the data that already exists, never stored.
 *
 * Storing them would mean a second source of truth that can drift out of sync
 * with the sessions themselves — and would let a bug hand out a badge that was
 * never earned, which is the fastest way to make the whole system feel fake.
 */
enum class Tier(val label: String) {
    BRONZE("BRONZE"), SILVER("SILVER"), GOLD("GOLD"), CROWN("CROWN")
}

data class Achievement(
    val id: String,
    val title: String,
    val detail: String,
    /** Said only once it is earned. Pride, never a lecture. */
    val reward: String,
    val tier: Tier,
    val progress: Float,
    val current: Int,
    val target: Int,
) {
    val unlocked: Boolean get() = progress >= 1f
}

private fun of(
    id: String,
    title: String,
    detail: String,
    reward: String,
    tier: Tier,
    current: Int,
    target: Int,
) = Achievement(
    id = id,
    title = title,
    detail = detail,
    reward = reward,
    tier = tier,
    progress = (current.toFloat() / target).coerceIn(0f, 1f),
    current = current.coerceAtMost(target),
    target = target,
)

fun AppData.achievements(): List<Achievement> {
    val completed = sessions.count { it.completed }
    val longestDay = (0..29).maxOfOrNull { minutesOn(java.time.LocalDate.now().toEpochDay() - it) } ?: 0
    val nightSessions = sessions.count { it.completed && it.minutes >= 45 }
    val journalDays = journal.size

    return listOf(
        of("first", "First deposit", "Finish one focus session",
            "You started. Most people never get past thinking about it.",
            Tier.BRONZE, completed, 1),
        of("ten", "Getting serious", "Ten sessions finished",
            "Ten times you chose the desk over the feed. That is a habit forming.",
            Tier.BRONZE, completed, 10),
        of("fifty", "Regular", "Fifty sessions finished",
            "Fifty sessions. This is not motivation any more, it is who you are.",
            Tier.SILVER, completed, 50),
        of("bank", "Ten hours banked", "Earn 600 focus minutes",
            "Ten hours of real work. Your parents would recognise that number.",
            Tier.SILVER, earnedMinutes, 600),
        of("marathon", "Long haul", "Three hours in a single day",
            "Three hours in one day. That is a topper's afternoon.",
            Tier.GOLD, longestDay, 180),
        of("deep", "Deep worker", "Twenty sessions of 45 minutes or more",
            "Twenty long sessions. Deep work is rare and you can do it now.",
            Tier.GOLD, nightSessions, 20),
        of("week", "Seven days", "Hold a seven day streak",
            "A full week held. The hardest week is behind you.",
            Tier.SILVER, maxOf(bestStreak, streakDays), 7),
        of("month", "Thirty days", "Hold a thirty day streak",
            "Thirty days. Your family can see the difference even if nobody says it.",
            Tier.CROWN, maxOf(bestStreak, streakDays), 30),
        of("resist", "Held the line", "Beat ten urges",
            "Ten times you wanted to and did not. That is the whole game.",
            Tier.GOLD, urgesSurvived, 10),
        of("honest", "Honest log", "Write ten journal entries",
            "Ten honest entries, slips included. Honesty is what makes the rest work.",
            Tier.BRONZE, journalDays, 10),
    )
}

val AppData.unlockedCount: Int get() = achievements().count { it.unlocked }
