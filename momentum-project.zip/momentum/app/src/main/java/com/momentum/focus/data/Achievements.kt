package com.momentum.focus.data

/**
 * Achievements are computed from the data that already exists, never stored.
 *
 * Storing them would mean a second source of truth that can drift out of sync
 * with the sessions themselves — and would let a bug hand out a badge that was
 * never earned, which is the fastest way to make the whole system feel fake.
 */
data class Achievement(
    val id: String,
    val title: String,
    val detail: String,
    val progress: Float,
    val current: Int,
    val target: Int,
) {
    val unlocked: Boolean get() = progress >= 1f
}

private fun of(
    id: String,
    title: String,
    detail: String,
    current: Int,
    target: Int,
) = Achievement(
    id = id,
    title = title,
    detail = detail,
    progress = (current.toFloat() / target).coerceIn(0f, 1f),
    current = current.coerceAtMost(target),
    target = target,
)

fun AppData.achievements(): List<Achievement> {
    val completed = sessions.count { it.completed }
    val longestDay = (0..29).maxOfOrNull { minutesOn(java.time.LocalDate.now().toEpochDay() - it) } ?: 0
    val nightSessions = sessions.count { it.completed && it.minutes >= 45 }
    val journalDays = journal.size

    return listOf(
        of("first", "First deposit", "Finish one focus session", completed, 1),
        of("ten", "Getting serious", "Ten sessions finished", completed, 10),
        of("fifty", "Regular", "Fifty sessions finished", completed, 50),
        of("bank", "Ten hours banked", "Earn 600 focus minutes", earnedMinutes, 600),
        of("marathon", "Long haul", "Three hours in a single day", longestDay, 180),
        of("deep", "Deep worker", "Twenty sessions of 45 minutes or more", nightSessions, 20),
        of("week", "Seven days", "Hold a seven day streak", maxOf(bestStreak, streakDays), 7),
        of("month", "Thirty days", "Hold a thirty day streak", maxOf(bestStreak, streakDays), 30),
        of("resist", "Held the line", "Beat ten urges", urgesSurvived, 10),
        of("honest", "Honest log", "Write ten journal entries", journalDays, 10),
    )
}

val AppData.unlockedCount: Int get() = achievements().count { it.unlocked }
