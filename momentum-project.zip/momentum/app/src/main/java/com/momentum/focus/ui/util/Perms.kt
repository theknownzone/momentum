package com.momentum.focus.ui.util

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.getSystemService

/**
 * Every permission this app needs, what it unlocks, and how to ask for it.
 *
 * Three of these cannot be granted by a normal dialog — usage access, overlay
 * and battery exemption all require sending the user into a system settings
 * page. So the app has to explain the reason first, then hand them off, then
 * re-check when they come back.
 */
enum class Perm(
    val title: String,
    val why: String,
    val required: Boolean,
) {
    NOTIFICATIONS(
        "Notifications",
        "Session reminders and streak milestones",
        required = false,
    ),
    USAGE_ACCESS(
        "Usage access",
        "Lets the app see which app is open, so it can block distractions",
        required = true,
    ),
    OVERLAY(
        "Display over other apps",
        "Draws the shield screen on top when you open a blocked app",
        required = true,
    ),
    BATTERY(
        "Unrestricted battery",
        "Stops Android killing the blocker in the background",
        required = false,
    );
}

object Perms {

    fun granted(context: Context, perm: Perm): Boolean = when (perm) {
        Perm.NOTIFICATIONS ->
            NotificationManagerCompat.from(context).areNotificationsEnabled()

        Perm.USAGE_ACCESS -> hasUsageAccess(context)

        Perm.OVERLAY -> Settings.canDrawOverlays(context)

        Perm.BATTERY -> context.getSystemService<PowerManager>()
            ?.isIgnoringBatteryOptimizations(context.packageName) ?: false
    }

    /**
     * There is no permission check for usage access — it has to be read out of
     * AppOps, which is the only place the grant is recorded.
     */
    private fun hasUsageAccess(context: Context): Boolean = runCatching {
        val ops = context.getSystemService<AppOpsManager>() ?: return false
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                context.packageName,
            )
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                context.packageName,
            )
        }
        mode == AppOpsManager.MODE_ALLOWED
    }.getOrDefault(false)

    /** Returns the settings intent for a permission, or null if it uses a dialog. */
    fun intentFor(context: Context, perm: Perm): Intent? = when (perm) {
        Perm.NOTIFICATIONS -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)

        Perm.USAGE_ACCESS -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

        Perm.OVERLAY -> Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}"),
        )

        Perm.BATTERY -> Intent(
            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            Uri.parse("package:${context.packageName}"),
        )
    }

    fun allRequiredGranted(context: Context): Boolean =
        Perm.entries.filter { it.required }.all { granted(context, it) }
}
