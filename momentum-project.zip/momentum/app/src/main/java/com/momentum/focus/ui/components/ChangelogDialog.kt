package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.util.Updater

/**
 * What changed in the build you are holding.
 *
 * The notes come from the release body, falling back to commit subjects when
 * nobody wrote one — [Updater.notesOrCommits] already does that work for the
 * update card, so this is the same source rather than a second one that could
 * disagree with it.
 */
@Composable
fun ChangelogDialog(onClose: () -> Unit) {
    val context = LocalContext.current
    var notes by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        notes = runCatching { Updater.notesOrCommits() }.getOrNull()
        loading = false
    }

    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 520.dp)
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(18.dp),
        ) {
            Text("KYA BADLA", style = MaterialTheme.typography.labelSmall, color = InkMid)
            Text(
                "v${Updater.currentVersion(context)}",
                style = MaterialTheme.typography.headlineSmall,
                color = Ink,
            )
            Spacer(Modifier.height(14.dp))

            Column(
                Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState()),
            ) {
                val text = when {
                    loading -> "Padh raha hoon…"
                    notes.isNullOrBlank() ->
                        "Notes nahi mile. Internet on hai? Ya is release pe kuch likha hi nahi gaya."
                    else -> notes!!
                }
                Text(
                    text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (loading || notes.isNullOrBlank()) InkMid else Ink,
                )
            }

            Spacer(Modifier.height(16.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Mint.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClose)
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "Band karo",
                    style = MaterialTheme.typography.titleMedium,
                    color = Mint.on,
                )
            }
        }
    }
}
