package com.momentum.focus.ui.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import com.momentum.focus.MainActivity
import com.momentum.focus.R

/**
 * The live session card — a countdown that stays visible while studying.
 *
 * Android's answer to the Dynamic Island is Live Updates: an ongoing
 * notification the system promotes to the top of the shade, onto the lock
 * screen, and into a chip in the status bar when the shade is closed. Samsung
 * routes them into the Now Bar. A focus session is exactly what the pattern is
 * for — ongoing, user-started, and worth glancing at for its whole duration.
 *
 * The promotion flag normally needs compileSdk 36, which this project is not on
 * yet. Rather than force a Gradle upgrade that cannot be verified here, the
 * flag is set through its string extra key instead. On a device new enough the
 * system reads it and promotes the notification; on every older device the
 * extra is ignored and this stays an ordinary ongoing notification with a live
 * countdown, which is still useful. Nothing breaks either way.
 */
object FocusNotice {

    private const val CHANNEL = "momentum_session"
    private const val ID = 78

    /** The string key behind setRequestPromotedOngoing, usable without API 36. */
    private const val EXTRA_PROMOTED = "android.requestPromotedOngoing"

    /** The string key behind setShortCriticalText — this is the status bar chip. */
    private const val EXTRA_SHORT_CRITICAL = "android.shortCriticalText"

    /**
     * Shows or updates the session card.
     *
     * @param endsAtMs when the session finishes, for the countdown
     * @param subject what is being studied, or null
     * @param elapsedMin minutes done so far, for the progress bar
     * @param totalMin the session length
     */
    fun show(
        context: Context,
        endsAtMs: Long,
        subject: String?,
        elapsedMin: Int,
        totalMin: Int,
    ) {
        if (!canPost(context)) return
        ensureChannel(context)

        val remaining = ((endsAtMs - System.currentTimeMillis()) / 60_000L)
            .coerceAtLeast(0L).toInt()

        val open = PendingIntent.getActivity(
            context,
            2,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        val builder = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(if (subject.isNullOrBlank()) "Focus" else subject)
            .setContentText("$remaining min baaki")
            .setSubText("Momentum")
            .setOngoing(true)
            // Without this every one-second update would re-alert, which on a
            // fifty minute session is fifty minutes of buzzing.
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(open)
            .setProgress(totalMin.coerceAtLeast(1), elapsedMin, false)
            // The system draws and ticks this itself, so the notification does
            // not have to be rewritten every second to show a live countdown.
            .setWhen(endsAtMs)
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)

        builder.extras.apply {
            putBoolean(EXTRA_PROMOTED, true)
            // Short enough to fit a status bar chip. "12m", not "12 minutes".
            putCharSequence(EXTRA_SHORT_CRITICAL, "${remaining}m")
        }

        runCatching {
            NotificationManagerCompat.from(context).notify(ID, builder.build())
        }
    }

    /** Clears the card. Called when a session ends, completes or is abandoned. */
    fun clear(context: Context) {
        runCatching { NotificationManagerCompat.from(context).cancel(ID) }
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = context.getSystemService<NotificationManager>() ?: return
        val channel = NotificationChannel(
            CHANNEL,
            "Focus session",
            // LOW so it never makes a sound. The card is there to be glanced
            // at, and a study app that pings every minute is a distraction
            // wearing the costume of a focus tool.
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = "Live countdown while a session is running"
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun canPost(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
}
