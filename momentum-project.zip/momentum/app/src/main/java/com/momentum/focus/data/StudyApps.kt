package com.momentum.focus.data

/**
 * Known study apps.
 *
 * There is no way to "auto-detect" that an app is educational — Android
 * exposes no such category reliably. So this is a maintained list, matched on
 * package prefix, and the user can add anything it misses.
 */
object StudyApps {
    private val known = listOf(
        "com.physicswallah",
        "xyz.penpencil",          // PW
        "com.nextoppers",
        "com.unacademy",
        "com.byjus",
        "com.vedantu",
        "com.doubtnut",
        "com.khanacademy",
        "com.google.android.apps.classroom",
        "com.duolingo",
        "com.adobe.reader",
        "com.microsoft.office.onenote",
        "com.evernote",
        "com.notion",
        "com.anydo",
        "org.coursera",
        "com.udemy",
    )

    fun looksLikeStudy(pkg: String): Boolean =
        known.any { pkg.startsWith(it) }

    fun suggestions(installed: List<String>): List<String> =
        installed.filter { looksLikeStudy(it) }
}
