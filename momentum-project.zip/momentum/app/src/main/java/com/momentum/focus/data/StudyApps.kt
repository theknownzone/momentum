package com.momentum.focus.data

/**
 * Known study apps.
 *
 * There is no way to "auto-detect" that an app is educational — Android
 * exposes no such category reliably. So this is a maintained list, matched on
 * package prefix, and the user can add anything it misses.
 */
object StudyApps {
    val known = listOf(
        "com.physicswallah",
        "xyz.penpencil",          // PW
        "com.nextoppers",
        "com.unacademy",
        "com.byjus",
        "com.vedantu",
        "com.doubtnut",
        "com.khanacademy",
        "com.google.android.apps.classroom",
        "com.duolingo",
        "com.adobe.reader",
        "com.microsoft.office.onenote",
        "com.evernote",
        "com.notion",
        "com.anydo",
        "org.coursera",
        "com.udemy",
    )

    val forbidden = listOf(
        "com.instagram",
        "com.google.android.youtube",
        "com.facebook",
        "com.snapchat",
        "com.twitter",
        "com.zhiliaoapp.musically",
        "com.ss.android.ugc.trill",
        "com.reddit",
        "in.mohalla.sharechat",
        "com.netflix",
        "com.hotstar",
        "com.whatsapp",
        "org.telegram",
        "com.discord",
        "com.android.chrome",
        "com.brave.browser",
        "com.opera",
    )

    fun isForbidden(pkg: String): Boolean =
        forbidden.any { pkg.startsWith(it) }

    fun looksLikeStudy(pkg: String): Boolean =
        known.any { pkg.startsWith(it) } && !isForbidden(pkg)

    fun suggestions(installed: List<String>): List<String> =
        installed.filter { looksLikeStudy(it) }
}
