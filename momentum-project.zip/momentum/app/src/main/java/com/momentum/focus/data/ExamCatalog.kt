package com.momentum.focus.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

data class ExamEntry(
    val id: String,
    val name: String,
    val region: String,
)

/**
 * Bundled list first. If GitHub has a newer exams.json, swap it in.
 * Offline always works.
 */
object ExamCatalog {

    private const val REMOTE =
        "https://raw.githubusercontent.com/theknownzone/momentum/main/exams.json"

    @Volatile
    private var cached: List<ExamEntry> = emptyList()

    fun bundled(context: Context): List<ExamEntry> {
        if (cached.isNotEmpty()) return cached
        val text = runCatching {
            context.assets.open("exams.json").bufferedReader().use { it.readText() }
        }.getOrDefault("[]")
        cached = parse(text)
        return cached
    }

    suspend fun refresh(context: Context): List<ExamEntry> = withContext(Dispatchers.IO) {
        val local = bundled(context)
        val remote = runCatching {
            val conn = (URL(REMOTE).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
            }
            if (conn.responseCode != 200) return@runCatching null
            parse(conn.inputStream.bufferedReader().use { it.readText() })
        }.getOrNull()
        if (!remote.isNullOrEmpty()) {
            cached = remote
            remote
        } else local
    }

    fun search(list: List<ExamEntry>, query: String): List<ExamEntry> {
        val q = query.trim().lowercase()
        if (q.length < 2) return emptyList()
        return list.filter {
            it.name.lowercase().contains(q) || it.id.contains(q)
        }.take(8)
    }

    private fun parse(text: String): List<ExamEntry> = runCatching {
        val arr = JSONArray(text)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ExamEntry(
                id = o.optString("id"),
                name = o.optString("name"),
                region = o.optString("region"),
            )
        }
    }.getOrDefault(emptyList())
}
