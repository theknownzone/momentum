package com.momentum.focus.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

data class ExamEntry(
    val id: String,
    val name: String,
    val region: String,
)

/**
 * Bundled list first. If GitHub has a newer exams.json, swap it in.
 * Offline always works.
 */
object ExamCatalog {

    private const val REMOTE =
        "https://raw.githubusercontent.com/theknownzone/momentum/main/exams.json"

    @Volatile
    private var cached: List<ExamEntry> = emptyList()

    fun bundled(context: Context): List<ExamEntry> {
        if (cached.isNotEmpty()) return cached
        val text = runCatching {
            context.assets.open("exams.json").bufferedReader().use { it.readText() }
        }.getOrDefault("[]")
        cached = parse(text)
        return cached
    }

    suspend fun refresh(context: Context): List<ExamEntry> = withContext(Dispatchers.IO) {
        val local = bundled(context)
        val remote = runCatching {
            val conn = (URL(REMOTE).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
            }
            if (conn.responseCode != 200) return@runCatching null
            parse(conn.inputStream.bufferedReader().use { it.readText() })
        }.getOrNull()
        if (!remote.isNullOrEmpty()) {
            cached = remote
            remote
        } else local
    }

    fun packFor(name: String): List<String> {
        val n = name.lowercase()
        return when {
            "neet" in n -> listOf("Physics", "Chemistry", "Biology")
            "jee" in n || "gate" in n -> listOf("Physics", "Maths", "Chemistry")
            "cuet" in n -> listOf("Language", "Domain", "GT")
            "upsc" in n || "ras" in n -> listOf("GS", "CSAT", "Optional")
            "ssc" in n || "rrb" in n -> listOf("Maths", "English", "GS")
            "ibps" in n || "sbi" in n || "bank" in n -> listOf("Quant", "Reasoning", "English")
            "cat" in n || "gmat" in n -> listOf("Quant", "DILR", "Verbal")
            "ldc" in n || "reet" in n || "rpsc" in n -> listOf("Hindi", "English", "GK")
            n.startsWith("ca") -> listOf("Accounts", "Law", "Tax")
            "clat" in n -> listOf("Legal", "GK", "English")
            "nda" in n || "cds" in n -> listOf("Maths", "GAT", "English")
            "board" in n || "cbse" in n || "rbse" in n -> listOf("Physics", "Chemistry", "Maths")
            "ielts" in n || "toefl" in n -> listOf("Reading", "Writing", "Speaking")
            "sat" in n || "gre" in n || "act" in n -> listOf("Math", "Verbal", "Writing")
            else -> listOf("Paper 1", "Paper 2", "Revision")
        }
    }

    fun search(list: List<ExamEntry>, query: String): List<ExamEntry> {
        val q = query.trim().lowercase()
        if (q.length < 2) return emptyList()
        return list.filter {
            it.name.lowercase().contains(q) || it.id.contains(q)
        }.take(8)
    }

    private fun parse(text: String): List<ExamEntry> = runCatching {
        val arr = JSONArray(text)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ExamEntry(
                id = o.optString("id"),
                name = o.optString("name"),
                region = o.optString("region"),
            )
        }
    }.getOrDefault(emptyList())
}
