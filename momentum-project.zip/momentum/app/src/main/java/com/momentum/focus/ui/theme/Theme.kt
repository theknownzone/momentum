package com.momentum.focus.ui.theme

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightScheme = lightColorScheme(
    background        = PaperLight,
    onBackground      = InkStrong,
    surface           = PaperLightRaise,
    onSurface         = InkStrong,
    surfaceVariant    = PaperLightSunk,
    onSurfaceVariant  = InkMuted,
    primary           = Coral.fill,
    onPrimary         = Coral.on,
    secondary         = Jade.fill,
    onSecondary       = Jade.on,
    tertiary          = Marigold.fill,
    onTertiary        = Marigold.on,
    outline           = InkFaint,
)

private val DarkScheme = darkColorScheme(
    background        = PaperDark,
    onBackground      = InkStrongD,
    surface           = PaperDarkRaise,
    onSurface         = InkStrongD,
    surfaceVariant    = PaperDarkSunk,
    onSurfaceVariant  = InkMutedD,
    primary           = Coral.fill,
    onPrimary         = Coral.on,
    secondary         = Jade.fill,
    onSecondary       = Jade.on,
    tertiary          = Marigold.fill,
    onTertiary        = Marigold.on,
    outline           = InkFaintD,
)

@Composable
fun MomentumTheme(
    dark: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        typography = AppTypography,
        content = content,
    )
}

// ---- Motion ---------------------------------------------------------------
// One rule: nothing in this app uses a linear or default tween. Every change
// is a spring, because springs are what the hand reads as "alive".
object Motion {
    /** Buttons, chips, anything under a finger. Fast, barely any overshoot. */
    fun <T> press() = spring<T>(
        dampingRatio = 0.55f,
        stiffness = Spring.StiffnessHigh,
    )

    /** Cards entering, sheets, layout shifts. Visible, playful bounce. */
    fun <T> bouncy() = spring<T>(
        dampingRatio = 0.42f,
        stiffness = Spring.StiffnessMediumLow,
    )

    /** Progress rings, counters. Smooth settle, no wobble. */
    fun <T> settle() = spring<T>(
        dampingRatio = 1f,
        stiffness = Spring.StiffnessLow,
    )
}

object Paper {
    val CardRadius = 26.dp
    val ChipRadius = 18.dp
    /** How far the "cut paper" shadow sits below-right of a sticker element. */
    val StickerOffset = 5.dp
    val ScreenPad = 20.dp
    val Gap = 14.dp
}
