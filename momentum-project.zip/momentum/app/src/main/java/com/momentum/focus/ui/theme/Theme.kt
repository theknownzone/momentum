package com.momentum.focus.ui.theme

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val Scheme = lightColorScheme(
    background       = Cream,
    onBackground     = Ink,
    surface          = CreamCard,
    onSurface        = Ink,
    surfaceVariant   = Sunk,
    onSurfaceVariant = InkMid,
    primary          = Mint.fill,
    onPrimary        = Mint.on,
    secondary        = Butter.fill,
    onSecondary      = Butter.on,
    tertiary         = Lilac.fill,
    onTertiary       = Lilac.on,
    outline          = Ink,
)

@Composable
fun MomentumTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = AppTypography, content = content)
}

object Motion {
    fun <T> press() = spring<T>(dampingRatio = 0.55f, stiffness = Spring.StiffnessHigh)
    fun <T> bouncy() = spring<T>(dampingRatio = 0.42f, stiffness = Spring.StiffnessMediumLow)
    fun <T> settle() = spring<T>(dampingRatio = 1f, stiffness = Spring.StiffnessLow)
}

object Paper {
    val CardRadius = 16.dp
    val ChipRadius = 13.dp
    val StickerOffset = 0.dp
    /** Every outline in the app is this thick. Vary it and the print look dies. */
    val Outline = 3.dp
    val ScreenPad = 18.dp
    val Gap = 12.dp
}
