package com.momentum.focus.ui.theme

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val Scheme = darkColorScheme(
    background       = Void,
    onBackground     = Chalk,
    surface          = Charcoal,
    onSurface        = Chalk,
    surfaceVariant   = Slate,
    onSurfaceVariant = Ash,
    primary          = Emerald.accent,
    onPrimary        = Void,
    secondary        = Gold.accent,
    onSecondary      = Void,
    tertiary         = Violet.accent,
    onTertiary       = Void,
    outline          = Dim,
)

/** Dark only. A focus app is used at night; a light mode would defeat it. */
@Composable
fun MomentumTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = AppTypography, content = content)
}

object Motion {
    fun <T> press() = spring<T>(dampingRatio = 0.55f, stiffness = Spring.StiffnessHigh)
    fun <T> bouncy() = spring<T>(dampingRatio = 0.42f, stiffness = Spring.StiffnessMediumLow)
    fun <T> settle() = spring<T>(dampingRatio = 1f, stiffness = Spring.StiffnessLow)
}

object Paper {
    val CardRadius = 24.dp
    val ChipRadius = 16.dp
    val StickerOffset = 4.dp
    val ScreenPad = 20.dp
    val Gap = 12.dp
}
