package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.ui.components.GlassPanel
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.launch

/**
 * The two plans, and an explicit promise about where the line sits.
 *
 * Everything that stops a distraction is free — the shield, the feed guard, the
 * pact, crown mode and panic. What is paid is room to work in: more profiles,
 * more themes, the full history, a backup. Someone relapsing because they did
 * not pay would be the app failing at the only job it has, so the free column
 * is listed first and the promise is printed under the buy button rather than
 * buried in a policy.
 */
@Composable
fun PlansScreen(
    data: AppData,
    onBuy: () -> Unit,
    onRedeem: suspend (String) -> Boolean,
    onRemove: () -> Unit,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()
    val skin = LocalSkin.current
    var keyOpen by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        // A large ghost word behind the heading, the way a pricing page sets
        // its own title as a backdrop. Kept faint enough to read as texture —
        // any darker and it competes with the line that actually matters.
        Box(Modifier.fillMaxWidth()) {
            Text(
                "PLANS",
                style = MaterialTheme.typography.displayLarge,
                color = skin.accent.copy(alpha = 0.16f),
                maxLines = 1,
                // Scaled from its left edge, not its centre — scaling about
                // the centre pushed half the word off the screen, which is why
                // it read as "LANS".
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(y = (-10).dp)
                    .graphicsLayer {
                        scaleX = 1.7f
                        scaleY = 1.7f
                        transformOrigin = TransformOrigin(0f, 0.5f)
                    },
            )
            Column {
                Text("PLANS", style = MaterialTheme.typography.labelSmall, color = InkMid)
                Text(
                    "Blocking stays free.",
                    style = MaterialTheme.typography.displayMedium,
                    color = Ink,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Pay only if you want more room to work in.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = InkMid,
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        // ---- free ----
        GlassPanel(Modifier.fillMaxWidth(), tint = skin.petal) {
          Column(Modifier.padding(16.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Free", style = MaterialTheme.typography.headlineSmall, color = Ink)
                if (!data.premium) Tag("YOU'RE ON THIS", Mint)
            }
            Rule()
            PlanLine("App blocking + shield")
            PlanLine("Shorts / Reels / Stories guard")
            PlanLine("Focus timer + wallet")
            PlanLine("Pact & crown mode")
            PlanLine("Panic button")
            PlanLine("Unlimited profiles & schedules")
            PlanLine("Full history")
            Spacer(Modifier.height(6.dp))
            Text(
                "Themes unlock as you level up.",
                style = MaterialTheme.typography.bodyMedium,
                color = InkMid,
            )
          }
        }

        Spacer(Modifier.height(Paper.Gap))

        // ---- lifetime ----
        // The aura is the only glow in the app and it appears on exactly one
        // card. That scarcity is what makes it read as premium rather than as
        // decoration.
        Aura(color = skin.accent, strength = if (data.premium) 0.5f else 0.32f) {
            GlassPanel(Modifier.fillMaxWidth(), tint = skin.accent) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(Butter.fill)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom,
                ) {
                    Text(
                        "Lifetime",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Butter.on,
                    )
                    Text(
                        if (data.premium) "Yours" else "₹399",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Butter.on,
                    )
                }
                Box(Modifier.fillMaxWidth().height(Paper.Outline).background(Ink))

                Column(Modifier.padding(16.dp)) {
                    Text(
                        "One payment. No subscription, ever.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                    )
                    Spacer(Modifier.height(10.dp))
                    PlanLine("Every theme, unlocked today")
                    PlanLine("The glow on your card")
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "AAGE AA RAHA HAI",
                        style = MaterialTheme.typography.labelSmall,
                        color = InkMid,
                    )
                    Spacer(Modifier.height(4.dp))
                    Soon("Backup & restore")
                    Soon("Website blocking")
                    Text(
                        "Ye abhi bane nahi hain. Jab banenge, tumhe muft milenge — " +
                            "dobara paise nahi.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                    )

                    Spacer(Modifier.height(16.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (data.premium) Sunk else Mint.fill)
                            .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                            .clickableNoRipple(
                                remember { MutableInteractionSource() },
                                enabled = !data.premium,
                            ) { haptics.confirm(); onBuy() }
                            .padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            if (data.premium) "Unlocked" else "Unlock lifetime",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (data.premium) InkMid else Mint.on,
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        if (data.premium) "Key: ${License.pretty(data.licenseKey)}"
                        else "Already bought? Enter your key",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tap()
                                if (data.premium) onRemove() else keyOpen = true
                            }
                            .padding(6.dp),
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Nothing that blocks a distraction is behind this.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                        modifier = Modifier.align(Alignment.CenterHorizontally),
                    )
                }
            }
        }

        if (keyOpen) {
            LicenseDialog(
                onRedeem = onRedeem,
                onClose = { keyOpen = false },
            )
        }

        Spacer(Modifier.height(20.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                .clickableNoRipple(remember { MutableInteractionSource() }) {
                    haptics.tap(); onDone()
                }
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text("Back", style = MaterialTheme.typography.titleMedium, color = Ink)
        }
    }
}

@Composable
private fun Rule() {
    Spacer(Modifier.height(10.dp))
    Box(Modifier.fillMaxWidth().height(Paper.Outline).background(Ink))
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun PlanLine(text: String) {
    Row(Modifier.padding(vertical = 3.dp)) {
        Text("✓", style = MaterialTheme.typography.bodyLarge, color = Mint.accent)
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge, color = Ink)
    }
}

@Composable
private fun Tag(label: String, sticker: Sticker) {
    Box(
        Modifier
            .clip(RoundedCornerShape(9.dp))
            .background(sticker.fill)
            .border(2.dp, Ink, RoundedCornerShape(9.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = sticker.on)
    }
}

/**
 * Key entry.
 *
 * Deliberately forgiving about formatting: it accepts lowercase, missing dashes
 * and stray spaces, because these get retyped from an email on a phone keyboard
 * and rejecting a correct key over a lowercase letter is a support ticket that
 * should never exist. Only a genuinely wrong key is refused, and it says so
 * rather than silently doing nothing.
 */
@Composable
private fun LicenseDialog(
    onRedeem: suspend (String) -> Boolean,
    onClose: () -> Unit,
) {
    val haptics = rememberHaptics()
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(18.dp),
        ) {
            Text("LICENCE KEY", style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(4.dp))
            Text(
                "Jo key kharidne pe mili thi",
                style = MaterialTheme.typography.headlineSmall,
                color = Ink,
            )
            Spacer(Modifier.height(14.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(24); error = false },
                placeholder = { Text("MOM-XXXXX-XXXXX-XXXXX") },
                singleLine = true,
                isError = error,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )

            if (error) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Ye key sahi nahi hai. Dobara dekh lo — dash aur capital " +
                        "letters ki fikar mat karo, wo apne aap sambhal jaate hain.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClose)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("Cancel", style = MaterialTheme.typography.titleMedium, color = Ink)
                }
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Mint.fill)
                        .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(
                            remember { MutableInteractionSource() },
                            enabled = !checking && text.isNotBlank(),
                        ) {
                            checking = true
                            scope.launch {
                                val ok = onRedeem(text)
                                checking = false
                                if (ok) { haptics.confirm(); onClose() }
                                else { haptics.press(); error = true }
                            }
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (checking) "Checking…" else "Unlock",
                        style = MaterialTheme.typography.titleMedium,
                        color = Mint.on,
                    )
                }
            }
        }
    }
}

/** A line for something bought but not built yet. Struck through, not ticked. */
@Composable
private fun Soon(text: String) {
    Row(Modifier.padding(vertical = 3.dp)) {
        Text("\u25CB", style = MaterialTheme.typography.bodyLarge, color = InkMid)
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge, color = InkMid)
    }
}
