package com.momentum.focus.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate

/**
 * The written cards on Home, fetched from the repo so they can change without
 * shipping a build.
 *
 * They were hardcoded, which meant the deck read identically on day one and
 * day fifty and there was no way to add one without a release. Same shape as
 * `holidays.json`: a bundled copy ships in assets so the deck is never empty
 * offline, and a remote copy replaces it when reachable.
 *
 * Not a public quotes API on purpose. Those return English aphorisms with
 * invented attributions — half the "Kalam said" lines in circulation were
 * never said by him — and none of it would sound like the rest of the app.
 * Writing them means they are in the right language and cannot be wrong about
 * who said what.
 *
 * `day` rotates the deck: cards with no day always qualify, and a card marked
 * with a weekday only appears on it.
 */
data class Card(
    val kicker: String,
    val title: String,
    val punch: String,
    val body: String,
    val tone: String,
    val day: Int? = null,
)

object CardFeed {

    private const val REMOTE =
        "https://raw.githubusercontent.com/theknownzone/momentum/main/cards.json"

    @Volatile
    private var cached: List<Card> = emptyList()

    fun bundled(context: Context): List<Card> {
        if (cached.isNotEmpty()) return cached
        val text = runCatching {
            context.assets.open("cards.json").bufferedReader().use { it.readText() }
        }.getOrDefault("[]")
        cached = parse(text)
        return cached
    }

    suspend fun refresh(context: Context): List<Card> = withContext(Dispatchers.IO) {
        val local = bundled(context)
        val remote = runCatching {
            val conn = (URL(REMOTE).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
            }
            if (conn.responseCode != 200) return@runCatching null
            parse(conn.inputStream.bufferedReader().use { it.readText() })
        }.getOrNull()
        if (!remote.isNullOrEmpty()) {
            cached = remote
            remote
        } else local
    }

    /** Cards valid for today, in a stable order that shifts with the date. */
    fun forToday(all: List<Card>, today: LocalDate = LocalDate.now()): List<Card> {
        val dow = today.dayOfWeek.value
        val eligible = all.filter { it.day == null || it.day == dow }
        if (eligible.isEmpty()) return emptyList()
        // Rotate by the day number so the deck does not open on the same card
        // every morning, without being random enough to feel unstable.
        val shift = (today.toEpochDay() % eligible.size).toInt()
        return eligible.drop(shift) + eligible.take(shift)
    }

    private fun parse(text: String): List<Card> = runCatching {
        val arr = JSONArray(text)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val title = o.optString("title")
            if (title.isBlank()) return@mapNotNull null
            Card(
                kicker = o.optString("kicker", "NOTE"),
                title = title,
                punch = o.optString("punch"),
                body = o.optString("body"),
                tone = o.optString("tone", "mint"),
                day = o.optInt("day", 0).takeIf { it in 1..7 },
            )
        }
    }.getOrDefault(emptyList())
}
