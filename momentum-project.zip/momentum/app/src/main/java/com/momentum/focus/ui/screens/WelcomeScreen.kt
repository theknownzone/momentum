package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

private data class Page(
    val kicker: String,
    val title: String,
    val body: String,
    val sticker: Sticker,
)

private val PAGES = listOf(
    Page(
        "HOW IT WORKS",
        "Focus is money",
        "Study a minute, bank a minute. That balance at the top of the app is the only currency here, and nothing but studying adds to it.",
        Emerald,
    ),
    Page(
        "THE CATCH",
        "Distraction costs",
        "Scrolling costs what you banked. Empty balance, locked app. You set that price now, while you are calm — not at midnight, mid-craving.",
        Gold,
    ),
    Page(
        "WHEN IT'S HARD",
        "One tap out",
        "An urge peaks in about ten minutes. Hit Panic and wait it out with something to hold onto. Slip anyway and it gets logged, not judged — you delete the app that scolds you.",
        Ember,
    ),
)

@Composable
fun WelcomeScreen(
    onDone: (String) -> Unit,
) {
    val haptics = rememberHaptics()
    var index by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }

    val onNamePage = index == PAGES.size

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 32.dp, bottom = 24.dp),
    ) {
        // Progress dots. Four steps is short enough that people finish it.
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(PAGES.size + 1) { i ->
                Box(
                    Modifier
                        .height(4.dp)
                        .weight(1f)
                        .clip(RoundedCornerShape(50))
                        .background(
                            if (i <= index) Mint.fill
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                )
            }
        }

        Spacer(Modifier.weight(1f))

        if (onNamePage) {
            Text(
                "LAST THING",
                style = MaterialTheme.typography.labelSmall,
                color = Lilac.on,
            )
            Text(
                "What should I call you?",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(18) },
                placeholder = { Text("Your name") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            )

            // Typing into an empty box gives no sense of what the name is for.
            // Showing the greeting as it is typed makes the field feel like it
            // is wiring something up rather than collecting a field.
            Spacer(Modifier.height(16.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .background(Lilac.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                    .padding(16.dp),
            ) {
                Column {
                    Text(
                        "YOU'LL SEE",
                        style = MaterialTheme.typography.labelSmall,
                        color = Lilac.on.copy(alpha = 0.7f),
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (name.isBlank()) "Welcome back." else "Welcome back, ${name.trim()}.",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Lilac.on,
                    )
                }
            }
        } else {
            val page = PAGES[index]
            Box(
                Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(page.sticker.fill)
                    .border(Paper.Outline, Ink, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "${index + 1}",
                    style = MaterialTheme.typography.headlineSmall,
                    color = page.sticker.on,
                )
            }
            Spacer(Modifier.height(22.dp))
            Text(
                page.kicker,
                style = MaterialTheme.typography.labelSmall,
                color = page.sticker.on,
            )
            Text(
                page.title,
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                page.body,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Spacer(Modifier.weight(1f))

        SquishButton(
            label = if (onNamePage) "Start" else "Next",
            sticker = if (onNamePage) Emerald else Ice,
            modifier = Modifier.fillMaxWidth(),
        ) {
            haptics.confirm()
            if (onNamePage) onDone(name.trim()) else index++
        }

        if (!onNamePage) {
            Spacer(Modifier.height(10.dp))
            Text(
                "Skip",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .padding(10.dp),
            )
        }
    }
}
