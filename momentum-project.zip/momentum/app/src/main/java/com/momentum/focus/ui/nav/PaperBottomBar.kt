package com.momentum.focus.ui.nav

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import com.momentum.focus.ui.components.FrostPill
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

enum class Tab(val icon: ImageVector, val sticker: Sticker) {
    HOME(Icons.Filled.Home, Mint),
    FOCUS(Icons.Filled.Timer, Sky),
    WALLET(Icons.Filled.AccountBalanceWallet, Butter),
    STATS(Icons.Filled.BarChart, Tang),
    REWARDS(Icons.Filled.MilitaryTech, Lilac),
    JOURNAL(Icons.Filled.EditNote, Candy),
}

@Composable
fun PaperBottomBar(
    current: Tab,
    onSelect: (Tab) -> Unit,
) {
    val haptics = rememberHaptics()
    Box(
        Modifier
            .fillMaxWidth()
            .background(Color.Transparent)
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
    FrostPill(Modifier.fillMaxWidth()) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Tab.entries.forEach { tab ->
            val selected = tab == current
            // The selected tab lifts and fills with its own colour. No labels —
            // four destinations is few enough that icons alone stay legible.
            val scale by animateFloatAsState(
                if (selected) 1f else 0.86f, Motion.bouncy(), label = tab.name
            )
            Box(
                Modifier
                    .scale(scale)
                    .clip(RoundedCornerShape(15.dp))
                    .background(
                        if (selected) tab.sticker.fill
                        else CreamCard
                    )
                    .border(
                        if (selected) Paper.Outline else 2.dp,
                        Ink,
                        RoundedCornerShape(15.dp),
                    )
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        if (!selected) { haptics.tap(); onSelect(tab) }
                    }
                    .padding(horizontal = 10.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    tab.icon,
                    contentDescription = tab.name.lowercase(),
                    tint = if (selected) tab.sticker.on else Ink,
                )
            }
        }
    }
    }
    }
}
