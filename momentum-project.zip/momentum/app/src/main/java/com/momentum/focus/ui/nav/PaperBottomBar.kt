package com.momentum.focus.ui.nav

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

enum class Tab(val icon: ImageVector, val sticker: Sticker) {
    HOME(Icons.Filled.Home, Jade),
    FOCUS(Icons.Filled.Timer, Cobalt),
    STATS(Icons.Filled.BarChart, Marigold),
    JOURNAL(Icons.Filled.EditNote, Grape),
}

@Composable
fun PaperBottomBar(
    current: Tab,
    onSelect: (Tab) -> Unit,
) {
    val haptics = rememberHaptics()
    Row(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Tab.entries.forEach { tab ->
            val selected = tab == current
            // The selected tab lifts and fills with its own colour. No labels —
            // four destinations is few enough that icons alone stay legible.
            val scale by animateFloatAsState(
                if (selected) 1f else 0.86f, Motion.bouncy(), label = tab.name
            )
            Box(
                Modifier
                    .scale(scale)
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        if (selected) tab.sticker.fill
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        if (!selected) { haptics.tap(); onSelect(tab) }
                    }
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    tab.icon,
                    contentDescription = tab.name.lowercase(),
                    tint = if (selected) tab.sticker.on else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
