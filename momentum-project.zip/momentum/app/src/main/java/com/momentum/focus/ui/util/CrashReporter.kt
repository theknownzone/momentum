package com.momentum.focus.ui.util

import android.content.Context
import java.io.File

/**
 * A phone with no laptop attached has no logcat. So the app catches its own
 * crashes, writes the stack trace to disk, and shows it on the next launch.
 * The user can screenshot that screen — which is the whole debugging loop.
 */
object CrashReporter {

    private const val FILE = "last_crash.txt"

    fun install(context: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                val text = buildString {
                    appendLine("Thread: ${thread.name}")
                    appendLine("Type: ${error::class.java.name}")
                    appendLine("Message: ${error.message}")
                    appendLine()
                    error.stackTrace.take(25).forEach { appendLine(it.toString()) }
                    var cause = error.cause
                    var depth = 0
                    while (cause != null && depth < 3) {
                        appendLine()
                        appendLine("Caused by: ${cause::class.java.name}: ${cause.message}")
                        cause.stackTrace.take(12).forEach { appendLine(it.toString()) }
                        cause = cause.cause
                        depth++
                    }
                }
                File(context.filesDir, FILE).writeText(text)
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun lastCrash(context: Context): String? {
        val f = File(context.filesDir, FILE)
        return if (f.exists()) runCatching { f.readText() }.getOrNull() else null
    }

    fun clear(context: Context) {
        runCatching { File(context.filesDir, FILE).delete() }
    }
}
