package com.momentum.focus.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

/**
 * Exam notifications from across India, pulled from the repo.
 *
 * An item is either a standing link to an official notice board or a dated
 * announcement — a form date, an admit card, a result, a postponement. Only
 * the second kind sets [ExamNewsItem.alert] and is allowed to interrupt. The bundled copy in assets is what a fresh install reads, and
 * the remote copy is what keeps it current — same arrangement the cards and
 * the exam catalogue already use, so publishing an alert is editing one JSON
 * file rather than shipping a build.
 *
 * The app never invents an item. Everything shown here is something written
 * into that file with a source, because a wrong date on an exam alert is worse
 * than no alert at all.
 */
data class ExamNewsItem(
    val id: String,
    val title: String,
    val body: String,
    val exam: String,
    val region: String,
    val date: String,
    val url: String,
    /**
     * Whether this item may interrupt with a popup.
     *
     * Most of the feed is standing links to official notice boards, which are
     * true every day of the year and are not news. Those belong in the card,
     * where they can be browsed, and nowhere else — a portal link that arrives
     * as an alert teaches people to dismiss alerts. Only a dated announcement
     * with a deadline attached should be allowed to take over the screen.
     */
    val alert: Boolean = false,
) {
    /**
     * True when this item is about the exam the user is actually preparing for.
     *
     * Matching is on whole words, not substrings. "CA" reads as a substring of
     * "CAT" and "cat" of "CA Intermediate", so a substring test quietly serves
     * chartered-accountancy notices to MBA candidates and the other way round.
     * Splitting both sides into words and asking whether ours are all present
     * lets a family key like "SSC" still cover "SSC CGL" without that risk.
     */
    fun matches(examName: String?): Boolean {
        // A blank exam means the item is genuinely for everyone.
        if (exam.isBlank() || exam.equals("All", true)) return true
        val theirs = examName.orEmpty().lowercase().split(WORDS).filter { it.isNotBlank() }
        // Nothing chosen yet, so there is nothing to filter against. Showing
        // the whole board beats showing an empty one.
        if (theirs.isEmpty()) return true
        val ours = exam.lowercase().split(WORDS).filter { it.isNotBlank() }
        return ours.isNotEmpty() && theirs.containsAll(ours)
    }

    private companion object {
        val WORDS = Regex("[^a-z0-9]+")
    }
}

object ExamNews {

    private const val REMOTE =
        "https://raw.githubusercontent.com/theknownzone/momentum/main/exam-news.json"

    private const val PREFS = "exam_news"
    private const val KEY_SEEN = "seen_ids"

    @Volatile
    private var cached: List<ExamNewsItem> = emptyList()

    fun bundled(context: Context): List<ExamNewsItem> {
        if (cached.isNotEmpty()) return cached
        val text = runCatching {
            context.assets.open("exam-news.json").bufferedReader().use { it.readText() }
        }.getOrDefault("[]")
        cached = parse(text)
        return cached
    }

    /**
     * Bundled list, replaced by the remote one when it is reachable.
     *
     * A failed fetch is not an error state here — it returns what is already
     * on the device. The app is used with the network off constantly.
     */
    suspend fun refresh(context: Context): List<ExamNewsItem> = withContext(Dispatchers.IO) {
        val local = bundled(context)
        val remote = runCatching {
            val conn = (URL(REMOTE).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
            }
            if (conn.responseCode != 200) return@runCatching null
            parse(conn.inputStream.bufferedReader().use { it.readText() })
        }.getOrNull()
        if (!remote.isNullOrEmpty()) {
            cached = remote
            remote
        } else local
    }

    /**
     * The newest unseen item that is relevant to this user, or null.
     *
     * Relevance is checked before novelty so a UPSC alert never interrupts
     * someone studying for NEET. Everything marked All India is relevant to
     * everyone.
     */
    fun nextUnseen(
        context: Context,
        items: List<ExamNewsItem>,
        examName: String?,
    ): ExamNewsItem? {
        val seen = seenIds(context)
        return items
            .filter { it.alert && it.id !in seen && it.matches(examName) }
            .maxByOrNull { it.date }
    }

    fun relevant(
        items: List<ExamNewsItem>,
        examName: String?,
    ): List<ExamNewsItem> =
        items.filter { it.matches(examName) }.sortedByDescending { it.date }

    fun markSeen(context: Context, id: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val seen = prefs.getStringSet(KEY_SEEN, emptySet()).orEmpty().toMutableSet()
        seen += id
        // Trimmed so the set cannot grow without bound on a long-lived install.
        val kept = seen.toList().takeLast(200).toSet()
        prefs.edit().putStringSet(KEY_SEEN, kept).apply()
    }

    private fun seenIds(context: Context): Set<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_SEEN, emptySet()).orEmpty()

    private fun parse(text: String): List<ExamNewsItem> = runCatching {
        val arr = JSONArray(text)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ExamNewsItem(
                id = o.optString("id"),
                title = o.optString("title"),
                body = o.optString("body"),
                exam = o.optString("exam"),
                region = o.optString("region", "All India"),
                date = o.optString("date"),
                url = o.optString("url"),
                alert = o.optBoolean("alert", false),
            )
        }.filter { it.id.isNotBlank() && it.title.isNotBlank() }
    }.getOrDefault(emptyList())
}
