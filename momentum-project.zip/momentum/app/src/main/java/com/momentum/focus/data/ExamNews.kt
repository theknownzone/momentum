package com.momentum.focus.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

/**
 * Exam notifications from across India, pulled from the repo.
 *
 * One item is one announcement: a form date, an admit card, a result, a
 * postponement. The bundled copy in assets is what a fresh install reads, and
 * the remote copy is what keeps it current — same arrangement the cards and
 * the exam catalogue already use, so publishing an alert is editing one JSON
 * file rather than shipping a build.
 *
 * The app never invents an item. Everything shown here is something written
 * into that file with a source, because a wrong date on an exam alert is worse
 * than no alert at all.
 */
data class ExamNewsItem(
    val id: String,
    val title: String,
    val body: String,
    val exam: String,
    val region: String,
    val date: String,
    val url: String,
) {
    /** True when this item is about the exam the user is actually preparing for. */
    fun matches(examName: String?, stateName: String?): Boolean {
        if (region.equals("All India", true)) return true
        val e = examName?.lowercase().orEmpty()
        val s = stateName?.lowercase().orEmpty()
        return (e.isNotBlank() && exam.lowercase().let { it in e || e in it }) ||
            (s.isNotBlank() && region.lowercase().contains(s))
    }
}

object ExamNews {

    private const val REMOTE =
        "https://raw.githubusercontent.com/theknownzone/momentum/main/exam-news.json"

    private const val PREFS = "exam_news"
    private const val KEY_SEEN = "seen_ids"

    @Volatile
    private var cached: List<ExamNewsItem> = emptyList()

    fun bundled(context: Context): List<ExamNewsItem> {
        if (cached.isNotEmpty()) return cached
        val text = runCatching {
            context.assets.open("exam-news.json").bufferedReader().use { it.readText() }
        }.getOrDefault("[]")
        cached = parse(text)
        return cached
    }

    /**
     * Bundled list, replaced by the remote one when it is reachable.
     *
     * A failed fetch is not an error state here — it returns what is already
     * on the device. The app is used with the network off constantly.
     */
    suspend fun refresh(context: Context): List<ExamNewsItem> = withContext(Dispatchers.IO) {
        val local = bundled(context)
        val remote = runCatching {
            val conn = (URL(REMOTE).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
            }
            if (conn.responseCode != 200) return@runCatching null
            parse(conn.inputStream.bufferedReader().use { it.readText() })
        }.getOrNull()
        if (!remote.isNullOrEmpty()) {
            cached = remote
            remote
        } else local
    }

    /**
     * The newest unseen item that is relevant to this user, or null.
     *
     * Relevance is checked before novelty so a UPSC alert never interrupts
     * someone studying for NEET. Everything marked All India is relevant to
     * everyone.
     */
    fun nextUnseen(
        context: Context,
        items: List<ExamNewsItem>,
        examName: String?,
        stateName: String?,
    ): ExamNewsItem? {
        val seen = seenIds(context)
        return items
            .filter { it.id !in seen && it.matches(examName, stateName) }
            .maxByOrNull { it.date }
    }

    fun relevant(
        items: List<ExamNewsItem>,
        examName: String?,
        stateName: String?,
    ): List<ExamNewsItem> =
        items.filter { it.matches(examName, stateName) }.sortedByDescending { it.date }

    fun markSeen(context: Context, id: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val seen = prefs.getStringSet(KEY_SEEN, emptySet()).orEmpty().toMutableSet()
        seen += id
        // Trimmed so the set cannot grow without bound on a long-lived install.
        val kept = seen.toList().takeLast(200).toSet()
        prefs.edit().putStringSet(KEY_SEEN, kept).apply()
    }

    private fun seenIds(context: Context): Set<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_SEEN, emptySet()).orEmpty()

    private fun parse(text: String): List<ExamNewsItem> = runCatching {
        val arr = JSONArray(text)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ExamNewsItem(
                id = o.optString("id"),
                title = o.optString("title"),
                body = o.optString("body"),
                exam = o.optString("exam"),
                region = o.optString("region", "All India"),
                date = o.optString("date"),
                url = o.optString("url"),
            )
        }.filter { it.id.isNotBlank() && it.title.isNotBlank() }
    }.getOrDefault(emptyList())
}
