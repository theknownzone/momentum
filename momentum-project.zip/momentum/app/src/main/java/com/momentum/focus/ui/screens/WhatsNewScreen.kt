package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*

/**
 * Shown once after an update lands, then never again for that version.
 *
 * Written per release rather than generated, because "bug fixes and
 * improvements" tells nobody anything and is the reason people stop reading
 * changelogs at all.
 */
object Changelog {

    /**
     * Keyed by the build number in the version string, newest first.
     *
     * The old version was a single hardcoded list, so every update proudly
     * announced the same three things regardless of what had actually
     * changed. Anything without an entry falls back to the newest one rather
     * than showing nothing.
     */
    private val byBuild: Map<Int, List<Pair<String, List<String>>>> = mapOf(
        23 to listOf(
            "New" to listOf(
                "Exam countdown, with Crown mode switching itself on near the date",
                "A two-tap question after you spend minutes, so the app learns your triggers",
                "Shareable progress poster and invite link",
                "Level ups and badges now get a full celebration",
                "Easier weekends: half the earn rate on Sat and Sun",
            ),
            "Fixed" to listOf(
                "No more welcome screen flashing on launch",
                "Gap above the dashboard removed",
                "Update notes now match the version you installed",
            ),
        ),
        22 to listOf(
            "New" to listOf(
                "Swipeable card deck with study techniques",
                "3D avatars — rendered faces and drawn shapes",
                "Achievements now have Bronze to Crown tiers",
            ),
            "Fixed" to listOf(
                "Shield notification icon was a grey square",
                "Sounds rebuilt with real body instead of thin beeps",
            ),
        ),
    )

    fun forVersion(version: String): List<Pair<String, List<String>>> {
        val build = version.substringAfterLast('.').toIntOrNull()
        return byBuild[build]
            ?: byBuild.entries.maxByOrNull { it.key }?.value
            ?: emptyList()
    }
}

@Composable
fun WhatsNewScreen(version: String, onDone: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 40.dp, bottom = 24.dp),
    ) {
        Text(
            "JUST UPDATED",
            style = MaterialTheme.typography.labelSmall,
            color = Mint.accent,
        )
        Text(
            "What's new",
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            "Version $version",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(20.dp))

        Changelog.forVersion(version).forEachIndexed { i, (heading, lines) ->
            val sticker = stickerFor(i)
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = Paper.Gap)
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .background(sticker.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                    .padding(16.dp)
            ) {
                Text(
                    heading.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = sticker.on.copy(alpha = 0.75f),
                )
                Spacer(Modifier.height(8.dp))
                lines.forEach { line ->
                    Row(Modifier.padding(vertical = 3.dp)) {
                        Text(
                            "—",
                            style = MaterialTheme.typography.bodyLarge,
                            color = sticker.on.copy(alpha = 0.6f),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            line,
                            style = MaterialTheme.typography.bodyLarge,
                            color = sticker.on,
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        SquishButton(
            label = "Got it",
            sticker = Mint,
            modifier = Modifier.fillMaxWidth(),
            onClick = onDone,
        )
    }
}
