package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.theme.*

/**
 * Shown once after an update lands, then never again for that version.
 *
 * Written per release rather than generated, because "bug fixes and
 * improvements" tells nobody anything and is the reason people stop reading
 * changelogs at all.
 */
object Changelog {

    /**
     * Bumped by hand whenever there is something worth announcing.
     *
     * Keying this off the build number never worked: builds are numbered by CI
     * at push time, so the code could not know its own number and every
     * update fell back to the same stale entry. A counter the source controls
     * is the only version of this that can be correct.
     */
    /**
     * Bump this whenever the bundled list below changes, so the screen shows
     * again. Live release notes are preferred; this is the offline fallback.
     */
    const val LATEST = 8

    val entries: List<Pair<String, List<String>>> = listOf(
        "New" to listOf(
            "Shorts aur Reels ab sach mein rukte hain — app khuli rehti hai, feed band",
            "Blocked app PiP mein bhaag nahi sakti",
            "Profiles — alag din ke alag rules, ek tap mein switch",
            "Stats mein \"Kab kya khola\" timeline",
            "Home ke cards ab tumhare apne numbers dikhate hain",
            "Class hours ab din chun sakte ho",
        ),
        "Fixed" to listOf(
            "Phone, Contacts, Settings ab kabhi block nahi honge",
            "Permission hataoge toh app khulegi hi nahi",
            "What's New ab har build ke asli notes dikhata hai, purane nahi",
        ),
    )
}

/**
 * Turns a markdown release body into headed lists.
 *
 * A heading is any `##` line or a bare short line ending in a colon; anything
 * starting with a dash or bullet is an item. Text that fits neither is dropped
 * rather than guessed at — a release note with no structure should fall back
 * to the bundled list, not render as one long unreadable block.
 */
private fun parseNotes(body: String): List<Pair<String, List<String>>>? {
    val out = mutableListOf<Pair<String, MutableList<String>>>()
    body.lines().forEach { raw ->
        val line = raw.trim()
        when {
            line.isBlank() -> Unit
            line.startsWith("#") ->
                out += line.trimStart('#', ' ').trim() to mutableListOf()
            line.startsWith("-") || line.startsWith("*") || line.startsWith("•") -> {
                if (out.isEmpty()) out += "UPDATE" to mutableListOf()
                out.last().second += line.trimStart('-', '*', '•', ' ').trim()
            }
            line.endsWith(":") && line.length < 40 ->
                out += line.dropLast(1).trim() to mutableListOf()
            else -> Unit
        }
    }
    val clean = out.filter { it.second.isNotEmpty() }.map { it.first to it.second.toList() }
    return clean.ifEmpty { null }
}

@Composable
fun WhatsNewScreen(version: String, onDone: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 40.dp, bottom = 24.dp),
    ) {
        Text(
            "JUST UPDATED",
            style = MaterialTheme.typography.labelSmall,
            color = Mint.accent,
        )
        Text(
            "What's new",
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            "Version $version",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(20.dp))

        // Live notes from the release itself. The bundled list below is only
        // the offline fallback now — it is what went stale for several builds
        // in a row while every update claimed the same fixes.
        val liveNotes by produceState<List<Pair<String, List<String>>>?>(initialValue = null) {
            value = runCatching { Updater.latestNotes() }.getOrNull()?.let { parseNotes(it) }
        }

        val sections = liveNotes ?: Changelog.entries

        sections.forEachIndexed { i, (heading, lines) ->
            val sticker = stickerFor(i)
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = Paper.Gap)
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .background(sticker.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                    .padding(16.dp)
            ) {
                Text(
                    heading.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = sticker.on.copy(alpha = 0.75f),
                )
                Spacer(Modifier.height(8.dp))
                lines.forEach { line ->
                    Row(Modifier.padding(vertical = 3.dp)) {
                        Text(
                            "—",
                            style = MaterialTheme.typography.bodyLarge,
                            color = sticker.on.copy(alpha = 0.6f),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            line,
                            style = MaterialTheme.typography.bodyLarge,
                            color = sticker.on,
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        SquishButton(
            label = "Got it",
            sticker = Mint,
            modifier = Modifier.fillMaxWidth(),
            onClick = onDone,
        )
    }
}
