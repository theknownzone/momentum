package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*

/**
 * Shown once after an update lands, then never again for that version.
 *
 * Written per release rather than generated, because "bug fixes and
 * improvements" tells nobody anything and is the reason people stop reading
 * changelogs at all.
 */
object Changelog {

    /**
     * Bumped by hand whenever there is something worth announcing.
     *
     * Keying this off the build number never worked: builds are numbered by CI
     * at push time, so the code could not know its own number and every
     * update fell back to the same stale entry. A counter the source controls
     * is the only version of this that can be correct.
     */
    const val LATEST = 4

    val entries: List<Pair<String, List<String>>> = listOf(
        "New" to listOf(
            "A Wallet tab: balance, exchange rate and every transaction",
            "Everything is priced in rupees now, not minutes",
            "Subject breakdown, so you can see what you have been avoiding",
            "The tray notification shows what you have earned, not just that blocking is on",
        ),
        "Fixed" to listOf(
            "These notes finally match the version you installed",
            "Badges stopped showing your own face as a trophy",
            "Welcome screen no longer flashes on launch",
        ),
    )
}

@Composable
fun WhatsNewScreen(version: String, onDone: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 40.dp, bottom = 24.dp),
    ) {
        Text(
            "JUST UPDATED",
            style = MaterialTheme.typography.labelSmall,
            color = Mint.accent,
        )
        Text(
            "What's new",
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            "Version $version",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(20.dp))

        Changelog.entries.forEachIndexed { i, (heading, lines) ->
            val sticker = stickerFor(i)
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = Paper.Gap)
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .background(sticker.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                    .padding(16.dp)
            ) {
                Text(
                    heading.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = sticker.on.copy(alpha = 0.75f),
                )
                Spacer(Modifier.height(8.dp))
                lines.forEach { line ->
                    Row(Modifier.padding(vertical = 3.dp)) {
                        Text(
                            "—",
                            style = MaterialTheme.typography.bodyLarge,
                            color = sticker.on.copy(alpha = 0.6f),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            line,
                            style = MaterialTheme.typography.bodyLarge,
                            color = sticker.on,
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        SquishButton(
            label = "Got it",
            sticker = Mint,
            modifier = Modifier.fillMaxWidth(),
            onClick = onDone,
        )
    }
}
