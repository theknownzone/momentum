package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.momentum.focus.R
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.Currency
import com.momentum.focus.data.HolidayCalendar
import com.momentum.focus.data.ScreenTime
import com.momentum.focus.data.FocusSession
import com.momentum.focus.data.unlockedCount
import com.momentum.focus.ui.components.PactBanner
import com.momentum.focus.ui.components.*
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.rememberHaptics
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.roundToInt

/**
 * Two-plane dashboard: a dark hero card holding identity and the balance,
 * sitting on a cream body that carries everything else.
 *
 * The split is doing real work. The dark plane is where the number that
 * matters lives, so the eye goes there first every time the app opens; the
 * cream plane is where you act. One surface for status, one for doing.
 */
@Composable
fun HomeScreen(
    data: AppData,
    onStartFocus: () -> Unit,
    onPanic: () -> Unit,
    onJournal: () -> Unit,
    onProfile: () -> Unit,
    onShield: () -> Unit,
    onRewards: () -> Unit,
) {
    val haptics = rememberHaptics()
    val context = androidx.compose.ui.platform.LocalContext.current
    val phoneToday by produceState(0, context) {
        value = ScreenTime.report(context).dailyMinutes.lastOrNull() ?: 0
    }
    var holidays by remember { mutableStateOf(HolidayCalendar.bundled(context)) }
    LaunchedEffect(Unit) {
        holidays = HolidayCalendar.refresh(context)
        if (HolidayCalendar.inSeason(holidays) != null) haptics.festive()
    }
    val season = remember(holidays) { HolidayCalendar.inSeason(holidays) }
    val nextHoliday = remember(holidays) { HolidayCalendar.upcoming(holidays) }
    val liveSkin = season?.skin ?: skinFor(data.skin)

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .verticalScroll(rememberScrollState()),
    ) {
        Hero(data, liveSkin, season?.skin, phoneToday, onProfile, onStartFocus, onShield)

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 18.dp, bottom = 28.dp),
        ) {
            UpdateCard(Modifier.fillMaxWidth())

            nextHoliday?.takeIf { it.daysFrom() in 0L..7L }?.let { h ->
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(Paper.CardRadius))
                        .background(h.skin.accent.copy(alpha = 0.18f))
                        .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.festive()
                        }
                        .padding(16.dp),
                ) {
                    Column {
                        Text(
                            "CALENDAR",
                            style = MaterialTheme.typography.labelSmall,
                            color = h.skin.accent,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            h.headline,
                            style = MaterialTheme.typography.headlineSmall,
                            color = Ink,
                        )
                        Text(
                            if (h.daysFrom() <= 2)
                                "${h.skin.label} theme is live on Home today."
                            else
                                "Theme unlocks the day it arrives.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMid,
                        )
                    }
                }
            }

            if (data.examName.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    data.daysToExam?.let { "${data.examName} · ${it}d left" } ?: data.examName,
                    style = MaterialTheme.typography.titleMedium,
                    color = Ink,
                )
            }

            Spacer(Modifier.height(12.dp))
            PactBanner(data.lockUntilEpochMs, Modifier.fillMaxWidth())

            Spacer(Modifier.height(12.dp))
            InsightDeck(Modifier.fillMaxWidth())

            Spacer(Modifier.height(20.dp))
            Text("QUICK ACTIONS", style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard(
                    icon = Icons.Filled.Bolt,
                    title = "Panic",
                    detail = "or shake the phone",
                    sticker = Tang,
                    modifier = Modifier.weight(1f),
                ) { haptics.press(); onPanic() }
                ActionCard(
                    icon = Icons.Filled.EditNote,
                    title = "Journal",
                    detail = "log today",
                    sticker = Lilac,
                    modifier = Modifier.weight(1f),
                ) { haptics.tap(); onJournal() }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard(
                    icon = Icons.Filled.Shield,
                    title = "Shield",
                    detail = "${data.blockedPackages.size} apps blocked",
                    sticker = Mint,
                    modifier = Modifier.weight(1f),
                ) { haptics.tap(); onShield() }
                ActionCard(
                    icon = Icons.Filled.Timer,
                    title = "Rewards",
                    detail = "${data.unlockedCount} unlocked",
                    sticker = Butter,
                    modifier = Modifier.weight(1f),
                ) { onRewards() }
            }

            Spacer(Modifier.height(24.dp))

            Text(
                "RECENT",
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(10.dp))

            val feed = remember(data) { buildFeed(data) }
            if (feed.isEmpty()) EmptyFeed() else feed.forEach { ActivityRow(it) }

            Spacer(Modifier.height(36.dp))
            Wordmark(skinFor(data.skin))
        }
    }
}

/**
 * The mark at the end of the scroll.
 *
 * Deliberately low contrast and oversized: it is a full stop, not a headline.
 * Reaching it should feel like arriving at the bottom of something made, which
 * is why it carries the version too.
 */
@Composable
private fun Wordmark(skin: Skin) {
    Column(Modifier.fillMaxWidth()) {
        Text(
            "Earned, not claimed",
            style = MaterialTheme.typography.displayMedium.copy(
                fontFamily = FontFamily.Serif,
                letterSpacing = (-1.5).sp,
            ),
            color = InkLow.copy(alpha = 0.55f),
        )
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(InkLow.copy(alpha = 0.4f))
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "momentum",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontFamily = FontFamily.Serif,
            ),
            color = InkLow.copy(alpha = 0.5f),
        )
        Text(
            "${skin.label} theme",
            style = MaterialTheme.typography.bodyMedium,
            color = InkLow.copy(alpha = 0.45f),
        )
    }
}

// ---------------------------------------------------------------- hero

@Composable
private fun Hero(
    data: AppData,
    skin: Skin,
    festSkin: Skin?,
    phoneToday: Int,
    onProfile: () -> Unit,
    onStartFocus: () -> Unit,
    onShield: () -> Unit,
) {
    val haptics = rememberHaptics()
    val low = DeviceProfile.isLowEnd(androidx.compose.ui.platform.LocalContext.current)
    val counted by animateFloatAsState(
        targetValue = data.balanceMinutes.toFloat(),
        animationSpec = Motion.settle(),
        label = "balance",
    )
    val minutes = counted.roundToInt()

    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 26.dp, bottomEnd = 26.dp))
            .background(
                Brush.verticalGradient(listOf(skin.heroTop, skin.heroBottom))
            ),
    ) {
        // Petals live behind the content, clipped to the hero, so the movement
        // is always there without ever competing with the number.
        // Notes drift behind the balance, petals in front of them. Two layers
        // at different opacities give the hero depth without either of them
        // competing with the number.
        if (!low) {
            Image(
                painter = painterResource(
                    // Rakhi has no art of its own yet. The file that was here
                    // was a stock greeting card with "Happy Raksha Bandhan"
                    // baked into it, so cropping it behind the balance pushed
                    // half a word of English across the number.
                    when (festSkin) {
                        Skin.DIWALI -> R.drawable.fest_diwali
                        else -> R.drawable.money_rain
                    }
                ),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = if (festSkin != null) 0.42f else 0.28f,
                modifier = Modifier.matchParentSize(),
            )
            SakuraFall(Modifier.matchParentSize(), tint = skin.petal)
        }

        Column(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 14.dp, bottom = 22.dp),
        ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(data) { haptics.tap(); onProfile() }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                TypedGreeting(
                    name = data.userName,
                    nameColor = CreamCard,
                    labelColor = InkLow,
                )
                Text(
                    "${data.streakDays} day streak",
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkLow,
                )
            }
        }

        Spacer(Modifier.height(18.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Coin3D(color = skin.accent, size = 26.dp)
            Spacer(Modifier.width(8.dp))
            Text(
                "Wallet balance",
                style = MaterialTheme.typography.bodyMedium,
                color = InkLow,
            )
        }
        Spacer(Modifier.height(2.dp))

        // Hours large, minutes small — the same trick a bank uses for rupees
        // and paise, so the eye lands on the meaningful digit first.
        // Whole minutes big, the unit small and quiet — the shape a bank uses
        // for rupees and paise, so the number reads as money to spend rather
        // than a duration to endure.
        Text(
            Currency.format(minutes),
            style = MaterialTheme.typography.displayLarge,
            color = GoldNeon,
        )
        Text(
            "%dh %02dm banked from focus".format(minutes / 60, minutes % 60),
            style = MaterialTheme.typography.bodyMedium,
            color = InkLow,
        )
        Text(
            "%dh %02dm phone today".format(phoneToday / 60, phoneToday % 60),
            style = MaterialTheme.typography.bodyMedium,
            color = InkLow,
        )
        if (data.earnedMinutes == 0) {
            Spacer(Modifier.height(6.dp))
            Text(
                "25 min ${data.subjects.firstOrNull() ?: "Physics"} = first ₹",
                style = MaterialTheme.typography.bodyMedium,
                color = Mint.fill,
            )
        }

        Spacer(Modifier.height(12.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Mint.on)
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "▲ +${Currency.format(data.minutesToday)} earned today",
                style = MaterialTheme.typography.bodyMedium,
                color = Mint.fill,
            )
            Spacer(Modifier.weight(1f))
            Text(
                "${data.sessions.count { it.completed }} sessions",
                style = MaterialTheme.typography.bodyMedium,
                color = Mint.fill,
            )
        }

        data.daysToExam?.let { days ->
            if (days >= 0) {
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Tang.fill.copy(alpha = 0.18f))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "${days}d to ${data.examName.ifBlank { "Boards" }}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Tang.fill,
                        modifier = Modifier.weight(1f),
                    )
                    if (data.examIsClose) {
                        Text(
                            "CROWN WINDOW",
                            style = MaterialTheme.typography.labelSmall,
                            color = Tang.fill,
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HeroButton("Start focus", Mint.fill, Mint.on, Modifier.weight(1f)) {
                onStartFocus()
            }
            HeroButton("Shield", CreamCard, Ink, Modifier.weight(1f)) {
                onShield()
            }
        }
        }
    }
}

@Composable
private fun HeroButton(
    label: String,
    fill: androidx.compose.ui.graphics.Color,
    on: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    Box(
        modifier
            .clip(RoundedCornerShape(13.dp))
            .background(fill)
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                haptics.confirm(); onClick()
            }
            .padding(vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium, color = on)
    }
}

@Composable
private fun Avatar(data: AppData, onClick: () -> Unit) {
    Box(
        Modifier
            .size(52.dp)
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Avatar3D(
            colorIndex = data.avatarColor,
            shapeIndex = data.avatarShape,
            size = 52.dp,
        )
    }
}

// ---------------------------------------------------------------- body

@Composable
private fun ActionCard(
    icon: ImageVector,
    title: String,
    detail: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                haptics.tap(); onClick()
            }
            .padding(14.dp),
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(sticker.fill)
                .border(2.dp, Ink, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = sticker.on, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
        Text(detail, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}

private data class FeedRow(
    val title: String,
    val subtitle: String,
    val amount: String,
    val sticker: Sticker,
    val icon: ImageVector,
)

private fun buildFeed(data: AppData): List<FeedRow> {
    val today = LocalDate.now().toEpochDay()

    fun ago(day: Long) = when (val d = (today - day).toInt()) {
        0 -> "Today"
        1 -> "Yesterday"
        else -> "$d days ago"
    }

    val sessions = data.sessions.takeLast(6).reversed().map { s: FocusSession ->
        FeedRow(
            title = s.subject,
            subtitle = if (s.completed) ago(s.startedAtEpochDay)
                       else "${ago(s.startedAtEpochDay)} · left early",
            amount = "+${Currency.format(s.minutes)}",
            sticker = if (s.completed) Mint else Butter,
            icon = Icons.Filled.Timer,
        )
    }

    val urges = data.urges.takeLast(4).reversed().map { u ->
        FeedRow(
            title = if (u.survived) "Urge beaten" else "Slip logged",
            subtitle = "${ago(u.epochDay)} · around ${u.hour}:00",
            amount = if (u.survived) "held" else "reset",
            sticker = if (u.survived) Sky else Candy,
            icon = Icons.Filled.Shield,
        )
    }

    return (sessions + urges).take(8)
}

@Composable
private fun ActivityRow(row: FeedRow) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(row.sticker.fill)
                .border(2.dp, Ink, RoundedCornerShape(9.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                row.icon,
                contentDescription = null,
                tint = row.sticker.on,
                modifier = Modifier.size(18.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(row.title, style = MaterialTheme.typography.titleMedium, color = Ink)
            Text(row.subtitle, style = MaterialTheme.typography.bodyMedium, color = InkMid)
        }
        Text(row.amount, style = MaterialTheme.typography.titleMedium, color = row.sticker.accent)
    }
}

@Composable
private fun EmptyFeed() {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        NoteStack3D(noteColor = Mint.fill, coinColor = Butter.fill, size = 118.dp)
        Spacer(Modifier.height(10.dp))
        Text("Nothing banked yet", style = MaterialTheme.typography.titleMedium, color = Ink)
        Spacer(Modifier.height(4.dp))
        Text(
            "Finish one focus session and your first minutes land here.",
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun TodaySchedule(data: AppData, onStartFocus: () -> Unit) {
    val hour = LocalTime.now().hour
    val subs = data.subjects.ifEmpty { listOf("Physics", "Maths", "Chemistry") }
    val slots = listOf(
        Triple("06–10", "Subah", subs.getOrElse(0) { "Physics" } to 25),
        Triple("10–16", "Dopahar", subs.getOrElse(1) { "Maths" } to 50),
        Triple("16–22", "Shaam", subs.getOrElse(2) { subs[0] } to 25),
    )
    val active = when (hour) {
        in 6..9 -> 0
        in 10..15 -> 1
        in 16..21 -> 2
        else -> -1
    }
    Column(Modifier.fillMaxWidth()) {
        Text("AAJ KA PLAN", style = MaterialTheme.typography.labelSmall, color = InkMid)
        Text(
            "Subjects se auto. Tap = Focus.",
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
        )
        Spacer(Modifier.height(8.dp))
        slots.forEachIndexed { i, (when_, label, pair) ->
            val (subject, mins) = pair
            val on = i == active
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (on) Mint.fill else CreamCard)
                    .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) { onStartFocus() }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(when_, style = MaterialTheme.typography.labelSmall, color = if (on) Mint.on else InkMid)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(label, style = MaterialTheme.typography.titleMedium, color = if (on) Mint.on else Ink)
                    Text("$subject · ${mins}m", style = MaterialTheme.typography.bodyMedium, color = if (on) Mint.on else InkMid)
                }
                if (on) Text("NOW", style = MaterialTheme.typography.labelSmall, color = Mint.on)
            }
        }
    }
}
