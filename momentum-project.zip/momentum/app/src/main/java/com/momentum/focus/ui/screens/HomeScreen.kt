package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.FocusSession
import com.momentum.focus.data.unlockedCount
import com.momentum.focus.ui.components.*
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import java.time.LocalDate
import kotlin.math.roundToInt

/**
 * Two-plane dashboard: a dark hero card holding identity and the balance,
 * sitting on a cream body that carries everything else.
 *
 * The split is doing real work. The dark plane is where the number that
 * matters lives, so the eye goes there first every time the app opens; the
 * cream plane is where you act. One surface for status, one for doing.
 */
@Composable
fun HomeScreen(
    data: AppData,
    onStartFocus: () -> Unit,
    onPanic: () -> Unit,
    onJournal: () -> Unit,
    onProfile: () -> Unit,
    onShield: () -> Unit,
    onRewards: () -> Unit,
) {
    val haptics = rememberHaptics()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .verticalScroll(rememberScrollState()),
    ) {
        Hero(data, onProfile, onStartFocus, onShield)

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 18.dp, bottom = 28.dp),
        ) {
            UpdateCard(Modifier.fillMaxWidth())

            Spacer(Modifier.height(4.dp))

            InsightDeck(Modifier.fillMaxWidth())

            Spacer(Modifier.height(20.dp))

            Text(
                "QUICK ACTIONS",
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard(
                    icon = Icons.Filled.Bolt,
                    title = "Panic",
                    detail = "or shake the phone",
                    sticker = Tang,
                    modifier = Modifier.weight(1f),
                ) { haptics.press(); onPanic() }

                ActionCard(
                    icon = Icons.Filled.EditNote,
                    title = "Journal",
                    detail = "log today",
                    sticker = Lilac,
                    modifier = Modifier.weight(1f),
                ) { onJournal() }
            }

            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard(
                    icon = Icons.Filled.Shield,
                    title = "Shield",
                    detail = "${data.blockedPackages.size} apps blocked",
                    sticker = Mint,
                    modifier = Modifier.weight(1f),
                ) { onShield() }

                ActionCard(
                    icon = Icons.Filled.Timer,
                    title = "Rewards",
                    detail = "${data.unlockedCount} unlocked",
                    sticker = Butter,
                    modifier = Modifier.weight(1f),
                ) { onRewards() }
            }

            Spacer(Modifier.height(24.dp))

            Text(
                "RECENT",
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(10.dp))

            val feed = remember(data) { buildFeed(data) }
            if (feed.isEmpty()) EmptyFeed() else feed.forEach { ActivityRow(it) }
        }
    }
}

// ---------------------------------------------------------------- hero

@Composable
private fun Hero(
    data: AppData,
    onProfile: () -> Unit,
    onStartFocus: () -> Unit,
    onShield: () -> Unit,
) {
    val haptics = rememberHaptics()
    val counted by animateFloatAsState(
        targetValue = data.balanceMinutes.toFloat(),
        animationSpec = Motion.settle(),
        label = "balance",
    )
    val minutes = counted.roundToInt()

    Column(
        Modifier
            .fillMaxWidth()
            .background(Ink, RoundedCornerShape(bottomStart = 26.dp, bottomEnd = 26.dp))
            .statusBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 14.dp, bottom = 22.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(data) { haptics.tap(); onProfile() }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "hi, ${data.userName}",
                    style = MaterialTheme.typography.titleMedium,
                    color = CreamCard,
                )
                Text(
                    "${data.streakDays} day streak",
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkLow,
                )
            }
        }

        Spacer(Modifier.height(18.dp))

        Text(
            "Focus balance",
            style = MaterialTheme.typography.bodyMedium,
            color = InkLow,
        )
        Spacer(Modifier.height(2.dp))

        // Hours large, minutes small — the same trick a bank uses for rupees
        // and paise, so the eye lands on the meaningful digit first.
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                "${minutes / 60}",
                style = MaterialTheme.typography.displayLarge,
                color = CreamCard,
            )
            Text(
                "h",
                style = MaterialTheme.typography.headlineSmall,
                color = InkLow,
                modifier = Modifier.padding(bottom = 12.dp, start = 2.dp, end = 10.dp),
            )
            Text(
                "%02d".format(minutes % 60),
                style = MaterialTheme.typography.displayMedium,
                color = CreamCard,
            )
            Text(
                "m",
                style = MaterialTheme.typography.headlineSmall,
                color = InkLow,
                modifier = Modifier.padding(bottom = 6.dp, start = 2.dp),
            )
        }

        Spacer(Modifier.height(12.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Mint.on)
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "▲ +${data.minutesToday}m today",
                style = MaterialTheme.typography.bodyMedium,
                color = Mint.fill,
            )
            Spacer(Modifier.weight(1f))
            Text(
                "${data.sessions.count { it.completed }} sessions",
                style = MaterialTheme.typography.bodyMedium,
                color = Mint.fill,
            )
        }

        Spacer(Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HeroButton("Start focus", Mint.fill, Mint.on, Modifier.weight(1f)) {
                onStartFocus()
            }
            HeroButton("Shield", CreamCard, Ink, Modifier.weight(1f)) {
                onShield()
            }
        }
    }
}

@Composable
private fun HeroButton(
    label: String,
    fill: androidx.compose.ui.graphics.Color,
    on: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    Box(
        modifier
            .clip(RoundedCornerShape(13.dp))
            .background(fill)
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                haptics.confirm(); onClick()
            }
            .padding(vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium, color = on)
    }
}

@Composable
private fun Avatar(data: AppData, onClick: () -> Unit) {
    Box(
        Modifier
            .size(52.dp)
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Avatar3D(
            colorIndex = data.avatarColor,
            shapeIndex = data.avatarShape,
            size = 52.dp,
        )
    }
}

// ---------------------------------------------------------------- body

@Composable
private fun ActionCard(
    icon: ImageVector,
    title: String,
    detail: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                haptics.tap(); onClick()
            }
            .padding(14.dp),
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(sticker.fill)
                .border(2.dp, Ink, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = sticker.on, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
        Text(detail, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}

private data class FeedRow(
    val title: String,
    val subtitle: String,
    val amount: String,
    val sticker: Sticker,
    val icon: ImageVector,
)

private fun buildFeed(data: AppData): List<FeedRow> {
    val today = LocalDate.now().toEpochDay()

    fun ago(day: Long) = when (val d = (today - day).toInt()) {
        0 -> "Today"
        1 -> "Yesterday"
        else -> "$d days ago"
    }

    val sessions = data.sessions.takeLast(6).reversed().map { s: FocusSession ->
        FeedRow(
            title = s.subject,
            subtitle = if (s.completed) ago(s.startedAtEpochDay)
                       else "${ago(s.startedAtEpochDay)} · left early",
            amount = "+${s.minutes}m",
            sticker = if (s.completed) Mint else Butter,
            icon = Icons.Filled.Timer,
        )
    }

    val urges = data.urges.takeLast(4).reversed().map { u ->
        FeedRow(
            title = if (u.survived) "Urge beaten" else "Slip logged",
            subtitle = "${ago(u.epochDay)} · around ${u.hour}:00",
            amount = if (u.survived) "held" else "reset",
            sticker = if (u.survived) Sky else Candy,
            icon = Icons.Filled.Shield,
        )
    }

    return (sessions + urges).take(8)
}

@Composable
private fun ActivityRow(row: FeedRow) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(row.sticker.fill)
                .border(2.dp, Ink, RoundedCornerShape(9.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                row.icon,
                contentDescription = null,
                tint = row.sticker.on,
                modifier = Modifier.size(18.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(row.title, style = MaterialTheme.typography.titleMedium, color = Ink)
            Text(row.subtitle, style = MaterialTheme.typography.bodyMedium, color = InkMid)
        }
        Text(row.amount, style = MaterialTheme.typography.titleMedium, color = row.sticker.accent)
    }
}

@Composable
private fun EmptyFeed() {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CoinStack(Modifier.size(84.dp, 68.dp))
        Spacer(Modifier.height(12.dp))
        Text("Nothing banked yet", style = MaterialTheme.typography.titleMedium, color = Ink)
        Spacer(Modifier.height(4.dp))
        Text(
            "Finish one focus session and your first minutes land here.",
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
            textAlign = TextAlign.Center,
        )
    }
}
