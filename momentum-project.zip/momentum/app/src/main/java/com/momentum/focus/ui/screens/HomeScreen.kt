package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.FocusSession
import com.momentum.focus.ui.components.*
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.roundToInt

/**
 * Home is laid out like a banking app because the app treats focus time as
 * currency: you earn minutes by studying and spend them on distraction.
 *
 * Order matters — balance first, today's change second, actions third, history
 * last. That hierarchy is what makes a money app feel calm instead of busy.
 */
@Composable
fun HomeScreen(
    data: AppData,
    onStartFocus: () -> Unit,
    onPanic: () -> Unit,
    onJournal: () -> Unit,
    onProfile: () -> Unit,
) {
    val haptics = rememberHaptics()
    val greeting = when (LocalTime.now().hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..21 -> "Good evening"
        else -> "Still up"
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 12.dp, bottom = 28.dp),
    ) {
        UpdateBanner(Modifier.fillMaxWidth())

        // ---- identity row ----
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 12.dp, bottom = 22.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    greeting,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    data.userName,
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
            Avatar(data.userName) { haptics.tap(); onProfile() }
        }

        // ---- the hero number ----
        BalanceHero(data)

        Spacer(Modifier.height(22.dp))

        // ---- quick actions ----
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            QuickAction(Icons.Filled.Timer, "Focus", Ice) { onStartFocus() }
            QuickAction(Icons.Filled.Shield, "Panic", Ember) { haptics.press(); onPanic() }
            QuickAction(Icons.Filled.Bolt, "Streak", Gold) { onProfile() }
            QuickAction(Icons.Filled.EditNote, "Journal", Violet) { onJournal() }
        }

        Spacer(Modifier.height(26.dp))

        Text(
            "ACTIVITY",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))

        val feed = remember(data) { buildFeed(data) }
        if (feed.isEmpty()) {
            EmptyFeed()
        } else {
            feed.forEach { row -> ActivityRow(row) }
        }
    }
}

// ---------------------------------------------------------------- hero

@Composable
private fun BalanceHero(data: AppData) {
    val counted by animateFloatAsState(
        targetValue = data.balanceMinutes.toFloat(),
        animationSpec = Motion.settle(),
        label = "balance",
    )
    val minutes = counted.roundToInt()

    StickerCard(sticker = Emerald, modifier = Modifier.fillMaxWidth()) {
        Text(
            "FOCUS BALANCE",
            style = MaterialTheme.typography.labelSmall,
            color = Emerald.accent,
        )
        Spacer(Modifier.height(10.dp))

        // Hours and minutes at different weights, so the eye lands on the hour
        // first the way it lands on rupees before paise.
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                "${minutes / 60}",
                style = MaterialTheme.typography.displayLarge,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                "h",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 12.dp, start = 2.dp, end = 10.dp),
            )
            Text(
                "%02d".format(minutes % 60),
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                "m",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 6.dp, start = 2.dp),
            )
        }

        Spacer(Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("+${data.minutesToday}m today", Emerald)
            Pill("${data.streakDays} day streak", Gold)
        }
    }
}

@Composable
private fun Pill(text: String, sticker: Sticker) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(sticker.accent.copy(alpha = 0.14f))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text, style = MaterialTheme.typography.bodyMedium, color = sticker.accent)
    }
}

// ---------------------------------------------------------------- pieces

@Composable
private fun Avatar(name: String, onClick: () -> Unit) {
    val initial = name.trim().firstOrNull()?.uppercase() ?: "?"
    Box(
        Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Violet.accent.copy(alpha = 0.18f))
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(initial, style = MaterialTheme.typography.titleMedium, color = Violet.accent)
    }
}

@Composable
private fun QuickAction(
    icon: ImageVector,
    label: String,
    sticker: Sticker,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(62.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(sticker.accent.copy(alpha = 0.13f))
                .clickableNoRipple(interaction) { haptics.tap(); onClick() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = label, tint = sticker.accent)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ---------------------------------------------------------------- feed

private data class FeedRow(
    val title: String,
    val subtitle: String,
    val amount: String,
    val sticker: Sticker,
    val icon: ImageVector,
)

private fun buildFeed(data: AppData): List<FeedRow> {
    val today = LocalDate.now().toEpochDay()

    fun ago(day: Long) = when (val d = (today - day).toInt()) {
        0 -> "Today"
        1 -> "Yesterday"
        else -> "$d days ago"
    }

    val sessions = data.sessions.takeLast(6).reversed().map { s: FocusSession ->
        FeedRow(
            title = s.subject,
            subtitle = if (s.completed) ago(s.startedAtEpochDay)
                       else "${ago(s.startedAtEpochDay)} · left early",
            amount = "+${s.minutes}m",
            sticker = if (s.completed) Emerald else Gold,
            icon = Icons.Filled.Timer,
        )
    }

    val urges = data.urges.takeLast(4).reversed().map { u ->
        FeedRow(
            title = if (u.survived) "Urge beaten" else "Slip logged",
            subtitle = "${ago(u.epochDay)} · around ${u.hour}:00",
            amount = if (u.survived) "held" else "reset",
            sticker = if (u.survived) Ice else Rose,
            icon = Icons.Filled.Shield,
        )
    }

    return (sessions + urges).take(8)
}

@Composable
private fun ActivityRow(row: FeedRow) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(row.sticker.accent.copy(alpha = 0.13f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                row.icon,
                contentDescription = null,
                tint = row.sticker.accent,
                modifier = Modifier.size(20.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                row.title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                row.subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Text(
            row.amount,
            style = MaterialTheme.typography.titleMedium,
            color = row.sticker.accent,
        )
    }
}

@Composable
private fun EmptyFeed() {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "Nothing banked yet",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Finish one focus session and your first minutes land here.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}
