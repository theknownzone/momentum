package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.momentum.focus.R
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.Currency
import com.momentum.focus.data.ExamNews
import com.momentum.focus.data.ExamNewsItem
import com.momentum.focus.data.HolidayCalendar
import com.momentum.focus.data.ScreenTime
import com.momentum.focus.data.FocusSession
import com.momentum.focus.data.unlockedCount
import androidx.compose.foundation.Canvas
import com.momentum.focus.block.Heartbeat
import com.momentum.focus.ui.components.FrostCard
import com.momentum.focus.ui.components.rakhiMotif
import com.momentum.focus.ui.components.PactBanner
import com.momentum.focus.ui.components.*
import com.momentum.focus.ui.i18n.Strings
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.rememberHaptics
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.roundToInt

/**
 * Two-plane dashboard: a dark hero card holding identity and the balance,
 * sitting on a cream body that carries everything else.
 *
 * The split is doing real work. The dark plane is where the number that
 * matters lives, so the eye goes there first every time the app opens; the
 * cream plane is where you act. One surface for status, one for doing.
 */
@Composable
fun HomeScreen(
    data: AppData,
    onStartFocus: () -> Unit,
    onPanic: () -> Unit,
    onJournal: () -> Unit,
    onProfile: () -> Unit,
    onShield: () -> Unit,
    onFeeds: () -> Unit,
    onRewards: () -> Unit,
) {
    val s = strings()
    val haptics = rememberHaptics()
    val context = androidx.compose.ui.platform.LocalContext.current
    val phoneToday by produceState(0, context) {
        value = ScreenTime.report(context).dailyMinutes.lastOrNull() ?: 0
    }
    var holidays by remember { mutableStateOf(HolidayCalendar.bundled(context)) }
    // Exam notices. Bundled copy renders instantly, the remote copy replaces it
    // when the network allows; a failed fetch simply leaves what is on device.
    var news by remember { mutableStateOf(ExamNews.bundled(context)) }
    // No region lookup here any more. The catalogue's region field holds "IN"
    // or "World", never a state, so feeding it to the matcher only ever looked
    // like state filtering — the Rajasthan notices actually reach RPSC and REET
    // candidates through the exam name itself.
    var alert by remember { mutableStateOf<ExamNewsItem?>(null) }
    LaunchedEffect(Unit) {
        news = ExamNews.refresh(context)
        // Interrupts once per announcement, and only for an announcement that
        // is relevant to this profile.
        alert = ExamNews.nextUnseen(context, news, data.examName)
    }
    alert?.let { item ->
        ExamNewsPopup(item) {
            ExamNews.markSeen(context, item.id)
            alert = null
        }
    }
    LaunchedEffect(Unit) {
        holidays = HolidayCalendar.refresh(context)
        if (HolidayCalendar.inSeason(holidays) != null) haptics.festive()
    }
    val season = remember(holidays) { HolidayCalendar.inSeason(holidays) }
    val nextHoliday = remember(holidays) { HolidayCalendar.upcoming(holidays) }
    val liveSkin = season?.skin ?: skinFor(data.skin)

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .verticalScroll(rememberScrollState()),
    ) {
        Hero(data, s, liveSkin, season?.skin, phoneToday, onProfile, onStartFocus, onShield)

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 18.dp, bottom = 28.dp),
        ) {
            UpdateCard(Modifier.fillMaxWidth())

            ExamNews.relevant(news, data.examName).let { relevant ->
                if (relevant.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    ExamNewsCard(relevant, Modifier.fillMaxWidth())
                }
            }

            // Says plainly that the first days are thin rather than dressing
            // three data points up as a trend.
            data.daysCollecting?.takeIf { it < 3 }?.let { days ->
                Spacer(Modifier.height(10.dp))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(CreamCard)
                        .border(Paper.Outline, Ink, RoundedCornerShape(16.dp))
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                ) {
                    Text(
                        s.home.notEnoughData,
                        style = MaterialTheme.typography.labelSmall,
                        color = InkMid,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (days <= 0) s.home.countingFromToday
                        else s.home.countingSince(days),
                        style = MaterialTheme.typography.titleMedium,
                        color = Ink,
                    )
                    Text(
                        s.home.afterThreeDays,
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                    )
                }
            }

            // Only on the day itself. A card counting down for a week sat on
            // Home doing nothing — it is not a task, not a warning, and not
            // something anyone acts on, so it was just a festival taking up the
            // slot the actual state of the app should occupy. Rule 5 already
            // says the skin arrives on the day; the card now matches it.
            nextHoliday?.takeIf { it.daysFrom() == 0L }?.let { h ->
                Spacer(Modifier.height(10.dp))
                // Frosted, as the preview of the iOS-style pass. Works here
                // because the page behind is a known flat cream — see FrostCard.
                FrostCard(
                    tint = h.skin.accent,
                    modifier = Modifier.clickableNoRipple(
                        remember { MutableInteractionSource() }
                    ) { haptics.festive() },
                ) {
                    Column {
                        Text(
                            s.home.calendar,
                            style = MaterialTheme.typography.labelSmall,
                            color = h.skin.accent,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            h.headline,
                            style = MaterialTheme.typography.headlineSmall,
                            color = Ink,
                        )
                        Text(
                            if (h.daysFrom() == 0L)
                                // Was "${h.skin.label} theme ...", which read
                                // "Rakhi theme" under a Ganesh Chaturthi
                                // headline, because several festivals share one
                                // skin. The skin name is not the festival name.
                                s.home.themeLiveToday
                            else
                                s.home.themeArrivesOnDay,
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMid,
                        )
                    }
                }
            }

            if (data.examName.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    data.daysToExam?.let { s.home.examWithDaysLeft(data.examName, it) }
                        ?: data.examName,
                    style = MaterialTheme.typography.titleMedium,
                    color = Ink,
                )
            }

            Spacer(Modifier.height(12.dp))

            // The heartbeat was being written by the service and read by
            // nobody, so an OEM kill stayed invisible — which is the entire
            // problem it existed to surface.
            val deadMins = remember(phoneToday) {
                runCatching { Heartbeat.deadMinutes(context) }.getOrDefault(0)
            }
            if (deadMins > 0) {
                FrostCard(tint = Tang.fill) {
                  Column {
                    Text(
                        s.home.shieldWasKilled,
                        style = MaterialTheme.typography.labelSmall,
                        color = Tang.on,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (deadMins >= 60)
                            s.home.deadForHoursMinutes(deadMins / 60, deadMins % 60)
                        else s.home.deadForMinutes(deadMins),
                        style = MaterialTheme.typography.headlineSmall,
                        color = Tang.on,
                    )
                    Text(
                        s.home.shieldKilledBody,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Tang.on,
                    )
                  }
                }
                Spacer(Modifier.height(12.dp))
            }

            PactBanner(data.lockUntilEpochMs, Modifier.fillMaxWidth())

            Spacer(Modifier.height(12.dp))
            InsightDeck(Modifier.fillMaxWidth())

            Spacer(Modifier.height(20.dp))
            Text(s.home.quickActions, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard(
                    icon = Icons.Filled.Bolt,
                    title = s.home.panic,
                    detail = s.home.panicDetail,
                    sticker = Tang,
                    modifier = Modifier.weight(1f),
                ) { haptics.press(); onPanic() }
                ActionCard(
                    icon = Icons.Filled.EditNote,
                    title = s.home.journal,
                    detail = s.home.journalDetail,
                    sticker = Lilac,
                    modifier = Modifier.weight(1f),
                ) { haptics.tap(); onJournal() }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard(
                    icon = Icons.Filled.Shield,
                    title = s.home.shield,
                    detail = s.home.shieldDetail(data.blockedPackages.size),
                    sticker = Mint,
                    modifier = Modifier.weight(1f),
                ) { haptics.tap(); onShield() }
                ActionCard(
                    icon = Icons.Filled.Timer,
                    title = s.home.rewards,
                    detail = s.home.rewardsDetail(data.unlockedCount),
                    sticker = Butter,
                    modifier = Modifier.weight(1f),
                ) { onRewards() }
            }
            Spacer(Modifier.height(10.dp))
            // Full width rather than half with a hole beside it. Five cards do
            // not divide into pairs, and the odd one left a gap that read as a
            // card that had failed to load. This is also the app's main
            // feature, so the wider slot is the right one for it.
            ActionCard(
                icon = Icons.Filled.Shield,
                title = s.home.feeds,
                detail = if (data.blockedSurfaces.isEmpty()) s.home.feedsAllOn
                else s.home.feedsBlocked(data.blockedSurfaces.size),
                sticker = Tang,
                modifier = Modifier.fillMaxWidth(),
            ) { haptics.tap(); onFeeds() }

            Spacer(Modifier.height(24.dp))

            Text(
                s.home.recent,
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(10.dp))

            val feed = remember(data, s) { buildFeed(data, s) }
            if (feed.isEmpty()) EmptyFeed(s) else feed.forEach { ActivityRow(it) }

            Spacer(Modifier.height(36.dp))
            Wordmark(skinFor(data.skin), s)
        }
    }
}

/**
 * The mark at the end of the scroll.
 *
 * Deliberately low contrast and oversized: it is a full stop, not a headline.
 * Reaching it should feel like arriving at the bottom of something made, which
 * is why it carries the version too.
 */
@Composable
private fun Wordmark(skin: Skin, s: Strings) {
    Column(Modifier.fillMaxWidth()) {
        Text(
            s.home.wordmarkTagline,
            style = MaterialTheme.typography.displayMedium.copy(
                fontFamily = FontFamily.Serif,
                letterSpacing = (-1.5).sp,
            ),
            color = InkLow.copy(alpha = 0.55f),
        )
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(InkLow.copy(alpha = 0.4f))
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "momentum",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontFamily = FontFamily.Serif,
            ),
            color = InkLow.copy(alpha = 0.5f),
        )
        Text(
            s.home.skinTheme(skin.label),
            style = MaterialTheme.typography.bodyMedium,
            color = InkLow.copy(alpha = 0.45f),
        )
    }
}

// ---------------------------------------------------------------- hero

@Composable
private fun Hero(
    data: AppData,
    s: Strings,
    skin: Skin,
    festSkin: Skin?,
    phoneToday: Int,
    onProfile: () -> Unit,
    onStartFocus: () -> Unit,
    onShield: () -> Unit,
) {
    val haptics = rememberHaptics()
    val low = DeviceProfile.isLowEnd(androidx.compose.ui.platform.LocalContext.current)
    val counted by animateFloatAsState(
        targetValue = data.balanceMinutes.toFloat(),
        animationSpec = Motion.settle(),
        label = "balance",
    )
    val minutes = counted.roundToInt()

    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 26.dp, bottomEnd = 26.dp))
            .background(
                Brush.verticalGradient(listOf(skin.heroTop, skin.heroBottom))
            ),
    ) {
        // Petals live behind the content, clipped to the hero, so the movement
        // is always there without ever competing with the number.
        // Notes drift behind the balance, petals in front of them. Two layers
        // at different opacities give the hero depth without either of them
        // competing with the number.
        if (!low) {
            // The alpha bump exists to let dedicated festival art read through
            // the hero. Rakhi has no art of its own, so bumping it only made
            // money_rain look washed out over the dark band — a skin with no
            // art gets the ordinary treatment.
            val festArt = when (festSkin) {
                Skin.DIWALI -> R.drawable.fest_diwali
                else -> null
            }
            // Rakhi has no artwork file — it is drawn, so there is nothing to
            // source, nothing to watermark and no baked-in English to collide
            // with the balance.
            if (festSkin == Skin.RAKHI) {
                Canvas(Modifier.matchParentSize()) {
                    rakhiMotif(
                        cx = size.width * 0.80f,
                        cy = size.height * 0.30f,
                        radius = size.minDimension * 0.10f,
                        thread = skin.petal.copy(alpha = 0.55f),
                        petal = skin.petal.copy(alpha = 0.40f),
                        centre = skin.heroTop.copy(alpha = 0.85f),
                        outline = skin.petal.copy(alpha = 0.30f),
                    )
                }
            }
            // Janmashtami is drawn too, for the same reason as Rakhi. The
            // radius is smaller than the rakhi's because the aarti arcs swing
            // out to nearly two and a half times it, and at 0.10 they ran off
            // the top of the band.
            if (festSkin == Skin.JANMASHTAMI) {
                Canvas(Modifier.matchParentSize()) {
                    aartiMotif(
                        cx = size.width * 0.80f,
                        cy = size.height * 0.34f,
                        radius = size.minDimension * 0.075f,
                        glow = skin.accent.copy(alpha = 0.55f),
                        flame = skin.accent.copy(alpha = 0.85f),
                        lamp = skin.petal.copy(alpha = 0.55f),
                        outline = skin.petal.copy(alpha = 0.30f),
                    )
                }
            }
            Image(
                painter = painterResource(festArt ?: R.drawable.money_rain),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = if (festArt != null) 0.42f else 0.28f,
                modifier = Modifier.matchParentSize(),
            )
            SakuraFall(Modifier.matchParentSize(), tint = skin.petal)
        }

        Column(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 14.dp, bottom = 22.dp),
        ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(data) { haptics.tap(); onProfile() }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                TypedGreeting(
                    name = data.userName,
                    nameColor = CreamCard,
                    labelColor = InkLow,
                )
                Text(
                    s.home.dayStreak(data.streakDays),
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkLow,
                )
            }
        }

        Spacer(Modifier.height(18.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Coin3D(color = skin.accent, size = 26.dp)
            Spacer(Modifier.width(8.dp))
            Text(
                s.home.walletBalance,
                style = MaterialTheme.typography.bodyMedium,
                color = InkLow,
            )
        }
        Spacer(Modifier.height(2.dp))

        // Hours large, minutes small — the same trick a bank uses for rupees
        // and paise, so the eye lands on the meaningful digit first.
        // Whole minutes big, the unit small and quiet — the shape a bank uses
        // for rupees and paise, so the number reads as money to spend rather
        // than a duration to endure.
        Text(
            Currency.format(minutes),
            style = MaterialTheme.typography.displayLarge,
            color = GoldNeon,
        )
        Text(
            s.home.bankedFromFocus(minutes / 60, minutes % 60),
            style = MaterialTheme.typography.bodyMedium,
            color = InkLow,
        )
        Text(
            s.home.phoneToday(phoneToday / 60, phoneToday % 60),
            style = MaterialTheme.typography.bodyMedium,
            color = InkLow,
        )
        if (data.earnedMinutes == 0) {
            Spacer(Modifier.height(6.dp))
            Text(
                s.home.firstRupeeHint(data.subjects.firstOrNull() ?: "Physics"),
                style = MaterialTheme.typography.bodyMedium,
                color = Mint.fill,
            )
        }

        Spacer(Modifier.height(12.dp))

        // Glass rather than a solid fill: the money_rain art and the petals
        // run behind this strip, and a flat Mint.on block cut a hole in them.
        GlassBar(Modifier.fillMaxWidth(), tint = skin.accent) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    s.home.earnedToday(Currency.format(data.minutesToday)),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mint.fill,
                )
                Spacer(Modifier.weight(1f))
                Text(
                    s.home.sessionsCount(data.sessions.count { it.completed }),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mint.fill,
                )
            }
        }

        data.daysToExam?.let { days ->
            if (days >= 0) {
                Spacer(Modifier.height(10.dp))
                // Same glass as the earned-today strip above it. This was a
                // flat 18% wash, which let the art through but had none of the
                // lit edge, so two bars sitting on the same artwork a few dp
                // apart were treated two different ways.
                GlassBar(Modifier.fillMaxWidth(), tint = Tang.fill, radius = 10.dp) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        s.home.daysToExam(days, data.examName.ifBlank { s.home.boardsFallback }),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Tang.fill,
                        modifier = Modifier.weight(1f),
                    )
                    if (data.examIsClose) {
                        Text(
                            s.home.crownWindow,
                            style = MaterialTheme.typography.labelSmall,
                            color = Tang.fill,
                        )
                    }
                }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HeroButton(s.home.startFocus, Mint.fill, Mint.on, Modifier.weight(1f)) {
                onStartFocus()
            }
            HeroButton(s.home.shield, CreamCard, Ink, Modifier.weight(1f)) {
                onShield()
            }
        }
        }
    }
}

@Composable
private fun HeroButton(
    label: String,
    fill: androidx.compose.ui.graphics.Color,
    on: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    Box(
        modifier
            .clip(RoundedCornerShape(13.dp))
            .background(fill)
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                haptics.confirm(); onClick()
            }
            .padding(vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium, color = on)
    }
}

@Composable
private fun Avatar(data: AppData, onClick: () -> Unit) {
    Box(
        Modifier
            .size(52.dp)
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Avatar3D(
            colorIndex = data.avatarColor,
            shapeIndex = data.avatarShape,
            size = 52.dp,
        )
    }
}

// ---------------------------------------------------------------- body

@Composable
private fun ActionCard(
    icon: ImageVector,
    title: String,
    detail: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                haptics.tap(); onClick()
            }
            .padding(14.dp),
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(sticker.fill)
                .border(2.dp, Ink, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = sticker.on, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
        Text(detail, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}

private data class FeedRow(
    val title: String,
    val subtitle: String,
    val amount: String,
    val sticker: Sticker,
    val icon: ImageVector,
)

private fun buildFeed(data: AppData, s: Strings): List<FeedRow> {
    val today = LocalDate.now().toEpochDay()

    fun ago(day: Long) = when (val d = (today - day).toInt()) {
        0 -> s.common.today
        1 -> s.common.yesterday
        else -> s.common.daysAgo(d)
    }

    val sessions = data.sessions.takeLast(6).reversed().map { session: FocusSession ->
        FeedRow(
            title = session.subject,
            subtitle = if (session.completed) ago(session.startedAtEpochDay)
                       else s.home.leftEarly(ago(session.startedAtEpochDay)),
            amount = "+${Currency.format(session.minutes)}",
            sticker = if (session.completed) Mint else Butter,
            icon = Icons.Filled.Timer,
        )
    }

    val urges = data.urges.takeLast(4).reversed().map { u ->
        FeedRow(
            title = if (u.survived) s.home.urgeBeaten else s.home.slipLogged,
            subtitle = s.home.urgeWhen(ago(u.epochDay), u.hour),
            amount = if (u.survived) s.home.held else s.home.reset,
            sticker = if (u.survived) Sky else Candy,
            icon = Icons.Filled.Shield,
        )
    }

    return (sessions + urges).take(8)
}

@Composable
private fun ActivityRow(row: FeedRow) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(row.sticker.fill)
                .border(2.dp, Ink, RoundedCornerShape(9.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                row.icon,
                contentDescription = null,
                tint = row.sticker.on,
                modifier = Modifier.size(18.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(row.title, style = MaterialTheme.typography.titleMedium, color = Ink)
            Text(row.subtitle, style = MaterialTheme.typography.bodyMedium, color = InkMid)
        }
        Text(row.amount, style = MaterialTheme.typography.titleMedium, color = row.sticker.accent)
    }
}

@Composable
private fun EmptyFeed(s: Strings) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        NoteStack3D(noteColor = Mint.fill, coinColor = Butter.fill, size = 118.dp)
        Spacer(Modifier.height(10.dp))
        Text(s.home.nothingBankedYet, style = MaterialTheme.typography.titleMedium, color = Ink)
        Spacer(Modifier.height(4.dp))
        Text(
            s.home.emptyFeedBody,
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
            textAlign = TextAlign.Center,
        )
    }
}

