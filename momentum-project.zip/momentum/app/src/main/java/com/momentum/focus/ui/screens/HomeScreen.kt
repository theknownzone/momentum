package com.momentum.focus.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.*
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import java.time.LocalTime

@Composable
fun HomeScreen(
    data: AppData,
    onStartFocus: () -> Unit,
    onPanic: () -> Unit,
) {
    val haptics = rememberHaptics()
    val greeting = when (LocalTime.now().hour) {
        in 5..11 -> "GOOD MORNING"
        in 12..16 -> "GOOD AFTERNOON"
        in 17..21 -> "GOOD EVENING"
        else -> "STILL UP"
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain(seed = 3, density = 2200, alpha = 0.045f)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 28.dp, bottom = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        UpdateBanner(Modifier.fillMaxWidth())

        Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
            Column(Modifier.weight(1f)) {
                Text(
                    greeting,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    data.userName,
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        Reveal(0) {
            StreakRing(
                days = data.streakDays,
                goal = data.streakGoal,
                sticker = Jade,
            )
        }

        Spacer(Modifier.height(4.dp))
        Text(
            if (data.streakDays >= data.streakGoal) "Goal reached. Set a bigger one."
            else "${data.streakGoal - data.streakDays} days to your ${data.streakGoal}-day goal",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(24.dp))

        Reveal(120) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(Paper.Gap),
        ) {
            StatSticker(
                label = "FOCUSED TODAY",
                value = "${data.minutesToday / 60}h ${data.minutesToday % 60}m",
                caption = "${data.sessionsToday} sessions",
                sticker = Marigold,
                modifier = Modifier.weight(1f),
            )
            StatSticker(
                label = "URGES BEATEN",
                value = "${data.urgesSurvived}",
                caption = "best: ${maxOf(data.bestStreak, data.streakDays)}d",
                sticker = Grape,
                modifier = Modifier.weight(1f),
            )
        }
        }

        Spacer(Modifier.height(Paper.Gap))

        Reveal(240) {
        StickerCard(sticker = Cobalt, onClick = onStartFocus, modifier = Modifier.fillMaxWidth()) {
            Text("START FOCUS SESSION", style = MaterialTheme.typography.labelSmall, color = Cobalt.accent)
            Spacer(Modifier.height(6.dp))
            Text(
                data.subjects.firstOrNull() ?: "Deep work",
                style = MaterialTheme.typography.headlineSmall,
                color = Cobalt.on,
            )
            Text(
                "50 min · phone down",
                style = MaterialTheme.typography.bodyMedium,
                color = Cobalt.on.copy(alpha = 0.75f),
            )
        }
        }

        Spacer(Modifier.height(Paper.Gap))

        Reveal(360) {

        // The panic card is deliberately the loudest thing here and always one
        // tap from the home screen. In a craving nobody navigates menus.
        StickerCard(
            sticker = Coral,
            onClick = { haptics.press(); onPanic() },
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("FEELING AN URGE?", style = MaterialTheme.typography.labelSmall, color = Coral.accent)
            Spacer(Modifier.height(6.dp))
            Text("Hold on — tap here", style = MaterialTheme.typography.headlineSmall, color = Coral.on)
        }
        }
    }
}

@Composable
fun StatSticker(
    label: String,
    value: String,
    caption: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
) {
    StickerCard(sticker = sticker, modifier = modifier) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = sticker.accent)
        Spacer(Modifier.height(8.dp))
        Text(value, style = MaterialTheme.typography.displayMedium, color = sticker.accent)
        Text(caption, style = MaterialTheme.typography.bodyMedium, color = sticker.on.copy(alpha = 0.7f))
    }
}

/**
 * Staggered entrance. Each block slides up and fades in a beat after the one
 * above it. The delay is what reads as "authored" rather than "everything
 * appeared at once".
 */
@Composable
private fun Reveal(
    delayMillis: Int,
    content: @Composable () -> Unit,
) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(delayMillis.toLong())
        shown = true
    }
    AnimatedVisibility(
        visible = shown,
        enter = fadeIn(tween(340)) + slideInVertically(tween(420)) { it / 3 },
    ) { content() }
}
