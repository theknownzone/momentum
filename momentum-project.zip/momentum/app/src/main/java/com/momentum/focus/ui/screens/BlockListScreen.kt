package com.momentum.focus.ui.screens

import android.content.Intent
import android.content.pm.ApplicationInfo
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

private data class Launchable(val pkg: String, val label: String)

@Composable
fun BlockListScreen(
    data: AppData,
    onToggle: (String) -> Unit,
    onDone: () -> Unit,
) {
    val context = LocalContext.current
    val haptics = rememberHaptics()

    // Only apps with a launcher icon. Listing every installed package would
    // bury the four apps anyone actually wants to block.
    val apps by produceState(initialValue = emptyList<Launchable>()) {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        value = pm.queryIntentActivities(intent, 0)
            .mapNotNull { it.activityInfo?.applicationInfo }
            .filter { it.packageName != context.packageName }
            .distinctBy { it.packageName }
            .map { info: ApplicationInfo ->
                Launchable(info.packageName, pm.getApplicationLabel(info).toString())
            }
            .sortedBy { it.label.lowercase() }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 20.dp),
    ) {
        Text(
            "SHIELD",
            style = MaterialTheme.typography.labelSmall,
            color = Tang.accent,
        )
        Text(
            "What should it stop?",
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            "${data.blockedPackages.size} selected",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(16.dp))

        LazyColumn(Modifier.weight(1f)) {
            items(apps, key = { it.pkg }) { app ->
                val on = app.pkg in data.blockedPackages
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Tang.fill else CreamCard)
                        .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onToggle(app.pkg)
                        }
                        .padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        app.label,
                        style = MaterialTheme.typography.titleMedium,
                        color = if (on) Tang.on else Ink,
                        modifier = Modifier.weight(1f),
                    )
                    Box(
                        Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(if (on) Ink else CreamCard)
                            .border(2.dp, Ink, CircleShape)
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        SquishButton(
            label = "Done",
            sticker = Mint,
            modifier = Modifier.fillMaxWidth(),
            onClick = onDone,
        )
    }
}
