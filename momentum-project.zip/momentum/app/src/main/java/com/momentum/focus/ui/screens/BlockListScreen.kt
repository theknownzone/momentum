package com.momentum.focus.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppCatalog
import com.momentum.focus.data.AppData
import com.momentum.focus.data.CataloguedApp
import com.momentum.focus.data.Currency
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.momentum.focus.ui.components.Coin3D
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

@Composable
fun BlockListScreen(
    data: AppData,
    onToggle: (String) -> Unit,
    onCap: (String, Int?) -> Unit,
    onDone: () -> Unit,
    preselectTop: Boolean = false,
) {
    val context = LocalContext.current
    val haptics = rememberHaptics()

    // Only apps with a launcher icon. Listing every installed package would
    // bury the four apps anyone actually wants to block.
    // Sorted by how much time each app actually took this week, so the ones
    // that cost the most sit at the top instead of whatever starts with "A".
    val apps by produceState(initialValue = emptyList<CataloguedApp>()) {
        value = withContext(Dispatchers.IO) {
            runCatching { AppCatalog.scan(context) }.getOrDefault(emptyList())
        }
    }

    // The three biggest time sinks are ticked for you. An empty list is the
    // most common way this screen gets skipped, and the apps that hurt most
    // are exactly the ones nobody volunteers to block.
    var preselected by remember { mutableStateOf(false) }
    LaunchedEffect(apps) {
        if (preselectTop && !preselected && apps.isNotEmpty() && data.blockedPackages.isEmpty()) {
            preselected = true
            apps.filter { it.isDistraction }
                .take(3)
                .forEach { onToggle(it.pkg) }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 20.dp),
    ) {
        Text(
            "SHIELD",
            style = MaterialTheme.typography.labelSmall,
            color = Tang.accent,
        )
        Text(
            "Your biggest time sinks",
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            "${data.blockedPackages.size} selected · sorted by time spent",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(16.dp))

        LazyColumn(Modifier.weight(1f)) {
            items(apps, key = { it.pkg }) { app ->
                val on = app.pkg in data.blockedPackages
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Tang.fill else CreamCard)
                        .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onToggle(app.pkg)
                        }
                        .padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            app.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (on) Tang.on else Ink,
                        )
                        Text(
                            buildString {
                                append(app.kind.label)
                                if (app.minutes > 0) {
                                    append(" · ")
                                    append("%dh %02dm this week".format(app.minutes / 60, app.minutes % 60))
                                }
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (on) Tang.on.copy(alpha = 0.75f) else InkMid,
                        )
                    }
                    if (on) {
                        // Showing the price on the row makes the trade explicit
                        // while the user is calm, which is the only time the
                        // number can actually change a decision.
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Coin3D(color = Butter.fill, size = 22.dp)
                            Spacer(Modifier.width(6.dp))
                            Text(
                                Currency.format(10),
                                style = MaterialTheme.typography.titleMedium,
                                color = Tang.on,
                            )
                        }
                    } else {
                        Box(
                            Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(CreamCard)
                                .border(2.dp, Ink, CircleShape)
                        )
                    }
                }
                // The cap only appears once the app is blocked, because a cap
                // on an app that is not blocked would never be enforced. Off
                // by default: this tightens the shield, so it is opt in.
                if (on) {
                    val cap = data.dailyCapMinutes[app.pkg]
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(start = 14.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            if (cap == null) "Daily cap" else "Cap $cap min/day",
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMid,
                        )
                        Spacer(Modifier.width(10.dp))
                        listOf(null, 15, 30, 60).forEach { option ->
                            val picked = cap == option
                            Box(
                                Modifier
                                    .padding(end = 6.dp)
                                    .clip(RoundedCornerShape(11.dp))
                                    .background(if (picked) Cobalt.fill else CreamCard)
                                    .border(2.dp, Ink, RoundedCornerShape(11.dp))
                                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                                        haptics.tick(); onCap(app.pkg, option)
                                    }
                                    .padding(horizontal = 9.dp, vertical = 5.dp),
                            ) {
                                Text(
                                    option?.toString() ?: "Off",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (picked) Cobalt.on else Ink,
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        SquishButton(
            label = "Done",
            sticker = Mint,
            modifier = Modifier.fillMaxWidth(),
            onClick = onDone,
        )
    }
}
