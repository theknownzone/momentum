package com.momentum.focus.ui.screens

import android.content.Intent
import android.content.pm.ApplicationInfo
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.Currency
import com.momentum.focus.data.ScreenTime
import com.momentum.focus.data.StudyApps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.momentum.focus.ui.components.Coin3D
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

private data class Launchable(
    val pkg: String,
    val label: String,
    val minutes: Int,
)

@Composable
fun BlockListScreen(
    data: AppData,
    onToggle: (String) -> Unit,
    onDone: () -> Unit,
    preselectTop: Boolean = false,
) {
    val context = LocalContext.current
    val haptics = rememberHaptics()

    // Only apps with a launcher icon. Listing every installed package would
    // bury the four apps anyone actually wants to block.
    // Sorted by how much time each app actually took this week, so the ones
    // that cost the most sit at the top instead of whatever starts with "A".
    val apps by produceState(initialValue = emptyList<Launchable>()) {
        value = withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val usage = ScreenTime.report(context).topApps.associate { it.pkg to it.minutes }
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(intent, 0)
                .mapNotNull { it.activityInfo?.applicationInfo }
                .filter { it.packageName != context.packageName }
                .distinctBy { it.packageName }
                .map { info: ApplicationInfo ->
                    Launchable(
                        pkg = info.packageName,
                        label = pm.getApplicationLabel(info).toString(),
                        minutes = usage[info.packageName] ?: 0,
                    )
                }
                .sortedWith(
                    compareByDescending<Launchable> { it.minutes }
                        .thenBy { it.label.lowercase() }
                )
        }
    }

    // The three biggest time sinks are ticked for you. An empty list is the
    // most common way this screen gets skipped, and the apps that hurt most
    // are exactly the ones nobody volunteers to block.
    var preselected by remember { mutableStateOf(false) }
    LaunchedEffect(apps) {
        if (preselectTop && !preselected && apps.isNotEmpty() && data.blockedPackages.isEmpty()) {
            preselected = true
            apps.filter { it.minutes > 0 && !StudyApps.looksLikeStudy(it.pkg) }
                .take(3)
                .forEach { onToggle(it.pkg) }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 20.dp),
    ) {
        Text(
            "SHIELD",
            style = MaterialTheme.typography.labelSmall,
            color = Tang.accent,
        )
        Text(
            "Your biggest time sinks",
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            "${data.blockedPackages.size} selected · sorted by time spent",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(16.dp))

        LazyColumn(Modifier.weight(1f)) {
            items(apps, key = { it.pkg }) { app ->
                val on = app.pkg in data.blockedPackages
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Tang.fill else CreamCard)
                        .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onToggle(app.pkg)
                        }
                        .padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            app.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (on) Tang.on else Ink,
                        )
                        if (app.minutes > 0) {
                            Text(
                                "%dh %02dm this week".format(app.minutes / 60, app.minutes % 60),
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (on) Tang.on.copy(alpha = 0.75f) else InkMid,
                            )
                        }
                    }
                    if (on) {
                        // Showing the price on the row makes the trade explicit
                        // while the user is calm, which is the only time the
                        // number can actually change a decision.
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Coin3D(color = Butter.fill, size = 22.dp)
                            Spacer(Modifier.width(6.dp))
                            Text(
                                Currency.format(10),
                                style = MaterialTheme.typography.titleMedium,
                                color = Tang.on,
                            )
                        }
                    } else {
                        Box(
                            Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(CreamCard)
                                .border(2.dp, Ink, CircleShape)
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        SquishButton(
            label = "Done",
            sticker = Mint,
            modifier = Modifier.fillMaxWidth(),
            onClick = onDone,
        )
    }
}
