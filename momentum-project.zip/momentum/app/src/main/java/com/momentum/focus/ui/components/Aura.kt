package com.momentum.focus.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * A slow breathing halo behind something, for premium surfaces only.
 *
 * Built from a radial gradient rather than `Modifier.blur`. Blur is API 31+ and
 * this app ships to API 26, where it silently does nothing — a blurred glow
 * would look expensive on a new phone and simply absent on an old one, which is
 * the worst possible outcome for the one effect meant to signal that someone
 * paid. A radial gradient renders identically everywhere.
 *
 * Used sparingly and only around a paid surface. The rest of the app stays flat
 * cream and hard outlines; if everything glowed, nothing would read as special.
 */
@Composable
fun Aura(
    color: Color,
    modifier: Modifier = Modifier,
    strength: Float = 0.45f,
    content: @Composable BoxScope.() -> Unit,
) {
    // Swells once on arrival, then settles into the slow breath. A halo that
    // is already at its resting size when the screen opens is easy to miss
    // entirely — the entrance is what makes someone look at it, and the breath
    // is what keeps it from becoming wallpaper.
    val entrance = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        entrance.animateTo(1.35f, tween(420))
        entrance.animateTo(1f, tween(620))
    }

    val pulse = rememberInfiniteTransition(label = "aura")
    val breath by pulse.animateFloat(
        initialValue = 0.82f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2600),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "breath",
    )

    Box(modifier, contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .matchParentSize()
                .drawBehind {
                    // Drawn well outside the content bounds so the falloff has
                    // room to fade to nothing instead of ending on a hard edge.
                    val r = maxOf(size.width, size.height) * 0.95f * breath * entrance.value
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                color.copy(alpha = strength * breath * entrance.value),
                                color.copy(alpha = strength * 0.35f * breath * entrance.value),
                                Color.Transparent,
                            ),
                            center = Offset(size.width / 2f, size.height / 2f),
                            radius = r,
                        ),
                        radius = r,
                        center = Offset(size.width / 2f, size.height / 2f),
                    )
                }
        )
        content()
    }
}
