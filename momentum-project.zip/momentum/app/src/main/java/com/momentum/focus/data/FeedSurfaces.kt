package com.momentum.focus.data

/**
 * The short-form feeds hiding inside apps that are otherwise useful.
 *
 * Why this needs view IDs and not window class names: on current builds none
 * of these surfaces is a separate screen. YouTube runs Shorts, the home feed
 * and a three hour lecture inside one activity. Instagram runs Reels, Stories
 * and DMs inside one activity. Matching on the window name therefore gives one
 * of two useless answers — block the whole app, or block nothing.
 *
 * What is different per surface is the view tree. The Shorts pager, the Reels
 * pager and the Stories viewer each have their own resource ids, and those ids
 * are visible to an accessibility service that is allowed to read window
 * content. That is the only way to let a lecture play while Shorts does not.
 *
 * These ids are read off shipping builds and they do drift when the app is
 * updated. Several per surface are listed so one rename does not silently turn
 * the guard off, and [ShortsGuard] falls back to class-name matching when it
 * finds none of them. If a surface stops being caught, the fix is a new id
 * here rather than new logic.
 */
data class FeedSurface(
    val key: String,
    val pkg: String,
    val app: String,
    val label: String,
    val note: String,
    val viewIds: List<String>,
    val classHints: List<String> = emptyList(),
    val onByDefault: Boolean,
)

object FeedSurfaces {

    val all: List<FeedSurface> = listOf(
        FeedSurface(
            key = "ig_explore",
            pkg = "com.instagram.android",
            app = "Instagram",
            label = "Explore",
            note = "Chat aur apni feed chalti rahegi",
            // Explore is the endless-scroll grid behind the search tab. It is
            // a separate surface from Reels: someone can have Reels blocked and
            // still lose an hour here, because the grid autoplays too.
            viewIds = listOf(
                "com.instagram.android:id/explore_grid",
                "com.instagram.android:id/explore_recycler_view",
                "com.instagram.android:id/discovery_recycler_view",
                "com.instagram.android:id/explore_topic_grid",
            ),
            classHints = listOf("explore", "discovery"),
            onByDefault = false,
        ),
        FeedSurface(
            key = "yt_home",
            pkg = "com.google.android.youtube",
            app = "YouTube",
            label = "Home feed",
            note = "Search aur subscriptions chalti rahengi",
            // The recommendation wall. Blocking it leaves search and
            // subscriptions working, so a lecture someone went looking for
            // still opens — they just do not get handed nine more.
            viewIds = listOf(
                "com.google.android.youtube:id/results",
                "com.google.android.youtube:id/browse_fragment_container",
                "com.google.android.youtube:id/home_fragment_container",
            ),
            classHints = listOf("browse", "home"),
            onByDefault = false,
        ),
        FeedSurface(
            key = "snap_stories",
            pkg = "com.snapchat.android",
            app = "Snapchat",
            label = "Stories",
            note = "Chat chalti rahegi",
            viewIds = listOf(
                "com.snapchat.android:id/stories_page",
                "com.snapchat.android:id/df_discover_feed",
                "com.snapchat.android:id/ngs_story_button",
            ),
            classHints = listOf("stories", "discover"),
            onByDefault = false,
        ),
        FeedSurface(
            key = "yt_shorts",
            pkg = "com.google.android.youtube",
            app = "YouTube",
            label = "Shorts",
            note = "Lecture aur normal video chalti rahegi",
            viewIds = listOf(
                "com.google.android.youtube:id/reel_recycler",
                "com.google.android.youtube:id/reel_player_page_container",
                "com.google.android.youtube:id/reel_watch_fragment_root",
                "com.google.android.youtube:id/shorts_container",
            ),
            classHints = listOf("shorts", "reel"),
            onByDefault = true,
        ),
        FeedSurface(
            key = "ytr_shorts",
            pkg = "com.google.android.apps.youtube.music",
            app = "YouTube Music",
            label = "Samples feed",
            note = "Gaane chalte rahenge",
            viewIds = listOf(
                "com.google.android.apps.youtube.music:id/reel_recycler",
            ),
            onByDefault = false,
        ),
        FeedSurface(
            key = "ig_reels",
            pkg = "com.instagram.android",
            app = "Instagram",
            label = "Reels",
            note = "Chat aur profile chalte rahenge",
            viewIds = listOf(
                "com.instagram.android:id/clips_viewer_view_pager",
                "com.instagram.android:id/clips_swipe_refresh_container",
                "com.instagram.android:id/clips_viewer_media_container",
            ),
            classHints = listOf("clipsviewer", "reelsviewer"),
            onByDefault = true,
        ),
        FeedSurface(
            key = "ig_stories",
            pkg = "com.instagram.android",
            app = "Instagram",
            label = "Stories",
            note = "Alag se band karo",
            viewIds = listOf(
                "com.instagram.android:id/reel_viewer_root",
                "com.instagram.android:id/reel_viewer_media_container",
            ),
            onByDefault = false,
        ),
        FeedSurface(
            key = "snap_spotlight",
            pkg = "com.snapchat.android",
            app = "Snapchat",
            label = "Spotlight",
            note = "Chat chalti rahegi",
            viewIds = listOf(
                "com.snapchat.android:id/spotlight_view_pager",
                "com.snapchat.android:id/spotlight_recycler_view",
            ),
            classHints = listOf("spotlight"),
            onByDefault = true,
        ),
        FeedSurface(
            key = "wa_status",
            pkg = "com.whatsapp",
            app = "WhatsApp",
            label = "Status",
            note = "Messages chalte rahenge",
            viewIds = listOf(
                "com.whatsapp:id/status_playback_root",
                "com.whatsapp:id/statusPlaybackFragment",
            ),
            onByDefault = false,
        ),
        FeedSurface(
            key = "fb_reels",
            pkg = "com.facebook.katana",
            app = "Facebook",
            label = "Reels",
            note = "Baaki app chalti rahegi",
            viewIds = listOf(
                "com.facebook.katana:id/reels_viewer_root",
                "com.facebook.katana:id/video_player_reels",
            ),
            classHints = listOf("reels"),
            onByDefault = true,
        ),
    )

    val defaults: Set<String> = all.filter { it.onByDefault }.map { it.key }.toSet()

    fun forPackage(pkg: String): List<FeedSurface> = all.filter { it.pkg == pkg }

    /** Packages the guard has any reason to inspect. Everything else is skipped. */
    val watchedPackages: Set<String> = all.map { it.pkg }.toSet()
}
