package com.momentum.focus.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.focus.data.*
import com.momentum.focus.ui.util.FocusNotice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

data class TimerState(
    val running: Boolean = false,
    val totalSeconds: Int = 50 * 60,
    val remaining: Int = 50 * 60,
    /**
     * Blank until the user picks one.
     *
     * This defaulted to "Physics", which meant an IBPS Clerk candidate who had
     * never touched a subject chip was told "Physics untouched in 30 days" —
     * a reproach about a subject that was not even on their list. The nudge
     * already guards on isNotBlank(); the guard just never fired because the
     * default was a real subject name.
     */
    val subject: String = "",
    val startedAtMs: Long = 0L,
) {
    val progress: Float
        get() = if (totalSeconds == 0) 0f else 1f - (remaining.toFloat() / totalSeconds)
    val label: String
        get() = "%02d:%02d".format(remaining / 60, remaining % 60)
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = AppStore(app)

    /**
     * Null until DataStore has actually emitted.
     *
     * Starting from AppData() meant the app briefly believed onboarding was
     * incomplete, so the welcome screen flashed on every cold start before the
     * real state arrived.
     */
    val data: StateFlow<AppData?> = store.data
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _timer = MutableStateFlow(TimerState())
    val timer: StateFlow<TimerState> = _timer.asStateFlow()

    /** Emits once when a session finishes, so the UI can buzz and confetti. */
    private val _sessionFinished = MutableStateFlow(0)
    val sessionFinished: StateFlow<Int> = _sessionFinished.asStateFlow()

    private var tickJob: Job? = null

    init {
        // A session that was running when the process died is picked back up
        // from the wall clock. Without this, force-stopping the app or having
        // an OEM kill it silently threw away however long someone had studied.
        viewModelScope.launch {
            val d = store.data.first { it != null } ?: return@launch
            val endsAt = d.liveSessionEndsAtMs
            if (endsAt <= 0L) return@launch
            val leftSec = ((endsAt - System.currentTimeMillis()) / 1000L).toInt()
            if (leftSec > 0) {
                _timer.value = TimerState(
                    running = false,
                    totalSeconds = d.liveSessionTotalSec,
                    remaining = leftSec,
                    subject = d.liveSessionSubject.ifBlank { _timer.value.subject },
                    startedAtMs = d.liveSessionStartedAtMs,
                )
                resume()
            } else {
                // It ran out while the app was gone. Settle it rather than
                // discarding minutes that were genuinely spent.
                _timer.value = TimerState(
                    running = false,
                    totalSeconds = d.liveSessionTotalSec,
                    remaining = 0,
                    subject = d.liveSessionSubject.ifBlank { _timer.value.subject },
                    startedAtMs = d.liveSessionStartedAtMs,
                )
                finishSession(completed = true)
            }
        }
    }

    private fun resume() {
        _timer.value = _timer.value.copy(running = true)
        runTicker()
    }

    fun setDuration(minutes: Int) {
        if (_timer.value.running) return
        _timer.value = _timer.value.copy(
            totalSeconds = minutes * 60,
            remaining = minutes * 60,
        )
    }

    fun setSubject(subject: String) {
        _timer.value = _timer.value.copy(subject = subject)
    }

    fun toggleTimer() {
        if (_timer.value.running) pause() else start()
    }

    /**
     * Why the timer will not start, or null if it will.
     *
     * Exists so the Begin button can say something. It used to fail by doing
     * nothing at all — tapping Begin on Light, or with no study app picked, left
     * the screen exactly as it was and the person had no way to tell whether
     * the app was broken or they had missed a step.
     */
    fun startBlocked(): String? {
        val d = data.value ?: return "Ek second, load ho raha hai."
        if (d.studyPackages.isEmpty()) {
            return "Pehle ek study app choose karo, warna minute count nahi honge."
        }
        return null
    }

    private fun start() {
        val ready = data.value ?: return
        // The old gate also refused any session below Lock, so Light — which simply
        // means "no blocking" — could not run a timer at all. A soft session
        // that only counts minutes is still a session, and refusing it silently
        // made the level chip look broken.
        if (ready.studyPackages.isEmpty()) return
        val now = System.currentTimeMillis()
        _timer.value = _timer.value.copy(running = true, startedAtMs = now)
        val t = _timer.value
        // Written down before the ticker starts, so the session survives the
        // process being killed a second later.
        viewModelScope.launch {
            store.update {
                it.copy(
                    liveSessionEndsAtMs = now + t.remaining * 1000L,
                    liveSessionTotalSec = t.totalSeconds,
                    liveSessionStartedAtMs = now,
                    liveSessionSubject = t.subject,
                )
            }
        }
        runTicker()
    }

    private fun runTicker() {
        tickJob?.cancel()
        tickJob = viewModelScope.launch {
            // Refreshed once a minute, not once a second. The system draws the
            // countdown itself from setWhen, so rewriting the notification
            // every tick would burn battery to change nothing on screen.
            var lastNotice = 0L
            while (_timer.value.running && _timer.value.remaining > 0) {
                val t = _timer.value
                val now = System.currentTimeMillis()
                if (now - lastNotice > 60_000L || lastNotice == 0L) {
                    lastNotice = now
                    FocusNotice.show(
                        context = getApplication(),
                        endsAtMs = now + t.remaining * 1000L,
                        subject = t.subject,
                        elapsedMin = (t.totalSeconds - t.remaining) / 60,
                        totalMin = t.totalSeconds / 60,
                    )
                }
                delay(1000)
                _timer.value = _timer.value.copy(remaining = _timer.value.remaining - 1)
            }
            if (_timer.value.remaining <= 0) finishSession(completed = true)
        }
    }

    private fun pause() {
        _timer.value = _timer.value.copy(running = false)
        tickJob?.cancel()
        // A paused session has no countdown to show, and a frozen one would be
        // worse than none — it would keep claiming time was passing.
        FocusNotice.clear(getApplication())
        viewModelScope.launch {
            store.update { it.copy(liveSessionEndsAtMs = 0L) }
        }
    }

    /** Give up early. The partial time is still logged — honesty beats zeroes. */
    fun abandon() {
        pause()
        val elapsed = (_timer.value.totalSeconds - _timer.value.remaining) / 60
        settleSession(elapsed, celebrate = false)
        reset()
    }

    private fun finishSession(completed: Boolean) {
        pause()
        settleSession(_timer.value.totalSeconds / 60, celebrate = completed)
        reset()
    }

    /**
     * Minutes of real study a session must reach before it pays anything.
     *
     * Seventy percent of what was planned, so a fifty minute session cannot be
     * cashed in after two. The rule is sound and it was invisible: the timer
     * counted up, the screen said fifty minutes was worth twelve rupees, and a
     * ten minute session paid zero with nothing anywhere explaining the bar.
     * Exposed so the Focus screen can show it before someone sits down rather
     * than after they have given up.
     */

    private fun settleSession(planned: Int, celebrate: Boolean) {
        if (planned < 1) return
        val start = _timer.value.startedAtMs
        val end = System.currentTimeMillis()
        viewModelScope.launch {
            val snap = data.value
            val study = snap?.studyPackages.orEmpty()
            val blocked = snap?.blockedPackages.orEmpty()
            val (honest, junk) = if (start > 0L) {
                ScreenTime.sessionAudit(getApplication(), start, end, study, blocked)
            } else 0 to 0
            val studyClean = study.filterNot { StudyApps.isForbidden(it) }.toSet()
            // The level gate is gone. Light means "no blocking", not "no
            // earning", and refusing to pay a genuine Light session while the timer counted
            // its minutes up made the app look like it was keeping the money.
            val ok = studyClean.isNotEmpty() &&
                junk <= 0 &&
                honest >= bankBar(planned)
            val credit = if (ok) honest.coerceIn(1, planned) else 0
            logSession(credit, completed = credit > 0)
            // XP is the lecture tracker, not the wallet. It follows the same
            // audited minutes so it can never be farmed separately, but it is
            // credited even on a session that missed the 70% bar — time in a
            // study app is still time in a study app.
            if (honest > 0 && junk <= 0) addStudyXp(honest)
            if (credit > 0 && celebrate) {
                _sessionFinished.value = _sessionFinished.value + 1
            }
        }
    }

    private fun reset() {
        _timer.value = _timer.value.copy(remaining = _timer.value.totalSeconds, running = false)
    }

    private fun logSession(minutes: Int, completed: Boolean) {
        val subject = _timer.value.subject
        viewModelScope.launch {
            store.update { d ->
                d.copy(
                    sessions = d.sessions + FocusSession(
                        startedAtEpochDay = LocalDate.now().toEpochDay(),
                        minutes = minutes,
                        subject = subject.ifBlank { "General" },
                        completed = completed,
                        ratio = d.effectiveRatio.coerceAtLeast(1),
                    )
                )
            }
        }
    }

    // ---- Streak ----------------------------------------------------------

    fun resetStreak() = viewModelScope.launch {
        store.update { d ->
            d.copy(
                bestStreak = maxOf(d.bestStreak, d.streakDays),
                streakStartEpochDay = LocalDate.now().toEpochDay(),
            )
        }
    }

    /** Trade banked focus minutes for distraction time. */

    /**
     * Why removing an app from the blocklist is currently refused, or null.
     *
     * Deciding what to block and then starting the timer are two separate
     * moments, and only the second one should be binding. Before a session the
     * list is meant to be edited freely — that is the whole point of setting it
     * up. Once the clock is running, taking an app off the list is the same
     * move as quitting, so it is refused for as long as the session lasts.
     */
    fun blockEditLock(): String? = when {
        data.value?.pactLive == true -> "Pact live hai. Pact khatam hone tak nahi hata sakte."
        _timer.value.running -> "Session chal raha hai. Timer band karo, phir badlo."
        else -> null
    }

    fun toggleBlocked(pkg: String) = viewModelScope.launch {
        store.update { d ->
            val removing = pkg in d.blockedPackages
            // Adding is always allowed. Only removal is ever locked — a rule
            // can tighten mid-session, it just cannot loosen.
            val locked = d.pactLive || _timer.value.running
            if (locked && removing) d
            else {
                val next = if (removing) d.blockedPackages - pkg else d.blockedPackages + pkg
                // Editing by hand means these are no longer that profile's
                // rules, so the label stops claiming they are.
                d.copy(blockedPackages = next, activeProfileId = "")
            }
        }
    }

    fun setSkin(index: Int) = viewModelScope.launch {
        store.update { it.copy(skin = index) }
    }

    fun setAvatar(shape: Int, color: Int) = viewModelScope.launch {
        store.update { it.copy(avatarShape = shape, avatarColor = color) }
    }

    fun setLang(code: String) = viewModelScope.launch {
        store.update { it.copy(lang = code) }
    }

    fun markVersionSeen(version: String, changelog: Int) = viewModelScope.launch {
        store.update { it.copy(lastSeenVersion = version, lastSeenChangelog = changelog) }
    }

    fun setExam(name: String, epochDay: Long) = viewModelScope.launch {
        store.update { d ->
            // Subjects follow the exam only while they are still the stock
            // pack. Once someone has edited them, they are theirs.
            //
            // This used to overwrite unconditionally, and the day chips call
            // straight through to here — so tapping "90d" to move a deadline
            // silently threw away a hand-written subject list. The pack is a
            // starting point, not a thing that keeps reasserting itself.
            val untouched = d.subjects.isEmpty() ||
                d.subjects == ExamCatalog.packFor(d.examName)
            d.copy(
                examName = name,
                examEpochDay = epochDay,
                subjects = if (untouched) ExamCatalog.packFor(name) else d.subjects,
            )
        }
    }

    fun setWeekendRelaxed(on: Boolean) = viewModelScope.launch {
        store.update { it.copy(weekendRelaxed = on) }
    }

    fun setClassHours(on: Boolean, start: Int = 6, end: Int = 22) = viewModelScope.launch {
        store.update { d ->
            if (d.pactLive && !on) d
            else d.copy(
                classHoursOn = on,
                classStartHour = start.coerceIn(0, 23),
                classEndHour = end.coerceIn(1, 24),
            )
        }
    }

    fun logSlip(reason: String, regretted: Boolean) = viewModelScope.launch {
        store.update {
            it.copy(
                slips = it.slips + Slip(
                    epochDay = java.time.LocalDate.now().toEpochDay(),
                    reason = reason,
                    regretted = regretted,
                ),
                pendingReflectionMinutes = 0,
            )
        }
    }

    fun skipReflection() = viewModelScope.launch {
        store.update { it.copy(pendingReflectionMinutes = 0) }
    }

    /**
     * Checks a key and unlocks if it holds up. Returns false on a bad key.
     *
     * Validation happens here rather than in the screen so there is one place
     * that can grant premium, and so a future move to server-side checking
     * changes this function and nothing else.
     */
    suspend fun redeem(raw: String): Boolean {
        if (!License.isValid(raw)) return false
        store.update {
            it.copy(premium = true, licenseKey = License.normalise(raw))
        }
        return true
    }

    /** Removes the unlock. Used when someone moves their key to another phone. */
    fun clearLicense() = viewModelScope.launch {
        store.update { it.copy(premium = false, licenseKey = "") }
    }

    fun toggleStudyOnly(on: Boolean) = viewModelScope.launch {
        store.update { it.copy(studyOnlyYouTube = on) }
    }

    fun addChannel(name: String) = viewModelScope.launch {
        val clean = name.trim().lowercase()
        if (clean.isBlank()) return@launch
        store.update { it.copy(allowedChannels = it.allowedChannels + clean) }
    }

    fun removeChannel(name: String) = viewModelScope.launch {
        store.update { it.copy(allowedChannels = it.allowedChannels - name) }
    }

    fun markTourSeen() = viewModelScope.launch {
        store.update { it.copy(tourSeen = true) }
    }

    /** Stamps the first launch. Does nothing on every launch after it. */
    fun stampFirstOpen() = viewModelScope.launch {
        store.update {
            if (it.firstOpenEpochDay > 0L) it
            else it.copy(firstOpenEpochDay = java.time.LocalDate.now().toEpochDay())
        }
    }

    fun markCelebrated(level: Int, badges: Int) = viewModelScope.launch {
        store.update { it.copy(lastCelebratedLevel = level, lastCelebratedBadges = badges) }
    }

    /** One badge, by id. Several new badges celebrate one after another. */
    fun markBadgeCelebrated(id: String, badges: Int) = viewModelScope.launch {
        store.update {
            it.copy(
                lastCelebratedBadges = badges,
                celebratedBadgeIds = it.celebratedBadgeIds + id,
            )
        }
    }

    /**
     * Marks every already-earned badge as seen without showing anything.
     *
     * Runs once on an install that predates [AppData.celebratedBadgeIds].
     * Without it the upgrade would replay a celebration for every badge the
     * user earned months ago.
     */
    fun seedCelebratedBadges(ids: Set<String>) = viewModelScope.launch {
        store.update {
            if (it.celebratedBadgeIds.isNotEmpty()) it
            else it.copy(celebratedBadgeIds = ids, lastCelebratedBadges = ids.size)
        }
    }

    fun setCrown(on: Boolean) = viewModelScope.launch {
        store.update { d ->
            if (d.pactLive && !on) d
            else d.copy(crownMode = on, shieldOn = if (on) true else d.shieldOn)
        }
    }

    fun setEarnRatio(ratio: Int) = viewModelScope.launch {
        store.update { it.copy(earnRatio = ratio.coerceIn(1, 20)) }
    }

    fun setSubjects(list: List<String>) = viewModelScope.launch {
        val next = list.map { it.trim() }.filter { it.isNotBlank() }.take(3)
        if (next.isEmpty()) return@launch
        store.update { it.copy(subjects = next) }
    }

    /** 1 soft, 2 shield, 3 hard, 4 crown. */
    fun setFocusLevel(level: Int) = viewModelScope.launch {
        val lv = level.coerceIn(1, 4)
        store.update { d ->
            // A running session locks the level the same way a pact does. You
            // chose the terms before you started; dropping to a softer level
            // halfway through is quitting with the clock still counting, which
            // is exactly the move the session is meant to make hard. Raising it
            // stays open — a rule can always tighten.
            if ((d.pactLive || _timer.value.running) && lv < d.focusLevel) d
            else {
                // A pact is only armed when the user actually climbs to a
                // locking level. Re-selecting the level they are already on
                // used to push the clock back out to a fresh three hours,
                // which turned a stray tap into hours of extra lockout.
                val climbing = lv > d.focusLevel
                val lock = if (lv >= 3 && climbing) {
                    maxOf(d.lockUntilEpochMs, System.currentTimeMillis() + 3 * 60 * 60 * 1000L)
                } else d.lockUntilEpochMs
                d.copy(
                    focusLevel = lv,
                    shieldOn = lv >= 2,
                    blockedPackages = if (lv >= 2 && d.blockedPackages.isEmpty())
                        StudyApps.defaultBlocklist(getApplication()) else d.blockedPackages,
                    // The earn rate is the user's own setting, chosen in
                    // Profile. Overwriting it here meant picking a focus level
                    // silently replaced it — Profile went on showing 8:1 while
                    // Focus charged 12, and neither screen mentioned that the
                    // other had been overruled. Levels control blocking; the
                    // rate stays where it was set.
                    earnRatio = d.earnRatio,
                    // Crown belongs to its own switch in Profile and to the
                    // exam window. Setting it from here made two owners for one
                    // flag: Profile showed it off while the shield said it was
                    // on, and neither was lying about what it could see.
                    // Reaching Crown level still turns it on — it cannot turn
                    // it off, because a pact refuses that anyway.
                    crownMode = d.crownMode || lv >= 4,
                    lockUntilEpochMs = lock,
                )
            }
        }
    }

    /**
     * Only extends an existing pact. It can never start one: with no guard a
     * single tap on "+6h" at Soft created a six hour lock that rule 12 then
     * refused to shorten, so a stray tap cost the user the rest of the day.
     * Arming a pact has to go through setFocusLevel, which is deliberate.
     */
    fun extendPact(hours: Int) = viewModelScope.launch {
        val add = hours.coerceIn(1, MAX_EXTEND_HOURS) * 3600_000L
        store.update { d ->
            if (!d.pactLive) d
            else {
                // Capped in total, not just per tap. Nothing can shorten a
                // pact, so without a ceiling a few taps of the longest option
                // would lock the phone down for months with no way back.
                val ceiling = System.currentTimeMillis() + MAX_PACT_HORIZON_MS
                val end = (d.lockUntilEpochMs + add).coerceAtMost(ceiling)
                d.copy(lockUntilEpochMs = end, shieldOn = true)
            }
        }
    }

    /**
     * Set or clear a daily cap. A cap only ever tightens the shield, so unlike
     * the blocklist it stays editable during a pact in one direction: a live
     * pact refuses to remove or raise one, matching rule 12.
     */
    fun setDailyCap(pkg: String, minutes: Int?) = viewModelScope.launch {
        store.update { d ->
            val existing = d.dailyCapMinutes[pkg]
            val loosening = minutes == null || (existing != null && minutes > existing)
            if (d.pactLive && loosening) d
            else d.copy(
                dailyCapMinutes = if (minutes == null) d.dailyCapMinutes - pkg
                else d.dailyCapMinutes + (pkg to minutes)
            )
        }
    }

    /**
     * Picks up the study apps this phone actually has, once, at setup.
     *
     * Without this the user had to know to go and choose them, and a timer
     * with no study app pays nothing — so the most common first experience was
     * a completed session worth zero rupees and no explanation.
     */
    fun seedStudyApps() = viewModelScope.launch {
        val found = withContext(Dispatchers.IO) {
            runCatching { AppCatalog.installedStudyApps(getApplication()) }
                .getOrDefault(emptyList())
                .map { it.pkg }
        }
        if (found.isEmpty()) return@launch
        store.update { d ->
            if (d.studyPackages.isNotEmpty()) d
            else d.copy(studyPackages = found.filterNot { StudyApps.isForbidden(it) }.toSet())
        }
    }

    /**
     * Turns a single in-app feed on or off.
     *
     * A live pact may tighten but not loosen, same rule as everything else:
     * switching Shorts back on mid-pact is exactly the move the pact exists to
     * refuse.
     */
    fun toggleSurface(key: String) = viewModelScope.launch {
        store.update { d ->
            val on = key in d.blockedSurfaces
            if (d.pactLive && on) d
            else d.copy(
                blockedSurfaces = if (on) d.blockedSurfaces - key
                else d.blockedSurfaces + key,
                surfacesSeeded = true,
            )
        }
    }

    /** Sensible starting set on first run: the endless feeds, not Stories. */
    fun seedSurfaces() = viewModelScope.launch {
        store.update { d ->
            if (d.surfacesSeeded) d
            else d.copy(blockedSurfaces = FeedSurfaces.defaults, surfacesSeeded = true)
        }
    }

    /** Turning off the last day would silently disable the window entirely. */
    fun toggleClassDay(day: Int) = viewModelScope.launch {
        store.update { d ->
            val on = day in d.classDays
            if (on && d.classDays.size == 1) d
            else d.copy(
                classDays = if (on) d.classDays - day else d.classDays + day
            )
        }
    }

    /** Captures the current rules under a name. Overwrites a profile of the same name. */
    fun saveProfile(name: String) = viewModelScope.launch {
        val clean = name.trim().take(24)
        if (clean.isBlank()) return@launch
        store.update { d ->
            val snapshot = BlockProfile(
                id = clean.lowercase().replace(" ", "_"),
                name = clean,
                blockedPackages = d.blockedPackages,
                dailyCapMinutes = d.dailyCapMinutes,
                blockedSurfaces = d.blockedSurfaces,
                classHoursOn = d.classHoursOn,
                classDays = d.classDays,
                classStartHour = d.classStartHour,
                classEndHour = d.classEndHour,
            )
            d.copy(
                profiles = d.profiles.filterNot { it.id == snapshot.id } + snapshot,
                activeProfileId = snapshot.id,
            )
        }
    }

    /**
     * Loads a profile's rules.
     *
     * A live pact refuses this outright rather than merging. Switching to a
     * lighter profile is the simplest possible way around a pact, and a
     * half-applied one — new blocklist, old caps — would be worse than either.
     */
    fun applyProfile(id: String) = viewModelScope.launch {
        store.update { d ->
            if (d.pactLive) d
            else {
                val p = d.profiles.firstOrNull { it.id == id } ?: return@update d
                d.copy(
                    blockedPackages = p.blockedPackages,
                    dailyCapMinutes = p.dailyCapMinutes,
                    blockedSurfaces = p.blockedSurfaces,
                    surfacesSeeded = true,
                    classHoursOn = p.classHoursOn,
                    classDays = p.classDays,
                    classStartHour = p.classStartHour,
                    classEndHour = p.classEndHour,
                    activeProfileId = p.id,
                )
            }
        }
    }

    fun deleteProfile(id: String) = viewModelScope.launch {
        store.update { d ->
            if (d.pactLive) d
            else d.copy(
                profiles = d.profiles.filterNot { it.id == id },
                activeProfileId = if (d.activeProfileId == id) "" else d.activeProfileId,
            )
        }
    }

    fun toggleStudyApp(pkg: String) = viewModelScope.launch {
        if (StudyApps.isForbidden(pkg)) return@launch
        store.update { d ->
            val next = if (pkg in d.studyPackages) d.studyPackages - pkg
                       else d.studyPackages + pkg
            d.copy(studyPackages = next.filterNot { StudyApps.isForbidden(it) }.toSet())
        }
    }

    /** One XP per minute spent inside a study app, PW-style. */
    fun addStudyXp(minutes: Int) = viewModelScope.launch {
        store.update { it.copy(studyXp = it.studyXp + minutes) }
    }

    fun setShield(on: Boolean) = viewModelScope.launch {
        store.update { d ->
            if (d.pactLive && !on) d
            else d.copy(
                shieldOn = on,
                // Arming the shield with nothing in the list is a shield that
                // does nothing, and that is how people conclude the app is
                // broken. Seed the obvious offenders on the first arm only —
                // an empty list after this point is the user's own choice.
                blockedPackages = if (on && d.blockedPackages.isEmpty())
                    StudyApps.defaultBlocklist(getApplication()) else d.blockedPackages,
            )
        }
    }

    /** Saves the guesses and the measured baseline the app is judged against. */
    fun saveBaseline(guessHours: Int, guessPickups: Int, actualMinutes: Int) =
        viewModelScope.launch {
            store.update {
                it.copy(
                    guessHours = guessHours,
                    guessPickups = guessPickups,
                    baselineMinutes = actualMinutes,
                )
            }
        }

    fun completeOnboarding() = viewModelScope.launch {
        store.update { it.copy(onboarded = true) }
    }

    fun setName(name: String) = viewModelScope.launch {
        store.update { it.copy(userName = name.ifBlank { "friend" }) }
    }

    fun setGoal(days: Int) = viewModelScope.launch {
        store.update { it.copy(streakGoal = days.coerceIn(7, 365)) }
    }

    // ---- Urges -----------------------------------------------------------

    fun logUrge(survived: Boolean, note: String = "") = viewModelScope.launch {
        store.update { d ->
            d.copy(
                urges = d.urges + UrgeEvent(
                    epochDay = LocalDate.now().toEpochDay(),
                    hour = nowHour(),
                    survived = survived,
                    note = note,
                )
            )
        }
    }

    // ---- Journal ---------------------------------------------------------

    fun saveJournal(mood: Int, text: String, trigger: String) = viewModelScope.launch {
        val today = LocalDate.now().toEpochDay()
        store.update { d ->
            d.copy(
                journal = d.journal.filterNot { it.epochDay == today } +
                    JournalEntry(today, mood, text, trigger)
            )
        }
    }

    private companion object {
        /**
         * Longest single extension the picker offers — one week.
         *
         * Was 24h back when the only controls were +1h, +3h and +6h. A longer
         * pact is a legitimate thing to want before an exam, but the UI has to
         * confirm anything at this end of the range: it cannot be taken back.
         */
        const val MAX_EXTEND_HOURS = 24 * 7

        /**
         * Furthest into the future any pact may reach, counted from now.
         *
         * Extensions add to an existing end time, so repeated taps compound.
         * Thirty days is already far past any exam this app is used for, and
         * past it the phone would be locked down with no mechanism to undo it.
         */
        const val MAX_PACT_HORIZON_MS = 30L * 24 * 3600_000L
    }
}
