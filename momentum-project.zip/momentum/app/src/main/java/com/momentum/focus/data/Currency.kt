package com.momentum.focus.data

/**
 * Banked minutes are presented as rupees.
 *
 * The unit stays minutes everywhere in the data, because that is what is
 * actually earned and spent. Only the display converts, so nothing can drift.
 * People have decades of instinct about what a rupee is worth and none at all
 * about what a banked minute is worth, and that instinct is the whole point.
 */
object Currency {

    /** One minute of real focus is worth one rupee of scroll. */
    const val RATE = 1

    fun rupees(minutes: Int): Int = minutes * RATE

    /** Formatted with the Indian grouping people actually read: 1,20,450. */
    fun format(minutes: Int): String {
        val n = rupees(minutes)
        if (n < 1000) return "₹$n"

        val s = n.toString()
        val last3 = s.takeLast(3)
        val rest = s.dropLast(3)
        val grouped = rest.reversed().chunked(2).joinToString(",").reversed()
        return "₹$grouped,$last3"
    }

    fun plain(minutes: Int): String = format(minutes).removePrefix("₹")
}
