package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.achievements
import com.momentum.focus.data.unlockedCount
import com.momentum.focus.ui.components.Avatar3D
import com.momentum.focus.ui.components.shapeOnly
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*

@Composable
fun AchievementsScreen(data: AppData) {
    val list = data.achievements()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 20.dp, bottom = 28.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "REWARDS",
                    style = MaterialTheme.typography.labelSmall,
                    color = Butter.accent,
                )
                Text(
                    "${data.unlockedCount} of ${list.size}",
                    style = MaterialTheme.typography.displayMedium,
                    color = Ink,
                )
            }
            CoinStack(Modifier.size(96.dp, 78.dp))
        }

        Spacer(Modifier.height(18.dp))

        list.forEachIndexed { i, a ->
            val sticker = stickerFor(i)
            val fill by animateFloatAsState(a.progress, Motion.settle(), label = a.id)

            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (a.unlocked) sticker.fill else CreamCard)
                    .border(
                        if (a.unlocked) Paper.Outline else 2.dp,
                        Ink,
                        RoundedCornerShape(14.dp),
                    )
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar3D(
                        colorIndex = i,
                        shapeIndex = shapeOnly(a.tier.ordinal),
                        size = 44.dp,
                        modifier = Modifier.padding(end = 12.dp),
                    )
                    Column(Modifier.weight(1f)) {
                        Text(
                            a.tier.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (a.unlocked) sticker.on.copy(alpha = 0.7f) else InkLow,
                        )
                        Text(
                            a.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (a.unlocked) sticker.on else Ink,
                        )
                        Text(
                            if (a.unlocked) a.reward else a.detail,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (a.unlocked) sticker.on.copy(alpha = 0.85f)
                                    else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(
                        if (a.unlocked) "✓" else "${a.current}/${a.target}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (a.unlocked) sticker.on else InkMid,
                    )
                }

                if (!a.unlocked) {
                    Spacer(Modifier.height(10.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Sunk)
                            .border(2.dp, Ink, RoundedCornerShape(50))
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(fill)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(50))
                                .background(sticker.fill)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Isometric coin stack, drawn in code.
 *
 * The trick to isometric shapes without an illustrator: an ellipse whose
 * height is roughly a third of its width reads as a circle lying flat on a
 * surface, and a straight-sided body joining two of them becomes a cylinder.
 * Stack three, outline them all, and it reads as drawn.
 */
@Composable
fun CoinStack(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val coinW = w * 0.72f
        val coinH = coinW * 0.34f
        val thickness = coinH * 0.55f
        val left = (w - coinW) / 2f
        val outline = 3.dp.toPx()

        // Bottom coin first so the ones above overlap it correctly.
        for (i in 2 downTo 0) {
            val top = size.height - coinH - thickness - (i * thickness * 1.15f)

            val body = Path().apply {
                moveTo(left, top + coinH / 2)
                lineTo(left, top + coinH / 2 + thickness)
                arcTo(
                    androidx.compose.ui.geometry.Rect(
                        Offset(left, top + thickness),
                        Size(coinW, coinH),
                    ),
                    180f, -180f, false,
                )
                lineTo(left + coinW, top + coinH / 2)
                close()
            }
            drawPath(body, Butter.accent)
            drawPath(body, Ink, style = Stroke(outline))

            drawOval(
                color = Butter.fill,
                topLeft = Offset(left, top),
                size = Size(coinW, coinH),
            )
            drawOval(
                color = Ink,
                topLeft = Offset(left, top),
                size = Size(coinW, coinH),
                style = Stroke(outline),
            )
        }
    }
}
