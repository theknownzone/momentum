package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.achievements
import com.momentum.focus.data.unlockedCount
import com.momentum.focus.ui.components.Avatar3D
import com.momentum.focus.ui.components.NoteStack3D
import com.momentum.focus.ui.components.shapeOnly
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*

@Composable
fun AchievementsScreen(data: AppData) {
    val list = data.achievements()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 20.dp, bottom = 28.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "REWARDS",
                    style = MaterialTheme.typography.labelSmall,
                    color = Butter.accent,
                )
                Text(
                    "${data.unlockedCount} of ${list.size}",
                    style = MaterialTheme.typography.displayMedium,
                    color = Ink,
                )
            }
            NoteStack3D(noteColor = Mint.fill, coinColor = Butter.fill, size = 96.dp)
        }

        Spacer(Modifier.height(18.dp))

        list.forEachIndexed { i, a ->
            val sticker = stickerFor(i)
            val fill by animateFloatAsState(a.progress, Motion.settle(), label = a.id)

            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (a.unlocked) sticker.fill else CreamCard)
                    .border(
                        if (a.unlocked) Paper.Outline else 2.dp,
                        Ink,
                        RoundedCornerShape(14.dp),
                    )
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar3D(
                        colorIndex = i,
                        shapeIndex = shapeOnly(a.tier.ordinal),
                        size = 44.dp,
                        modifier = Modifier.padding(end = 12.dp),
                    )
                    Column(Modifier.weight(1f)) {
                        Text(
                            a.tier.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (a.unlocked) sticker.on.copy(alpha = 0.7f) else InkLow,
                        )
                        Text(
                            a.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (a.unlocked) sticker.on else Ink,
                        )
                        Text(
                            if (a.unlocked) a.reward else a.detail,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (a.unlocked) sticker.on.copy(alpha = 0.85f)
                                    else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(
                        if (a.unlocked) "✓" else "${a.current}/${a.target}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (a.unlocked) sticker.on else InkMid,
                    )
                }

                if (!a.unlocked) {
                    Spacer(Modifier.height(10.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Sunk)
                            .border(2.dp, Ink, RoundedCornerShape(50))
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(fill)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(50))
                                .background(sticker.fill)
                        )
                    }
                }
            }
        }
    }
}
