package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private data class Petal(
    val x: Float,
    val phase: Float,
    val speed: Float,
    val drift: Float,
    val scale: Float,
    val spin: Float,
    val alpha: Float,
)

/**
 * Sakura falling behind the hero.
 *
 * One infinite 0..1 transition drives every petal; each one just reads it at a
 * different phase offset. Running fifty separate animations would cost fifty
 * times as much for a result nobody could tell apart.
 *
 * Petals sway on a sine and rotate as they fall, because a petal that drops
 * straight down reads as rain.
 */
@Composable
fun SakuraFall(
    modifier: Modifier = Modifier,
    count: Int = 22,
    tint: Color = Color(0xFFFFB7C5),
) {
    val petals = remember(count) {
        val rng = Random(17)
        List(count) {
            Petal(
                x = rng.nextFloat(),
                phase = rng.nextFloat(),
                speed = 0.6f + rng.nextFloat() * 0.8f,
                drift = 0.03f + rng.nextFloat() * 0.07f,
                scale = 0.6f + rng.nextFloat() * 0.9f,
                spin = (rng.nextFloat() - 0.5f) * 8f,
                alpha = 0.25f + rng.nextFloat() * 0.45f,
            )
        }
    }

    val transition = rememberInfiniteTransition(label = "sakura")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "fall",
    )

    Canvas(modifier) {
        petals.forEach { p ->
            val progress = (t * p.speed + p.phase) % 1f
            val y = progress * (size.height + 60f) - 30f
            val sway = sin(progress * 8f + p.phase * 6.28f) * size.width * p.drift
            val x = p.x * size.width + sway
            val angle = progress * p.spin + p.phase * 3f

            drawPetal(
                center = Offset(x, y),
                radius = 13f * p.scale,
                angle = angle,
                color = tint.copy(alpha = p.alpha),
            )
        }
    }
}

/**
 * A petal is two arcs meeting at a point. Drawn with quadratic curves rather
 * than a circle so it keeps the notched, tapered silhouette even at 9px.
 */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawPetal(
    center: Offset,
    radius: Float,
    angle: Float,
    color: Color,
) {
    fun rotate(dx: Float, dy: Float): Offset {
        val c = cos(angle)
        val s = sin(angle)
        return Offset(center.x + dx * c - dy * s, center.y + dx * s + dy * c)
    }

    val tip = rotate(0f, -radius)
    val leftC = rotate(-radius * 1.1f, -radius * 0.2f)
    val rightC = rotate(radius * 1.1f, -radius * 0.2f)
    val notchL = rotate(-radius * 0.28f, radius * 0.75f)
    val notchC = rotate(0f, radius * 0.45f)
    val notchR = rotate(radius * 0.28f, radius * 0.75f)

    val path = Path().apply {
        moveTo(tip.x, tip.y)
        quadraticBezierTo(leftC.x, leftC.y, notchL.x, notchL.y)
        quadraticBezierTo(notchC.x, notchC.y, notchR.x, notchR.y)
        quadraticBezierTo(rightC.x, rightC.y, tip.x, tip.y)
        close()
    }
    drawPath(path, color)
}
