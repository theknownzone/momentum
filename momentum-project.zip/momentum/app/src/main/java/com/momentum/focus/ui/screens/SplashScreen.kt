package com.momentum.focus.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay

/**
 * Opening animation.
 *
 * Three beats, deliberately staggered: the block punches in with overshoot,
 * the tick draws itself stroke-by-stroke, then the wordmark fades up. A single
 * simultaneous fade would read as a loading screen; the stagger is what makes
 * it read as an intro.
 */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val blockScale = remember { Animatable(0.3f) }
    val tick = remember { Animatable(0f) }
    val word = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        blockScale.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessMedium,
            ),
        )
        haptics.tick()
        tick.animateTo(1f, tween(420))
        haptics.confirm()
        word.animateTo(1f, tween(320))
        delay(420)
        onDone()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain(),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(
                Modifier
                    .size(132.dp)
                    .scale(blockScale.value)
            ) {
                val pad = 14.dp.toPx()
                val stroke = 7.dp.toPx()
                val corner = 26.dp.toPx()

                drawRoundRect(
                    color = Mint.fill,
                    topLeft = Offset(pad, pad),
                    size = Size(size.width - pad * 2, size.height - pad * 2),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(corner),
                )
                drawRoundRect(
                    color = Ink,
                    topLeft = Offset(pad, pad),
                    size = Size(size.width - pad * 2, size.height - pad * 2),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(corner),
                    style = Stroke(stroke),
                )

                // The tick is drawn as a partial path, so it appears to be
                // written rather than switched on.
                val path = Path().apply {
                    moveTo(size.width * 0.33f, size.height * 0.51f)
                    lineTo(size.width * 0.45f, size.height * 0.64f)
                    lineTo(size.width * 0.68f, size.height * 0.38f)
                }
                val measure = PathMeasure().apply { setPath(path, false) }
                val partial = Path()
                measure.getSegment(0f, measure.length * tick.value, partial, true)

                drawPath(
                    path = partial,
                    color = Ink,
                    style = Stroke(
                        width = stroke + 2f,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round,
                    ),
                )
            }

            Spacer(Modifier.height(22.dp))

            Text(
                "MOMENTUM",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.alpha(word.value),
            )
            Text(
                "focus is money",
                style = MaterialTheme.typography.headlineSmall,
                color = Ink,
                textAlign = TextAlign.Center,
                modifier = Modifier.alpha(word.value),
            )
        }
    }
}
