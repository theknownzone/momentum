package com.momentum.focus.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.components.SakuraFall
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.rememberHaptics
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

/**
 * Opening animation: three slabs drop in and stack into a solid isometric
 * tower, then the whole thing turns once.
 *
 * The old version drew a flat tick, which is the most generic loading mark
 * there is. This builds an object instead — pieces arriving separately and
 * assembling reads as something being made, and the final rotation is what
 * proves it has volume.
 */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val low = DeviceProfile.isLowEnd(androidx.compose.ui.platform.LocalContext.current)

    val slabs = remember { List(3) { Animatable(0f) } }
    val spin = remember { Animatable(0f) }
    val word = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        if (low) {
            slabs.forEach { it.snapTo(1f) }
            word.snapTo(1f)
            delay(400)
            onDone()
            return@LaunchedEffect
        }
        slabs.forEachIndexed { i, slab ->
            if (i > 0) delay(130)
            haptics.tick()
            slab.animateTo(
                1f,
                spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMedium,
                ),
            )
        }
        haptics.confirm()
        spin.animateTo(1f, tween(620, easing = LinearEasing))
        word.animateTo(1f, tween(280))
        delay(360)
        onDone()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Ink),
        contentAlignment = Alignment.Center,
    ) {
        SakuraFall(Modifier.fillMaxSize(), count = 14)

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(Modifier.size(180.dp)) {
                val turn = spin.value * 6.2832f
                slabs.forEachIndexed { i, slab ->
                    val drop = slab.value
                    if (drop <= 0f) return@forEachIndexed
                    isoSlab(
                        level = i,
                        drop = drop,
                        turn = turn,
                        sticker = listOf(Mint, Sky, Butter)[i],
                    )
                }
            }

            Spacer(Modifier.height(26.dp))

            Text(
                "MOMENTUM",
                style = MaterialTheme.typography.labelSmall,
                color = Mint.fill,
                textAlign = TextAlign.Center,
                modifier = Modifier.alpha(word.value),
            )
            Text(
                "focus is money",
                style = MaterialTheme.typography.headlineSmall,
                color = CreamCard,
                textAlign = TextAlign.Center,
                modifier = Modifier.alpha(word.value),
            )
        }
    }
}

/**
 * One slab of the tower.
 *
 * Three faces at three brightnesses is what sells the solidity; rotating the
 * corner offsets rather than the whole canvas keeps the vertical edges vertical,
 * which is exactly how real isometric art behaves.
 */
private fun DrawScope.isoSlab(level: Int, drop: Float, turn: Float, sticker: Sticker) {
    val w = size.width
    val cx = w / 2
    val baseY = w * 0.68f - level * w * 0.13f
    // Slabs fall in from above and settle.
    val y = baseY - (1f - drop) * w * 0.5f

    val rx = w * (0.30f - level * 0.035f)
    val ry = rx * 0.55f
    val thickness = w * 0.085f

    fun corner(step: Int): Offset {
        val a = turn + step * 1.5708f
        return Offset(cx + cos(a) * rx, y + sin(a) * ry)
    }

    val c0 = corner(0)
    val c1 = corner(1)
    val c2 = corner(2)
    val c3 = corner(3)

    fun face(a: Offset, b: Offset, shade: Float) {
        val path = Path().apply {
            moveTo(a.x, a.y)
            lineTo(b.x, b.y)
            lineTo(b.x, b.y + thickness)
            lineTo(a.x, a.y + thickness)
            close()
        }
        drawPath(path, sticker.fill.mul(shade))
        drawPath(path, Ink, style = Stroke(3f))
    }

    // Only the two front-facing sides are drawn; the far ones are hidden by
    // the top anyway and drawing them just costs fill rate.
    face(c2, c3, 0.62f)
    face(c3, c0, 0.80f)

    val top = Path().apply {
        moveTo(c0.x, c0.y)
        lineTo(c1.x, c1.y)
        lineTo(c2.x, c2.y)
        lineTo(c3.x, c3.y)
        close()
    }
    drawPath(top, sticker.fill.mul(1.12f))
    drawPath(top, Ink, style = Stroke(3f))
}

private fun Color.mul(f: Float) = Color(
    (red * f).coerceIn(0f, 1f),
    (green * f).coerceIn(0f, 1f),
    (blue * f).coerceIn(0f, 1f),
    alpha,
)
