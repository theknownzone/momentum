package com.momentum.focus.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay

/**
 * Opening animation: the wordmark flies in and a mint underline whips beneath it.
 *
 * The version before this dropped three isometric slabs onto a black page,
 * spun them, and faded the name in under falling petals. Three things were
 * wrong with it. The page was black while the app is cream, so the handoff to
 * the first real screen was a jolt. The petals were decoration nobody asked
 * for. And the name arrived by fading, which is the weakest way a word can
 * appear — a channel ident throws it and stops it.
 *
 * All the motion is finished inside a second. What makes an opening feel
 * expensive is not how much happens, it is that everything stops at once and
 * then holds perfectly still.
 */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val low = DeviceProfile.isLowEnd(LocalContext.current)

    // 0 = off to the left, 1 = home. Overshoot comes from the spring.
    val slide = remember { Animatable(0f) }
    val underline = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        if (low) {
            slide.snapTo(1f)
            underline.snapTo(1f)
            delay(420)
            onDone()
            return@LaunchedEffect
        }
        slide.animateTo(
            1f,
            spring(
                dampingRatio = Spring.DampingRatioLowBouncy,
                stiffness = Spring.StiffnessMedium,
            ),
        )
        // Fired on arrival, not on start — the tap should land with the word.
        haptics.confirm()
        underline.animateTo(1f, tween(300))
        delay(420)
        onDone()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Cream),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "momentum",
                style = MaterialTheme.typography.displayMedium,
                color = Ink,
                modifier = Modifier.graphicsLayer {
                    // Comes in from the left, and squashes horizontally on the
                    // way so the stop reads as an impact rather than a halt.
                    translationX = (slide.value - 1f) * size.width * 1.6f
                    scaleX = 1f + (1f - slide.value) * 0.18f
                    scaleY = 1f - (1f - slide.value) * 0.10f
                },
            )
            Spacer(Modifier.height(6.dp))
            Canvas(
                Modifier
                    .width(210.dp)
                    .height(14.dp),
            ) {
                if (underline.value > 0f) brushUnderline(underline.value)
            }
        }
    }
}

/**
 * A mint underline that looks drawn rather than ruled.
 *
 * Built as a filled shape rather than a stroke so it can be thick through the
 * middle and taper at both ends, with a slight sag across its length. A plain
 * straight stroke of even weight reads as a text-editor underline; this reads
 * as one pass of a brush, which is the same hand the rest of the app is drawn
 * in.
 */
private fun DrawScope.brushUnderline(progress: Float) {
    val w = size.width * progress
    val midY = size.height * 0.45f
    val sag = size.height * 0.22f
    val thick = size.height * 0.34f

    val path = Path().apply {
        moveTo(0f, midY)
        // Top edge, bowing gently downward through the middle.
        quadraticBezierTo(w * 0.5f, midY + sag - thick, w, midY + sag * 0.4f)
        // Back along the bottom edge, which sags a little further, so the
        // shape is fattest where a brush would carry the most paint.
        quadraticBezierTo(w * 0.5f, midY + sag + thick, 0f, midY + thick * 0.35f)
        close()
    }
    drawPath(path, Mint.fill)

    // A few bristle flecks past the tip, only once the stroke is nearly done.
    if (progress > 0.82f) {
        val tipAlpha = ((progress - 0.82f) / 0.18f).coerceIn(0f, 1f)
        listOf(0.30f, 0.62f, 0.86f).forEachIndexed { i, up ->
            drawCircle(
                color = Mint.fill.copy(alpha = 0.55f * tipAlpha),
                radius = size.height * (0.07f - i * 0.015f),
                center = Offset(w + size.height * (0.18f + i * 0.22f), midY + sag * up),
            )
        }
    }
}
