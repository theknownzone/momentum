package com.momentum.focus.block

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.momentum.focus.data.AppStore
import com.momentum.focus.data.FeedSurface
import com.momentum.focus.data.FeedSurfaces
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Blocks short-form feeds without blocking the app around them.
 *
 * The service asks the window which view ids are on screen right now. A Shorts
 * pager answers to a different id than a lecture player, even though both live
 * in the same activity, so a lecture survives and Shorts does not.
 *
 * Three things keep this from becoming a battery problem. The manifest limits
 * the service to six packages, so nothing fires while the user is anywhere
 * else. Lookups go through findAccessibilityNodeInfosByViewId, which is a
 * targeted query rather than a walk of the whole tree. And content events are
 * throttled, because a scrolling feed emits them continuously.
 */
class ShortsGuard : AccessibilityService() {

    private val scope = CoroutineScope(Dispatchers.Default)

    @Volatile private var lastCheck = 0L
    @Volatile private var lastShieldAt = 0L
    @Volatile private var enabled: Set<String> = FeedSurfaces.defaults
    @Volatile private var shieldOn = false
    @Volatile private var studyOnly = false
    @Volatile private var allowed: Set<String> = emptySet()

    private var captureJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        // The debug capture polls instead of waiting for events.
        //
        // It used to run only from onAccessibilityEvent, which fires when an
        // app changes something on screen. A Short playing in a floating window
        // changes nothing — the video moves, the UI does not — so the app you
        // most want to inspect is the one that emits nothing, and the dialog
        // sat there reporting it could see no ids while the video played beside
        // it. Polling costs nothing because it only runs while the dialog asks.
        captureJob?.cancel()
        captureJob = scope.launch {
            while (true) {
                if (captureIds) {
                    val pkg = runCatching {
                        rootInActiveWindow?.packageName?.toString()
                    }.getOrNull()
                    captureVisibleIds(pkg ?: lastSeenPackage)
                }
                delay(900)
            }
        }
        // Read once here and then on every check, so a toggle the user just
        // flipped takes effect without restarting the service.
        scope.launch { refreshSettings() }
    }

    private suspend fun refreshSettings() {
        runCatching {
            val d = AppStore(this@ShortsGuard).data.first()
            // An unseeded install has an empty set. Falling back to the
            // defaults here means someone who was already onboarded before
            // this feature existed still gets Shorts blocked, instead of a
            // guard that is running and matching nothing.
            enabled = if (d.surfacesSeeded) d.blockedSurfaces else FeedSurfaces.defaults
            shieldOn = d.shieldOn
            studyOnly = d.studyOnlyYouTube
            allowed = d.allowedChannels
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg !in FeedSurfaces.watchedPackages) return

        val now = System.currentTimeMillis()
        // A feed being scrolled emits content events without pause. Sampling
        // is enough: the shield only has to arrive quickly, not instantly.
        if (now - lastCheck < 350) return
        lastCheck = now

        scope.launch {
            refreshSettings()
            // Before the shieldOn gate on purpose: the ids are most needed
            // exactly when nothing is matching.
            if (captureIds) captureVisibleIds(pkg)
            // This used to require a live pact. That made the whole feature
            // invisible: no pact, no block, and Shorts played exactly as
            // before. A feed the user has switched off is switched off — the
            // pact's job is to stop them switching it back on, not to be the
            // only time the switch does anything.
            // Study-only runs before the feed check. A lecture from an allowed
            // channel and a music video sit on the same screen with the same
            // view ids, so the surface match cannot tell them apart — only the
            // channel name can.
            if (studyOnly && pkg == "com.google.android.youtube") {
                val channel = watchingChannel()
                if (channel != null && !isAllowed(channel)) {
                    if (System.currentTimeMillis() - lastShieldAt >= 2000) {
                        lastShieldAt = System.currentTimeMillis()
                        blockChannel(pkg, channel)
                    }
                    return@launch
                }
            }

            if (!shieldOn) return@launch
            val (hitPkg, hit) = detect() ?: return@launch
            // Backing out fires window events of its own, so without a gap the
            // guard would react to its own work and press Back repeatedly. Two
            // seconds is long enough for the app to settle and short enough
            // that returning to the feed is caught straight away.
            if (System.currentTimeMillis() - lastShieldAt < 2000) return@launch
            lastShieldAt = System.currentTimeMillis()
            leaveFeed(hitPkg, hit)
            // The player pops out a moment after focus moves, so the sweep has
            // to come after the exit, not before.
            delay(600)
            dismissPip(hitPkg)
        }
    }

    /**
     * Every window root on screen, focused or not.
     *
     * [rootInActiveWindow] returns only the window holding focus. In
     * split-screen that is whichever pane was tapped last, so a feed playing
     * in the other pane was invisible to the id lookup and scrolled freely —
     * tap the notes app once and the block was gone. Floating and picture-in-
     * picture players sit in their own windows for the same reason.
     *
     * Requires flagRetrieveInteractiveWindows, which shorts_guard.xml already
     * declares.
     */
    private fun windowRoots(): List<AccessibilityNodeInfo> {
        val roots = ArrayList<AccessibilityNodeInfo>(4)
        runCatching { rootInActiveWindow }.getOrNull()?.let { roots.add(it) }
        runCatching { windows }.getOrNull()?.forEach { w ->
            runCatching { w.root }.getOrNull()?.let { roots.add(it) }
        }
        return roots
    }

    /**
     * The channel of the video currently open, or null if none is.
     *
     * Only fires on a watch page, never in the feed. Scrolling a feed moves
     * rows constantly, so anything drawn over them lags behind the content and
     * flashes the very thing it is hiding. Waiting until a video is actually
     * opened turns a continuous tracking problem into a single state change,
     * which is the same reason the surface guard is reliable.
     */
    private fun watchingChannel(): String? {
        val root = runCatching { rootInActiveWindow }.getOrNull() ?: return null

        // A watch page is identified by its player being present. Without this
        // the channel byline on a feed card would read as "watching".
        // A handle only appears on a watch page, so finding one is itself the
        // signal that a video is open. The id-based anchor stays as a second
        // route for builds that put the handle somewhere this cannot reach.
        val playing = CHANNEL_ANCHORS.any { id ->
            runCatching { root.findAccessibilityNodeInfosByViewId(id) }
                .getOrNull()?.isNotEmpty() == true
        } || findHandle(root) != null
        if (!playing) return null

        // Handle first, ids second.
        //
        // On current builds the channel shows as "@SomeName" inside the same
        // text node as the like and view counts, not in a byline with an id of
        // its own — so the id list below matched nothing at all. A leading "@"
        // is the one thing about a channel that YouTube has not renamed, and it
        // survives the updates that break view ids every few months.
        findHandle(root)?.let { return it }

        CHANNEL_NAME_IDS.forEach { id ->
            val hit = runCatching { root.findAccessibilityNodeInfosByViewId(id) }
                .getOrNull()?.firstOrNull()
            val text = runCatching { hit?.text?.toString() }.getOrNull()
            runCatching { hit?.recycle() }
            if (!text.isNullOrBlank()) return text.trim()
        }
        return null
    }

    /** Walks the tree for the first "@handle" on screen. */
    private fun findHandle(node: AccessibilityNodeInfo?, depth: Int = 0): String? {
        if (node == null || depth > 20) return null
        val text = runCatching { node.text?.toString() }.getOrNull()
        if (!text.isNullOrBlank()) {
            // The handle is the first token, and the rest of the line is
            // counts and dates, so only the token is taken.
            val token = text.trim().substringBefore(' ')
            if (token.length > 2 && token.startsWith("@")) {
                return token.removePrefix("@")
            }
        }
        for (i in 0 until node.childCount) {
            findHandle(runCatching { node.getChild(i) }.getOrNull(), depth + 1)?.let { return it }
        }
        return null
    }

    /**
     * Matched loosely on purpose.
     *
     * People add "PW" and the byline says "Physics Wallah"; they add "Dear Sir"
     * and it says "Dear Sir Official". Demanding an exact string would block
     * the channel someone deliberately allowed, which is the one failure this
     * feature cannot have — it would look broken and get switched off.
     */
    private fun isAllowed(channel: String): Boolean {
        val c = channel.lowercase()
        return allowed.any { a -> c.contains(a) || a.contains(c) }
    }

    private fun blockChannel(pkg: String, channel: String) {
        runCatching {
            startActivity(
                Intent(this, ShieldActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra(ShieldActivity.EXTRA_PACKAGE, pkg)
                    .putExtra("surface", channel),
            )
        }
    }

    /** Collects every view id on screen. Only runs while a debug screen asks. */
    private fun captureVisibleIds(pkg: String) {
        val found = LinkedHashSet<String>()
        // All panes, so the debug list matches what detect() actually sees.
        windowRoots().forEach { walk(it, found, 0) }
        if (found.isNotEmpty()) {
            lastSeenIds = found.toList()
            lastSeenPackage = pkg
        }
    }

    private fun walk(node: AccessibilityNodeInfo?, into: MutableSet<String>, depth: Int) {
        if (node == null || depth > 24 || into.size > 400) return
        runCatching { node.viewIdResourceName }.getOrNull()
            ?.takeIf { it.isNotBlank() }
            ?.let { into.add(it) }
        for (i in 0 until node.childCount) {
            walk(runCatching { node.getChild(i) }.getOrNull(), into, depth + 1)
        }
    }

    /**
     * The blocked surface on screen and the package showing it, or null.
     *
     * The package is taken from the window that matched rather than from the
     * event, because in split-screen the event can arrive from one pane while
     * the feed is in the other. Passing the event's package through to the
     * shield used to name the wrong app.
     */
    private fun detect(): Pair<String, FeedSurface>? {
        windowRoots().forEach { root ->
            val rootPkg = runCatching { root.packageName?.toString() }.getOrNull()
                ?: return@forEach
            val surfaces = FeedSurfaces.forPackage(rootPkg).filter { it.key in enabled }
            if (surfaces.isEmpty()) return@forEach

            surfaces.forEach { surface ->
                surface.viewIds.forEach { id ->
                    val found = runCatching {
                        root.findAccessibilityNodeInfosByViewId(id)
                    }.getOrNull()
                    if (!found.isNullOrEmpty()) {
                        found.forEach { runCatching { it.recycle() } }
                        return rootPkg to surface
                    }
                }
            }
        }
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        captureJob?.cancel()
        scope.cancel()
    }

    override fun onInterrupt() {}

    /**
     * Closes the little floating player the app leaves behind.
     *
     * YouTube treats the shield appearing as the user navigating away, which is
     * its cue to pop the video into picture-in-picture. The block screen then
     * sits there with the Short still playing in a corner of it — technically
     * blocked, actually not.
     *
     * PiP belongs to the other app, so there is no API to kill it directly.
     * What is available is the window list: a PiP window reports itself, and
     * its root node usually accepts a dismiss action. This is best effort by
     * nature and will not fire on every build, which is why it runs after the
     * shield rather than instead of it.
     */
    private fun dismissPip(pkg: String) {
        runCatching {
            windows.forEach { w ->
                val isPip = Build.VERSION.SDK_INT >= 26 && w.isInPictureInPictureMode
                if (!isPip) return@forEach
                val root = w.root ?: return@forEach
                if (root.packageName?.toString() != pkg) return@forEach
                if (!root.performAction(AccessibilityNodeInfo.ACTION_DISMISS)) {
                    // Some players only respond to the close control, so fall
                    // back to collapsing the window the ordinary way.
                    performGlobalAction(GLOBAL_ACTION_BACK)
                }
            }
        }
    }

    /**
     * Gets the user off the feed while leaving the app they were in.
     *
     * This used to launch the full shield, the same screen a blocked app gets.
     * That contradicts what a feed guard is for: the promise on the Block hub
     * is "app khuli rehti hai", and covering YouTube entirely is just an app
     * block wearing a different label. Opening YouTube cold made it worse,
     * because YouTube can start straight on Shorts — the shield appeared
     * before the user had reached anything, so the app looked fully blocked.
     *
     * Back alone is not enough for that cold start either. With Shorts as the
     * first screen there is nothing behind it, so Back leaves YouTube
     * altogether. When that happens the app is relaunched, which lands on its
     * normal home instead of nowhere.
     */
    private suspend fun leaveFeed(pkg: String, surface: FeedSurface) {
        performGlobalAction(GLOBAL_ACTION_BACK)
        delay(450)

        val nowPkg = runCatching { rootInActiveWindow?.packageName?.toString() }.getOrNull()
        val stillOnFeed = detect() != null
        if (stillOnFeed || nowPkg != pkg) {
            runCatching {
                packageManager.getLaunchIntentForPackage(pkg)
                    ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ?.let { startActivity(it) }
            }
        }

        // Without a word the feed just vanishes and the app reads as broken.
        // A toast says what happened without taking the screen away.
        Handler(Looper.getMainLooper()).post {
            runCatching {
                Toast.makeText(this, "${surface.label} band hai", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        /**
         * A window onto what the guard can actually see.
         *
         * View ids drift every time YouTube or Instagram ships an update, and
         * when they drift the guard keeps running and matches nothing — it
         * fails silently, which is the worst way for a blocker to fail.
         * Guessing replacement ids away from the device is not possible; they
         * only exist on a phone with that build installed. This lets the
         * person holding it read them off the screen instead.
         *
         * Capture stays off unless a debug screen asks, because walking the
         * whole node tree is the thing the sampled, targeted lookup exists to
         * avoid.
         */
        /**
         * Ids that only exist on a watch page. Several are listed because one
         * rename should not silently switch the whole feature off — the same
         * reason FeedSurfaces carries more than one id per surface.
         */
        private val CHANNEL_ANCHORS = listOf(
            "com.google.android.youtube:id/watch_player",
            "com.google.android.youtube:id/player_fragment_container",
            "com.google.android.youtube:id/watch_while_player",
        )

        /** Where the channel byline sits on a watch page. */
        private val CHANNEL_NAME_IDS = listOf(
            "com.google.android.youtube:id/channel_name",
            "com.google.android.youtube:id/owner_name",
            "com.google.android.youtube:id/byline",
            "com.google.android.youtube:id/channel_title",
        )

        /**
         * A window onto what the guard can actually see.
         *
         * View ids drift every time YouTube or Instagram ships an update, and
         * when they drift the guard keeps running and matches nothing — it
         * fails silently, which is the worst way for a blocker to fail.
         * Guessing replacement ids away from the device is not possible; they
         * only exist on a phone with that build installed. This lets the
         * person holding it read them off the screen instead.
         *
         * Capture stays off unless a debug screen asks, because walking the
         * whole node tree is the thing the sampled, targeted lookup exists to
         * avoid.
         */
        @Volatile var captureIds: Boolean = false
        @Volatile var lastSeenIds: List<String> = emptyList()
            private set
        @Volatile var lastSeenPackage: String = ""
            private set

        /**
         * Class-name fallback, kept for surfaces that really do get their own
         * window. It cannot see Shorts or Reels on current builds — that is
         * what the view id lookup above is for — so nothing should depend on
         * it alone.
         */
        fun isShortsSurface(pkg: String, cls: String): Boolean {
            val c = cls.lowercase()
            if (listOf("watchwhile", "playeractivity", "exoplayer").any { c.contains(it) }) {
                return false
            }
            return FeedSurfaces.forPackage(pkg)
                .any { s -> s.classHints.any { c.contains(it) } }
        }
    }
}
