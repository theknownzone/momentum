package com.momentum.focus.block

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.momentum.focus.data.AppStore
import com.momentum.focus.data.FeedSurface
import com.momentum.focus.data.FeedSurfaces
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

/**
 * Blocks short-form feeds without blocking the app around them.
 *
 * The service asks the window which view ids are on screen right now. A Shorts
 * pager answers to a different id than a lecture player, even though both live
 * in the same activity, so a lecture survives and Shorts does not.
 *
 * Three things keep this from becoming a battery problem. The manifest limits
 * the service to six packages, so nothing fires while the user is anywhere
 * else. Lookups go through findAccessibilityNodeInfosByViewId, which is a
 * targeted query rather than a walk of the whole tree. And content events are
 * throttled, because a scrolling feed emits them continuously.
 */
class ShortsGuard : AccessibilityService() {

    private val scope = CoroutineScope(Dispatchers.Default)

    @Volatile private var lastCheck = 0L
    @Volatile private var lastShieldAt = 0L
    @Volatile private var enabled: Set<String> = FeedSurfaces.defaults
    @Volatile private var pactLive = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Read once here and then on every check, so a toggle the user just
        // flipped takes effect without restarting the service.
        scope.launch { refreshSettings() }
    }

    private suspend fun refreshSettings() {
        runCatching {
            val d = AppStore(this@ShortsGuard).data.first()
            enabled = d.blockedSurfaces
            pactLive = d.pactLive
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg !in FeedSurfaces.watchedPackages) return

        val now = System.currentTimeMillis()
        // A feed being scrolled emits content events without pause. Sampling
        // is enough: the shield only has to arrive quickly, not instantly.
        if (now - lastCheck < 350) return
        lastCheck = now

        scope.launch {
            refreshSettings()
            if (!pactLive) return@launch
            val hit = detect(pkg) ?: return@launch
            // The shield is an activity, so re-firing on every sample would
            // stack it. Two seconds is long enough to notice it did not work
            // and short enough that dismissing does not buy free scrolling.
            if (System.currentTimeMillis() - lastShieldAt < 2000) return@launch
            lastShieldAt = System.currentTimeMillis()
            launchShield(pkg, hit)
        }
    }

    /** The blocked surface currently on screen, or null. */
    private fun detect(pkg: String): FeedSurface? {
        val surfaces = FeedSurfaces.forPackage(pkg).filter { it.key in enabled }
        if (surfaces.isEmpty()) return null
        val root: AccessibilityNodeInfo = runCatching { rootInActiveWindow }.getOrNull()
            ?: return null

        surfaces.forEach { surface ->
            surface.viewIds.forEach { id ->
                val found = runCatching {
                    root.findAccessibilityNodeInfosByViewId(id)
                }.getOrNull()
                if (!found.isNullOrEmpty()) {
                    found.forEach { runCatching { it.recycle() } }
                    return surface
                }
            }
        }
        return null
    }

    override fun onInterrupt() {}

    private fun launchShield(pkg: String, surface: FeedSurface) {
        runCatching {
            startActivity(
                Intent(this, ShieldActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra(ShieldActivity.EXTRA_PACKAGE, pkg)
                    .putExtra("surface", surface.label),
            )
        }
    }

    companion object {
        /**
         * Class-name fallback, kept for surfaces that really do get their own
         * window. It cannot see Shorts or Reels on current builds — that is
         * what the view id lookup above is for — so nothing should depend on
         * it alone.
         */
        fun isShortsSurface(pkg: String, cls: String): Boolean {
            val c = cls.lowercase()
            if (listOf("watchwhile", "playeractivity", "exoplayer").any { c.contains(it) }) {
                return false
            }
            return FeedSurfaces.forPackage(pkg)
                .any { s -> s.classHints.any { c.contains(it) } }
        }
    }
}
