package com.momentum.focus.block

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.momentum.focus.data.AppStore
import com.momentum.focus.data.FeedSurface
import com.momentum.focus.data.FeedSurfaces
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Blocks short-form feeds without blocking the app around them.
 *
 * The service asks the window which view ids are on screen right now. A Shorts
 * pager answers to a different id than a lecture player, even though both live
 * in the same activity, so a lecture survives and Shorts does not.
 *
 * Three things keep this from becoming a battery problem. The manifest limits
 * the service to six packages, so nothing fires while the user is anywhere
 * else. Lookups go through findAccessibilityNodeInfosByViewId, which is a
 * targeted query rather than a walk of the whole tree. And content events are
 * throttled, because a scrolling feed emits them continuously.
 */
class ShortsGuard : AccessibilityService() {

    /**
     * A window onto what the guard can actually see.
     *
     * View ids drift every time YouTube or Instagram ships an update, and when
     * they drift the guard keeps running and matches nothing — it fails
     * silently, which is the worst way for a blocker to fail. Guessing
     * replacement ids from a laptop is not possible; they only exist on the
     * device with that build of the app installed. This lets the person
     * holding the phone read them off the screen instead.
     *
     * Capture is off unless a debug screen is open, because walking the whole
     * node tree is exactly the thing the sampled, targeted lookup below exists
     * to avoid.
     */
    companion object {
        @Volatile var captureIds: Boolean = false
        @Volatile var lastSeenIds: List<String> = emptyList()
            private set
        @Volatile var lastSeenPackage: String = ""
            private set
    }

    private val scope = CoroutineScope(Dispatchers.Default)

    @Volatile private var lastCheck = 0L
    @Volatile private var lastShieldAt = 0L
    @Volatile private var enabled: Set<String> = FeedSurfaces.defaults
    @Volatile private var shieldOn = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Read once here and then on every check, so a toggle the user just
        // flipped takes effect without restarting the service.
        scope.launch { refreshSettings() }
    }

    private suspend fun refreshSettings() {
        runCatching {
            val d = AppStore(this@ShortsGuard).data.first()
            // An unseeded install has an empty set. Falling back to the
            // defaults here means someone who was already onboarded before
            // this feature existed still gets Shorts blocked, instead of a
            // guard that is running and matching nothing.
            enabled = if (d.surfacesSeeded) d.blockedSurfaces else FeedSurfaces.defaults
            shieldOn = d.shieldOn
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg !in FeedSurfaces.watchedPackages) return

        val now = System.currentTimeMillis()
        // A feed being scrolled emits content events without pause. Sampling
        // is enough: the shield only has to arrive quickly, not instantly.
        if (now - lastCheck < 350) return
        lastCheck = now

        scope.launch {
            refreshSettings()
            // Before the shieldOn gate on purpose: the ids are most needed
            // exactly when nothing is matching.
            if (captureIds) captureVisibleIds(pkg)
            // This used to require a live pact. That made the whole feature
            // invisible: no pact, no block, and Shorts played exactly as
            // before. A feed the user has switched off is switched off — the
            // pact's job is to stop them switching it back on, not to be the
            // only time the switch does anything.
            if (!shieldOn) return@launch
            val hit = detect(pkg) ?: return@launch
            // The shield is an activity, so re-firing on every sample would
            // stack it. Two seconds is long enough to notice it did not work
            // and short enough that dismissing does not buy free scrolling.
            if (System.currentTimeMillis() - lastShieldAt < 2000) return@launch
            lastShieldAt = System.currentTimeMillis()
            launchShield(pkg, hit)
            // The player pops out a moment after the shield takes focus, so
            // the sweep has to come after it, not before.
            delay(600)
            dismissPip(pkg)
        }
    }

    /** Collects every view id on screen. Only runs while a debug screen asks. */
    private fun captureVisibleIds(pkg: String) {
        val root = runCatching { rootInActiveWindow }.getOrNull() ?: return
        val found = LinkedHashSet<String>()
        walk(root, found, 0)
        if (found.isNotEmpty()) {
            lastSeenIds = found.toList()
            lastSeenPackage = pkg
        }
    }

    private fun walk(node: AccessibilityNodeInfo?, into: MutableSet<String>, depth: Int) {
        if (node == null || depth > 24 || into.size > 400) return
        runCatching { node.viewIdResourceName }.getOrNull()
            ?.takeIf { it.isNotBlank() }
            ?.let { into.add(it) }
        for (i in 0 until node.childCount) {
            walk(runCatching { node.getChild(i) }.getOrNull(), into, depth + 1)
        }
    }

    /** The blocked surface currently on screen, or null. */
    private fun detect(pkg: String): FeedSurface? {
        val surfaces = FeedSurfaces.forPackage(pkg).filter { it.key in enabled }
        if (surfaces.isEmpty()) return null
        val root: AccessibilityNodeInfo = runCatching { rootInActiveWindow }.getOrNull()
            ?: return null

        surfaces.forEach { surface ->
            surface.viewIds.forEach { id ->
                val found = runCatching {
                    root.findAccessibilityNodeInfosByViewId(id)
                }.getOrNull()
                if (!found.isNullOrEmpty()) {
                    found.forEach { runCatching { it.recycle() } }
                    return surface
                }
            }
        }
        return null
    }

    override fun onInterrupt() {}

    /**
     * Closes the little floating player the app leaves behind.
     *
     * YouTube treats the shield appearing as the user navigating away, which is
     * its cue to pop the video into picture-in-picture. The block screen then
     * sits there with the Short still playing in a corner of it — technically
     * blocked, actually not.
     *
     * PiP belongs to the other app, so there is no API to kill it directly.
     * What is available is the window list: a PiP window reports itself, and
     * its root node usually accepts a dismiss action. This is best effort by
     * nature and will not fire on every build, which is why it runs after the
     * shield rather than instead of it.
     */
    private fun dismissPip(pkg: String) {
        runCatching {
            windows.forEach { w ->
                val isPip = Build.VERSION.SDK_INT >= 26 && w.isInPictureInPictureMode
                if (!isPip) return@forEach
                val root = w.root ?: return@forEach
                if (root.packageName?.toString() != pkg) return@forEach
                if (!root.performAction(AccessibilityNodeInfo.ACTION_DISMISS)) {
                    // Some players only respond to the close control, so fall
                    // back to collapsing the window the ordinary way.
                    performGlobalAction(GLOBAL_ACTION_BACK)
                }
            }
        }
    }

    private fun launchShield(pkg: String, surface: FeedSurface) {
        runCatching {
            startActivity(
                Intent(this, ShieldActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra(ShieldActivity.EXTRA_PACKAGE, pkg)
                    .putExtra("surface", surface.label),
            )
        }
    }

    companion object {
        /**
         * Class-name fallback, kept for surfaces that really do get their own
         * window. It cannot see Shorts or Reels on current builds — that is
         * what the view id lookup above is for — so nothing should depend on
         * it alone.
         */
        fun isShortsSurface(pkg: String, cls: String): Boolean {
            val c = cls.lowercase()
            if (listOf("watchwhile", "playeractivity", "exoplayer").any { c.contains(it) }) {
                return false
            }
            return FeedSurfaces.forPackage(pkg)
                .any { s -> s.classHints.any { c.contains(it) } }
        }
    }
}
