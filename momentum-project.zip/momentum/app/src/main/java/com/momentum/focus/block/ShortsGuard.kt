package com.momentum.focus.block

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.momentum.focus.data.AppStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/**
 * Window-class only. Does not read screen text.
 * Shorts/Reels activities get the same shield as a blocked app.
 * Watch / Player activities are left alone so a lecture video still plays.
 */
class ShortsGuard : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: return
        if (!isShortsSurface(pkg, cls)) return
        val live = runCatching {
            runBlocking { AppStore(this@ShortsGuard).data.first().pactLive }
        }.getOrDefault(false)
        if (!live) return
        startActivity(
            Intent(this, ShieldActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("pkg", pkg),
        )
    }

    override fun onInterrupt() {}

    companion object {

        /**
         * Full-screen players that must keep working. A lecture is the whole
         * point of allowing the app through, so these are checked first and
         * win outright — the old order tested "short" before this and made
         * the YouTube exemption below unreachable dead code.
         */
        private val PLAYER_SURFACES = listOf(
            "watchwhile",          // YouTube's main player host
            "watchactivity",
            "playeractivity",
            "videoplayer",
            "exoplayer",
            "fullscreenplayer",
            "livestream",
        )

        /**
         * Feed surfaces that are a different activity from the rest of the app.
         * Matching on the window class only, never on screen text.
         */
        private val SHORT_SURFACES = listOf(
            "shorts",
            "reelsviewer",
            "reelviewer",
            "clipsviewer",
            "spotlight",           // Snapchat
            "immersive",           // Instagram's full-bleed reel host
            "discoverfeed",
        )

        fun isShortsSurface(pkg: String, cls: String): Boolean {
            val c = cls.lowercase()
            val p = pkg.lowercase()

            // Lecture first, always.
            if (PLAYER_SURFACES.any { c.contains(it) }) return false

            if (SHORT_SURFACES.any { c.contains(it) }) return true

            // Generic fallbacks, kept narrow so a settings screen with the word
            // "short" in it does not trip the shield.
            if (c.contains("short") && (p.contains("youtube") || p.contains("google"))) return true
            if (c.contains("reel") && p.contains("instagram")) return true
            if (c.contains("clip") && p.contains("instagram")) return true

            return false
        }
    }
}
