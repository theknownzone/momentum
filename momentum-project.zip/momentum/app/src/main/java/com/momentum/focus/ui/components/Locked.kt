package com.momentum.focus.ui.components

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink

/**
 * Frosts something that has not been unlocked yet, and says so.
 *
 * A locked row used to be an ordinary row with the word LOCKED at the end,
 * which reads as a label rather than a state — the eye skips it and the row
 * still looks available. Frosting it makes the difference structural: you can
 * see there is something there and you can see you cannot reach it.
 *
 * Real blur is used from API 31 up, where `Modifier.blur` exists. Below that it
 * silently does nothing, so those devices get a translucent cream scrim and a
 * lowered opacity instead. Both read as frosted; only the newer one is actually
 * blurred. Shipping the blur alone would leave older phones showing a locked
 * row that looks exactly like an unlocked one.
 */
@Composable
fun Locked(
    locked: Boolean,
    modifier: Modifier = Modifier,
    label: String = "LOCKED",
    content: @Composable BoxScope.() -> Unit,
) {
    if (!locked) {
        Box(modifier, content = content)
        return
    }

    Box(modifier) {
        Box(
            Modifier
                .then(
                    if (Build.VERSION.SDK_INT >= 31) Modifier.blur(3.dp)
                    else Modifier.alpha(0.45f)
                ),
            content = content,
        )
        // The scrim goes on for everyone. On a blurred device it deepens the
        // frost; on an older one it is the whole effect.
        Box(
            Modifier
                .matchParentSize()
                .background(CreamCard.copy(alpha = 0.42f))
        )
        Box(
            Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(Ink)
                .padding(horizontal = 9.dp, vertical = 4.dp),
        ) {
            Text(
                "\uD83D\uDD12 $label",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
            )
        }
    }
}
