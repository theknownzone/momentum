package com.momentum.focus.block

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.core.content.getSystemService

/**
 * Makes the app un-uninstallable while a hard mode is running.
 *
 * Android will not let a package be removed while it is an active device
 * admin, which is the only supported way to stop someone deleting the blocker
 * the moment it becomes inconvenient.
 *
 * There is always a way out, on purpose. A lock with no key is not discipline,
 * it is a bricked phone: if this screen ever fails, the only remaining fix is a
 * factory reset. Deactivation stays available in Profile at all times.
 */
class AdminReceiver : DeviceAdminReceiver() {

    override fun onDisabled(context: Context, intent: Intent) {
        // Losing admin means uninstall protection is gone, so the shield is
        // stopped too rather than left running in a state it cannot defend.
        BlockerService.stop(context)
    }
}

object Admin {

    fun component(context: Context) = ComponentName(context, AdminReceiver::class.java)

    fun isActive(context: Context): Boolean = runCatching {
        context.getSystemService<DevicePolicyManager>()
            ?.isAdminActive(component(context)) ?: false
    }.getOrDefault(false)

    /** Opens the system screen asking the user to grant admin. */
    fun requestIntent(context: Context): Intent =
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component(context))
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Stops the app being deleted while Crown mode is on. " +
                    "You can turn this off any time from Profile.",
            )
        }

    fun deactivate(context: Context) = runCatching {
        context.getSystemService<DevicePolicyManager>()
            ?.removeActiveAdmin(component(context))
    }
}
