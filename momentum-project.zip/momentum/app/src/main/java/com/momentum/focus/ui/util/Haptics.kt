package com.momentum.focus.ui.util

import android.os.Build
import android.os.Vibrator
import android.os.VibrationEffect
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.content.getSystemService

/**
 * Haptics done properly.
 *
 * Two channels are used deliberately:
 *  - View.performHapticFeedback() for standard taps. The OEM tunes these, so
 *    they feel correct on that specific phone and respect system settings.
 *  - Vibrator + VibrationEffect for custom celebration patterns that no
 *    stock constant covers.
 *
 * Everything degrades quietly on old devices. Never crash for a buzz.
 */
class Haptics(
    private val view: View,
    private val vibrator: Vibrator?,
) {
    private fun perform(constant: Int) = runCatching {
        view.performHapticFeedback(constant)
    }

    /** Every ordinary tap. The baseline tick under a finger. */
    fun tap() {
        Sfx.play(Sound.POP)
        perform(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    /** Passing a threshold: slider notch, minute tick, item snapping in. */
    fun tick() {
        Sfx.play(Sound.TICK)
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CLOCK_TICK
            else HapticFeedbackConstants.KEYBOARD_TAP
        )
    }

    /** Long press opened something. Heavier, deliberate. */
    fun press() {
        Sfx.play(Sound.WHOOSH)
        perform(HapticFeedbackConstants.LONG_PRESS)
    }

    /** Action succeeded: session logged, habit checked. */
    fun confirm() {
        Sfx.play(Sound.SUCCESS)
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
            else HapticFeedbackConstants.VIRTUAL_KEY
        )
    }

    /** Action refused: blocked app, invalid input. Sharp double bump. */
    fun reject() {
        Sfx.play(Sound.ERROR)
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.REJECT
            else HapticFeedbackConstants.LONG_PRESS
        )
    }

    /** Drag finished, gesture completed. */
    fun gestureEnd() = perform(
        if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.GESTURE_END
        else HapticFeedbackConstants.CLOCK_TICK
    )

    /**
     * Streak milestone. A rising three-beat that ramps in amplitude — this is
     * the one moment in the app allowed to be loud. Fire it with confetti.
     */
    fun celebrate() {
        Sfx.play(Sound.SUCCESS)
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        runCatching {
            if (Build.VERSION.SDK_INT >= 26) {
                val timings = longArrayOf(0, 45, 70, 55, 70, 110)
                val amps    = intArrayOf(0, 90, 0, 150, 0, 255)
                v.vibrate(VibrationEffect.createWaveform(timings, amps, -1))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(longArrayOf(0, 45, 70, 55, 70, 110), -1)
            }
        }
    }

    /**
     * Focus session ended. Long, calm, single swell — the opposite of an alarm.
     */
    /** Soft two-beat for a festival banner. */
    fun festive() {
        Sfx.play(Sound.POP)
        val v = vibrator ?: run { tap(); return }
        runCatching {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0, 35, 50, 70),
                        intArrayOf(0, 80, 0, 160),
                        -1,
                    )
                )
            } else tap()
        }
    }

    fun sessionComplete() {
        val v = vibrator ?: return
        if (Build.VERSION.SDK_INT >= 26 && v.hasAmplitudeControl()) {
            runCatching {
                v.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0, 250), intArrayOf(0, 140), -1
                    )
                )
            }
        } else confirm()
    }
}

val LocalHaptics = staticCompositionLocalOf<Haptics> {
    error("Haptics not provided. Wrap your content in ProvideHaptics { }.")
}

@Composable
fun rememberHaptics(): Haptics {
    val view = LocalView.current
    val context = LocalContext.current
    return remember(view) {
        Sfx.init(context.applicationContext)
        Haptics(view, context.getSystemService<Vibrator>())
    }
}
