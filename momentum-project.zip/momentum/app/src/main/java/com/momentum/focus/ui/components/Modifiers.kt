package com.momentum.focus.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.Modifier

/**
 * Material's ripple fights the paper look — a spreading grey circle on a
 * coloured cutout reads as a bug. The press feedback here is scale + haptic
 * instead, which is both more physical and cheaper to draw.
 */
fun Modifier.clickableNoRipple(
    interactionSource: MutableInteractionSource,
    enabled: Boolean = true,
    onClick: () -> Unit,
): Modifier = this.clickable(
    interactionSource = interactionSource,
    indication = null,
    enabled = enabled,
    onClick = onClick,
)
