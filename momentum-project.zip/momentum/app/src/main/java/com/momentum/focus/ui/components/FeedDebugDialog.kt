package com.momentum.focus.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.block.ShortsGuard
import com.momentum.focus.data.FeedSurfaces
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import kotlinx.coroutines.delay

/**
 * Shows the view ids the guard can see right now, and which of them it knows.
 *
 * When a feed stops being caught the cause is almost always that the app
 * renamed an id, and no amount of reasoning away from the device will produce
 * the new one. Reading them off the phone is the whole fix.
 */
@Composable
fun FeedDebugDialog(onClose: () -> Unit) {
    val context = LocalContext.current
    var ids by remember { mutableStateOf(ShortsGuard.lastSeenIds) }
    var pkg by remember { mutableStateOf(ShortsGuard.lastSeenPackage) }

    // Capture is expensive, so it is on only while this dialog is open.
    DisposableEffect(Unit) {
        ShortsGuard.captureIds = true
        onDispose { ShortsGuard.captureIds = false }
    }
    LaunchedEffect(Unit) {
        while (true) {
            ids = ShortsGuard.lastSeenIds
            pkg = ShortsGuard.lastSeenPackage
            delay(700)
        }
    }

    val known = remember {
        FeedSurfaces.all.flatMap { it.viewIds }.toSet()
    }

    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 520.dp)
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(16.dp),
        ) {
            Text("FEED GUARD", style = MaterialTheme.typography.labelSmall, color = InkMid)
            Text(
                if (pkg.isBlank()) "Kuch nahi dikha abhi" else pkg,
                style = MaterialTheme.typography.titleMedium,
                color = Ink,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Ye dialog khula chhod ke Shorts ya Reels kholo, phir wapas aao. " +
                    "Jo id yahan dikhe aur ✓ na ho, wo nayi hai.",
                style = MaterialTheme.typography.bodyMedium,
                color = InkMid,
            )
            Spacer(Modifier.height(12.dp))

            Column(
                Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState()),
            ) {
                if (ids.isEmpty()) {
                    Text(
                        "Abhi tak koi id nahi mili. Accessibility service on hai?",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                    )
                }
                ids.forEach { id ->
                    val hit = id in known
                    Text(
                        (if (hit) "✓  " else "•  ") + id,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontFamily = FontFamily.Monospace,
                        ),
                        color = if (hit) Mint.on else Ink,
                        modifier = Modifier.padding(vertical = 2.dp),
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DebugButton("Copy", Modifier.weight(1f)) {
                    copyToClipboard(context, ids.joinToString("\n"))
                }
                DebugButton("Band karo", Modifier.weight(1f), onClose)
            }
        }
    }
}

@Composable
private fun DebugButton(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Mint.fill)
            .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
            .padding(vertical = 12.dp),
    ) {
        Text(
            label,
            style = MaterialTheme.typography.titleMedium,
            color = Mint.on,
            modifier = Modifier.align(androidx.compose.ui.Alignment.Center),
        )
    }
}

private fun copyToClipboard(context: Context, text: String) {
    runCatching {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("view ids", text))
    }
}
