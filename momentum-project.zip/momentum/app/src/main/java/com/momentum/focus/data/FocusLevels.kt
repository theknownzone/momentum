package com.momentum.focus.data

/**
 * The three names on the focus-level picker.
 *
 * Kept in one place because the labels are not confined to the picker — they
 * also sit inside sentences on Profile and What's New, and the words are far
 * too common to grep for safely. Searching this codebase for "Lock" turns up
 * the uninstall lock, the pact lock and a Material icon long before it finds
 * the level.
 *
 * The constants are named after what each level *does*, not what it is
 * *called*, so renaming a label never leaves a constant lying about itself.
 * That has already gone wrong once here: the old L3 was dropped from the
 * picker and its name lingered in comments describing behaviour that had
 * moved elsewhere.
 *
 * Deliberately not in the i18n string tables. These read identically in
 * Hinglish and English, which was part of why they were chosen — a name that
 * needs translating would double the work every time it appears mid-sentence.
 */
object FocusLevels {
    /** Level 1 — nothing is blocked, and the session still earns. */
    const val NO_BLOCK = "Light"

    /** Level 2 — Shield is on. */
    const val SHIELD = "Lock"

    /** Level 3 and above — Shield plus the uninstall lock. */
    const val SHIELD_AND_UNINSTALL = "Crown"
}
