package com.momentum.focus.block

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.getSystemService
import com.momentum.focus.MainActivity
import com.momentum.focus.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Watches the foreground app and throws up the shield when a blocked one opens.
 *
 * Polling UsageStats is used rather than an AccessibilityService on purpose:
 * accessibility can read the whole screen, Play reviews it harshly, and it is
 * overkill when all we need is the current package name.
 *
 * The poll is 700ms. Faster drains battery for no gain; slower and the user
 * gets a visible second of Instagram before the shield lands, which is exactly
 * the second that matters.
 */
class BlockerService : Service() {

    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    companion object {
        const val CHANNEL = "momentum_blocker"
        const val NOTIF_ID = 41

        /** Packages currently blocked. Set by the app when settings change. */
        @Volatile var blocked: Set<String> = emptySet()

        /** package -> epoch millis until which it is temporarily allowed. */
        private val allowances = mutableMapOf<String, Long>()

        fun allow(pkg: String, minutes: Int) {
            synchronized(allowances) {
                allowances[pkg] = System.currentTimeMillis() + minutes * 60_000L
            }
        }

        private fun isAllowed(pkg: String): Boolean = synchronized(allowances) {
            val until = allowances[pkg] ?: return false
            if (System.currentTimeMillis() > until) {
                allowances.remove(pkg); false
            } else true
        }

        fun start(context: Context) {
            val intent = Intent(context, BlockerService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, BlockerService::class.java))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())
        job = scope.launch {
            var lastShielded = ""
            var lastFiredAt = 0L
            while (true) {
                val current = foregroundPackage()
                val blockedNow = current != null &&
                    current in blocked &&
                    current != packageName &&
                    !isAllowed(current)

                if (blockedNow) {
                    val now = System.currentTimeMillis()
                    // Re-fires if the blocked app is still in front two seconds
                    // later. Firing only once let people dismiss the shield and
                    // carry on scrolling, which made blocking advisory rather
                    // than real.
                    val stale = now - lastFiredAt > 2000
                    if (current != lastShielded || stale) {
                        lastShielded = current!!
                        lastFiredAt = now
                        launchShield(current)
                    }
                } else if (current != null && current != packageName) {
                    lastShielded = ""
                }
                delay(350)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        job?.cancel()
        super.onDestroy()
    }

    /**
     * queryEvents rather than queryUsageStats: the latter reports aggregate
     * totals that lag by minutes, which is useless for "what is on screen now".
     */
    private fun foregroundPackage(): String? {
        val usage = getSystemService<UsageStatsManager>() ?: return null
        val now = System.currentTimeMillis()
        val events = usage.queryEvents(now - 10_000, now)
        val event = UsageEvents.Event()
        var latest: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                latest = event.packageName
            }
        }
        return latest
    }

    private fun launchShield(pkg: String) {
        val intent = Intent(this, ShieldActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            putExtra(ShieldActivity.EXTRA_PACKAGE, pkg)
        }
        runCatching { startActivity(intent) }
    }

    private fun buildNotification(): Notification {
        val manager = getSystemService<NotificationManager>()
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL,
                "Shield",
                NotificationManager.IMPORTANCE_MIN,
            ).apply { setShowBadge(false) }
            manager?.createNotificationChannel(channel)
        }

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE,
        )

        return NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Shield is on")
            .setContentText("Blocked apps will be stopped")
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }
}
