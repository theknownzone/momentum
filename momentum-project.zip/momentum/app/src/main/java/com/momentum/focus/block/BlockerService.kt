package com.momentum.focus.block

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.getSystemService
import com.momentum.focus.MainActivity
import com.momentum.focus.R
import com.momentum.focus.data.ScreenTime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Watches the foreground app and throws up the shield when a blocked one opens.
 *
 * Polling UsageStats is used rather than an AccessibilityService on purpose:
 * accessibility can read the whole screen, Play reviews it harshly, and it is
 * overkill when all we need is the current package name.
 *
 * The poll is 700ms. Faster drains battery for no gain; slower and the user
 * gets a visible second of Instagram before the shield lands, which is exactly
 * the second that matters.
 */
class BlockerService : Service() {

    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    companion object {
        const val CHANNEL = "momentum_blocker"
        const val NOTIF_ID = 41

        /** Kept up to date by the app so the notification can show real data. */
        @Volatile var balanceMinutes: Int = 0
        @Volatile var earnedTodayMinutes: Int = 0
        @Volatile var streakDays: Int = 0

        /** Packages currently blocked. Set by the app when settings change. */
        @Volatile var blocked: Set<String> = emptySet()

        /** package -> minutes per day. Optional, set by the app. */
        @Volatile var dailyCaps: Map<String, Int> = emptyMap()

        /** Packages that have already burned their cap today. */
        @Volatile private var overCap: Set<String> = emptySet()

        fun isOverCap(pkg: String): Boolean = pkg in overCap

        /** package -> epoch millis until which it is temporarily allowed. */
        private val allowances = mutableMapOf<String, Long>()

        fun allow(pkg: String, minutes: Int) {
            synchronized(allowances) {
                allowances[pkg] = System.currentTimeMillis() + minutes * 60_000L
            }
        }

        private fun isAllowed(pkg: String): Boolean = synchronized(allowances) {
            val until = allowances[pkg] ?: return false
            if (System.currentTimeMillis() > until) {
                allowances.remove(pkg); false
            } else true
        }

        fun start(context: Context) {
            val intent = Intent(context, BlockerService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            // Deliberate stop, so the gap that follows is not an OEM kill.
            Heartbeat.disarm(context)
            context.stopService(Intent(context, BlockerService::class.java))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())
        job = scope.launch {
            var lastShielded = ""
            var lastFiredAt = 0L
            var lastNotify = 0L
            var lastBeat = 0L
            var lastCapScan = 0L
            while (true) {
                // Proof of life. If these stamps stop while the shield is armed,
                // the OEM killed us and the app can say so when it next opens.
                if (System.currentTimeMillis() - lastBeat > 20_000) {
                    lastBeat = System.currentTimeMillis()
                    runCatching { Heartbeat.beat(this@BlockerService) }
                }
                val current = foregroundPackage()
                // Caps are read from UsageStats, which only updates every so
                // often, so once a minute is plenty and keeps the 350ms loop
                // free of system calls.
                if (System.currentTimeMillis() - lastCapScan > 60_000) {
                    lastCapScan = System.currentTimeMillis()
                    runCatching {
                        val caps = dailyCaps
                        overCap = if (caps.isEmpty()) emptySet() else {
                            val used = ScreenTime.minutesTodayFor(
                                this@BlockerService, caps.keys,
                            )
                            caps.filter { (pkg, cap) -> (used[pkg] ?: 0) >= cap }.keys
                        }
                    }
                }

                val cappedOut = current != null && isOverCap(current)
                val blockedNow = current != null &&
                    current != packageName &&
                    (
                        // A cap is the user's own limit, so the wallet cannot
                        // buy past it the way it can buy past a plain block.
                        cappedOut ||
                            (current in blocked && !isAllowed(current))
                        )

                if (blockedNow) {
                    val now = System.currentTimeMillis()
                    // Re-fires if the blocked app is still in front two seconds
                    // later. Firing only once let people dismiss the shield and
                    // carry on scrolling, which made blocking advisory rather
                    // than real.
                    val stale = now - lastFiredAt > 2000
                    if (current != lastShielded || stale) {
                        lastShielded = current!!
                        lastFiredAt = now
                        launchShield(current)
                    }
                } else if (current != null && current != packageName) {
                    lastShielded = ""
                }
                // Cheap enough to redraw once a minute; the tray line then
                // stays current instead of freezing at whatever it was when
                // the service started.
                if (System.currentTimeMillis() - lastNotify > 60_000) {
                    lastNotify = System.currentTimeMillis()
                    runCatching {
                        getSystemService<NotificationManager>()
                            ?.notify(NOTIF_ID, buildNotification())
                    }
                }
                delay(350)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        job?.cancel()
        super.onDestroy()
    }

    /**
     * queryEvents rather than queryUsageStats: the latter reports aggregate
     * totals that lag by minutes, which is useless for "what is on screen now".
     */
    private fun foregroundPackage(): String? {
        val usage = getSystemService<UsageStatsManager>() ?: return null
        val now = System.currentTimeMillis()
        val events = usage.queryEvents(now - 10_000, now)
        val event = UsageEvents.Event()
        var latest: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                latest = event.packageName
            }
        }
        return latest
    }

    private fun launchShield(pkg: String) {
        val intent = Intent(this, ShieldActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            putExtra(ShieldActivity.EXTRA_PACKAGE, pkg)
        }
        runCatching { startActivity(intent) }
    }

    private fun buildNotification(): Notification {
        val manager = getSystemService<NotificationManager>()
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL,
                "Shield",
                NotificationManager.IMPORTANCE_MIN,
            ).apply { setShowBadge(false) }
            manager?.createNotificationChannel(channel)
        }

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE,
        )

        val rupees = balanceMinutes
        val earned = earnedTodayMinutes

        // A blocker notification that only says "blocking" reads like spyware
        // sitting in the tray. Showing what has been earned makes the same
        // line read as a study app keeping score.
        val headline = when {
            earned > 0 -> "₹$rupees banked · +₹$earned today"
            rupees > 0 -> "₹$rupees in your wallet"
            else -> "Start a session to earn"
        }
        val detail = buildString {
            append("${blocked.size} apps guarded")
            if (streakDays > 0) append(" · $streakDays day streak")
            append("\n${rupees / 60}h ${rupees % 60}m of screen time already paid for.")
        }

        return NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle(headline)
            .setContentText(detail.substringBefore('\n'))
            .setStyle(NotificationCompat.BigTextStyle().bigText(detail))
            .setSubText("Momentum")
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setShowWhen(false)
            .setContentIntent(open)
            .build()
    }
}
