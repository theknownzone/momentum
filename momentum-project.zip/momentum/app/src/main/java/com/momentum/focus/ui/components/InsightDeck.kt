package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.absoluteValue

private data class DeckCard(
    val kicker: String,
    val title: String,
    /** The line that actually lands, in the language it lands in. */
    val punch: String,
    val body: String,
    val sticker: Sticker,
)

/**
 * Cards are written, not scraped.
 *
 * Real quotes get misattributed constantly and half the "Kalam said" lines on
 * the internet were never said by him. Originals cost nothing and cannot be
 * wrong. The techniques are real ones with evidence behind them.
 */
private val DECK = listOf(
    DeckCard(
        "TECHNIQUE", "Active recall",
        "Kitaab band karo, phir likho.",
        "Close the book and write what you remember. Re-reading feels productive and teaches you almost nothing — being forced to retrieve is what builds the memory.",
        Mint,
    ),
    DeckCard(
        "TECHNIQUE", "Spaced repetition",
        "Ek raat ki mehnat, teen din mein gayab.",
        "Revise a topic on day 1, 3, 7, then 21. The same hours spread across weeks beat the same hours in one night by a wide margin.",
        Sky,
    ),
    DeckCard(
        "TRUTH", "The first ten minutes",
        "Shuru karna hi mushkil hai, baaki sab aasan.",
        "Sit down and do ten minutes badly. The resistance is almost always gone by minute eleven.",
        Butter,
    ),
    DeckCard(
        "TECHNIQUE", "Explain it out loud",
        "Jahan atko, wahi tumhe aata nahi.",
        "Teach the chapter to an empty room. Every place you stumble is exactly where you don't actually understand it yet.",
        Lilac,
    ),
    DeckCard(
        "TRUTH", "Nobody feels ready",
        "Toppers bhi bore hote hain. Bas uthte nahi.",
        "The people you compare yourself to also sat down distracted and unsure. They just kept the chair warm anyway.",
        Tang,
    ),
    DeckCard(
        "TECHNIQUE", "One tab, one book",
        "Har khula tab ek nyota hai bhaagne ka.",
        "Close them all before you start. The friction of reopening is enough to keep you in place.",
        Candy,
    ),
    DeckCard(
        "TRUTH", "A slip is not a reset",
        "Ek din kharab hone se kuch khatam nahi hota.",
        "People don't fail because they slipped. They fail because they treated the slip as proof and stopped.",
        Mint,
    ),
    DeckCard(
        "TRUTH", "Time is the only fee",
        "Fees waqt mein bharni padti hai.",
        "Marks, seats and salaries all get paid for in the same currency: hours nobody else could see you spending.",
        Butter,
    ),
)

/**
 * A swipeable deck with real depth.
 *
 * The card being read sits flat and full size; its neighbours rotate away and
 * shrink, so the stack reads as physical cards on a table rather than a strip
 * of panels sliding past.
 */
@Composable
fun InsightDeck(modifier: Modifier = Modifier) {
    val haptics = rememberHaptics()
    val state = rememberPagerState(pageCount = { DECK.size })

    LaunchedEffect(state.currentPage) { haptics.tick() }

    Column(modifier) {
        HorizontalPager(
            state = state,
            contentPadding = PaddingValues(end = 42.dp),
            pageSpacing = 12.dp,
        ) { page ->
            val card = DECK[page]

            // How far this page is from settled, 0 when centred and 1 when a
            // full page away. Everything below is driven off it.
            val offset = (
                (state.currentPage - page) + state.currentPageOffsetFraction
                ).absoluteValue.coerceIn(0f, 1f)

            Column(
                Modifier
                    .graphicsLayer {
                        val scale = 1f - offset * 0.12f
                        scaleX = scale
                        scaleY = scale
                        rotationY = offset * 22f
                        // Without a raised camera distance the rotation looks
                        // like a fish-eye lens instead of a turning card.
                        cameraDistance = 18f * density
                        alpha = 1f - offset * 0.35f
                    }
                    .fillMaxWidth()
                    .height(224.dp)
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .background(card.sticker.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                    .padding(18.dp),
            ) {
                Text(
                    card.kicker,
                    style = MaterialTheme.typography.labelSmall,
                    color = card.sticker.on.copy(alpha = 0.7f),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    card.punch,
                    style = MaterialTheme.typography.headlineSmall,
                    color = card.sticker.on,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    card.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = card.sticker.on.copy(alpha = 0.75f),
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    card.body,
                    style = MaterialTheme.typography.bodyLarge,
                    color = card.sticker.on.copy(alpha = 0.88f),
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
        ) {
            repeat(DECK.size) { i ->
                val on = state.currentPage == i
                Box(
                    Modifier
                        .padding(horizontal = 3.dp)
                        .size(width = if (on) 18.dp else 7.dp, height = 7.dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (on) Ink else InkLow)
                )
            }
        }
    }
}
