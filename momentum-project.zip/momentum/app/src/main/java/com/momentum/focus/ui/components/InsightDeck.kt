package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.momentum.focus.data.CardFeed
import com.momentum.focus.data.ScreenTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.absoluteValue

private data class DeckCard(
    val kicker: String,
    val title: String,
    /** The line that actually lands, in the language it lands in. */
    val punch: String,
    val body: String,
    val sticker: Sticker,
)

/**
 * Cards are written, not scraped.
 *
 * Real quotes get misattributed constantly and half the "Kalam said" lines on
 * the internet were never said by him. Originals cost nothing and cannot be
 * wrong. The techniques are real ones with evidence behind them.
 */
private fun stickerFor(tone: String): Sticker = when (tone.lowercase()) {
    "mint" -> Mint
    "tang" -> Tang
    "butter" -> Butter
    "lilac" -> Lilac
    "sky" -> Sky
    else -> Mint
}

private val DECK = listOf(
    DeckCard(
        "TECHNIQUE", "Active recall",
        "Kitaab band karo, phir likho.",
        "Re-reading feels productive and teaches you almost nothing. Being forced to retrieve is what builds the memory.",
        Mint,
    ),
    DeckCard(
        "TECHNIQUE", "Spaced repetition",
        "Ek raat ki mehnat, teen din mein gayab.",
        "Revise on day 1, 3, 7, then 21. Hours spread across weeks beat one long night, easily.",
        Sky,
    ),
    DeckCard(
        "TRUTH", "The first ten minutes",
        "Shuru karna hi mushkil hai, baaki sab aasan.",
        "Sit down and do ten minutes badly. The resistance is almost always gone by minute eleven.",
        Butter,
    ),
    DeckCard(
        "TECHNIQUE", "Explain it out loud",
        "Jahan atko, wahi tumhe aata nahi.",
        "Teach the chapter to an empty room. Every place you stumble is exactly where you don't actually understand it yet.",
        Lilac,
    ),
    DeckCard(
        "TRUTH", "Nobody feels ready",
        "Toppers bhi bore hote hain. Bas uthte nahi.",
        "The people you compare yourself to also sat down distracted and unsure. They just kept the chair warm anyway.",
        Tang,
    ),
    DeckCard(
        "TECHNIQUE", "One tab, one book",
        "Har khula tab ek nyota hai bhaagne ka.",
        "Close them all before you start. The friction of reopening is enough to keep you in place.",
        Candy,
    ),
    DeckCard(
        "TRUTH", "A slip is not a reset",
        "Ek din kharab hone se kuch khatam nahi hota.",
        "People don't fail because they slipped. They fail because they treated the slip as proof and stopped.",
        Mint,
    ),
    DeckCard(
        "TRUTH", "Time is the only fee",
        "Fees waqt mein bharni padti hai.",
        "Marks and seats are paid for in one currency: hours nobody saw you spending.",
        Butter,
    ),
)

/**
 * A swipeable deck with real depth.
 *
 * The card being read sits flat and full size; its neighbours rotate away and
 * shrink, so the stack reads as physical cards on a table rather than a strip
 * of panels sliding past.
 */
/**
 * Cards built from what the phone actually did. Returns nothing when usage
 * access has not been granted yet — an empty deck slot is better than a card
 * confidently reporting zero hours.
 */
private fun usageCards(context: android.content.Context): List<DeckCard> {
    val report = ScreenTime.report(context)
    if (!report.hasData) return emptyList()

    val today = report.dailyMinutes.lastOrNull() ?: 0
    val top = report.topApps.firstOrNull()
    val out = mutableListOf<DeckCard>()

    if (top != null && top.minutes > 0) {
        val h = top.minutes / 60
        val m = top.minutes % 60
        out += DeckCard(
            "IS HAFTE",
            top.label,
            if (h > 0) "$h ghante $m minute." else "$m minute.",
            "Sirf ek app pe. Poore hafte ka jod. Ye time wapas nahi aata — " +
                "par agla hafta abhi likha nahi gaya.",
            Tang,
        )
    }

    if (today > 0) {
        val h = today / 60
        val m = today % 60
        // Compare against the days before today, not against a window that
        // includes today itself. Including it dragged the average toward the
        // very number being judged, and averaging over the pre-shield days
        // produced things like "841 min kam" against a 17-hour baseline —
        // arithmetically true, and useless as a fact about today.
        val prior = report.dailyMinutes.dropLast(1).filter { it > 0 }
        val avg = if (prior.isEmpty()) 0 else prior.sum() / prior.size
        val diff = today - avg
        out += DeckCard(
            "AAJ",
            if (h > 0) "$h ghante $m min phone" else "$m min phone",
            when {
                // One day of history cannot describe a habit.
                avg == 0 || prior.size < 2 -> "Aaj ka hisaab."
                diff < -30 -> "Rozana se ${-diff} min kam."
                diff > 30 -> "Rozana se $diff min zyada."
                else -> "Rozana jitna hi."
            },
            "Pichhle ${prior.size} din ka average $avg min hai. Ye roz badalta hai — " +
                "isliye ise dekhne ka matlab hai.",
            Mint,
        )
    }
    return out
}

@Composable
fun InsightDeck(modifier: Modifier = Modifier) {
    val haptics = rememberHaptics()
    val context = LocalContext.current

    // The deck used to be technique cards only, which read the same on day one
    // and day fifty. The first card is now this phone's own numbers, so the
    // deck opens on something that changed since yesterday.
    val live by produceState(initialValue = emptyList<DeckCard>(), context) {
        value = withContext(Dispatchers.IO) {
            runCatching { usageCards(context) }.getOrDefault(emptyList())
        }
    }
    // Written cards now come from cards.json — bundled for offline, replaced
    // from the repo when reachable, so the deck can change without a build.
    val written by produceState(initialValue = emptyList<DeckCard>(), context) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                CardFeed.forToday(CardFeed.refresh(context)).map { c ->
                    DeckCard(c.kicker, c.title, c.punch, c.body, stickerFor(c.tone))
                }
            }.getOrDefault(emptyList())
        }
    }
    val deck = remember(live, written) {
        // DECK is the last-resort fallback: only used when the file failed to
        // load at all, so an offline first run is never an empty screen.
        live + written.ifEmpty { DECK }
    }
    val state = rememberPagerState(pageCount = { deck.size })

    LaunchedEffect(state.currentPage) { haptics.tick() }

    Column(modifier) {
        HorizontalPager(
            state = state,
            contentPadding = PaddingValues(end = 42.dp),
            pageSpacing = 12.dp,
        ) { page ->
            val card = deck[page]

            // How far this page is from settled, 0 when centred and 1 when a
            // full page away. Everything below is driven off it.
            val offset = (
                (state.currentPage - page) + state.currentPageOffsetFraction
                ).absoluteValue.coerceIn(0f, 1f)

            Column(
                Modifier
                    .graphicsLayer {
                        val scale = 1f - offset * 0.12f
                        scaleX = scale
                        scaleY = scale
                        rotationY = offset * 22f
                        // Without a raised camera distance the rotation looks
                        // like a fish-eye lens instead of a turning card.
                        cameraDistance = 18f * density
                        alpha = 1f - offset * 0.35f
                    }
                    .fillMaxWidth()
                    .height(250.dp)
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .background(card.sticker.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                    .padding(18.dp),
            ) {
                Text(
                    card.kicker,
                    style = MaterialTheme.typography.labelSmall,
                    color = card.sticker.on.copy(alpha = 0.7f),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    card.punch,
                    style = MaterialTheme.typography.headlineSmall,
                    color = card.sticker.on,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    card.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = card.sticker.on.copy(alpha = 0.75f),
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    card.body,
                    style = MaterialTheme.typography.bodyLarge,
                    color = card.sticker.on.copy(alpha = 0.88f),
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
        ) {
            repeat(DECK.size) { i ->
                val on = state.currentPage == i
                Box(
                    Modifier
                        .padding(horizontal = 3.dp)
                        .size(width = if (on) 18.dp else 7.dp, height = 7.dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (on) Ink else InkLow)
                )
            }
        }
    }
}
