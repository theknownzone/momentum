package com.momentum.focus.ai

import android.content.Context
import com.momentum.focus.data.AppData
import com.momentum.focus.data.ScreenTime
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import org.json.JSONObject
import java.time.LocalDate

/**
 * A weekly read of the user's own numbers.
 *
 * This is the half of the AI work that is worth having. A doubt solver answers
 * questions any chatbot could; this one can only be written here, because the
 * facts it stands on — which subject went untouched for a month, what hour the
 * urges land, how many sessions were abandoned before the bar — live in this
 * app and nowhere else.
 *
 * It runs at most once a week and produces a card, not a conversation. That is
 * deliberate: a report cannot become the thing you scroll instead of studying.
 */
@Serializable
data class CoachReport(
    val headline: String = "",
    val findings: List<String> = emptyList(),
    val actions: List<String> = emptyList(),
    val generatedAtMs: Long = 0L,
) {
    val isEmpty: Boolean get() = headline.isBlank() && findings.isEmpty()
}

object Coach {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    /** A week between runs. The data underneath barely moves faster than that. */
    const val MIN_GAP_MS = 7L * 24 * 3600_000

    /** Below this there is nothing to see, and a confident answer would be a lie. */
    const val MIN_SESSIONS = 5

    fun canRun(data: AppData, lastAtMs: Long, nowMs: Long = System.currentTimeMillis()): Boolean =
        Ai.enabled &&
            data.sessions.count { it.completed } >= MIN_SESSIONS &&
            nowMs - lastAtMs >= MIN_GAP_MS

    /**
     * Everything the model is given, and nothing else.
     *
     * Counts and shapes only — no journal prose, no app names beyond the ones
     * already on the blocklist. The app's own promise is that what you write
     * stays on the phone, and a weekly summary is not a reason to start
     * shipping someone's diary somewhere.
     */
    fun summarise(context: Context, data: AppData): String {
        val today = LocalDate.now().toEpochDay()
        val recent = data.sessions.filter { today - it.startedAtEpochDay <= 30 }
        val done = recent.filter { it.completed }
        val abandoned = recent.size - done.size

        val perSubject = data.subjects.associateWith { subject ->
            done.filter { it.subject == subject }.sumOf { it.minutes }
        }
        val urgeHours = data.urges
            .filter { today - it.epochDay <= 30 }
            .groupBy { it.hour }
            .mapValues { it.value.size }
            .entries.sortedByDescending { it.value }.take(3)
        val heldRate = data.urges.takeIf { it.isNotEmpty() }
            ?.let { it.count { u -> u.survived } * 100 / it.size }

        val slipReasons = data.slips
            .groupBy { it.reason }
            .mapValues { it.value.size }
            .entries.sortedByDescending { it.value }.take(3)

        val screen = runCatching { ScreenTime.report(context) }.getOrNull()

        return buildString {
            appendLine("EXAM: ${data.examName.ifBlank { "not set" }}")
            data.daysToExam?.let { appendLine("DAYS LEFT: $it") }
            appendLine("SUBJECTS: ${data.subjects.joinToString().ifBlank { "none set" }}")
            appendLine("STREAK: ${data.streakDays} days")
            appendLine()
            appendLine("LAST 30 DAYS")
            appendLine("- sessions finished: ${done.size}")
            appendLine("- sessions abandoned: $abandoned")
            appendLine("- minutes studied: ${done.sumOf { it.minutes }}")
            perSubject.forEach { (subject, mins) ->
                appendLine("- $subject: $mins min")
            }
            if (urgeHours.isNotEmpty()) {
                appendLine("- urges by hour: " + urgeHours.joinToString {
                    "${it.key}:00 x${it.value}"
                })
            }
            heldRate?.let { appendLine("- urges resisted: $it%") }
            if (slipReasons.isNotEmpty()) {
                appendLine("- slip reasons: " + slipReasons.joinToString { "${it.key} x${it.value}" })
            }
            screen?.let {
                appendLine()
                appendLine("PHONE USE")
                appendLine("- daily average: ${it.averageMinutes} min")
                appendLine("- longest day: ${it.longestDayMinutes} min")
                appendLine("- pickups yesterday: ${it.pickups}")
            }
        }
    }

    private fun systemPrompt(data: AppData): String {
        val exam = data.examName.ifBlank { "their exam" }
        val subjects = data.subjects.joinToString().ifBlank { "their subjects" }
        return """
            You are reading one student's study data from Momentum, an app that
            pays them screen time for focused study. They are preparing for
            $exam. Their subjects are $subjects.

            Write a short weekly read of the numbers you are given.

            Rules:
            - Stay inside $exam and $subjects. Do not suggest Physics to a
              banking candidate or Reasoning to a medical one.
            - Every finding must point at a number in the data. If the data does
              not support a claim, leave the claim out. Never invent a figure.
            - No praise, no scolding, no motivational lines. This app does not
              cheer and does not lecture. State what happened and what follows.
            - Actions must be things they can do this week, tied to a subject or
              a time of day that appears in the data.
            - Plain English, short sentences, second person.
            - If the data is thin, say so plainly instead of padding.

            Reply with a JSON object only, no code fence, no prose:
            {"headline": "one sentence",
             "findings": ["2 to 4 short observations"],
             "actions": ["2 or 3 concrete steps"]}
        """.trimIndent()
    }

    suspend fun run(context: Context, data: AppData): CoachReport {
        val raw = Ai.ask(
            system = systemPrompt(data),
            user = summarise(context, data),
            maxTokens = 700,
            temperature = 0.3,
            json = true,
        )
        val obj = JSONObject(Ai.unfence(raw))
        fun list(key: String) = obj.optJSONArray(key)?.let { arr ->
            (0 until arr.length()).map { arr.getString(it) }.filter { it.isNotBlank() }
        }.orEmpty()

        return CoachReport(
            headline = obj.optString("headline").trim(),
            findings = list("findings"),
            actions = list("actions"),
            generatedAtMs = System.currentTimeMillis(),
        )
    }

    fun encode(report: CoachReport): String = json.encodeToString(report)

    fun decode(stored: String): CoachReport =
        if (stored.isBlank()) CoachReport()
        else runCatching { json.decodeFromString<CoachReport>(stored) }.getOrDefault(CoachReport())
}
