package com.momentum.focus.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Emerald
import com.momentum.focus.ui.util.Release
import com.momentum.focus.ui.util.Updater
import kotlinx.coroutines.launch

/**
 * Checks for a new build on launch and offers a one-tap install. This exists so
 * that shipping a fix does not require the user to touch GitHub at all — the
 * new APK simply appears in the app.
 */
@Composable
fun UpdateBanner(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var release by remember { mutableStateOf<Release?>(null) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { release = Updater.check(context) }

    val found = release
    AnimatedVisibility(
        visible = found != null,
        enter = fadeIn() + slideInVertically { -it },
        modifier = modifier,
    ) {
        if (found == null) return@AnimatedVisibility
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Emerald.accent.copy(alpha = 0.14f))
                .clickableNoRipple(remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) {
                    if (!busy) {
                        busy = true
                        scope.launch { Updater.downloadAndInstall(context, found); busy = false }
                    }
                }
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "UPDATE AVAILABLE",
                    style = MaterialTheme.typography.labelSmall,
                    color = Emerald.accent,
                )
                Text(
                    "Version ${found.version} — tap to install",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (busy) {
                CircularProgressIndicator(
                    Modifier.size(20.dp),
                    color = Emerald.accent,
                    strokeWidth = 2.dp,
                )
            }
        }
    }
}
