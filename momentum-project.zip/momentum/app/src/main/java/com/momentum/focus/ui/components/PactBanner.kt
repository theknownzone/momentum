package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Tang
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * Shown wherever the user might reach for a setting the pact will refuse.
 *
 * It ticks on its own clock. pactLive is derived from the wall clock and no
 * state changes when the lock runs out, so a banner that read the time once at
 * composition would sit there claiming to be locked long after it wasn't.
 */
@Composable
fun PactBanner(
    lockUntilEpochMs: Long,
    modifier: Modifier = Modifier,
) {
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(lockUntilEpochMs) {
        while (true) {
            delay(1_000)
            nowMs = System.currentTimeMillis()
        }
    }
    if (lockUntilEpochMs <= nowMs) return

    val until = remember(lockUntilEpochMs) {
        runCatching {
            DateTimeFormatter.ofPattern("HH:mm").format(
                Instant.ofEpochMilli(lockUntilEpochMs).atZone(ZoneId.systemDefault())
            )
        }.getOrDefault("--:--")
    }
    val leftMs = lockUntilEpochMs - nowMs
    val h = leftMs / 3_600_000L
    val m = (leftMs % 3_600_000L) / 60_000L

    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(Tang.fill)
            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Text(
            "PACT",
            style = MaterialTheme.typography.labelSmall,
            color = Tang.on,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            "Locked until $until — only extend",
            style = MaterialTheme.typography.headlineSmall,
            color = Tang.on,
        )
        Text(
            if (h > 0) "${h}h ${m}m baaki · level gira nahi sakte, shield off nahi kar sakte"
            else "${m.coerceAtLeast(1)} min baaki · level gira nahi sakte, shield off nahi kar sakte",
            style = MaterialTheme.typography.bodyMedium,
            color = Tang.on,
        )
    }
}
