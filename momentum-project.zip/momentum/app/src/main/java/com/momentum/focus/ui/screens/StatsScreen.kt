package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.momentum.focus.data.AppData
import com.momentum.focus.data.ScreenTime
import com.momentum.focus.data.ScreenTimeReport
import com.momentum.focus.ui.components.paperGrain
import androidx.compose.foundation.border
import com.momentum.focus.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The dashboard.
 *
 * The headline is time reclaimed against the baseline measured during setup,
 * not a streak. Streaks break and people quit; reclaimed hours only ever go up,
 * so there is nothing to lose and no reason to walk away after a bad day.
 */
@Composable
fun StatsScreen(data: AppData) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current

    var refresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) refresh++
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    // Reading a week of usage stats is slow enough to drop frames on the main
    // thread, so it happens on IO and the screen renders around it.
    val report by produceState<ScreenTimeReport?>(null, refresh) {
        value = kotlinx.coroutines.withContext(Dispatchers.IO) {
            ScreenTime.report(context)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 20.dp, bottom = 28.dp),
    ) {
        Text("DASHBOARD", style = MaterialTheme.typography.labelSmall, color = InkMid)
        Text("Where it's going", style = MaterialTheme.typography.displayMedium, color = Ink)

        Spacer(Modifier.height(18.dp))

        val r = report
        if (r == null) {
            Loading()
            return@Column
        }

        ReclaimedCard(data, r)

        Spacer(Modifier.height(Paper.Gap))

        Row(horizontalArrangement = Arrangement.spacedBy(Paper.Gap)) {
            MiniStat("LEVEL", "${data.level}", "${data.xpIntoLevel}/600 xp", Butter, Modifier.weight(1f))
            MiniStat(
                "FOCUSED",
                "${data.earnedMinutes / 60}h",
                "${data.sessions.count { it.completed }} sessions",
                Mint,
                Modifier.weight(1f),
            )
        }

        Spacer(Modifier.height(Paper.Gap))

        WeekChart(r, data.baselineMinutes)

        if (r.topApps.isNotEmpty()) {
            Spacer(Modifier.height(22.dp))
            Text("WHERE IT GOES", style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(10.dp))
            val worst = r.topApps.first().minutes.coerceAtLeast(1)
            r.topApps.forEach { app ->
                val blocked = app.pkg in data.blockedPackages
                Column(Modifier.padding(bottom = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            app.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = Ink,
                            modifier = Modifier.weight(1f),
                        )
                        if (blocked) {
                            Box(
                                Modifier
                                    .padding(end = 8.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(Mint.fill)
                                    .border(2.dp, Ink, RoundedCornerShape(50))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    "blocked",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Mint.on,
                                )
                            }
                        }
                        Text(
                            "%dh %02dm".format(app.minutes / 60, app.minutes % 60),
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMid,
                        )
                    }
                    Spacer(Modifier.height(5.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Sunk)
                            .border(2.dp, Ink, RoundedCornerShape(50))
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(app.minutes.toFloat() / worst)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(50))
                                .background(if (blocked) Mint.fill else Tang.fill)
                        )
                    }
                }
            }
        }

        val split = remember(data) { data.subjectSplit() }
        if (split.isNotEmpty()) {
            Spacer(Modifier.height(22.dp))
            Text("BY SUBJECT", style = MaterialTheme.typography.labelSmall, color = InkMid)
            Text(
                "Last 30 days",
                style = MaterialTheme.typography.bodyMedium,
                color = InkMid,
            )
            Spacer(Modifier.height(10.dp))

            val top = split.first().second.coerceAtLeast(1)
            split.forEachIndexed { i, (name, mins) ->
                val sticker = stickerFor(i)
                val neglected = mins == 0
                Column(Modifier.padding(bottom = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            name,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (neglected) InkLow else Ink,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            if (neglected) "untouched" else "%dh %02dm".format(mins / 60, mins % 60),
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (neglected) Tang.accent else InkMid,
                        )
                    }
                    Spacer(Modifier.height(5.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Sunk)
                            .border(2.dp, Ink, RoundedCornerShape(50))
                    ) {
                        if (!neglected) {
                            Box(
                                Modifier
                                    .fillMaxWidth(mins.toFloat() / top)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(50))
                                    .background(sticker.fill)
                            )
                        }
                    }
                }
            }
        }

        if (data.slips.size >= 3) {
            Spacer(Modifier.height(Paper.Gap))
            val worst = SLIP_REASONS
                .map { it to data.regretRate(it) }
                .filter { it.second.second >= 2 }
                .maxByOrNull { (_, r) -> r.first.toFloat() / r.second }

            if (worst != null) {
                val (reason, rate) = worst
                val percent = (rate.first * 100 / rate.second)
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(Paper.CardRadius))
                        .background(Butter.fill)
                        .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                        .padding(16.dp)
                ) {
                    Text("YOUR PATTERN", style = MaterialTheme.typography.labelSmall, color = Butter.on)
                    Spacer(Modifier.height(6.dp))
                    // Computed from the user's own answers, not a guess. This
                    // is the one thing no other app can tell them.
                    Text(
                        "When you spend out of \"${reason.lowercase()}\", you regret it $percent% of the time.",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Butter.on,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Based on ${data.slips.size} answers you gave after the fact.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Butter.on.copy(alpha = 0.75f),
                    )
                }
            }
        }

        if (data.urges.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            val worstHour = data.urges.groupBy { it.hour }.maxByOrNull { it.value.size }?.key
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .background(Lilac.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                    .padding(16.dp)
            ) {
                Text("PATTERN", style = MaterialTheme.typography.labelSmall, color = Lilac.on)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Most urges hit around ${worstHour}:00. Put something there.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Lilac.on,
                )
            }
        }
    }
}

@Composable
private fun ReclaimedCard(data: AppData, report: ScreenTimeReport) {
    val baseline = data.baselineMinutes
    val today = report.dailyMinutes.lastOrNull() ?: 0
    val saved = (baseline - today).coerceAtLeast(0)
    val over = today > baseline && baseline > 0

    val animated by animateFloatAsState(saved.toFloat(), Motion.settle(), label = "saved")
    val minutes = animated.roundToInt()

    val sticker = if (over) Tang else Mint

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(sticker.fill)
            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
            .padding(18.dp)
    ) {
        Text(
            if (baseline == 0) "TODAY'S SCREEN TIME"
            else if (over) "OVER YOUR BASELINE"
            else "RECLAIMED TODAY",
            style = MaterialTheme.typography.labelSmall,
            color = sticker.on.copy(alpha = 0.75f),
        )
        Spacer(Modifier.height(8.dp))

        val headline = when {
            baseline == 0 -> "%dh %02dm".format(today / 60, today % 60)
            over -> "+%dh %02dm".format(abs(today - baseline) / 60, abs(today - baseline) % 60)
            else -> "%dh %02dm".format(minutes / 60, minutes % 60)
        }
        Text(headline, style = MaterialTheme.typography.displayLarge, color = sticker.on)

        Spacer(Modifier.height(6.dp))
        Text(
            if (baseline == 0)
                "Grant usage access to set a baseline."
            else
                "Baseline was %dh %02dm a day. Today: %dh %02dm.".format(
                    baseline / 60, baseline % 60, today / 60, today % 60
                ),
            style = MaterialTheme.typography.bodyMedium,
            color = sticker.on.copy(alpha = 0.8f),
        )
    }
}

@Composable
private fun WeekChart(report: ScreenTimeReport, baseline: Int) {
    val peak = (report.dailyMinutes.maxOrNull() ?: 60).coerceAtLeast(baseline).coerceAtLeast(60)
    val days = listOf("M", "T", "W", "T", "F", "S", "S")

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(CreamCard)
            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
            .padding(16.dp)
    ) {
        Text("LAST 7 DAYS", style = MaterialTheme.typography.labelSmall, color = InkMid)
        Spacer(Modifier.height(14.dp))

        Box(Modifier.fillMaxWidth().height(130.dp)) {
            if (baseline > 0) {
                // The baseline sits behind the bars as a line to beat. A chart
                // without it just shows numbers; with it, every bar is a result.
                Box(
                    Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomStart)
                        .padding(bottom = 130.dp * (baseline.toFloat() / peak))
                        .height(2.dp)
                        .background(Tang.accent)
                )
            }
            Row(
                Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                report.dailyMinutes.forEachIndexed { i, m ->
                    val frac by animateFloatAsState(
                        m.toFloat() / peak, Motion.bouncy(), label = "b$i"
                    )
                    val beat = baseline > 0 && m < baseline
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight(frac.coerceAtLeast(0.04f))
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (beat) Mint.fill else Tang.fill)
                            .border(2.dp, Ink, RoundedCornerShape(6.dp))
                    )
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            days.forEach {
                Text(
                    it,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Average %dh %02dm · red line is your baseline".format(
                report.averageMinutes / 60, report.averageMinutes % 60
            ),
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
        )
    }
}

@Composable
private fun MiniStat(
    label: String,
    value: String,
    caption: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(sticker.fill)
            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
            .padding(14.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = sticker.on.copy(alpha = 0.75f))
        Spacer(Modifier.height(6.dp))
        Text(value, style = MaterialTheme.typography.displayMedium, color = sticker.on)
        Text(caption, style = MaterialTheme.typography.bodyMedium, color = sticker.on.copy(alpha = 0.8f))
    }
}

@Composable
private fun Loading() {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(CreamCard)
            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Reading your week…", style = MaterialTheme.typography.titleMedium, color = Ink)
    }
}
