package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.StickerCard
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*

@Composable
fun StatsScreen(data: AppData) {
    val days = data.recentMinutes(14)
    val peak = (days.maxOrNull() ?: 0).coerceAtLeast(60)
    val weekTotal = days.takeLast(7).sum()
    val prevWeek = days.take(7).sum()
    val delta = weekTotal - prevWeek

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain(seed = 33, density = 2000, alpha = 0.045f)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 28.dp, bottom = 32.dp),
    ) {
        Text(
            "YOUR NUMBERS",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            "Last 14 days",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )

        Spacer(Modifier.height(20.dp))

        StickerCard(sticker = Cobalt, modifier = Modifier.fillMaxWidth()) {
            Text("FOCUS MINUTES PER DAY", style = MaterialTheme.typography.labelSmall, color = Cobalt.on)
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                days.forEachIndexed { i, minutes ->
                    val frac by animateFloatAsState(
                        targetValue = minutes.toFloat() / peak,
                        animationSpec = Motion.bouncy(),
                        label = "bar$i",
                    )
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight(frac.coerceAtLeast(0.03f))
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (i == days.lastIndex) Marigold.fill else Cobalt.on.copy(alpha = 0.35f))
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "peak ${peak}m · today highlighted",
                style = MaterialTheme.typography.bodyMedium,
                color = Cobalt.on.copy(alpha = 0.7f),
            )
        }

        Spacer(Modifier.height(Paper.Gap))

        Row(horizontalArrangement = Arrangement.spacedBy(Paper.Gap)) {
            StatSticker(
                label = "THIS WEEK",
                value = "${weekTotal / 60}h",
                caption = if (delta >= 0) "+${delta}m vs last" else "${delta}m vs last",
                sticker = if (delta >= 0) Jade else Blush,
                modifier = Modifier.weight(1f),
            )
            StatSticker(
                label = "SESSIONS",
                value = "${data.sessions.count { it.completed }}",
                caption = "all time",
                sticker = Grape,
                modifier = Modifier.weight(1f),
            )
        }

        Spacer(Modifier.height(Paper.Gap))

        Row(horizontalArrangement = Arrangement.spacedBy(Paper.Gap)) {
            StatSticker(
                label = "URGES BEATEN",
                value = "${data.urgesSurvived}",
                caption = "of ${data.urges.size} logged",
                sticker = Coral,
                modifier = Modifier.weight(1f),
            )
            StatSticker(
                label = "BEST STREAK",
                value = "${maxOf(data.bestStreak, data.streakDays)}",
                caption = "days",
                sticker = Marigold,
                modifier = Modifier.weight(1f),
            )
        }

        if (data.urges.isNotEmpty()) {
            Spacer(Modifier.height(Paper.Gap))
            val worstHour = data.urges.groupBy { it.hour }.maxByOrNull { it.value.size }?.key
            StickerCard(sticker = Jade, modifier = Modifier.fillMaxWidth()) {
                Text("PATTERN SPOTTED", style = MaterialTheme.typography.labelSmall, color = Jade.on)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Most urges hit around ${worstHour}:00. Plan something for that hour.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Jade.on,
                )
            }
        }
    }
}
