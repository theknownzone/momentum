package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.LocalSkin
import com.momentum.focus.ui.theme.Paper

/**
 * Frost only as a veil behind a solid paper card.
 * Never used as the whole screen (Shield stays cream).
 */
@Composable
fun FrostScrim(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(modifier.fillMaxSize()) {
        Box(
            Modifier
                .matchParentSize()
                .blur(22.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0x66FFFFFF),
                            Color(0x44140E08),
                        )
                    )
                )
        )
        Box(
            Modifier
                .matchParentSize()
                .background(Color(0x33000000))
        )
        content()
    }
}

@Composable
fun FrostSheet(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(Color(0xE6FBF3D5))
            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
    ) {
        content()
    }
}

@Composable
fun FrostPill(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    // A wash of the current skin under the white. Faint on purpose: the bar
    // sits under every screen, so it has to carry the theme without competing
    // with the tab that is selected. The tabs keep their own colours — those
    // identify the destination, which is not what a skin is for.
    val tint = LocalSkin.current.petal
    Box(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .background(tint.copy(alpha = 0.35f))
            .background(Color(0xCCFFFFFF))
            .border(2.dp, Ink.copy(alpha = 0.35f), RoundedCornerShape(22.dp)),
        contentAlignment = Alignment.Center,
        content = content,
    )
}
