package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import android.content.Intent
import android.provider.Settings
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.momentum.focus.data.AppData
import com.momentum.focus.data.FeedSurfaces
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.rememberHaptics

/**
 * The feeds inside apps you still need.
 *
 * Kept apart from the blocklist on purpose: that screen answers "which apps
 * are off", this one answers "which parts of an app are off". Mixing them made
 * the second question invisible, and the second question is the one most
 * people actually came for.
 */
@Composable
fun FeedGuardScreen(
    data: AppData,
    onToggleSurface: (String) -> Unit,
    onDone: () -> Unit,
) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val owner = LocalLifecycleOwner.current

    var refresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) refresh++
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val guardOn = remember(refresh) { Perms.isShortsGuardOn(context) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 24.dp),
    ) {
        Text("FEEDS", style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Text(
            "App khuli, feed band",
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            "YouTube pe lecture chalti rahegi, Shorts nahi. Instagram pe chat chalegi, " +
                "Reels nahi. Poori app band karne ki zaroorat nahi.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp),
        )

        Spacer(Modifier.height(18.dp))

        if (!guardOn) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .background(Tang.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.tick()
                        runCatching {
                            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                    }
                    .padding(16.dp),
            ) {
                Column {
                    Text(
                        "Ye sab abhi band hai",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Tang.on,
                    )
                    Text(
                        "Accessibility ON karo — tabhi app andar dekh paayegi ki Shorts " +
                            "khuli hai ya lecture. Tap karke Settings kholo.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Tang.on,
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        FeedSurfaces.all.groupBy { it.app }.forEach { (app, surfaces) ->
            Text(
                app.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            surfaces.forEach { s ->
                val on = s.key in data.blockedSurfaces
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Mint.fill else CreamCard)
                        .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onToggleSurface(s.key)
                        }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            s.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (on) Mint.on else Ink,
                        )
                        Text(
                            s.note,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (on) Mint.on.copy(alpha = 0.75f) else InkMid,
                        )
                    }
                    Text(
                        if (on) "BAND" else "CHALU",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (on) Mint.on else InkMid,
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        Text(
            "Ye sirf pact ke dauran chalta hai. Aur agar koi app apna update laakar " +
                "andar ka naam badal de, wo feed nikal sakti hai — tab batana, list " +
                "update karni hogi.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(16.dp))

        SquishButton(
            label = "Done",
            sticker = Emerald,
            modifier = Modifier.fillMaxWidth(),
        ) { haptics.confirm(); onDone() }
    }
}
