package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import android.content.Intent
import android.provider.Settings
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.momentum.focus.data.AppData
import com.momentum.focus.data.FeedSurfaces
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.rememberHaptics

/**
 * The feeds inside apps you still need.
 *
 * Kept apart from the blocklist on purpose: that screen answers "which apps
 * are off", this one answers "which parts of an app are off". Mixing them made
 * the second question invisible, and the second question is the one most
 * people actually came for.
 */
@Composable
fun FeedGuardScreen(
    data: AppData,
    onToggleSurface: (String) -> Unit,
    onDone: () -> Unit,
    onStudyOnly: (Boolean) -> Unit = {},
    onAddChannel: (String) -> Unit = {},
    onRemoveChannel: (String) -> Unit = {},
) {
    var newChannel by remember { mutableStateOf("") }
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val owner = LocalLifecycleOwner.current

    var refresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) refresh++
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val guardOn = remember(refresh) { Perms.isShortsGuardOn(context) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 24.dp),
    ) {
        Text("FEEDS", style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Text(
            "App khuli, feed band",
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            "YouTube pe lecture chalti rahegi, Shorts nahi. Instagram pe chat chalegi, " +
                "Reels nahi. Poori app band karne ki zaroorat nahi.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp),
        )

        Spacer(Modifier.height(18.dp))

        if (!guardOn) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .background(Tang.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.tick()
                        runCatching {
                            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                    }
                    .padding(16.dp),
            ) {
                Column {
                    Text(
                        "Ye sab abhi band hai",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Tang.on,
                    )
                    Text(
                        "Accessibility ON karo — tabhi app andar dekh paayegi ki Shorts " +
                            "khuli hai ya lecture. Tap karke Settings kholo.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Tang.on,
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        FeedSurfaces.all.groupBy { it.app }.forEach { (app, surfaces) ->
            Text(
                app.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            surfaces.forEach { s ->
                val on = s.key in data.blockedSurfaces
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Mint.fill else CreamCard)
                        .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onToggleSurface(s.key)
                        }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            s.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (on) Mint.on else Ink,
                        )
                        Text(
                            s.note,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (on) Mint.on.copy(alpha = 0.75f) else InkMid,
                        )
                    }
                    Text(
                        if (on) "BAND" else "CHALU",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (on) Mint.on else InkMid,
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        // Only worth saying when it is actually true. This used to sit here
        // permanently, so it read as "do this after every update" — which is
        // wrong, and is exactly the kind of standing instruction people learn
        // to ignore. The guard being off is the only time it matters.
        if (!guardOn) {
            Text(
                "Ek baar Accessibility OFF karke wapas ON karo",
                style = MaterialTheme.typography.headlineSmall,
                color = Ink,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Android service ki setting sirf ON karte waqt padhta hai. Isliye jab " +
                    "guard mein kuch naya judta hai, purani permission chalu toh dikhti " +
                    "hai par naya kaam nahi karti. Ye har update pe nahi — sirf tab jab " +
                    "yahan ye likha ho.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
        }

        Spacer(Modifier.height(20.dp))

        // Deliberately a watch-page check, not a feed overlay. Blurring rows in
        // a scrolling feed means chasing them as they move, and the lag flashes
        // the very video being hidden. Catching the video when it opens is a
        // single state change, which is why the rest of this guard is reliable.
        Text("STUDY ONLY", style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(Mint.fill.lit())
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Sirf study channels",
                    style = MaterialTheme.typography.titleMedium,
                    color = Mint.on,
                )
                Text(
                    "Baaki channel ka video khulte hi shield aa jayega",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mint.on.copy(alpha = 0.8f),
                )
            }
            Switch(
                checked = data.studyOnlyYouTube,
                onCheckedChange = { haptics.tick(); onStudyOnly(it) },
            )
        }

        if (data.studyOnlyYouTube) {
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = newChannel,
                    onValueChange = { newChannel = it.take(30) },
                    placeholder = { Text("Channel ka naam") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Mint.fill)
                        .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            if (newChannel.isNotBlank()) {
                                haptics.tap(); onAddChannel(newChannel); newChannel = ""
                            }
                        }
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                ) {
                    Text("Add", style = MaterialTheme.typography.titleMedium, color = Mint.on)
                }
            }

            if (data.allowedChannels.isEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Ek bhi channel nahi. Aise mein har video block ho jayega — " +
                        "pehle apne teachers ke naam daalo.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }

            data.allowedChannels.sorted().forEach { c ->
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(Paper.ChipRadius))
                        .background(CreamCard)
                        .border(2.dp, Ink, RoundedCornerShape(Paper.ChipRadius))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(c, style = MaterialTheme.typography.bodyLarge, color = Ink, modifier = Modifier.weight(1f))
                    Text(
                        "Hatao",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Tang.accent,
                        modifier = Modifier
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tap(); onRemoveChannel(c)
                            }
                            .padding(4.dp),
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                "Channel ka handle sabse pakka hai — YouTube pe video ke neeche " +
                    "@ ke saath jo likha hota hai, wahi. Poora naam bhi chalega: " +
                    "\"PW\" likhoge to \"PhysicsWallah\" bhi match karega.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Spacer(Modifier.height(20.dp))

        Text(
            "Feeds tabhi rukti hain jab Shield on ho. Aur agar koi app apna update " +
                "laakar andar ka naam badal de, wo feed nikal sakti hai — tab batana, " +
                "list update kar denge.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(16.dp))

        SquishButton(
            label = "Done",
            sticker = Emerald,
            modifier = Modifier.fillMaxWidth(),
        ) { haptics.confirm(); onDone() }
    }
}
