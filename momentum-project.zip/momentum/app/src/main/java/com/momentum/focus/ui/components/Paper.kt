package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Motion
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Sticker
import com.momentum.focus.ui.util.rememberHaptics
import com.momentum.focus.ui.util.rememberTilt
import com.momentum.focus.ui.util.tilt3d
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Film grain, rendered once into a bitmap and cached by drawWithCache.
 *
 * The first version redrew thousands of dots every frame, which froze the app
 * outright on a mid-range phone. This builds the texture only when the size
 * changes, so it is free per frame.
 */
fun Modifier.paperGrain(
    seed: Int = 7,
    density: Int = 500,
    alpha: Float = 0.05f,
) = this.drawWithCache {
    val w = size.width.toInt().coerceAtLeast(1)
    val h = size.height.toInt().coerceAtLeast(1)
    val texture = ImageBitmap(w, h)
    val canvas = androidx.compose.ui.graphics.Canvas(texture)
    val paint = Paint()
    val rng = Random(seed)
    repeat(density) {
        paint.color = Color.White.copy(alpha = alpha * rng.nextFloat())
        canvas.drawCircle(
            Offset(rng.nextFloat() * w, rng.nextFloat() * h),
            rng.nextFloat() * 1.2f,
            paint,
        )
    }
    onDrawBehind { drawImage(texture) }
}

/**
 * A dark card with a gradient body, a hairline lit edge, and a soft accent
 * bloom in one corner. It tilts in 3D with the phone.
 *
 * The hairline is the whole trick: a 1px border at ~14% white along the top
 * edge is what makes a flat rectangle read as a physical panel catching light.
 */
@Composable
fun StickerCard(
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val haptics = rememberHaptics()
    val tilt by rememberTilt()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()

    val squish by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = Motion.press(),
        label = "squish",
    )

    LaunchedEffect(pressed) { if (pressed) haptics.tap() }

    val shape = RoundedCornerShape(Paper.CardRadius)

    Box(
        modifier
            .scale(squish)
            .tilt3d(tilt, strength = 5f)
            .clip(shape)
            .background(sticker.brush)
            .border(1.dp, Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.02f))
            ), shape)
            .then(
                if (onClick != null) Modifier.clickableNoRipple(interaction) {
                    haptics.confirm(); onClick()
                } else Modifier
            )
    ) {
        // Bloom sits behind the content and shifts with the tilt, so the light
        // source feels fixed in the room while the card moves.
        Box(
            Modifier
                .size(200.dp)
                .offset(x = (-40).dp + (tilt.x * 18).dp, y = (-70).dp + (tilt.y * 18).dp)
                .background(sticker.bloom)
        )
        Column(Modifier.fillMaxWidth().padding(18.dp), content = content)
    }
}

/**
 * The streak ring. A gradient sweep plus a dimmed under-layer, so the arc has
 * a lit edge rather than reading as a flat progress bar.
 */
@Composable
fun StreakRing(
    days: Int,
    goal: Int,
    sticker: Sticker,
    modifier: Modifier = Modifier,
) {
    val tilt by rememberTilt()
    val progress by animateFloatAsState(
        targetValue = (days.toFloat() / goal).coerceIn(0f, 1f),
        animationSpec = Motion.settle(),
        label = "progress",
    )
    val counted by animateFloatAsState(
        targetValue = days.toFloat(),
        animationSpec = Motion.settle(),
        label = "count",
    )
    val track = MaterialTheme.colorScheme.surfaceVariant

    Box(
        modifier.size(240.dp).tilt3d(tilt, strength = 9f),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 16.dp.toPx()
            val inset = stroke / 2
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(inset, inset)

            drawArc(track, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))

            drawArc(sticker.accent.copy(alpha = 0.25f), -90f, 360f * progress, false,
                topLeft, arcSize, style = Stroke(stroke * 1.6f, cap = StrokeCap.Round))

            drawArc(
                Brush.sweepGradient(
                    listOf(sticker.accent.copy(alpha = 0.5f), sticker.accent, sticker.accent)
                ),
                -90f, 360f * progress, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round),
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                counted.roundToInt().toString(),
                style = MaterialTheme.typography.displayLarge,
                color = sticker.accent,
            )
            Text(
                "DAY STREAK",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Big primary action: solid accent, dark text, squish and tick on press. */
@Composable
fun SquishButton(
    label: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.95f else 1f, Motion.press(), label = "scale"
    )

    LaunchedEffect(pressed) { if (pressed) haptics.tick() }

    Box(
        modifier
            .scale(scale)
            .clip(RoundedCornerShape(Paper.ChipRadius))
            .background(sticker.accent)
            .clickableNoRipple(interaction) { haptics.confirm(); onClick() }
            .padding(horizontal = 26.dp, vertical = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium, color = Color(0xFF0A0A0C))
    }
}
