package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Motion
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Sticker
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Fibre grain. Thousands of 1px specks at very low alpha, seeded so they never
 * re-randomise on recomposition. This is the single detail that turns a flat
 * beige rectangle into something that reads as paper.
 */
fun Modifier.paperGrain(
    seed: Int = 7,
    density: Int = 1400,
    alpha: Float = 0.035f,
) = this.drawBehind {
    val rng = Random(seed)
    repeat(density) {
        val x = rng.nextFloat() * size.width
        val y = rng.nextFloat() * size.height
        drawCircle(
            color = Color.Black.copy(alpha = alpha * rng.nextFloat()),
            radius = rng.nextFloat() * 1.4f,
            center = Offset(x, y),
        )
    }
}

/**
 * A card that looks cut out of coloured paper and dropped on the page: hard
 * offset edge underneath, no blur. Blurred shadows read as glass; hard offsets
 * read as physical objects.
 */
@Composable
fun StickerCard(
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()

    // Pressing pushes the card down into its own shadow.
    val lift by animateFloatAsState(
        targetValue = if (pressed) 0.25f else 1f,
        animationSpec = Motion.press(),
        label = "lift",
    )
    val squish by animateFloatAsState(
        targetValue = if (pressed) 0.975f else 1f,
        animationSpec = Motion.press(),
        label = "squish",
    )

    LaunchedEffect(pressed) { if (pressed) haptics.tap() }

    val shape = RoundedCornerShape(Paper.CardRadius)
    val offset = Paper.StickerOffset

    Box(modifier = modifier.scale(squish)) {
        Box(
            Modifier
                .matchParentSize()
                .offset(x = offset * lift, y = offset * lift)
                .clip(shape)
                .background(sticker.edge)
        )
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(sticker.fill)
                .paperGrain(seed = sticker.fill.value.toInt())
                .then(
                    if (onClick != null) Modifier.clickableNoRipple(interaction) {
                        haptics.confirm(); onClick()
                    } else Modifier
                )
                .padding(18.dp),
            content = content,
        )
    }
}

/**
 * The streak ring. Two things make it feel good: the sweep springs to its
 * target instead of tweening, and the number counts up rather than snapping.
 */
@Composable
fun StreakRing(
    days: Int,
    goal: Int,
    sticker: Sticker,
    modifier: Modifier = Modifier,
) {
    val progress by animateFloatAsState(
        targetValue = (days.toFloat() / goal).coerceIn(0f, 1f),
        animationSpec = Motion.settle(),
        label = "progress",
    )
    val counted by animateFloatAsState(
        targetValue = days.toFloat(),
        animationSpec = Motion.settle(),
        label = "count",
    )
    val track = MaterialTheme.colorScheme.surfaceVariant

    Box(modifier.size(230.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 20.dp.toPx()
            val inset = stroke / 2
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(inset, inset)

            drawArc(track, -90f, 360f, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            // Edge colour drawn slightly thicker underneath gives the arc a
            // printed, two-tone look instead of a flat progress bar.
            drawArc(sticker.edge, -90f, 360f * progress, false,
                topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(sticker.fill, -90f, 360f * progress, false,
                topLeft.copy(y = topLeft.y - 2.dp.toPx()), arcSize,
                style = Stroke(stroke * 0.72f, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                counted.roundToInt().toString(),
                style = MaterialTheme.typography.displayLarge,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                "DAY STREAK",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
    }
}

/** Big primary action. Squishes on press, thunks on release. */
@Composable
fun SquishButton(
    label: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.94f else 1f, Motion.press(), label = "scale"
    )

    LaunchedEffect(pressed) { if (pressed) haptics.tick() }

    Box(
        modifier
            .scale(scale)
            .clip(RoundedCornerShape(Paper.ChipRadius))
            .background(sticker.fill)
            .clickableNoRipple(interaction) { haptics.confirm(); onClick() }
            .padding(horizontal = 26.dp, vertical = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium, color = sticker.on)
    }
}
