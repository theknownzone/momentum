package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.CircleShape
import com.momentum.focus.ui.theme.GridLine
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Motion
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Sticker
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.roundToInt

/**
 * The printed grid. Drawn once into a cached bitmap, so it costs nothing per
 * frame even while a timer is ticking.
 */
fun Modifier.paperGrain(
    seed: Int = 7,
    density: Int = 40,
    alpha: Float = 1f,
) = this.drawWithCache {
    val step = 40.dp.toPx()
    onDrawBehind {
        var x = 0f
        while (x < size.width) {
            drawLine(GridLine, Offset(x, 0f), Offset(x, size.height), 1f)
            x += step
        }
        var y = 0f
        while (y < size.height) {
            drawLine(GridLine, Offset(0f, y), Offset(size.width, y), 1f)
            y += step
        }
    }
}

/**
 * A flat colour block with a hard black outline and a rivet in each corner —
 * the enamel-sign look. No gradient, no shadow: the outline alone does the
 * work, which is why it must never get thinner.
 */
@Composable
fun StickerCard(
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val squish by animateFloatAsState(
        targetValue = if (pressed) 0.975f else 1f,
        animationSpec = Motion.press(),
        label = "squish",
    )

    LaunchedEffect(pressed) { if (pressed) haptics.tap() }

    val shape = RoundedCornerShape(Paper.CardRadius)

    Box(
        modifier
            .scale(squish)
            .clip(shape)
            .background(sticker.fill)
            .border(Paper.Outline, Ink, shape)
            .then(
                if (onClick != null) Modifier.clickableNoRipple(interaction) {
                    haptics.confirm(); onClick()
                } else Modifier
            )
    ) {
        Rivets()
        Column(Modifier.fillMaxWidth().padding(16.dp), content = content)
    }
}

@Composable
private fun BoxScope.Rivets() {
    listOf(
        Alignment.TopStart, Alignment.TopEnd,
        Alignment.BottomStart, Alignment.BottomEnd,
    ).forEach { corner ->
        Box(
            Modifier
                .align(corner)
                .padding(9.dp)
                .size(5.dp)
                .clip(CircleShape)
                .background(Ink)
        )
    }
}

/**
 * The streak ring. A gradient sweep plus a dimmed under-layer, so the arc has
 * a lit edge rather than reading as a flat progress bar.
 */
@Composable
fun StreakRing(
    days: Int,
    goal: Int,
    sticker: Sticker,
    modifier: Modifier = Modifier,
) {
    val progress by animateFloatAsState(
        targetValue = (days.toFloat() / goal).coerceIn(0f, 1f),
        animationSpec = Motion.settle(),
        label = "progress",
    )
    val counted by animateFloatAsState(
        targetValue = days.toFloat(),
        animationSpec = Motion.settle(),
        label = "count",
    )
    val track = MaterialTheme.colorScheme.surfaceVariant

    Box(
        modifier.size(240.dp),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 16.dp.toPx()
            val inset = stroke / 2
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(inset, inset)

            drawArc(track, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))

            drawArc(Ink, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke + 6f, cap = StrokeCap.Round))
            drawArc(track, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(Ink, -90f, 360f * progress, false, topLeft, arcSize,
                style = Stroke(stroke + 6f, cap = StrokeCap.Round))
            drawArc(sticker.fill, -90f, 360f * progress, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                counted.roundToInt().toString(),
                style = MaterialTheme.typography.displayLarge,
                color = Ink,
            )
            Text(
                "DAY STREAK",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Big primary action: solid accent, dark text, squish and tick on press. */
@Composable
fun SquishButton(
    label: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.95f else 1f, Motion.press(), label = "scale"
    )

    LaunchedEffect(pressed) { if (pressed) haptics.tick() }

    Box(
        modifier
            .scale(scale)
            .clip(RoundedCornerShape(Paper.ChipRadius))
            .background(sticker.fill)
            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.ChipRadius))
            .clickableNoRipple(interaction) { haptics.confirm(); onClick() }
            .padding(horizontal = 26.dp, vertical = 15.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium, color = sticker.on)
    }
}
