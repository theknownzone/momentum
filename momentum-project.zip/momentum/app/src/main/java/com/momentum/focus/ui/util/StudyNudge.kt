package com.momentum.focus.ui.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import com.momentum.focus.MainActivity
import com.momentum.focus.R

/**
 * Offers to start the timer when someone is clearly already studying.
 *
 * The timer has to be remembered, and it is remembered least at the exact
 * moment it matters — someone opens their lecture app, gets absorbed, and
 * forty minutes later finds nothing was banked because nothing was running.
 * The app knows the foreground package every 350ms; it just never used that to
 * offer anything.
 *
 * The whole design problem here is not detection, it is restraint. A prompt on
 * every launch of a study app becomes noise within a day and gets switched off,
 * and then it helps nobody. So it waits until someone has genuinely settled in,
 * asks at most once an hour, and never interrupts a session that is already
 * running.
 */
object StudyNudge {

    private const val CHANNEL = "momentum_nudge"
    private const val ID = 79

    /** Opened briefly to check one thing is not studying. */
    private const val SETTLE_MS = 3 * 60_000L

    /** Asked and ignored means the answer was no for a while. */
    private const val COOLDOWN_MS = 60 * 60_000L

    const val ACTION_START = "com.momentum.focus.START_FROM_NUDGE"

    @Volatile private var since = 0L
    @Volatile private var lastAsked = 0L
    @Volatile private var lastPkg: String? = null

    /**
     * Called from the foreground poll with whatever is on screen.
     *
     * @param studying true while a session is already running
     */
    fun onForeground(
        context: Context,
        pkg: String?,
        studyPackages: Set<String>,
        studying: Boolean,
    ) {
        val now = System.currentTimeMillis()

        if (pkg != lastPkg) {
            lastPkg = pkg
            since = now
        }
        if (pkg == null || pkg !in studyPackages) return
        // Asking while the clock is already running would be the app failing to
        // notice its own state, which is worse than not asking at all.
        if (studying) return
        if (now - since < SETTLE_MS) return
        if (now - lastAsked < COOLDOWN_MS) return

        lastAsked = now
        show(context)
    }

    /** Forgets the streak, so leaving and returning starts the clock again. */
    fun reset() {
        since = 0L
        lastPkg = null
    }

    private fun show(context: Context) {
        if (!canPost(context)) return
        ensureChannel(context)

        val start = PendingIntent.getActivity(
            context,
            3,
            Intent(context, MainActivity::class.java)
                .setAction(ACTION_START)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Padh rahe ho?")
            .setContentText("Timer chalu kar do, warna ye minute count nahi honge.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(start)
            .addAction(0, "Timer chalu karo", start)
            .build()

        runCatching { NotificationManagerCompat.from(context).notify(ID, n) }
    }

    fun clear(context: Context) {
        runCatching { NotificationManagerCompat.from(context).cancel(ID) }
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = context.getSystemService<NotificationManager>() ?: return
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL,
                "Start reminder",
                // DEFAULT rather than HIGH: this is an offer, not an alarm.
                // A heads-up banner over someone's lecture would be the app
                // interrupting exactly the thing it wants to encourage.
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Offers to start a session when you are already studying"
                setShowBadge(false)
            }
        )
    }

    private fun canPost(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
}
