package com.momentum.focus.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ---- Paper -----------------------------------------------------------------
// Butter-yellow page with a printed grid, like an engineer's notebook.
val Cream     = Color(0xFFFBF3D5)
val CreamCard = Color(0xFFFFFDF2)
val GridLine  = Color(0xFFE8D98E)
val Sunk      = Color(0xFFF2E7BE)

// ---- Ink -------------------------------------------------------------------
// One near-black used for every border and every heading. Consistency of the
// outline is what makes the whole screen read as a single printed object.
val Ink    = Color(0xFF1A1A1A)
val InkMid = Color(0xFF8A7A3E)
val InkLow = Color(0xFFB0A26A)

/**
 * A block of colour with a hard black outline.
 *
 * `fill` is the flat colour, `on` is the text that sits on it — always a very
 * dark shade of the same hue, never pure black, so the block still reads as
 * coloured rather than as a hole in the page.
 */
data class Sticker(
    val fill: Color,
    val edge: Color,
    val on: Color,
    val accent: Color = fill,
) {
    val brush: Brush get() = Brush.linearGradient(listOf(fill, fill))
    val bloom: Brush get() = Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
}

val Mint   = Sticker(Color(0xFF3FE28F), Ink, Color(0xFF0B3D26), Color(0xFF1D9E55))
val Butter = Sticker(Color(0xFFFFD84D), Ink, Color(0xFF4A3600), Color(0xFF8A6400))
val Tang   = Sticker(Color(0xFFFF8A5C), Ink, Color(0xFF4A1B08), Color(0xFFB24A1E))
val Lilac  = Sticker(Color(0xFFB9A7FF), Ink, Color(0xFF231457), Color(0xFF5A3FC0))
val Sky    = Sticker(Color(0xFF7FD4FF), Ink, Color(0xFF073048), Color(0xFF1A6E96))
val Candy  = Sticker(Color(0xFFFF9EC4), Ink, Color(0xFF4A0F2A), Color(0xFFB2306A))

// Old names kept so every screen keeps compiling.
val Emerald = Mint
val Gold = Butter
val Violet = Lilac
val Ember = Tang
val Ice = Sky
val Rose = Candy
val Jade = Mint
val Marigold = Butter
val Grape = Lilac
val Coral = Tang
val Cobalt = Sky
val Blush = Candy

val StickerCycle = listOf(Mint, Butter, Tang, Lilac, Sky, Candy)

fun stickerFor(seed: Int): Sticker = StickerCycle[Math.floorMod(seed, StickerCycle.size)]
