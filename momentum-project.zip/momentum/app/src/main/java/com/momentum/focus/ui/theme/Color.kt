package com.momentum.focus.ui.theme

import androidx.compose.ui.graphics.Color

// ---- Paper surfaces -------------------------------------------------------
// Warm, slightly yellowed off-white. Never pure #FFFFFF — pure white looks
// like a screen, this looks like a page.
val PaperLight      = Color(0xFFFAF6EF)
val PaperLightRaise = Color(0xFFFFFDF8)
val PaperLightSunk  = Color(0xFFF2ECE1)

// Dark mode = ink-stained paper, not black.
val PaperDark       = Color(0xFF17150F)
val PaperDarkRaise  = Color(0xFF201D16)
val PaperDarkSunk   = Color(0xFF100E09)

// ---- Ink (text) -----------------------------------------------------------
val InkStrong  = Color(0xFF1C1810)
val InkMuted   = Color(0xFF6B6355)
val InkFaint   = Color(0xFF9C9384)

val InkStrongD = Color(0xFFF5EFE3)
val InkMutedD  = Color(0xFFB0A794)
val InkFaintD  = Color(0xFF7A7263)

// ---- Sticker colors -------------------------------------------------------
// Each accent is a pair: a saturated "cut paper" fill and a deeper edge used
// for the offset shadow. This pairing is what sells the paper-cutout look.
data class Sticker(val fill: Color, val edge: Color, val on: Color)

val Coral   = Sticker(Color(0xFFFF7A5C), Color(0xFFC64A2F), Color(0xFF3D0F04))
val Marigold= Sticker(Color(0xFFFFC24B), Color(0xFFC98D18), Color(0xFF402B00))
val Jade    = Sticker(Color(0xFF3FCF9B), Color(0xFF1E9A6E), Color(0xFF00301F))
val Cobalt  = Sticker(Color(0xFF5B8CFF), Color(0xFF2C58C4), Color(0xFF03133F))
val Grape   = Sticker(Color(0xFFA57BFF), Color(0xFF6F45CC), Color(0xFF1D0A45))
val Blush   = Sticker(Color(0xFFFF8FB1), Color(0xFFCC5A7D), Color(0xFF42101F))

/** Rotating palette so streak cards, subjects and habits each get an identity. */
val StickerCycle = listOf(Coral, Marigold, Jade, Cobalt, Grape, Blush)

fun stickerFor(seed: Int): Sticker = StickerCycle[Math.floorMod(seed, StickerCycle.size)]
