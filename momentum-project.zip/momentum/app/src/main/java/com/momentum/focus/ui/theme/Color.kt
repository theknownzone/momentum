package com.momentum.focus.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ---- Surfaces -------------------------------------------------------------
// Near-black, but never #000000. Pure black kills depth because shadows have
// nowhere left to go.
val Void      = Color(0xFF08080A)
val Charcoal  = Color(0xFF121216)
val Slate     = Color(0xFF1A1A20)
val SlateHigh = Color(0xFF232330)

// ---- Text -----------------------------------------------------------------
val Chalk = Color(0xFFF2F2F5)
val Ash   = Color(0xFF9A9AAA)
val Dim   = Color(0xFF5C5C6B)

/**
 * A card identity. The body stays dark; the accent carries the meaning and the
 * glow. That split is what premium fintech UIs do -- colour as light source
 * rather than colour as paint.
 */
data class Sticker(
    val fill: Color,
    val edge: Color,
    val on: Color,
    val accent: Color = on,
) {
    val brush: Brush get() = Brush.linearGradient(listOf(fill, edge))
    val bloom: Brush
        get() = Brush.radialGradient(listOf(accent.copy(alpha = 0.20f), Color.Transparent))
}

val Emerald = Sticker(Color(0xFF16241F), Color(0xFF0D1512), Chalk, Color(0xFF2BE39B))
val Gold    = Sticker(Color(0xFF241E12), Color(0xFF15110A), Chalk, Color(0xFFF5C451))
val Violet  = Sticker(Color(0xFF1D1830), Color(0xFF110E1D), Chalk, Color(0xFF9D7BFF))
val Ember   = Sticker(Color(0xFF2A1714), Color(0xFF170C0A), Chalk, Color(0xFFFF7A5C))
val Ice     = Sticker(Color(0xFF12202B), Color(0xFF0A1319), Chalk, Color(0xFF4CC9F0))
val Rose    = Sticker(Color(0xFF2A1620), Color(0xFF170C12), Chalk, Color(0xFFFF6E9C))

// Old names kept so the existing screens keep compiling.
val Jade     = Emerald
val Marigold = Gold
val Grape    = Violet
val Coral    = Ember
val Cobalt   = Ice
val Blush    = Rose

val StickerCycle = listOf(Emerald, Gold, Violet, Ember, Ice, Rose)

fun stickerFor(seed: Int): Sticker = StickerCycle[Math.floorMod(seed, StickerCycle.size)]
