package com.momentum.focus.data

import kotlinx.serialization.Serializable
import java.time.LocalDate
import java.time.LocalDateTime

@Serializable
data class FocusSession(
    val startedAtEpochDay: Long,
    val minutes: Int,
    val subject: String,
    val completed: Boolean,
    /**
     * The earn ratio in force when this session was banked.
     *
     * Rupees used to be worked out from lifetime minutes divided by whatever
     * ratio happened to be current, which meant the whole wallet was repriced
     * every time the user changed focus level or the weekend arrived. Dropping
     * from Hard to Soft tripled a balance that had already been earned. A
     * session is priced once, when it is banked, and never again.
     */
    val ratio: Int = 8,
)

@Serializable
data class UrgeEvent(
    val epochDay: Long,
    val hour: Int,
    val survived: Boolean,
    val note: String = "",
)

@Serializable
data class JournalEntry(
    val epochDay: Long,
    val mood: Int,          // 1..5
    val text: String,
    val trigger: String = "",
)

@Serializable
data class Slip(
    val epochDay: Long,
    val reason: String,
    val regretted: Boolean,
)


/**
 * A named set of rules the user can switch between.
 *
 * One blocklist could not describe a real week. WhatsApp has to go at
 * midnight and come back at eight; a Sunday needs less than a Monday. Without
 * this the only way to get either was to edit the list by hand twice a day,
 * which nobody does, so people set one harsh list and turned the app off
 * instead.
 *
 * A profile is a snapshot, not a live link. Activating one copies its values
 * into the live settings; editing the live settings afterwards does not write
 * back. That keeps "what is switched on right now" a single answer rather than
 * something assembled from a profile plus overrides.
 */
@Serializable
data class BlockProfile(
    val id: String,
    val name: String,
    val blockedPackages: Set<String> = emptySet(),
    val dailyCapMinutes: Map<String, Int> = emptyMap(),
    val blockedSurfaces: Set<String> = emptySet(),
    val classHoursOn: Boolean = true,
    val classDays: Set<Int> = setOf(1, 2, 3, 4, 5, 6),
    val profiles: List<BlockProfile> = emptyList(),
    /** Which profile's rules are loaded, for display only. Empty means custom. */
    val activeProfileId: String = "",
    val classStartHour: Int = 6,
    val classEndHour: Int = 22,
)

@Serializable
data class AppData(
    val userName: String = "friend",
    val streakStartEpochDay: Long = LocalDate.now().toEpochDay(),
    val bestStreak: Int = 0,
    val streakGoal: Int = 90,
    val sessions: List<FocusSession> = emptyList(),
    val urges: List<UrgeEvent> = emptyList(),
    val journal: List<JournalEntry> = emptyList(),
    /**
     * Empty until the user names them.
     *
     * Defaulting to Physics/Maths/Chemistry quietly decided the app was for
     * science students. A commerce student saw three subjects they do not
     * study, a UPSC aspirant saw school subjects, and both got told their
     * Physics was "untouched in 30 days" — a reproach for not studying
     * something they never signed up for. Blank asks instead of assuming.
     */
    val subjects: List<String> = emptyList(),
    val onboarded: Boolean = false,
    val spentMinutes: Int = 0,
    val blockedPackages: Set<String> = emptySet(),
    val shieldOn: Boolean = false,
    val avatarSymbol: String = "",
    val avatarColor: Int = 3,
    val avatarShape: Int = 0,
    val skin: Int = 0,
    val lastSeenVersion: String = "",
    val lastSeenChangelog: Int = 0,
    /** Minutes of study needed to earn one minute of distraction. */
    val earnRatio: Int = 8,
    val focusLevel: Int = 2,
    val crownMode: Boolean = false,
    val studyPackages: Set<String> = emptySet(),
    val studyXp: Int = 0,
    val guessHours: Int = 0,
    val guessPickups: Int = 0,
    val baselineMinutes: Int = 0,
    val examName: String = "",
    val examEpochDay: Long = 0L,
    /** Crown mode switches itself on inside this many days of the exam. */
    val examCrownDays: Int = 30,
    val weekendRelaxed: Boolean = true,
    val classHoursOn: Boolean = true,
    /**
     * Weekdays the class-hours window applies to, 1 = Monday through 7 =
     * Sunday. A single window with no day filter meant Sunday was policed like
     * a school day, which is the fastest way to get the whole feature switched
     * off. Default is Mon-Sat, matching an Indian school week.
     */
    val classDays: Set<Int> = setOf(1, 2, 3, 4, 5, 6),
    val profiles: List<BlockProfile> = emptyList(),
    /** Which profile's rules are loaded, for display only. Empty means custom. */
    val activeProfileId: String = "",
    val classStartHour: Int = 6,
    val classEndHour: Int = 22,
    val lockUntilEpochMs: Long = 0L,
    /**
     * Which in-app feeds the guard shields, by FeedSurface key. Defaults are
     * applied at first run rather than here, so a user who turns everything
     * off does not have it all switch back on next launch.
     */
    val blockedSurfaces: Set<String> = emptySet(),
    val surfacesSeeded: Boolean = false,
    /**
     * package -> minutes allowed per day. Optional and empty by default; a cap
     * only ever tightens. Once a package is over its cap the shield fires for
     * the rest of the day regardless of the wallet, so paying cannot buy past
     * a limit the user set for themselves.
     */
    val dailyCapMinutes: Map<String, Int> = emptyMap(),
    val slips: List<Slip> = emptyList(),
    val lastCelebratedLevel: Int = 1,
    val lastCelebratedBadges: Int = 0,
    val pendingReflectionMinutes: Int = 0,
) {
    val pactLive: Boolean
        get() = lockUntilEpochMs > System.currentTimeMillis()

    /**
     * Consecutive days ending today or yesterday with real completed minutes.
     *
     * This used to be plain calendar arithmetic from a start date, which meant
     * it kept climbing for someone who had not opened a book in a month. A
     * streak that rises while you do nothing is the same lie as a fake usage
     * number, and it is worse here because the whole app is built on it.
     *
     * Today not being studied yet does not break the streak — it is only
     * broken once a full day has been missed.
     */
    val streakDays: Int
        get() {
            val today = LocalDate.now().toEpochDay()
            val studied = sessions.filter { it.completed && it.minutes > 0 }
                .map { it.startedAtEpochDay }
                .toSet()
            if (studied.isEmpty()) return 0
            // Start from today if it counts, otherwise from yesterday.
            var cursor = if (today in studied) today else today - 1
            if (cursor !in studied) return 0
            var count = 0
            // A logged relapse moves this floor to today, so the walk stops
            // there. Without it resetStreak had nothing left to reset and the
            // "I slipped" button silently did nothing.
            while (cursor in studied && cursor >= streakStartEpochDay) {
                count++
                cursor--
            }
            return count
        }

    fun minutesOn(day: Long): Int =
        sessions.filter { it.startedAtEpochDay == day && it.completed }.sumOf { it.minutes }

    val minutesToday: Int get() = minutesOn(LocalDate.now().toEpochDay())

    val sessionsToday: Int
        get() = sessions.count {
            it.startedAtEpochDay == LocalDate.now().toEpochDay() && it.completed
        }

    /** Minutes per day for the last [days] days, oldest first. */
    fun recentMinutes(days: Int): List<Int> {
        val today = LocalDate.now().toEpochDay()
        return (days - 1 downTo 0).map { minutesOn(today - it) }
    }

    val urgesSurvived: Int get() = urges.count { it.survived }

    /**
     * Minutes per subject over the last 30 days, biggest first.
     *
     * The subject you have been avoiding is invisible in a single total, and
     * it is almost always the one that decides the result.
     */
    fun subjectSplit(): List<Pair<String, Int>> {
        val cutoff = LocalDate.now().toEpochDay() - 30
        val byName = sessions
            .filter { it.completed && it.startedAtEpochDay >= cutoff }
            // A "Bas focus" session is filed with no subject. The Focus screen
            // promises it lands under General, so it has to have a name here or
            // the minutes vanish from the breakdown entirely.
            .groupBy { it.subject.ifBlank { "General" } }
            .mapValues { (_, list) -> list.sumOf { it.minutes } }
        // Subjects with no time still appear, at zero. A missing row reads as
        // "not tracked"; a zero row reads as "you have not touched this".
        val all = (subjects + byName.keys).distinct()
        return all.map { it to (byName[it] ?: 0) }.sortedByDescending { it.second }
    }

    /** Every completed minute of focus, for display. Not the wallet. */
    val earnedMinutes: Int get() = sessions.filter { it.completed }.sumOf { it.minutes }

    /**
     * What is left to spend on distraction.
     *
     * Each session is converted at the ratio it was banked at, so eight
     * minutes of study buys one minute of scrolling and stays bought. The
     * accumulation runs in hundredths so a run of short sessions is not
     * rounded away one at a time.
     */
    val earnedRupees: Int
        get() = sessions.filter { it.completed }
            .sumOf { (it.minutes * 100L) / it.ratio.coerceAtLeast(1) }
            .let { (it / 100L).toInt() }

    val balanceMinutes: Int
        get() = (earnedRupees - spentMinutes).coerceAtLeast(0)

    val level: Int get() = 1 + (studyXp / 600)
    val xpIntoLevel: Int get() = studyXp % 600

    val daysToExam: Int?
        get() = if (examEpochDay == 0L) null
                else (examEpochDay - LocalDate.now().toEpochDay()).toInt()

    val examIsClose: Boolean
        get() = daysToExam?.let { it in 0..examCrownDays } == true

    /** Saturday or Sunday, used to loosen the rules if the user allows it. */
    val isWeekend: Boolean
        get() = LocalDate.now().dayOfWeek.value >= 6

    val effectiveRatio: Int
        get() = if (weekendRelaxed && isWeekend) (earnRatio / 2).coerceAtLeast(1) else earnRatio

    /**
     * The share of slips the user later called a mistake, per reason. This is
     * the one number no other app has, because it needs a question asked after
     * the craving has passed rather than during it.
     */
    fun regretRate(reason: String): Pair<Int, Int> {
        val all = slips.filter { it.reason == reason }
        return all.count { it.regretted } to all.size
    }

    val todayJournal: JournalEntry?
        get() = journal.firstOrNull { it.epochDay == LocalDate.now().toEpochDay() }
}

fun nowHour(): Int = LocalDateTime.now().hour
