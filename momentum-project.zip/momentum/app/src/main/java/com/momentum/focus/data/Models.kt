package com.momentum.focus.data

import kotlinx.serialization.Serializable
import java.time.LocalDate
import java.time.LocalDateTime

@Serializable
data class FocusSession(
    val startedAtEpochDay: Long,
    val minutes: Int,
    val subject: String,
    val completed: Boolean,
)

@Serializable
data class UrgeEvent(
    val epochDay: Long,
    val hour: Int,
    val survived: Boolean,
    val note: String = "",
)

@Serializable
data class JournalEntry(
    val epochDay: Long,
    val mood: Int,          // 1..5
    val text: String,
    val trigger: String = "",
)

@Serializable
data class Slip(
    val epochDay: Long,
    val reason: String,
    val regretted: Boolean,
)

@Serializable
data class AppData(
    val userName: String = "friend",
    val streakStartEpochDay: Long = LocalDate.now().toEpochDay(),
    val bestStreak: Int = 0,
    val streakGoal: Int = 90,
    val sessions: List<FocusSession> = emptyList(),
    val urges: List<UrgeEvent> = emptyList(),
    val journal: List<JournalEntry> = emptyList(),
    val subjects: List<String> = listOf("Physics", "Maths", "Chemistry"),
    val onboarded: Boolean = false,
    val spentMinutes: Int = 0,
    val blockedPackages: Set<String> = emptySet(),
    val shieldOn: Boolean = false,
    val avatarSymbol: String = "",
    val avatarColor: Int = 3,
    val avatarShape: Int = 0,
    val skin: Int = 0,
    val lastSeenVersion: String = "",
    val lastSeenChangelog: Int = 0,
    /** Minutes of study needed to earn one minute of distraction. */
    val earnRatio: Int = 8,
    val focusLevel: Int = 2,
    val crownMode: Boolean = false,
    val studyPackages: Set<String> = emptySet(),
    val studyXp: Int = 0,
    val guessHours: Int = 0,
    val guessPickups: Int = 0,
    val baselineMinutes: Int = 0,
    val examName: String = "",
    val examEpochDay: Long = 0L,
    /** Crown mode switches itself on inside this many days of the exam. */
    val examCrownDays: Int = 30,
    val weekendRelaxed: Boolean = true,
    val classHoursOn: Boolean = true,
    val classStartHour: Int = 6,
    val classEndHour: Int = 22,
    val slips: List<Slip> = emptyList(),
    val lastCelebratedLevel: Int = 1,
    val lastCelebratedBadges: Int = 0,
    val pendingReflectionMinutes: Int = 0,
) {
    val streakDays: Int
        get() = (LocalDate.now().toEpochDay() - streakStartEpochDay).toInt().coerceAtLeast(0)

    fun minutesOn(day: Long): Int =
        sessions.filter { it.startedAtEpochDay == day && it.completed }.sumOf { it.minutes }

    val minutesToday: Int get() = minutesOn(LocalDate.now().toEpochDay())

    val sessionsToday: Int
        get() = sessions.count {
            it.startedAtEpochDay == LocalDate.now().toEpochDay() && it.completed
        }

    /** Minutes per day for the last [days] days, oldest first. */
    fun recentMinutes(days: Int): List<Int> {
        val today = LocalDate.now().toEpochDay()
        return (days - 1 downTo 0).map { minutesOn(today - it) }
    }

    val urgesSurvived: Int get() = urges.count { it.survived }

    /**
     * Minutes per subject over the last 30 days, biggest first.
     *
     * The subject you have been avoiding is invisible in a single total, and
     * it is almost always the one that decides the result.
     */
    fun subjectSplit(): List<Pair<String, Int>> {
        val cutoff = LocalDate.now().toEpochDay() - 30
        val byName = sessions
            .filter { it.completed && it.startedAtEpochDay >= cutoff }
            .groupBy { it.subject }
            .mapValues { (_, list) -> list.sumOf { it.minutes } }
        // Subjects with no time still appear, at zero. A missing row reads as
        // "not tracked"; a zero row reads as "you have not touched this".
        val all = (subjects + byName.keys).distinct()
        return all.map { it to (byName[it] ?: 0) }.sortedByDescending { it.second }
    }

    /** Every completed minute of focus is earned currency. */
    val earnedMinutes: Int get() = sessions.filter { it.completed }.sumOf { it.minutes }

    /**
     * What is left to spend on distraction.
     *
     * Earned minutes are divided by the ratio, so eight minutes of study buys
     * one minute of scrolling by default. A one-to-one trade would let anyone
     * bank a morning and lose the afternoon.
     */
    val balanceMinutes: Int
        get() = ((earnedMinutes / effectiveRatio.coerceAtLeast(1)) - spentMinutes).coerceAtLeast(0)

    val level: Int get() = 1 + (studyXp / 600)
    val xpIntoLevel: Int get() = studyXp % 600

    val daysToExam: Int?
        get() = if (examEpochDay == 0L) null
                else (examEpochDay - LocalDate.now().toEpochDay()).toInt()

    val examIsClose: Boolean
        get() = daysToExam?.let { it in 0..examCrownDays } == true

    /** Saturday or Sunday, used to loosen the rules if the user allows it. */
    val isWeekend: Boolean
        get() = LocalDate.now().dayOfWeek.value >= 6

    val effectiveRatio: Int
        get() = if (weekendRelaxed && isWeekend) (earnRatio / 2).coerceAtLeast(1) else earnRatio

    /**
     * The share of slips the user later called a mistake, per reason. This is
     * the one number no other app has, because it needs a question asked after
     * the craving has passed rather than during it.
     */
    fun regretRate(reason: String): Pair<Int, Int> {
        val all = slips.filter { it.reason == reason }
        return all.count { it.regretted } to all.size
    }

    val todayJournal: JournalEntry?
        get() = journal.firstOrNull { it.epochDay == LocalDate.now().toEpochDay() }
}

fun nowHour(): Int = LocalDateTime.now().hour
