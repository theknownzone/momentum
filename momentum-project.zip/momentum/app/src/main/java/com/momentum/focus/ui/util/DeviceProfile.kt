package com.momentum.focus.ui.util

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import androidx.core.content.getSystemService

/**
 * Cheap phones keep the same features. They drop petals, festival bitmaps
 * and long splash so 4 GB / Helio devices stay usable.
 */
object DeviceProfile {

    fun isLowEnd(context: Context): Boolean {
        val am = context.getSystemService<ActivityManager>() ?: return Build.VERSION.SDK_INT < 29
        if (am.isLowRamDevice) return true
        val mem = runCatching { ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) } }.getOrNull()
        val ramGb = (mem?.totalMem ?: 0L) / (1024L * 1024L * 1024L)
        return ramGb in 1..4 || Build.VERSION.SDK_INT < 29
    }
}
