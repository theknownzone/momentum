package com.momentum.focus.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Release
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.UpdateNotice
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Update card with a real install button and a real progress bar.
 *
 * The previous version was one big tappable strip with no button and no
 * feedback, so a tap anywhere started a silent download that looked like
 * nothing had happened. Here the button is the only tap target, the bar fills
 * with measured bytes, and the sound fires when the installer opens.
 */
@Composable
fun UpdateCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptics = rememberHaptics()

    var release by remember { mutableStateOf(Updater.cached) }
    var progress by remember { mutableFloatStateOf(-1f) }

    LaunchedEffect(Unit) {
        val found = Updater.check(context) ?: Updater.cached
        release = found
        if (found != null) UpdateNotice.show(context, found.version)
    }

    val found = release
    AnimatedVisibility(
        visible = found != null,
        enter = fadeIn() + slideInVertically { -it },
        modifier = modifier,
    ) {
        if (found == null) return@AnimatedVisibility
        val downloading = progress >= 0f
        val animated by animateFloatAsState(
            targetValue = progress.coerceAtLeast(0f),
            animationSpec = Motion.settle(),
            label = "dl",
        )

        FrostPill(
            Modifier.fillMaxWidth()
        ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                "UPDATE READY",
                style = MaterialTheme.typography.labelSmall,
                color = Butter.on.copy(alpha = 0.75f),
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Version ${found.version}",
                style = MaterialTheme.typography.headlineSmall,
                color = Butter.on,
            )
            Text(
                "Install ke baad list khulegi.",
                style = MaterialTheme.typography.bodyMedium,
                color = Butter.on.copy(alpha = 0.75f),
            )

            if (downloading) {
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(12.dp)
                        .clip(RoundedCornerShape(50))
                        .background(CreamCard)
                        .border(2.dp, Ink, RoundedCornerShape(50))
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(animated)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(50))
                            .background(Mint.fill)
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    if (animated >= 1f) "Opening installer…"
                    else "${(animated * 100).roundToInt()}%",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Butter.on,
                )
            } else {
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier
                        .clip(RoundedCornerShape(Paper.ChipRadius))
                        .background(Mint.fill)
                        .border(Paper.Outline, Ink, RoundedCornerShape(Paper.ChipRadius))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.confirm()
                            progress = 0f
                            scope.launch {
                                Updater.downloadAndInstall(context, found) { progress = it }
                                UpdateNotice.clear(context)
                                Sfx.play(Sound.SUCCESS)
                            }
                        }
                        .padding(horizontal = 22.dp, vertical = 11.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "Install now",
                        style = MaterialTheme.typography.titleMedium,
                        color = Mint.on,
                    )
                }
            }
        }
        }
    }
}
