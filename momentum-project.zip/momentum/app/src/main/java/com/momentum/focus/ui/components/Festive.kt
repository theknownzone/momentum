package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Paper
import kotlin.math.cos
import kotlin.math.sin

/**
 * A rakhi, drawn rather than shipped.
 *
 * The image that used to sit here was a stock greeting card with "Happy Raksha
 * Bandhan" baked into it, so cropping it behind the balance pushed half a word
 * of English across the number. Drawing it means no file to source, no
 * watermark to miss, no text to collide with, and it scales to any hero
 * without resampling.
 *
 * Built from the app's own vocabulary: flat fills, one hue at three
 * brightnesses, hard outlines. It reads as a rakhi without pretending to be a
 * photograph of one.
 */
fun DrawScope.rakhiMotif(
    cx: Float,
    cy: Float,
    radius: Float,
    thread: Color,
    petal: Color,
    centre: Color,
    outline: Color,
) {
    val stroke = radius * 0.09f

    // The thread, running off both edges so it reads as tied rather than
    // floating.
    drawLine(
        color = thread,
        start = Offset(cx - radius * 4.2f, cy + radius * 0.75f),
        end = Offset(cx + radius * 4.2f, cy - radius * 0.55f),
        strokeWidth = stroke * 0.9f,
        cap = StrokeCap.Round,
    )

    // Petals around the disc, evenly spaced so it stays symmetrical at any size.
    val petals = 8
    repeat(petals) { i ->
        val angle = (2.0 * Math.PI / petals) * i
        val px = cx + (radius * 0.92f) * cos(angle).toFloat()
        val py = cy + (radius * 0.92f) * sin(angle).toFloat()
        drawCircle(color = petal, radius = radius * 0.42f, center = Offset(px, py))
        drawCircle(
            color = outline,
            radius = radius * 0.42f,
            center = Offset(px, py),
            style = Stroke(width = stroke * 0.5f),
        )
    }

    drawCircle(color = centre, radius = radius, center = Offset(cx, cy))
    drawCircle(
        color = outline,
        radius = radius,
        center = Offset(cx, cy),
        style = Stroke(width = stroke),
    )
    drawCircle(color = petal, radius = radius * 0.38f, center = Offset(cx, cy))
}

/**
 * A card that reads as frosted glass over the paper behind it.
 *
 * Worth being precise about what this is, because the obvious approach does
 * not work: Compose's `Modifier.blur` blurs a composable's own content, never
 * what is behind it, and it is API 31+ while this app runs from 26. There is
 * no backdrop blur to reach for.
 *
 * What makes the effect possible here is that the background is known — a flat
 * cream with a faint grain. Layering a translucent white wash, a soft top-left
 * highlight and a hairline edge over a known colour produces the same read as
 * real frost, at no cost and on every API level. It would fall apart over a
 * photograph; over this page it does not.
 */
@Composable
fun FrostCard(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    radius: Dp = Paper.CardRadius,
    padding: Dp = 16.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(radius))
            // The tint has to stay faint. At the alpha a normal card uses it
            // reads as a solid colour with a white line round it, which is
            // what the first attempt shipped — a flat pink card that fooled
            // nobody. Glass is mostly the light on it, not the colour under.
            .background(tint.copy(alpha = 0.16f))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.72f),
                        Color.White.copy(alpha = 0.34f),
                        Color.White.copy(alpha = 0.52f),
                    )
                )
            )
            // A brighter sweep across the top left is what sells a curved
            // surface catching light; without it the panel looks printed.
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.55f),
                        Color.Transparent,
                    ),
                    start = Offset.Zero,
                    end = Offset(420f, 260f),
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.9f), RoundedCornerShape(radius))
            .padding(padding),
        content = content,
    )
}
