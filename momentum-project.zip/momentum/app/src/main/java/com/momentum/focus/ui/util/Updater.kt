package com.momentum.focus.ui.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class Release(
    val version: String,
    val apkUrl: String,
    val notes: String,
)

/**
 * Checks GitHub Releases for a newer build and installs it.
 *
 * Releases are used rather than Actions artifacts because artifacts require an
 * authenticated API token to download, while release assets are public. The CI
 * workflow publishes one release per successful build.
 */
object Updater {

    @Volatile
    var cached: Release? = null
        private set

    // Change this if the repo ever moves.
    private const val REPO = "theknownzone/momentum"
    private const val API = "https://api.github.com/repos/$REPO/releases/latest"

    fun currentVersion(context: Context): String = runCatching {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0"
    }.getOrDefault("0")

    /**
     * Download progress, held here rather than in the card.
     *
     * It used to live in the composable's own state, so switching tabs threw
     * the card away mid-download and it came back offering to start over — the
     * bytes were still arriving, the UI had just forgotten. Process-wide state
     * survives navigation because the download does.
     */
    var progress by mutableFloatStateOf(-1f)

    /**
     * Recent commit subjects, used when the release body is empty.
     *
     * Nothing writes those bodies — the workflow publishes and GitHub appends
     * only a compare link — so the app fell back to a list baked into the APK,
     * which is exactly the stale list this was meant to replace. The commits
     * exist either way and describe the same build, so they are a truer answer
     * than a hardcoded one and need nothing added to the release process.
     */
    private suspend fun recentCommits(): String? = withContext(Dispatchers.IO) {
        runCatching {
            val conn = (URL("https://api.github.com/repos/$REPO/commits?per_page=15")
                .openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("Accept", "application/vnd.github+json")
            }
            if (conn.responseCode != 200) return@withContext null
            val arr = JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
            val lines = (0 until arr.length()).mapNotNull { i ->
                val msg = arr.optJSONObject(i)?.optJSONObject("commit")
                    ?.optString("message").orEmpty()
                // First line only; commit bodies are for the repo, not a phone.
                val subject = msg.lineSequence().firstOrNull()?.trim().orEmpty()
                subject.takeIf {
                    it.isNotBlank() &&
                        !it.startsWith("Merge", true) &&
                        !it.startsWith("Bump", true) &&
                        !it.startsWith("chore", true)
                }
            }.distinct().take(10)
            if (lines.isEmpty()) null
            else "## Is build mein\n\n" + lines.joinToString("\n") { "- $it" }
        }.getOrNull()
    }

    /**
     * The notes attached to the newest release, whether or not it is newer
     * than what is installed.
     *
     * What's New used to read from a list hardcoded in the app, which meant it
     * only changed when someone remembered to edit it — and it went several
     * builds without being touched, so every update proudly announced the same
     * old fixes. The release body is written once, at release time, and cannot
     * fall out of step with the build it describes.
     */
    suspend fun latestNotes(): String? = withContext(Dispatchers.IO) {
        runCatching {
            val conn = (URL(API).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("Accept", "application/vnd.github+json")
            }
            if (conn.responseCode != 200) return@withContext null
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            json.optString("body").takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    /** Release body if someone wrote one, otherwise the commits themselves. */
    suspend fun notesOrCommits(): String? = latestNotes()?.let { body ->
        val meaningful = body.lines().map { it.trim() }.any {
            it.isNotBlank() &&
                !it.startsWith("**Full Changelog", true) &&
                !it.startsWith("Full Changelog", true) &&
                !it.startsWith("https://")
        }
        if (meaningful) body else null
    } ?: recentCommits()

    suspend fun check(context: Context): Release? = withContext(Dispatchers.IO) {
        runCatching {
            val conn = (URL(API).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("Accept", "application/vnd.github+json")
            }
            if (conn.responseCode != 200) return@withContext null
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })

            val tag = json.optString("tag_name").removePrefix("v")
            val assets = json.optJSONArray("assets") ?: return@withContext null
            var apk: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) {
                    apk = a.optString("browser_download_url"); break
                }
            }
            if (apk == null) return@withContext null

            if (!isNewer(tag, currentVersion(context))) {
                cached = null
                return@withContext null
            }
            Release(tag, apk, json.optString("body")).also { cached = it }
        }.getOrNull()
    }

    /** Compares dotted versions numerically, so 1.0.10 beats 1.0.9. */
    private fun isNewer(remote: String, local: String): Boolean {
        val r = remote.split(".").mapNotNull { it.toIntOrNull() }
        val l = local.split(".").mapNotNull { it.toIntOrNull() }
        for (i in 0 until maxOf(r.size, l.size)) {
            val a = r.getOrElse(i) { 0 }
            val b = l.getOrElse(i) { 0 }
            if (a != b) return a > b
        }
        return false
    }

    /**
     * Downloads with real progress and hands the file to the system installer.
     *
     * Content-Length gives the total up front, so bytes copied is a true
     * percentage rather than a spinner that tells the user nothing.
     */
    suspend fun downloadAndInstall(
        context: Context,
        release: Release,
        onProgress: (Float) -> Unit = {},
    ): Boolean =
        withContext(Dispatchers.IO) {
            runCatching {
                val file = File(context.cacheDir, "update.apk")
                val conn = (URL(release.apkUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 30000
                    instanceFollowRedirects = true
                }
                // Without this a 404 or a rate-limit page was written straight
                // into update.apk and handed to the package installer, which
                // then failed with "App not installed" and no reason why.
                if (conn.responseCode != 200) {
                    conn.disconnect()
                    return@withContext false
                }
                // contentLength is -1 whenever the response is chunked, and the
                // old coerce turned that into a total of one byte, so the bar
                // hit 100% on the first read and sat there for the whole
                // download. Unknown length now reports no progress instead of
                // lying about it.
                val total = conn.contentLength.toLong()
                var read = 0L
                conn.inputStream.use { input ->
                    file.outputStream().use { out ->
                        val buffer = ByteArray(16 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            out.write(buffer, 0, n)
                            read += n
                            if (total > 0) {
                                onProgress((read.toFloat() / total).coerceIn(0f, 1f))
                            }
                        }
                    }
                }
                if (read <= 0L) return@withContext false
                onProgress(1f)

                val uri: Uri = FileProvider.getUriForFile(
                    context, "${context.packageName}.fileprovider", file
                )
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                true
            }.getOrDefault(false)
        }
}
