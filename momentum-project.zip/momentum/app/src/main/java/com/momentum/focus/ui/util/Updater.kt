package com.momentum.focus.ui.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class Release(
    val version: String,
    val apkUrl: String,
    val notes: String,
)

/**
 * Checks GitHub Releases for a newer build and installs it.
 *
 * Releases are used rather than Actions artifacts because artifacts require an
 * authenticated API token to download, while release assets are public. The CI
 * workflow publishes one release per successful build.
 */
object Updater {

    @Volatile
    var cached: Release? = null
        private set

    // Change this if the repo ever moves.
    private const val REPO = "theknownzone/momentum"
    private const val API = "https://api.github.com/repos/$REPO/releases/latest"

    fun currentVersion(context: Context): String = runCatching {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0"
    }.getOrDefault("0")

    suspend fun check(context: Context): Release? = withContext(Dispatchers.IO) {
        runCatching {
            val conn = (URL(API).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("Accept", "application/vnd.github+json")
            }
            if (conn.responseCode != 200) return@withContext null
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })

            val tag = json.optString("tag_name").removePrefix("v")
            val assets = json.optJSONArray("assets") ?: return@withContext null
            var apk: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) {
                    apk = a.optString("browser_download_url"); break
                }
            }
            if (apk == null) return@withContext null

            if (!isNewer(tag, currentVersion(context))) {
                cached = null
                return@withContext null
            }
            Release(tag, apk, json.optString("body")).also { cached = it }
        }.getOrNull()
    }

    /** Compares dotted versions numerically, so 1.0.10 beats 1.0.9. */
    private fun isNewer(remote: String, local: String): Boolean {
        val r = remote.split(".").mapNotNull { it.toIntOrNull() }
        val l = local.split(".").mapNotNull { it.toIntOrNull() }
        for (i in 0 until maxOf(r.size, l.size)) {
            val a = r.getOrElse(i) { 0 }
            val b = l.getOrElse(i) { 0 }
            if (a != b) return a > b
        }
        return false
    }

    /**
     * Downloads with real progress and hands the file to the system installer.
     *
     * Content-Length gives the total up front, so bytes copied is a true
     * percentage rather than a spinner that tells the user nothing.
     */
    suspend fun downloadAndInstall(
        context: Context,
        release: Release,
        onProgress: (Float) -> Unit = {},
    ): Boolean =
        withContext(Dispatchers.IO) {
            runCatching {
                val file = File(context.cacheDir, "update.apk")
                val conn = (URL(release.apkUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    instanceFollowRedirects = true
                }
                val total = conn.contentLength.toLong().coerceAtLeast(1L)
                var read = 0L
                conn.inputStream.use { input ->
                    file.outputStream().use { out ->
                        val buffer = ByteArray(16 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            out.write(buffer, 0, n)
                            read += n
                            onProgress((read.toFloat() / total).coerceIn(0f, 1f))
                        }
                    }
                }
                onProgress(1f)

                val uri: Uri = FileProvider.getUriForFile(
                    context, "${context.packageName}.fileprovider", file
                )
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                true
            }.getOrDefault(false)
        }
}
