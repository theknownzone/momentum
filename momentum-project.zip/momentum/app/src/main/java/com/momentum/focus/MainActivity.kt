package com.momentum.focus

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.focus.ui.AppViewModel
import com.momentum.focus.ui.nav.PaperBottomBar
import com.momentum.focus.ui.nav.Tab
import com.momentum.focus.ui.screens.*
import com.momentum.focus.ui.screens.Changelog
import com.momentum.focus.ui.theme.MomentumTheme
import com.momentum.focus.ui.theme.Skin
import com.momentum.focus.ui.theme.skinFor
import com.momentum.focus.ui.util.CrashReporter
import com.momentum.focus.block.BlockerService
import com.momentum.focus.data.ScreenTime
import com.momentum.focus.data.achievements
import com.momentum.focus.ui.components.TourOverlay
import com.momentum.focus.ui.components.shapeOnly
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.ShakeToPanic
import com.momentum.focus.ui.util.rememberHaptics

/**
 * Where the buy button sends people.
 *
 * Payment happens off-device on purpose. A sideloaded build cannot use Play
 * Billing, and wiring a card form into the app would mean handling money and
 * PCI scope for a student project. The store page issues a licence key, the
 * key unlocks the app offline, and nothing sensitive ever touches this code.
 *
 * << REPLACE WITH THE REAL STORE URL BEFORE SELLING >>
 */
private const val BUY_URL = "https://example.com/momentum"

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) Sfx.release()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashReporter.install(applicationContext)
        Sfx.init(applicationContext)
        val startupCrash = CrashReporter.lastCrash(this)
        enableEdgeToEdge()

        setContent {
            // Hoisted above the theme so the chosen skin can colour it. Read
            // inside, it could only ever tint what sat below the one screen
            // that happened to look it up.
            val loaded by vm.data.collectAsStateWithLifecycle()
            MomentumTheme(skin = loaded?.let { skinFor(it.skin) } ?: Skin.SAKURA) {

                var splashDone by remember { mutableStateOf(false) }
                // The splash also covers the DataStore read, so there is never
                // a frame where the app is guessing what state it is in.
                if (!splashDone || loaded == null) {
                    SplashScreen { splashDone = true }
                    return@MomentumTheme
                }
                val data = loaded!!

                var crash by remember { mutableStateOf(startupCrash) }
                val shownCrash = crash
                if (shownCrash != null) {
                    CrashScreen(trace = shownCrash) {
                        CrashReporter.clear(this@MainActivity)
                        crash = null
                    }
                    return@MomentumTheme
                }

                val timer by vm.timer.collectAsStateWithLifecycle()
                val finished by vm.sessionFinished.collectAsStateWithLifecycle()
                val haptics = rememberHaptics()

                var tab by remember { mutableStateOf(Tab.HOME) }
                var panicOpen by remember { mutableStateOf(false) }
                var profileOpen by remember { mutableStateOf(false) }
                var permsOpen by remember { mutableStateOf(false) }
                var blockListOpen by remember { mutableStateOf(false) }
                var plansOpen by remember { mutableStateOf(false) }
                var changelogOpen by remember { mutableStateOf(false) }
                var feedGuardOpen by remember { mutableStateOf(false) }
                var profilesOpen by remember { mutableStateOf(false) }
                var blockHubOpen by remember { mutableStateOf(false) }
                var permsRecheck by remember { mutableIntStateOf(0) }
                val permsStillGranted = remember(permsRecheck, data.onboarded) {
                    !data.onboarded || Perms.allRequiredGranted(this@MainActivity)
                }
                DisposableEffect(Unit) {
                    val obs = LifecycleEventObserver { _, e ->
                        if (e == Lifecycle.Event.ON_RESUME) permsRecheck++
                    }
                    lifecycle.addObserver(obs)
                    onDispose { lifecycle.removeObserver(obs) }
                }

                // Shown once per version: if the installed build is newer than
                // the one last acknowledged, the changelog comes up first.
                val version = remember { Updater.currentVersion(this@MainActivity) }
                var newsOpen by remember(data.lastSeenVersion, data.lastSeenChangelog, version) {
                    mutableStateOf(
                        data.onboarded && (
                            data.lastSeenVersion != version ||
                                data.lastSeenChangelog < Changelog.LATEST
                            )
                    )
                }

                // The service only ever runs with the user's current choices,
                // so both the list and the on/off switch push straight into it.
                LaunchedEffect(
                    data.blockedPackages,
                    data.shieldOn,
                    data.balanceMinutes,
                    data.minutesToday,
                    data.classHoursOn,
                    data.focusLevel,
                    data.classStartHour,
                    data.classEndHour,
                ) {
                    // Seeding only at onboarding meant every install that
                    // already existed kept an empty surface set forever, so the
                    // guard ran and matched nothing. Seeding is idempotent.
                    if (data.onboarded && !data.surfacesSeeded) vm.seedSurfaces()
                    BlockerService.blocked = data.blockedPackages
                    BlockerService.dailyCaps = data.dailyCapMinutes
                    BlockerService.balanceMinutes = data.balanceMinutes
                    BlockerService.earnedTodayMinutes = data.minutesToday
                    BlockerService.streakDays = data.streakDays
                    val hourNow = java.time.LocalTime.now().hour
                    val dayNow = java.time.LocalDate.now().dayOfWeek.value
                    val inClass = data.classHoursOn &&
                        dayNow in data.classDays &&
                        hourNow >= data.classStartHour && hourNow < data.classEndHour
                    val shieldNow = data.shieldOn || (inClass && data.focusLevel >= 2)
                    if (shieldNow && data.blockedPackages.isNotEmpty() &&
                        Perms.allRequiredGranted(this@MainActivity)
                    ) {
                        BlockerService.start(this@MainActivity)
                    } else {
                        BlockerService.stop(this@MainActivity)
                    }
                }

                // Onboarding is two stages: explain the idea, then ask for the
                // permissions. Asking first, before anyone knows what the app
                // does, is how permission prompts get denied.
                var explained by remember(data.onboarded) { mutableStateOf(data.onboarded) }

                var sessionWon by remember { mutableStateOf(false) }
                LaunchedEffect(finished) {
                    if (finished > 0) {
                        haptics.sessionComplete()
                        sessionWon = true
                    }
                }

                // Crown switches itself on inside the exam window. A deadline
                // is a better trigger than a toggle nobody remembers to flip.
                LaunchedEffect(data.examIsClose) {
                    if (data.examIsClose && !data.crownMode) vm.setCrown(true)
                }

                LaunchedEffect(Unit) { vm.stampFirstOpen() }

                // Before every other full-screen gate: a celebration or a
                // reflection prompt makes no sense to someone who has not been
                // told what the app does yet.
                if (data.onboarded && !data.tourSeen) {
                    TourOverlay { vm.markTourSeen() }
                    return@MomentumTheme
                }

                // Shake twice to reach panic from anywhere. During a craving
                // nobody navigates menus, and the gesture works with the screen
                // barely looked at.
                ShakeToPanic(enabled = !panicOpen) {
                    haptics.press()
                    panicOpen = true
                }

                // Finishing a session is the behaviour the whole app exists to
                // produce, so it gets the loud screen too.
                if (sessionWon) {
                    CelebrationScreen(
                        kicker = "SESSION BANKED",
                        title = "+₹${(timer.totalSeconds / 60) / data.effectiveRatio.coerceAtLeast(1)}",
                        body = "${timer.totalSeconds / 60} min studied. In the wallet now.",
                        colorIndex = 0,
                        shapeIndex = shapeOnly(0),
                    ) { sessionWon = false }
                    return@MomentumTheme
                }

                // Reward first, honesty second, then the app.
                val badges = remember(data) { data.achievements().count { it.unlocked } }
                if (data.onboarded && data.level > data.lastCelebratedLevel) {
                    CelebrationScreen(
                        kicker = "LEVEL UP",
                        title = "Level ${data.level}",
                        body = "Every minute of this was earned. Nobody handed it to you.",
                        colorIndex = data.avatarColor,
                        shapeIndex = data.avatarShape,
                    ) { vm.markCelebrated(data.level, badges) }
                    return@MomentumTheme
                }
                // Which badge was just earned cannot be read off a count, and
                // achievements() is ordered by theme rather than by when it
                // unlocks — so last { it.unlocked } was picking whichever badge
                // happened to sit lowest in the list, not the new one.
                val unlocked = remember(data) { data.achievements().filter { it.unlocked } }
                val seeded = data.celebratedBadgeIds.isNotEmpty() ||
                    data.lastCelebratedBadges == 0
                LaunchedEffect(seeded) {
                    if (!seeded) vm.seedCelebratedBadges(unlocked.map { it.id }.toSet())
                }
                val newest = if (!seeded) null
                    else unlocked.firstOrNull { it.id !in data.celebratedBadgeIds }
                if (data.onboarded && newest != null) {
                    CelebrationScreen(
                        kicker = "${newest.tier.label} UNLOCKED",
                        title = newest.title,
                        body = newest.reward,
                        colorIndex = newest.tier.ordinal + 1,
                        shapeIndex = shapeOnly(newest.tier.ordinal),
                    ) { vm.markBadgeCelebrated(newest.id, badges) }
                    return@MomentumTheme
                }

                if (data.onboarded && data.pendingReflectionMinutes > 0) {
                    SlipReflectionScreen(
                        minutes = data.pendingReflectionMinutes,
                        onAnswer = vm::logSlip,
                        onSkip = vm::skipReflection,
                    )
                    return@MomentumTheme
                }

                if (!explained) {
                    WelcomeScreen { name ->
                        if (name.isNotBlank()) vm.setName(name)
                        explained = true
                    }
                    return@MomentumTheme
                }

                if (!data.onboarded) {
                    // Order matters. Permissions first, because without usage
                    // access there is no real data and the quiz has nothing to
                    // reveal. Then guess-then-truth. Then pick the apps, once
                    // the person has just seen which ones cost them most.
                    var permsDone by remember { mutableStateOf(false) }
                    var quizDone by remember { mutableStateOf(false) }

                    when {
                        !permsDone -> PermissionsScreen(onDone = { permsDone = true })

                        !quizDone -> {
                            val report = remember {
                                ScreenTime.report(this@MainActivity)
                            }
                            if (!report.hasData) {
                                // No usage access granted, so skip rather than
                                // show a screen full of zeroes.
                                LaunchedEffect(Unit) { quizDone = true }
                            } else {
                                ScreenTimeQuiz(report) { hours, picks ->
                                    vm.saveBaseline(hours, picks, report.averageMinutes)
                                    quizDone = true
                                }
                            }
                        }

                        else -> BlockListScreen(
                            data = data,
                            preselectTop = true,
                            onToggle = vm::toggleBlocked,
                            onCap = vm::setDailyCap,
                            onDone = {
                                vm.setShield(true)
                                vm.seedStudyApps()
                                vm.seedSurfaces()
                                vm.markVersionSeen(version, Changelog.LATEST)
                                vm.completeOnboarding()
                            },
                        )
                    }
                    return@MomentumTheme
                }

                if (newsOpen) {
                    WhatsNewScreen(version = version) {
                        vm.markVersionSeen(version, Changelog.LATEST)
                        newsOpen = false
                    }
                    return@MomentumTheme
                }

                // Full-screen modes deliberately hide the tab bar: during a
                // craving or a settings edit there is nowhere else to go.
                val fullScreen = panicOpen || profileOpen || permsOpen ||
                    blockListOpen || feedGuardOpen || profilesOpen || blockHubOpen ||
                    plansOpen || changelogOpen

                // Back was doing nothing on every overlay, so the only way out
                // of Profile was to kill the app. Innermost layer closes first.
                BackHandler(enabled = fullScreen) {
                    when {
                        // Order matters and mirrors how deep each screen is:
                        // a child closes back to the hub, and the hub closes
                        // last. Duplicated branches here would be dead code
                        // and would strand the user one level down.
                        permsOpen -> permsOpen = false
                        changelogOpen -> changelogOpen = false
                        plansOpen -> plansOpen = false
                        blockListOpen -> blockListOpen = false
                        feedGuardOpen -> feedGuardOpen = false
                        profilesOpen -> profilesOpen = false
                        blockHubOpen -> blockHubOpen = false
                        profileOpen -> profileOpen = false
                        panicOpen -> panicOpen = false
                    }
                }

                // On a tab other than Home, back returns Home rather than
                // dropping the user out of the app entirely.
                BackHandler(enabled = !fullScreen && tab != Tab.HOME) {
                    tab = Tab.HOME
                }

                Scaffold(
                    bottomBar = {
                        if (!fullScreen) PaperBottomBar(current = tab, onSelect = { tab = it })
                    },
                    containerColor = MaterialTheme.colorScheme.background,
                ) { padding ->
                    Box(
                        Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .background(MaterialTheme.colorScheme.background)
                    ) {
                        when {
                            // Revoking usage access or overlay after setup left
                            // the shield dead and the app cheerfully pretending
                            // otherwise. Grants are re-checked on every resume,
                            // and a missing one puts this screen back in front
                            // of everything until it is fixed.
                            !permsStillGranted -> PermissionsScreen(
                                onDone = { permsRecheck++ }
                            )

                            permsOpen -> PermissionsScreen(onDone = { permsOpen = false })

                            profilesOpen -> ProfilesScreen(
                                data = data,
                                onSave = vm::saveProfile,
                                onApply = vm::applyProfile,
                                onDelete = vm::deleteProfile,
                                onDone = { profilesOpen = false },
                            )

                            feedGuardOpen -> FeedGuardScreen(
                                data = data,
                                onToggleSurface = vm::toggleSurface,
                                onDone = { feedGuardOpen = false },
                            )

                            changelogOpen -> WhatsNewScreen(version = version) {
                                changelogOpen = false
                            }

                            plansOpen -> PlansScreen(
                                data = data,
                                // Buying happens outside the app. Sideloaded
                                // builds cannot use Play Billing, so the button
                                // hands off to the store page and the buyer
                                // comes back with a key.
                                onBuy = {
                                    runCatching {
                                        startActivity(
                                            Intent(Intent.ACTION_VIEW, Uri.parse(BUY_URL))
                                        )
                                    }
                                },
                                onRedeem = { vm.redeem(it) },
                                onRemove = { vm.clearLicense() },
                                onDone = { plansOpen = false },
                            )

                            blockListOpen -> BlockListScreen(
                                data = data,
                                onToggle = vm::toggleBlocked,
                                editLock = vm.blockEditLock(),
                                onCap = vm::setDailyCap,
                                onDone = { blockListOpen = false },
                            )

                            // Below its children on purpose. The hub stays
                            // open underneath while one of them is showing, so
                            // matching it first meant tapping a row set the
                            // child's flag and nothing changed on screen.
                            blockHubOpen -> BlockHubScreen(
                                data = data,
                                onApps = { blockListOpen = true },
                                onFeeds = { feedGuardOpen = true },
                                onProfiles = { profilesOpen = true },
                                onSchedule = { blockHubOpen = false; profileOpen = true },
                                onDone = { blockHubOpen = false },
                            )

                            profileOpen -> ProfileScreen(
                                data = data,
                                onCrown = vm::setCrown,
                                onRatio = vm::setEarnRatio,
                                onExam = vm::setExam,
                                onWeekend = vm::setWeekendRelaxed,
                                onAvatar = vm::setAvatar,
                                onSkin = vm::setSkin,
                                onName = vm::setName,
                                onGoal = vm::setGoal,
                                onPermissions = { permsOpen = true },
                                onPlans = { plansOpen = true },
                                onChangelog = { changelogOpen = true },
                                onBlockList = { blockHubOpen = true },
                                onShield = vm::setShield,
                                onSubjects = vm::setSubjects,
                                onClassHours = vm::setClassHours,
                                onClassDay = vm::toggleClassDay,
                            )

                            panicOpen -> PanicScreen(
                                onSurvived = { vm.logUrge(survived = true) },
                                onRelapsed = { vm.logUrge(survived = false); vm.resetStreak() },
                                onDone = { panicOpen = false },
                            )

                            tab == Tab.HOME -> HomeScreen(
                                data = data,
                                onStartFocus = { tab = Tab.FOCUS },
                                onPanic = { panicOpen = true },
                                onJournal = { tab = Tab.JOURNAL },
                                onProfile = { profileOpen = true },
                                onShield = { blockHubOpen = true },
                                onFeeds = { blockHubOpen = true },
                                onRewards = { tab = Tab.REWARDS },
                            )

                            tab == Tab.FOCUS -> FocusScreen(
                                data = data,
                                timer = timer,
                                onToggle = vm::toggleTimer,
                                onAbandon = vm::abandon,
                                onDuration = vm::setDuration,
                                onSubject = vm::setSubject,
                                onFocusLevel = vm::setFocusLevel,
                                onToggleStudy = vm::toggleStudyApp,
                                onExtendPact = vm::extendPact,
                            )

                            tab == Tab.WALLET -> WalletScreen(
                                data = data,
                                onEarn = { tab = Tab.FOCUS },
                            )

                            tab == Tab.STATS -> StatsScreen(data = data)

                            tab == Tab.REWARDS -> AchievementsScreen(data = data)

                            tab == Tab.JOURNAL -> JournalScreen(
                                data = data,
                                onSave = vm::saveJournal,
                            )
                        }
                    }
                }
            }
        }
    }
}
