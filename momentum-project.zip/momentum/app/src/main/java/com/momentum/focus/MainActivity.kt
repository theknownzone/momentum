package com.momentum.focus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.focus.ui.AppViewModel
import com.momentum.focus.ui.nav.PaperBottomBar
import com.momentum.focus.ui.nav.Tab
import com.momentum.focus.ui.screens.*
import com.momentum.focus.ui.theme.MomentumTheme
import com.momentum.focus.ui.util.CrashReporter
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.rememberHaptics

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) Sfx.release()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashReporter.install(applicationContext)
        Sfx.init(applicationContext)
        val startupCrash = CrashReporter.lastCrash(this)
        enableEdgeToEdge()

        setContent {
            MomentumTheme {
                var crash by remember { mutableStateOf(startupCrash) }
                val shownCrash = crash
                if (shownCrash != null) {
                    CrashScreen(trace = shownCrash) {
                        CrashReporter.clear(this@MainActivity)
                        crash = null
                    }
                    return@MomentumTheme
                }

                val data by vm.data.collectAsStateWithLifecycle()
                val timer by vm.timer.collectAsStateWithLifecycle()
                val finished by vm.sessionFinished.collectAsStateWithLifecycle()
                val haptics = rememberHaptics()

                var tab by remember { mutableStateOf(Tab.HOME) }
                var panicOpen by remember { mutableStateOf(false) }
                var profileOpen by remember { mutableStateOf(false) }
                var permsOpen by remember { mutableStateOf(false) }

                // Onboarding is two stages: explain the idea, then ask for the
                // permissions. Asking first, before anyone knows what the app
                // does, is how permission prompts get denied.
                var explained by remember(data.onboarded) { mutableStateOf(data.onboarded) }

                LaunchedEffect(finished) { if (finished > 0) haptics.sessionComplete() }

                if (!explained) {
                    WelcomeScreen { name ->
                        if (name.isNotBlank()) vm.setName(name)
                        explained = true
                    }
                    return@MomentumTheme
                }

                if (!data.onboarded) {
                    PermissionsScreen(onDone = vm::completeOnboarding)
                    return@MomentumTheme
                }

                // Full-screen modes deliberately hide the tab bar: during a
                // craving or a settings edit there is nowhere else to go.
                val fullScreen = panicOpen || profileOpen || permsOpen

                Scaffold(
                    bottomBar = {
                        if (!fullScreen) PaperBottomBar(current = tab, onSelect = { tab = it })
                    },
                    containerColor = MaterialTheme.colorScheme.background,
                ) { padding ->
                    Box(
                        Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .statusBarsPadding()
                            .background(MaterialTheme.colorScheme.background)
                    ) {
                        when {
                            permsOpen -> PermissionsScreen(onDone = { permsOpen = false })

                            profileOpen -> ProfileScreen(
                                data = data,
                                onName = vm::setName,
                                onGoal = vm::setGoal,
                                onPermissions = { permsOpen = true },
                            )

                            panicOpen -> PanicScreen(
                                onSurvived = { vm.logUrge(survived = true) },
                                onRelapsed = { vm.logUrge(survived = false); vm.resetStreak() },
                                onDone = { panicOpen = false },
                            )

                            tab == Tab.HOME -> HomeScreen(
                                data = data,
                                onStartFocus = { tab = Tab.FOCUS },
                                onPanic = { panicOpen = true },
                                onJournal = { tab = Tab.JOURNAL },
                                onProfile = { profileOpen = true },
                            )

                            tab == Tab.FOCUS -> FocusScreen(
                                data = data,
                                timer = timer,
                                onToggle = vm::toggleTimer,
                                onAbandon = vm::abandon,
                                onDuration = vm::setDuration,
                                onSubject = vm::setSubject,
                            )

                            tab == Tab.STATS -> StatsScreen(data = data)

                            tab == Tab.JOURNAL -> JournalScreen(
                                data = data,
                                onSave = vm::saveJournal,
                            )
                        }
                    }
                }
            }
        }
    }
}
