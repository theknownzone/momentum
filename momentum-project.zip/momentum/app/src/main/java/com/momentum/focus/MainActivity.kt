package com.momentum.focus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.focus.ui.AppViewModel
import com.momentum.focus.ui.nav.PaperBottomBar
import com.momentum.focus.ui.nav.Tab
import com.momentum.focus.ui.screens.*
import com.momentum.focus.ui.theme.MomentumTheme
import com.momentum.focus.ui.util.CrashReporter
import com.momentum.focus.block.BlockerService
import com.momentum.focus.data.ScreenTime
import com.momentum.focus.data.achievements
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.ShakeToPanic
import com.momentum.focus.ui.util.rememberHaptics

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) Sfx.release()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashReporter.install(applicationContext)
        Sfx.init(applicationContext)
        val startupCrash = CrashReporter.lastCrash(this)
        enableEdgeToEdge()

        setContent {
            MomentumTheme {
                val loaded by vm.data.collectAsStateWithLifecycle()

                var splashDone by remember { mutableStateOf(false) }
                // The splash also covers the DataStore read, so there is never
                // a frame where the app is guessing what state it is in.
                if (!splashDone || loaded == null) {
                    SplashScreen { splashDone = true }
                    return@MomentumTheme
                }
                val data = loaded!!

                var crash by remember { mutableStateOf(startupCrash) }
                val shownCrash = crash
                if (shownCrash != null) {
                    CrashScreen(trace = shownCrash) {
                        CrashReporter.clear(this@MainActivity)
                        crash = null
                    }
                    return@MomentumTheme
                }

                val timer by vm.timer.collectAsStateWithLifecycle()
                val finished by vm.sessionFinished.collectAsStateWithLifecycle()
                val haptics = rememberHaptics()

                var tab by remember { mutableStateOf(Tab.HOME) }
                var panicOpen by remember { mutableStateOf(false) }
                var profileOpen by remember { mutableStateOf(false) }
                var permsOpen by remember { mutableStateOf(false) }
                var blockListOpen by remember { mutableStateOf(false) }

                // Shown once per version: if the installed build is newer than
                // the one last acknowledged, the changelog comes up first.
                val version = remember { Updater.currentVersion(this@MainActivity) }
                var newsOpen by remember(data.lastSeenVersion) {
                    mutableStateOf(
                        data.onboarded && data.lastSeenVersion.isNotBlank() &&
                            data.lastSeenVersion != version
                    )
                }

                // The service only ever runs with the user's current choices,
                // so both the list and the on/off switch push straight into it.
                LaunchedEffect(data.blockedPackages, data.shieldOn) {
                    BlockerService.blocked = data.blockedPackages
                    if (data.shieldOn && data.blockedPackages.isNotEmpty() &&
                        Perms.allRequiredGranted(this@MainActivity)
                    ) {
                        BlockerService.start(this@MainActivity)
                    } else {
                        BlockerService.stop(this@MainActivity)
                    }
                }

                // Onboarding is two stages: explain the idea, then ask for the
                // permissions. Asking first, before anyone knows what the app
                // does, is how permission prompts get denied.
                var explained by remember(data.onboarded) { mutableStateOf(data.onboarded) }

                var sessionWon by remember { mutableStateOf(false) }
                LaunchedEffect(finished) {
                    if (finished > 0) {
                        haptics.sessionComplete()
                        sessionWon = true
                    }
                }

                // Crown switches itself on inside the exam window. A deadline
                // is a better trigger than a toggle nobody remembers to flip.
                LaunchedEffect(data.examIsClose) {
                    if (data.examIsClose && !data.crownMode) vm.setCrown(true)
                }

                // Shake twice to reach panic from anywhere. During a craving
                // nobody navigates menus, and the gesture works with the screen
                // barely looked at.
                ShakeToPanic(enabled = !panicOpen) {
                    haptics.press()
                    panicOpen = true
                }

                // Finishing a session is the behaviour the whole app exists to
                // produce, so it gets the loud screen too.
                if (sessionWon) {
                    CelebrationScreen(
                        kicker = "SESSION BANKED",
                        title = "+${timer.totalSeconds / 60} minutes",
                        body = "That is time nobody can take back off you.",
                        colorIndex = 0,
                        shapeIndex = data.avatarShape,
                    ) { sessionWon = false }
                    return@MomentumTheme
                }

                // Reward first, honesty second, then the app.
                val badges = remember(data) { data.achievements().count { it.unlocked } }
                if (data.onboarded && data.level > data.lastCelebratedLevel) {
                    CelebrationScreen(
                        kicker = "LEVEL UP",
                        title = "Level ${data.level}",
                        body = "Every minute of this was earned. Nobody handed it to you.",
                        colorIndex = data.avatarColor,
                        shapeIndex = data.avatarShape,
                    ) { vm.markCelebrated(data.level, badges) }
                    return@MomentumTheme
                }
                if (data.onboarded && badges > data.lastCelebratedBadges) {
                    val newest = data.achievements().last { it.unlocked }
                    CelebrationScreen(
                        kicker = "${newest.tier.label} UNLOCKED",
                        title = newest.title,
                        body = newest.reward,
                        colorIndex = newest.tier.ordinal + 1,
                        shapeIndex = newest.tier.ordinal,
                    ) { vm.markCelebrated(data.level, badges) }
                    return@MomentumTheme
                }

                if (data.onboarded && data.pendingReflectionMinutes > 0) {
                    SlipReflectionScreen(
                        minutes = data.pendingReflectionMinutes,
                        onAnswer = vm::logSlip,
                        onSkip = vm::skipReflection,
                    )
                    return@MomentumTheme
                }

                if (!explained) {
                    WelcomeScreen { name ->
                        if (name.isNotBlank()) vm.setName(name)
                        explained = true
                    }
                    return@MomentumTheme
                }

                if (!data.onboarded) {
                    // Order matters. Permissions first, because without usage
                    // access there is no real data and the quiz has nothing to
                    // reveal. Then guess-then-truth. Then pick the apps, once
                    // the person has just seen which ones cost them most.
                    var permsDone by remember { mutableStateOf(false) }
                    var quizDone by remember { mutableStateOf(false) }

                    when {
                        !permsDone -> PermissionsScreen(onDone = { permsDone = true })

                        !quizDone -> {
                            val report = remember {
                                ScreenTime.report(this@MainActivity)
                            }
                            if (!report.hasData) {
                                // No usage access granted, so skip rather than
                                // show a screen full of zeroes.
                                LaunchedEffect(Unit) { quizDone = true }
                            } else {
                                ScreenTimeQuiz(report) { hours, picks ->
                                    vm.saveBaseline(hours, picks, report.averageMinutes)
                                    quizDone = true
                                }
                            }
                        }

                        else -> BlockListScreen(
                            data = data,
                            preselectTop = true,
                            onToggle = vm::toggleBlocked,
                            onDone = {
                                vm.setShield(true)
                                vm.markVersionSeen(version)
                                vm.completeOnboarding()
                            },
                        )
                    }
                    return@MomentumTheme
                }

                if (newsOpen) {
                    WhatsNewScreen(version = version) {
                        vm.markVersionSeen(version)
                        newsOpen = false
                    }
                    return@MomentumTheme
                }

                // Full-screen modes deliberately hide the tab bar: during a
                // craving or a settings edit there is nowhere else to go.
                val fullScreen = panicOpen || profileOpen || permsOpen || blockListOpen

                // Back was doing nothing on every overlay, so the only way out
                // of Profile was to kill the app. Innermost layer closes first.
                BackHandler(enabled = fullScreen) {
                    when {
                        permsOpen -> permsOpen = false
                        blockListOpen -> blockListOpen = false
                        profileOpen -> profileOpen = false
                        panicOpen -> panicOpen = false
                    }
                }

                // On a tab other than Home, back returns Home rather than
                // dropping the user out of the app entirely.
                BackHandler(enabled = !fullScreen && tab != Tab.HOME) {
                    tab = Tab.HOME
                }

                Scaffold(
                    bottomBar = {
                        if (!fullScreen) PaperBottomBar(current = tab, onSelect = { tab = it })
                    },
                    containerColor = MaterialTheme.colorScheme.background,
                ) { padding ->
                    Box(
                        Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .background(MaterialTheme.colorScheme.background)
                    ) {
                        when {
                            permsOpen -> PermissionsScreen(onDone = { permsOpen = false })

                            blockListOpen -> BlockListScreen(
                                data = data,
                                onToggle = vm::toggleBlocked,
                                onDone = { blockListOpen = false },
                            )

                            profileOpen -> ProfileScreen(
                                data = data,
                                onCrown = vm::setCrown,
                                onRatio = vm::setEarnRatio,
                                onExam = vm::setExam,
                                onWeekend = vm::setWeekendRelaxed,
                                onAvatar = vm::setAvatar,
                                onName = vm::setName,
                                onGoal = vm::setGoal,
                                onPermissions = { permsOpen = true },
                                onBlockList = { blockListOpen = true },
                                onShield = vm::setShield,
                            )

                            panicOpen -> PanicScreen(
                                onSurvived = { vm.logUrge(survived = true) },
                                onRelapsed = { vm.logUrge(survived = false); vm.resetStreak() },
                                onDone = { panicOpen = false },
                            )

                            tab == Tab.HOME -> HomeScreen(
                                data = data,
                                onStartFocus = { tab = Tab.FOCUS },
                                onPanic = { panicOpen = true },
                                onJournal = { tab = Tab.JOURNAL },
                                onProfile = { profileOpen = true },
                                onShield = { blockListOpen = true },
                                onRewards = { tab = Tab.REWARDS },
                            )

                            tab == Tab.FOCUS -> FocusScreen(
                                data = data,
                                timer = timer,
                                onToggle = vm::toggleTimer,
                                onAbandon = vm::abandon,
                                onDuration = vm::setDuration,
                                onSubject = vm::setSubject,
                            )

                            tab == Tab.STATS -> StatsScreen(data = data)

                            tab == Tab.REWARDS -> AchievementsScreen(data = data)

                            tab == Tab.JOURNAL -> JournalScreen(
                                data = data,
                                onSave = vm::saveJournal,
                            )
                        }
                    }
                }
            }
        }
    }
}
