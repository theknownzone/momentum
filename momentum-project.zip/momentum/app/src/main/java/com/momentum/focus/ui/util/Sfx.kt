package com.momentum.focus.ui.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class Sound { POP, TICK, SUCCESS, ERROR, WHOOSH }

/**
 * UI sounds generated as raw PCM at startup instead of shipped as .wav files.
 *
 * Two reasons: no binary assets to manage, and the tones can be tuned by
 * changing a number rather than re-exporting audio. Each sound is a sine with
 * an exponential decay envelope — a decay is what separates a "pop" from a
 * "beep", since a flat envelope always sounds like a cheap alarm.
 */
object Sfx {

    private const val RATE = 44100
    private val tracks = mutableMapOf<Sound, AudioTrack>()
    private var audioManager: AudioManager? = null
    var enabled: Boolean = true

    fun init(context: Context) {
        if (tracks.isNotEmpty()) return
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        runCatching {
            tracks[Sound.POP] = build(tone(880f, 0.05f, decay = 45f, pitchDrop = 0.35f))
            tracks[Sound.TICK] = build(tone(2100f, 0.018f, decay = 140f))
            tracks[Sound.SUCCESS] = build(
                tone(660f, 0.07f, decay = 30f) + tone(990f, 0.13f, decay = 22f)
            )
            tracks[Sound.ERROR] = build(tone(200f, 0.10f, decay = 26f, pitchDrop = 0.5f))
            tracks[Sound.WHOOSH] = build(noise(0.09f))
        }
    }

    fun play(sound: Sound) {
        if (!enabled) return
        // Respect the physical silent switch. Nothing annoys people faster than
        // an app that chirps in a library.
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val track = tracks[sound] ?: return
        runCatching {
            track.stop()
            track.reloadStaticData()
            track.play()
        }
    }

    fun release() {
        tracks.values.forEach { runCatching { it.release() } }
        tracks.clear()
    }

    // ---- synthesis --------------------------------------------------------

    private fun tone(
        freq: Float,
        seconds: Float,
        decay: Float,
        pitchDrop: Float = 0f,
    ): ShortArray {
        val n = (RATE * seconds).toInt()
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            // Sliding the frequency down over the note gives the sound a body,
            // like something physical settling.
            val f = freq * (1f - pitchDrop * (i.toFloat() / n))
            val envelope = exp(-decay * t)
            (sin(2.0 * PI * f * t) * envelope * Short.MAX_VALUE * 0.28).toInt().toShort()
        }
    }

    private fun noise(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(4)
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            val envelope = exp(-38f * t)
            ((rng.nextFloat() * 2 - 1) * envelope * Short.MAX_VALUE * 0.14).toInt().toShort()
        }
    }

    private operator fun ShortArray.plus(other: ShortArray): ShortArray {
        val out = ShortArray(size + other.size)
        copyInto(out)
        other.copyInto(out, size)
        return out
    }

    private fun build(samples: ShortArray): AudioTrack {
        val bytes = samples.size * 2
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bytes)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(samples, 0, samples.size)
        return track
    }
}
