package com.momentum.focus.ui.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class Sound { POP, TICK, SUCCESS, ERROR, WHOOSH }

/**
 * UI sounds generated as raw PCM at startup instead of shipped as .wav files.
 *
 * Two reasons: no binary assets to manage, and the tones can be tuned by
 * changing a number rather than re-exporting audio. Each sound is a sine with
 * an exponential decay envelope — a decay is what separates a "pop" from a
 * "beep", since a flat envelope always sounds like a cheap alarm.
 */
object Sfx {

    private const val RATE = 44100
    private val tracks = mutableMapOf<Sound, AudioTrack>()
    private var audioManager: AudioManager? = null
    var enabled: Boolean = true

    fun init(context: Context) {
        if (tracks.isNotEmpty()) return
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        runCatching {
            // A pure sine is thin and plasticky. Adding a quiet octave and a
            // fifth above the root gives every sound a body, the same way a
            // real object resonates instead of beeping.
            tracks[Sound.POP] = build(
                chord(523f, 0.07f, decay = 34f, pitchDrop = 0.22f)
            )
            tracks[Sound.TICK] = build(
                tone(1760f, 0.022f, decay = 120f, level = 0.16f)
            )
            // A rising major third, the interval every reward sound uses,
            // because it is the one people hear as "yes" rather than "done".
            tracks[Sound.SUCCESS] = build(
                chord(659f, 0.09f, decay = 26f) + chord(880f, 0.20f, decay = 16f)
            )
            tracks[Sound.ERROR] = build(
                chord(196f, 0.14f, decay = 20f, pitchDrop = 0.35f)
            )
            tracks[Sound.WHOOSH] = build(noise(0.13f))
        }
    }

    fun play(sound: Sound) {
        if (!enabled) return
        // Respect the physical silent switch. Nothing annoys people faster than
        // an app that chirps in a library.
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val track = tracks[sound] ?: return
        runCatching {
            track.stop()
            track.reloadStaticData()
            track.play()
        }
    }

    fun release() {
        tracks.values.forEach { runCatching { it.release() } }
        tracks.clear()
    }

    // ---- synthesis --------------------------------------------------------

    /** Root plus an octave and a fifth, mixed low so it reads as timbre. */
    private fun chord(
        freq: Float,
        seconds: Float,
        decay: Float,
        pitchDrop: Float = 0f,
    ): ShortArray {
        val root = tone(freq, seconds, decay, pitchDrop, level = 0.24f)
        val octave = tone(freq * 2f, seconds, decay * 1.4f, pitchDrop, level = 0.09f)
        val fifth = tone(freq * 1.5f, seconds, decay * 1.2f, pitchDrop, level = 0.06f)
        return ShortArray(root.size) { i ->
            (root[i] + octave[i] + fifth[i]).coerceIn(
                Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()
            ).toShort()
        }
    }

    private fun tone(
        freq: Float,
        seconds: Float,
        decay: Float,
        pitchDrop: Float = 0f,
        level: Float = 0.28f,
    ): ShortArray {
        val n = (RATE * seconds).toInt()
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            // Sliding the frequency down over the note gives the sound a body,
            // like something physical settling.
            val f = freq * (1f - pitchDrop * (i.toFloat() / n))
            val envelope = exp(-decay * t)
            // A short fade-in kills the click that a hard start produces.
            val attack = (i / 140f).coerceAtMost(1f)
            (sin(2.0 * PI * f * t) * envelope * attack * Short.MAX_VALUE * level)
                .toInt().toShort()
        }
    }

    private fun noise(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(4)
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            // Low-passed noise: averaging consecutive samples removes the
            // hiss and leaves the soft rush of air.
            val envelope = exp(-26f * t)
            val n = (rng.nextFloat() * 2 - 1) * 0.5f + (rng.nextFloat() * 2 - 1) * 0.5f
            (n * envelope * Short.MAX_VALUE * 0.13).toInt().toShort()
        }
    }

    private operator fun ShortArray.plus(other: ShortArray): ShortArray {
        val out = ShortArray(size + other.size)
        copyInto(out)
        other.copyInto(out, size)
        return out
    }

    private fun build(samples: ShortArray): AudioTrack {
        val bytes = samples.size * 2
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bytes)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(samples, 0, samples.size)
        return track
    }
}
