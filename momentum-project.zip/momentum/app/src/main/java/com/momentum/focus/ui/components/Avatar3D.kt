package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.momentum.focus.R
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Sticker
import com.momentum.focus.ui.theme.stickerFor

/**
 * Isometric avatars drawn in code.
 *
 * The whole illusion of solidity comes from one rule: the same colour at three
 * brightnesses, one per visible face. Top face lightest, left face mid, right
 * face darkest. Get that ordering right and a flat shape reads as an object
 * lit from above, with no image files involved.
 */
enum class AvatarShape { CUBE, GEM, TOWER, COIN, PRISM, ORB }

/**
 * Rendered avatars supplied as artwork. They sit first in the picker because a
 * face is what most people want, and the drawn shapes remain for anyone who
 * would rather not be represented by a person at all.
 */
private val PHOTOS = listOf(
    R.drawable.avatar_1,
    R.drawable.avatar_2,
    R.drawable.avatar_3,
)

/** Total pickable avatars: the rendered faces followed by the drawn shapes. */
val AVATAR_COUNT = PHOTOS.size + AvatarShape.entries.size

@Composable
fun Avatar3D(
    colorIndex: Int,
    shapeIndex: Int,
    size: Dp = 64.dp,
    modifier: Modifier = Modifier,
) {
    val index = Math.floorMod(shapeIndex, AVATAR_COUNT)

    if (index < PHOTOS.size) {
        // The artwork ships on a square coloured background, so it is clipped
        // to a circle and ringed to sit on any surface the app uses.
        Image(
            painter = painterResource(PHOTOS[index]),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier
                .size(size)
                .clip(CircleShape)
                .border(2.dp, Ink, CircleShape),
        )
        return
    }

    val sticker = stickerFor(colorIndex)
    val shape = AvatarShape.entries[index - PHOTOS.size]

    Canvas(modifier.size(size)) {
        when (shape) {
            AvatarShape.CUBE -> cube(sticker)
            AvatarShape.GEM -> gem(sticker)
            AvatarShape.TOWER -> tower(sticker)
            AvatarShape.COIN -> coin(sticker)
            AvatarShape.PRISM -> prism(sticker)
            AvatarShape.ORB -> orb(sticker)
        }
    }
}

private fun Color.shade(factor: Float): Color = Color(
    red = (red * factor).coerceIn(0f, 1f),
    green = (green * factor).coerceIn(0f, 1f),
    blue = (blue * factor).coerceIn(0f, 1f),
    alpha = alpha,
)

private fun DrawScope.face(points: List<Offset>, fill: Color, outline: Float) {
    val path = Path().apply {
        moveTo(points[0].x, points[0].y)
        points.drop(1).forEach { lineTo(it.x, it.y) }
        close()
    }
    drawPath(path, fill)
    drawPath(path, Ink, style = Stroke(outline))
}

private fun DrawScope.cube(s: Sticker) {
    val w = size.width
    val o = 3.dp.toPx()
    val cx = w / 2
    val top = w * 0.16f
    val mid = w * 0.40f
    val low = w * 0.62f
    val bot = w * 0.86f
    val half = w * 0.32f

    face(listOf(Offset(cx, top), Offset(cx + half, mid), Offset(cx, low), Offset(cx - half, mid)),
        s.fill.shade(1.15f), o)
    face(listOf(Offset(cx - half, mid), Offset(cx, low), Offset(cx, bot), Offset(cx - half, bot - (low - mid))),
        s.fill.shade(0.82f), o)
    face(listOf(Offset(cx + half, mid), Offset(cx, low), Offset(cx, bot), Offset(cx + half, bot - (low - mid))),
        s.fill.shade(0.62f), o)
}

private fun DrawScope.gem(s: Sticker) {
    val w = size.width
    val o = 3.dp.toPx()
    val cx = w / 2
    val half = w * 0.30f

    face(listOf(Offset(cx, w * 0.12f), Offset(cx + half, w * 0.40f), Offset(cx, w * 0.52f)),
        s.fill.shade(1.15f), o)
    face(listOf(Offset(cx, w * 0.12f), Offset(cx - half, w * 0.40f), Offset(cx, w * 0.52f)),
        s.fill.shade(0.95f), o)
    face(listOf(Offset(cx - half, w * 0.40f), Offset(cx, w * 0.52f), Offset(cx, w * 0.90f)),
        s.fill.shade(0.78f), o)
    face(listOf(Offset(cx + half, w * 0.40f), Offset(cx, w * 0.52f), Offset(cx, w * 0.90f)),
        s.fill.shade(0.58f), o)
}

private fun DrawScope.tower(s: Sticker) {
    val w = size.width
    val o = 2.5f.dp.toPx()
    val cx = w / 2
    val half = w * 0.26f

    // Three stacked slabs, each slightly smaller — a podium read.
    for (i in 0..2) {
        val topY = w * (0.22f + i * 0.20f)
        val h = w * 0.14f
        val inset = half * (1f - i * 0.16f)
        face(
            listOf(
                Offset(cx, topY - h * 0.5f),
                Offset(cx + inset, topY),
                Offset(cx, topY + h * 0.5f),
                Offset(cx - inset, topY),
            ),
            s.fill.shade(1.15f - i * 0.1f), o,
        )
        face(
            listOf(
                Offset(cx - inset, topY), Offset(cx, topY + h * 0.5f),
                Offset(cx, topY + h * 1.2f), Offset(cx - inset, topY + h * 0.7f),
            ),
            s.fill.shade(0.8f - i * 0.06f), o,
        )
        face(
            listOf(
                Offset(cx + inset, topY), Offset(cx, topY + h * 0.5f),
                Offset(cx, topY + h * 1.2f), Offset(cx + inset, topY + h * 0.7f),
            ),
            s.fill.shade(0.6f - i * 0.05f), o,
        )
    }
}

private fun DrawScope.coin(s: Sticker) {
    val w = size.width
    val o = 3.dp.toPx()
    val cw = w * 0.62f
    val ch = cw * 0.34f
    val left = (w - cw) / 2
    val top = w * 0.34f
    val thick = ch * 0.7f

    val body = Path().apply {
        moveTo(left, top + ch / 2)
        lineTo(left, top + ch / 2 + thick)
        arcTo(
            androidx.compose.ui.geometry.Rect(
                Offset(left, top + thick),
                androidx.compose.ui.geometry.Size(cw, ch),
            ),
            180f, -180f, false,
        )
        lineTo(left + cw, top + ch / 2)
        close()
    }
    drawPath(body, s.fill.shade(0.66f))
    drawPath(body, Ink, style = Stroke(o))

    drawOval(s.fill.shade(1.12f), Offset(left, top), androidx.compose.ui.geometry.Size(cw, ch))
    drawOval(Ink, Offset(left, top), androidx.compose.ui.geometry.Size(cw, ch), style = Stroke(o))
}

private fun DrawScope.prism(s: Sticker) {
    val w = size.width
    val o = 3.dp.toPx()
    val cx = w / 2
    val half = w * 0.30f

    face(listOf(Offset(cx, w * 0.16f), Offset(cx + half, w * 0.76f), Offset(cx - half, w * 0.76f)),
        s.fill.shade(1.1f), o)
    face(listOf(Offset(cx, w * 0.16f), Offset(cx - half, w * 0.76f), Offset(cx - half * 0.2f, w * 0.88f)),
        s.fill.shade(0.72f), o)
    face(listOf(Offset(cx, w * 0.16f), Offset(cx + half, w * 0.76f), Offset(cx - half * 0.2f, w * 0.88f)),
        s.fill.shade(0.55f), o)
}

private fun DrawScope.orb(s: Sticker) {
    val w = size.width
    val o = 3.dp.toPx()
    val r = w * 0.30f
    val c = Offset(w / 2, w * 0.52f)

    drawCircle(s.fill.shade(0.7f), r, c)
    // A highlight offset up-left is the cheapest possible sphere: the eye
    // reads the gradient as a curved surface immediately.
    drawCircle(s.fill.shade(1.2f), r * 0.62f, Offset(c.x - r * 0.24f, c.y - r * 0.26f))
    drawCircle(s.fill.shade(1.45f), r * 0.22f, Offset(c.x - r * 0.36f, c.y - r * 0.38f))
    drawCircle(Ink, r, c, style = Stroke(o))
}
