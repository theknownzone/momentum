#!/usr/bin/env python3
"""Draft English translations for Momentum's remaining Hinglish strings.

Run this on your own machine, not on a user's phone. It reads the Kotlin
sources, finds the user-facing strings that have not been migrated into
ui/i18n yet, and asks Chutes for a first pass. It writes drafts to a JSON
file for you to read and correct — nothing goes near the app automatically.

    export CHUTES_API_KEY=...
    python3 tools/draft_translations.py --repo . --out translations.json

Options:
    --limit N     stop after N strings (use a small number the first time)
    --batch N     strings per request (default 20)
    --model NAME  Chutes model id

WHY THE PLACEHOLDERS ARE MASKED
    Strings carry things like ${data.examName} and "%dh %02dm". A model that
    rewrites one of those either breaks the build or silently prints the wrong
    number. So they never reach the model: each is swapped for a marker, and
    the original is put back afterwards, byte for byte. Any reply whose markers
    don't match goes to the needs_check list instead of the drafts.

WHAT THIS IS NOT
    It is not a translator you can trust unread. The Hinglish in this app is a
    voice, not just a language, and a first pass will flatten it. Read every
    line before it ships.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

API_URL = "https://llm.chutes.ai/v1/chat/completions"
DEFAULT_MODEL = "deepseek-ai/DeepSeek-V3.2"

# ---------------------------------------------------------------- extraction

SKIP_PAT = [
    re.compile(r"_"),
    re.compile(r"^https?://"),
    re.compile(r"^android[.:]"),
    re.compile(r"^com\.[a-z]"),
    re.compile(r"^[a-z]+\.[a-z]+\."),
    re.compile(r"^#[0-9a-fA-F]{3,8}$"),
    re.compile(r"^[\d\s%.:+\-/*()]+$"),
    re.compile(r"^\W+$"),
]

# Strings that must stay exactly as they are. "General" is the bucket that
# subject-less sessions are saved under; "Full Changelog" is a prefix used to
# filter remote release notes. Translating either breaks matching, not wording.
NEVER = {"General", "Full Changelog", "HH:mm"}


def scan_kotlin(src: str):
    """Yield (line, text) for every string literal, skipping comments."""
    out, i, n, line = [], 0, len(src), 1
    while i < n:
        c = src[i]
        if c == "\n":
            line += 1
            i += 1
        elif c == "/" and i + 1 < n and src[i + 1] == "/":
            while i < n and src[i] != "\n":
                i += 1
        elif c == "/" and i + 1 < n and src[i + 1] == "*":
            i += 2
            while i + 1 < n and not (src[i] == "*" and src[i + 1] == "/"):
                line += src[i] == "\n"
                i += 1
            i += 2
        elif c == "'":
            i += 1
            while i < n and src[i] != "'":
                i += 2 if src[i] == "\\" else 1
            i += 1
        elif src.startswith('"""', i):
            i += 3
            start, buf = line, []
            while i < n and not src.startswith('"""', i):
                line += src[i] == "\n"
                buf.append(src[i])
                i += 1
            i += 3
            out.append((start, "".join(buf)))
        elif c == '"':
            i += 1
            start, buf = line, []
            while i < n and src[i] != '"':
                if src[i] == "\\" and i + 1 < n:
                    buf.append(src[i:i + 2])
                    i += 2
                    continue
                line += src[i] == "\n"
                buf.append(src[i])
                i += 1
            i += 1
            out.append((start, "".join(buf)))
        else:
            i += 1
    return out


def is_translatable(t: str) -> bool:
    t = t.strip()
    if t in NEVER or len(t) < 2 or " " not in t:
        return False
    if not re.search(r"[A-Za-z]", t):
        return False
    return not any(p.match(t) for p in SKIP_PAT)


def collect(repo: str):
    root = os.path.join(repo, "app/src/main/java/com/momentum/focus")
    if not os.path.isdir(root):
        sys.exit(f"not a Momentum checkout: {root} missing")
    found = {}
    for dirpath, _, files in os.walk(root):
        rel_dir = os.path.relpath(dirpath, root)
        # ui/i18n holds the finished tables — that is the destination.
        if rel_dir.startswith("ui/i18n"):
            continue
        for f in sorted(files):
            if not f.endswith(".kt"):
                continue
            path = os.path.join(dirpath, f)
            with open(path, encoding="utf-8") as fh:
                for line, text in scan_kotlin(fh.read()):
                    if is_translatable(text):
                        found.setdefault(text, f"{os.path.relpath(path, root)}:{line}")
    return found


# ------------------------------------------------------------- placeholders

PLACEHOLDER = re.compile(
    r"\$\{[^}]*\}"          # ${data.examName}
    r"|\$[A-Za-z_]\w*"      # $minsNow
    r"|%[-0-9.]*[sdfx]"     # %dh, %02dm, %.1f
    r"|\\n|\\\"|\\t"        # escapes
)


def mask(text: str):
    slots = []

    def take(m):
        slots.append(m.group(0))
        return f"\u27e6{len(slots) - 1}\u27e7"

    return PLACEHOLDER.sub(take, text), slots


def unmask(text: str, slots: list[str]):
    """Put the originals back. Returns None if the markers were disturbed."""
    seen = sorted(int(m) for m in re.findall(r"\u27e6(\d+)\u27e7", text))
    if seen != list(range(len(slots))):
        return None
    for idx, original in enumerate(slots):
        text = text.replace(f"\u27e6{idx}\u27e7", original)
    return text


# -------------------------------------------------------------------- model

SYSTEM = """You translate UI strings for Momentum, an Android study app used by \
Indian students preparing for exams like JEE, NEET, UPSC and IBPS.

The source is Hinglish: Hindi written in Latin script, mixed with the English \
words students actually use — focus, session, streak, shield, wallet. Some \
strings are already fully English.

Translate each string into natural English. Rules:
- Keep the register: plain, direct, second person, no marketing tone. The app \
never scolds and never congratulates itself.
- A string already in English usually needs no change. Return it unchanged.
- Never translate proper nouns: exam names, app names, subject names, Momentum, \
Shorts, Reels, Shield, Crown, Light, Lock.
- Markers like ⟦0⟧ are placeholders. Copy them through exactly, same count, and \
put them where the English sentence needs them.
- Keep it about as short as the original. These sit in narrow phone layouts.

Reply with a JSON object only: keys are the exact input strings, values are the \
English. No prose, no code fences."""


def ask(model: str, key: str, batch: list[str], retries: int = 3) -> dict:
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": json.dumps(batch, ensure_ascii=False, indent=1)},
        ],
        "max_tokens": 4000,
        "temperature": 0.2,
        "stream": False,
    }
    req = urllib.request.Request(
        API_URL,
        data=json.dumps(payload).encode(),
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
        },
    )
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                body = json.load(r)
            text = body["choices"][0]["message"]["content"]
            text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
            return json.loads(text)
        except (urllib.error.URLError, KeyError, json.JSONDecodeError) as e:
            wait = 5 * (attempt + 1)
            print(f"    retry {attempt + 1}/{retries} after {e} ({wait}s)", file=sys.stderr)
            time.sleep(wait)
    return {}


# --------------------------------------------------------------------- main

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".")
    ap.add_argument("--out", default="translations.json")
    ap.add_argument("--model", default=DEFAULT_MODEL)
    ap.add_argument("--batch", type=int, default=20)
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    key = os.getenv("CHUTES_API_KEY")
    if not key:
        return print("set CHUTES_API_KEY first", file=sys.stderr) or 1

    found = collect(args.repo)
    print(f"{len(found)} translatable strings in the tree")

    # Resume: never pay twice for a string already drafted.
    done = {}
    if os.path.exists(args.out):
        with open(args.out, encoding="utf-8") as fh:
            done = json.load(fh).get("drafts", {})
        print(f"{len(done)} already drafted in {args.out}, skipping those")

    todo = [t for t in found if t not in done]
    if args.limit:
        todo = todo[:args.limit]
    if not todo:
        print("nothing to do")
        return 0
    print(f"drafting {len(todo)} in batches of {args.batch}\n")

    needs_check = {}
    for start in range(0, len(todo), args.batch):
        chunk = todo[start:start + args.batch]
        masked, slotmap = [], {}
        for original in chunk:
            m, slots = mask(original)
            masked.append(m)
            slotmap[m] = (original, slots)

        print(f"  [{start + 1}-{start + len(chunk)}/{len(todo)}]", flush=True)
        reply = ask(args.model, key, masked)

        for m, (original, slots) in slotmap.items():
            english = reply.get(m)
            if english is None:
                needs_check[original] = "no reply"
                continue
            restored = unmask(english, slots)
            if restored is None:
                # Placeholders came back wrong — this is exactly the failure
                # that would have shipped a broken format string.
                needs_check[original] = f"placeholder mismatch: {english}"
                continue
            done[original] = restored

        # Written every batch, so a crash costs one batch and not the run.
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(
                {"drafts": done, "needs_check": needs_check, "source": found},
                fh, ensure_ascii=False, indent=1,
            )

    print(f"\n{len(done)} drafted, {len(needs_check)} need a look")
    print(f"written to {args.out}")
    print("\nRead them before using any of it. Especially anything that")
    print("sounded like a person rather than a label.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
