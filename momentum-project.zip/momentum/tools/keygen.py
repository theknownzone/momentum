#!/usr/bin/env python3
"""
Momentum licence key generator.

Run this on your own machine after each sale and send the key to the buyer.
Keep it off the phone and out of any public repo — anyone holding this file
and the secret can mint unlimited keys.

    python3 keygen.py            # one key
    python3 keygen.py 25         # twenty-five keys

SECRET must match License.SECRET in the app exactly, character for character.
Change both together, and remember that changing it invalidates every key
already sold.
"""

import hmac
import hashlib
import secrets
import sys

SECRET = "momentum-change-me-before-selling"
ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"   # no I, L, O, U - misread by hand
PREFIX = "MOM"


def checksum(payload: str) -> str:
    digest = hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).digest()
    return "".join(ALPHABET[digest[i] % len(ALPHABET)] for i in range(5))


def mint() -> str:
    payload = "".join(secrets.choice(ALPHABET) for _ in range(10))
    body = PREFIX + payload + checksum(payload)
    return f"{body[:3]}-{body[3:8]}-{body[8:13]}-{body[13:]}"


if __name__ == "__main__":
    count = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    for _ in range(count):
        print(mint())
