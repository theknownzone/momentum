# Momentum

A study-focus and habit-recovery app for Android. Paper-cutout UI, spring
animations, haptics on every state change. Jetpack Compose, no backend, all
data stays on the device.

## Screens

| Screen | What it does |
|---|---|
| Home | Streak ring, today's stats, one-tap panic button |
| Focus | 25/50/90 min timer, subject chips, haptic tick every minute |
| Panic | 4-7-8 breathing pacer synced to haptics, urge logging |
| Stats | 14-day bar chart, week-over-week delta, urge-hour pattern |
| Journal | Mood 1-5, trigger tags, daily note |

---

## Getting an APK without a PC

You do not need Android Studio or a computer. GitHub will build it for you free.

1. Make a GitHub account, create a new **public** repository
2. Upload every file from this folder into it, keeping the folder structure
3. Open the **Actions** tab → click **Build APK** → **Run workflow**
4. Wait about 5 minutes
5. Open the finished run → scroll to **Artifacts** → download `momentum-debug-apk`
6. Unzip it on your phone and install. Allow "install from unknown sources"

That's it. Every time you push a change, a fresh APK appears.

## Building on a PC instead

Open the folder in Android Studio (Ladybug or newer), let it sync, press Run.
Android Studio generates the Gradle wrapper automatically on first sync.

---

## Before you publish to Play Store

Right now this builds as a **debug** APK signed with a throwaway key — fine for
your own phone, rejected by Play. To publish:

1. Generate an upload keystore (Android Studio → Build → Generate Signed Bundle)
2. Store the keystore and passwords as GitHub repository **secrets**, never in
   the repo itself
3. Switch the workflow to `bundleRelease` and upload the `.aab`, not an APK
4. Change `applicationId` in `app/build.gradle.kts` to something you own

Also worth knowing before you add app blocking: using `AccessibilityService` to
block apps triggers a Play policy review that rejects most submissions. Use
`UsageStatsManager` instead — it needs the `PACKAGE_USAGE_STATS` permission
granted through system settings, and Play accepts it for wellbeing apps.

---

## Where things live

```
data/Models.kt        Serializable state, streak and stat calculations
data/AppStore.kt      DataStore persistence, whole state as one JSON blob
ui/AppViewModel.kt    Timer clock, streak/urge/journal actions
ui/theme/             Colors, type scale, springs, spacing
ui/util/Haptics.kt    Seven named haptic patterns, API-guarded
ui/components/Paper.kt  paperGrain, StickerCard, StreakRing, SquishButton
ui/nav/               Bottom bar
ui/screens/           The five screens
```

### The four rules that make it feel right

Keep these consistent as you add screens, or the whole look falls apart.

1. **Never pure white or pure black.** Warm off-white, ink-brown dark mode.
2. **Hard offset shadows, never blur.** Blur reads as glass, offset reads as paper.
3. **Springs everywhere, no tweens.** `Motion.press()`, `bouncy()`, `settle()`.
4. **Haptics on state changes, not every touch.** Constant buzzing gets turned off.

## Upgrading the typography

`Type.kt` uses system fonts so this builds with zero downloads. For the real
look: put Fraunces (display) and Inter (body) from Google Fonts into
`app/src/main/res/font/`, then swap the two families at the top of `Type.kt`.
Both are OFL licensed and safe to ship commercially.

## Not built yet

- App blocking service via `UsageStatsManager`
- Notifications and milestone celebrations
- Home screen widget
- Backup export/import (`AppStore.serialize` is already there for it)
- Settings screen for name, goal length and subject list

## A note on the recovery side

This app tracks and encourages — it is not treatment. If the habit someone is
fighting is seriously disrupting their life, an app is a support, not a
substitute for talking to a doctor or counsellor. Worth saying plainly in your
Play Store listing too; it builds trust rather than costing you installs.
