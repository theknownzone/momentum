# Momentum — Full Audit & Improvement Plan (2026-09-29)

Verified against the actual source, not memory. Every item has file:line.
`tools/scan.py` baseline: **clean, exit 0** (153 files, 22 string interfaces, 44 tables).

---

## P0 — Real user-facing bugs (fix first)

### 1. Back button is a dead end on FocusMachineScreen
`MainActivity.kt:577-579` — `fullScreen` expression:
```kotlin
val fullScreen = panicOpen || profileOpen || settingsOpen || permsOpen ||
    blockListOpen || feedGuardOpen || profilesOpen || blockHubOpen ||
    plansOpen || changelogOpen || supportOpen
```
`focusMachineOpen` is **missing**. The `BackHandler` at line 597 even has a
`focusMachineOpen -> focusMachineOpen = false` branch — but the handler is
gated by `enabled = fullScreen`, which is false while FocusMachine is the only
overlay open. Since it's opened from Home (tab == HOME, line 846), the second
BackHandler (tab → HOME) is also disabled. **Result: Back does nothing; user
is stranded and has to kill the app.**
**Fix:** add `|| focusMachineOpen` to line 577. One line. This also correctly
hides the tab bar while the machine is open (the `!fullScreen && !hideBar`
gate at line 665).

### 2. MockSheet Back behaviour is janky
`mockOpen` is also not in `fullScreen`. MockSheet renders inside the Scaffold
content (line 959), so Back on the mock drill jumps the tab to HOME while the
sheet stays floating on top. **Fix:** add `mockOpen` to `fullScreen` and add a
`mockOpen -> { mockOpen = false; vm.clearMock() }` branch to the BackHandler
(before `blockHubOpen`, mirroring how the sheet sits above the tabs).

### 3. Clear skies read as cloudy
`data/Weather.kt:81-87`:
```kotlin
code <= 1 && tempC >= 26 -> WeatherCondition.SUN
else -> WeatherCondition.CLOUD
```
WMO 0–1 is clear/few-cloud; anything clear under 26 °C falls into `else` →
☁️. The whole Home hero weather layer is wrong on most clear days.
**Fix:** `code <= 1 -> WeatherCondition.SUN`.

### 4. Self-recursive, never-populated model field
`data/Models.kt:95` — `BlockProfile` contains `profiles: List<BlockProfile>`.
The real list lives on `AppData` (used at `AppViewModel.kt:1201,1216,1238`);
nothing ever writes to the nested one. It's a serialization footgun (recursion
on read if it ever got data) and dead weight.
**Fix:** delete the field. **Safe:** `AppStore.kt:23` has
`ignoreUnknownKeys = true`, so existing saved profiles decode fine after the
field is gone.

### 5. Hardcoded Hinglish toast in the blocking engine
`block/ShortsGuard.kt:390`: `Toast.makeText(this, "${surface.label} band hai", ...)`
This fires *outside* the Compose tree, so it can't call `strings()` directly.
**Fix:** expose the two-locale copy from `ui/i18n` as a plain function
(e.g. `stringsFor(lang).blockSurface(label)`) — `Lang` is already persisted in
`AppData`, readable from the context via a small accessor — or at minimum
store the formatted string at the call site where locale is known.

### 6. Dead CTA on the "JUST UPDATED" hero slide
`ui/screens/HomeScreen.kt:685-697` — `HeroBannerCarousel`'s `just_updated`
slide has a `{}` no-op click, with a comment admitting no callback is threaded.
But `HomeScreen` **already receives** `onOpenChangelog` (MainActivity.kt:852).
**Fix:** add `onOpenChangelog: () -> Unit` to `HeroBannerCarousel`'s signature
and pass it through. The slide now does what its CTA ("See what's new") says.

### 7. Hardcoded Hinglish inside the Compose tree
`ui/screens/HomeScreen.kt:513` — `"Autostart kholne ke liye tap karo →"`
in the shield-dead card, while every line around it uses `str.home.*`.
**Fix:** add to `HomeStrings` (all 19 locale files) and use it.

---

## P1 — i18n sweep (39 hardcoded Hinglish lines outside `ui/i18n/`)

Counted with a strict pass (i18n dir excluded):

| File | Lines |
|---|---|
| `ui/screens/SupportScreen.kt` | 10 |
| `ui/components/InsightDeck.kt` | 7 (quote *content* — decide: localizable content or permanent Hinglish brand voice) |
| `ui/components/FeedDebugDialog.kt` | 5 (debug-only; lowest priority) |
| `ui/AppViewModel.kt` | 4 (user-facing strings returned from the VM — lines 200, 410 + 2) |
| `ui/screens/SettingsScreen.kt` | 4 |
| `ui/util/StudyNudge.kt` | 2 (notification text) |
| `ai/Ai.kt`, `PactBanner.kt`, `UpdateCard.kt`, `block/ShortsGuard.kt`, `data/FeedSurfaces.kt` | 1 each |

Pattern for each: add the key to the matching interface, fill every locale
(`tools/draft_translations.py` exists for exactly this), swap the literal.

---

## P1 — Product decisions needed from pacman (not code bugs)

- **`HomeScreen.kt:330` — `targetMinutes = 180`** in `CeramicProgressBar` is
  hardcoded. There is no per-user daily goal in `AppData` for minutes
  (`streakGoal` is days). Decide: fixed product number, or a new setting?
  Don't improvise one.
- **Pro vs Pro Plus = same `premium` boolean** (`PlansScreen.kt:111-120`,
  documented in-file): buying "Pro" grants everything Pro Plus lists. This is
  the *documented* pre-subscription state — per `CLAUDE_PROJECT_RULES.md` the
  tier work waits on the payment-platform decision. The tier split (features,
  gestures, points/colours, level definition) is already listed there for that
  day. Nothing to do now; flagged so it isn't "fixed" half-way or forgotten.
- **Yearly/Monthly pill** — cosmetic by decision. Leave.

---

## P2 — Ship checklist (security / release, all already documented, must not be skipped)

1. **`myaifix` key** — `MainActivity.kt:228,888`. Temporary dev shutter over
   MyAI with the key hardcoded in source. Remove the whole block (plus the
   check) before the app goes public. Comment even says so.
2. **`MOMENTUM_LICENSE_SECRET`** — must be set before the first sale. Until
   then anyone reading the public repo mints valid keys (README §Build
   secrets; `data/License.kt` fallback is the shipped placeholder by design).
   Changing it invalidates all placeholder-minted keys — do it pre-sale, not
   post-sale.
3. **`MOMENTUM_STORE_URL`** — buy button is inert until a real HTTPS store
   URL exists (the store itself isn't built yet — per the rules, no fake
   routing before the decision).
4. **Play Store** — currently debug-signed throwaway key; needs upload
   keystore as repo secrets + `bundleRelease` + own `applicationId`
   (README §Before you publish). Also the README's own warning stands:
   Accessibility-based blocking risks Play rejection — the app uses
   `UsageStatsManager` for the core, but the Accessibility pieces should be
   double-checked against policy before submission.

---

## P2 — Engineering hardening

- **Zero tests.** Highest-value first tests are pure and cheap:
  streak/XP math in `data/Models.kt` (streak calc, `XP_PER_LEVEL` rollover),
  `License.kt` verify/format round-trip, `Weather.codeToCondition` buckets
  (the P0#3 bug is exactly what one test would have caught).
- **No Gradle wrapper** — CI self-provisions 8.9, so it's not broken, but
  `gradle wrapper --gradle-version 8.9` once removes a local-build dependency
  on a matching install (README already documents the command).
- **`MainActivity.kt` is 1,061 lines** and owns all overlay state + the
  back-stack ordering whose subtlety is documented in comments (e.g. the
  settings-before-profile ordering fix, lines 795-800). P0#1 shows why that
  ordering is load-bearing. Refactoring it is possible (extract an
  `OverlayState` + `BackStack` object with unit tests for the ordering) but
  **not worth doing in the same pass as the bug fixes** — do it after P0/P1
  land, with the back-order tests written first.
- Large-but-fine files for later, if ever needed: `HomeScreen` 1,927 /
  `PlansScreen` 1,574 / `AppViewModel` 1,375 lines. No action now.

---

## What is already good (don't touch)

- `tools/scan.py` passes clean; cross-references all resolve; asset copies
  identical; no stale TODO/FIXME markers (only `MOM-XXXXX` key placeholders).
- Sfx synthesis (glass partials, PANIC deliberately not a reward sound),
  the four design rules (no pure white/black, hard offset shadows, springs
  only, haptics on state changes) are followed consistently.
- Shield-pill guard (`blockedPackages.isNotEmpty()`), Crown-during-session
  locking, Plans single-scroll-column rebuild, PremiumWelcomeScreen close,
  Updater chooser fallback — all confirmed in place per the rules file.
- No keystore or secrets committed; `.gitignore` covers them.

---

## Suggested order of attack

1. P0 #1–#7 as one small verified batch (each ≤ a few lines; run
   `tools/scan.py` after).
2. P1 i18n sweep in one pass (mechanical, `draft_translations.py` assists).
3. Ask pacman the two P1 product questions (180-min target; nothing needed on
   tiers yet).
4. P2 ship checklist when pacman is near a release.
5. Tests for Models/License/Weather before the MainActivity refactor, which
   comes last — if at all, this cycle.
