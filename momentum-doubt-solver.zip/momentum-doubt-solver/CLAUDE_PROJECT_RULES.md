# Momentum — standing rules for whoever works on this next

These came directly from the product owner (pacman) on 2026-09-27. They apply
to every future change, by any AI or human, until pacman changes them.

1. **HTML reference = literal spec.** When a reference mockup exists, match it
   exactly — colours, gradients, spacing, radii. No silent "I'll interpret
   this differently" calls. If following it literally would visibly clash
   with something else in the app (e.g. two tiers using the same colour),
   say so and ask, rather than quietly picking a different value.
2. **Professional only, never "kiddish."** UI, icons, style, colour, sound,
   features — all of it. No cheap-looking placeholder art, no toy vector
   clip-art that doesn't match the app's own illustrated style.
3. **Whatever you touch, polish it.** Don't leave a half-finished edge next
   to a finished one.
4. **Say when something is past you.** If a task is beyond what you can
   verify or build confidently, say so plainly and suggest the person switch
   to a stronger model for that piece, rather than guessing.
5. **Don't rebuild/deliver a zip after every micro-fix.** Make the code
   changes, keep a running list of what changed, and only package + present
   the zip when the person explicitly asks for it. Mid-stream zips full of
   half-verified fixes are worse than one clean one at the end.
6. **Dopamine / brainrot energy in EVERY fix and update — no exceptions,
   including backend/technical work.** This was tested explicitly on
   2026-09-28: an import-scan (pure code verification, no UI surface) was
   first treated as exempt ("nothing visual to add energy to"), and pacman
   corrected that — flatly, "is must." Where a fix has a real UI/sound
   surface, add the actual glow/motion/sound. Where it genuinely doesn't
   (a code scan, an import fix, a data-model change), the visible surface
   is the response reporting it — make that reporting itself energetic and
   engaging rather than a flat status report. "No user-facing UI here" is
   not a reason to drop this rule; find the surface that does exist
   (the report, the summary, the delivery) and put the energy there.

   **But dopamine/brainrot is not the same as kiddish/fast/gamey — the
   two get confused easily and must not be.** Stated explicitly on
   2026-09-29, the same day as the "last update": no kids-style sounds,
   no childish emoji-driven animation, nothing that moves FAST just to
   feel busy. None of that actually builds real user trust or engagement
   — it reads as a toy, not as a serious tool. What earns trust instead:
   proper illustration quality (the mascots, the comic-paper linework),
   and animation that is *paced* — deliberate timing, real easing, motion
   that respects the moment (a purchase-confirm settles, it doesn't
   spazz) — the same restraint already documented for Sfx.kt's sound
   design (glass partials over cheap beeps, PANIC not sounding like a
   reward). Energetic and well-crafted, not fast and cartoonish. When in
   doubt, favor the slower, more considered version of an effect.
7. **This file is the memory.** Keep it current. Anything that reads this
   repo's source (a different AI, a future session) should be able to open
   this file and immediately know how to work here.
8. **Ask before using a connector.** If a task needs an external
   connector/integration, name it and ask first rather than assuming access.
9. **No childish vector-art additions.** The app has one established theme
   (paper/comic, flat fills + Ink outlines, the existing mascot set) —
   anything new must sync with that, not introduce a different illustration
   style.
10. **If you can't produce a design, say so — and name a specific
    alternative AI** the person could ask instead, rather than a vague "get
    help elsewhere."

## Working-language rule
Pacman writes instructions in Hinglish. Before acting on a Hinglish
instruction, restate it as a clean, structured prompt (in the response,
before doing the work) — translating and organizing it — rather than working
directly off the mixed-language original. This has been observed to reduce
misreads.

## Known, deliberate product decisions (don't "fix" these back)
- **Pro / Pro Plus stay one-time, key-based purchases for now.** A real
  monthly/yearly subscription needs two things pacman confirmed on
  2026-09-27: (1) actual recurring-billing products on an external payment
  platform (a website — not built yet) or a Play Store billing switch
  (possible later, not decided), and (2) the app-side plumbing (license
  carrying a subscription type + expiry, expiry-checked and reverting to
  free, real differing monthly/yearly prices, the buy button routing to the
  right product). Neither side is being built yet — there is nothing to wire
  the Plans screen's Yearly/Monthly pill to. Do not add fake price changes or
  partial subscription logic before pacman actually has a platform decision
  and (if a website) real product links. When that day comes, design context
  pacman flagged to remember: plan **features** per tier, **gesture**
  interactions, **points/colours** per tier, and a **level** definition —
  all of this needs deciding as part of that feature, not improvised then.
  Until then the Yearly/Monthly pill is cosmetic only (see below).
- **The Yearly/Monthly pill on Plans is cosmetic only** — added to match a
  reference screenshot, confirmed by pacman ("1"). It changes no price.
  Revisit once the subscription decision above is actually made.
- **Floating Shield pill only shows when something is actually blocked.**
  `if (data.blockedPackages.isNotEmpty())` guards it in HomeScreen.kt — do not
  remove this guard or show the pill (or a "0" count) when nothing is
  blocked. Confirmed already correct on 2026-09-27; kept here since pacman
  flagged it as important to not regress.
- **Crown Mode locking an app during an active focus session is intended
  behaviour**, not a bug — it's the commitment device the feature exists to
  provide.
- **Shield popup redesign is on hold** pending a new reference HTML from
  pacman specifically for it. Don't re-redesign it speculatively in the
  meantime; fix concrete bugs in the current version only.

## Log of major fixes (most recent first)
Kept short — see git history / chat for full detail once this repo has one.
- 2026-09-30: premium-welcome.html v2.1 — THREE owner-reported bugs: (1)
  slip vanished after flight: `docked` state sat on the ceremony root but
  the CSS rule expected it on the cert → selector fixed (`.docked .cert`).
  (2) Sound unreliable: AudioContext now try/catch-guarded, resumes on any
  pointerdown (mobile autounlock), master gain .22→.3. (3) Features flat:
  chips now carry accent-tinted gradients + paper grain, monoline ink
  icons (accent stroke), per-chip glow bloom + one-pass shine sweep, and
  chipsIn fires 6 staggered tick sounds (rule 6, rule 9).
- 2026-09-30: `design/premium-welcome.html` v2 (pacman feedback on v1:
  slip falling was not readable + no sound + wanted more polish). Added:
  WebAudio sound engine (tick / thunk / whoosh / shimmer / paper / knock /
  chime / success — quiet-luxury, no beeps, master toggle in rail),
  vault-mouth printing (certificate now feeds OUT of the open doorway —
  scale-up toward viewer → arc → visible fall to dock, 1.55 s, gravity-ish
  settle), ground shadow on landing, gold edge pulse, serial etch № 0499,
  vault slot, ember drift, seal glint. All visual↔sound beats on one clock.
- 2026-09-30: `design/premium-welcome.html` REBUILT as an original design
  (pacman: code-copy nahi chahiye — Claude wo design pehle se bana chuka).
  Previous 1:1 spec moved to `design/premium-welcome-literal.html`. New
  concept "VAULT № 0499" on the app's own line "focus, banked": ratchet
  clicks → bolt clunk → 1.5 s door swing → banked-focus coins glow →
  certificate floats out → PAID ink stamp → wax seal → chip-grid features
  → CTA. Paced/deliberate per rule 6. Same palette/fonts; chip-grid
  features are the one deliberate departure from the app's list card.
- 2026-09-30: PremiumWelcomeScreen — deleted PremiumBadge's dead `rotation`
  rememberInfiniteTransition (ran an invisible 20 s loop forever).
- 2026-09-30: PremiumWelcomeScreen — screen now scrolls: fixed 200 dp hero +
  cards + CTA could clip the CTA off short viewports/large font scale (the
  unused verticalScroll imports were a leftover of an unfinished attempt;
  Spacer weight would crash in a scrollable Column → replaced with 20 dp).
- 2026-09-30: `design/premium-welcome.html` completed (previous session had
  stalled at a 3 KB stub — CSS variables only). Full literal reference now:
  Scene A = UnlockReceipt 20 s printer ceremony (one linear clock; feed-
  slaved beam/head-lights/paper-mask, Tang→CreamCard split mask at the 64 dp
  header, 1.5 dp Tang.accent print-edge line, atmosphere canvas with ghost
  arc + pulsing bloom + 18-ray end burst, skip pill, lift-out 620 ms
  FastOutSlowIn). Scene B = PremiumWelcomeScreen four phases (literal
  22-piece confetti formula, 12-spike POW star with staggered halftone,
  badge with 2.8 s BreathingOrb + 24 s 16-spoke Starburst + halftone
  diamond, edge gold pulse 2.2 s, features card, PowerButton 5 dp hard
  shadow sink-on-press). All colours from Color.kt, timings from the .kt
  files. JS syntax verified via node --check; tags balanced; no dup ids.
- 2026-09-29: i18n sweep finished. Every user-facing Hinglish literal outside
  `ui/i18n/` moved into the string tables (25 interfaces, 50 tables, scanner
  clean). Files touched: AppViewModel (start/block gates, empty-answer error,
  nudge lang), FocusScreen + CrownStrings (drop-Crown dialog), PlansScreen
  (remove-key dialog), SettingsScreen (pact banners, target section, help
  tile), HomeScreen (notify sheet, holiday headline), MockSheet (picker),
  FeedGuardScreen + FeedSurfaces (surface notes now keyed by surface key),
  FeedDebugDialog, UpdateCard (notes toggle + default notes), SupportScreen
  (whole screen, new SupportStrings), JournalScreen (new JournalStrings),
  InsightDeck (generated usage cards, new InsightStrings), notifications
  (FocusNotice, StudyNudge now speak the user's lang), HolidayCalendar
  (headline moved to HomeStrings). The only Hinglish literals left in the
  tree are the InsightDeck written-card fallback — that is shipped content
  (the same voice as cards.json), not UI.
- 2026-09-29: Full audit report written to `IMPROVEMENT_PLAN.md` (all findings
  verified against source; `tools/scan.py` clean).
- 2026-09-29: Back button was dead on FocusMachineScreen and janky on
  MockSheet — both were missing from the `fullScreen` gate in MainActivity
  (the BackHandler had the focusMachine branch but never enabled). Both now
  in the gate; mockOpen gets its own first branch that also clears the drill.
- 2026-09-29: `Weather.codeToCondition` only showed SUN above 26 C, so most
  clear days read as ☁️. Clear/few-cloud (WMO 0–1) now always SUN; the
  now-unused temp parameter dropped.
- 2026-09-29: Deleted the self-recursive, never-populated
  `BlockProfile.profiles` field (the real list lives on AppData). Safe for
  existing saves — AppStore decodes with `ignoreUnknownKeys = true`.
- 2026-09-29: ShortsGuard's feed-exit toast was hardcoded Hinglish in the
  service. New `feedGuard.feedSurfaceBlocked(surface)` string (hi/en); the
  service keeps the user's `lang` from the AppData it already collects.
- 2026-09-29: "JUST UPDATED" hero slide's CTA was a no-op. Threaded
  `onOpenChangelog` through HeroBannerCarousel (Settings passes it).
- 2026-09-29: HomeScreen's hardcoded "Autostart kholne ke liye tap karo →"
  moved to `home.openAutostart` (hi/en).
- 2026-09-27: PremiumWelcomeScreen onDismiss was wired to an empty lambda —
  the X button did nothing, matching the "screen freezes, no close button"
  report. Fixed to actually close.
- 2026-09-27: Updater.openDownload failed silently if no browser handled
  ACTION_VIEW. Now uses createChooser + a Toast fallback.
- 2026-09-27: Pro / Pro Plus card gap widened (mascot and the "BEST VALUE"
  tag were overlapping by about 1dp).
- 2026-09-27: Shield popup rebuilt so every element (header, each app row,
  the streak strip, both buttons) is its own bordered+shadowed card, matching
  the reference's actual structure instead of one big outer card.
- 2026-09-27: PlansScreen restructured off HorizontalPager onto a single
  scrolling column (the pager + fixed-height container was the root cause of
  a blank-card bug and a scroll-desync bug when switching tiers).
