package com.momentum.focus.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.GlassSection
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.rememberHaptics

/** Support inbox. Replace if this ever moves to a domain address. */
private const val SUPPORT_EMAIL = "barrytbrooks2@gmail.com"

/**
 * Help, feedback and the plain facts about what the app does with data.
 *
 * The device and build details are filled into the email body automatically.
 * Asking someone to find their Android version and app build before they can
 * report a bug is how bug reports stop arriving.
 */
@Composable
fun SupportScreen(data: AppData, onDone: () -> Unit) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val skin = LocalSkin.current
    val str = strings()

    fun mail(subject: String) {
        val body = buildString {
            append("\n\n\n---\n")
            append(str.support.emailKeepLines + "\n")
            append("App: Momentum ${Updater.currentVersion(context)}\n")
            append("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
            append("Device: ${Build.MANUFACTURER} ${Build.MODEL}\n")
            append("Plan: ${if (data.premium) "Lifetime" else "Free"}\n")
        }
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$SUPPORT_EMAIL"))
                    .putExtra(Intent.EXTRA_SUBJECT, subject)
                    .putExtra(Intent.EXTRA_TEXT, body)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        Text(str.support.kicker, style = MaterialTheme.typography.labelSmall, color = InkMid)
        Text(
            str.support.title,
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            str.support.subtitle,
            style = MaterialTheme.typography.bodyLarge,
            color = InkMid,
        )

        GlassSection(str.support.talkTitle, str.support.talkSub, tint = skin.accent, initiallyOpen = true) {
            SupportRow(
                str.support.bugRow,
                str.support.bugRowSub,
            ) { haptics.tap(); mail("Momentum — bug") }
            SupportRow(
                str.support.featureRow,
                str.support.featureRowSub,
            ) { haptics.tap(); mail("Momentum — feature") }
            SupportRow(
                str.support.paymentRow,
                str.support.paymentRowSub,
            ) { haptics.tap(); mail("Momentum — licence") }
        }

        GlassSection(str.support.dataTitle, str.support.dataSub, tint = skin.petal) {
            Fact(
                str.support.onPhoneTitle,
                str.support.onPhoneBody,
            )
            Fact(
                str.support.accessibilityTitle,
                str.support.accessibilityBody,
            )
            Fact(
                str.support.internetTitle,
                str.support.internetBody,
            )
        }

        Spacer(Modifier.height(20.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                .clickableNoRipple(remember { MutableInteractionSource() }) {
                    haptics.tap(); onDone()
                }
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(str.common.back, style = MaterialTheme.typography.titleMedium, color = Ink)
        }
    }
}

@Composable
private fun SupportRow(title: String, note: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
            Text(note, style = MaterialTheme.typography.bodyMedium, color = InkMid)
        }
        Text("\u203A", style = MaterialTheme.typography.headlineSmall, color = InkMid)
    }
}

@Composable
private fun Fact(title: String, body: String) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
        Text(body, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}
