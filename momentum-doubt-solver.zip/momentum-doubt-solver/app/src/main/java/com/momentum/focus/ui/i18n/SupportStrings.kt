package com.momentum.focus.ui.i18n

/**
 * The help screen.
 *
 * Built once with every line literal and never connected to the tables —
 * the same bug class as the tour overlay. The auto-filled email footer is a
 * string here too, because it is the one place the person reading the bug
 * report will also be reading the app.
 */
interface SupportStrings {
    val kicker: String
    val title: String
    val subtitle: String

    val talkTitle: String
    val talkSub: String
    val bugRow: String
    val bugRowSub: String
    val featureRow: String
    val featureRowSub: String
    val paymentRow: String
    val paymentRowSub: String

    val dataTitle: String
    val dataSub: String
    val onPhoneTitle: String
    val onPhoneBody: String
    val accessibilityTitle: String
    val accessibilityBody: String
    val internetTitle: String
    val internetBody: String

    /** The lines the bug-report email is pre-filled with. */
    val emailKeepLines: String
}

object SupportHi : SupportStrings {
    override val kicker = "HELP"
    override val title = "Kuch atka hai?"
    override val subtitle = "Seedha likh do. Jawab ek aadmi dega, bot nahi."

    override val talkTitle = "Baat karo"
    override val talkSub = "Email, bug, suggestion"
    override val bugRow = "Kuch toota hai"
    override val bugRowSub = "Bug report bhejo — device ki details apne aap lag jayengi"
    override val featureRow = "Kuch chahiye"
    override val featureRowSub = "Naya feature ya badlav suggest karo"
    override val paymentRow = "Paise ki dikkat"
    override val paymentRowSub = "Key nahi chali, ya payment ka sawaal"

    override val dataTitle = "Tumhara data"
    override val dataSub = "Kahan jaata hai"
    override val onPhoneTitle = "Sab kuch is phone pe hai"
    override val onPhoneBody =
        "Koi server nahi hai. Na account, na login. Jo tumne banaya wo " +
            "yahin rehta hai, aur app uninstall karne pe chala jaata hai."
    override val accessibilityTitle = "Screen padhne wali permission"
    override val accessibilityBody =
        "Accessibility sirf ye dekhne ke liye hai ki Shorts ya Reels " +
            "khuli hai ya nahi. Kuch bhejta nahi, kuch save nahi karta."
    override val internetTitle = "Internet kab lagta hai"
    override val internetBody =
        "Sirf update check karne ke liye. Baaki poora app offline chalta hai."

    override val emailKeepLines =
        "Ye lines rakh dena, inse dikkat dhoondhne mein aasani hoti hai."
}

object SupportEn : SupportStrings {
    override val kicker = "HELP"
    override val title = "Stuck on something?"
    override val subtitle = "Write it straight. A person answers, not a bot."

    override val talkTitle = "Get in touch"
    override val talkSub = "Email, bug, suggestion"
    override val bugRow = "Something is broken"
    override val bugRowSub = "Send a bug report — the device details fill in by themselves"
    override val featureRow = "Something you want"
    override val featureRowSub = "Suggest a new feature or a change"
    override val paymentRow = "Money problem"
    override val paymentRowSub = "A key did not work, or a payment question"

    override val dataTitle = "Your data"
    override val dataSub = "Where it goes"
    override val onPhoneTitle = "Everything is on this phone"
    override val onPhoneBody =
        "There is no server. No account, no login. What you build stays " +
            "here, and it goes away when the app is uninstalled."
    override val accessibilityTitle = "The screen-reading permission"
    override val accessibilityBody =
        "Accessibility is only used to see whether Shorts or Reels is " +
            "open. It sends nothing and saves nothing."
    override val internetTitle = "When the internet is used"
    override val internetBody =
        "Only to check for updates. The rest of the app runs offline."

    override val emailKeepLines =
        "Keep these lines — they make finding the problem easier."
}
