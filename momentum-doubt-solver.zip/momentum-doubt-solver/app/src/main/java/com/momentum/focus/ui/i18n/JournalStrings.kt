package com.momentum.focus.ui.i18n

/**
 * The journal screen — one entry a day.
 *
 * The screen was the one place in the app where the headings were English and
 * the title under them was Hinglish in both languages. Now it reads in the
 * language the app is set to, like everything else.
 */
interface JournalStrings {
    val kicker: String
    val todayTitle: String
    val triggersLabel: String
    val placeholder: String
    val saved: String
    val save: String
}

object JournalHi : JournalStrings {
    override val kicker = "AAJ"
    override val todayTitle = "Aaj ka hisaab"
    override val triggersLabel = "KYSI BAAT CHIDI"
    override val placeholder = "Teen line kaafi hain. Kya hua?"
    override val saved = "Save ho gaya"
    override val save = "Entry save karo"
}

object JournalEn : JournalStrings {
    override val kicker = "TODAY"
    override val todayTitle = "Today's tally"
    override val triggersLabel = "WHAT SET YOU OFF"
    override val placeholder = "Three lines is enough. What happened?"
    override val saved = "Saved"
    override val save = "Save entry"
}
