package com.momentum.focus.ui.i18n

/**
 * The mock test's text.
 *
 * The warning line is not a disclaimer bolted on at the end. These questions
 * are written by a model that can be confidently wrong about its own answer
 * key, so the screen says so before the first question rather than after the
 * score.
 */
interface MockStrings {
    val label: String
    val title: String
    val intro: String
    val warning: String
    val start: String
    val building: String
    val submit: String
    val again: String
    val close: String
    val why: String
    val empty: String
    fun scoreLine(right: Int, total: Int): String
    fun question(index: Int, total: Int): String
    val fromPage: String
    val fromSyllabus: String
    fun weakestHint(score: Int, total: Int): String
    val topicLabel: String
    val buildTest: String
    val buildHint: String
    /** The "you were weak here" suggestion card in the picker. */
    val weakerKicker: String
    /** The subject chips header in the picker. */
    val subjectLabel: String
    /** Under the topic box: what happens when it stays empty. */
    val topicEmpty: String
}

object MockHi : MockStrings {
    override val label = "MOCK"
    override val title = "10 sawaal"
    override val intro = "Chhota drill. Ek baithak, paanch sawaal, phir wapas kitaab pe."
    override val warning =
        "Ye sawaal AI ne banaye hain aur answer key galat bhi ho sakti hai. " +
            "Har jawab ke saath wajah di gayi hai — usse milao, andhaa vishwas mat karo."
    override val start = "Shuru karo"
    override val building = "Sawaal ban rahe hain"
    override val submit = "Check karo"
    override val again = "Naye sawaal"
    override val close = "Band karo"
    override val why = "Wajah"
    override val empty = "Model se saaf sawaal nahi bane. Dobara koshish karo."
    override fun scoreLine(right: Int, total: Int) = "$right sahi, $total mein se"
    override fun question(index: Int, total: Int) = "Sawaal $index / $total"
    override val fromPage = "Tumhare page se"
    override val fromSyllabus = "Syllabus se"
    override fun weakestHint(score: Int, total: Int) =
        "Pichhli baar $score/$total. Tap karke isi pe test banao."
    override val topicLabel = "KOI KHAAS TOPIC? (OPTIONAL)"
    override val buildTest = "Test banao"
    override val buildHint = "Settings mein subject likho, ya upar topic daalo."
    override val weakerKicker = "YAHAN KAMZOR HO"
    override val subjectLabel = "KIS SUBJECT KA"
    override val topicEmpty = "Khaali chhoda to poore subject se banega."
}

object MockEn : MockStrings {
    override val label = "MOCK"
    override val title = "Ten questions"
    override val intro = "A short drill. One sitting, five questions, then back to the book."
    override val warning =
        "These are written by AI and the answer key can be wrong. Every answer " +
            "comes with its reason — check it rather than trusting it."
    override val start = "Start"
    override val building = "Writing the questions"
    override val submit = "Check"
    override val again = "New questions"
    override val close = "Close"
    override val why = "Why"
    override val empty = "The model did not return clean questions. Try again."
    override fun scoreLine(right: Int, total: Int) = "$right right out of $total"
    override fun question(index: Int, total: Int) = "Question $index / $total"
    override val fromPage = "From your page"
    override val fromSyllabus = "From the syllabus"
    override fun weakestHint(score: Int, total: Int) =
        "Last time it was $score/$total. Tap to drill it again."
    override val topicLabel = "A SPECIFIC TOPIC? (OPTIONAL)"
    override val buildTest = "Build the test"
    override val buildHint = "Add a subject in Settings, or type a topic above."
    override val weakerKicker = "YOU WERE WEAK HERE"
    override val subjectLabel = "WHICH SUBJECT"
    override val topicEmpty = "Leave it empty and the whole subject is tested."
}
