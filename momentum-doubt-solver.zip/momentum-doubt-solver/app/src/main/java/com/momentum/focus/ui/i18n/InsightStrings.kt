package com.momentum.focus.ui.i18n

/**
 * The insight deck's generated cards — the ones built from this phone's own
 * screen-time numbers, as opposed to the written cards in cards.json.
 *
 * The written cards are shipped content (a Hinglish voice is part of the
 * brand, in either language); the generated ones are app chrome, so they
 * follow the chosen language like the rest of the app.
 */
interface InsightStrings {
    val weekKicker: String
    fun hoursMinutes(hours: Int, minutes: Int): String
    val weekBody: String

    val todayKicker: String
    fun todayPhone(hours: Int, minutes: Int): String
    val todayNoHistory: String
    fun lessThanDaily(minutes: Int): String
    fun moreThanDaily(minutes: Int): String
    val sameAsDaily: String
    fun averageLine(days: Int, avg: Int): String
}

object InsightHi : InsightStrings {
    override val weekKicker = "IS HAFTE"
    override fun hoursMinutes(hours: Int, minutes: Int) =
        if (hours > 0) "$hours ghante $minutes minute." else "$minutes minute."
    override val weekBody =
        "Sirf ek app pe. Poore hafte ka jod. Ye time wapas nahi aata — " +
            "par agla hafta abhi likha nahi gaya."

    override val todayKicker = "AAJ"
    override fun todayPhone(hours: Int, minutes: Int) =
        if (hours > 0) "$hours ghante $minutes min phone" else "$minutes min phone"
    override val todayNoHistory = "Aaj ka hisaab."
    override fun lessThanDaily(minutes: Int) = "Rozana se $minutes min kam."
    override fun moreThanDaily(minutes: Int) = "Rozana se $minutes min zyada."
    override val sameAsDaily = "Rozana jitna hi."
    override fun averageLine(days: Int, avg: Int) =
        "Pichhle $days din ka average $avg min hai. Ye roz badalta hai — " +
            "isliye ise dekhne ka matlab hai."
}

object InsightEn : InsightStrings {
    override val weekKicker = "THIS WEEK"
    override fun hoursMinutes(hours: Int, minutes: Int) =
        if (hours > 0) "$hours hours $minutes minutes." else "$minutes minutes."
    override val weekBody =
        "On one app only. The whole week's total. This time doesn't come back — " +
            "but next week isn't written yet."

    override val todayKicker = "TODAY"
    override fun todayPhone(hours: Int, minutes: Int) =
        if (hours > 0) "$hours hours $minutes min on the phone" else "$minutes min on the phone"
    override val todayNoHistory = "Today's tally."
    override fun lessThanDaily(minutes: Int) = "$minutes min under the daily average."
    override fun moreThanDaily(minutes: Int) = "$minutes min over the daily average."
    override val sameAsDaily = "Right on the daily average."
    override fun averageLine(days: Int, avg: Int) =
        "The average over the last $days days is $avg min. It moves every day — " +
            "which is the point of watching it."
}
