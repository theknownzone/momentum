## New
- MyAI, rebuilt :: The answer gets the whole screen. Controls fit in two slim rows.
  hi: नया MyAI :: जवाब को पूरी स्क्रीन। सारे कंट्रोल दो पतली लाइनों में।
- Study, Dost, Guru in one tap :: Slide between modes right above the chat.
  hi: Study, Dost, Guru एक टैप में :: चैट के ऊपर ही मोड बदलो।
- Answer style sheet :: Short, Normal or Deep. English or Hinglish. What each mode means.
  hi: जवाब का स्टाइल :: छोटा, नॉर्मल या डीप। इंग्लिश या हिंग्लिश। हर मोड का मतलब।
- A proper welcome to MyAI :: Shown once. Then straight to your doubts.
  hi: MyAI का स्वागत :: बस एक बार। फिर सीधे तुम्हारे सवाल।
- New tour :: Story-style, tap to move, hold to pause.
  hi: नया टूर :: स्टोरी जैसा, टैप करके आगे, दबाकर रोको।
- Fresh sounds :: New sounds for choices and finish buttons. Less repetition.
  hi: नई आवाज़ें :: चुनने और खत्म करने की नई आवाज़ें। कम दोहराव।
## Fixed
- Crown animation :: Now plays after you allow device admin, every time.
  hi: क्राउन एनिमेशन :: एडमिन देने के बाद अब हर बार चलता है।
- Long answers :: Scroll up to re-read and the screen stays put. Tap Latest to jump back.
  hi: लंबे जवाब :: ऊपर पढ़ो तो स्क्रीन नहीं खिसकती। नीचे जाने को Latest दबाओ।
- Update notes :: Always match the build you installed.
  hi: अपडेट नोट्स :: अब हमेशा उसी बिल्ड के जो तुमने इंस्टॉल किया।
