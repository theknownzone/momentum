## New
- Crown Mode, rebuilt :: Hyperspace warp, a gold impact, then the crown. New sound.
  hi: क्राउन मोड, नया :: हाइपरस्पेस वार्प, सुनहरा धमाका, फिर क्राउन। नई आवाज़।
- Galactic update bar :: Downloads now fly through a nebula with a comet at the tip.
  hi: गैलेक्टिक अपडेट बार :: डाउनलोड अब नेबुला से गुज़रता है, आगे धूमकेतु।
- Cinematic tour :: Dark stage, glossy objects, camera drift. Still tap, hold, skip.
  hi: सिनेमैटिक टूर :: डार्क स्टेज, चमकदार चीज़ें, कैमरा मूवमेंट।
- Mode emoji on the sign :: Book for Study, smiley for Dost, crown for Guru.
  hi: साइन पर मोड का इमोजी :: Study की किताब, Dost का स्माइली, Guru का क्राउन।
## Better
- Tab switching :: Faster and lighter. Less fade, less lag.
  hi: टैब बदलना :: तेज़ और हल्का। कम फेड, कम लैग।
- MyAI opens clean :: Chat shows instantly. No bubble fade-in on entry.
  hi: MyAI साफ़ खुलता है :: चैट तुरंत दिखती है। एंट्री पर बबल फेड नहीं।
- Shield :: The floating pill is gone. A shield chip now sits by the bell on Home.
  hi: शील्ड :: तैरता पिल हट गया। अब Home पर घंटी के पास शील्ड चिप है।
- App start :: Sounds load in the background, so launch is lighter.
  hi: ऐप स्टार्ट :: आवाज़ें बैकग्राउंड में लोड होती हैं, लॉन्च हल्का।
## Fixed
- MyAI bottom bar :: The Speak line no longer hides behind the phone buttons.
  hi: MyAI का नीचे का हिस्सा :: Speak लाइन अब फ़ोन के बटनों के पीछे नहीं छिपती।
