package com.momentum.focus.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.focus.ai.Ai
import com.momentum.focus.ai.Coach
import com.momentum.focus.ai.Doubt
import com.momentum.focus.ai.DoubtState
import com.momentum.focus.ai.Mock
import com.momentum.focus.ai.MockState
import com.momentum.focus.ai.MyAiMode
import com.momentum.focus.ai.StudyPulse
import com.momentum.focus.block.Admin
import com.momentum.focus.data.*
import com.momentum.focus.ui.util.CoachNotice
import com.momentum.focus.ui.util.FocusNotice
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Haptics
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

data class TimerState(
    val running: Boolean = false,
    val totalSeconds: Int = 50 * 60,
    val remaining: Int = 50 * 60,
    /**
     * Blank until the user picks one.
     *
     * This defaulted to "Physics", which meant an IBPS Clerk candidate who had
     * never touched a subject chip was told "Physics untouched in 30 days" —
     * a reproach about a subject that was not even on their list. The nudge
     * already guards on isNotBlank(); the guard just never fired because the
     * default was a real subject name.
     */
    val subject: String = "",
    val startedAtMs: Long = 0L,
) {
    val progress: Float
        get() = if (totalSeconds == 0) 0f else 1f - (remaining.toFloat() / totalSeconds)
    val label: String
        get() = "%02d:%02d".format(remaining / 60, remaining % 60)
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = AppStore(app)

    /**
     * Null until DataStore has actually emitted.
     *
     * Starting from AppData() meant the app briefly believed onboarding was
     * incomplete, so the welcome screen flashed on every cold start before the
     * real state arrived.
     *
     * This used to be `store.data.stateIn(...)` — every screen read straight
     * off DataStore's own Flow. That meant every Switch and toggle in the app
     * went: tap -> DataStore.edit() decodes the whole JSON blob off disk,
     * transforms it, re-encodes it, writes it back -> DataStore's Flow
     * re-emits -> this StateFlow updates -> recompose -> the switch actually
     * moves. A real disk write sitting between a tap and the pixel moving is
     * a beat, not nothing, and it is exactly the "halka sa lag" every toggle
     * in the app had. It is now an in-memory copy that [updateData] writes to
     * immediately; the disk write still happens underneath it, it just no
     * longer sits in the way of the animation.
     */
    private val _data = MutableStateFlow<AppData?>(null)
    val data: StateFlow<AppData?> = _data.asStateFlow()

    private val _timer = MutableStateFlow(TimerState())
    val timer: StateFlow<TimerState> = _timer.asStateFlow()

    /** Emits once when a session finishes, so the UI can buzz and confetti. */
    private val _sessionFinished = MutableStateFlow(0)
    val sessionFinished: StateFlow<Int> = _sessionFinished.asStateFlow()

    /**
     * Clears the session signal once its screen has been shown.
     *
     * Same reasoning as [consumeStreakUp]. This counter only ever went up, so
     * it was permanently non-zero after the first banked session of the
     * process — and the screen that reads it keeps its "already shown" flag in
     * `remember`, which does not survive the Activity being recreated. Rotate
     * the phone and the celebration, haptic and all, played again for a
     * session banked an hour earlier. Nothing here is orientation-locked, so
     * that was one rotation away at any time.
     */
    fun consumeSessionFinished() {
        _sessionFinished.value = 0
    }

    // 0 means nothing to celebrate. Holds the new streak count itself, not a
    // boolean, so the screen that reacts to it doesn't have to go read
    // data.value a second time and risk reading a value from after the
    // person has already banked another session.
    private val _streakUp = MutableStateFlow(0)
    val streakUp: StateFlow<Int> = _streakUp.asStateFlow()

    /**
     * Clears the streak signal once its screen has been shown.
     *
     * Without this the value sits at, say, 5 forever, and every recomposition
     * that restarts the collecting LaunchedEffect — a rotation, a theme
     * change, anything that rebuilds the composition while the ViewModel
     * survives — sees a non-zero value again and re-opens the celebration
     * for a streak that was celebrated days ago.
     */
    fun consumeStreakUp() {
        _streakUp.value = 0
    }

    private var tickJob: Job? = null

    init {
        // Seeded exactly once. AppViewModel is the only writer to the store
        // — BlockerService, ShortsGuard and ShieldActivity each open their
        // own AppStore but only ever collect it, never update it — so there
        // is nobody else who could change the file out from under this and
        // no reason to keep listening to DataStore's Flow after the first
        // value. Every change from here on goes through updateData, which
        // keeps this copy and the disk write in step itself.
        viewModelScope.launch {
            _data.value = store.data.first()
        }

        // A session that was running when the process died is picked back up
        // from the wall clock. Without this, force-stopping the app or having
        // an OEM kill it silently threw away however long someone had studied.
        viewModelScope.launch {
            val d = store.data.first { it != null } ?: return@launch
            val endsAt = d.liveSessionEndsAtMs
            if (endsAt <= 0L) return@launch
            val leftSec = ((endsAt - System.currentTimeMillis()) / 1000L).toInt()
            if (leftSec > 0) {
                _timer.value = TimerState(
                    running = false,
                    totalSeconds = d.liveSessionTotalSec,
                    remaining = leftSec,
                    subject = d.liveSessionSubject.ifBlank { _timer.value.subject },
                    startedAtMs = d.liveSessionStartedAtMs,
                )
                resume()
            } else {
                // It ran out while the app was gone. Settle it rather than
                // discarding minutes that were genuinely spent.
                _timer.value = TimerState(
                    running = false,
                    totalSeconds = d.liveSessionTotalSec,
                    remaining = 0,
                    subject = d.liveSessionSubject.ifBlank { _timer.value.subject },
                    startedAtMs = d.liveSessionStartedAtMs,
                )
                finishSession(completed = true)
            }
        }
    }

    private fun resume() {
        _timer.value = _timer.value.copy(running = true)
        runTicker()
    }

    fun setDuration(minutes: Int) {
        if (_timer.value.running) return
        _timer.value = _timer.value.copy(
            totalSeconds = minutes * 60,
            remaining = minutes * 60,
        )
    }

    fun setSubject(subject: String) {
        _timer.value = _timer.value.copy(subject = subject)
    }

    fun toggleTimer() {
        if (_timer.value.running) pause() else start()
    }

    /**
     * Why the timer will not start, or null if it will.
     *
     * Exists so the Begin button can say something. It used to fail by doing
     * nothing at all — tapping Begin on Light, or with no study app picked, left
     * the screen exactly as it was and the person had no way to tell whether
     * the app was broken or they had missed a step.
     */
    fun startBlocked(): String? {
        val d = data.value ?: return "Ek second, load ho raha hai."
        if (d.studyPackages.isEmpty()) {
            return "Pehle ek study app choose karo, warna minute count nahi honge."
        }
        return null
    }

    private fun start() {
        val ready = data.value ?: return
        // The old gate also refused any session below Lock, so Light — which simply
        // means "no blocking" — could not run a timer at all. A soft session
        // that only counts minutes is still a session, and refusing it silently
        // made the level chip look broken.
        if (ready.studyPackages.isEmpty()) return
        val now = System.currentTimeMillis()
        _timer.value = _timer.value.copy(running = true, startedAtMs = now)
        val t = _timer.value
        // Written down before the ticker starts, so the session survives the
        // process being killed a second later.
        viewModelScope.launch {
            updateData {
                it.copy(
                    liveSessionEndsAtMs = now + t.remaining * 1000L,
                    liveSessionTotalSec = t.totalSeconds,
                    liveSessionStartedAtMs = now,
                    liveSessionSubject = t.subject,
                    // The five doubts belong to the session, so they arrive
                    // with it. Refilling anywhere else — on opening the sheet,
                    // on a new day — would let someone hold a conversation
                    // without ever sitting down to a session.
                    doubtsUsed = 0,
                )
            }
        }
        // Last session's questions are last session's. Keeping them would put
        // an hour-old thread in front of someone who just sat down.
        _doubt.value = DoubtState()
        // A new session is a new set of numbers.
        factsCache = null
        lastAnswerAtMs = 0L
        lastAnswerChars = 0
        pendingGapSec = -1
        runTicker()
    }

    private fun runTicker() {
        tickJob?.cancel()
        tickJob = viewModelScope.launch {
            // Refreshed once a minute, not once a second. The system draws the
            // countdown itself from setWhen, so rewriting the notification
            // every tick would burn battery to change nothing on screen.
            var lastNotice = 0L
            while (_timer.value.running && _timer.value.remaining > 0) {
                val t = _timer.value
                val now = System.currentTimeMillis()
                if (now - lastNotice > 60_000L || lastNotice == 0L) {
                    lastNotice = now
                    FocusNotice.show(
                        context = getApplication(),
                        endsAtMs = now + t.remaining * 1000L,
                        subject = t.subject,
                        elapsedMin = (t.totalSeconds - t.remaining) / 60,
                        totalMin = t.totalSeconds / 60,
                    )
                }
                delay(1000)
                _timer.value = _timer.value.copy(remaining = _timer.value.remaining - 1)
            }
            if (_timer.value.remaining <= 0) finishSession(completed = true)
        }
    }

    private fun pause() {
        _timer.value = _timer.value.copy(running = false)
        tickJob?.cancel()
        // A paused session has no countdown to show, and a frozen one would be
        // worse than none — it would keep claiming time was passing.
        FocusNotice.clear(getApplication())
        viewModelScope.launch {
            updateData { it.copy(liveSessionEndsAtMs = 0L) }
        }
    }

    /**
     * Give up early. The audited minutes are still logged — honesty beats
     * zeroes — but the session is judged against what was planned.
     *
     * It used to pass the elapsed minutes as the plan, which quietly deleted
     * the seventy percent bar on exactly the path the bar exists for: quit
     * after two minutes of a fifty minute session and the bar became
     * bankBar(2), which is one, so two minutes paid out in full. The rule is
     * that a fifty minute session cannot be cashed in early, and this is the
     * only way it holds.
     */
    fun abandon() {
        pause()
        settleSession(_timer.value.totalSeconds / 60, finished = false, celebrate = false)
        reset()
    }

    private fun finishSession(completed: Boolean) {
        pause()
        settleSession(_timer.value.totalSeconds / 60, finished = true, celebrate = completed)
        reset()
    }

    /**
     * Minutes of real study a session must reach before it pays anything.
     *
     * Seventy percent of what was planned, so a fifty minute session cannot be
     * cashed in after two. The rule is sound and it was invisible: the timer
     * counted up, the screen said fifty minutes was worth twelve rupees, and a
     * ten minute session paid zero with nothing anywhere explaining the bar.
     * Exposed so the Focus screen can show it before someone sits down rather
     * than after they have given up.
     */

    private fun settleSession(planned: Int, finished: Boolean, celebrate: Boolean) {
        if (planned < 1) return
        val start = _timer.value.startedAtMs
        val end = System.currentTimeMillis()
        viewModelScope.launch {
            val snap = data.value
            val study = snap?.studyPackages.orEmpty()
            val blocked = snap?.blockedPackages.orEmpty()
            val (honest, junk) = if (start > 0L) {
                ScreenTime.sessionAudit(getApplication(), start, end, study, blocked)
            } else 0 to 0
            val studyClean = study.filterNot { StudyApps.isForbidden(it) }.toSet()
            // The level gate is gone. Light means "no blocking", not "no
            // earning", and refusing to pay a genuine Light session while the timer counted
            // its minutes up made the app look like it was keeping the money.
            val ok = studyClean.isNotEmpty() &&
                junk <= 0 &&
                honest >= bankBar(planned)
            val credit = if (ok) honest.coerceIn(1, planned) else 0
            // Read before logging, not after — streakDays is derived from
            // sessions, so this is the only chance to see the "before" value.
            val streakBefore = snap?.streakDays ?: 0
            // Finished and paid are two different questions. Paying an
            // abandoned session that still cleared the bar is right; recording
            // it as completed is not — it would feed the streak and the
            // Finishing part of the success score, both of which exist to
            // measure the thing that did not happen.
            logSession(credit, completed = finished && credit > 0)
            // XP is the lecture tracker, not the wallet. It follows the same
            // audited minutes so it can never be farmed separately, but it is
            // credited even on a session that missed the 70% bar — time in a
            // study app is still time in a study app.
            if (honest > 0 && junk <= 0) addStudyXp(honest)
            if (credit > 0 && celebrate) {
                _sessionFinished.value = _sessionFinished.value + 1
            }
            // Only fires the day the streak actually moves. Three sessions
            // banked on the same day should not show this screen three times
            // — the second and third do not change streakDays at all, since
            // it counts days, not sessions.
            if (finished && credit > 0) {
                val streakAfter = data.value?.streakDays ?: 0
                if (streakAfter > streakBefore) _streakUp.value = streakAfter
            }
        }
    }

    private fun reset() {
        _timer.value = _timer.value.copy(remaining = _timer.value.totalSeconds, running = false)
    }

    private fun logSession(minutes: Int, completed: Boolean) {
        val subject = _timer.value.subject
        // Was wrapped in its own viewModelScope.launch, left over from when
        // updateData's predecessor was a suspend function. updateData applies
        // to the in-memory copy synchronously now, so wrapping it queued a
        // second coroutine for no reason — and settleSession, right below,
        // needs to read data.value immediately after this call returns to
        // tell whether the streak moved. A queued update made that read race.
        updateData { d ->
            d.copy(
                sessions = d.sessions + FocusSession(
                    startedAtEpochDay = LocalDate.now().toEpochDay(),
                    minutes = minutes,
                    subject = subject.ifBlank { "General" },
                    completed = completed,
                    ratio = d.effectiveRatio.coerceAtLeast(1),
                )
            )
        }
    }

    // ---- Streak ----------------------------------------------------------

    fun resetStreak() = viewModelScope.launch {
        updateData { d ->
            d.copy(
                bestStreak = maxOf(d.bestStreak, d.streakDays),
                streakStartEpochDay = LocalDate.now().toEpochDay(),
            )
        }
    }

    /** Trade banked focus minutes for distraction time. */

    /**
     * Why removing an app from the blocklist is currently refused, or null.
     *
     * Deciding what to block and then starting the timer are two separate
     * moments, and only the second one should be binding. Before a session the
     * list is meant to be edited freely — that is the whole point of setting it
     * up. Once the clock is running, taking an app off the list is the same
     * move as quitting, so it is refused for as long as the session lasts.
     */
    fun blockEditLock(): String? = when {
        data.value?.pactLive == true -> "Pact live hai. Pact khatam hone tak nahi hata sakte."
        _timer.value.running -> "Session chal raha hai. Timer band karo, phir badlo."
        else -> null
    }

    fun toggleBlocked(pkg: String) = viewModelScope.launch {
        updateData { d ->
            val removing = pkg in d.blockedPackages
            // Adding is always allowed. Only removal is ever locked — a rule
            // can tighten mid-session, it just cannot loosen.
            val locked = d.pactLive || _timer.value.running
            if (locked && removing) d
            else {
                val next = if (removing) d.blockedPackages - pkg else d.blockedPackages + pkg
                // Editing by hand means these are no longer that profile's
                // rules, so the label stops claiming they are.
                d.copy(blockedPackages = next, activeProfileId = "")
            }
        }
    }

    /**
     * Every screen-facing setter routes through this instead of calling
     * store.update directly.
     *
     * The transform is applied to the in-memory copy first — synchronously,
     * on the caller's thread — so the switch, chip or toggle moves on the
     * same frame as the tap. store.update still runs underneath it on
     * viewModelScope to persist to disk; nothing here skips the write, it
     * only stops the write from being on the critical path to the pixel.
     */
    private fun updateData(transform: (AppData) -> AppData) {
        _data.value = _data.value?.let(transform)
        viewModelScope.launch { store.update(transform) }
    }

    fun setSkin(index: Int) = viewModelScope.launch {
        updateData { it.copy(skin = index) }
    }

    fun setAvatar(shape: Int, color: Int) = viewModelScope.launch {
        updateData { it.copy(avatarShape = shape, avatarColor = color) }
    }

    fun setLang(code: String) = viewModelScope.launch {
        updateData { it.copy(lang = code) }
    }

    /** True while a coach run is in flight, so the card can show it. */
    private val _coachBusy = MutableStateFlow(false)
    val coachBusy: StateFlow<Boolean> = _coachBusy

    /** Last failure, shown as itself rather than as an empty card. */
    private val _coachError = MutableStateFlow<String?>(null)
    val coachError: StateFlow<String?> = _coachError

    /**
     * Runs the weekly read, if it is allowed to run.
     *
     * Guarded rather than trusting the caller: the card is one tap and a
     * double tap would otherwise buy two answers to the same question.
     */
    fun runCoach(force: Boolean = false) = viewModelScope.launch {
        if (_coachBusy.value) return@launch
        val snap = data.value ?: return@launch
        if (!Ai.enabled) return@launch
        if (!force && !Coach.canRun(snap, snap.coachAtMs)) return@launch
        _coachBusy.value = true
        _coachError.value = null
        try {
            val report = Coach.run(getApplication(), snap)
            updateData {
                it.copy(coachJson = Coach.encode(report), coachAtMs = report.generatedAtMs)
            }
            if (!report.isEmpty) {
                CoachNotice.show(getApplication(), report.headline)
            }
        } catch (e: Exception) {
            _coachError.value = e.message ?: "Could not reach the model."
        } finally {
            _coachBusy.value = false
        }
    }

    /**
     * The doubt sheet's whole state, as one object.
     *
     * The thread lives here rather than in the store on purpose. A weekly
     * report is worth keeping across restarts; a conversation about one step
     * of one sum is not, and writing it down would turn the sheet into
     * something with a history to scroll.
     *
     * [DoubtState.left] is the exception and is left at its default here: the
     * count belongs to the store, and the screen fills it in from there rather
     * than this flow keeping a second copy that can drift out of step.
     */
    private val _doubt = MutableStateFlow(DoubtState())
    val doubt: StateFlow<DoubtState> = _doubt.asStateFlow()

    private val _myAiMode = MutableStateFlow(MyAiMode.Study)
    val myAiMode: StateFlow<MyAiMode> = _myAiMode.asStateFlow()

    private val _pulse = MutableStateFlow<StudyPulse?>(null)
    val pulse: StateFlow<StudyPulse?> = _pulse.asStateFlow()

    fun setMyAiMode(mode: MyAiMode) {
        _myAiMode.value = mode
    }

    fun refreshPulse() {
        val snap = data.value ?: return
        val phone = runCatching {
            ScreenTime.report(getApplication()).averageMinutes
        }.getOrNull()
        _pulse.value = Doubt.pulse(snap, phone)
    }

    private var doubtJob: Job? = null

    /**
     * When the last answer landed and how long it was, so the next question can
     * be checked against the time it would have taken to read it.
     *
     * This is the only thing MyAi measures about the person using it, and it
     * exists for one reason: firing questions faster than the answers can be
     * read is what this feature turns into when it is being used to avoid the
     * page. It is a timestamp and a character count, held in memory, gone when
     * the session ends. Nothing is stored and nothing leaves the phone except
     * the one line below, which goes into the prompt so the model can say
     * something about it.
     */
    private var lastAnswerAtMs = 0L
    private var lastAnswerChars = 0
    private var pendingGapSec = -1

    /**
     * The numbers that ride along with a question, and when they were read.
     *
     * Cached because building them means walking seven days of usage events
     * through UsageStatsManager, and that was being done again before every
     * single message — so the wait before an answer even started was the
     * phone's stats query, not the model. The figures move once a day at most;
     * re-reading them per keystroke-turn bought nothing and cost the one thing
     * a chat is judged on.
     */
    private var factsCache: String? = null
    private var factsAtMs = 0L

    /** Asks a new question, appending it to the thread. */
    fun askDoubt(
        question: String,
        imageB64: String? = null,
        more: List<String> = emptyList(),
        /** True when the pages came from an earlier question, not this one. */
        carried: Boolean = false,
    ) {
        val text = question.trim().take(Doubt.MAX_CHARS)
        val pics = listOfNotNull(imageB64) + more
        if (text.isBlank() && pics.isEmpty()) return
        pendingGapSec = if (lastAnswerAtMs == 0L) {
            -1
        } else {
            ((System.currentTimeMillis() - lastAnswerAtMs) / 1000L).toInt()
        }
        val thread = _doubt.value.thread + Ai.Turn(
            fromUser = true,
            text = text.ifBlank { "Read the attached page and explain the doubt on it." },
            imageB64 = pics.firstOrNull(),
            more = pics.drop(1).take(4),
            carried = carried,
        )
        runDoubt(thread)
    }

    /**
     * Re-asks the question already at the end of the thread.
     *
     * Stopping an answer, or losing it to a dead network, should not cost the
     * typing that led to it — and it must not append a second copy of the same
     * question either.
     */
    fun retryDoubt() {
        val thread = _doubt.value.thread
        if (thread.lastOrNull()?.fromUser != true) return
        // A retry is the same question again, so there is no new gap to judge.
        pendingGapSec = -1
        runDoubt(thread)
    }

    private fun runDoubt(thread: List<Ai.Turn>) {
        if (_doubt.value.busy) return
        val snap = data.value ?: return
        if (!Ai.enabled) return
        if (Doubt.left(snap.doubtsUsed, snap.premium) <= 0) return

        if (!snap.premium && _myAiMode.value != MyAiMode.Study) {
            _myAiMode.value = MyAiMode.Study
        }
        _doubt.value = _doubt.value.copy(thread = thread, busy = true, error = null)
        doubtJob = viewModelScope.launch {
            try {
                val facts = buildString {
                    val fresh = System.currentTimeMillis() - factsAtMs < FACTS_TTL_MS
                    val cached = factsCache
                    val summary = if (fresh && cached != null) {
                        cached
                    } else {
                        withContext(Dispatchers.IO) {
                            runCatching { Coach.summarise(getApplication(), snap) }.getOrDefault("")
                        }.also {
                            factsCache = it
                            factsAtMs = System.currentTimeMillis()
                        }
                    }
                    append(summary)
                    val gap = pendingGapSec
                    if (gap >= 0 && gap < Doubt.readingSeconds(lastAnswerChars)) {
                        appendLine()
                        appendLine("PACE")
                        appendLine(
                            "- this question came ${gap}s after the last answer, " +
                                "which is less time than reading it would take",
                        )
                    }
                }
                // Rendered as it arrives.
                //
                // The reply used to appear in one piece when the last token
                // landed, so every answer felt like a wait even when the model
                // started writing immediately. The partial text goes into
                // DoubtState.streaming; the sheet shows it under the question
                // and it is replaced by the finished turn below.
                //
                // Deltas arrive on the IO thread, so the state write hops back
                // via the main dispatcher this scope already runs on.
                val partial = StringBuilder()
                // Emitted on a clock, not on every token.
                //
                // This used to write _doubt.value on each delta. A 400-token
                // answer is 400 StateFlow emissions, 400 fresh Strings built
                // from a growing StringBuilder, and 400 recompositions of the
                // whole sheet — and the string copies get longer as the answer
                // grows, so it gets worse the further in you are. That is the
                // stutter mid-reply: not the model thinking, the UI thread
                // choking on its own updates.
                //
                // 60ms is under the eye's threshold for text appearing
                // continuously, and it cuts the work by roughly twenty times.
                var lastEmit = 0L
                val answer = Doubt.answer(snap, thread, _myAiMode.value, facts) { piece ->
                    partial.append(piece)
                    val now = System.currentTimeMillis()
                    if (now - lastEmit >= 60L) {
                        lastEmit = now
                        _doubt.value = _doubt.value.copy(streaming = partial.toString())
                    }
                }
                // A blank reply is a failure, not an answer. Some models
                // return empty content when they run out of budget, and an
                // empty bubble in the thread is worse than an error: it looks
                // like the app worked and had nothing to say.
                if (answer.isBlank()) {
                    _doubt.value = _doubt.value.copy(
                        busy = false,
                        streaming = "",
                        error = "Model ne khaali jawab bheja. Phir se poochho.",
                    )
                    return@launch
                }
                lastAnswerAtMs = System.currentTimeMillis()
                lastAnswerChars = answer.length
                pendingGapSec = -1
                _doubt.value = _doubt.value.copy(
                    thread = thread + Ai.Turn(fromUser = false, text = answer),
                    busy = false,
                    streaming = "",
                )
                // Counted here, not at the ask. A question that was stopped or
                // that died on a train with no signal produced no answer, and
                // charging for it would make a flaky connection cost someone
                // their session's doubts.
                updateData { it.copy(doubtsUsed = it.doubtsUsed + 1) }
            } catch (e: CancellationException) {
                // Stop was pressed. The question stays on screen with nothing
                // under it, which is what the sheet offers to re-ask.
                _doubt.value = _doubt.value.copy(busy = false)
                throw e
            } catch (e: Exception) {
                // Cancelling tears the socket down mid-read, and that arrives
                // here as an IOException rather than as a cancellation. A stop
                // the user asked for is not a failure and must not be reported
                // as one, so the error line depends on whether this job was
                // still meant to be running.
                _doubt.value = _doubt.value.copy(
                    busy = false,
                    error = if (isActive) e.message ?: "Could not reach the model." else null,
                )
            }
        }
    }

    /**
     * Stops an answer that is on its way.
     *
     * Cancelling the job disconnects the socket — see [Ai.chat] — so this
     * stops the request rather than only the spinner. The state is cleared
     * here as well as in the job's own handler, because the button has to stop
     * looking like a stop button the moment it is pressed rather than whenever
     * the socket gets around to noticing.
     */
    // ---- Mock test --------------------------------------------------------

    /** What the drill in flight was set on, so the result can be filed under it. */
    private var lastMockSubject: String = ""
    private var lastMockTopic: String = ""

    private val _mock = MutableStateFlow(MockState())
    val mock: StateFlow<MockState> = _mock.asStateFlow()
    private var mockJob: Job? = null

    /**
     * Builds a five question drill.
     *
     * Counted against the same session allowance as a doubt, because it is the
     * same model, the same money and the same minutes off the clock. A test
     * that was free to regenerate would be the cheapest way there is to sit in
     * MyAi and call it studying.
     */
    fun startMock(
        pageJpegB64: String? = null,
        subject: String = "",
        topic: String = "",
    ) {
        if (_mock.value.busy) return
        val snap = data.value ?: return
        if (!Ai.enabled) return
        // Paid. A drill is a twelve-hundred token request against the same
        // model the doubt sheet uses, so it costs real money every time it is
        // pressed — and a free tier that hands that out is a free tier that
        // decides how much the app loses per install.
        if (!snap.premium) return
        if (Doubt.left(snap.doubtsUsed, snap.premium) <= 0) return

        _mock.value = MockState(busy = true)
        val chosenSubject = subject.ifBlank {
            _timer.value.subject.ifBlank { snap.subjects.firstOrNull().orEmpty() }
        }
        lastMockSubject = chosenSubject
        lastMockTopic = topic
        mockJob = viewModelScope.launch {
            try {
                val items = Mock.generate(
                    data = snap,
                    // What was asked for, then the running session's subject,
                    // then the first one on the profile.
                    //
                    // That last fallback used to be the only real input, and
                    // it is why a student revising Maths got a Biology paper:
                    // subjects.firstOrNull() is whichever of the three boxes
                    // in Settings happened to be filled in first, and outside
                    // a focus session nothing could override it. There was no
                    // way to say what the drill should be on.
                    subject = chosenSubject,
                    topic = topic,
                    // What went wrong last time on this ground. The model aims
                    // at it instead of setting another general paper.
                    missed = snap.mockResults
                        .takeLast(5)
                        .filter { it.subject.equals(chosenSubject, ignoreCase = true) }
                        .flatMap { it.missed }
                        .takeLast(6),
                    pageJpegB64 = pageJpegB64,
                )
                _mock.value = MockState(items = items)
                if (items.isNotEmpty()) {
                    updateData { it.copy(doubtsUsed = it.doubtsUsed + 1) }
                }
            } catch (e: CancellationException) {
                _mock.value = MockState()
                throw e
            } catch (e: Exception) {
                _mock.value = MockState(
                    error = if (isActive) e.message ?: "Could not reach the model." else null,
                )
            }
        }
    }

    fun chooseMock(question: Int, option: Int) {
        val state = _mock.value
        if (state.marked) return
        _mock.value = state.copy(chosen = state.chosen + (question to option))
    }

    fun submitMock() {
        if (!_mock.value.answeredAll) return
        val marked = _mock.value.copy(marked = true)
        _mock.value = marked
        // Kept, not thrown away.
        //
        // A drill used to end here: score shown, sheet closed, nothing
        // written. So the app could never say what you were weak at, and the
        // model setting the next one had to guess. The missed questions are
        // the part worth keeping — a score says a drill went badly, the misses
        // say what to set next.
        val missed = marked.items.indices
            .filter { marked.chosen[it] != marked.items[it].answerIndex }
            .map { marked.items[it].question.take(120) }
        viewModelScope.launch {
            updateData { d ->
                d.copy(
                    // Capped at forty. This lives inside the one JSON blob
                    // that is read on every store access, including from the
                    // blocker service, so it cannot be allowed to grow without
                    // limit.
                    mockResults = (
                        d.mockResults + MockResult(
                            epochDay = LocalDate.now().toEpochDay(),
                            subject = lastMockSubject,
                            topic = lastMockTopic,
                            score = marked.score,
                            total = marked.items.size,
                            missed = missed,
                        )
                        ).takeLast(40),
                )
            }
        }
    }

    fun clearMock() {
        mockJob?.cancel()
        mockJob = null
        _mock.value = MockState()
    }

    fun stopDoubt() {
        doubtJob?.cancel()
        doubtJob = null
        _doubt.value = _doubt.value.copy(busy = false)
    }

    fun markVersionSeen(version: String, changelog: Int) = viewModelScope.launch {
        updateData { it.copy(lastSeenVersion = version, lastSeenChangelog = changelog) }
    }

    fun setExam(name: String, epochDay: Long) = viewModelScope.launch {
        updateData { d ->
            // Subjects follow the exam only while they are still the stock
            // pack. Once someone has edited them, they are theirs.
            //
            // This used to overwrite unconditionally, and the day chips call
            // straight through to here — so tapping "90d" to move a deadline
            // silently threw away a hand-written subject list. The pack is a
            // starting point, not a thing that keeps reasserting itself.
            val untouched = d.subjects.isEmpty() ||
                d.subjects == ExamCatalog.packFor(d.examName)
            d.copy(
                examName = name,
                examEpochDay = epochDay,
                subjects = if (untouched) ExamCatalog.packFor(name) else d.subjects,
            )
        }
    }

    fun setWeekendRelaxed(on: Boolean) = viewModelScope.launch {
        updateData { it.copy(weekendRelaxed = on) }
    }

    fun setClassHours(on: Boolean, start: Int = 6, end: Int = 22) = viewModelScope.launch {
        updateData { d ->
            if (d.pactLive && !on) d
            else d.copy(
                classHoursOn = on,
                classStartHour = start.coerceIn(0, 23),
                classEndHour = end.coerceIn(1, 24),
            )
        }
    }

    fun logSlip(reason: String, regretted: Boolean) = viewModelScope.launch {
        updateData {
            it.copy(
                slips = it.slips + Slip(
                    epochDay = java.time.LocalDate.now().toEpochDay(),
                    reason = reason,
                    regretted = regretted,
                ),
                pendingReflectionMinutes = 0,
            )
        }
    }

    fun skipReflection() = viewModelScope.launch {
        updateData { it.copy(pendingReflectionMinutes = 0) }
    }

    /**
     * Checks a key and unlocks if it holds up. Returns false on a bad key.
     *
     * Validation happens here rather than in the screen so there is one place
     * that can grant premium, and so a future move to server-side checking
     * changes this function and nothing else.
     */
    suspend fun redeem(raw: String): Boolean {
        if (!License.isValid(raw)) return false
        updateData {
            it.copy(premium = true, licenseKey = License.normalise(raw))
        }
        return true
    }

    /** Removes the unlock. Used when someone moves their key to another phone. */
    fun clearLicense() = viewModelScope.launch {
        updateData { it.copy(premium = false, licenseKey = "") }
    }

    fun toggleStudyOnly(on: Boolean) = viewModelScope.launch {
        updateData { it.copy(studyOnlyYouTube = on) }
    }

    fun addChannel(name: String) = viewModelScope.launch {
        val clean = name.trim().lowercase()
        if (clean.isBlank()) return@launch
        updateData { it.copy(allowedChannels = it.allowedChannels + clean) }
    }

    fun removeChannel(name: String) = viewModelScope.launch {
        updateData { it.copy(allowedChannels = it.allowedChannels - name) }
    }

    fun markTourSeen() = viewModelScope.launch {
        updateData { it.copy(tourSeen = true) }
    }

    /** Stamps the first launch. Does nothing on every launch after it. */
    fun stampFirstOpen() = viewModelScope.launch {
        updateData {
            if (it.firstOpenEpochDay > 0L) it
            else it.copy(firstOpenEpochDay = java.time.LocalDate.now().toEpochDay())
        }
    }

    fun markCelebrated(level: Int, badges: Int) = viewModelScope.launch {
        updateData { it.copy(lastCelebratedLevel = level, lastCelebratedBadges = badges) }
    }

    /** One badge, by id. Several new badges celebrate one after another. */
    fun markBadgeCelebrated(id: String, badges: Int) = viewModelScope.launch {
        updateData {
            it.copy(
                lastCelebratedBadges = badges,
                celebratedBadgeIds = it.celebratedBadgeIds + id,
            )
        }
    }

    /**
     * Marks every already-earned badge as seen without showing anything.
     *
     * Runs once on an install that predates [AppData.celebratedBadgeIds].
     * Without it the upgrade would replay a celebration for every badge the
     * user earned months ago.
     */
    fun seedCelebratedBadges(ids: Set<String>) = viewModelScope.launch {
        updateData {
            if (it.celebratedBadgeIds.isNotEmpty()) it
            else it.copy(celebratedBadgeIds = ids, lastCelebratedBadges = ids.size)
        }
    }

    fun setNotify(on: Boolean) = viewModelScope.launch {
        updateData { it.copy(notifyOn = on) }
    }

    fun setSound(on: Boolean) = viewModelScope.launch {
        Sfx.enabled = on
        updateData { it.copy(soundOn = on) }
    }

    fun setHapticIntensity(value: Float) = viewModelScope.launch {
        Haptics.intensity = value
        updateData { it.copy(hapticIntensity = value) }
    }

    fun markCrownIntroSeen() = viewModelScope.launch {
        updateData { it.copy(crownIntroSeen = true) }
    }

    fun setCrown(on: Boolean) = viewModelScope.launch {
        var released = false
        updateData { d ->
            if (d.pactLive && !on) d
            else {
                // Admin protection is documented as lasting "while a hard
                // mode is running" (see AdminReceiver), but nothing actually
                // released it when hard mode ended — once granted, Android
                // keeps the app un-installable regardless of what crownMode
                // says internally, and it stayed that way until someone
                // remembered to go turn it off by hand in Settings. A pact
                // still blocks this branch entirely above, so this can only
                // run when there is nothing currently holding the person to
                // hard mode.
                if (!on) released = true
                d.copy(crownMode = on, shieldOn = if (on) true else d.shieldOn)
            }
        }
        if (released) Admin.deactivate(getApplication())
    }

    fun setEarnRatio(ratio: Int) = viewModelScope.launch {
        updateData { it.copy(earnRatio = ratio.coerceIn(1, 20)) }
    }

    fun setSubjects(list: List<String>) = viewModelScope.launch {
        val next = list.map { it.trim() }.filter { it.isNotBlank() }.take(3)
        if (next.isEmpty()) return@launch
        updateData { it.copy(subjects = next) }
    }

    /** 1 soft, 2 shield, 3 hard, 4 crown. */
    fun setFocusLevel(level: Int) = viewModelScope.launch {
        val lv = level.coerceIn(1, 4)
        updateData { d ->
            // A running session locks the level the same way a pact does. You
            // chose the terms before you started; dropping to a softer level
            // halfway through is quitting with the clock still counting, which
            // is exactly the move the session is meant to make hard. Raising it
            // stays open — a rule can always tighten.
            if ((d.pactLive || _timer.value.running) && lv < d.focusLevel) d
            else if (lv >= 3 && !d.crownMode) d
            else {
                // A pact is only armed when the user actually climbs to a
                // locking level. Re-selecting the level they are already on
                // used to push the clock back out to a fresh three hours,
                // which turned a stray tap into hours of extra lockout.
                val climbing = lv > d.focusLevel
                val lock = if (lv >= 3 && climbing) {
                    maxOf(
                        d.lockUntilEpochMs,
                        System.currentTimeMillis() +
                            FocusLevels.PACT_HOURS * 60L * 60L * 1000L,
                    )
                } else d.lockUntilEpochMs
                d.copy(
                    focusLevel = lv,
                    shieldOn = lv >= 2,
                    blockedPackages = if (lv >= 2 && d.blockedPackages.isEmpty())
                        StudyApps.defaultBlocklist(getApplication()) else d.blockedPackages,
                    // The earn rate is the user's own setting, chosen in
                    // Profile. Overwriting it here meant picking a focus level
                    // silently replaced it — Profile went on showing 8:1 while
                    // Focus charged 12, and neither screen mentioned that the
                    // other had been overruled. Levels control blocking; the
                    // rate stays where it was set.
                    earnRatio = d.earnRatio,
                    // Crown belongs to its own switch in Profile and to the
                    // exam window. Setting it from here made two owners for one
                    // flag: Profile showed it off while the shield said it was
                    // on, and neither was lying about what it could see.
                    // Reaching Crown level still turns it on — it cannot turn
                    // it off, because a pact refuses that anyway.
                    crownMode = lv >= 3,
                    lockUntilEpochMs = lock,
                )
            }
        }
    }

    /**
     * Only extends an existing pact. It can never start one: with no guard a
     * single tap on "+6h" at Soft created a six hour lock that rule 12 then
     * refused to shorten, so a stray tap cost the user the rest of the day.
     * Arming a pact has to go through setFocusLevel, which is deliberate.
     */
    fun extendPact(hours: Int) = viewModelScope.launch {
        val add = hours.coerceIn(1, MAX_EXTEND_HOURS) * 3600_000L
        updateData { d ->
            if (!d.pactLive) d
            else {
                // Capped in total, not just per tap. Nothing can shorten a
                // pact, so without a ceiling a few taps of the longest option
                // would lock the phone down for months with no way back.
                val ceiling = System.currentTimeMillis() + MAX_PACT_HORIZON_MS
                val end = (d.lockUntilEpochMs + add).coerceAtMost(ceiling)
                d.copy(lockUntilEpochMs = end, shieldOn = true)
            }
        }
    }

    /**
     * Set or clear a daily cap. A cap only ever tightens the shield, so unlike
     * the blocklist it stays editable during a pact in one direction: a live
     * pact refuses to remove or raise one, matching rule 12.
     */
    fun setDailyCap(pkg: String, minutes: Int?) = viewModelScope.launch {
        updateData { d ->
            val existing = d.dailyCapMinutes[pkg]
            val loosening = minutes == null || (existing != null && minutes > existing)
            if (d.pactLive && loosening) d
            else d.copy(
                dailyCapMinutes = if (minutes == null) d.dailyCapMinutes - pkg
                else d.dailyCapMinutes + (pkg to minutes)
            )
        }
    }

    /**
     * Picks up the study apps this phone actually has, once, at setup.
     *
     * Without this the user had to know to go and choose them, and a timer
     * with no study app pays nothing — so the most common first experience was
     * a completed session worth zero rupees and no explanation.
     */
    fun seedStudyApps() = viewModelScope.launch {
        val found = withContext(Dispatchers.IO) {
            runCatching { AppCatalog.installedStudyApps(getApplication()) }
                .getOrDefault(emptyList())
                .map { it.pkg }
        }
        if (found.isEmpty()) return@launch
        updateData { d ->
            if (d.studyPackages.isNotEmpty()) d
            else d.copy(studyPackages = found.filterNot { StudyApps.isForbidden(it) }.toSet())
        }
    }

    /**
     * Turns a single in-app feed on or off.
     *
     * A live pact may tighten but not loosen, same rule as everything else:
     * switching Shorts back on mid-pact is exactly the move the pact exists to
     * refuse.
     */
    fun toggleSurface(key: String) = viewModelScope.launch {
        updateData { d ->
            val on = key in d.blockedSurfaces
            if (d.pactLive && on) d
            else d.copy(
                blockedSurfaces = if (on) d.blockedSurfaces - key
                else d.blockedSurfaces + key,
                surfacesSeeded = true,
            )
        }
    }

    /** Sensible starting set on first run: the endless feeds, not Stories. */
    fun seedSurfaces() = viewModelScope.launch {
        updateData { d ->
            if (d.surfacesSeeded) d
            else d.copy(blockedSurfaces = FeedSurfaces.defaults, surfacesSeeded = true)
        }
    }

    /** Turning off the last day would silently disable the window entirely. */
    fun toggleClassDay(day: Int) = viewModelScope.launch {
        updateData { d ->
            val on = day in d.classDays
            if (on && d.classDays.size == 1) d
            else d.copy(
                classDays = if (on) d.classDays - day else d.classDays + day
            )
        }
    }

    /** Captures the current rules under a name. Overwrites a profile of the same name. */
    fun saveProfile(name: String) = viewModelScope.launch {
        val clean = name.trim().take(24)
        if (clean.isBlank()) return@launch
        updateData { d ->
            val snapshot = BlockProfile(
                id = clean.lowercase().replace(" ", "_"),
                name = clean,
                blockedPackages = d.blockedPackages,
                dailyCapMinutes = d.dailyCapMinutes,
                blockedSurfaces = d.blockedSurfaces,
                classHoursOn = d.classHoursOn,
                classDays = d.classDays,
                classStartHour = d.classStartHour,
                classEndHour = d.classEndHour,
            )
            d.copy(
                profiles = d.profiles.filterNot { it.id == snapshot.id } + snapshot,
                activeProfileId = snapshot.id,
            )
        }
    }

    /**
     * Loads a profile's rules.
     *
     * A live pact refuses this outright rather than merging. Switching to a
     * lighter profile is the simplest possible way around a pact, and a
     * half-applied one — new blocklist, old caps — would be worse than either.
     */
    fun applyProfile(id: String) = viewModelScope.launch {
        updateData { d ->
            val p = d.profiles.firstOrNull { it.id == id }
            if (d.pactLive || p == null) d
            else {
                d.copy(
                    blockedPackages = p.blockedPackages,
                    dailyCapMinutes = p.dailyCapMinutes,
                    blockedSurfaces = p.blockedSurfaces,
                    surfacesSeeded = true,
                    classHoursOn = p.classHoursOn,
                    classDays = p.classDays,
                    classStartHour = p.classStartHour,
                    classEndHour = p.classEndHour,
                    activeProfileId = p.id,
                )
            }
        }
    }

    fun deleteProfile(id: String) = viewModelScope.launch {
        updateData { d ->
            if (d.pactLive) d
            else d.copy(
                profiles = d.profiles.filterNot { it.id == id },
                activeProfileId = if (d.activeProfileId == id) "" else d.activeProfileId,
            )
        }
    }

    fun toggleStudyApp(pkg: String) = viewModelScope.launch {
        if (StudyApps.isForbidden(pkg)) return@launch
        updateData { d ->
            val next = if (pkg in d.studyPackages) d.studyPackages - pkg
                       else d.studyPackages + pkg
            d.copy(studyPackages = next.filterNot { StudyApps.isForbidden(it) }.toSet())
        }
    }

    /** One XP per minute spent inside a study app, PW-style. */
    fun addStudyXp(minutes: Int) = viewModelScope.launch {
        updateData { it.copy(studyXp = it.studyXp + minutes) }
    }

    /**
     * True only when the shield can actually do something.
     *
     * setShield used to accept `on` at face value — flip the switch, done.
     * So someone who skipped Usage Access or Overlay during onboarding, or
     * revoked it later, could still turn Shield "on" from Home or Settings:
     * the toggle would show on, and nothing would ever block, and nothing
     * would ever ask for the permission again, because the only places that
     * checked permissions were the onboarding screen and the manual
     * Permissions page — not the moment a feature was actually switched on.
     * A switch that is on and does nothing is worse than one that refuses,
     * because it hides the missing permission instead of surfacing it.
     */
    private fun canShield(): Boolean =
        com.momentum.focus.ui.util.Perms.allRequiredGranted(getApplication())

    fun setShield(on: Boolean) = viewModelScope.launch {
        if (on && !canShield()) return@launch
        updateData { d ->
            if (d.pactLive && !on) d
            else d.copy(
                shieldOn = on,
                // Arming the shield with nothing in the list is a shield that
                // does nothing, and that is how people conclude the app is
                // broken. Seed the obvious offenders on the first arm only —
                // an empty list after this point is the user's own choice.
                blockedPackages = if (on && d.blockedPackages.isEmpty())
                    StudyApps.defaultBlocklist(getApplication()) else d.blockedPackages,
            )
        }
    }

    /** Saves the guesses and the measured baseline the app is judged against. */
    fun saveBaseline(guessHours: Int, guessPickups: Int, actualMinutes: Int) =
        viewModelScope.launch {
            updateData {
                it.copy(
                    guessHours = guessHours,
                    guessPickups = guessPickups,
                    baselineMinutes = actualMinutes,
                )
            }
        }

    fun completeOnboarding() = viewModelScope.launch {
        updateData { it.copy(onboarded = true) }
    }

    fun setName(name: String) = viewModelScope.launch {
        updateData { it.copy(userName = name.ifBlank { "friend" }) }
    }

    fun setGoal(days: Int) = viewModelScope.launch {
        updateData { it.copy(streakGoal = days.coerceIn(7, 365)) }
    }

    // ---- Urges -----------------------------------------------------------

    fun logUrge(survived: Boolean, note: String = "") = viewModelScope.launch {
        updateData { d ->
            d.copy(
                urges = d.urges + UrgeEvent(
                    epochDay = LocalDate.now().toEpochDay(),
                    hour = nowHour(),
                    survived = survived,
                    note = note,
                )
            )
        }
    }

    // ---- Journal ---------------------------------------------------------

    fun saveJournal(mood: Int, text: String, trigger: String) = viewModelScope.launch {
        val today = LocalDate.now().toEpochDay()
        updateData { d ->
            d.copy(
                journal = d.journal.filterNot { it.epochDay == today } +
                    JournalEntry(today, mood, text, trigger)
            )
        }
    }

    private companion object {
        /**
         * How long the study numbers stay warm.
         *
         * Ten minutes. They are day-scale figures — streak, minutes this
         * month, phone average — so anything shorter is paying a stats query
         * for a number that has not moved.
         */
        const val FACTS_TTL_MS = 10 * 60 * 1000L

        /**
         * Longest single extension the picker offers — one week.
         *
         * Was 24h back when the only controls were +1h, +3h and +6h. A longer
         * pact is a legitimate thing to want before an exam, but the UI has to
         * confirm anything at this end of the range: it cannot be taken back.
         */
        const val MAX_EXTEND_HOURS = 24 * 7

        /**
         * Furthest into the future any pact may reach, counted from now.
         *
         * Extensions add to an existing end time, so repeated taps compound.
         * Thirty days is already far past any exam this app is used for, and
         * past it the phone would be locked down with no mechanism to undo it.
         */
        const val MAX_PACT_HORIZON_MS = 30L * 24 * 3600_000L
    }
}
