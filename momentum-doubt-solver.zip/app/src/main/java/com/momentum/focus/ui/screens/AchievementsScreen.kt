package com.momentum.focus.ui.screens

import androidx.compose.runtime.*
import com.momentum.focus.data.tr
import com.momentum.focus.data.Tier
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.draw.drawBehind
import androidx.compose.material3.Icon
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.Canvas
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import com.momentum.focus.ui.components.GlowProgressBar
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.achievements
import com.momentum.focus.data.unlockedCount
import com.momentum.focus.ui.components.Avatar3D
import com.momentum.focus.ui.components.NoteStack3D
import com.momentum.focus.ui.components.shapeOnly
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*

@Composable
fun AchievementsScreen(data: AppData) {
    // v6 rewards wall (Gen-Z pass): every achievement has its own colour
    // fade, its own icon, and a tier badge with an aura — bronze, silver,
    // gold or holographic crown — that breathes once it's earned. Cards rise
    // in one after another; progress glows in the card's own colour.
    val list = data.achievements()
    val inf = rememberInfiniteTransition(label = "rewards")
    val breath by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400), RepeatMode.Reverse), label = "breath")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "spin")

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 20.dp, bottom = 28.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("REWARDS", fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp, color = InkMid)
                Text("${data.unlockedCount} of ${list.size}", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Black, color = Ink)
                Text(tr("Earn them. Flex them.", "कमाओ। दिखाओ।"), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = InkMid)
            }
            // trophy: a holographic hex medal with a slow aura (replaces the cash-pile art)
            Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    drawCircle(Brush.radialGradient(listOf(Color(0xFFB9A7FF).copy(alpha = 0.25f + 0.2f * breath), Color.Transparent)), size.minDimension / 2)
                    rotate(spin, center) {
                        drawCircle(Brush.sweepGradient(listOf(Color(0xFFFF9EC4), Color(0xFF7FD4FF), Color(0xFF3FE28F), Color(0xFFFFD84D), Color(0xFFFF9EC4))), size.minDimension * 0.36f, style = Stroke(5.dp.toPx()))
                    }
                }
                TierBadge(Tier.CROWN, Icons.Filled.EmojiEvents, Color(0xFFB9A7FF), unlocked = true, breath = breath, size = 58.dp)
            }
        }
        Spacer(Modifier.height(10.dp))
        GlowProgressBar(progress = if (list.isEmpty()) 0f else data.unlockedCount / list.size.toFloat(), height = 10.dp)
        Spacer(Modifier.height(18.dp))

        list.forEachIndexed { i, a ->
            val col = REWARD_COLOURS[i % REWARD_COLOURS.size]
            val icon = REWARD_ICONS[i % REWARD_ICONS.size]
            val fill by animateFloatAsState(a.progress, Motion.settle(), label = a.id)
            var shown by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { kotlinx.coroutines.delay(60L + i.coerceAtMost(10) * 55L); shown = true }
            val k by animateFloatAsState(if (shown) 1f else 0f, tween(300, easing = FastOutSlowInEasing), label = "in$i")
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp, end = 5.dp)
                    .graphicsLayer { alpha = k; translationY = (1f - k) * 24.dp.toPx() }
                    .drawBehind {
                        if (a.unlocked) for (g in 1..4) {
                            val d = (g * 3f + breath * 3f).dp.toPx()
                            drawRoundRect(col.copy(alpha = 0.14f * (1f - g / 5f)), Offset(-d, -d), Size(size.width + 2 * d, size.height + 2 * d), CornerRadius(16.dp.toPx() + d))
                        }
                        drawRoundRect(Ink, Offset(5.dp.toPx(), 5.dp.toPx()), size, CornerRadius(16.dp.toPx()))
                    }
                    .clip(RoundedCornerShape(16.dp))
                    .background(CreamCard)
                    .background(Brush.linearGradient(listOf(col.copy(alpha = if (a.unlocked) 0.55f else 0.22f), col.copy(alpha = 0.04f)), Offset.Zero, Offset(900f, 300f)))
                    .border(2.5.dp, Ink, RoundedCornerShape(16.dp))
                    .padding(14.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TierBadge(a.tier, icon, col, unlocked = a.unlocked, breath = breath, size = 52.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            a.tier.label, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp,
                            color = tierColour(a.tier).copy(alpha = if (a.unlocked) 1f else 0.75f),
                        )
                        Text(a.title, fontSize = 18.sp, fontWeight = FontWeight.Black, color = Ink)
                        Text(if (a.unlocked) a.reward else a.detail, fontSize = 13.sp, color = Ink.copy(alpha = 0.6f))
                    }
                    Text(
                        if (a.unlocked) "✓" else "${a.current}/${a.target}",
                        fontSize = 12.sp, fontWeight = FontWeight.Black,
                        color = if (a.unlocked) Ink else Ink.copy(alpha = 0.7f),
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(if (a.unlocked) col else Color.White.copy(alpha = 0.7f))
                            .border(2.dp, Ink, RoundedCornerShape(999.dp))
                            .padding(horizontal = 9.dp, vertical = 3.dp),
                    )
                }
                if (!a.unlocked) {
                    Spacer(Modifier.height(12.dp))
                    GlowProgressBar(progress = fill, height = 11.dp, color = col)
                }
            }
        }
    }
}

/** Hex badge: tier metal for the frame, the achievement's own colour inside, an icon, and a breathing aura once earned. */
@Composable
private fun TierBadge(tier: Tier, icon: ImageVector, col: Color, unlocked: Boolean, breath: Float, size: androidx.compose.ui.unit.Dp) {
    val metal = tierColour(tier)
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2
            val c = center
            fun hex(rr: Float) = Path().apply {
                for (k in 0 until 6) {
                    val a = Math.toRadians(-90.0 + k * 60.0)
                    val p = Offset(c.x + (kotlin.math.cos(a) * rr).toFloat(), c.y + (kotlin.math.sin(a) * rr).toFloat())
                    if (k == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y)
                }
                close()
            }
            if (unlocked) drawCircle(Brush.radialGradient(listOf(col.copy(alpha = 0.55f * (0.6f + 0.4f * breath)), Color.Transparent), c, r * 1.25f), r * 1.25f, c)
            val outer = hex(r * 0.98f)
            val frame = if (tier == Tier.CROWN)
                Brush.sweepGradient(listOf(Color(0xFFFF9EC4), Color(0xFF7FD4FF), Color(0xFF3FE28F), Color(0xFFFFD84D), Color(0xFFFF9EC4)), c)
            else Brush.linearGradient(listOf(lerp(metal, Color.White, 0.55f), metal, lerp(metal, Color.Black, 0.35f)), Offset(c.x - r, c.y - r), Offset(c.x + r, c.y + r))
            drawPath(outer, frame)
            val inner = hex(r * 0.74f)
            drawPath(inner, Brush.linearGradient(listOf(lerp(col, Color.White, 0.25f), lerp(col, Color.Black, 0.25f)), Offset(c.x, c.y - r), Offset(c.x, c.y + r)))
            drawPath(outer, Ink, style = Stroke(2.dp.toPx()))
            drawPath(inner, Ink.copy(alpha = 0.5f), style = Stroke(1.dp.toPx()))
            drawOval(Color.White.copy(alpha = 0.35f), Offset(c.x - r * 0.45f, c.y - r * 0.62f), Size(r * 0.7f, r * 0.3f))
            if (!unlocked) drawPath(outer, Color(0xFFF7F4EA).copy(alpha = 0.45f))
        }
        Icon(icon, contentDescription = null, tint = if (unlocked) Color.White else Ink.copy(alpha = 0.75f), modifier = Modifier.size(size * 0.38f))
        if (!unlocked) {
            Box(
                Modifier.align(Alignment.BottomEnd).size(size * 0.36f).clip(CircleShape).background(Ink),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.Lock, null, tint = Color.White, modifier = Modifier.size(size * 0.2f)) }
        }
    }
}

private fun tierColour(t: Tier): Color = when (t) {
    Tier.BRONZE -> Color(0xFFC97A3E)
    Tier.SILVER -> Color(0xFF9AA4B2)
    Tier.GOLD -> Color(0xFFE8B21F)
    Tier.CROWN -> Color(0xFF9D7BFF)
}

private val REWARD_COLOURS = listOf(
    Color(0xFF2ED98C), Color(0xFFFFB020), Color(0xFFFF6A2E), Color(0xFF9D7BFF),
    Color(0xFF22C7FF), Color(0xFFFF4F8B), Color(0xFF00C2A8), Color(0xFFFFC531),
    Color(0xFF6C7BFF), Color(0xFFFF7A9C), Color(0xFF36D1DC), Color(0xFFB45CFF),
)
private val REWARD_ICONS = listOf(
    Icons.Filled.Bolt, Icons.Filled.LocalFireDepartment, Icons.Filled.Whatshot, Icons.Filled.TrendingUp,
    Icons.Filled.Diamond, Icons.Filled.Star, Icons.Filled.Timer, Icons.Filled.Shield,
    Icons.Filled.AutoAwesome, Icons.Filled.Psychology, Icons.Filled.WorkspacePremium, Icons.Filled.EmojiEvents,
)
