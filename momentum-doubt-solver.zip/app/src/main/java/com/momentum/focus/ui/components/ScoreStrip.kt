package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.Success
import com.momentum.focus.data.SuccessPart
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import kotlin.math.roundToInt

/**
 * One-line Momentum Score on Home (idea from Opal's single score), so the
 * number is easy to find without bringing the full report back onto Home —
 * that moved to Profile on purpose, and a tap here goes there.
 *
 * Same Success.of() score Profile shows. Four segment ticks = the four parts;
 * the weakest is Tang. Number counts up once (600 ms). No loop.
 */
@Composable
fun ScoreStrip(data: AppData, onOpen: () -> Unit, modifier: Modifier = Modifier) {
    val score = remember(data) { Success.of(data) }
    if (!score.hasData) return
    val str = strings().success
    val count = remember { Animatable(0f) }
    LaunchedEffect(score.total) { count.animateTo(score.total.toFloat(), tween(600, easing = FastOutSlowInEasing)) }

    val shape = RoundedCornerShape(14.dp)
    val shadow = 3.dp * Vibe.shadow
    Row(
        modifier
            .fillMaxWidth()
            .drawBehind {
                val d = shadow.toPx()
                drawRoundRect(Ink, Offset(d, d), size, CornerRadius(14.dp.toPx()))
            }
            .clip(shape)
            .background(CreamCard)
            .border(Paper.Outline, Ink, shape)
            .clickableNoRipple(remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, onClick = onOpen)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(str.label.uppercase(), style = MaterialTheme.typography.labelSmall, color = InkMid)
                Spacer(Modifier.width(6.dp))
                NewBadge()
            }
            Text(str.verdict(score.total), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ink)
        }
        // Four part ticks, weakest highlighted.
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.Bottom) {
            SuccessPart.entries.forEach { p ->
                val v = (score.parts[p] ?: 0) / 25f
                val weak = p == score.weakest
                Box(
                    Modifier
                        .size(width = 8.dp, height = 26.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Sunk)
                        .drawBehind {
                            val h = size.height * v.coerceIn(0.08f, 1f)
                            drawRect(if (weak) Tang.fill else Mint.fill, Offset(0f, size.height - h), Size(size.width, h))
                        }
                        .border(1.5.dp, Ink, RoundedCornerShape(3.dp))
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Text(
            "${count.value.roundToInt()}",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Black,
            color = Ink,
        )
        Text(str.outOf, style = MaterialTheme.typography.bodySmall, color = InkMid, modifier = Modifier.padding(start = 2.dp, top = 8.dp))
    }
}
