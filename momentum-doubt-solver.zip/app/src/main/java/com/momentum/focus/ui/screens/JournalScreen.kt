package com.momentum.focus.ui.screens

import com.momentum.focus.data.tr
import androidx.compose.animation.core.animateFloatAsState
import com.momentum.focus.data.JournalEntry
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

private val TRIGGERS = listOf("Bored", "Stressed", "Alone", "Late night", "Reels", "Tired")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JournalScreen(
    data: AppData,
    onSave: (Int, String, String) -> Unit,
) {
    val haptics = rememberHaptics()
    val existing = data.todayJournal

    var mood by remember(existing) { mutableIntStateOf(existing?.mood ?: 3) }
    var text by remember(existing) { mutableStateOf(existing?.text ?: "") }
    var trigger by remember(existing) { mutableStateOf(existing?.trigger ?: "") }
    var saved by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 28.dp, bottom = 32.dp),
    ) {
        Text(
            "TODAY",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            tr("Today's tally", "आज का हिसाब"),
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )

        Spacer(Modifier.height(20.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            (1..5).forEach { value ->
                val selected = mood == value
                val scale by animateFloatAsState(
                    if (selected) 1.12f else 1f, Motion.bouncy(), label = "mood$value"
                )
                val sticker = stickerFor(value + 1)
                Box(
                    Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .graphicsLayer { scaleX = scale; scaleY = scale }
                        .clip(CircleShape)
                        .background(
                            if (selected) sticker.fill
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .border(if (selected) Paper.Outline else 2.dp, Ink, CircleShape)
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); mood = value; saved = false
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "$value",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (selected) Lilac.on else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        Text(
            "WHAT SET YOU OFF",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(10.dp))

        FlowRow(Modifier.fillMaxWidth()) {
            TRIGGERS.forEach { t ->
                val selected = trigger == t
                Box(
                    Modifier
                        .padding(end = 8.dp, bottom = 8.dp)
                        .clip(RoundedCornerShape(Paper.ChipRadius))
                        .background(if (selected) Lilac.fill else MaterialTheme.colorScheme.surfaceVariant)
                        .border(2.dp, Ink, RoundedCornerShape(Paper.ChipRadius))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); trigger = if (selected) "" else t; saved = false
                        }
                        .padding(horizontal = 16.dp, vertical = 9.dp)
                ) {
                    Text(
                        t,
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (selected) Lilac.on else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = text,
            onValueChange = { text = it; saved = false },
            placeholder = { Text("Three lines is enough. What happened?") },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 130.dp),
            shape = RoundedCornerShape(14.dp),
        )

        Spacer(Modifier.height(18.dp))

        SquishButton(
            label = if (saved) "Saved" else "Save entry",
            sticker = if (saved) Jade else Cobalt,
            modifier = Modifier.fillMaxWidth(),
        ) {
            onSave(mood, text, trigger)
            saved = true
            haptics.confirm()
        }

        val past = remember(data.journal) {
            val today = java.time.LocalDate.now().toEpochDay()
            data.journal.filter { it.epochDay != today }.sortedByDescending { it.epochDay }.take(4)
        }
        if (past.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            Text(
                tr("PAST ENTRIES", "पिछली एंट्री"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            JournalFolder(past, Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

/**
 * Journal folder (from Uiverse folder card, in ink): tap the folder and the
 * last few entries fan up out of it like papers; tap again to tuck them back.
 * Read-only. Every motion value is read inside graphicsLayer (draw phase).
 */
@Composable
private fun JournalFolder(entries: List<JournalEntry>, modifier: Modifier = Modifier) {
    val haptics = rememberHaptics()
    var open by remember { mutableStateOf(false) }
    val overshoot = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f)
    val flap by animateFloatAsState(if (open) 1f else 0f, tween(380, easing = overshoot), label = "flap")
    val lifts = listOf(118f, 88f, 58f, 28f)
    val tilts = listOf(-8f, 7f, -11f, 9f)
    val shifts = listOf(-14f, 16f, -8f, 10f)
    val fmt = remember { java.time.format.DateTimeFormatter.ofPattern("d MMM") }

    Box(
        modifier
            .width(250.dp)
            .height(250.dp)
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                haptics.tick(); open = !open
            },
        contentAlignment = Alignment.BottomCenter,
    ) {
        // back of the folder, with its tab
        Box(
            Modifier
                .padding(bottom = 4.dp)
                .width(240.dp)
                .height(130.dp)
                .hardInk(14.dp)
                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 14.dp, bottomStart = 14.dp, bottomEnd = 14.dp))
                .background(Butter.accent)
                .border(Paper.Outline, Ink, RoundedCornerShape(topStart = 4.dp, topEnd = 14.dp, bottomStart = 14.dp, bottomEnd = 14.dp)),
        )
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .padding(start = 5.dp, bottom = 128.dp)
                .width(78.dp)
                .height(18.dp)
                .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
                .background(Butter.accent)
                .border(Paper.Outline, Ink, RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp)),
        )
        // papers, last drawn = on top, so draw oldest first
        entries.indices.reversed().forEach { i ->
            val e = entries[i]
            val k by animateFloatAsState(
                if (open) 1f else 0f,
                tween(460, delayMillis = if (open) (entries.size - 1 - i) * 50 else i * 30, easing = overshoot),
                label = "paper$i",
            )
            val sticker = stickerFor(e.mood + 1)
            Column(
                Modifier
                    .padding(bottom = 14.dp)
                    .width(196.dp)
                    .height(96.dp)
                    .graphicsLayer {
                        translationY = -lifts[i].dp.toPx() * k
                        translationX = shifts[i].dp.toPx() * k
                        rotationZ = tilts[i] * k
                    }
                    .hardInk(10.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(CreamCard)
                    .border(2.dp, Ink, RoundedCornerShape(10.dp))
                    .padding(10.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(18.dp).clip(CircleShape).background(sticker.fill).border(2.dp, Ink, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { Text("${e.mood}", style = MaterialTheme.typography.labelSmall, color = Ink) }
                    Spacer(Modifier.width(6.dp))
                    Text(
                        java.time.LocalDate.ofEpochDay(e.epochDay).format(fmt),
                        style = MaterialTheme.typography.labelSmall, color = Ink,
                    )
                    if (e.trigger.isNotBlank()) {
                        Spacer(Modifier.width(6.dp))
                        Text(e.trigger, style = MaterialTheme.typography.labelSmall, color = InkMid, maxLines = 1)
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    e.text.ifBlank { tr("(no words, just the mood)", "(सिर्फ़ मूड)") },
                    style = MaterialTheme.typography.bodySmall,
                    color = InkMid,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        // front flap, tips forward from its bottom edge as it opens
        Box(
            Modifier
                .width(240.dp)
                .height(104.dp)
                .graphicsLayer {
                    transformOrigin = TransformOrigin(0.5f, 1f)
                    rotationX = -48f * flap
                    cameraDistance = 12f * density
                }
                .clip(RoundedCornerShape(14.dp))
                .background(Butter.fill)
                .border(Paper.Outline, Ink, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                if (open) tr("Tap to close", "बंद करें") else tr("${entries.size} entries · tap", "${entries.size} एंट्री · टैप"),
                style = MaterialTheme.typography.titleMedium,
                color = Butter.on,
            )
        }
    }
}

/** The app's hard offset ink shadow, drawn behind (place before clip). */
private fun Modifier.hardInk(radius: androidx.compose.ui.unit.Dp): Modifier = drawBehind {
    val d = 3.dp.toPx()
    drawRoundRect(Ink, Offset(d, d), size, CornerRadius(radius.toPx()))
}

