package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.util.DeviceProfile
import kotlin.random.Random

/**
 * LED dot-matrix status board for MyAI — the style of the owner's reference
 * clip (a red "BUILDING" sign that pixel-dissolves into a green "LAUNCHED"),
 * rebuilt as our own component, not the clip itself.
 *
 *   ASK ME   amber  — nothing asked yet
 *   THINKING red    — question sent, nothing back yet (a scan sweeps the dots)
 *   WRITING  orange — answer streaming in
 *   SOLVED   green  — answer finished
 *   RETRY    red    — last call failed
 *
 * Changing state = pixel dissolve: every dot flips from the old frame to the
 * new one at its own random moment over 420 ms, with a little flicker, like a
 * real LED sign rewriting itself. Orange bezel, black panel, unlit dots dim.
 *
 * Cost: a few hundred dots on one Canvas. Static when idle; the THINKING scan
 * is the only loop and it's a still frame on cheap phones (lowEndLoop).
 */
enum class LedState(val word: String, val color: Color, val icon: Int) {
    ASK("ASK ME", Color(0xFFFFB020), 0),
    THINKING("THINKING", Color(0xFFFF3B30), 1),
    WRITING("WRITING", Color(0xFFFF7A1A), 1),
    SOLVED("SOLVED", Color(0xFF39E26A), 2),
    RETRY("RETRY", Color(0xFFFF3B30), 3),
}

private const val ROWS = 7

// 5×7 glyphs, one string per row, '#' = lit.
private val FONT: Map<Char, List<String>> = mapOf(
    'A' to listOf(".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"),
    'S' to listOf(".####", "#....", "#....", ".###.", "....#", "....#", "####."),
    'K' to listOf("#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#"),
    'M' to listOf("#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#"),
    'E' to listOf("#####", "#....", "#....", "####.", "#....", "#....", "#####"),
    'T' to listOf("#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."),
    'H' to listOf("#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"),
    'I' to listOf("#####", "..#..", "..#..", "..#..", "..#..", "..#..", "#####"),
    'N' to listOf("#...#", "##..#", "#.#.#", "#.#.#", "#..##", "#...#", "#...#"),
    'G' to listOf(".####", "#....", "#....", "#.###", "#...#", "#...#", ".###."),
    'W' to listOf("#...#", "#...#", "#...#", "#.#.#", "#.#.#", "##.##", "#...#"),
    'R' to listOf("####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"),
    'O' to listOf(".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."),
    'L' to listOf("#....", "#....", "#....", "#....", "#....", "#....", "#####"),
    'V' to listOf("#...#", "#...#", "#...#", "#...#", "#...#", ".#.#.", "..#.."),
    'D' to listOf("####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####."),
    'Y' to listOf("#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.."),
    ' ' to List(7) { "..." },
)

// 7×7 icons: ? / bars / check / !
private val ICONS: List<List<String>> = listOf(
    listOf(".#####.", "##...##", ".....##", "...###.", "...#...", ".......", "...#..."),
    listOf(".......", ".....##", ".....##", "...####", "...####", ".######", ".######"),
    listOf(".......", "......#", ".....##", "#...##.", "##.##..", ".###...", "..#...."),
    listOf("...#...", "..###..", "..###..", "..###..", "...#...", ".......", "...#..."),
)

/** Builds the lit-dot grid for a state: icon, gap, word. Returns (cols, lit). */
private fun frame(state: LedState, cols: Int): BooleanArray {
    val lit = BooleanArray(cols * ROWS)
    val pieces = ArrayList<List<String>>()
    pieces += ICONS[state.icon]
    pieces += List(ROWS) { ".." }
    state.word.forEachIndexed { i, ch ->
        pieces += FONT[ch] ?: FONT[' ']!!
        if (i < state.word.length - 1) pieces += List(ROWS) { "." }
    }
    val width = pieces.sumOf { it[0].length }
    var x = ((cols - width) / 2).coerceAtLeast(0)
    pieces.forEach { g ->
        for (r in 0 until ROWS) for (c in g[r].indices) {
            val cx = x + c
            if (cx < cols && g[r][c] == '#') lit[r * cols + cx] = true
        }
        x += g[0].length
    }
    return lit
}

@Composable
fun LedBoard(state: LedState, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val glow = remember { DeviceProfile.tier(ctx) != DeviceProfile.Tier.LOW }
    val cols = 58
    var shown by remember { mutableStateOf(state) }
    var prev by remember { mutableStateOf(state) }
    val dissolve = remember { Animatable(1f) }
    val seeds = remember { FloatArray(cols * ROWS) { Random.nextFloat() } }
    LaunchedEffect(state) {
        if (state == shown) return@LaunchedEffect
        prev = shown
        shown = state
        dissolve.snapTo(0f)
        dissolve.animateTo(1f, tween(420, easing = LinearEasing))
    }
    val newLit = remember(shown) { frame(shown, cols) }
    val oldLit = remember(prev) { frame(prev, cols) }
    val scan by lowEndLoop(
        0f, 1f,
        infiniteRepeatable(tween(1100, easing = LinearEasing)),
        "led-scan",
    )
    val scanning = shown == LedState.THINKING || shown == LedState.WRITING

    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.verticalGradient(listOf(Tang.fill, Color(0xFFE0632E))))
            .border(2.dp, Ink, RoundedCornerShape(14.dp))
            .padding(6.dp)
    ) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .aspectRatio(cols / (ROWS + 2f))
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF120A08))
        ) {
            val pitch = size.width / cols
            val r = pitch * 0.36f
            val top = (size.height - pitch * ROWS) / 2f
            val p = dissolve.value
            for (row in 0 until ROWS) for (col in 0 until cols) {
                val i = row * cols + col
                val flipped = seeds[i] < p
                val on = if (flipped) newLit[i] else oldLit[i]
                // a little flicker while the sign rewrites itself
                val flick = p < 1f && kotlin.math.abs(seeds[i] - p) < 0.06f
                val color = if (flipped) shown.color else prev.color
                val c = Offset(col * pitch + pitch / 2f, top + row * pitch + pitch / 2f)
                if (on || flick) {
                    var a = if (flick && !on) 0.5f else 1f
                    if (scanning && on) {
                        val d = kotlin.math.abs(col / cols.toFloat() - scan)
                        a *= 0.55f + 0.45f * (1f - (d * 4f).coerceIn(0f, 1f))
                    }
                    if (glow) drawCircle(color.copy(alpha = 0.22f * a), r * 2.1f, c)
                    drawCircle(color.copy(alpha = a), r, c)
                } else {
                    drawCircle(Color(0xFF2A1E1A), r * 0.85f, c)
                }
            }
        }
    }
}
