package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.util.DeviceProfile
import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * LED dot-matrix sign for MyAI (owner's reference clip style, own build).
 *
 * 2026-10-07 rebuild: it used to be a full-width 60dp board under the count
 * bar, which on a small phone left the answer a letterbox. Now it is a slim
 * 34dp sign that lives IN the top bar and does three jobs:
 *
 *   - marquee: \"WELCOME, RAHUL • ASK ANY DOUBT • 7 LEFT\" runs gently, one
 *     column per step like a real shop sign (step, not slide — cheap, and
 *     it is how real LED marquees move).
 *   - status: THINKING (scan sweeps) / WRITING / SOLVED / RETRY, static.
 *   - confirm: \"GURU MODE\" for two seconds after a mode switch.
 *
 * Any change = pixel dissolve (every dot flips at its own moment over 420ms).
 * First show dissolves in from a dark board — that is the screen's entrance.
 * Text wider than the sign scrolls on its own. Unknown characters (e.g.
 * Devanagari) are skipped, so callers should give Latin text.
 */
enum class LedState(val color: Color, val icon: Int) {
    ASK(Color(0xFFFFB020), -1),
    THINKING(Color(0xFFFF3B30), 1),
    WRITING(Color(0xFFFF7A1A), 1),
    SOLVED(Color(0xFF39E26A), 2),
    RETRY(Color(0xFFFF3B30), 3),
}

private const val ROWS = 7

// 5×7 font (some glyphs narrower). One string per row, '#' = lit.
private val FONT: Map<Char, List<String>> = mapOf(
    'A' to listOf(".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"),
    'B' to listOf("####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."),
    'C' to listOf(".###.", "#...#", "#....", "#....", "#....", "#...#", ".###."),
    'D' to listOf("####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####."),
    'E' to listOf("#####", "#....", "#....", "####.", "#....", "#....", "#####"),
    'F' to listOf("#####", "#....", "#....", "####.", "#....", "#....", "#...."),
    'G' to listOf(".###.", "#...#", "#....", "#.###", "#...#", "#...#", ".####"),
    'H' to listOf("#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"),
    'I' to listOf("###", ".#.", ".#.", ".#.", ".#.", ".#.", "###"),
    'J' to listOf("..###", "...#.", "...#.", "...#.", "...#.", "#..#.", ".##.."),
    'K' to listOf("#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#"),
    'L' to listOf("#....", "#....", "#....", "#....", "#....", "#....", "#####"),
    'M' to listOf("#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#"),
    'N' to listOf("#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#"),
    'O' to listOf(".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."),
    'P' to listOf("####.", "#...#", "#...#", "####.", "#....", "#....", "#...."),
    'Q' to listOf(".###.", "#...#", "#...#", "#...#", "#.#.#", "#..#.", ".##.#"),
    'R' to listOf("####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"),
    'S' to listOf(".####", "#....", "#....", ".###.", "....#", "....#", "####."),
    'T' to listOf("#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."),
    'U' to listOf("#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."),
    'V' to listOf("#...#", "#...#", "#...#", "#...#", "#...#", ".#.#.", "..#.."),
    'W' to listOf("#...#", "#...#", "#...#", "#.#.#", "#.#.#", "#.#.#", ".#.#."),
    'X' to listOf("#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#"),
    'Y' to listOf("#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.."),
    'Z' to listOf("#####", "....#", "...#.", "..#..", ".#...", "#....", "#####"),
    '0' to listOf(".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###."),
    '1' to listOf(".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###"),
    '2' to listOf(".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####"),
    '3' to listOf("####.", "....#", "....#", ".###.", "....#", "....#", "####."),
    '4' to listOf("...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#."),
    '5' to listOf("#####", "#....", "####.", "....#", "....#", "#...#", ".###."),
    '6' to listOf(".###.", "#....", "#....", "####.", "#...#", "#...#", ".###."),
    '7' to listOf("#####", "....#", "...#.", "..#..", ".#...", ".#...", ".#..."),
    '8' to listOf(".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###."),
    '9' to listOf(".###.", "#...#", "#...#", ".####", "....#", "....#", ".###."),
    ' ' to List(ROWS) { "..." },
    '.' to listOf(".", ".", ".", ".", ".", ".", "#"),
    ',' to listOf("..", "..", "..", "..", "..", ".#", "#."),
    '!' to listOf("#", "#", "#", "#", "#", ".", "#"),
    '?' to listOf(".###.", "#...#", "....#", "...#.", "..#..", ".....", "..#.."),
    '-' to listOf("...", "...", "...", "###", "...", "...", "..."),
    ':' to listOf(".", "#", ".", ".", ".", "#", "."),
    '\'' to listOf("#", "#", ".", ".", ".", ".", "."),
    '/' to listOf("....#", "...#.", "...#.", "..#..", ".#...", ".#...", "#...."),
    '+' to listOf(".....", "..#..", "..#..", "#####", "..#..", "..#..", "....."),
    // The separator in marquee lines: a small four-point star.
    '•' to listOf("...", "...", ".#.", "###", ".#.", "...", "..."),
)

// 7×7 icons: ? / bars / check / !
private val ICONS: List<List<String>> = listOf(
    listOf(".#####.", "##...##", ".....##", "...###.", "...#...", ".......", "...#..."),
    listOf(".......", ".....##", ".....##", "...####", "...####", ".######", ".######"),
    listOf(".......", "......#", ".....##", "#...##.", "##.##..", ".###...", "..#...."),
    listOf("...#...", "..###..", "..###..", "..###..", "...#...", ".......", "...#..."),
)

/** True if the sign can draw at least one letter of [s] (used for names). */
fun ledCanShow(s: String): Boolean = s.uppercase().any { it != ' ' && FONT.containsKey(it) }

/** Uppercases and drops what the sign cannot draw. */
fun ledClean(s: String): String =
    s.uppercase().filter { FONT.containsKey(it) }.replace(Regex(" {2,}"), " ").trim()

/** Content as columns of 7 dots: optional icon, gap, then the letters. */
private fun columns(text: String, icon: Int): List<BooleanArray> {
    val out = ArrayList<BooleanArray>()
    fun add(g: List<String>) {
        for (c in g[0].indices) out += BooleanArray(ROWS) { r -> g[r][c] == '#' }
    }
    if (icon in ICONS.indices) {
        add(ICONS[icon])
        repeat(2) { out += BooleanArray(ROWS) }
    }
    val clean = ledClean(text)
    clean.forEachIndexed { i, ch ->
        add(FONT[ch] ?: return@forEachIndexed)
        if (i < clean.lastIndex) out += BooleanArray(ROWS)
    }
    return out
}

private class LedFrame(val cols: List<BooleanArray>, val color: Color, val scroll: Boolean)

private fun LedFrame.lit(col: Int, row: Int, width: Int, step: Int): Boolean {
    val w = cols.size
    if (w == 0) return false
    val moving = scroll || w > width
    if (!moving) {
        val i = col - (width - w) / 2
        return i in 0 until w && cols[i][row]
    }
    val total = w + maxOf(width / 3, 10)
    val i = ((col + step) % total + total) % total
    return i < w && cols[i][row]
}

/**
 * The sign. [text] is shown centred, or scrolled when [marquee] is on or it
 * does not fit. [scanning] sweeps a brighter band across (THINKING/WRITING).
 */
@Composable
fun LedSign(
    text: String,
    color: Color,
    modifier: Modifier = Modifier,
    icon: Int = -1,
    marquee: Boolean = false,
    scanning: Boolean = false,
    height: Dp = 34.dp,
) {
    val ctx = LocalContext.current
    val tier = remember { DeviceProfile.tier(ctx) }
    val glow = tier != DeviceProfile.Tier.LOW
    val stepMs = if (tier == DeviceProfile.Tier.LOW) 120L else 85L

    // Boots from a dark board: the first dissolve IS the screen's entrance.
    var cur by remember { mutableStateOf(LedFrame(emptyList(), color, false)) }
    var prev by remember { mutableStateOf(cur) }
    var prevStep by remember { mutableIntStateOf(0) }
    val step = remember { mutableIntStateOf(0) }
    val dissolve = remember { Animatable(1f) }
    val seeds = remember { FloatArray(ROWS * 400) { Random.nextFloat() } }

    LaunchedEffect(text, color, icon, marquee) {
        prev = cur
        prevStep = step.intValue
        cur = LedFrame(columns(text, icon), color, marquee)
        step.intValue = 0
        dissolve.snapTo(0f)
        dissolve.animateTo(1f, tween(420, easing = LinearEasing))
    }
    val scan by lowEndLoop(0f, 1f, infiniteRepeatable(tween(1100, easing = LinearEasing)), "led-scan")

    val bezel = RoundedCornerShape(10.dp)
    BoxWithConstraints(
        modifier
            .height(height)
            .clip(bezel)
            .background(Brush.verticalGradient(listOf(Tang.fill, Color(0xFFE0632E))))
            .border(2.dp, Ink, bezel)
            .padding(3.dp)
            .semantics { contentDescription = text },
    ) {
        val pitchDp = maxHeight / (ROWS + 2f)
        val width = (maxWidth / pitchDp).toInt().coerceIn(8, 400)
        val frame = cur
        // Only a moving frame needs the step clock; a static word costs
        // nothing after its dissolve.
        val moving = frame.scroll || frame.cols.size > width
        LaunchedEffect(frame, moving) {
            if (!moving) return@LaunchedEffect
            delay(1100) // let the first words be read before they move
            while (true) {
                delay(stepMs)
                step.intValue++
            }
        }
        Canvas(
            Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(7.dp))
                .background(Color(0xFF120A08)),
        ) {
            val pitch = size.height / (ROWS + 2f)
            val cols = (size.width / pitch).toInt().coerceIn(1, 400)
            val left = (size.width - cols * pitch) / 2f
            val top = pitch
            val r = pitch * 0.36f
            val p = dissolve.value
            val s = step.intValue
            for (row in 0 until ROWS) for (col in 0 until cols) {
                val seed = seeds[(row * 400 + col) % seeds.size]
                val flipped = seed < p
                val f = if (flipped) cur else prev
                val on = f.lit(col, row, cols, if (flipped) s else prevStep)
                val flick = p < 1f && kotlin.math.abs(seed - p) < 0.06f
                val c = Offset(left + col * pitch + pitch / 2f, top + row * pitch + pitch / 2f)
                if (on || flick) {
                    var a = if (flick && !on) 0.5f else 1f
                    if (scanning && on) {
                        val d = kotlin.math.abs(col / cols.toFloat() - scan)
                        a *= 0.55f + 0.45f * (1f - (d * 4f).coerceIn(0f, 1f))
                    }
                    if (glow) drawCircle(f.color.copy(alpha = 0.22f * a), r * 2.1f, c)
                    drawCircle(f.color.copy(alpha = a), r, c)
                } else {
                    drawCircle(Color(0xFF2A1E1A), r * 0.85f, c)
                }
            }
        }
    }
}
