package com.momentum.focus.ui.screens

import androidx.compose.ui.unit.sp
import androidx.activity.compose.BackHandler
import com.momentum.focus.data.tr

import androidx.compose.animation.core.RepeatMode
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.layout.onPlaced
import kotlin.math.roundToInt
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.keyframes
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.mutableIntStateOf
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import com.momentum.focus.ui.components.CrownCinematic
import com.momentum.focus.ui.components.MarkerTitle
import com.momentum.focus.ui.components.FrostScrim
import com.momentum.focus.ui.components.FrostSheet
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.block.Admin
import com.momentum.focus.data.AppData
import com.momentum.focus.data.FocusLevels
import com.momentum.focus.data.bankBar
import com.momentum.focus.data.Currency
import com.momentum.focus.ui.TimerState
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.PactBanner
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import androidx.compose.ui.platform.LocalContext
import com.momentum.focus.data.AppCatalog
import com.momentum.focus.data.CataloguedApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay

/**
 * Extensions long enough to need confirming, longest last.
 *
 * Three, not seven: the row has to fit a narrow phone, and the gap between
 * half a day and a week is not one anybody fine-tunes.
 */
private val LONG_EXTENDS = listOf("+12h" to 12, "+1d" to 24, "+7d" to 168)

@Composable
fun FocusScreen(
    data: AppData,
    timer: TimerState,
    onToggle: () -> Unit,
    onAbandon: () -> Unit,
    onDuration: (Int) -> Unit,
    onSubject: (String) -> Unit,
    onFocusLevel: (Int) -> Unit = {},
    onCrownIntroSeen: () -> Unit = {},
    onCrown: (Boolean) -> Unit = {},
    premium: Boolean = false,
    onPlans: () -> Unit = {},
    onToggleStudy: (String) -> Unit = {},
    onExtendPact: (Int) -> Unit = {},
    onSubjects: (List<String>) -> Unit = {},
    /** Non-null when Begin will not do anything, and says why. */
    startBlocked: String? = null,
) {
    val haptics = rememberHaptics()
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var adminRefresh by remember { mutableIntStateOf(0) }
    var pendingCrown by rememberSaveable { mutableStateOf(false) }
    // Declared up here, not further down with the other dialog flags, because
    // the effect below writes to it — and a local read before its own
    // declaration is not a warning in Kotlin, it is a compile error.
    var cinematic by remember { mutableStateOf(false) }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) adminRefresh++
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    val adminOnNow = remember(adminRefresh) { Admin.isActive(context) }
    LaunchedEffect(adminOnNow, premium) {
        if (pendingCrown && adminOnNow && premium) {
            // The level has to move too. This used to call onCrown alone, so
            // after granting admin you came back to a chip that still was not
            // selected and had to press Crown all over again.
            onCrown(true)
            onFocusLevel(4)
            pendingCrown = false
            if (!data.crownIntroSeen) cinematic = true
        }
        if (!adminOnNow && data.crownMode && !data.pactLive) onCrown(false)
    }
    val str = strings()
    var confirmStop by remember { mutableStateOf(false) }
    // Which long extension is waiting on a yes. Null when nothing is asked.
    var pactAsk by remember { mutableStateOf<Int?>(null) }
    // Crown waiting on a yes. Crown is the one level that arms a pact, and a
    // pact cannot be shortened, so it is the one level a stray tap can cost
    // you a day over.
    var crownAsk by remember { mutableStateOf(false) }
    /** Whether the brief's terms have been ticked. Resets every time it opens. */
    var crownRead by remember { mutableStateOf(false) }
    var addSubject by remember { mutableStateOf(false) }
    var levelRefused by remember { mutableStateOf(false) }
    LaunchedEffect(levelRefused) {
        if (levelRefused) { kotlinx.coroutines.delay(2600); levelRefused = false }
    }
    // Getting into Crown takes a brief, a re-read every time, and the system
    // admin dialog. Getting out used to take one tap on a lower level in
    // this same picker — no confirmation, no re-reading anything, same
    // motion as picking L1 on a free install. Locked Settings (see
    // SettingsScreen) closes the other exit; this one needed its own door.
    var dropCrownAsk by remember { mutableStateOf<Int?>(null) }
    var customOpen by rememberSaveable { mutableStateOf(false) }
    // Every sheet on this screen is a Box over a scrim, not a Dialog, so back
    // has to be wired by hand or it skips the sheet and leaves the tab.
    BackHandler(enabled = crownAsk || dropCrownAsk != null || pactAsk != null || customOpen) {
        when {
            dropCrownAsk != null -> dropCrownAsk = null
            crownAsk -> crownAsk = false
            pactAsk != null -> pactAsk = null
            else -> customOpen = false
        }
    }
    var customMins by rememberSaveable { mutableIntStateOf(40) }
    // Defaults to subject mode when a subject is already set, so returning to
    // the screen does not silently drop the label off the next session.
    var justFocus by rememberSaveable { mutableStateOf(false) }
    val split = remember(data.sessions, data.subjects) { data.subjectSplit() }
    val minsNow = (timer.totalSeconds / 60).coerceAtLeast(1)
    val earn = (minsNow / data.effectiveRatio.coerceAtLeast(1))
    val presets = listOf(25, 50, 90)
    val isCustom = timer.totalSeconds / 60 !in presets

    // A tick on every whole minute boundary. Frequent enough to feel present,
    // rare enough that it never becomes noise.
    LaunchedEffect(timer.remaining) {
        if (timer.running && timer.remaining > 0 && timer.remaining % 60 == 0) {
            haptics.tick()
        }
    }

    Box(Modifier.fillMaxSize()) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 28.dp, bottom = 168.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // Struck through with a marker rather than just set in colour. The
        // reference for this screen is a poster, and a poster's title is the
        // one thing on it that has been drawn on.
        // v5 header: a mono kicker and one big line that changes with the
        // session's state — the screen tells you where you are, not its name.
        Text(
            str.focus.header.uppercase(),
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.4.sp,
            fontSize = 11.sp,
            color = InkMid,
        )
        AnimatedContent(
            targetState = when { timer.running -> 1; timer.paused -> 2; else -> 0 },
            transitionSpec = {
                (fadeIn(tween(240)) + androidx.compose.animation.slideInVertically(tween(240)) { it / 2 }) togetherWith
                    (fadeOut(tween(160)) + androidx.compose.animation.slideOutVertically(tween(160)) { -it / 2 })
            },
            label = "focusHead",
        ) { st ->
            Text(
                when (st) {
                    1 -> tr("Locked in.", "लॉक्ड इन।")
                    2 -> tr("Paused. Don't drift.", "रुका है। भटको मत।")
                    else -> tr("Ready when you are.", "जब आप तैयार हों।")
                },
                fontSize = 30.sp,
                fontWeight = FontWeight.Black,
                color = Ink,
            )
        }
        if (timer.subject.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                timer.subject,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Black,
                color = Ink,
                modifier = Modifier
                    .graphicsLayer { rotationZ = -2f }
                    .clip(RoundedCornerShape(8.dp))
                    .background(Butter.fill)
                    .border(2.dp, Ink, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 3.dp),
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // The old L3 is gone from the picker. It armed the pact and Crown armed
            // the pact plus the uninstall lock, so the two read as the same
            // choice with one extra switch — and a level nobody can tell apart
            // from the next one is just a decision the user has to make twice.
            //
            // The stored value is left alone. Anyone already sitting on 3 keeps
            // working exactly as before and shows as Crown here, which is what
            // their level already does; migrating the number would risk more
            // than it fixes.
            // The lock count is the honest part of this row: one, two or
            // three, rising with how much the level takes away from you.
            // The label can be renamed without touching it.
            listOf(
                Triple(1, FocusLevels.NO_BLOCK, 1),
                Triple(2, FocusLevels.SHIELD, 2),
                Triple(4, FocusLevels.SHIELD_AND_UNINSTALL, 3),
            ).forEach { (lv, label, locks) ->
                // Dropping below the level you started on is refused while the
                // clock runs, so the chip has to look refused too. Tapping a
                // dead chip that stays silent is how a rule reads as a bug.
                val locked = (timer.running || timer.paused || data.pactLive) && lv < data.focusLevel
                Chip(
                    text = label,
                    selected = if (lv == 4) data.focusLevel >= 3 else data.focusLevel == lv,
                    sticker = if (lv == 4) Tang else Cobalt,
                    locks = locks,
                    dimmed = locked,
                ) {
                    when {
                        locked -> { haptics.press(); levelRefused = true }
                        // Climbing to Crown only. Tapping Crown while already
                        // there is a no-op and should not interrogate anyone.
                        lv == 4 && !premium -> {
                            haptics.tick(); onPlans()
                        }
                        // Every route to Crown goes through the brief. It used
                        // to jump straight to the system admin dialog whenever
                        // admin was off, so the popup explaining what Crown
                        // takes was skipped exactly when it mattered — and the
                        // brief only ever appeared for someone who had already
                        // granted admin some other way.
                        lv == 4 && data.focusLevel < 3 -> {
                            haptics.press()
                            crownAsk = true
                            // A fresh tick every time. Carrying it over would
                            // mean the second visit skips the warning, which
                            // is exactly the visit where someone is tapping
                            // fast.
                            crownRead = false
                            levelRefused = false
                        }
                        // Was an instant onCrown(false) here — one tap, no
                        // confirmation, the exact "commitment" Crown's own
                        // brief promises against. Dropping still works, it
                        // just now asks first, same as arming it made you
                        // read something first.
                        lv < 3 && data.crownMode -> {
                            haptics.tick(); dropCrownAsk = lv
                        }
                        lv < 3 -> { haptics.tick(); onCrown(false); onFocusLevel(lv) }
                        else -> { haptics.tick(); onFocusLevel(lv) }
                    }
                }
            }
        }
        if (levelRefused) {
            Spacer(Modifier.height(6.dp))
            Text(
                str.focus.levelRefused,
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.accent,
            )
        }
        Text(
            // The rate here used to be written into the label by hand, so it
            // could disagree with the line right below it and with Profile.
            // One source now: effectiveRatio.
            when (data.focusLevel) {
                1 -> str.focus.lineNoBlock(FocusLevels.NO_BLOCK)
                2 -> str.focus.lineShield(FocusLevels.SHIELD)
                else -> str.focus.lineCrown(FocusLevels.SHIELD_AND_UNINSTALL)
            } + str.focus.ratePerRupee(data.effectiveRatio),
        )
        // pactLive is derived from the wall clock, so nothing in the store
        // changes when it runs out. Without this tick the countdown froze at
        // whatever it read on the last recomposition and the screen went on
        // claiming to be locked long after the pact had ended.
        var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
        LaunchedEffect(Unit) {
            while (true) {
                delay(1_000)
                nowMs = System.currentTimeMillis()
            }
        }
        val pactLive = data.lockUntilEpochMs > nowMs

        if (pactLive) {
            // The same banner Home and Profile show, instead of a second
            // hand-rolled version of it here. Extending now lives inside that
            // card: loose under the level chips and built from the same Chip,
            // "+6h lock" read as a fourth level rather than as something that
            // acts on the pact.
            PactBanner(data.lockUntilEpochMs, Modifier.fillMaxWidth()) {
                Spacer(Modifier.height(10.dp))
                // Short extensions stay one tap. An hour is a small enough
                // mistake to live with.
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 3, 6).forEach { hrs ->
                        Chip(text = "+${hrs}h", selected = false, sticker = Tang) {
                            haptics.tick(); onExtendPact(hrs)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                val asked = pactAsk
                if (asked == null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LONG_EXTENDS.forEach { (label, hrs) ->
                            Chip(text = label, selected = false, sticker = Tang) {
                                haptics.tick(); pactAsk = hrs
                            }
                        }
                    }
                } else {
                    // Nothing shortens a pact, so a week has to be asked for
                    // twice. The old comment on extendPact records what one
                    // stray tap already cost when it was only six hours.
                    Text(
                        str.focus.pactConfirm(
                            LONG_EXTENDS.first { it.second == asked }.first
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Tang.on,
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip(text = str.common.yes, selected = true, sticker = Cobalt) {
                            haptics.press(); onExtendPact(asked); pactAsk = null
                        }
                        Chip(text = str.common.no, selected = false, sticker = Tang) {
                            haptics.tick(); pactAsk = null
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(28.dp))

        val buddyBar = bankBar(timer.totalSeconds / 60)
        val buddyMood = when {
            timer.running && (timer.totalSeconds - timer.remaining) / 60 >= buddyBar -> BuddyMood.SECURED
            timer.running -> BuddyMood.FOCUSED
            timer.paused -> BuddyMood.SAD
            else -> BuddyMood.IDLE
        }
        Box {
            TimerRing(progress = timer.progress, label = timer.label, running = timer.running, paused = timer.paused)
            FocusBuddy(buddyMood, Modifier.align(Alignment.BottomEnd).offset(x = 6.dp, y = 2.dp))
        }

        Spacer(Modifier.height(28.dp))

        if (!timer.running && !timer.paused) {
            Text(
                str.focus.willEarn(minsNow, Currency.format(earn)),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            // The bar was enforced and never shown. Someone would sit for ten
            // minutes of a fifty minute session, watch the timer count, and get
            // nothing — with no way to know a threshold existed at all.
            Text(
                str.focus.minimumToEarn(bankBar(minsNow)),
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.accent,
            )
            Spacer(Modifier.height(12.dp))
            // Deep focus sheet (idea from Regain): the protections that make
            // a session hard to escape, in one place, each with its real
            // on/off state. Shortcuts only — every row runs the flow that
            // already exists for it (Crown's own dialog, system settings).
            var deepOpen by remember { mutableStateOf(false) }
            DeepFocusPill { haptics.tick(); deepOpen = true }
            Spacer(Modifier.height(10.dp))
            if (deepOpen) {
                DeepFocusSheet(
                    pactLive = data.pactLive,
                    crownOn = data.crownMode && adminOnNow,
                    guardOn = remember(adminRefresh) { com.momentum.focus.ui.util.Perms.isShortsGuardOn(context) },
                    // Same gates as the Crown chip: Pro first, then the brief.
                    onCrown = {
                        deepOpen = false
                        if (!premium) onPlans() else { crownAsk = true; crownRead = false }
                    },
                    onGuard = {
                        deepOpen = false
                        runCatching { context.startActivity(android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                    },
                    onClose = { deepOpen = false },
                )
            }
            // Glider (Uiverse radio glider, in ink): a Cobalt bar under the
            // row slides to whichever duration is picked instead of jumping.
            val chipX = remember { mutableStateMapOf<Int, Pair<Float, Float>>() }
            val selIdx = presets.indexOfFirst { !isCustom && timer.totalSeconds == it * 60 }
                .let { if (it < 0) presets.size else it }
            val gx by animateFloatAsState(chipX[selIdx]?.first ?: 0f, Motion.press(), label = "gliderX")
            val gw by animateFloatAsState(chipX[selIdx]?.second ?: 0f, Motion.press(), label = "gliderW")
            Column(Modifier.width(IntrinsicSize.Max)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEachIndexed { idx, mins ->
                    Chip(
                        text = "${mins}m",
                        selected = !isCustom && timer.totalSeconds == mins * 60,
                        sticker = Cobalt,
                        modifier = Modifier.onPlaced {
                            chipX[idx] = it.positionInParent().x to it.size.width.toFloat()
                        },
                    ) {
                        haptics.tick()
                        customOpen = false
                        onDuration(mins)
                    }
                }
                Chip(
                    text = if (isCustom) "${minsNow}m" else str.focus.setCustom,
                    selected = isCustom || customOpen,
                    sticker = Lilac,
                    modifier = Modifier.onPlaced {
                        chipX[presets.size] = it.positionInParent().x to it.size.width.toFloat()
                    },
                ) {
                    haptics.tick()
                    customOpen = !customOpen
                }
            }
            Spacer(Modifier.height(6.dp))
            Canvas(Modifier.fillMaxWidth().height(6.dp)) {
                if (gw <= 0f) return@Canvas
                val inset = 10.dp.toPx()
                val left = gx + inset
                val w = (gw - inset * 2).coerceAtLeast(6.dp.toPx())
                drawRoundRect(
                    if (selIdx == presets.size) Lilac.fill else Cobalt.fill,
                    Offset(left, 0f), Size(w, size.height), CornerRadius(size.height / 2),
                )
                drawRoundRect(
                    Ink, Offset(left, 0f), Size(w, size.height), CornerRadius(size.height / 2),
                    style = Stroke(1.5.dp.toPx()),
                )
            }
            }
            if (customOpen) {
                Spacer(Modifier.height(8.dp))
                Text(
                    str.focus.customMinutes(customMins),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                DurationWheel(
                    value = customMins,
                    onValue = { next ->
                        if (next != customMins) haptics.tick()
                        customMins = next
                    },
                    onSettle = { haptics.confirm() },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                )
                SquishButton(
                    label = str.focus.useCustom(customMins),
                    sticker = Lilac,
                    modifier = Modifier.fillMaxWidth(0.6f),
                ) {
                    haptics.confirm()
                    onDuration(customMins)
                    customOpen = false
                }
            }
            Spacer(Modifier.height(16.dp))

            // Two ways in, asked before anything else, because they want
            // different things from this screen. Someone revising Physics
            // wants the subject on the record so the breakdown means
            // something. Someone who just needs the phone to leave them alone
            // for an hour was previously forced to label it Physics anyway,
            // which quietly poisoned the by-subject stats with sessions that
            // had nothing to do with Physics.
            Text(
                str.focus.howLabel,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(
                    text = str.focus.withSubject,
                    selected = !justFocus,
                    sticker = Marigold,
                ) { haptics.tick(); justFocus = false }
                Chip(
                    text = str.focus.justFocus,
                    selected = justFocus,
                    sticker = Cobalt,
                ) {
                    haptics.tick()
                    justFocus = true
                    // Nothing gets filed under a subject the user did not pick.
                    onSubject("")
                }
            }

            Spacer(Modifier.height(12.dp))
            if (justFocus) {
                Text(
                    str.focus.justFocusNote,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
            } else if (data.examName.isNotBlank()) {
                Text(
                    data.daysToExam?.let { str.focus.examDaysLeft(data.examName, it) }
                        ?: data.examName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
                Spacer(Modifier.height(8.dp))
            }
            if (!justFocus) {
                if (data.subjects.isEmpty()) {
                    // Nothing named yet. Saying so beats showing three chips
                    // the user never chose.
                    Text(
                        str.focus.noSubjectsYet,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    // Scrollable, because three subjects plus "+ Naya" is
                    // wider than a narrow phone. The add chip was being cut in
                    // half at the right edge and read as an empty pill.
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        data.subjects.take(3).forEach { subject ->
                            Chip(
                                text = subject,
                                selected = timer.subject == subject,
                                sticker = Marigold,
                            ) { haptics.tick(); onSubject(subject) }
                        }
                        // Adding a subject used to mean leaving the screen,
                        // finding Profile, opening a collapsed section and
                        // typing into one of three boxes — for something people
                        // realise they need at the moment they sit down.
                        Chip(text = str.focus.addSubject, selected = false, sticker = Cobalt) {
                            haptics.tick(); addSubject = true
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            Text(
                str.focus.studyAppLabel,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            // These used to be the first six entries of a hardcoded list, shown
            // whether or not the phone had them. Tapping one added a package
            // that was not installed, so the timer waited for an app that could
            // never come to the foreground and no rupees were ever paid.
            val context = LocalContext.current
            val studyFound by produceState(initialValue = emptyList<CataloguedApp>()) {
                value = withContext(Dispatchers.IO) {
                    runCatching { AppCatalog.installedStudyApps(context) }.getOrDefault(emptyList())
                }
            }
            if (studyFound.isEmpty()) {
                Text(
                    str.focus.noStudyApp,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                // Chunked rows rather than FlowRow: that one is still behind
                // ExperimentalLayoutApi, so using it is a compile error without
                // an opt-in, and the opt-in is not worth taking on for a list
                // that is almost always two or three chips long.
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    studyFound.chunked(2).forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            row.forEach { app ->
                                Box(Modifier.weight(1f)) {
                                    Chip(
                                        text = app.label,
                                        selected = app.pkg in data.studyPackages,
                                        sticker = Mint,
                                    ) { haptics.tick(); onToggleStudy(app.pkg) }
                                }
                            }
                            // Keeps a lone chip on the last row at half width
                            // instead of stretching it across the screen.
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
            if (data.studyPackages.isEmpty()) {
                Text(
                    str.focus.noStudyAppWarning,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }
            val subMins = split.firstOrNull { it.first == timer.subject }?.second ?: 0
            val untouched = split.filter { it.second == 0 }.map { it.first }
            // With no subject chosen there is nothing to report on, and
            // "untouched in 30 days" about a blank name is just a reproach for
            // not doing something nobody asked for.
            if (!justFocus && timer.subject.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(
                if (subMins == 0) str.focus.subjectUntouched(timer.subject)
                else str.focus.subjectMinutes(timer.subject, subMins),
                style = MaterialTheme.typography.bodyMedium,
                color = if (subMins == 0) Tang.accent else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (untouched.isNotEmpty() && timer.subject !in untouched) {
                Text(
                    str.focus.stillZero(untouched.take(3).joinToString()),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            }
                    }

        Spacer(Modifier.height(12.dp))

        if (timer.running) {
            val doneMin = (timer.totalSeconds - timer.remaining) / 60
            val bar = bankBar(timer.totalSeconds / 60)
            Spacer(Modifier.height(10.dp))
            BankBar(
                progress = (timer.totalSeconds - timer.remaining) / (bar * 60f),
                secured = doneMin >= bar,
                modifier = Modifier.padding(horizontal = 36.dp),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (doneMin >= bar) str.focus.earnSecured
                else str.focus.minutesUntilSecured(bar - doneMin),
                style = MaterialTheme.typography.bodyMedium,
                color = if (doneMin >= bar) Jade.accent else Tang.accent,
                textAlign = TextAlign.Center,
            )
        }


        if (timer.remaining < timer.totalSeconds) {
            Spacer(Modifier.height(10.dp))
            Text(
                str.focus.giveUp,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.reject(); confirmStop = true
                    }
                    .padding(10.dp),
            )
        }
    }

    // The one press the screen is built around, pinned in the thumb zone.
    // Leaves room on the left for the draggable shield pill when it is shown.
    val pillRoom = if (data.blockedPackages.isNotEmpty()) 84.dp else Paper.ScreenPad
    val bg = MaterialTheme.colorScheme.background
    Column(
        Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .background(Brush.verticalGradient(0f to Color.Transparent, 0.22f to bg, 1f to bg))
            .padding(start = pillRoom, end = Paper.ScreenPad, top = 26.dp, bottom = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AnimatedVisibility(
            visible = !timer.running && !timer.paused && startBlocked != null,
            enter = fadeIn(tween(200)) + expandVertically(tween(200)),
            exit = fadeOut(tween(150)) + shrinkVertically(tween(150)),
        ) {
            Text(
                startBlocked.orEmpty(),
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.accent,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }
        val phase = when { timer.running -> 1; timer.paused -> 2; else -> 0 }
        // Fires only when a session actually starts (0 -> 1). A blocked
        // start never flips phase, so it never celebrates a no-op.
        val burst = remember { Animatable(1f) }
        val lastPhase = remember { intArrayOf(phase) }
        LaunchedEffect(phase) {
            val from = lastPhase[0]; lastPhase[0] = phase
            if (from == 0 && phase == 1) {
                burst.snapTo(0f)
                burst.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
            }
        }
        AnimatedContent(
            targetState = phase,
            transitionSpec = {
                (fadeIn(tween(220)) + scaleIn(tween(220), initialScale = 0.94f)) togetherWith
                    (fadeOut(tween(150)) + scaleOut(tween(150), targetScale = 1.03f))
            },
            label = "cta",
            modifier = Modifier.starBurst { burst.value },
        ) { ph ->
            SquishButton(
                label = when (ph) { 1 -> str.focus.pause; 2 -> str.focus.resume; else -> str.focus.begin },
                sticker = if (ph == 1) Marigold else Jade,
                modifier = Modifier.fillMaxWidth().height(58.dp),
                onClick = { if (!timer.running) haptics.begin(); onToggle() },
            )
        }
        Spacer(Modifier.height(6.dp))
        AnimatedContent(
            targetState = phase,
            transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(150)) },
            label = "ctaLine",
        ) { ph ->
            Text(
                when (ph) {
                    1 -> tr("Locked in. Reels can wait.", "लॉक्ड इन। रील्स इंतज़ार करेंगी।")
                    2 -> tr("One more minute beats zero.", "एक मिनट और, ज़ीरो से बेहतर।")
                    else -> tr("Phone down. Timer up.", "फ़ोन नीचे। टाइमर ऊपर।")
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    if (addSubject) {
        NewSubjectDialog(
            existing = data.subjects,
            onSave = { name ->
                // Three is the cap the store already enforces. Dropping the
                // oldest keeps the newest choice working instead of silently
                // ignoring it once the list is full.
                val next = (data.subjects + name).takeLast(3)
                onSubjects(next)
                onSubject(name)
                addSubject = false
            },
            onClose = { addSubject = false },
        )
    }


    if (crownAsk) {
        // A sheet over a scrim, not four lines wedged under the chip row. This
        // is the single tap in the app that arms a lock the app then refuses
        // to undo, and it was being explained in the same visual weight as the
        // caption under a duration button — most of it below the fold.
        FrostScrim {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                // Glass rather than flat paper: a translucent pane, a bright
                // top edge where light would catch, and a sheen falling across
                // it. Every pixel of this is a gradient — Modifier.blur is API
                // 31+ and most of these phones are older, so a real frost would
                // simply not render on the ones that matter.
                Column(
                    Modifier
                        .padding(horizontal = 22.dp)
                        .clip(RoundedCornerShape(26.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color(0xF2FFFBE9),
                                    Color(0xE8F6EBC6),
                                    Color(0xF2FFF6DC),
                                ),
                            ),
                        )
                        .border(
                            width = 2.dp,
                            brush = Brush.verticalGradient(
                                listOf(
                                    Color.White.copy(alpha = 0.85f),
                                    Ink.copy(alpha = 0.55f),
                                    Ink,
                                ),
                            ),
                            shape = RoundedCornerShape(26.dp),
                        )
                        .drawBehind {
                            // The sheen. A pale diagonal band across the upper
                            // third, which is what separates glass from paper
                            // that happens to be see-through.
                            drawRect(
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = 0.55f),
                                        Color.Transparent,
                                    ),
                                    start = Offset(0f, 0f),
                                    end = Offset(size.width * 0.75f, size.height * 0.55f),
                                ),
                            )
                        },
                ) {
                    // A warning band across the top, not a quiet label.
                    //
                    // This dialog looked like every other card in the app: soft
                    // glass, a friendly heading, and a button reading "Let's
                    // begin". Nothing about it said that the next tap starts a
                    // three-hour lock the app will refuse to lift. A first-time
                    // user has no way to know that from the styling, so the
                    // styling has to say it.
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(Tang.fill)
                            .padding(start = 18.dp, end = 10.dp, top = 12.dp, bottom = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "⚠",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Tang.on,
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            str.crown.briefTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Tang.on,
                            modifier = Modifier.weight(1f),
                        )
                        // The way out, in the corner where people look for it.
                        //
                        // Backing out was only ever the small "Not now" line at
                        // the very bottom, under a list long enough to scroll —
                        // so on a short screen the only visible exits were the
                        // tick and the button that arms the lock. A dialog that
                        // is deliberately hard to agree to has to be easy to
                        // leave, or the pressure it creates is the wrong kind.
                        Box(
                            Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    haptics.tick()
                                    crownAsk = false
                                    crownRead = false
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                "✕",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Tang.on,
                            )
                        }
                    }
                    Column(Modifier.padding(20.dp)) {
                        Text(
                            str.focus.crownWarning,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Spacer(Modifier.height(14.dp))

                        // The duration, in its own boxed callout above the
                        // list.
                        //
                        // It is the only line here that costs someone their
                        // evening if they miss it, and it was not on this
                        // screen at all — the brief listed what Crown does and
                        // never said for how long. Someone taps a chip
                        // expecting a setting and finds out it was a
                        // three-hour commitment when it refuses to let them
                        // back down. A bullet among five bullets is not enough
                        // weight for the one fact that changes the decision.
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Tang.fill.copy(alpha = 0.20f))
                                .border(2.dp, Tang.accent, RoundedCornerShape(14.dp))
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                        ) {
                            Text(
                                str.crown.briefLock(FocusLevels.PACT_HOURS),
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                        Spacer(Modifier.height(16.dp))

                        // Numbered, not bulleted. Four identical dots read as a
                        // paragraph chopped into pieces; numbers read as terms
                        // you are agreeing to one at a time, which is what
                        // these are.
                        listOf(
                            str.crown.briefApps,
                            str.crown.briefUninstall,
                            str.crown.briefSettings,
                            str.crown.briefOut,
                        ).forEachIndexed { i, line ->
                            Row(Modifier.padding(bottom = 10.dp)) {
                                Box(
                                    Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(Tang.fill.copy(alpha = 0.30f))
                                        .border(1.5.dp, Tang.accent, CircleShape),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text(
                                        "${i + 1}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Tang.accent,
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    line,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                            }
                        }

                        Spacer(Modifier.height(6.dp))
                        // The tick has to be deliberate, and until it is the
                        // button does nothing.
                        //
                        // Everything above this line is only a warning if it
                        // gets read, and a single primary button lets someone
                        // tap straight past all of it — which on this screen
                        // is the whole failure. One extra tap is a small price
                        // for the person who was about to lock their phone for
                        // three hours by accident.
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    haptics.tick(); crownRead = !crownRead
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier
                                    .size(24.dp)
                                    .clip(RoundedCornerShape(7.dp))
                                    .background(
                                        if (crownRead) Tang.fill else Color.Transparent
                                    )
                                    .border(2.dp, Ink, RoundedCornerShape(7.dp)),
                                contentAlignment = Alignment.Center,
                            ) {
                                if (crownRead) {
                                    Text(
                                        "✓",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Tang.on,
                                    )
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(
                                str.focus.crownConfirm,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                        }

                        Spacer(Modifier.height(12.dp))
                        SquishButton(
                            str.crown.begin,
                            Tang,
                            Modifier.fillMaxWidth(),
                            enabled = crownRead,
                        ) {
                            haptics.press()
                            crownAsk = false
                            crownRead = false
                            if (Admin.isActive(context)) {
                                onCrown(true)
                                onFocusLevel(4)
                                if (!data.crownIntroSeen) cinematic = true
                            } else {
                                // The system dialog is the last step, not the
                                // first. Coming back from it finishes the job
                                // in the effect above.
                                pendingCrown = true
                                runCatching {
                                    context.startActivity(Admin.requestIntent(context))
                                }
                            }
                        }
                        // Always on screen while the button is dead, not only
                        // after someone has tapped it. A dimmed button with no
                        // explanation beside it reads as a broken screen, and
                        // the person most likely to hit that is the first-time
                        // user this whole dialog is written for.
                        if (!crownRead) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                str.focus.crownTickFirst,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Tang.accent,
                                modifier = Modifier.align(Alignment.CenterHorizontally),
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            str.focus.crownDecline,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    haptics.tick()
                                    crownAsk = false
                                    crownRead = false
                                },
                        )
                    }
                }
            }
        }
    }

    dropCrownAsk?.let { targetLevel ->
        // Deliberately plainer than the crownAsk brief above it — arming
        // Crown is the decision worth slowing down for; this is a shorter
        // "are you sure", not a second reading assignment.
        FrostScrim {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(
                    Modifier
                        .padding(horizontal = 28.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(CreamCard)
                        .border(Paper.Outline, Ink, RoundedCornerShape(22.dp))
                        .padding(20.dp),
                ) {
                    Text(
                        tr("Leave Crown?", "क्राउन छोड़ना है?"),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Ink,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        tr("Device admin will be removed too, and the locked settings will open up.", "डिवाइस एडमिन भी हट जाएगा, और जो सेटिंग्स अभी लॉक थीं वे खुल जाएँगी।"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                    )
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SquishButton(
                            tr("Keep it", "रहने दें"),
                            Mint,
                            Modifier.weight(1f),
                        ) {
                            haptics.tick(); dropCrownAsk = null
                        }
                        SquishButton(
                            tr("Yes, remove", "हाँ, हटाएँ"),
                            Tang,
                            Modifier.weight(1f),
                        ) {
                            haptics.press()
                            dropCrownAsk = null
                            onCrown(false)
                            onFocusLevel(targetLevel)
                            Admin.deactivate(context)
                        }
                    }
                }
            }
        }
    }

    if (cinematic) {
        CrownCinematic {
            cinematic = false
            onCrownIntroSeen()
        }
    }

    if (confirmStop) {
        FrostScrim {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = Paper.ScreenPad),
                contentAlignment = Alignment.Center,
            ) {
                // Brutalist alert card (Uiverse 0xnihilism): hard 8dp ink
                // shadow, inked header with a warning block, ruled dividers.
                // Same two actions, same calls as before.
                var shown by remember { mutableStateOf(false) }
                LaunchedEffect(Unit) { shown = true }
                val pop by animateFloatAsState(if (shown) 1f else 0.9f, Motion.bouncy(), label = "alertPop")
                Column(
                    Modifier
                        .fillMaxWidth()
                        .graphicsLayer { scaleX = pop; scaleY = pop }
                        .drawBehind {
                            val d = 8.dp.toPx() * com.momentum.focus.ui.theme.Vibe.shadow
                            drawRect(Ink, Offset(d, d), size)
                        }
                        .background(CreamCard)
                        .border(4.dp, Ink)
                        .padding(20.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(40.dp).background(Ink),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("!", style = MaterialTheme.typography.headlineSmall, color = Tang.fill)
                        }
                        Spacer(Modifier.width(14.dp))
                        Text(
                            str.focus.stopTitle.uppercase(),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                            color = Ink,
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Box(Modifier.fillMaxWidth().height(2.dp).background(Ink))
                    Spacer(Modifier.height(14.dp))
                    Text(
                        str.focus.stopBody,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = Ink,
                    )
                    Spacer(Modifier.height(14.dp))
                    Box(Modifier.fillMaxWidth().height(2.dp).background(Ink))
                    Spacer(Modifier.height(16.dp))
                    SquishButton(
                        label = str.focus.keepGoing,
                        sticker = Mint,
                        modifier = Modifier.fillMaxWidth(),
                    ) { confirmStop = false }
                    Spacer(Modifier.height(12.dp))
                    SquishButton(
                        label = str.focus.stopConfirm,
                        sticker = Tang,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        confirmStop = false
                        onAbandon()
                    }
                }
            }
        }
    }
}
}

enum class BuddyMood { IDLE, FOCUSED, SAD, SECURED }

/**
 * Focus Buddy (from Uiverse kawaii-pass, redrawn in ink): a 54dp face sitting
 * on the ring's edge that mirrors the session. Pure display — reads the mood,
 * changes nothing. Everything animates in the draw phase.
 */
@Composable
internal fun FocusBuddy(mood: BuddyMood, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val low = remember { com.momentum.focus.ui.util.DeviceProfile.isLowEnd(ctx) }
    val face by animateColorAsState(
        when (mood) {
            BuddyMood.IDLE -> Butter.fill
            BuddyMood.FOCUSED -> Sky.fill
            BuddyMood.SAD -> Candy.fill
            BuddyMood.SECURED -> Mint.fill
        }, tween(250), label = "buddyFace",
    )
    // -1 sad .. 0 flat .. 1 big smile
    val smile by animateFloatAsState(
        when (mood) { BuddyMood.IDLE -> 0.35f; BuddyMood.FOCUSED -> 0f; BuddyMood.SAD -> -0.7f; BuddyMood.SECURED -> 1f },
        Motion.bouncy(), label = "buddySmile",
    )
    val squint by animateFloatAsState(if (mood == BuddyMood.FOCUSED) 1f else 0f, tween(220), label = "buddySquint")
    val happy by animateFloatAsState(if (mood == BuddyMood.SECURED) 1f else 0f, tween(240), label = "buddyHappy")
    val pop by animateFloatAsState(if (mood == BuddyMood.SECURED) 1.08f else 1f, Motion.bouncy(), label = "buddyPop")
    // idle blink/twinkle only in the playful look (minimal = no idle motion)
    val loop = if (!low && Vibe.playful) rememberInfiniteTransition(label = "buddy") else null
    // Blink: eyes shut for ~120ms out of every 3.6s.
    val blink = loop?.animateFloat(
        1f, 1f,
        infiniteRepeatable(keyframes {
            durationMillis = 3600
            1f at 3360; 0.1f at 3420; 1f at 3480
        }), label = "blink",
    )
    val twinkle = loop?.animateFloat(0f, 1f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "twinkle")

    Canvas(modifier.size(54.dp).graphicsLayer { scaleX = pop; scaleY = pop }) {
        val r = size.minDimension / 2 - 4.dp.toPx()
        val c = Offset(size.width / 2 - 1.5.dp.toPx(), size.height / 2 - 1.5.dp.toPx())
        val outline = 3.dp.toPx()
        drawCircle(Ink, r, c + Offset(3.dp.toPx(), 3.dp.toPx()))      // hard shadow
        drawCircle(face, r, c)
        drawCircle(Ink, r, c, style = Stroke(outline))

        // eyes
        val eyeY = c.y - r * 0.12f
        val eyeDx = r * 0.36f
        val b = blink?.value ?: 1f
        val eyeH = r * 0.30f * (1f - 0.45f * squint) * b
        val eyeW = r * 0.22f
        listOf(-1f, 1f).forEach { side ->
            val ex = c.x + side * eyeDx
            if (happy < 1f) {
                drawOval(
                    Ink.copy(alpha = 1f - happy),
                    Offset(ex - eyeW / 2, eyeY - eyeH / 2), Size(eyeW, eyeH),
                )
            }
            if (happy > 0f) {   // ^ ^
                drawArc(
                    Ink.copy(alpha = happy), 200f, 140f, false,
                    Offset(ex - eyeW * 0.8f, eyeY - eyeW * 0.4f), Size(eyeW * 1.6f, eyeW * 1.6f),
                    style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round),
                )
            }
            // focused brows, angled in
            if (squint > 0f) {
                drawLine(
                    Ink.copy(alpha = squint),
                    Offset(ex - side * eyeW * 0.9f, eyeY - r * 0.36f),
                    Offset(ex + side * eyeW * 0.6f, eyeY - r * 0.26f),
                    2.5.dp.toPx(), StrokeCap.Round,
                )
            }
        }
        // blush
        drawCircle(Candy.accent.copy(alpha = 0.35f + 0.3f * happy), r * 0.12f, Offset(c.x - r * 0.6f, c.y + r * 0.16f))
        drawCircle(Candy.accent.copy(alpha = 0.35f + 0.3f * happy), r * 0.12f, Offset(c.x + r * 0.6f, c.y + r * 0.16f))
        // mouth: one quadratic curve, smile bends it
        val mw = r * (0.34f + 0.14f * happy)
        val my = c.y + r * 0.36f
        val mouth = Path().apply {
            moveTo(c.x - mw, my)
            quadraticBezierTo(c.x, my + smile * r * 0.42f, c.x + mw, my)
        }
        drawPath(mouth, Ink, style = Stroke(2.8.dp.toPx(), cap = StrokeCap.Round))
        // sparkles when banked
        if (happy > 0f) {
            val t = twinkle?.value ?: 1f
            listOf(Offset(-1.05f, -0.95f), Offset(1.1f, -0.7f), Offset(-1.15f, 0.55f)).forEachIndexed { i, o ->
                val k = happy * (0.6f + 0.4f * if (i % 2 == 0) t else 1f - t)
                val sc = c + Offset(o.x * r, o.y * r)
                val s = 5.dp.toPx() * k
                val star = Path().apply {
                    moveTo(sc.x, sc.y - s); lineTo(sc.x + s * 0.3f, sc.y - s * 0.3f)
                    lineTo(sc.x + s, sc.y); lineTo(sc.x + s * 0.3f, sc.y + s * 0.3f)
                    lineTo(sc.x, sc.y + s); lineTo(sc.x - s * 0.3f, sc.y + s * 0.3f)
                    lineTo(sc.x - s, sc.y); lineTo(sc.x - s * 0.3f, sc.y - s * 0.3f); close()
                }
                drawPath(star, Butter.fill)
                drawPath(star, Ink, style = Stroke(1.5.dp.toPx()))
            }
        }
    }
}

/**
 * Star burst (from Uiverse star button): eight ink-outlined stars fly out of
 * the node and fade. [t] runs 0 -> 1 once; at 1 nothing is drawn.
 */
private fun Modifier.starBurst(t: () -> Float): Modifier = drawWithContent {
    drawContent()
    val k = t()
    if (k >= 1f) return@drawWithContent
    val c = center
    val reach = size.width / 2 + 28.dp.toPx()
    for (i in 0 until 8) {
        val a = Math.toRadians(i * 45.0 - 90.0 + 22.5)
        val d = (size.height / 2) + (reach - size.height / 2) * k
        // stretch horizontally so stars clear the wide button's sides too
        val p = c + Offset((kotlin.math.cos(a) * d).toFloat(), (kotlin.math.sin(a) * d * 0.55).toFloat())
        val s = 7.dp.toPx() * (1f - k * 0.6f)
        val alpha = 1f - k
        val star = Path().apply {
            moveTo(p.x, p.y - s); lineTo(p.x + s * 0.3f, p.y - s * 0.3f)
            lineTo(p.x + s, p.y); lineTo(p.x + s * 0.3f, p.y + s * 0.3f)
            lineTo(p.x, p.y + s); lineTo(p.x - s * 0.3f, p.y + s * 0.3f)
            lineTo(p.x - s, p.y); lineTo(p.x - s * 0.3f, p.y - s * 0.3f); close()
        }
        drawPath(star, (if (i % 2 == 0) Butter.fill else Mint.fill).copy(alpha = alpha))
        drawPath(star, Ink.copy(alpha = alpha), style = Stroke(1.8.dp.toPx()))
    }
}

/**
 * Duration wheel (from Uiverse wheel selector, as an ink ruler): drag
 * sideways, snaps to 5 min, 15..180. Replaces the Material slider in custom.
 */
@Composable
private fun DurationWheel(
    value: Int,
    onValue: (Int) -> Unit,
    onSettle: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    val stepPx = with(LocalDensity.current) { 14.dp.toPx() }   // px per 5 min
    var pos by remember { mutableFloatStateOf(value.toFloat()) }
    val bg = MaterialTheme.colorScheme.background
    val drag = rememberDraggableState { dx ->
        pos = (pos - dx / stepPx * 5f).coerceIn(15f, 180f)
        onValue(((pos / 5f).roundToInt() * 5).coerceIn(15, 180))
    }
    val shape = RoundedCornerShape(Paper.ChipRadius)
    Canvas(
        modifier
            .height(56.dp)
            .drawBehind {
                val d = 3.dp.toPx() * com.momentum.focus.ui.theme.Vibe.shadow
                drawRoundRect(Ink, Offset(d, d), size, CornerRadius(Paper.ChipRadius.toPx()))
            }
            .clip(shape)
            .background(CreamCard)
            .border(Paper.Outline, Ink, shape)
            .draggable(
                drag, Orientation.Horizontal,
                onDragStopped = {
                    val target = ((pos / 5f).roundToInt() * 5f).coerceIn(15f, 180f)
                    scope.launch {
                        androidx.compose.animation.core.animate(pos, target, animationSpec = Motion.press()) { v, _ -> pos = v }
                        onSettle()
                    }
                },
            ),
    ) {
        val cx = size.width / 2
        var m = 15
        while (m <= 180) {
            val x = cx + (m - pos) / 5f * stepPx
            if (x > -stepPx && x < size.width + stepPx) {
                val major = m % 15 == 0
                val h = if (major) size.height * 0.42f else size.height * 0.24f
                drawLine(
                    Ink.copy(alpha = if (major) 0.9f else 0.45f),
                    Offset(x, size.height - 8.dp.toPx() - h), Offset(x, size.height - 8.dp.toPx()),
                    if (major) 3.dp.toPx() else 2.dp.toPx(), StrokeCap.Round,
                )
            }
            m += 5
        }
        // edge fade so the ruler reads as curving away, like the wheel
        val fade = size.width * 0.18f
        drawRect(Brush.horizontalGradient(listOf(CreamCard, CreamCard.copy(alpha = 0f)), 0f, fade), size = Size(fade, size.height))
        drawRect(
            Brush.horizontalGradient(listOf(CreamCard.copy(alpha = 0f), CreamCard), size.width - fade, size.width),
            topLeft = Offset(size.width - fade, 0f), size = Size(fade, size.height),
        )
        // centre pointer: Lilac block with ink outline
        val pw = 6.dp.toPx()
        drawRoundRect(Lilac.fill, Offset(cx - pw / 2, 6.dp.toPx()), Size(pw, size.height - 12.dp.toPx()), CornerRadius(pw / 2))
        drawRoundRect(Ink, Offset(cx - pw / 2, 6.dp.toPx()), Size(pw, size.height - 12.dp.toPx()), CornerRadius(pw / 2), style = Stroke(2.dp.toPx()))
        val tri = Path().apply {
            moveTo(cx - 7.dp.toPx(), 0f); lineTo(cx + 7.dp.toPx(), 0f); lineTo(cx, 8.dp.toPx()); close()
        }
        drawPath(tri, Ink)
    }
}

@Composable
private fun DeepFocusPill(onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(Ink)
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Lock, contentDescription = null, tint = Butter.fill, modifier = Modifier.size(13.dp))
        Spacer(Modifier.width(6.dp))
        Text(tr("Deep focus", "डीप फ़ोकस"), fontSize = 12.sp, fontWeight = FontWeight.Black, color = Butter.fill)
    }
}

@Composable
private fun DeepFocusSheet(
    pactLive: Boolean,
    crownOn: Boolean,
    guardOn: Boolean,
    onCrown: () -> Unit,
    onGuard: () -> Unit,
    onClose: () -> Unit,
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onClose) {
        var shown by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) { shown = true }
        val rise by animateFloatAsState(if (shown) 1f else 0f, Motion.bouncy(), label = "deepRise")
        Column(
            Modifier
                .fillMaxWidth()
                .graphicsLayer { translationY = (1f - rise) * 60.dp.toPx(); alpha = rise }
                .drawBehind {
                    val d = 6.dp.toPx() * com.momentum.focus.ui.theme.Vibe.shadow
                    drawRoundRect(Ink, Offset(d, d), size, CornerRadius(22.dp.toPx()))
                }
                .clip(RoundedCornerShape(22.dp))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(22.dp))
                .padding(18.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Deep focus", "डीप फ़ोकस"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, color = Ink, modifier = Modifier.weight(1f))
                Text(
                    "✕", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Ink,
                    modifier = Modifier.clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClose).padding(6.dp),
                )
            }
            Spacer(Modifier.height(12.dp))
            DeepRow(
                tr("Strict mode", "स्ट्रिक्ट मोड"),
                if (pactLive) tr("Pact is live — no quitting early, rules only tighten.", "पैक्ट चालू — बीच में नहीं छोड़ सकते, नियम सिर्फ़ सख़्त होंगे।")
                else tr("Pick a locking level below to arm a pact before you start.", "शुरू करने से पहले नीचे लॉक वाला लेवल चुनें।"),
                pactLive, null,
            )
            DeepRow(
                tr("Uninstall protection", "अनइंस्टॉल सुरक्षा"),
                tr("Crown: Momentum can't be removed mid-pact.", "क्राउन: पैक्ट के बीच Momentum हटाया नहीं जा सकता।"),
                crownOn, if (crownOn) null else onCrown,
            )
            DeepRow(
                tr("Shorts & Reels block", "शॉर्ट्स और रील्स ब्लॉक"),
                if (guardOn) tr("Feeds you switched off stay off.", "बंद की गई फ़ीड बंद रहेंगी।")
                else tr("Needs Accessibility on — tap to turn on.", "Accessibility चालू करनी होगी — टैप करें।"),
                guardOn, if (guardOn) null else onGuard,
            )
        }
    }
}

@Composable
private fun DeepRow(title: String, body: String, on: Boolean, onClick: (() -> Unit)?) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (on) Mint.fill.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.6f))
            .border(2.dp, Ink, RoundedCornerShape(14.dp))
            .then(if (onClick != null) Modifier.clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick) else Modifier)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = Ink)
            Text(body, style = MaterialTheme.typography.bodySmall, color = InkMid)
        }
        Spacer(Modifier.width(10.dp))
        Text(
            if (on) tr("ON", "चालू") else if (onClick != null) tr("TURN ON", "चालू करें") else tr("OFF", "बंद"),
            fontSize = 11.sp, fontWeight = FontWeight.Black, color = Ink,
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(if (on) Mint.fill else if (onClick != null) Butter.fill else Color(0xFFE9E3CF))
                .border(2.dp, Ink, RoundedCornerShape(999.dp))
                .padding(horizontal = 9.dp, vertical = 4.dp),
        )
    }
}

/**
 * Earn-secured bar (Uiverse striped progress, in ink): hatched Tang fill that
 * flips to Jade once the session is banked. Read-only — never touches timer.
 */
@Composable
private fun BankBar(progress: Float, secured: Boolean, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val low = remember { com.momentum.focus.ui.util.DeviceProfile.isLowEnd(ctx) }
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(240), label = "bank")
    val fill by animateColorAsState(if (secured) Jade.fill else Tang.fill, tween(250), label = "bankFill")
    val drift = if (!secured && !low) {
        rememberInfiniteTransition(label = "hatch").animateFloat(
            0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "hatchT",
        )
    } else null
    val shape = RoundedCornerShape(999.dp)
    Box(
        modifier
            .fillMaxWidth()
            .height(18.dp)
            .drawBehind {
                val d = 3.dp.toPx() * com.momentum.focus.ui.theme.Vibe.shadow
                drawRoundRect(Ink, Offset(d, d), size, CornerRadius(size.height / 2))
            }
            .clip(shape)
            .background(CreamCard)
            .drawBehind {
                val w = size.width * p
                if (w <= 0f) return@drawBehind
                clipRect(right = w) {
                    drawRect(fill)
                    val gap = 10.dp.toPx()
                    // drift read here only = draw-phase, zero recomposition
                    var x = -size.height - gap + (drift?.value ?: 0f) * gap
                    while (x < w + gap) {
                        drawLine(
                            Ink.copy(alpha = 0.18f),
                            Offset(x, size.height), Offset(x + size.height, 0f),
                            3.5.dp.toPx(),
                        )
                        x += gap
                    }
                    drawLine(Ink, Offset(w, 0f), Offset(w, size.height), 2.dp.toPx())
                }
            }
            .border(Paper.Outline, Ink, shape),
    )
}

@Composable
private fun TimerRing(progress: Float, label: String, running: Boolean, paused: Boolean = false) {
    val str = strings()
    val animated by animateFloatAsState(progress, Motion.settle(), label = "p")
    val track = MaterialTheme.colorScheme.surfaceVariant
    // The filled arc is the single element most looked at in the app, so it is
    // where a skin earns its keep. The track, the outline and the cream behind
    // it are untouched — a theme changes the accent, not the paper.
    // Now follows the session instead: orange at the start, gold mid-way,
    // mint as it lands — the same ramp as every progress bar in the app.
    val arcColor = com.momentum.focus.ui.components.progressColor(animated)

    // A halo outside the ring while the clock is running. Not glowEdge — that
    // draws on a shape's border and this is a circle drawn by hand — but the
    // same idea and the same rule: it appears only while something is actually
    // happening, so it never becomes decoration.
    val breath = rememberInfiniteTransition(label = "ring")
    val pulse = breath.animateFloat(
        initialValue = 0.30f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(tween(1500), RepeatMode.Reverse),
        label = "ringglow",
    )

    // Settles in when the clock starts, eases back when it stops. 240ms, no bounce.
    val ringScale by animateFloatAsState(if (running) 1f else 0.96f, tween(240), label = "ringScale")
    Box(
        Modifier.size(250.dp).graphicsLayer { scaleX = ringScale; scaleY = ringScale },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 22.dp.toPx()
            if (running) {
                val p = pulse.value
                val ringSize = Size(size.width - stroke, size.height - stroke)
                val tl = Offset(stroke / 2, stroke / 2)
                listOf(6.dp to 0.42f, 14.dp to 0.20f).forEach { halo ->
                    val out = halo.first.toPx()
                    drawArc(
                        arcColor.copy(alpha = halo.second * p),
                        -90f,
                        360f,
                        false,
                        Offset(tl.x - out, tl.y - out),
                        Size(ringSize.width + out * 2, ringSize.height + out * 2),
                        style = Stroke(3.dp.toPx(), cap = StrokeCap.Round),
                    )
                }
            }
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(stroke / 2, stroke / 2)
            drawArc(track, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(Ink, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke + 6f, cap = StrokeCap.Round))
            drawArc(track, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
            // Watch-dial: 60 minute ticks inside the track, every fifth longer;
            // passed ticks take the progress colour.
            run {
                val c = Offset(size.width / 2, size.height / 2)
                val rOut = arcSize.width / 2 - stroke / 2 - 8.dp.toPx()
                for (i in 0 until 60) {
                    val major = i % 5 == 0
                    val ang = Math.toRadians(-90.0 + i * 6.0)
                    val len = (if (major) 9f else 4.5f).dp.toPx()
                    val cs = kotlin.math.cos(ang).toFloat(); val sn = kotlin.math.sin(ang).toFloat()
                    val passed = i / 60f <= animated && animated > 0f
                    drawLine(
                        if (passed) arcColor else Ink.copy(alpha = if (major) 0.45f else 0.18f),
                        Offset(c.x + cs * rOut, c.y + sn * rOut),
                        Offset(c.x + cs * (rOut - len), c.y + sn * (rOut - len)),
                        (if (major) 2.5f else 1.5f).dp.toPx(),
                        StrokeCap.Round,
                    )
                }
            }
            // Bloom along the filled arc only — light coming off the progress.
            if (animated > 0f) {
                for (k in 1..5) {
                    drawArc(
                        arcColor.copy(alpha = 0.10f * (1f - k / 6f)),
                        -90f, 360f * animated, false, topLeft, arcSize,
                        style = Stroke(stroke + k * 7.dp.toPx(), cap = StrokeCap.Round),
                    )
                }
            }
            drawArc(Ink, -90f, 360f * animated, false, topLeft, arcSize,
                style = Stroke(stroke + 6f, cap = StrokeCap.Round))
            drawArc(arcColor, -90f, 360f * animated, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
            // White-hot head where the arc is growing.
            if (animated > 0.01f) {
                val ang = Math.toRadians((-90.0 + 360.0 * animated))
                val rr = arcSize.width / 2
                val hc = Offset(size.width / 2 + (rr * kotlin.math.cos(ang)).toFloat(), size.height / 2 + (rr * kotlin.math.sin(ang)).toFloat())
                drawCircle(Color.White.copy(alpha = 0.85f), stroke * 0.28f, hc)
                drawCircle(arcColor.copy(alpha = 0.35f), stroke * 0.6f, hc)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                label,
                style = MaterialTheme.typography.displayMedium,
                color = Ink,
            )
            AnimatedContent(
                targetState = when {
                    running -> str.focus.inSession
                    paused -> tr("PAUSED", "रुका है")
                    else -> str.focus.ready
                },
                transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(150)) },
                label = "ringState",
            ) { word ->
                Text(
                    word,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (running) LocalSkin.current.accent else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun Chip(
    text: String,
    selected: Boolean,
    sticker: Sticker,
    /** Small locks under the label — one per step of strictness. 0 hides them. */
    locks: Int = 0,
    /** Still tappable, so the tap can explain itself instead of doing nothing. */
    dimmed: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    // Keycap (owner's macro-pad reference): every chip is a chunky key.
    // Unchosen keys are a pastel of their own colour instead of grey, so a
    // row reads like the coloured keypad; the chosen key is full colour and
    // sits taller. Press = the cap travels down its own wall.
    val bg = if (selected) sticker.fill else lerp(sticker.fill, Color.White, 0.62f)
    val fg = if (selected) sticker.on else Ink
    val shape = RoundedCornerShape(Paper.ChipRadius)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 1f else 0f, Motion.press(), label = "chipPress")
    val wall = if (selected) 6.dp else 4.dp
    val wallColor = lerp(bg, Color.Black, 0.28f)
    Column(
        modifier
            .padding(bottom = wall)
            .alpha(if (dimmed) 0.42f else 1f)
            .drawBehind {
                // the key's side wall, fixed; the cap moves, the wall doesn't
                val w = wall.toPx()
                val cr = CornerRadius(Paper.ChipRadius.toPx(), Paper.ChipRadius.toPx())
                drawRoundRect(wallColor, Offset(0f, w), size, cr)
                drawRoundRect(Ink, Offset(0f, w), size, cr, style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
            }
            .graphicsLayer { translationY = wall.toPx() * press }
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(lerp(bg, Color.White, 0.25f), bg),
                ),
            )
            .drawBehind {
                // dished top, like a real keycap: a softer inset face
                val inset = 3.dp.toPx()
                drawRoundRect(
                    Brush.radialGradient(
                        listOf(lerp(bg, Color.White, 0.35f), bg),
                        center = Offset(size.width / 2, size.height * 0.35f),
                        radius = size.maxDimension * 0.7f,
                    ),
                    Offset(inset, inset),
                    androidx.compose.ui.geometry.Size(size.width - inset * 2, size.height - inset * 2.6f),
                    CornerRadius(Paper.ChipRadius.toPx() * 0.7f),
                )
            }
            .border(2.dp, Ink, shape)
            .clickableNoRipple(interaction, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(text, style = MaterialTheme.typography.titleMedium, color = fg)
        if (locks > 0) {
            Spacer(Modifier.height(3.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                repeat(locks) {
                    Icon(
                        Icons.Filled.Lock,
                        // Decorative: the label names the level and the line
                        // under the row already says what it does, so a
                        // screen reader announcing "lock" three times would
                        // only add noise.
                        contentDescription = null,
                        tint = fg,
                        modifier = Modifier.size(10.dp),
                    )
                }
            }
        }
    }
}


/** Names a subject without leaving the screen someone is about to start on. */
@Composable
private fun NewSubjectDialog(
    existing: List<String>,
    onSave: (String) -> Unit,
    onClose: () -> Unit,
) {
    var text by remember { mutableStateOf("") }
    val clean = text.trim()
    val dupe = existing.any { it.equals(clean, ignoreCase = true) }

    val str = strings()
    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(18.dp),
        ) {
            Text(
                str.focus.newSubjectTitle,
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(18) },
                placeholder = { Text(str.focus.newSubjectHint) },
                singleLine = true,
                isError = dupe,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )
            if (existing.size >= 3) {
                Spacer(Modifier.height(8.dp))
                Text(
                    str.focus.threeMax(existing.first()),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }
            if (dupe) {
                Spacer(Modifier.height(8.dp))
                Text(
                    str.focus.duplicateName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClose)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        str.common.cancel,
                        style = MaterialTheme.typography.titleMedium,
                        color = Ink,
                    )
                }
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Jade.fill)
                        .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(
                            remember { MutableInteractionSource() },
                            enabled = clean.isNotBlank() && !dupe,
                        ) { onSave(clean) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        str.common.save,
                        style = MaterialTheme.typography.titleMedium,
                        color = Jade.on,
                    )
                }
            }
        }
    }
}
