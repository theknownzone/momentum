package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import kotlin.math.sin

/**
 * A small, believable thermal printer rather than a flat mascot icon.
 *
 * The machine has a separate lid, paper slot, feed roller, front controls,
 * ventilation detail and a real status LED. During the unlock sequence the LED
 * changes state and the roller marks move, so the printer itself communicates
 * that it is powered, feeding and finished.
 */
@Composable
fun PrinterMark(
    size: Dp = 64.dp,
    tint: Color = Color(0xFF3FE28F),
    modifier: Modifier = Modifier,
    powered: Boolean = true,
    printing: Boolean = false,
    paperFeed: Float = 0f,
) {
    val transition = rememberInfiniteTransition(label = "printer")
    val roller = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(520, easing = LinearEasing)),
        label = "roller",
    )
    val ledPulse = transition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "led",
    )
    Canvas(modifier.size(size)) {
        drawPrinterMark(
            tint = tint,
            powered = powered,
            printing = printing,
            paperFeed = paperFeed,
            rollerPhase = roller.value,
            ledPulse = ledPulse.value,
        )
    }
}

private fun DrawScope.drawPrinterMark(
    tint: Color,
    powered: Boolean,
    printing: Boolean,
    paperFeed: Float,
    rollerPhase: Float,
    ledPulse: Float,
) {
    val w = size.width
    val h = size.height
    val stroke = (w * 0.014f).coerceAtLeast(1.5f)
    val bodyX = w * 0.09f
    val bodyY = h * 0.29f
    val bodyW = w * 0.82f
    val bodyH = h * 0.56f
    val radius = w * 0.075f

    // Contact shadow: tight and offset, so the machine sits on the scene.
    drawRoundRect(
        color = Color.Black.copy(alpha = 0.42f),
        topLeft = Offset(bodyX + w * 0.018f, bodyY + h * 0.028f),
        size = Size(bodyW, bodyH),
        cornerRadius = CornerRadius(radius, radius),
    )

    // Main shell. The highlight is asymmetric like molded plastic, not a flat
    // two-colour sticker.
    drawRoundRect(
        brush = Brush.linearGradient(
            colors = listOf(
                Color(0xFFF8FFF9),
                Color(0xFFDDE7E1),
                Color(0xFFB8C8BF),
            ),
            start = Offset(bodyX, bodyY),
            end = Offset(bodyX + bodyW, bodyY + bodyH),
        ),
        topLeft = Offset(bodyX, bodyY),
        size = Size(bodyW, bodyH),
        cornerRadius = CornerRadius(radius, radius),
    )
    drawRoundRect(
        color = Color(0xFF18221D),
        topLeft = Offset(bodyX, bodyY),
        size = Size(bodyW, bodyH),
        cornerRadius = CornerRadius(radius, radius),
        style = Stroke(width = stroke),
    )

    // Raised top lid.
    val lidX = bodyX + bodyW * 0.05f
    val lidY = bodyY - h * 0.055f
    val lidW = bodyW * 0.90f
    val lidH = h * 0.18f
    drawRoundRect(
        brush = Brush.verticalGradient(
            listOf(Color(0xFFFFFFFF), Color(0xFFDCE7E0), Color(0xFFBFCBC4)),
        ),
        topLeft = Offset(lidX, lidY),
        size = Size(lidW, lidH),
        cornerRadius = CornerRadius(radius * 0.75f, radius * 0.75f),
    )
    drawRoundRect(
        color = Color(0xFF18221D),
        topLeft = Offset(lidX, lidY),
        size = Size(lidW, lidH),
        cornerRadius = CornerRadius(radius * 0.75f, radius * 0.75f),
        style = Stroke(width = stroke),
    )

    // Paper slot: recessed black channel with a cylindrical roller visible
    // through it. The little moving highlights are what make this read as a
    // printer instead of a generic box.
    val slotX = bodyX + bodyW * 0.17f
    val slotY = bodyY + bodyH * 0.02f
    val slotW = bodyW * 0.66f
    val slotH = h * 0.075f
    drawRoundRect(
        color = Color(0xFF0A0E0C),
        topLeft = Offset(slotX, slotY),
        size = Size(slotW, slotH),
        cornerRadius = CornerRadius(slotH * 0.5f, slotH * 0.5f),
    )
    drawRoundRect(
        color = Color(0xFF3B4740),
        topLeft = Offset(slotX + slotW * 0.06f, slotY + slotH * 0.23f),
        size = Size(slotW * 0.88f, slotH * 0.54f),
        cornerRadius = CornerRadius(slotH * 0.25f, slotH * 0.25f),
    )
    val rollerX = slotX + slotW * (0.18f + 0.64f * rollerPhase)
    if (printing) {
        drawRoundRect(
            color = tint.copy(alpha = 0.42f),
            topLeft = Offset(rollerX, slotY + slotH * 0.27f),
            size = Size(slotW * 0.11f, slotH * 0.46f),
            cornerRadius = CornerRadius(slotH * 0.18f, slotH * 0.18f),
        )
    }

    // Front information panel.
    val panelX = bodyX + bodyW * 0.13f
    val panelY = bodyY + bodyH * 0.22f
    val panelW = bodyW * 0.74f
    val panelH = bodyH * 0.25f
    drawRoundRect(
        color = Color(0xFF1B2420),
        topLeft = Offset(panelX, panelY),
        size = Size(panelW, panelH),
        cornerRadius = CornerRadius(radius * 0.45f, radius * 0.45f),
    )
    drawRoundRect(
        brush = Brush.horizontalGradient(
            listOf(
                tint.copy(alpha = if (powered) 0.32f else 0.10f),
                Color.White.copy(alpha = 0.06f),
                Color.Transparent,
            ),
        ),
        topLeft = Offset(panelX, panelY),
        size = Size(panelW, panelH),
        cornerRadius = CornerRadius(radius * 0.45f, radius * 0.45f),
    )
    drawRoundRect(
        color = Color(0xFF111713),
        topLeft = Offset(panelX, panelY),
        size = Size(panelW, panelH),
        cornerRadius = CornerRadius(radius * 0.45f, radius * 0.45f),
        style = Stroke(width = stroke * 0.8f),
    )

    // Tiny status bars / paper indicator.
    val barY = panelY + panelH * 0.62f
    repeat(5) { i ->
        val lit = powered && (printing || i < 3)
        drawRoundRect(
            color = if (lit) tint.copy(alpha = 0.75f) else Color.White.copy(alpha = 0.16f),
            topLeft = Offset(panelX + panelW * (0.12f + i * 0.12f), barY),
            size = Size(panelW * 0.075f, panelH * 0.07f),
            cornerRadius = CornerRadius(2f, 2f),
        )
    }

    // Mechanical front lip.
    val lipY = bodyY + bodyH * 0.62f
    drawRoundRect(
        color = Color(0xFFCBD6D0),
        topLeft = Offset(bodyX + bodyW * 0.08f, lipY),
        size = Size(bodyW * 0.84f, bodyH * 0.16f),
        cornerRadius = CornerRadius(radius * 0.35f, radius * 0.35f),
    )
    drawRoundRect(
        color = Color(0xFF65736B),
        topLeft = Offset(bodyX + bodyW * 0.08f, lipY),
        size = Size(bodyW * 0.84f, bodyH * 0.16f),
        cornerRadius = CornerRadius(radius * 0.35f, radius * 0.35f),
        style = Stroke(width = stroke * 0.7f),
    )

    // Power LED: off, breathing, or steady green when the job is done.
    val ledCenter = Offset(bodyX + bodyW * 0.84f, bodyY + bodyH * 0.80f)
    val ledAlpha = when {
        !powered -> 0.10f
        printing -> 0.55f + 0.35f * ledPulse
        else -> 0.98f
    }
    if (powered) {
        drawCircle(
            color = tint.copy(alpha = ledAlpha * 0.22f),
            radius = w * 0.065f,
            center = ledCenter,
        )
    }
    drawCircle(
        color = if (powered) tint.copy(alpha = ledAlpha) else Color(0xFF59625D),
        radius = w * 0.028f,
        center = ledCenter,
    )
    drawCircle(
        color = Color(0xFF111713),
        radius = w * 0.030f,
        center = ledCenter,
        style = Stroke(width = stroke * 0.65f),
    )

    // Physical power button and a tiny service light.
    drawCircle(
        color = Color(0xFF52615A),
        radius = w * 0.035f,
        center = Offset(bodyX + bodyW * 0.16f, bodyY + bodyH * 0.80f),
    )
    drawCircle(
        color = Color.White.copy(alpha = 0.50f),
        radius = w * 0.010f,
        center = Offset(bodyX + bodyW * 0.16f, bodyY + bodyH * 0.80f),
    )

    // Feed motion line. It is subtle; the paper itself remains the hero.
    if (printing) {
        val wobble = sin((paperFeed * 18f + rollerPhase * 6f)) * w * 0.006f
        drawLine(
            color = tint.copy(alpha = 0.45f),
            start = Offset(bodyX + bodyW * 0.38f + wobble, bodyY + bodyH * 0.73f),
            end = Offset(bodyX + bodyW * 0.62f + wobble, bodyY + bodyH * 0.73f),
            strokeWidth = stroke,
        )
    }
}
