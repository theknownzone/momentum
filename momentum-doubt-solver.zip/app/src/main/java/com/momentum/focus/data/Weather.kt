package com.momentum.focus.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

enum class WeatherCondition { RAIN, SNOW, SUN, CLOUD }

data class WeatherSnapshot(val condition: WeatherCondition, val tempC: Int)

/**
 * One weather check, synced once and then left alone — same shape the person
 * asked for: it runs, it settles, the Hero goes back to being whatever skin
 * they actually picked.
 *
 * No GPS, no location permission dialog: an IP-based lookup (ipapi.co, free,
 * no key) gives a city-level position, which is all a "looks like rain
 * today" accent needs and is nowhere near precise enough to be worth asking
 * permission for. Cached for [CACHE_HOURS] so opening Home five times in a
 * morning is one network round trip, not five — the same "check once, then
 * leave it" shape [ExamNews] already uses. Same failure rule too: if either
 * call fails, [sync] returns null and the Hero simply shows no badge that
 * run, never a stale or a fake condition.
 */
object Weather {
    private const val PREFS = "weather_sync"
    private const val KEY_CONDITION = "condition"
    private const val KEY_TEMP = "temp"
    private const val KEY_AT = "at"
    private const val CACHE_HOURS = 6L

    private fun cached(context: Context): WeatherSnapshot? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val at = prefs.getLong(KEY_AT, 0L)
        if (at == 0L || System.currentTimeMillis() - at > CACHE_HOURS * 3_600_000L) return null
        val name = prefs.getString(KEY_CONDITION, null) ?: return null
        val condition = runCatching { WeatherCondition.valueOf(name) }.getOrNull() ?: return null
        return WeatherSnapshot(condition, prefs.getInt(KEY_TEMP, 20))
    }

    suspend fun sync(context: Context): WeatherSnapshot? = withContext(Dispatchers.IO) {
        cached(context)?.let { return@withContext it }
        val snapshot = runCatching {
            val geo = JSONObject(get("https://ipapi.co/json/"))
            val lat = geo.getDouble("latitude")
            val lon = geo.getDouble("longitude")
            val url = "https://api.open-meteo.com/v1/forecast" +
                "?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code"
            val current = JSONObject(get(url)).getJSONObject("current")
            val code = current.getInt("weather_code")
            val temp = current.getDouble("temperature_2m").toInt()
            WeatherSnapshot(codeToCondition(code, temp), temp)
        }.getOrNull() ?: return@withContext null

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_CONDITION, snapshot.condition.name)
            .putInt(KEY_TEMP, snapshot.tempC)
            .putLong(KEY_AT, System.currentTimeMillis())
            .apply()
        snapshot
    }

    private fun get(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 5000
            readTimeout = 5000
            requestMethod = "GET"
        }
        return try {
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    // WMO weather codes (what Open-Meteo returns), collapsed to four buckets
    // — a decorative badge needs "which of four" right, not the exact code.
    private fun codeToCondition(code: Int, tempC: Int): WeatherCondition = when {
        code in 71..77 || code in 85..86 -> WeatherCondition.SNOW
        code in 51..67 || code in 80..82 || code in 95..99 -> WeatherCondition.RAIN
        code in 45..48 || code in 2..3 -> WeatherCondition.CLOUD
        code <= 1 && tempC >= 26 -> WeatherCondition.SUN
        else -> WeatherCondition.CLOUD
    }
}
