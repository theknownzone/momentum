package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

@Composable
fun GhostTypography(
    word: String,
    modifier: Modifier = Modifier
) {
    val textMeasurer: TextMeasurer = rememberTextMeasurer()

    Canvas(modifier = modifier.fillMaxSize()) {
        val style = TextStyle(
            color = Color.White.copy(alpha = 0.065f),
            fontSize = 82.sp,
            fontWeight = FontWeight.Black
        )
        val measured = textMeasurer.measure(word, style)
        val x = (size.width - measured.size.width) / 2f
        val y = size.height * 0.30f

        drawText(
            textLayoutResult = measured,
            topLeft = Offset(x, y)
        )

        val nodes = listOf(
            Offset(size.width * 0.12f, size.height * 0.24f),
            Offset(size.width * 0.30f, size.height * 0.18f),
            Offset(size.width * 0.52f, size.height * 0.25f),
            Offset(size.width * 0.74f, size.height * 0.17f),
            Offset(size.width * 0.90f, size.height * 0.29f),
            Offset(size.width * 0.20f, size.height * 0.47f),
            Offset(size.width * 0.46f, size.height * 0.42f),
            Offset(size.width * 0.78f, size.height * 0.46f)
        )

        val links = listOf(
            0 to 1, 1 to 2, 2 to 3, 3 to 4,
            0 to 5, 5 to 6, 6 to 7, 3 to 7
        )

        links.forEach { (a, b) ->
            val path = Path().apply {
                moveTo(nodes[a].x, nodes[a].y)
                lineTo(nodes[b].x, nodes[b].y)
            }
            drawPath(
                path = path,
                color = Color(0xFF8FD3FF).copy(alpha = 0.12f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1f)
            )
        }

        nodes.forEach {
            drawCircle(
                color = Color(0xFFBFE8FF).copy(alpha = 0.14f),
                radius = 2.2f,
                center = it
            )
        }
    }
}