package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.R
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Tang
import kotlinx.coroutines.delay
import java.time.LocalDate

/** The rungs. Each one is a day count and what reaching it is worth. */
private val RUNGS = listOf(7, 14, 30, 60, 90)

/**
 * The eight frames of a real flicker, not a shape drawn once and left
 * still. This was a hand-drawn [TileObject] flame for a long time — flat,
 * static, and the one thing on this card that never actually looked lit.
 * These came from a short reference clip on a solid pink background,
 * chroma-keyed to transparent and cropped to a shared bounding box so the
 * flame flickers in place instead of drifting frame to frame.
 */
private val FLAME_FRAMES = listOf(
    R.drawable.streak_flame_00,
    R.drawable.streak_flame_01,
    R.drawable.streak_flame_02,
    R.drawable.streak_flame_03,
    R.drawable.streak_flame_04,
    R.drawable.streak_flame_05,
    R.drawable.streak_flame_06,
    R.drawable.streak_flame_07,
)

/** A small looping flip-book, not a video view — eight PNGs are cheap to hold
 * in memory and swapping [painterResource] on a timer needs nothing else.
 */
@Composable
fun AnimatedFlame(size: Dp, modifier: Modifier = Modifier) {
    var frame by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(90)
            frame = (frame + 1) % FLAME_FRAMES.size
        }
    }
    Image(
        painter = painterResource(FLAME_FRAMES[frame]),
        contentDescription = null,
        modifier = modifier.size(size),
    )
}

/**
 * The streak, and what it is climbing towards.
 *
 * The number on its own answers "how long" and nothing else. A streak is a
 * thing you keep going, so the question it actually raises is "until what" —
 * and the app had no answer anywhere on any screen. Seven days of ticks show
 * the week just gone; the ladder underneath shows the next rung and how far
 * off it is.
 *
 * Rungs are days, not rewards, because nothing is handed out for them. Saying
 * a number is coming and then not paying it would be worse than saying
 * nothing; what a rung buys is the fact of having got there.
 */
@Composable
fun StreakLadder(data: AppData, modifier: Modifier = Modifier) {
    val str = strings()
    val shape = RoundedCornerShape(Paper.CardRadius)
    val streak = data.streakDays
    val next = RUNGS.firstOrNull { it > streak }

    // Dark, not the cream-and-ink paper every other card on this screen
    // uses. That was a deliberate rule for a long time — dark surfaces
    // reserved for paid screens, so the one place that glowed meant
    // something. The reference widgets this was built from are dark
    // because a flame reads as lit against black in a way it never does
    // on cream, no matter how good the glow underneath it is; the streak
    // is the one free feature worth breaking the rule for.
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Ink)
            .border(1.2.dp, Color.White.copy(alpha = 0.10f), shape)
            .drawBehind {
                val r = size.width * 0.55f
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Tang.fill.copy(alpha = 0.16f), Color.Transparent),
                        center = Offset(size.width * 0.18f, 0f),
                        radius = r,
                    ),
                    radius = r,
                    center = Offset(size.width * 0.18f, 0f),
                )
            }
            .padding(16.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // The flame in its own small dark tile rather than floating
            // loose on the card — the same "icon gets a housing" move the
            // reference widget makes, and it is what stops the glow from
            // just bleeding into the card's own background with nothing to
            // frame it.
            Box(
                Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.05f)),
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    listOf(Tang.fill.copy(alpha = 0.55f), Color.Transparent),
                                ),
                            )
                        },
                )
                AnimatedFlame(size = 32.dp)
            }
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    str.success.streakLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.55f),
                )
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        streak.toString(),
                        style = MaterialTheme.typography.displaySmall,
                        fontWeight = FontWeight.Bold,
                        color = CreamCard,
                    )
                    Spacer(Modifier.size(6.dp))
                    Text(
                        str.success.streakDays,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.55f),
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        StreakWeekRow(data)

        Spacer(Modifier.height(16.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            RUNGS.forEach { rung ->
                val reached = streak >= rung
                val isNext = rung == next
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            when {
                                reached -> Tang.fill.copy(alpha = 0.85f)
                                isNext -> Color.White.copy(alpha = 0.08f)
                                else -> Color.White.copy(alpha = 0.04f)
                            },
                        )
                        .border(
                            if (isNext) 1.5.dp else 1.dp,
                            if (reached) Color.Transparent
                            else if (isNext) Tang.fill.copy(alpha = 0.6f)
                            else Color.White.copy(alpha = 0.08f),
                            RoundedCornerShape(10.dp),
                        )
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        rung.toString(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (reached) Ink else CreamCard.copy(alpha = if (isNext) 0.92f else 0.45f),
                        textAlign = TextAlign.Center,
                    )
                    Text(
                        str.success.rungDays,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (reached) Ink.copy(alpha = 0.65f) else Color.White.copy(alpha = if (isNext) 0.55f else 0.32f),
                    )
                }
            }
        }

        if (next != null) {
            Spacer(Modifier.height(10.dp))
            Text(
                str.success.toNextRung(next - streak, next),
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.75f),
            )
        }
    }
}

/**
 * The seven days ending today, ticked from the session log.
 *
 * Pulled out of [StreakLadder] so the streak celebration screen can show the
 * same row someone already recognises from the ladder card, instead of a
 * second, slightly different-looking week widget. Marked from the log rather
 * than the streak count itself — a streak that broke on Tuesday should still
 * show Monday's tick.
 */
@Composable
fun StreakWeekRow(data: AppData, modifier: Modifier = Modifier) {
    val today = LocalDate.now()
    val week = (6 downTo 0).map { back ->
        val day = today.minusDays(back.toLong())
        val epoch = day.toEpochDay()
        day to data.sessions.any { it.startedAtEpochDay == epoch && it.completed }
    }
    Row(
        modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        week.forEach { (day, done) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    day.dayOfWeek.name.take(1),
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.45f),
                )
                Spacer(Modifier.height(4.dp))
                // Tang, not Mint — this row now only ever appears on the
                // streak's own dark card or the streak celebration behind
                // it, and the warm colour matches the flame instead of
                // fighting it. The unchecked circle used to be a light
                // cream fill (Sunk), built for sitting on a cream card; on
                // dark it read as a small glowing dot for a day that never
                // happened, which is backwards. A faint ring on the card's
                // own tone reads as empty instead.
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(if (done) Tang.fill else Color.White.copy(alpha = 0.06f))
                        .border(
                            2.dp,
                            if (done) Tang.fill else Color.White.copy(alpha = 0.14f),
                            CircleShape,
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    if (done) {
                        Canvas(Modifier.size(14.dp)) {
                            val p = Path().apply {
                                moveTo(size.width * 0.18f, size.height * 0.52f)
                                lineTo(size.width * 0.42f, size.height * 0.78f)
                                lineTo(size.width * 0.84f, size.height * 0.22f)
                            }
                            drawPath(
                                p,
                                color = Color.White,
                                style = Stroke(width = size.minDimension * 0.22f),
                            )
                        }
                    }
                }
            }
        }
    }
}
