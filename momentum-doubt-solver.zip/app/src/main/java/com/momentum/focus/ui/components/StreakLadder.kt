package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.R
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Motion
import com.momentum.focus.data.FREEZE_CAP
import com.momentum.focus.data.FREEZE_PRICE
import com.momentum.focus.data.Currency
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.time.LocalDate

/** The rungs. Each one is a day count and what reaching it is worth. */
private val RUNGS = listOf(7, 14, 30, 60, 90)

/**
 * The eight frames of a real flicker, not a shape drawn once and left
 * still. This was a hand-drawn [TileObject] flame for a long time — flat,
 * static, and the one thing on this card that never actually looked lit.
 * These came from a short reference clip on a solid pink background,
 * chroma-keyed to transparent and cropped to a shared bounding box so the
 * flame flickers in place instead of drifting frame to frame.
 */
private val FLAME_FRAMES = listOf(
    R.drawable.streak_flame_00,
    R.drawable.streak_flame_01,
    R.drawable.streak_flame_02,
    R.drawable.streak_flame_03,
    R.drawable.streak_flame_04,
    R.drawable.streak_flame_05,
    R.drawable.streak_flame_06,
    R.drawable.streak_flame_07,
)

/** A small looping flip-book, not a video view — eight PNGs are cheap to hold
 * in memory and swapping [painterResource] on a timer needs nothing else.
 */
@Composable
fun AnimatedFlame(size: Dp, modifier: Modifier = Modifier) {
    var frame by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(90)
            frame = (frame + 1) % FLAME_FRAMES.size
        }
    }
    Image(
        painter = painterResource(FLAME_FRAMES[frame]),
        contentDescription = null,
        modifier = modifier.size(size),
    )
}

/**
 * The streak, and what it is climbing towards.
 *
 * The number on its own answers "how long" and nothing else. A streak is a
 * thing you keep going, so the question it actually raises is "until what" —
 * and the app had no answer anywhere on any screen. Seven days of ticks show
 * the week just gone; the ladder underneath shows the next rung and how far
 * off it is.
 *
 * Rungs are days, not rewards, because nothing is handed out for them. Saying
 * a number is coming and then not paying it would be worse than saying
 * nothing; what a rung buys is the fact of having got there.
 */
@Composable
fun StreakLadder(
    data: AppData,
    modifier: Modifier = Modifier,
    /** Streak 2.0: buys one freeze. Returns false when it couldn't (broke / full). */
    onBuyFreeze: (() -> Boolean)? = null,
) {
    val str = strings()
    val shape = RoundedCornerShape(Paper.CardRadius)
    val streak = data.streakDays
    val next = RUNGS.firstOrNull { it > streak }

    // Dark, not the cream-and-ink paper every other card on this screen
    // uses. That was a deliberate rule for a long time — dark surfaces
    // reserved for paid screens, so the one place that glowed meant
    // something. The reference widgets this was built from are dark
    // because a flame reads as lit against black in a way it never does
    // on cream, no matter how good the glow underneath it is; the streak
    // is the one free feature worth breaking the rule for.
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Ink)
            .border(1.2.dp, Color.White.copy(alpha = 0.10f), shape)
            .drawBehind {
                val r = size.width * 0.55f
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Tang.fill.copy(alpha = 0.16f), Color.Transparent),
                        center = Offset(size.width * 0.18f, 0f),
                        radius = r,
                    ),
                    radius = r,
                    center = Offset(size.width * 0.18f, 0f),
                )
            }
            .padding(16.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // The flame in its own small dark tile rather than floating
            // loose on the card — the same "icon gets a housing" move the
            // reference widget makes, and it is what stops the glow from
            // just bleeding into the card's own background with nothing to
            // frame it.
            Box(
                Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.05f)),
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    listOf(Tang.fill.copy(alpha = 0.55f), Color.Transparent),
                                ),
                            )
                        },
                )
                AnimatedFlame(size = 32.dp)
            }
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    str.success.streakLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.55f),
                )
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        streak.toString(),
                        style = MaterialTheme.typography.displaySmall,
                        fontWeight = FontWeight.Bold,
                        color = CreamCard,
                    )
                    Spacer(Modifier.size(6.dp))
                    Text(
                        str.success.streakDays,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.55f),
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        StreakWeekRow(data)

        if (onBuyFreeze != null) {
            Spacer(Modifier.height(14.dp))
            FreezeRow(data, onBuyFreeze)
        }

        Spacer(Modifier.height(14.dp))

        val target = next ?: maxOf(streak, RUNGS.last())
        val previous = RUNGS.lastOrNull { it <= streak } ?: 0
        val progress = if (target <= previous) 1f
        else ((streak - previous).toFloat() / (target - previous).toFloat()).coerceIn(0f, 1f)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "$streak / $target",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = 0.82f),
            )
            Spacer(Modifier.size(10.dp))
            GlowProgressBar(progress = progress, modifier = Modifier.weight(1f), height = 9.dp, dark = true)
        }

        Spacer(Modifier.height(16.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            RUNGS.forEach { rung ->
                val reached = streak >= rung
                val isNext = rung == next
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            when {
                                reached -> Tang.fill.copy(alpha = 0.85f)
                                isNext -> Color.White.copy(alpha = 0.08f)
                                else -> Color.White.copy(alpha = 0.04f)
                            },
                        )
                        .border(
                            if (isNext) 1.5.dp else 1.dp,
                            if (reached) Color.Transparent
                            else if (isNext) Tang.fill.copy(alpha = 0.6f)
                            else Color.White.copy(alpha = 0.08f),
                            RoundedCornerShape(10.dp),
                        )
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        rung.toString(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (reached) Ink else CreamCard.copy(alpha = if (isNext) 0.92f else 0.45f),
                        textAlign = TextAlign.Center,
                    )
                    Text(
                        str.success.rungDays,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (reached) Ink.copy(alpha = 0.65f) else Color.White.copy(alpha = if (isNext) 0.55f else 0.32f),
                    )
                }
            }
        }

        if (next != null) {
            Spacer(Modifier.height(10.dp))
            Text(
                str.success.toNextRung(next - streak, next),
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.75f),
            )
        }
    }
}

/**
 * The seven days ending today, ticked from the session log.
 *
 * Pulled out of [StreakLadder] so the streak celebration screen can show the
 * same row someone already recognises from the ladder card, instead of a
 * second, slightly different-looking week widget. Marked from the log rather
 * than the streak count itself — a streak that broke on Tuesday should still
 * show Monday's tick.
 */
@Composable
fun StreakWeekRow(data: AppData, modifier: Modifier = Modifier) {
    val today = LocalDate.now()
    val week = (6 downTo 0).map { back ->
        val day = today.minusDays(back.toLong())
        val epoch = day.toEpochDay()
        Triple(
            day,
            data.sessions.any { it.startedAtEpochDay == epoch && it.completed },
            epoch in data.frozenDays,
        )
    }
    Row(
        modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        week.forEach { (day, done, frozen) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    day.dayOfWeek.name.take(1),
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.45f),
                )
                Spacer(Modifier.height(4.dp))
                // Tang, not Mint — this row now only ever appears on the
                // streak's own dark card or the streak celebration behind
                // it, and the warm colour matches the flame instead of
                // fighting it. The unchecked circle used to be a light
                // cream fill (Sunk), built for sitting on a cream card; on
                // dark it read as a small glowing dot for a day that never
                // happened, which is backwards. A faint ring on the card's
                // own tone reads as empty instead.
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                done -> Tang.fill
                                frozen -> Sky.fill
                                else -> Color.White.copy(alpha = 0.06f)
                            }
                        )
                        .border(
                            2.dp,
                            when {
                                done -> Tang.fill
                                frozen -> Sky.fill
                                else -> Color.White.copy(alpha = 0.14f)
                            },
                            CircleShape,
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    if (frozen && !done) {
                        Snowflake(Modifier.size(14.dp), Sky.on)
                    }
                    if (done) {
                        Canvas(Modifier.size(14.dp)) {
                            val p = Path().apply {
                                moveTo(size.width * 0.18f, size.height * 0.52f)
                                lineTo(size.width * 0.42f, size.height * 0.78f)
                                lineTo(size.width * 0.84f, size.height * 0.22f)
                            }
                            drawPath(
                                p,
                                color = Color.White,
                                style = Stroke(width = size.minDimension * 0.22f),
                            )
                        }
                    }
                }
            }
        }
    }
}


/**
 * Streak 2.0 — the freeze shelf on the streak card.
 *
 * Ice cubes are drawn, not emoji. Buying one: the new cube drops into its slot
 * (240 ms settle, no bounce), SPEND sound, a confirm haptic. Nothing loops.
 */
@Composable
private fun FreezeRow(data: AppData, onBuy: () -> Boolean) {
    val str = strings().streak
    val haptics = rememberHaptics()
    val scope = rememberCoroutineScope()
    val owned = data.streakFreezes.coerceIn(0, FREEZE_CAP)
    val full = owned >= FREEZE_CAP
    val broke = data.balanceMinutes < FREEZE_PRICE
    val price = Currency.format(FREEZE_PRICE)
    val drop = remember { Animatable(1f) }
    var justBought by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(FREEZE_CAP) { i ->
                    val filled = i < owned
                    val isNew = filled && i == owned - 1
                    IceCube(
                        filled = filled,
                        modifier = Modifier
                            .size(30.dp)
                            .graphicsLayer {
                                if (isNew) {
                                    val v = drop.value
                                    translationY = (1f - v) * -18.dp.toPx()
                                    alpha = 0.3f + 0.7f * v
                                }
                            },
                    )
                }
            }
            Spacer(Modifier.size(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    str.freezeTitle,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black,
                    color = Sky.fill,
                )
                Text(
                    if (justBought) str.bought else str.equipped(owned, FREEZE_CAP),
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.75f),
                )
            }
            SquishButton(
                label = when {
                    full -> str.full
                    else -> str.buy(price)
                },
                sticker = Sky,
                enabled = !full && !broke,
            ) {
                if (onBuy()) {
                    haptics.confirm()
                    Sfx.play(Sound.SPEND)
                    justBought = true
                    scope.launch {
                        drop.snapTo(0f)
                        drop.animateTo(1f, tween(240, easing = FastOutSlowInEasing))
                    }
                } else {
                    haptics.reject()
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            if (broke && !full) str.needMore(price) + " · " + str.freezeHow else str.freezeHow,
            style = MaterialTheme.typography.bodySmall,
            color = Color.White.copy(alpha = 0.5f),
        )
    }
}

/** A flat ink-outlined ice cube with one highlight — the app's paper style on the dark card. */
@Composable
fun IceCube(filled: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val r = CornerRadius(size.minDimension * 0.24f)
        if (filled) {
            drawRoundRect(Sky.fill, cornerRadius = r)
            drawRoundRect(Ink, cornerRadius = r, style = Stroke(2.dp.toPx()))
            drawLine(
                Color.White.copy(alpha = 0.85f),
                Offset(size.width * 0.26f, size.height * 0.30f),
                Offset(size.width * 0.26f, size.height * 0.58f),
                strokeWidth = 2.5.dp.toPx(),
                cap = StrokeCap.Round,
            )
            drawLine(
                Color.White.copy(alpha = 0.85f),
                Offset(size.width * 0.26f, size.height * 0.30f),
                Offset(size.width * 0.50f, size.height * 0.30f),
                strokeWidth = 2.5.dp.toPx(),
                cap = StrokeCap.Round,
            )
        } else {
            drawRoundRect(
                Color.White.copy(alpha = 0.22f),
                cornerRadius = r,
                style = Stroke(1.5.dp.toPx(), pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6f, 5f))),
            )
        }
    }
}

/** Six-armed mark for a frozen day in the week row. */
@Composable
fun Snowflake(modifier: Modifier = Modifier, color: Color = Ink) {
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        for (i in 0 until 3) {
            val a = Math.toRadians(90.0 + i * 60.0)
            val dx = (kotlin.math.cos(a) * r).toFloat()
            val dy = (kotlin.math.sin(a) * r).toFloat()
            drawLine(color, Offset(c.x - dx, c.y - dy), Offset(c.x + dx, c.y + dy), strokeWidth = size.minDimension * 0.16f, cap = StrokeCap.Round)
        }
    }
}
