package com.momentum.focus.ui.components

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.tr
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

/*
 * MyAI "Ask" tab pieces DoubtSheet drops in (length/language moved to
 * AnswerStyleSheet in MyAiBars.kt, 2026-10-07):
 *
 *  FollowUps   one-tap next questions after an answer lands
 *  SpeakChip   mic (phone's own voice typing) on the footer line
 */
@Composable
fun FollowUps(enabled: Boolean, onAsk: (String) -> Unit) {
    val haptics = rememberHaptics()
    val items = listOf(
        tr("Give one more example", "एक और उदाहरण दो"),
        tr("Explain it simpler", "और आसान करके समझाओ"),
        tr("Common mistake here?", "यहाँ आम गलती क्या है?"),
        tr("2-mark answer version", "2 नंबर वाला जवाब"),
    )
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        items.forEach { q ->
            val shape = RoundedCornerShape(50)
            Text(
                q,
                fontSize = 12.5.sp, fontWeight = FontWeight.Bold,
                color = if (enabled) Ink else InkMid,
                modifier = Modifier
                    .clip(shape)
                    .background(CreamCard)
                    .border(1.5.dp, Ink, shape)
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        if (enabled) { haptics.tick(); onAsk(q) }
                    }
                    .padding(horizontal = 11.dp, vertical = 6.dp),
            )
        }
    }
}

/**
 * "Speak" — the phone's own voice typing (en-IN), appended to the box. Sits
 * on the composer's footer line now; the n/300 counter moved there too and
 * only shows while typing (2026-10-07: the separate speak row cost 26dp).
 */
@Composable
fun SpeakChip(text: String, max: Int, enabled: Boolean, onText: (String) -> Unit) {
    val haptics = rememberHaptics()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) onText(listOf(text, spoken).filter { it.isNotBlank() }.joinToString(" ").take(max))
        }
    }
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .clip(shape)
            .background(if (enabled) Butter.fill else Sunk)
            .border(1.5.dp, Ink, shape)
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                if (!enabled) return@clickableNoRipple
                haptics.tick()
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, tr("Ask your doubt", "अपना सवाल बोलो"))
                // No voice-typing app on the phone: the button just does nothing.
                runCatching { launcher.launch(i) }
            }
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Mic, contentDescription = null, tint = Ink, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(3.dp))
        Text(tr("Speak", "बोलो"), fontSize = 12.sp, fontWeight = FontWeight.Black, color = Ink)
    }
}
