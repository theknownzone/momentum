package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.drawBehind
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Sticker
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.i18n.strings

private data class TourStep(
    val kicker: String,
    val title: String,
    val body: String,
    val sticker: Sticker,
)

/**
 * The one-time walkthrough a new install gets.
 *
 * Five things have to land before any of the screens make sense: minutes turn
 * into money, the shield exists, feeds are separate from apps, a pact only
 * tightens, and the numbers are real. Someone who opens the app cold and finds
 * a wallet with ₹0 and a locked toggle has no way to work that out.
 *
 * Deliberately not a spotlight over the live UI. Anchoring cut-outs to real
 * composables means measuring their coordinates, and a wrong measurement puts
 * the hole over empty space — worse than no tour at all.
 */
@Composable
fun TourOverlay(onDone: () -> Unit) {
    val str = strings().tour
    // Built from strings() now, not five TourStep literals sitting at file
    // scope in Hinglish — the whole reason this needed fixing at all. The
    // kicker is just a position count ("1 / 5"), not words, so it's built
    // here rather than carried as five near-identical string pairs.
    val steps = remember(str) {
        listOf(
            TourStep("1 / 5", str.step1Title, str.step1Body, Mint),
            TourStep("2 / 5", str.step2Title, str.step2Body, Sky),
            TourStep("3 / 5", str.step3Title, str.step3Body, Tang),
            TourStep("4 / 5", str.step4Title, str.step4Body, Butter),
            TourStep("5 / 5", str.step5Title, str.step5Body, Mint),
        )
    }
    var index by remember { mutableStateOf(0) }
    val step = steps[index]

    // Reset per step, so each card scales up on arrival. Animating straight to
    // 1f from a state that already holds 1f produces no motion at all — the
    // value has to start below the target for every step, not just the first.
    var settled by remember(index) { mutableStateOf(false) }
    LaunchedEffect(index) { settled = true }
    val pop by animateFloatAsState(
        targetValue = if (settled) 1f else 0.88f,
        animationSpec = tween(260),
        label = "pop",
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Ink.copy(alpha = 0.55f)),
        contentAlignment = Alignment.Center,
    ) {
        // Tour hint dot (from Uiverse item-hints): a pulsing ink pin above the
        // card whose leader line draws itself down to the card on each step.
        // Decorative only — no anchoring to live UI (see note above).
        val lead = remember(index) { Animatable(0f) }
        LaunchedEffect(index) { lead.animateTo(1f, tween(420, delayMillis = 120)) }
        val ping = rememberInfiniteTransition(label = "hintPing").animateFloat(
            0f, 1f, infiniteRepeatable(tween(1600)), label = "hintPingT",
        )
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .scale(pop)
                .drawBehind {
                    val pin = Offset(26.dp.toPx(), -46.dp.toPx())
                    val end = Offset(70.dp.toPx(), 0f)
                    val k = lead.value
                    drawLine(Ink, pin, pin + (end - pin) * k, 2.5.dp.toPx(), StrokeCap.Round)
                    val p = ping.value
                    drawCircle(step.sticker.fill.copy(alpha = 0.6f * (1f - p)), 7.dp.toPx() + 14.dp.toPx() * p, pin)
                    drawCircle(Ink, 8.dp.toPx(), pin + Offset(2.dp.toPx(), 2.dp.toPx()))
                    drawCircle(step.sticker.fill, 8.dp.toPx(), pin)
                    drawCircle(Ink, 8.dp.toPx(), pin, style = Stroke(2.5.dp.toPx()))
                }
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(step.sticker.fill)
                    .border(2.dp, Ink, RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
            ) {
                Text(
                    step.kicker,
                    style = MaterialTheme.typography.labelSmall,
                    color = step.sticker.on,
                )
            }

            Spacer(Modifier.height(14.dp))
            Text(
                step.title,
                style = MaterialTheme.typography.headlineSmall,
                color = Ink,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(10.dp))
            Text(
                step.body,
                style = MaterialTheme.typography.bodyLarge,
                color = InkMid,
                textAlign = TextAlign.Center,
            )

            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                steps.indices.forEach { i ->
                    Box(
                        Modifier
                            .size(if (i == index) 10.dp else 7.dp)
                            .clip(CircleShape)
                            .background(if (i == index) Ink else InkMid.copy(alpha = 0.4f))
                    )
                }
            }

            Spacer(Modifier.height(18.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(step.sticker.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        if (index < steps.lastIndex) index++ else onDone()
                    }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (index < steps.lastIndex) str.next else str.start,
                    style = MaterialTheme.typography.titleMedium,
                    color = step.sticker.on,
                )
            }

            if (index < steps.lastIndex) {
                Spacer(Modifier.height(8.dp))
                Text(
                    str.skip,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                    modifier = Modifier
                        .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onDone)
                        .padding(6.dp),
                )
            }
        }
    }
}
