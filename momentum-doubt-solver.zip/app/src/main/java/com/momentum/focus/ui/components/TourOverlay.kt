package com.momentum.focus.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.Candy
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Sticker
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.isActive
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.sin

/**
 * The one-time walkthrough a new install gets (gated by AppData.tourSeen in
 * MainActivity, so it is shown ONCE).
 *
 * 2026-10-07 rebuild (owner: high-production motion, not a tooltip list).
 * Built like Instagram stories, because every student already knows how to
 * drive those:
 *
 *  - five segments across the top fill over 8.5s; the next story starts on
 *    its own. Tap the right of the stage = next, left = back, press and hold
 *    = pause (the segment freezes). The last story waits for the button.
 *  - each story has its own drawn animation on the stage card (ink lines,
 *    sticker fills — the app's comic-paper style, no clip-art, no emoji):
 *      1 ring sweeps, coins drop into the wallet, ₹ counts up
 *      2 app tiles, a shield draws itself over them, two get stamped
 *      3 a phone: lecture stays playing, the reels strip freezes and locks
 *      4 a level slider climbs, tries to slide down, a padlock clamps it
 *      5 seven bars grow, a tick draws, "7 DAYS" lands
 *  - the stage colour changes with a circular wipe from where you tapped;
 *    kicker / title / body rise in staggered (0 / 120 / 240ms, 420ms ease).
 *  - one CHIME per story, pitched up a step each time; DONE on Get started.
 *
 * Deliberately not a spotlight over live UI — anchoring cut-outs to real
 * composables needs measured coordinates, and a wrong one points at nothing.
 */
private data class TourStep(val title: String, val body: String, val sticker: Sticker)

private const val STEP_MS = 8500f

@Composable
fun TourOverlay(onDone: () -> Unit) {
    val str = strings().tour
    val haptics = rememberHaptics()
    val steps = remember(str) {
        listOf(
            TourStep(str.step1Title, str.step1Body, Mint),
            TourStep(str.step2Title, str.step2Body, Sky),
            TourStep(str.step3Title, str.step3Body, Tang),
            TourStep(str.step4Title, str.step4Body, Butter),
            TourStep(str.step5Title, str.step5Body, Lilac),
        )
    }
    var index by remember { mutableIntStateOf(0) }
    var prevIndex by remember { mutableIntStateOf(0) }
    var paused by remember { mutableStateOf(false) }
    var wipeFrom by remember { mutableStateOf(Offset(0.85f, 0.85f)) }
    var finished by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    // Step-local clock for the stage art and the text stagger.
    var t by remember { mutableFloatStateOf(0f) }

    fun finish() {
        if (finished) return
        finished = true
        haptics.confirm()
        Sfx.playOnce(Sound.DONE)
        onDone()
    }
    fun go(to: Int, from: Offset = Offset(0.85f, 0.85f)) {
        if (to < 0 || to > steps.lastIndex || to == index) return
        prevIndex = index
        wipeFrom = from
        // Reset in the same frame the step changes, so the new copy and
        // colour never flash in fully before their animation starts.
        t = 0f
        progress = 0f
        index = to
    }
    BackHandler { if (index > 0) go(index - 1, Offset(0.1f, 0.5f)) else finish() }

    // Per step: chime, restart the wipe, the clock and the segment.
    LaunchedEffect(index) {
        haptics.tick()
        Sfx.playOnce(Sound.CHIME, 1f + index * 0.12f)
        var last = withFrameNanos { it }
        while (isActive) {
            withFrameNanos { now ->
                val dt = (now - last) / 1_000_000f
                last = now
                if (!paused) {
                    t += dt
                    progress = (progress + dt / STEP_MS).coerceAtMost(1f)
                }
            }
            if (progress >= 1f && index < steps.lastIndex && !paused) {
                go(index + 1)
                break
            }
        }
    }

    val step = steps[index]
    val prev = steps[prevIndex]
    val measurer = rememberTextMeasurer()

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain(),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(bottom = rememberSafeBottom())
                .padding(horizontal = Paper.ScreenPad),
        ) {
            // Story segments + skip.
            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    steps.indices.forEach { i ->
                        val fill = when {
                            i < index -> 1f
                            i == index -> progress
                            else -> 0f
                        }
                        Box(
                            Modifier
                                .weight(1f)
                                .height(5.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Ink.copy(alpha = 0.14f))
                                .drawBehind {
                                    drawRoundRect(
                                        Ink,
                                        size = Size(size.width * fill, size.height),
                                        cornerRadius = CornerRadius(size.height / 2f),
                                    )
                                },
                        )
                    }
                }
                Spacer(Modifier.width(10.dp))
                Text(
                    str.skip,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = InkMid,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickableNoRipple(remember { MutableInteractionSource() }) { finish() }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                )
            }
            Spacer(Modifier.height(14.dp))

            // The stage: drawn art, colour wipe, tap / hold controls.
            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .heightIn(min = 200.dp)
                    .drawBehind {
                        val d = 6.dp.toPx()
                        drawRoundRect(Ink, Offset(d, d), size, CornerRadius(22.dp.toPx()))
                    }
                    .clip(RoundedCornerShape(22.dp))
                    .pointerInput(steps.size) {
                        detectTapGestures(
                            onPress = {
                                paused = true
                                tryAwaitRelease()
                                paused = false
                            },
                            onTap = { pos ->
                                val from = Offset(pos.x / size.width, pos.y / size.height)
                                if (pos.x < size.width * 0.3f) go(index - 1, from)
                                else if (index < steps.lastIndex) go(index + 1, from)
                            },
                        )
                    },
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    drawRect(prev.sticker.fill)
                    val c = Offset(size.width * wipeFrom.x, size.height * wipeFrom.y)
                    val far = hypot(size.width, size.height)
                    val r = far * ease(seg(t, 0f, 520f))
                    clipPath(Path().apply { addOval(androidx.compose.ui.geometry.Rect(c, r)) }) {
                        drawRect(step.sticker.fill)
                    }
                    halftone(step.sticker)
                    val art = Offset(size.width / 2f, size.height / 2f)
                    val u = minOf(size.width, size.height) / 10f
                    when (index) {
                        0 -> artEarn(art, u, t, measurer)
                        1 -> artShield(art, u, t)
                        2 -> artFeeds(art, u, t)
                        3 -> artPact(art, u, t)
                        else -> artReal(art, u, t, measurer)
                    }
                }
                Box(
                    Modifier
                        .fillMaxSize()
                        .border(Paper.Outline, Ink, RoundedCornerShape(22.dp)),
                )
                if (paused) {
                    androidx.compose.material3.Icon(
                        androidx.compose.material.icons.Icons.Filled.Pause,
                        contentDescription = null,
                        tint = Ink.copy(alpha = 0.6f),
                        modifier = Modifier.align(Alignment.TopEnd).padding(12.dp).size(20.dp),
                    )
                }
            }

            Spacer(Modifier.height(18.dp))
            // Copy, staggered. Scrolls if a long Hindi line + big font
            // would otherwise push the button off screen.
            Column(Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState())) {
                Box(
                    Modifier
                        .riseAt(t, 0f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(step.sticker.fill)
                        .border(2.dp, Ink, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                ) {
                    Text(
                        "${index + 1} / ${steps.size}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Black,
                        color = step.sticker.on,
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    step.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black,
                    color = Ink,
                    modifier = Modifier.riseAt(t, 120f),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    step.body,
                    style = MaterialTheme.typography.bodyLarge,
                    color = InkMid,
                    modifier = Modifier.riseAt(t, 240f),
                )
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (index > 0) {
                    Text(
                        "←",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = Ink,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                go(index - 1, Offset(0.1f, 0.5f))
                            }
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                }
                SquishButton(
                    if (index < steps.lastIndex) str.next else str.start,
                    step.sticker,
                    Modifier.weight(1f),
                ) {
                    if (index < steps.lastIndex) go(index + 1) else finish()
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

private fun ease(x: Float) = 1f - (1f - x) * (1f - x) * (1f - x)
private fun seg(t: Float, a: Float, d: Float) = ((t - a) / d).coerceIn(0f, 1f)

private fun Modifier.riseAt(t: Float, at: Float): Modifier = graphicsLayer {
    val p = ease(seg(t, at, 420f))
    alpha = p
    translationY = (1f - p) * 16.dp.toPx()
}

/** Faint Ben-Day dots in the stage's own darker tone. */
private fun DrawScope.halftone(s: Sticker) {
    val step = 14.dp.toPx()
    val dot = s.accent.copy(alpha = 0.16f)
    var y = step / 2f
    var row = 0
    while (y < size.height) {
        var x = if (row % 2 == 0) step / 2f else step
        while (x < size.width) {
            drawCircle(dot, 1.6.dp.toPx(), Offset(x, y))
            x += step
        }
        y += step
        row++
    }
}

private fun DrawScope.inkRect(topLeft: Offset, sz: Size, fill: Color, radius: Float, stroke: Float) {
    val sh = stroke * 1.4f
    drawRoundRect(Ink, topLeft + Offset(sh, sh), sz, CornerRadius(radius))
    drawRoundRect(fill, topLeft, sz, CornerRadius(radius))
    drawRoundRect(Ink, topLeft, sz, CornerRadius(radius), style = Stroke(stroke))
}

private fun DrawScope.stamp(m: TextMeasurer, text: String, center: Offset, sizeSp: Int, color: Color = Ink) {
    val style = TextStyle(fontSize = sizeSp.sp, fontWeight = FontWeight.Black, color = color)
    val r = m.measure(text, style)
    drawText(r, topLeft = Offset(center.x - r.size.width / 2f, center.y - r.size.height / 2f))
}

/* 1 — Study, then earn. */
private fun DrawScope.artEarn(c: Offset, u: Float, t: Float, m: TextMeasurer) {
    val w = 3.dp.toPx()
    val ring = Offset(c.x - u * 1.9f, c.y - u * 0.4f)
    val rr = u * 1.6f
    drawCircle(CreamCard, rr, ring)
    drawCircle(Ink, rr, ring, style = Stroke(w))
    val sweep = 300f * ease(seg(t, 200f, 1600f))
    drawArc(
        Mint.accent, -90f, sweep, false,
        topLeft = ring - Offset(rr * 0.78f, rr * 0.78f), size = Size(rr * 1.56f, rr * 1.56f),
        style = Stroke(u * 0.32f, cap = StrokeCap.Round),
    )
    stamp(m, "${(25 * ease(seg(t, 200f, 1600f))).toInt()}m", ring, 18)
    // Wallet.
    val wl = Offset(c.x + u * 0.6f, c.y + u * 0.3f)
    val ws = Size(u * 3.2f, u * 2.2f)
    // Coins: drop one after another from the ring into the wallet.
    for (k in 0 until 4) {
        val p = ease(seg(t, 1100f + k * 260f, 520f))
        if (p <= 0f || p >= 1f) continue
        val from = ring + Offset(rr * 0.6f, -rr * 0.2f)
        val to = wl + Offset(ws.width / 2f, u * 0.3f)
        val pos = from + (to - from) * p - Offset(0f, sin(p * PI.toFloat()) * u * 1.4f)
        drawCircle(Ink, u * 0.36f, pos + Offset(w * 0.8f, w * 0.8f))
        drawCircle(Butter.fill, u * 0.36f, pos)
        drawCircle(Ink, u * 0.36f, pos, style = Stroke(w * 0.8f))
    }
    inkRect(wl, ws, CreamCard, u * 0.4f, w)
    drawRoundRect(Ink, wl + Offset(ws.width * 0.62f, ws.height * 0.32f), Size(ws.width * 0.5f, ws.height * 0.36f), CornerRadius(u * 0.2f))
    val money = (25 * ease(seg(t, 1300f, 1300f))).toInt()
    stamp(m, "₹$money", wl + Offset(ws.width * 0.36f, ws.height / 2f), 20)
}

/* 2 — The shield blocks apps. */
private fun DrawScope.artShield(c: Offset, u: Float, t: Float) {
    val w = 3.dp.toPx()
    val fills = listOf(Candy.fill, Sky.fill, Butter.fill, Mint.fill, Lilac.fill, Tang.fill)
    val tile = u * 1.35f
    val gap = u * 0.45f
    val gridW = tile * 3 + gap * 2
    val gridH = tile * 2 + gap
    val origin = Offset(c.x - gridW / 2f, c.y - gridH / 2f)
    for (i in 0 until 6) {
        val col = i % 3
        val row = i / 3
        val pop = ease(seg(t, i * 70f, 360f))
        val tl = origin + Offset(col * (tile + gap), row * (tile + gap) + (1f - pop) * u)
        inkRect(tl, Size(tile, tile), fills[i].copy(alpha = pop), u * 0.35f, w)
        // Two blocked apps get stamped once the shield is up.
        if (i == 0 || i == 4) {
            val s = ease(seg(t, 1700f + (if (i == 0) 0f else 220f), 260f))
            if (s > 0f) {
                drawRoundRect(Ink.copy(alpha = 0.35f * s), tl, Size(tile, tile), CornerRadius(u * 0.35f))
                val a = tl + Offset(tile * 0.25f, tile * 0.25f)
                val b = tl + Offset(tile * 0.75f, tile * 0.75f)
                drawLine(CreamCard, a, a + (b - a) * s, w * 1.4f, StrokeCap.Round)
                drawLine(CreamCard, Offset(b.x, a.y), Offset(b.x, a.y) + (Offset(a.x, b.y) - Offset(b.x, a.y)) * s, w * 1.4f, StrokeCap.Round)
            }
        }
    }
    // Shield outline draws itself over the grid.
    val sw = u * 3.4f
    val top = c.y - u * 2.3f
    val shield = Path().apply {
        moveTo(c.x, top)
        lineTo(c.x + sw / 2f, top + u * 0.7f)
        lineTo(c.x + sw / 2f, top + u * 2.4f)
        quadraticTo(c.x + sw / 2f, top + u * 4.0f, c.x, top + u * 4.6f)
        quadraticTo(c.x - sw / 2f, top + u * 4.0f, c.x - sw / 2f, top + u * 2.4f)
        lineTo(c.x - sw / 2f, top + u * 0.7f)
        close()
    }
    val p = ease(seg(t, 700f, 900f))
    if (p > 0f) {
        val pm = PathMeasure()
        pm.setPath(shield, false)
        val part = Path()
        pm.getSegment(0f, pm.length * p, part, true)
        drawPath(part, Ink, style = Stroke(w * 3.2f, cap = StrokeCap.Round))
        drawPath(part, CreamCard, style = Stroke(w * 1.4f, cap = StrokeCap.Round))
    }
}

/* 3 — Feeds are blocked on their own. */
private fun DrawScope.artFeeds(c: Offset, u: Float, t: Float) {
    val w = 3.dp.toPx()
    val ps = Size(u * 3.6f, u * 6.4f)
    val tl = Offset(c.x - ps.width / 2f, c.y - ps.height / 2f)
    inkRect(tl, ps, CreamCard, u * 0.6f, w)
    val pad = u * 0.35f
    // Lecture: stays playing (progress bar keeps moving).
    val lec = tl + Offset(pad, pad * 2f)
    val lecS = Size(ps.width - pad * 2, u * 2.0f)
    inkRect(lec, lecS, Sky.fill, u * 0.25f, w * 0.8f)
    val tri = Path().apply {
        val m = lec + Offset(lecS.width / 2f, lecS.height / 2f)
        moveTo(m.x - u * 0.3f, m.y - u * 0.4f)
        lineTo(m.x + u * 0.45f, m.y)
        lineTo(m.x - u * 0.3f, m.y + u * 0.4f)
        close()
    }
    drawPath(tri, Ink)
    val play = (t / 4000f) % 1f
    drawLine(Ink, lec + Offset(u * 0.2f, lecS.height - u * 0.25f), lec + Offset(u * 0.2f + (lecS.width - u * 0.4f) * play, lecS.height - u * 0.25f), w, StrokeCap.Round)
    // Reels: scroll fast, then freeze, grey out, lock.
    val reel = Offset(lec.x, lec.y + lecS.height + pad)
    val reelS = Size(lecS.width, ps.height - (reel.y - tl.y) - pad * 2f)
    val freeze = ease(seg(t, 1500f, 500f))
    val scroll = (if (freeze < 1f) t else 1500f) / 220f
    clipPath(Path().apply { addRoundRect(androidx.compose.ui.geometry.RoundRect(reel.x, reel.y, reel.x + reelS.width, reel.y + reelS.height, CornerRadius(u * 0.25f))) }) {
        val card = u * 1.5f
        val fills = listOf(Candy.fill, Tang.fill, Lilac.fill, Butter.fill)
        for (k in -1..4) {
            val y = reel.y + ((k * card - (scroll * card) % card) + card) - card
            drawRect(fills[(k + 4 + (scroll.toInt())) % 4], Offset(reel.x, y), Size(reelS.width, card - w))
        }
        drawRect(Ink.copy(alpha = 0.55f * freeze), reel, reelS)
    }
    drawRoundRect(Ink, reel, reelS, CornerRadius(u * 0.25f), style = Stroke(w * 0.8f))
    if (freeze > 0f) {
        val lc = reel + Offset(reelS.width / 2f, reelS.height / 2f)
        padlock(lc, u * 0.9f * (0.6f + 0.4f * freeze), ease(seg(t, 1900f, 300f)), w)
    }
}

/** A small padlock; [shut] 0 = shackle up, 1 = clamped. */
private fun DrawScope.padlock(c: Offset, s: Float, shut: Float, w: Float) {
    val body = Size(s * 1.4f, s * 1.1f)
    val bl = Offset(c.x - body.width / 2f, c.y - body.height * 0.2f)
    val lift = (1f - shut) * s * 0.45f
    drawArc(
        Ink, 180f, 180f, false,
        topLeft = Offset(c.x - s * 0.45f, bl.y - s * 0.75f - lift), size = Size(s * 0.9f, s * 1.0f),
        style = Stroke(w * 1.6f, cap = StrokeCap.Round),
    )
    drawLine(Ink, Offset(c.x - s * 0.45f, bl.y - s * 0.25f - lift), Offset(c.x - s * 0.45f, bl.y), w * 1.6f)
    drawLine(Ink, Offset(c.x + s * 0.45f, bl.y - s * 0.25f - lift), Offset(c.x + s * 0.45f, bl.y), w * 1.6f)
    inkRect(bl, body, Butter.fill, s * 0.2f, w)
    drawCircle(Ink, s * 0.14f, bl + Offset(body.width / 2f, body.height * 0.45f))
}

/* 4 — A pact only tightens. */
private fun DrawScope.artPact(c: Offset, u: Float, t: Float) {
    val w = 3.dp.toPx()
    val track = Size(u * 1.1f, u * 6.0f)
    val tl = Offset(c.x - u * 1.6f - track.width / 2f, c.y - track.height / 2f)
    inkRect(tl, track, CreamCard, track.width / 2f, w)
    // Level marks.
    for (k in 0 until 4) {
        val y = tl.y + track.height * (0.2f + k * 0.2f)
        drawLine(Ink, Offset(tl.x + track.width + u * 0.2f, y), Offset(tl.x + track.width + u * 0.6f, y), w * 0.8f)
    }
    // Knob climbs, then tries to come down and is held.
    val up = ease(seg(t, 200f, 1000f))
    val tug = if (t in 1500f..2300f) sin((t - 1500f) / 800f * PI.toFloat() * 3f) * (1f - (t - 1500f) / 800f) else 0f
    val pos = 0.8f - 0.6f * up + 0.06f * tug.coerceAtLeast(0f)
    val knob = Offset(tl.x + track.width / 2f, tl.y + track.height * pos)
    drawRoundRect(Mint.fill, Offset(tl.x + w, knob.y), Size(track.width - w * 2, tl.y + track.height - knob.y - w), CornerRadius(track.width / 2f))
    drawCircle(Ink, u * 0.75f, knob + Offset(w, w))
    drawCircle(Butter.fill, u * 0.75f, knob)
    drawCircle(Ink, u * 0.75f, knob, style = Stroke(w))
    // Up arrow: fine. Down arrow: crossed out.
    val ax = c.x + u * 1.4f
    val upA = Offset(ax, c.y - u * 1.6f)
    drawLine(Ink, upA + Offset(0f, u * 1.2f), upA, w * 1.6f, StrokeCap.Round)
    drawLine(Ink, upA, upA + Offset(-u * 0.5f, u * 0.5f), w * 1.6f, StrokeCap.Round)
    drawLine(Ink, upA, upA + Offset(u * 0.5f, u * 0.5f), w * 1.6f, StrokeCap.Round)
    val dnA = Offset(ax, c.y + u * 1.8f)
    drawLine(Ink.copy(alpha = 0.4f), dnA - Offset(0f, u * 1.2f), dnA, w * 1.6f, StrokeCap.Round)
    drawLine(Ink.copy(alpha = 0.4f), dnA, dnA + Offset(-u * 0.5f, -u * 0.5f), w * 1.6f, StrokeCap.Round)
    drawLine(Ink.copy(alpha = 0.4f), dnA, dnA + Offset(u * 0.5f, -u * 0.5f), w * 1.6f, StrokeCap.Round)
    val x = ease(seg(t, 1700f, 300f))
    if (x > 0f) {
        val a = dnA + Offset(-u * 0.8f, -u * 1.4f)
        val b = dnA + Offset(u * 0.8f, u * 0.2f)
        drawLine(Tang.accent, a, a + (b - a) * x, w * 2f, StrokeCap.Round)
    }
    padlock(Offset(ax, c.y + u * 0.15f), u * 0.75f, ease(seg(t, 2100f, 260f)), w)
}

/* 5 — The numbers are real. */
private fun DrawScope.artReal(c: Offset, u: Float, t: Float, m: TextMeasurer) {
    val w = 3.dp.toPx()
    val bw = u * 0.62f
    val gap = u * 0.28f
    val totalW = bw * 7 + gap * 6
    val base = c.y + u * 2.2f
    val heights = listOf(0.35f, 0.55f, 0.45f, 0.7f, 0.6f, 0.85f, 1f)
    drawLine(Ink, Offset(c.x - totalW / 2f - u * 0.3f, base), Offset(c.x + totalW / 2f + u * 0.3f, base), w, StrokeCap.Round)
    heights.forEachIndexed { i, h ->
        val g = ease(seg(t, 150f + i * 110f, 520f))
        val bh = u * 4.2f * h * g
        if (bh > 1f) {
            val tl = Offset(c.x - totalW / 2f + i * (bw + gap), base - bh)
            inkRect(tl, Size(bw, bh), if (i == 6) Mint.fill else CreamCard, u * 0.15f, w * 0.8f)
        }
    }
    // Tick draws over the last bar, then the count lands.
    val tick = ease(seg(t, 1250f, 380f))
    if (tick > 0f) {
        val pts = listOf(Offset(c.x + u * 1.6f, c.y - u * 2.6f), Offset(c.x + u * 2.1f, c.y - u * 2.1f), Offset(c.x + u * 3.1f, c.y - u * 3.2f))
        val first = (tick * 2f).coerceAtMost(1f)
        drawLine(Ink, pts[0], pts[0] + (pts[1] - pts[0]) * first, w * 2f, StrokeCap.Round)
        if (tick > 0.5f) drawLine(Ink, pts[1], pts[1] + (pts[2] - pts[1]) * ((tick - 0.5f) * 2f), w * 2f, StrokeCap.Round)
    }
    val land = ease(seg(t, 1500f, 420f))
    if (land > 0f) {
        val center = Offset(c.x - u * 1.3f, c.y - u * 2.7f + (1f - land) * u)
        val days = (7 * land).toInt().coerceAtLeast(1)
        stamp(m, "$days DAYS", center, 22, Ink.copy(alpha = land))
    }
    // A slow idle shimmer so the last story is never a still frame.
    val sh = (t / 2600f) % 1f
    drawCircle(CreamCard.copy(alpha = 0.18f), u * 1.2f, Offset(c.x - totalW / 2f + totalW * sh, base - u * 2f))
}

