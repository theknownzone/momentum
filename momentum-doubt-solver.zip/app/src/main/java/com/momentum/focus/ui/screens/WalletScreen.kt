package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.R
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.theme.lighten
import com.momentum.focus.data.Currency
import com.momentum.focus.data.FocusSession
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.i18n.Strings
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import java.time.LocalDate
import kotlin.math.roundToInt

private data class Txn(
    val title: String,
    val when_: String,
    val amount: String,
    val credit: Boolean,
)

/**
 * The wallet.
 *
 * Modelled on a payments app on purpose: a dark banner with the illustration
 * and balance, then a plain ledger underneath. Seeing earnings and spends in
 * one column is what makes the trade real — a balance alone hides the fact
 * that something was paid for it.
 */
@Composable
fun WalletScreen(
    data: AppData,
    onEarn: () -> Unit,
) {
    val str = strings()
    val balance = data.balanceMinutes
    val animated by animateFloatAsState(
        balance.toFloat(), Motion.settle(), label = "wallet"
    )

    val ledger = remember(data, str) { buildLedger(data, str) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState()),
    ) {
        // ---- banner ----
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(
                    Brush.verticalGradient(listOf(Color_Banner_Top, Color_Banner_Bottom))
                )
                .statusBarsPadding()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 18.dp, bottom = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(
                painter = painterResource(R.drawable.wallet_hero),
                contentDescription = null,
                modifier = Modifier.size(140.dp),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                str.wallet.yourBalance,
                style = MaterialTheme.typography.labelSmall,
                color = Butter.fill,
            )
            Spacer(Modifier.height(4.dp))
            // A pool of light behind the number, and the number lit rather
            // than white.
            //
            // The figure was plain CreamCard on the dark banner — legible, and
            // completely inert. It is the one number the whole app is built to
            // move, and it looked like a caption. The reference this is taken
            // from does the same thing with a score: the digits carry the
            // accent colour and sit in a soft glow of it, so the eye lands
            // there before anywhere else on the screen.
            //
            // The glow is drawn behind rather than as a background on the text,
            // so it spills past the digits instead of ending at a box.
            Box(contentAlignment = Alignment.Center) {
                Canvas(Modifier.matchParentSize()) {
                    val r = size.maxDimension * 0.72f
                    drawCircle(
                        brush = Brush.radialGradient(
                            colorStops = arrayOf(
                                0f to Butter.fill.copy(alpha = 0.42f),
                                0.5f to Butter.fill.copy(alpha = 0.16f),
                                1f to Color.Transparent,
                            ),
                            center = center,
                            radius = r,
                        ),
                        radius = r,
                    )
                }
                Text(
                    Currency.format(animated.roundToInt()),
                    style = MaterialTheme.typography.displayLarge,
                    color = Butter.fill,
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                if (balance == 0)
                    str.wallet.nothingBanked
                else
                    str.wallet.balancePaidFor(balance / 60, balance % 60),
                style = MaterialTheme.typography.bodyMedium,
                color = InkLow,
                textAlign = TextAlign.Center,
            )

            Spacer(Modifier.height(18.dp))

            MetallicButton(
                label = str.wallet.earnMore,
                modifier = Modifier.fillMaxWidth(),
                onClick = onEarn,
            )
        }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 20.dp, bottom = 28.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(Paper.Gap)) {
                // EARNED was printing raw study minutes with a rupee sign on
                // it while SPENT was real rupees, so the two headline numbers
                // never reconciled with the balance underneath them — earned
                // ₹800, spent ₹50, balance ₹66.
                Summary(str.wallet.earned, Currency.format(data.earnedRupees), Mint, Modifier.weight(1f))
                Summary(str.wallet.spent, Currency.format(data.spentMinutes), Tang, Modifier.weight(1f))
            }

            Spacer(Modifier.height(14.dp))

            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(CreamCard)
                    .border(2.dp, Ink, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Text(str.wallet.exchangeRate, style = MaterialTheme.typography.labelSmall, color = InkMid)
                Spacer(Modifier.height(4.dp))
                Text(
                    str.wallet.rateLine(data.effectiveRatio, Currency.format(1)),
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                )
                if (data.weekendRelaxed && data.isWeekend) {
                    Text(
                        str.wallet.weekendRate,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mint.accent,
                    )
                }
            }

            Spacer(Modifier.height(22.dp))

            Text(str.wallet.transactions, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(10.dp))

            if (ledger.isEmpty()) {
                Text(
                    str.wallet.noTransactions,
                    style = MaterialTheme.typography.bodyLarge,
                    color = InkMid,
                )
            } else {
                ledger.forEach { t -> LedgerRow(t) }
            }
        }
    }
}

private val Color_Banner_Top = androidx.compose.ui.graphics.Color(0xFF1E1A10)
private val Color_Banner_Bottom = androidx.compose.ui.graphics.Color(0xFF12100A)

@Composable
private fun Summary(
    label: String,
    value: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(sticker.fill)
            .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = sticker.on.copy(alpha = 0.75f))
        Spacer(Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.displayMedium, color = sticker.on)
    }
}

@Composable
private fun LedgerRow(t: Txn) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(if (t.credit) Mint.fill else Tang.fill)
                .border(2.dp, Ink, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                if (t.credit) "+" else "−",
                style = MaterialTheme.typography.titleMedium,
                color = if (t.credit) Mint.on else Tang.on,
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, style = MaterialTheme.typography.titleMedium, color = Ink)
            Text(t.when_, style = MaterialTheme.typography.bodyMedium, color = InkMid)
        }
        Text(
            t.amount,
            style = MaterialTheme.typography.titleMedium,
            color = if (t.credit) Mint.accent else Tang.accent,
        )
    }
}

private fun buildLedger(data: AppData, str: Strings): List<Txn> {
    val today = LocalDate.now().toEpochDay()
    fun ago(day: Long) = when (val d = (today - day).toInt()) {
        0 -> str.common.today
        1 -> str.common.yesterday
        else -> str.common.daysAgo(d)
    }

    val credits = data.sessions.filter { it.completed }.takeLast(10).reversed()
        .map { session: FocusSession ->
            Txn(
                title = str.wallet.studied(session.subject),
                when_ = "${ago(session.startedAtEpochDay)} · ${session.minutes} min",
                amount = "+${Currency.format(session.minutes / data.effectiveRatio.coerceAtLeast(1))}",
                credit = true,
            )
        }

    val debits = data.slips.takeLast(10).reversed().map { slip ->
        Txn(
            title = str.wallet.unlockedAnApp,
            when_ = "${ago(slip.epochDay)} · ${slip.reason.lowercase()}",
            amount = "−${Currency.format(10)}",
            credit = false,
        )
    }

    return (credits + debits).take(14)
}

/**
 * The 3D metallic bevel button from the reference — a curved-surface
 * gradient, a bright top-edge highlight, and a subtle press-in feel,
 * rather than SquishButton's flat sticker fill. Kept to this one screen's
 * one button rather than replacing SquishButton itself, which every
 * other button in the app still uses and is tuned for a flatter,
 * paper-and-ink look this metal finish doesn't belong on.
 */
@Composable
private fun MetallicButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, tween(120), label = "metallic-scale")

    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(if (pressed) 3.dp else 9.dp, RoundedCornerShape(16.dp), clip = false)
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Mint.accent.lighten(0.14f), Mint.fill, Mint.accent),
                ),
            )
            .drawBehind {
                drawLine(
                    Color.White.copy(alpha = 0.5f),
                    Offset(size.width * 0.08f, 2.dp.toPx()),
                    Offset(size.width * 0.92f, 2.dp.toPx()),
                    strokeWidth = 1.5.dp.toPx(),
                )
            }
            .border(1.dp, Ink, RoundedCornerShape(16.dp))
            .clickableNoRipple(interaction) { haptics.confirm(); onClick() }
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Mint.on)
    }
}
