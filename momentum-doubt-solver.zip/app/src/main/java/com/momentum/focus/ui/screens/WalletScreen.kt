package com.momentum.focus.ui.screens

import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import com.momentum.focus.R
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.theme.lighten
import com.momentum.focus.data.Currency
import com.momentum.focus.data.FocusSession
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.i18n.Strings
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import java.time.LocalDate
import kotlin.math.roundToInt

private data class Txn(
    val title: String,
    val when_: String,
    val amount: String,
    val credit: Boolean,
)

/**
 * The wallet.
 *
 * Modelled on a payments app on purpose: a dark banner with the illustration
 * and balance, then a plain ledger underneath. Seeing earnings and spends in
 * one column is what makes the trade real — a balance alone hides the fact
 * that something was paid for it.
 */
/** Process-lifetime memory of the last balance this screen showed. */
private var lastSeenWalletBalance: Int? = null

@Composable
fun WalletScreen(
    data: AppData,
    onEarn: () -> Unit,
) {
    val str = strings()
    val balance = data.balanceMinutes
    val animated by animateFloatAsState(
        balance.toFloat(), Motion.settle(), label = "wallet"
    )

    val ledger = remember(data, str) { buildLedger(data, str) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState()),
    ) {
        // ---- banner ----
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(
                    Brush.verticalGradient(listOf(Color_Banner_Top, Color_Banner_Bottom))
                )
                .statusBarsPadding()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 18.dp, bottom = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // v5: the cartoon wallet and floating gem are gone. One gold
            // object carries the screen: a coin that spins in, settles, and
            // keeps a slow 3D turn inside two orbit rings with gold dust; the
            // balance counts up in lit gold beneath it with a single shine.
            var shown by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { shown = true }
            val inK by animateFloatAsState(if (shown) 1f else 0f, tween(700, easing = FastOutSlowInEasing), label = "walletIn")
            val spin by com.momentum.focus.ui.components.ambient(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "coinSpin")
            val orbit by com.momentum.focus.ui.components.ambient(0f, 360f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "orbit")
            val bob by com.momentum.focus.ui.components.ambient(0f, 1f, infiniteRepeatable(tween(2600), RepeatMode.Reverse), label = "bob")
            Spacer(Modifier.height(8.dp))
            Text(
                str.wallet.yourBalance,
                style = MaterialTheme.typography.labelSmall,
                letterSpacing = 2.sp,
                color = Butter.fill,
                modifier = Modifier.graphicsLayer { alpha = inK },
            )
            Box(Modifier.size(200.dp).graphicsLayer { alpha = inK; translationY = (1f - inK) * 20.dp.toPx() }, contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = center
                    drawCircle(Brush.radialGradient(listOf(Color(0xFFFFC94D).copy(alpha = 0.30f), Color.Transparent), c, size.minDimension / 2), size.minDimension / 2, c)
                    // two tilted orbit rings
                    for (k in 0..1) {
                        rotate(orbit * (if (k == 0) 1f else -0.7f) + k * 60f, c) {
                            scale(1f, 0.32f, c) {
                                drawCircle(Color(0xFFFFD27A).copy(alpha = 0.35f - k * 0.12f), size.minDimension * (0.40f + k * 0.07f), c, style = Stroke(2.dp.toPx()))
                            }
                        }
                    }
                    // gold dust on the orbit
                    for (i in 0 until 14) {
                        val a = Math.toRadians((orbit * 1.3f + i * 25.7f).toDouble())
                        val rx = size.minDimension * 0.42f; val ry = rx * 0.32f
                        val p = Offset(c.x + (kotlin.math.cos(a) * rx).toFloat(), c.y + (kotlin.math.sin(a) * ry).toFloat())
                        drawCircle(Color(0xFFFFE7A3).copy(alpha = 0.3f + 0.5f * ((i % 3) / 2f)), (1f + (i % 3)).dp.toPx(), p)
                    }
                }
                // the coin: 3D turn = horizontal squash by |cos|
                val turn = kotlin.math.cos(Math.toRadians(spin.toDouble())).toFloat()
                Box(
                    Modifier
                        .size(96.dp)
                        .graphicsLayer {
                            scaleX = 0.12f + 0.88f * kotlin.math.abs(turn)
                            translationY = (bob - 0.5f) * 8.dp.toPx()
                            val drop = 1f - inK; rotationZ = drop * 180f
                        }
                        .drawBehind {
                            val r = size.minDimension / 2
                            drawCircle(Color(0xFF8A5A10), r, center + Offset(0f, 4.dp.toPx()))
                            drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF1C2), Color(0xFFF4CB5A), Color(0xFFB57A1C)), center + Offset(-r * 0.3f, -r * 0.35f), r * 1.4f), r)
                            drawCircle(Color(0xFF8A5A10).copy(alpha = 0.6f), r * 0.78f, style = Stroke(3.dp.toPx()))
                            drawCircle(Color.White.copy(alpha = 0.35f), r * 0.2f, center + Offset(-r * 0.4f, -r * 0.45f))
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    if (kotlin.math.abs(turn) > 0.35f) Text("₹", fontSize = 44.sp, fontWeight = FontWeight.Black, color = Color(0xFF8A5A10))
                }
            }
            // balance: lit gold, counts up, one shine pass when it lands
            val shine = remember { androidx.compose.animation.core.Animatable(0f) }
            // Balance ray (Uiverse card ray): if the balance grew since this
            // screen was last seen, the ray fires again and an "aura +₹X" chip
            // floats up off the number. Display only.
            val gained = remember {
                val prev = lastSeenWalletBalance
                lastSeenWalletBalance = balance
                if (prev != null && balance > prev) balance - prev else 0
            }
            val rise = remember { androidx.compose.animation.core.Animatable(if (gained > 0) 0f else 1f) }
            LaunchedEffect(Unit) {
                kotlinx.coroutines.delay(900)
                if (gained > 0) launch { rise.animateTo(1f, tween(1400, easing = FastOutSlowInEasing)) }
                shine.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
            }
            Box(contentAlignment = Alignment.Center, modifier = Modifier.graphicsLayer { alpha = inK; val sc = 0.85f + 0.15f * inK; scaleX = sc; scaleY = sc }) {
                Canvas(Modifier.matchParentSize()) {
                    val r = size.maxDimension * 0.72f
                    drawCircle(Brush.radialGradient(listOf(Butter.fill.copy(alpha = 0.32f), Color.Transparent), center, r), r)
                }
                Text(
                    Currency.format(animated.roundToInt()),
                    style = MaterialTheme.typography.displayLarge.copy(
                        brush = Brush.linearGradient(listOf(Color(0xFFFFF1C2), Color(0xFFF4CB5A), Color(0xFFC68B1E))),
                    ),
                    modifier = Modifier
                        .graphicsLayer { compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.Offscreen }
                        .drawWithContent {
                            drawContent()
                            val p = shine.value
                            if (p in 0.001f..0.999f) {
                                val x = size.width * (-0.3f + 1.6f * p)
                                drawRect(
                                    Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.8f), Color.Transparent), Offset(x - 40f, 0f), Offset(x + 40f, size.height)),
                                    blendMode = androidx.compose.ui.graphics.BlendMode.SrcAtop,
                                )
                            }
                        },
                )
            }
            if (gained > 0) {
                Text(
                    "aura +" + Currency.format(gained),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black,
                    color = Ink,
                    modifier = Modifier
                        .graphicsLayer {
                            val r = rise.value
                            translationY = -28.dp.toPx() * r
                            alpha = if (r < 0.7f) 1f else (1f - r) / 0.3f
                            rotationZ = -4f
                        }
                        .drawBehind {
                            val d = 2.dp.toPx() * com.momentum.focus.ui.theme.Vibe.shadow
                            drawRoundRect(Ink, Offset(d, d), size, androidx.compose.ui.geometry.CornerRadius(size.height / 2))
                        }
                        .clip(RoundedCornerShape(999.dp))
                        .background(Mint.fill)
                        .border(2.dp, Ink, RoundedCornerShape(999.dp))
                        .padding(horizontal = 10.dp, vertical = 3.dp),
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                if (balance == 0)
                    str.wallet.nothingBanked
                else
                    str.wallet.balancePaidFor(balance / 60, balance % 60),
                style = MaterialTheme.typography.bodyMedium,
                color = InkLow,
                textAlign = TextAlign.Center,
            )

            Spacer(Modifier.height(18.dp))

            MetallicButton(
                label = str.wallet.earnMore,
                modifier = Modifier.fillMaxWidth(),
                onClick = onEarn,
            )
        }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 20.dp, bottom = 28.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(Paper.Gap)) {
                // EARNED was printing raw study minutes with a rupee sign on
                // it while SPENT was real rupees, so the two headline numbers
                // never reconciled with the balance underneath them — earned
                // ₹800, spent ₹50, balance ₹66.
                Summary(str.wallet.earned, Currency.format(data.earnedRupees), Mint, Modifier.weight(1f))
                Summary(str.wallet.spent, Currency.format(data.spentMinutes), Tang, Modifier.weight(1f))
            }

            Spacer(Modifier.height(14.dp))

            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(CreamCard)
                    .border(2.dp, Ink, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Text(str.wallet.exchangeRate, style = MaterialTheme.typography.labelSmall, color = InkMid)
                Spacer(Modifier.height(4.dp))
                Text(
                    str.wallet.rateLine(data.effectiveRatio, Currency.format(1)),
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                )
                if (data.weekendRelaxed && data.isWeekend) {
                    Text(
                        str.wallet.weekendRate,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mint.accent,
                    )
                }
            }

            Spacer(Modifier.height(22.dp))

            Text(str.wallet.transactions, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(10.dp))

            if (ledger.isEmpty()) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(Paper.CardRadius))
                        .background(CreamCard)
                        .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("📒", style = MaterialTheme.typography.displayMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        str.wallet.noTransactions,
                        style = MaterialTheme.typography.bodyLarge,
                        color = InkMid,
                        textAlign = TextAlign.Center,
                    )
                }
            } else {
                ledger.forEach { t -> LedgerRow(t) }
            }
        }
    }
}

private val Color_Banner_Top = androidx.compose.ui.graphics.Color(0xFF1E1A10)
private val Color_Banner_Bottom = androidx.compose.ui.graphics.Color(0xFF12100A)

@Composable
private fun Summary(
    label: String,
    value: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(sticker.fill)
            .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = sticker.on.copy(alpha = 0.75f))
        Spacer(Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.displayMedium, color = sticker.on)
    }
}

@Composable
private fun LedgerRow(t: Txn) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(if (t.credit) Mint.fill else Tang.fill)
                .border(2.dp, Ink, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                if (t.credit) "+" else "−",
                style = MaterialTheme.typography.titleMedium,
                color = if (t.credit) Mint.on else Tang.on,
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, style = MaterialTheme.typography.titleMedium, color = Ink)
            Text(t.when_, style = MaterialTheme.typography.bodyMedium, color = InkMid)
        }
        Text(
            t.amount,
            style = MaterialTheme.typography.titleMedium,
            color = if (t.credit) Mint.accent else Tang.accent,
        )
    }
}

private fun buildLedger(data: AppData, str: Strings): List<Txn> {
    val today = LocalDate.now().toEpochDay()
    fun ago(day: Long) = when (val d = (today - day).toInt()) {
        0 -> str.common.today
        1 -> str.common.yesterday
        else -> str.common.daysAgo(d)
    }

    val credits = data.sessions.filter { it.completed }.takeLast(10).reversed()
        .map { session: FocusSession ->
            Txn(
                title = str.wallet.studied(session.subject),
                when_ = "${ago(session.startedAtEpochDay)} · ${session.minutes} min",
                amount = "+${Currency.format(session.minutes / data.effectiveRatio.coerceAtLeast(1))}",
                credit = true,
            )
        }

    val debits = data.slips.takeLast(10).reversed().map { slip ->
        Txn(
            title = str.wallet.unlockedAnApp,
            when_ = "${ago(slip.epochDay)} · ${slip.reason.lowercase()}",
            amount = "−${Currency.format(10)}",
            credit = false,
        )
    }

    return (credits + debits).take(14)
}

/**
 * The 3D metallic bevel button from the reference — a curved-surface
 * gradient, a bright top-edge highlight, and a subtle press-in feel,
 * rather than SquishButton's flat sticker fill. Kept to this one screen's
 * one button rather than replacing SquishButton itself, which every
 * other button in the app still uses and is tuned for a flatter,
 * paper-and-ink look this metal finish doesn't belong on.
 */
@Composable
private fun MetallicButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, tween(120), label = "metallic-scale")

    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(if (pressed) 3.dp else 9.dp, RoundedCornerShape(16.dp), clip = false)
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Mint.accent.lighten(0.14f), Mint.fill, Mint.accent),
                ),
            )
            .drawBehind {
                drawLine(
                    Color.White.copy(alpha = 0.5f),
                    Offset(size.width * 0.08f, 2.dp.toPx()),
                    Offset(size.width * 0.92f, 2.dp.toPx()),
                    strokeWidth = 1.5.dp.toPx(),
                )
            }
            .border(1.dp, Ink, RoundedCornerShape(16.dp))
            .clickableNoRipple(interaction) { haptics.confirm(); onClick() }
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Mint.on)
    }
}

/**
 * The gold-investment app reference the user sent: a floating cut-gem
 * over concentric pulsing rings. Recoloured to this app's own Butter/gold
 * token rather than the reference's orange, and sized to sit above the
 * balance figure as a crown rather than as its own screen.
 */
@Composable
fun FloatingGoldGem(modifier: Modifier = Modifier) {
    val tumble by com.momentum.focus.ui.components.ambient(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Restart),
        label = "gem-tumble",
    )
    val ringPhase by com.momentum.focus.ui.components.ambient(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart),
        label = "gem-ring",
    )
    val bob = kotlin.math.sin(tumble * 2f * Math.PI.toFloat()) * 6f
    val squeezeRaw = kotlin.math.sin(tumble * 4f * Math.PI.toFloat())
    val squeeze = 1f - 0.16f * (if (squeezeRaw < 0f) 0f else squeezeRaw)

    val sparkleT by com.momentum.focus.ui.components.ambient(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart),
        label = "gem-sparkle",
    )
    val rayT by com.momentum.focus.ui.components.ambient(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
        label = "gem-rays",
    )

    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            // 8 rays fanning out from the gem's centre, each fading in and
            // out on its own offset phase rather than all firing together.
            repeat(8) { i ->
                val angle = i * (360f / 8) * (Math.PI.toFloat() / 180f)
                val phase = (rayT + i / 8f) % 1f
                val alpha = (kotlin.math.sin(phase * Math.PI.toFloat())).coerceIn(0f, 1f) * 0.5f
                val len = size.height * 0.32f
                val cx = center.x
                val cy = size.height * 0.42f
                drawLine(
                    color = Butter.fill.copy(alpha = alpha),
                    start = Offset(cx, cy),
                    end = Offset(cx + kotlin.math.cos(angle) * len, cy + kotlin.math.sin(angle) * len),
                    strokeWidth = 1.5.dp.toPx(),
                )
            }
            // 6 twinkling sparkles at fixed positions around the gem.
            val sparklePositions = listOf(
                0.18f to 0.15f, 0.82f to 0.22f, 0.10f to 0.58f,
                0.90f to 0.62f, 0.30f to 0.05f, 0.68f to 0.72f,
            )
            sparklePositions.forEachIndexed { i, (fx, fy) ->
                val phase = (sparkleT + i * 0.17f) % 1f
                val alpha = (kotlin.math.sin(phase * Math.PI.toFloat())).coerceIn(0f, 1f)
                if (alpha > 0.05f) {
                    val px = size.width * fx
                    val py = size.height * fy
                    val r = 3.dp.toPx() * alpha
                    drawLine(Butter.fill.copy(alpha = alpha), Offset(px - r, py), Offset(px + r, py), strokeWidth = 1.5.dp.toPx())
                    drawLine(Butter.fill.copy(alpha = alpha), Offset(px, py - r), Offset(px, py + r), strokeWidth = 1.5.dp.toPx())
                }
            }
            // Three rings at staggered phase, expanding and fading — same
            // "sound wave rising from underneath" read as the reference.
            repeat(3) { i ->
                val phase = (ringPhase + i / 3f) % 1f
                val ringAlpha = (1f - phase) * 0.55f
                if (ringAlpha > 0.01f) {
                    val ringWidth = size.width * (0.18f + phase * 0.55f)
                    drawOval(
                        color = Butter.fill.copy(alpha = ringAlpha),
                        topLeft = Offset(center.x - ringWidth / 2f, size.height * 0.86f),
                        size = Size(ringWidth, ringWidth * 0.16f),
                        style = Stroke(width = 2.dp.toPx()),
                    )
                }
            }
        }
        Canvas(
            Modifier
                .size(30.dp, 38.dp)
                .graphicsLayer { translationY = bob; scaleX = squeeze },
        ) {
            val w = size.width
            val h = size.height
            val gem = Path().apply {
                moveTo(w * 0.5f, 0f)
                lineTo(w, h * 0.34f)
                lineTo(w * 0.8f, h)
                lineTo(w * 0.2f, h)
                lineTo(0f, h * 0.34f)
                close()
            }
            drawPath(
                gem,
                brush = Brush.linearGradient(
                    listOf(Color(0xFFFFE9A8), Butter.fill, Color(0xFFC68B1E)),
                    start = Offset(0f, 0f), end = Offset(w, h),
                ),
            )
            drawPath(gem, color = Ink, style = Stroke(width = 2.dp.toPx()))
            drawLine(
                color = Color.White.copy(alpha = 0.55f),
                start = Offset(w * 0.36f, h * 0.12f),
                end = Offset(w * 0.36f, h * 0.42f),
                strokeWidth = 2.dp.toPx(),
            )
        }
    }
}
