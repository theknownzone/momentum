package com.momentum.focus.ui.components

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.delay
import com.momentum.focus.ui.theme.Mint
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import kotlin.math.sin
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.runtime.DisposableEffect
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.block.Admin
import com.momentum.focus.ui.util.Perm
import com.momentum.focus.ui.util.Perms

/**
 * What is switched off, and what that costs.
 *
 * The app has features that quietly do nothing without a permission: the
 * shield needs accessibility, screen time needs usage access, Crown needs
 * device admin. Until now each one failed in silence — the switch went on, the
 * screen looked normal, and the blocking simply never happened. Someone in
 * that state has no way to tell a broken app from an unconfigured one, and
 * they blame the app.
 *
 * One banner, one problem at a time, in the language the app is already
 * speaking. It says which feature is dead and offers the screen that fixes it,
 * and it is gone the moment the permission is granted — nothing to dismiss.
 */
@Composable
fun BrokenNotice(data: AppData, onFix: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val str = strings()

    // Permissions are granted on a system screen, so the only honest way to
    // know the current state is to re-read on every resume.
    val owner = LocalLifecycleOwner.current
    var refresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) refresh++
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val problem = remember(refresh, data.shieldOn, data.crownMode) {
        when {
            // Ordered by how much is broken, so the worst thing is the one
            // shown. Listing three at once is a wall nobody reads.
            // Overlay first: without it the shield can decide to block and
            // then has no way to put anything on the screen, which is the most
            // complete kind of silent failure in the app.
            data.shieldOn && !Perms.granted(context, Perm.OVERLAY) -> Trouble.Shield
            !Perms.granted(context, Perm.USAGE_ACCESS) -> Trouble.Usage
            data.crownMode && !Admin.isActive(context) -> Trouble.Crown
            else -> null
        }
    }

    // Was broken, now is not: say so once instead of the banner just vanishing.
    //
    // A notice that disappears silently leaves someone wondering whether the
    // permission actually took or the app simply stopped complaining. One line
    // confirming it, for a few seconds, closes that loop.
    var wasBroken by remember { mutableStateOf(false) }
    var justFixed by remember { mutableStateOf(false) }
    LaunchedEffect(problem) {
        if (problem != null) {
            wasBroken = true
        } else if (wasBroken) {
            wasBroken = false
            justFixed = true
            delay(3500)
            justFixed = false
        }
    }

    if (problem == null) {
        if (!justFixed) return
        Row(
            modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(Mint.fill)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TileObject(art = TileArt.Shield, fill = Mint.accent, size = 28.dp)
            Spacer(Modifier.width(12.dp))
            Text(
                str.trouble.allGood,
                style = MaterialTheme.typography.titleMedium,
                color = Mint.on,
            )
        }
        return
    }

    val (title, body) = when (problem) {
        Trouble.Shield -> str.trouble.shieldTitle to str.trouble.shieldBody
        Trouble.Usage -> str.trouble.usageTitle to str.trouble.usageBody
        Trouble.Crown -> str.trouble.crownTitle to str.trouble.crownBody
    }

    // A one-time shake when the warning first appears — the reference's
    // hover-triggered alarm shake, moved to "just arrived" since a touch
    // screen has no hover to trigger it with.
    var shakeT by remember { mutableFloatStateOf(1f) }
    LaunchedEffect(problem) {
        if (problem != null) {
            shakeT = 0f
            val start = withFrameNanos { it }
            while (shakeT < 1f) {
                withFrameNanos { now -> shakeT = ((now - start) / 1_000_000f / 400f).coerceIn(0f, 1f) }
            }
        }
    }
    val shakeX = if (shakeT < 1f) {
        (sin(shakeT * 40f) * (1f - shakeT) * 6f)
    } else 0f

    Row(
        modifier
            .fillMaxWidth()
            .graphicsLayer { translationX = shakeX }
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(Tang.fill)
            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                // Straight to the one screen that fixes this, not to a list of
                // permissions with this one somewhere in it.
                //
                // Android will not let an app grant itself anything, so the
                // most "repair" can mean here is removing every step between
                // the problem and the switch. Handing someone the permissions
                // page and letting them find the right row is where people
                // give up — especially on the Chinese ROMs, where the toggle
                // is three menus deep under a different name.
                val intent = when (problem) {
                    Trouble.Shield -> Perms.intentFor(context, Perm.OVERLAY)
                    Trouble.Usage -> Perms.intentFor(context, Perm.USAGE_ACCESS)
                    Trouble.Crown -> Admin.requestIntent(context)
                }
                val opened = intent != null && runCatching {
                    context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }.isSuccess
                // If the direct route is refused — some ROMs block the deep
                // link — fall back to the app's own permissions screen rather
                // than doing nothing, which is the one outcome that looks
                // broken.
                if (!opened) onFix()
            }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        WarningTriangle(size = 32.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = Tang.on)
            Spacer(Modifier.height(2.dp))
            Text(
                body,
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.on.copy(alpha = 0.85f),
            )
        }
        Text(
            str.trouble.fix,
            style = MaterialTheme.typography.titleMedium,
            color = Tang.on,
            modifier = Modifier.padding(start = 8.dp),
        )
    }
}

private enum class Trouble { Shield, Usage, Crown }

/**
 * The warning-triangle-plus-exclamation from the reference, in place of
 * the generic shield icon this banner used regardless of which of the
 * three things was actually broken — a warning about something being
 * wrong should look like a warning, not like the same shield the rest of
 * the app uses for "this is protecting you".
 */
@Composable
private fun WarningTriangle(size: Dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val path = Path().apply {
            moveTo(w * 0.5f, h * 0.08f)
            lineTo(w * 0.95f, h * 0.90f)
            lineTo(w * 0.05f, h * 0.90f)
            close()
        }
        drawPath(path, color = Color(0xFFFFD84D))
        drawPath(path, color = Ink, style = Stroke(width = w * 0.06f))
        val barTop = h * 0.36f
        val barBottom = h * 0.60f
        drawLine(
            Ink,
            Offset(w * 0.5f, barTop),
            Offset(w * 0.5f, barBottom),
            strokeWidth = w * 0.10f,
            cap = StrokeCap.Round,
        )
        drawCircle(Ink, radius = w * 0.055f, center = Offset(w * 0.5f, h * 0.75f))
    }
}

private enum class Trouble { Shield, Usage, Crown }
