package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ai.AnswerStyle
import com.momentum.focus.ai.MyAiMode
import com.momentum.focus.data.tr
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics

/*
 * MyAI chrome, 2026-10-07 redesign (owner: page cramped, answer area tiny on
 * small phones, mode switcher in a bad place).
 *
 * Before: back/tune row (46dp) + count bar (~38) + LED board (~42) + length/
 * language toggles (~36) + speak/count row (~26) stacked over the chat —
 * ~190dp of controls before the first word of an answer.
 * Now: two slim rows, ~84dp total, and everything else is one tap away.
 *
 *   [←]  [ LED: WELCOME, RAHUL • ASK ANY DOUBT • 7 LEFT ]  [share]
 *   [ Study | Dost | Guru ]                         [≡ Normal · EN]
 */

/** Mode → sticker, label, one-liner. One place, so the bar and sheet agree. */
internal fun MyAiMode.sticker(): Sticker = when (this) {
    MyAiMode.Study -> Mint
    MyAiMode.Friend -> Lilac
    MyAiMode.Guru -> Butter
}

@Composable
internal fun MyAiMode.label(): String = when (this) {
    MyAiMode.Study -> strings().doubt.modeStudy
    MyAiMode.Friend -> strings().doubt.modeFriend
    MyAiMode.Guru -> strings().doubt.modeGuru
}

@Composable
internal fun MyAiMode.what(): String = when (this) {
    MyAiMode.Study -> strings().doubt.modeStudyWhat
    MyAiMode.Friend -> strings().doubt.modeFriendWhat
    MyAiMode.Guru -> strings().doubt.modeGuruWhat
}

/** LED text is Latin-only (5×7 font), so it always uses these words. */
internal fun MyAiMode.ledWord(): String = when (this) {
    MyAiMode.Study -> "STUDY"
    MyAiMode.Friend -> "DOST"
    MyAiMode.Guru -> "GURU"
}

@Composable
fun MyAiTopBar(
    ledText: String,
    ledState: LedState,
    marquee: Boolean,
    canShare: Boolean,
    onBack: () -> Unit,
    onShare: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 4.dp, end = 4.dp, top = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconTap(onBack) {
            Icon(
                Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = strings().doubt.close,
                tint = Ink,
                modifier = Modifier.size(22.dp),
            )
        }
        LedSign(
            text = ledText,
            color = ledState.color,
            icon = ledState.icon,
            marquee = marquee,
            scanning = ledState == LedState.THINKING || ledState == LedState.WRITING,
            height = 32.dp,
            modifier = Modifier.weight(1f),
        )
        // Share keeps its slot even when there is nothing to share, so the
        // LED sign does not jump sideways after the first answer.
        IconTap(onShare, enabled = canShare) {
            Icon(
                Icons.Filled.IosShare,
                contentDescription = strings().doubt.export,
                tint = Ink.copy(alpha = if (canShare) 1f else 0.25f),
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

@Composable
private fun IconTap(onClick: () -> Unit, enabled: Boolean = true, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickableNoRipple(remember { MutableInteractionSource() }, enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center,
    ) { content() }
}

/**
 * Mode switch + answer-style chip. The switch is a segmented pill with an
 * ink-edged sticker thumb that springs to the chosen mode — one tap, always
 * visible, no sheet to open for the most-used control. Locked modes carry a
 * small lock and open Plans instead.
 */
@Composable
fun MyAiControlBar(
    mode: MyAiMode,
    premium: Boolean,
    onMode: (MyAiMode) -> Unit,
    onPlans: () -> Unit,
    onStyle: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ModeSwitch(mode, premium, onMode, onPlans)
        Spacer(Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        StyleChip(onStyle)
    }
}

private val SegW = 62.dp
private val SegH = 34.dp

@Composable
private fun ModeSwitch(
    mode: MyAiMode,
    premium: Boolean,
    onMode: (MyAiMode) -> Unit,
    onPlans: () -> Unit,
) {
    val haptics = rememberHaptics()
    val shape = RoundedCornerShape(50)
    val thumbX by animateDpAsState(
        SegW * mode.ordinal,
        spring(dampingRatio = 0.72f, stiffness = 520f),
        label = "modeThumb",
    )
    Box(
        Modifier
            .width(SegW * 3 + 4.dp)
            .height(SegH + 4.dp)
            .clip(shape)
            .background(CreamCard)
            .border(2.dp, Ink, shape)
            .padding(2.dp),
    ) {
        // The thumb: the chosen mode's sticker colour, inked edge.
        Box(
            Modifier
                .offset(x = thumbX)
                .size(SegW, SegH)
                .clip(shape)
                .background(mode.sticker().fill)
                .border(1.5.dp, Ink, shape),
        )
        Row {
            MyAiMode.entries.forEach { item ->
                val locked = item != MyAiMode.Study && !premium
                val on = item == mode
                Row(
                    Modifier
                        .size(SegW, SegH)
                        .clip(shape)
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            when {
                                on -> Unit
                                locked -> { haptics.tick(); onPlans() }
                                else -> {
                                    haptics.tick()
                                    Sfx.play(Sound.TOGGLE)
                                    onMode(item)
                                }
                            }
                        },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        item.label(),
                        fontSize = 13.sp,
                        fontWeight = if (on) FontWeight.Black else FontWeight.Bold,
                        color = if (on) item.sticker().on else Ink.copy(alpha = if (locked) 0.45f else 0.8f),
                        maxLines = 1,
                    )
                    if (locked) {
                        Spacer(Modifier.width(2.dp))
                        Icon(
                            Icons.Filled.Lock,
                            contentDescription = strings().doubt.proTag,
                            tint = Ink.copy(alpha = 0.45f),
                            modifier = Modifier.size(11.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StyleChip(onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val len = when (AnswerStyle.length) {
        AnswerStyle.SHORT -> tr("Short", "छोटा")
        AnswerStyle.DEEP -> tr("Deep", "डीप")
        else -> tr("Normal", "नॉर्मल")
    }
    val lang = if (AnswerStyle.hinglish) "Hinglish" else "EN"
    Row(
        Modifier
            .height(SegH + 4.dp)
            .clip(shape)
            .background(CreamCard)
            .border(2.dp, Ink, shape)
            .clickableNoRipple(remember { MutableInteractionSource() }) { onClick() }
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Tune, contentDescription = null, tint = Ink, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(5.dp))
        Text(
            "$len · $lang",
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Bold,
            color = Ink,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 104.dp),
        )
    }
}

/**
 * Everything about HOW MyAI answers, in one sheet: length, language, mode
 * (with what each mode actually means — the switch alone never said), and
 * the question count. Rule-compliant overlay: FitDialog, Ink dim behind,
 * opaque Cream sheet capped at 82%, body scrolls, Done pinned.
 */
@Composable
fun AnswerStyleSheet(
    mode: MyAiMode,
    premium: Boolean,
    left: Int,
    aiOff: Boolean,
    onMode: (MyAiMode) -> Unit,
    onPlans: () -> Unit,
    onClose: () -> Unit,
) {
    val haptics = rememberHaptics()
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val lift by animateDpAsState(if (shown) 0.dp else 40.dp, spring(dampingRatio = 0.85f, stiffness = 420f), label = "sheetLift")
    FitDialog(onDismiss = onClose) { usable ->
        Box(
            Modifier
                .fillMaxSize()
                .background(Ink.copy(alpha = 0.42f))
                .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
        )
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .heightIn(max = usable * 0.82f)
                .graphicsLayer { translationY = lift.toPx() }
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Cream)
                .border(Paper.Outline, Ink, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .clickableNoRipple(remember { MutableInteractionSource() }) { },
        ) {
            Column(
                Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
                    .padding(start = 20.dp, end = 20.dp, top = 18.dp),
            ) {
                Text(
                    tr("How should MyAI answer?", "MyAI कैसे जवाब दे?"),
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    when {
                        aiOff -> tr("MyAI is offline in this build.", "इस बिल्ड में MyAI बंद है।")
                        else -> strings().doubt.left(left)
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (left <= 0) Tang.accent else InkMid,
                )

                SectionLabel(tr("Length", "लंबाई"))
                Option(
                    tr("Short", "छोटा"), tr("3–4 lines, straight to the point", "3–4 लाइन, सीधा जवाब"),
                    Sky, AnswerStyle.length == AnswerStyle.SHORT,
                ) { haptics.tick(); Sfx.play(Sound.TOGGLE); AnswerStyle.length = AnswerStyle.SHORT }
                Option(
                    tr("Normal", "नॉर्मल"), tr("Clear explanation, exam-ready", "साफ़ समझ, एग्ज़ाम लायक"),
                    Sky, AnswerStyle.length == AnswerStyle.NORMAL,
                ) { haptics.tick(); Sfx.play(Sound.TOGGLE); AnswerStyle.length = AnswerStyle.NORMAL }
                Option(
                    tr("Deep", "डीप"), tr("Steps, one worked example, an exam tip", "स्टेप्स, एक उदाहरण, एक एग्ज़ाम टिप"),
                    Sky, AnswerStyle.length == AnswerStyle.DEEP,
                ) { haptics.tick(); Sfx.play(Sound.TOGGLE); AnswerStyle.length = AnswerStyle.DEEP }

                SectionLabel(tr("Language", "भाषा"))
                Option(
                    "English", tr("Plain, simple English", "सीधी, आसान इंग्लिश"),
                    Candy, !AnswerStyle.hinglish,
                ) { haptics.tick(); Sfx.play(Sound.TOGGLE); AnswerStyle.hinglish = false }
                Option(
                    "Hinglish", tr("Hindi in English letters, terms stay English", "अंग्रेज़ी अक्षरों में हिंदी, टर्म्स इंग्लिश में"),
                    Candy, AnswerStyle.hinglish,
                ) { haptics.tick(); Sfx.play(Sound.TOGGLE); AnswerStyle.hinglish = true }

                SectionLabel(tr("Who answers", "कौन जवाब दे"))
                MyAiMode.entries.forEach { item ->
                    val locked = item != MyAiMode.Study && !premium
                    Option(
                        item.label(), item.what(), item.sticker(), item == mode, locked = locked,
                    ) {
                        haptics.tick()
                        if (locked) { onClose(); onPlans() } else { Sfx.play(Sound.TOGGLE); onMode(item) }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            Box(Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 16.dp)) {
                SquishButton(tr("Done", "हो गया"), Mint, Modifier.fillMaxWidth()) { onClose() }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Spacer(Modifier.height(16.dp))
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Black,
        letterSpacing = 1.2.sp,
        color = InkMid,
    )
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun Option(
    title: String,
    sub: String,
    sticker: Sticker,
    on: Boolean,
    locked: Boolean = false,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(Paper.ChipRadius)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(shape)
            .background(if (on) sticker.fill else CreamCard)
            .border(if (on) 2.5.dp else 1.5.dp, Ink, shape)
            .clickableNoRipple(remember { MutableInteractionSource() }) { onClick() }
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = if (on) sticker.on else Ink.copy(alpha = if (locked) 0.5f else 1f),
            )
            Text(
                sub,
                style = MaterialTheme.typography.bodySmall,
                color = if (on) sticker.on.copy(alpha = 0.8f) else InkMid,
            )
        }
        Spacer(Modifier.width(10.dp))
        when {
            locked -> Box(
                Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Butter.fill)
                    .border(1.5.dp, Ink, RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 1.dp),
            ) {
                Text(strings().doubt.proTag, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, color = Butter.on)
            }
            else -> Box(
                Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(if (on) Ink else CreamCard)
                    .border(2.dp, Ink, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                if (on) Box(Modifier.size(8.dp).clip(CircleShape).background(sticker.fill))
            }
        }
    }
}
