package com.momentum.focus.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import kotlinx.coroutines.launch
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.*

// ============================================================================
// Aura, glow, and light-beam effects that turn flat sticker fills into
// living, breathing surfaces. Every premium surface in the app should carry
// one of these — the absence of it is what makes a screen feel like a wireframe.
// ============================================================================

/**
 * A slow horizontal beam that scans across a surface — the premium card
 * on the plans screen, the featured update in What's New.
 *
 * This is not a gradient on the card itself. It is a transient light that
 * passes over it at a slight angle, the same way a retail window display
 * uses a moving highlight to catch the eye of someone walking past.
 *
 * @param tint  the accent colour the beam carries.
 * @param ms    full sweep duration, at least 2500ms or it becomes a strobe.
 */
@Composable
fun ScanningBeam(
    modifier: Modifier = Modifier,
    tint: Color = Sky.accent,
    ms: Int = 3_500,
) {
    val x by rememberInfiniteTransition(label = "scan").animateFloat(
        initialValue = -0.25f, targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            tween(ms, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "scan-x",
    )
    val alpha by rememberInfiniteTransition(label = "scan-a").animateFloat(
        initialValue = 0.6f, targetValue = 0.3f,
        animationSpec = infiniteRepeatable(
            tween(ms / 2, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "scan-alpha",
    )

    Canvas(modifier) {
        if (size.width <= 0f || size.height <= 0f) return@Canvas
        val beamW = size.width * 0.25f
        val beamH = size.height * 0.35f
        val beamX = size.width * x - beamW * 0.5f
        val beamY = size.height * 0.5f - beamH * 0.5f

        // Slight rotation so it does not read as a flat UI progress bar.
        rotate(-14f, pivot = Offset(beamX + beamW / 2f, beamY + beamH / 2f)) {
            drawRect(
                brush = Brush.linearGradient(
                    listOf(Color.Transparent, tint.copy(alpha), tint.copy(alpha), Color.Transparent),
                    start = Offset(0f, 0f),
                    end = Offset(beamW, 0f),
                ),
                topLeft = Offset(beamX, beamY),
                size = Size(beamW, beamH),
            )
        }
    }
}

/**
 * A breathing radial glow behind a round avatar or a premium token.
 *
 * Drawn as a radial gradient rather than `Modifier.shadow()` because shadow
 * always blurs the source shape, and a blurring circle stops reading as an
 * object and starts reading as a fog.
 */
@Composable
fun BreathingOrb(
    modifier: Modifier = Modifier,
    tint: Color = Lilac.accent,
    breathing: Boolean = true,
) {
    val radius by (if (breathing) {
        rememberInfiniteTransition(label = "orb").animateFloat(
            initialValue = 0.92f, targetValue = 1.08f,
            animationSpec = infiniteRepeatable(
                tween(2_800, easing = FastOutSlowInEasing),
                RepeatMode.Reverse,
            ),
            label = "breathe",
        )
    } else null) ?: return

    Canvas(modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = min(cx, cy) * radius
        drawCircle(
            brush = Brush.radialGradient(
                listOf(
                    tint.copy(alpha = 0.45f),
                    tint.copy(alpha = 0.18f),
                    Color.Transparent,
                ),
                center = Offset(cx, cy),
                radius = r,
            ),
            radius = r,
            center = Offset(cx, cy),
        )
    }
}

/**
 * A soft pulsing glow that wraps the *outside* of a rect — the premium
 * badge on the plans screen or the "BEST VALUE" sticker. Not inside the
 * shape like halftone; this is an ambient aura that leaks past the border.
 *
 * Kept as `drawBehind` rather than a full Canvas so it layers correctly
 * behind any content the caller already placed.
 */
fun Modifier.premiumAura(
    tint: Color = Tang.accent,
    breath: Boolean = true,
): Modifier = drawBehind {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val rx = size.width * 0.55f + size.height * 0.05f
    val ry = size.height * 0.55f + size.width * 0.05f

    // Draw once; if the caller wants breathing, they animate the alpha
    // externally. This keeps the modifier lightweight.
    drawOval(
        brush = Brush.radialGradient(
            listOf(tint.copy(alpha = 0.22f), Color.Transparent),
            center = Offset(cx, cy),
            radius = max(rx, ry),
        ),
        topLeft = Offset(cx - rx, cy - ry),
        size = Size(rx * 2f, ry * 2f),
    )
}

/**
 * The "shine" reflex on a 3D object — a narrow diagonal white stripe that
 * flashes once. Used on the metallic button to separate it from flat
 * surfaces: the highlight says "this is convex, not printed."
 *
 * Not for every button — only the one that is meant to be metal or glass.
 */
@Composable
fun SpecularFlash(
    modifier: Modifier = Modifier,
    trigger: Boolean,
    durationMs: Int = 800,
) {
    val progress by animateFloatAsState(
        if (trigger) 1f else 0f,
        tween(durationMs, easing = FastOutSlowInEasing),
        label = "flash",
    )
    if (progress <= 0f) return
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val p = progress
        val stripeW = w * 0.12f * p
        val sweep = w * 0.6f
        // Diagonal stripe moves left-to-right, fading in then out.
        val x = (w + sweep) * p - sweep * 0.5f
        val alpha = if (p < 0.5f) p * 2f else (1f - p) * 2f
        drawRect(
            color = Color.White.copy(alpha = alpha * 0.35f),
            topLeft = Offset(x, 0f),
            size = Size(stripeW, h),
        )
    }
}

/**
 * The "spark" behind a tap — a tiny point flash that radiates outward.
 * Layered behind the pressed button so it reads as the button firing
 * rather than as separate decoration.
 */
@Composable
fun TapSpark(
    modifier: Modifier = Modifier,
    tint: Color = Mint.fill,
    onComplete: () -> Unit = {},
) {
    val radius by remember { Animatable(0f) }
    val alpha by remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        launch { radius.animateTo(48f, tween(400)) }
        launch {
            alpha.animateTo(0f, tween(500, easing = FastOutSlowInEasing))
            onComplete()
        }
    }

    Canvas(modifier) {
        drawCircle(
            brush = Brush.radialGradient(
                listOf(tint.copy(alpha = alpha.value * 0.6f), Color.Transparent),
                center = Offset(size.width / 2f, size.height / 2f),
                radius = radius.value * density,
            ),
            radius = radius.value * density,
            center = Offset(size.width / 2f, size.height / 2f),
        )
    }
}
