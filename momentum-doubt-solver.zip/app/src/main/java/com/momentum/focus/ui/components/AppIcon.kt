package com.momentum.focus.ui.components

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * A row of app names reads a lot slower than a row of app icons — icon
 * recognition is closer to instant, the whole reason every real blocker
 * (this one included, everywhere else it lists apps) shows one per row
 * rather than relying on the label alone.
 *
 * `PackageManager.getApplicationIcon` decodes and can scale a drawable
 * per call, real work worth keeping off the main thread and worth not
 * repeating — this caches by package name for the process lifetime, since
 * an icon cannot change underneath a running app.
 */
private val iconCache = HashMap<String, Bitmap?>()

private fun Drawable.toBitmap(sizePx: Int): Bitmap {
    val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    setBounds(0, 0, sizePx, sizePx)
    draw(canvas)
    return bmp
}

@Composable
fun AppIcon(pkg: String, size: Dp, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val sizePx = with(androidx.compose.ui.platform.LocalDensity.current) { size.roundToPx() }
    val bitmap by produceState<Bitmap?>(initialValue = iconCache[pkg], key1 = pkg) {
        if (iconCache.containsKey(pkg)) {
            value = iconCache[pkg]
            return@produceState
        }
        value = withContext(Dispatchers.IO) {
            runCatching {
                context.packageManager.getApplicationIcon(pkg).toBitmap(sizePx)
            }.getOrNull().also { iconCache[pkg] = it }
        }
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap!!.asImageBitmap(),
            contentDescription = null,
            modifier = modifier
                .size(size)
                .clip(RoundedCornerShape(size / 4)),
        )
    } else {
        // Never blocks layout on a slow decode: the row keeps its shape with
        // a quiet placeholder square and swaps to the real icon the instant
        // it's ready, rather than the whole row jumping when it arrives.
        androidx.compose.foundation.layout.Box(
            modifier
                .size(size)
                .clip(RoundedCornerShape(size / 4))
                .background(Color(0x14000000)),
        )
    }
}
