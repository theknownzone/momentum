package com.momentum.focus.data

import com.momentum.focus.ui.theme.Skin

/**
 * One place that says what a NON-premium user may keep (owner bug: after the
 * key was removed, Crown stayed armed and the Pro theme stayed on).
 *
 * Runs on EVERY write (AppViewModel.updateData) and once at start, so no
 * screen can leave a Pro-only state behind. Pro checks that happen at use
 * time (MyAI modes, photo/PDF doubts, mock test, AI poster, questions per
 * session, playful look) already read data.premium live; this covers the
 * things that are SAVED and would otherwise outlive the key:
 *
 *  - Skin: back to the default unless the user's own level unlocks it.
 *  - Crown (crownMode + level 4): switched off and the level drops to Lock.
 *    EXCEPT while a pact lock is running: removing the key must never be an
 *    escape hatch from a lock the user chose (dev view: that's the exploit a
 *    student would find first). Crown ends the moment the pact does.
 *
 * Releasing device admin when Crown ends is done by the caller (needs a
 * Context) — see AppViewModel.updateData.
 */
object Entitlements {
    const val SAFE_LEVEL = 2   // Lock

    fun reconcile(d: AppData, nowMs: Long = System.currentTimeMillis()): AppData {
        if (d.premium) return d
        var x = d
        val skin = Skin.entries.getOrNull(d.skin)
        if (skin == null || d.level < skin.unlockLevel) {
            if (d.skin != 0) x = x.copy(skin = 0)
        }
        val pactLive = d.lockUntilEpochMs > nowMs
        if (!pactLive) {
            if (x.crownMode) x = x.copy(crownMode = false)
            if (x.focusLevel > 3) x = x.copy(focusLevel = SAFE_LEVEL)
        }
        return x
    }
}
