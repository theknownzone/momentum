package com.momentum.focus.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.components.*
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Haptics
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlin.math.*

/**
 * The Focus Machine — a 3D mechanical shield that physically blocks apps.
 *
 * HTML lab ka mechanic recycle: a box with a lid, a monster inside, and a
 * button that physically opens/closes it. The monster is the "blocking
 * engine" — when the lid is closed, apps are trapped; when open, they slip
 * through. The visual joke is that something this ridiculous is doing
 * something this serious.
 *
 * The machine uses comic physics: hard shadows, flat fills, no gradients
 * except the metallic sheen on the lid. Everything else is sticker colours.
 *
 * @param shieldOn  current shield state from AppData.
 * @param onToggle  callback to flip the system shield.
 * @param pactLocked  true while an active focus pact blocks turning the
 *   shield off — setShield() silently no-ops in that case, so this lets
 *   the button explain that instead of doing nothing with no feedback.
 */
@Composable
fun FocusMachineScreen(
    shieldOn: Boolean,
    blockedCount: Int,
    onToggle: () -> Unit,
    onBack: () -> Unit,
    pactLocked: Boolean = false,
) {
    val str = strings()
    val haptics = rememberHaptics()
    var showPactNotice by remember { mutableStateOf(false) }

    // Local animated state — the machine has its own physical lag so it
    // feels mechanical, not instant.
    var machineOpen by remember { mutableStateOf(!shieldOn) }
    val lidAngle by animateFloatAsState(
        if (machineOpen) -55f else 0f,
        spring(dampingRatio = 0.5f, stiffness = 180f),
        label = "lid",
    )
    val monsterY by animateFloatAsState(
        if (machineOpen) 1f else 0f,
        spring(dampingRatio = 0.45f, stiffness = 160f),
        label = "monster",
    )
    val glowAlpha by animateFloatAsState(
        if (machineOpen) 0f else 1f,
        tween(400),
        label = "glow",
    )

    LaunchedEffect(shieldOn) {
        machineOpen = !shieldOn
        if (shieldOn) {
            delay(100)
            haptics.shield(true)
            Sfx.play(Sound.SHIELD_ON)
        } else {
            delay(100)
            haptics.shield(false)
            Sfx.play(Sound.SHIELD_OFF)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "←",
                Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.tick(); onBack()
                    }
                    .padding(8.dp),
                style = MaterialTheme.typography.headlineSmall,
                color = Ink,
            )
            Spacer(Modifier.width(8.dp))
            Text(
                "Focus Machine",
                style = MaterialTheme.typography.headlineSmall,
                color = Ink,
            )
        }

        Spacer(Modifier.height(20.dp))

        Text(
            if (shieldOn) "Shield is ON" else "Shield is OFF",
            style = MaterialTheme.typography.displayMedium,
            color = if (shieldOn) Mint.fill else Tang.fill,
        )
        Text(
            if (shieldOn) "$blockedCount apps trapped inside"
            else "Nothing is being blocked right now.",
            style = MaterialTheme.typography.bodyLarge,
            color = InkMid,
        )

        Spacer(Modifier.height(32.dp))

        // ---- THE MACHINE ----
        Box(
            Modifier
                .fillMaxWidth()
                .height(280.dp),
            contentAlignment = Alignment.BottomCenter,
        ) {
            // Machine body background.
            MachineBody()

            // Glow behind monster when shield is on.
            if (!machineOpen) {
                BreathingOrb(
                    Modifier
                        .size(120.dp)
                        .align(Alignment.BottomCenter)
                        .offset(y = (-70).dp),
                    tint = Mint.accent.copy(alpha = glowAlpha),
                    breathing = glowAlpha > 0.5f,
                )
            }

            // Monster.
            Monster(
                Modifier
                    .size(90.dp)
                    .align(Alignment.BottomCenter)
                    .offset(
                        y = ((-80f - 60f * monsterY).dp),
                        x = 0.dp,
                    ),
                isHappy = machineOpen,
            )

            // Lid (drawn last so it sits on top).
            Lid(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .align(Alignment.BottomCenter),
                angle = lidAngle,
            )
        }

        Spacer(Modifier.height(24.dp))

        // Toggle button
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MachineToggleButton(
                shieldOn = shieldOn,
                modifier = Modifier.weight(1f),
                onToggle = {
                    if (shieldOn && pactLocked) {
                        haptics.reject()
                        showPactNotice = true
                    } else {
                        haptics.press()
                        onToggle()
                    }
                },
            )
        }

        if (showPactNotice) {
            Spacer(Modifier.height(12.dp))
            Text(
                "🔒 Locked until your current pact ends",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = Tang.fill,
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )
        }

        Spacer(Modifier.height(24.dp))

        // Blocked apps list
        if (blockedCount > 0 && shieldOn) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .background(CreamCard)
                    .comicShadow()
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .halftone(coverage = 0.08f)
                    .inkBorder()
                    .padding(16.dp),
            ) {
                Text(
                    "Trapped apps",
                    style = MaterialTheme.typography.labelSmall,
                    color = InkMid,
                )
                Spacer(Modifier.height(8.dp))
                // Dummy row for visual — real data comes from BlockListScreen
                repeat(minOf(blockedCount, 4)) { i ->
                    val sticker = stickerFor(i)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier
                                .size(10.dp)
                                .clip(androidx.compose.foundation.shape.CircleShape)
                                .background(sticker.fill)
                                .border(1.5.dp, Ink, androidx.compose.foundation.shape.CircleShape),
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "App ${i + 1}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Ink,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            "Blocked",
                            style = MaterialTheme.typography.labelSmall,
                            color = Mint.accent,
                        )
                    }
                }
            }
        }
    }
}

/**
 * The Shield on/off toggle, rebuilt from three Uiverse.io references the
 * user sent rather than the flat single-fill box this used to be:
 *
 * - The star badge button's stacked-ring edge (a handle colour, then Ink,
 *   then the bright face) — reworked here as two nested layers instead of
 *   ~20 stacked box-shadows, since Compose has no CSS box-shadow list.
 * - The brutalist button's hard offset shadow that the surface sinks into
 *   on interaction — that button used :hover (a mouse concept); this is a
 *   touchscreen, so it sinks on *press* instead, using the same
 *   press-then-settle spring [SquishButton] already uses elsewhere in this
 *   app rather than inventing a second press language.
 * - The glow button's halo — real here, but local to this one Box via
 *   drawBehind rather than the shared [Aura] composable, which the app
 *   reserves for paid surfaces specifically; reusing it here would blur
 *   that signal for a feature that costs nothing.
 *
 * Colour still comes from this app's own Sticker system, not the
 * references' palettes: Mint/Tang for the two states, and each Sticker's
 * own `accent` field (a deeper shade of the same hue) for the outer ring,
 * so "off-brand purple" or "off-brand yellow" never sneaks in.
 */
@Composable
private fun MachineToggleButton(
    shieldOn: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val tone = if (shieldOn) Mint else Tang
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressOffset by animateFloatAsState(
        if (pressed) 1f else 0f, Motion.press(), label = "toggle-press",
    )
    val shadowDp = 6.dp

    // A soft, local "powered" glow while the shield actually holds
    // something — quiet when there's nothing to hold (blockedCount driven
    // from the caller would be nicer, but shieldOn alone already answers
    // "is this button live right now", which is all a glow needs to say).
    val glowT by rememberInfiniteTransition(label = "toggle-glow")
        .animateFloat(
            initialValue = 0.25f,
            targetValue = 0.55f,
            animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
            label = "toggle-glow-v",
        )

    Box(modifier, contentAlignment = Alignment.Center) {
        if (shieldOn) {
            Canvas(Modifier.matchParentSize()) {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(tone.fill.copy(alpha = glowT), Color.Transparent),
                    ),
                    radius = size.maxDimension * 0.7f,
                    center = Offset(size.width / 2f, size.height / 2f),
                )
            }
        }

        Box(
            Modifier
                .fillMaxWidth()
                .height(68.dp)
                // The press-sink shadow — full size at rest, tucks under
                // the button as pressOffset climbs toward 1.
                .drawBehind {
                    val d = shadowDp.toPx() * (1f - pressOffset)
                    drawRoundRect(
                        color = Ink,
                        topLeft = Offset(d, d),
                        size = size,
                        cornerRadius = CornerRadius(20.dp.toPx(), 20.dp.toPx()),
                    )
                }
                .graphicsLayer {
                    translationX = shadowDp.toPx() * pressOffset
                    translationY = shadowDp.toPx() * pressOffset
                }
                // Outer ring: the sticker's own deeper accent shade —
                // the "stacked card" edge, in one layer instead of twenty.
                .clip(RoundedCornerShape(20.dp))
                .background(tone.accent)
                .padding(4.dp)
                // Inner face: the bright fill, wobble-bordered in Ink to
                // match the hand-drawn line the rest of the Machine uses.
                .clip(RoundedCornerShape(16.dp))
                .background(tone.fill)
                .inkBorder(corner = 16f)
                .clickableNoRipple(interaction, onClick = onToggle),
            contentAlignment = Alignment.Center,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (shieldOn) "🔒" else "🔓",
                    style = MaterialTheme.typography.headlineSmall,
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    if (shieldOn) "Open Lid" else "Close Lid",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = tone.on,
                )
            }
        }
    }
}

@Composable
private fun MachineBody() {
    Box(
        Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(22.dp))
            .background(Color(0xFF1E2A30))
            .comicShadow()
            .clip(RoundedCornerShape(22.dp))
            .inkBorder(color = Ink.copy(alpha = 0.6f))
            .drawBehind {
                // Inner panel lines (like a machine face).
                val stroke = 2f * density
                // Top panel seam.
                drawLine(
                    Color(0xFF2A3A42),
                    Offset(24f * density, 18f * density),
                    Offset(size.width - 24f * density, 18f * density),
                    strokeWidth = stroke,
                )
                // Side rivets.
                repeat(3) { i ->
                    val y = size.height * 0.3f + i * 45f * density
                    drawCircle(
                        Color(0xFF3A4A52),
                        radius = 4f * density,
                        center = Offset(18f * density, y),
                    )
                    drawCircle(
                        Color(0xFF3A4A52),
                        radius = 4f * density,
                        center = Offset(size.width - 18f * density, y),
                    )
                }
            },
    )
}

@Composable
private fun Monster(modifier: Modifier = Modifier, isHappy: Boolean) {
    val eyeOffset by animateFloatAsState(
        if (isHappy) 2f else -1f,
        spring(dampingRatio = 0.6f, stiffness = 200f),
        label = "eye",
    )
    val mouthCurve by animateFloatAsState(
        if (isHappy) 1f else -0.3f,
        spring(dampingRatio = 0.5f, stiffness = 180f),
        label = "mouth",
    )

    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val cy = h / 2f

            // Body: rounded rect blob.
            val bodyPath = Path().apply {
                addRoundRect(
                    androidx.compose.ui.geometry.RoundRect(
                        rect = androidx.compose.ui.geometry.Rect(
                            left = cx - w * 0.38f,
                            top = cy - h * 0.35f,
                            right = cx + w * 0.38f,
                            bottom = cy + h * 0.30f,
                        ),
                        radiusX = 28.dp.toPx(),
                        radiusY = 28.dp.toPx(),
                    )
                )
            }
            drawPath(bodyPath, Mint.fill)
            drawPath(bodyPath, Ink, style = Stroke(3f * density))

            // Eyes (white circles with ink pupils).
            val eyeR = w * 0.10f
            val eyeY = cy - h * 0.08f
            val eyeXOff = w * 0.18f
            listOf(-1f, 1f).forEach { side ->
                val eyeX = cx + side * eyeXOff
                drawCircle(Color.White, eyeR, center = Offset(eyeX, eyeY))
                drawCircle(Ink, eyeR * 0.4f, center = Offset(eyeX, eyeY + eyeOffset * density))
                drawCircle(Ink, eyeR, center = Offset(eyeX, eyeY), style = Stroke(2f * density))
            }

            // Mouth: quadratic curve that curves up for happy, flat/sad for closed.
            val mouthPath = Path().apply {
                val mx = cx
                val my = cy + h * 0.12f
                val mw = w * 0.30f
                moveTo(mx - mw, my)
                quadraticBezierTo(
                    mx, my + mouthCurve * h * 0.15f,
                    mx + mw, my,
                )
            }
            drawPath(mouthPath, Ink, style = Stroke(3f * density, cap = StrokeCap.Round))
        }
    }
}

@Composable
private fun Lid(modifier: Modifier, angle: Float) {
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val pivotX = w * 0.15f
            val pivotY = h * 0.85f

            rotate(angle, pivot = Offset(pivotX, pivotY)) {
                // Lid body.
                val lidPath = Path().apply {
                    addRoundRect(
                        androidx.compose.ui.geometry.RoundRect(
                            rect = androidx.compose.ui.geometry.Rect(
                                left = 0f,
                                top = 0f,
                                right = w,
                                bottom = h * 0.75f,
                            ),
                            radiusX = 10.dp.toPx(),
                            radiusY = 10.dp.toPx(),
                        )
                    )
                }
                drawPath(lidPath, Color(0xFF4A5A64))
                drawPath(lidPath, Ink, style = Stroke(2.5f * density))

                // Metallic sheen line across top.
                drawLine(
                    Color.White.copy(alpha = 0.25f),
                    Offset(w * 0.1f, h * 0.15f),
                    Offset(w * 0.9f, h * 0.15f),
                    strokeWidth = 2f * density,
                )

                // Handle bar.
                drawRoundRect(
                    color = Color(0xFF2A3A42),
                    topLeft = Offset(w * 0.35f, h * 0.45f),
                    size = Size(w * 0.30f, h * 0.20f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f),
                )
                drawRoundRect(
                    color = Ink,
                    topLeft = Offset(w * 0.35f, h * 0.45f),
                    size = Size(w * 0.30f, h * 0.20f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f),
                    style = Stroke(2f * density),
                )
            }
        }
    }
}
