package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.UrgePredictor
import com.momentum.focus.data.tr
import com.momentum.focus.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalTime

/**
 * Stats: "Danger hours" — today's 24 predicted-slip bars from UrgePredictor.
 * Peak hours Tang, the rest Sky, now marked with an ink caret. Bars grow once
 * (500 ms, draw phase). Hidden until the model has learnt something.
 */
@Composable
fun DangerHours(blocked: Set<String>, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val day by produceState<FloatArray?>(null) {
        value = withContext(Dispatchers.IO) {
            runCatching { UrgePredictor.rebuildIfStale(ctx, blocked); UrgePredictor.today(ctx) }.getOrNull()
        }
    }
    val danger by produceState<Pair<Int, String>?>(null, day) {
        value = withContext(Dispatchers.IO) { runCatching { UrgePredictor.dangerHour(ctx) }.getOrNull() }
    }
    val d = day ?: return
    if ((d.maxOrNull() ?: 0f) < 0.05f) return
    val grow = remember { Animatable(0f) }
    LaunchedEffect(Unit) { grow.animateTo(1f, tween(500, easing = FastOutSlowInEasing)) }
    val nowH = LocalTime.now().hour
    val shape = RoundedCornerShape(Paper.CardRadius)

    Column(
        modifier.fillMaxWidth().clip(shape).background(CreamCard).border(Paper.Outline, Ink, shape).padding(16.dp)
    ) {
        Text(tr("DANGER HOURS · PREDICTED", "खतरे के घंटे · अनुमान"), style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Spacer(Modifier.height(4.dp))
        danger?.let { (h, app) ->
            val h12 = if (h % 12 == 0) 12 else h % 12
            val ampm = if (h < 12) "AM" else "PM"
            Text(
                if (app.isNotBlank()) tr("$h12 $ampm is your $app hour.", "$h12 $ampm तुम्हारा $app वाला घंटा है।")
                else tr("$h12 $ampm is your weakest hour.", "$h12 $ampm सबसे कमज़ोर घंटा है।"),
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = Ink,
            )
        }
        Text(
            tr("Learnt on this phone from your last 3 weeks. We nudge you 10 min before, and the shield waits longer then.",
               "पिछले 3 हफ़्तों से इसी फ़ोन पर सीखा। 10 मिनट पहले याद दिलाएँगे, और तब शील्ड ज़्यादा रुकेगी।"),
            style = MaterialTheme.typography.bodySmall, color = InkMid,
        )
        Spacer(Modifier.height(10.dp))
        Canvas(Modifier.fillMaxWidth().height(64.dp)) {
            val gap = 2.dp.toPx()
            val bw = (size.width - gap * 23) / 24f
            val base = size.height - 10.dp.toPx()
            for (i in 0 until 24) {
                val h = (d[i] * (base - 4f) * grow.value).coerceAtLeast(2f)
                val x = i * (bw + gap)
                drawRoundRect(
                    if (d[i] >= UrgePredictor.PEAK) Tang.fill else Sky.fill,
                    Offset(x, base - h), Size(bw, h), CornerRadius(2.dp.toPx()),
                )
                if (i == nowH) drawRect(Ink, Offset(x, base + 3.dp.toPx()), Size(bw, 3.dp.toPx()))
            }
        }
        Row(Modifier.fillMaxWidth()) {
            listOf("12a", "6a", "12p", "6p").forEach {
                Text(it, style = MaterialTheme.typography.labelSmall, color = InkMid, modifier = Modifier.weight(1f))
            }
        }
    }
}
