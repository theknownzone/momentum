package com.momentum.focus.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.getSystemService
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Urge Predictor — Momentum's own on-device "dispatch engine".
 *
 * Uber predicts where riders will appear and moves drivers there first. This
 * predicts WHEN this person is about to slip and moves the defence there
 * first. Nothing leaves the phone; no server, no account, no ML library.
 *
 * MODEL: a 7×24 grid (weekday × hour) of "slip pressure", learnt from the last
 * 21 days of UsageStats: every open of a blocked/forbidden app adds weight to
 * its slot, decayed 0.9 per day so last week matters more than three weeks
 * ago (habits move). Each slot also remembers which app pulled hardest there.
 * Neighbouring hours share 25% (an 11 PM habit makes 10:30 risky too).
 * Normalised to 0..1 against the person's own worst slot — "high" means high
 * FOR THEM, not against some global average.
 *
 * MECHANISMS built on it ("predictive friction"):
 *  1. Pre-emptive nudge, ~10 min BEFORE a peak slot starts (once per slot per
 *     day): "11 PM is your Instagram hour. Lock in now?" — with Mute.
 *  2. Peak-hour friction: in a predicted peak the shield's wait gets +5 s.
 *  3. Stats "Danger hours" strip so the person can SEE their pattern.
 *
 * Cost: one events query every 6 h on the service thread (~tens of ms), a
 * 168-float array in prefs. Rebuilt lazily; reads are array lookups.
 */
object UrgePredictor {
    private const val PREFS = "momentum_urge"
    private const val KEY_GRID = "grid"
    private const val KEY_APPS = "apps"
    private const val KEY_BUILT = "built_at"
    private const val KEY_MUTED = "muted"
    private const val KEY_NUDGED = "nudged_slot"
    const val PEAK = 0.7f
    private const val CHANNEL = "momentum_urge"
    private const val NOTIF_ID = 4711

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Volatile private var grid: FloatArray? = null
    @Volatile private var apps: Array<String>? = null

    private fun slot(t: LocalDateTime) = (t.dayOfWeek.value - 1) * 24 + t.hour

    // ── Learn ──

    fun rebuildIfStale(c: Context, blocked: Set<String>) {
        if (System.currentTimeMillis() - prefs(c).getLong(KEY_BUILT, 0L) < 6 * 3_600_000L) return
        rebuild(c, blocked)
    }

    fun rebuild(c: Context, blocked: Set<String>) {
        val usm = c.getSystemService<UsageStatsManager>() ?: return
        val now = System.currentTimeMillis()
        val from = now - 21L * 86_400_000L
        val events = runCatching { usm.queryEvents(from, now) }.getOrNull() ?: return
        val g = FloatArray(168)
        val perApp = HashMap<Int, HashMap<String, Float>>()
        val zone = ZoneId.systemDefault()
        val ev = UsageEvents.Event()
        var lastPkg = ""
        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            if (ev.eventType != UsageEvents.Event.MOVE_TO_FOREGROUND) continue
            val pkg = ev.packageName ?: continue
            if (pkg == lastPkg) continue          // one open, not every activity inside it
            lastPkg = pkg
            val junk = StudyApps.isForbidden(pkg) || blocked.any { pkg == it || pkg.startsWith(it) }
            if (!junk) continue
            val daysAgo = ((now - ev.timeStamp) / 86_400_000L).toInt()
            val w = Math.pow(0.9, daysAgo.toDouble()).toFloat()
            val t = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(ev.timeStamp), zone)
            val s = slot(t)
            g[s] += w
            perApp.getOrPut(s) { HashMap() }.merge(pkg, w, Float::plus)
        }
        // Spill 25% into neighbouring hours (wraps across days/week).
        val smooth = FloatArray(168) { i -> g[i] + 0.25f * (g[(i + 167) % 168] + g[(i + 1) % 168]) }
        val max = smooth.maxOrNull()?.takeIf { it > 0f } ?: 1f
        for (i in smooth.indices) smooth[i] = smooth[i] / max
        val top = Array(168) { i -> perApp[i]?.maxByOrNull { it.value }?.key ?: "" }
        grid = smooth; apps = top
        prefs(c).edit()
            .putString(KEY_GRID, smooth.joinToString(",") { "%.3f".format(java.util.Locale.US, it) })
            .putString(KEY_APPS, top.joinToString("|"))
            .putLong(KEY_BUILT, now)
            .apply()
    }

    private fun load(c: Context): Pair<FloatArray, Array<String>>? {
        grid?.let { g -> return g to (apps ?: Array(168) { "" }) }
        val p = prefs(c)
        val gs = p.getString(KEY_GRID, null) ?: return null
        val g = gs.split(',').mapNotNull { it.toFloatOrNull() }.toFloatArray().takeIf { it.size == 168 } ?: return null
        val a = (p.getString(KEY_APPS, "") ?: "").split('|').toTypedArray().takeIf { it.size == 168 } ?: Array(168) { "" }
        grid = g; apps = a
        return g to a
    }

    // ── Read ──

    fun risk(c: Context, at: LocalDateTime = LocalDateTime.now()): Float =
        load(c)?.first?.get(slot(at)) ?: 0f

    fun isPeak(c: Context, at: LocalDateTime = LocalDateTime.now()) = risk(c, at) >= PEAK

    /** Today's 24 hours of risk, for the Stats strip. */
    fun today(c: Context): FloatArray? {
        val g = load(c)?.first ?: return null
        val base = (LocalDateTime.now().dayOfWeek.value - 1) * 24
        return FloatArray(24) { g[base + it] }
    }

    /** Hour (0–23) + app label of today's worst slot, or null if no data. */
    fun dangerHour(c: Context): Pair<Int, String>? {
        val (g, a) = load(c) ?: return null
        val base = (LocalDateTime.now().dayOfWeek.value - 1) * 24
        val h = (0 until 24).maxByOrNull { g[base + it] } ?: return null
        if (g[base + h] < 0.2f) return null
        return h to label(c, a[base + h])
    }

    private fun label(c: Context, pkg: String): String = if (pkg.isBlank()) "" else runCatching {
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault("")

    // ── Act: nudge ~10 min before a peak ──

    fun maybeNudge(c: Context, sessionRunning: Boolean) {
        val p = prefs(c)
        if (p.getBoolean(KEY_MUTED, false) || sessionRunning) return
        val soon = LocalDateTime.now().plusMinutes(10)
        if (soon.minute > 15) return                      // only right before the hour turns
        val (g, a) = load(c) ?: return
        val s = slot(soon)
        if (g[s] < PEAK) return
        val stamp = "${soon.toLocalDate()}#$s"
        if (p.getString(KEY_NUDGED, "") == stamp) return
        p.edit().putString(KEY_NUDGED, stamp).apply()

        val app = label(c, a[s]).ifBlank { tr("scrolling", "स्क्रॉलिंग") }
        val hour = soon.hour.let { h -> val h12 = if (h % 12 == 0) 12 else h % 12; "$h12 ${if (h < 12) "AM" else "PM"}" }
        val nm = c.getSystemService<NotificationManager>() ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, tr("Danger-hour heads-up", "खतरे के घंटे की चेतावनी"), NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val open = c.packageManager.getLaunchIntentForPackage(c.packageName)?.let {
            PendingIntent.getActivity(c, 31, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
        val mute = PendingIntent.getBroadcast(
            c, 32, Intent(c, UrgeMuteReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle(tr("$hour is your $app hour.", "$hour तुम्हारा $app वाला घंटा है।"))
            .setContentText(tr("You usually slip here. Lock in 25 min before it starts?", "यहीं अक्सर फिसलते हो। शुरू होने से पहले 25 मिनट लॉक इन?"))
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(0, tr("Mute these", "बंद करो"), mute)
            .build()
        runCatching { nm.notify(NOTIF_ID, n) }
    }

    fun mute(c: Context) { prefs(c).edit().putBoolean(KEY_MUTED, true).apply() }
}

class UrgeMuteReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        UrgePredictor.mute(context)
        context.getSystemService<NotificationManager>()?.cancel(4711)
    }
}
