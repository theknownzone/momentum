package com.momentum.focus.ui.util

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import com.momentum.focus.R

/**
 * Plays the Crown cinematic's pre-mixed score (res/raw/crown_score.ogg, built
 * by tools/crown_score.py). One file, one player, started in the same frame
 * as the visuals, so every cue lines up.
 *
 * Why not Sfx? (2026-10-07) Sfx follows the phone's RINGER mode and the
 * "tap sounds" switch, so on a phone on vibrate the whole cinematic played in
 * silence — the owner heard nothing. This is a once-per-arm, user-started
 * moment, so it plays on the MEDIA stream (like a video): it follows the
 * media volume, not the ringer. Media volume at 0 is still silent.
 */
object CrownAudio {
    private var mp: MediaPlayer? = null

    /** Blocking (~tens of ms): call off the main thread. True when ready. */
    fun prepare(ctx: Context): Boolean {
        release()
        return runCatching {
            val p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build(),
            )
            ctx.applicationContext.resources.openRawResourceFd(R.raw.crown_score).use { afd ->
                p.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            }
            p.prepare()
            p.setVolume(1f, 1f)
            mp = p
            true
        }.getOrDefault(false)
    }

    fun start() {
        runCatching { mp?.start() }
    }

    /** Short fade, then release — for a tap-to-close or Back mid-score. */
    fun stopFaded() {
        val p = mp ?: return
        mp = null
        val h = Handler(Looper.getMainLooper())
        var v = 1f
        val step = object : Runnable {
            override fun run() {
                v -= 0.125f
                if (v <= 0f) {
                    runCatching { p.stop() }
                    runCatching { p.release() }
                } else {
                    runCatching { p.setVolume(v, v) }
                    h.postDelayed(this, 35)
                }
            }
        }
        h.post(step)
    }

    fun release() {
        mp?.let {
            runCatching { it.stop() }
            runCatching { it.release() }
        }
        mp = null
    }
}
