package com.momentum.focus.ui.screens

import androidx.compose.ui.draw.drawBehind
import com.momentum.focus.data.tr
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.Sfx
import kotlin.math.roundToInt
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.animation.togetherWith
import com.momentum.focus.ui.components.BackPill
import android.content.Intent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material3.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Close
import androidx.compose.runtime.derivedStateOf
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.block.BlockerService
import com.momentum.focus.data.AppCatalog
import com.momentum.focus.data.AppData
import com.momentum.focus.data.CataloguedApp
import com.momentum.focus.data.Currency
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.sin
import com.momentum.focus.ui.components.AppIcon
import com.momentum.focus.ui.components.Coin3D
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun BlockListScreen(
    data: AppData,
    onToggle: (String) -> Unit,
    onCap: (String, Int?) -> Unit,
    onDone: () -> Unit,
    preselectTop: Boolean = false,
    /** Non-null while removals are refused, and says why. */
    editLock: String? = null,
) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    // A refused tap used to do nothing at all — the row simply did not change
    // and nothing said why, which read as the app being broken rather than
    // holding a line the user had set.
    var refused by remember { mutableStateOf(false) }
    // Today's real minutes for every blocked app (Regain's "12m spent / 5m").
    // Same UsageStats call the blocker's cap check uses; refreshed once a
    // minute while this screen is open, never per frame.
    val usedToday by produceState(initialValue = emptyMap<String, Int>(), data.blockedPackages) {
        while (true) {
            value = withContext(Dispatchers.IO) {
                runCatching { com.momentum.focus.data.ScreenTime.minutesTodayFor(context, data.blockedPackages) }
                    .getOrDefault(emptyMap())
            }
            kotlinx.coroutines.delay(60_000)
        }
    }

    // A draft. Tapping a row used to write straight to the store, so there was
    // no way to change your mind and no moment where the choice felt made —
    // people would tap around, leave, and not be sure what had stuck. Nothing
    // is committed until Save.
    var draft by remember(data.blockedPackages) {
        mutableStateOf(data.blockedPackages)
    }
    LaunchedEffect(refused) {
        if (refused) { kotlinx.coroutines.delay(2600); refused = false }
    }

    // Only apps with a launcher icon. Listing every installed package would
    // bury the four apps anyone actually wants to block.
    // Sorted by how much time each app actually took this week, so the ones
    // that cost the most sit at the top instead of whatever starts with "A".
    // Enumerating every launchable app on the phone (queryIntentActivities,
    // then a label lookup for each) genuinely takes real IO thread time on a
    // phone with 100+ apps installed — already off the main thread, so it
    // was never actually janky, but nothing on screen said so, and a blank
    // list for a second or two reads as the screen having hung. This is
    // purely a "say something's happening" fix; the scan itself is unchanged.
    var loading by remember { mutableStateOf(true) }
    val apps by produceState(initialValue = emptyList<CataloguedApp>()) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                // Phone, contacts, clock and settings are never blockable, so
                // offering them as choices only invites a lockout the pact will
                // then refuse to undo.
                AppCatalog.scan(context)
                    .filterNot { BlockerService.isNeverBlocked(it.pkg) }
            }.getOrDefault(emptyList())
        }
        loading = false
    }

    // Search + "most used first". The scan already sorts by this week's
    // minutes; the top three heavy hitters also get a rank tag so the
    // obvious ones to block are the first thing you see.
    var query by remember { mutableStateOf("") }
    val shown = remember(apps, query) {
        val q = query.trim()
        if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
    }
    val topRank = remember(apps) {
        apps.filter { it.minutes > 0 }.sortedByDescending { it.minutes }.take(3)
            .mapIndexed { i, a -> a.pkg to i + 1 }.toMap()
    }

    // The three biggest time sinks are ticked for you. An empty list is the
    // most common way this screen gets skipped, and the apps that hurt most
    // are exactly the ones nobody volunteers to block.
    var preselected by remember { mutableStateOf(false) }
    LaunchedEffect(apps) {
        if (preselectTop && !preselected && apps.isNotEmpty() && draft.isEmpty()) {
            preselected = true
            // Into the draft, not the store — the preselection is a suggestion
            // like any other tap, and Save is still what makes it real.
            draft = draft + apps.filter { it.isDistraction }.take(3).map { it.pkg }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 20.dp),
    ) {
        // Only the back pill stays put. The title, the lock note and the
        // count used to be fixed above the list and ate ~40% of the screen on
        // the one page where the list IS the job. They now scroll away with
        // the apps; once they are gone a small pill keeps the count in view.
        val listState = rememberLazyListState()
        val headerGone by remember { derivedStateOf { listState.firstVisibleItemIndex > 0 } }
        Row(verticalAlignment = Alignment.CenterVertically) {
            BackPill(onBack = onDone)
            Spacer(Modifier.width(12.dp))
            androidx.compose.animation.AnimatedVisibility(
                visible = headerGone,
                enter = androidx.compose.animation.fadeIn(tween(180)) +
                    androidx.compose.animation.slideInHorizontally(tween(220)) { -it / 3 },
                exit = androidx.compose.animation.fadeOut(tween(150)),
            ) {
                Text(
                    "SHIELD · ${draft.size} selected",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Black,
                    color = Ink,
                    modifier = Modifier
                        .drawBehind {
                            val d = 2.5.dp.toPx()
                            drawRoundRect(Ink, Offset(d, d), size, CornerRadius(999f))
                        }
                        .clip(RoundedCornerShape(999.dp))
                        .background(Tang.fill)
                        .border(2.dp, Ink, RoundedCornerShape(999.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                )
            }
        }

        LazyColumn(Modifier.weight(1f), state = listState) {
            item(key = "header") {
                Column {
                Spacer(Modifier.height(14.dp))
                Text(
                    "SHIELD",
                    style = MaterialTheme.typography.labelSmall,
                    color = Tang.accent,
                )

                if (editLock != null) {
                    Spacer(Modifier.height(8.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(Paper.ChipRadius))
                            .background(if (refused) Tang.fill else Sunk)
                            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.ChipRadius))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                    ) {
                        Text(
                            editLock,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (refused) Tang.on else InkMid,
                        )
                    }
                }
                Text(
                    "Your biggest time sinks",
                    style = MaterialTheme.typography.displayMedium,
                    color = Ink,
                )
                Text(
                    "${draft.size} selected · sorted by time spent",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                Spacer(Modifier.height(14.dp))

                // The one thing this screen never actually said: what turning a
                // toggle on does, and why a coin appears next to it. Both facts in
                // one line, once, rather than a user discovering either by trial —
                // opening the app and hitting a lock screen for the first time, or
                // wondering where a stray ₹10 came from.
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Sky.fill.copy(alpha = 0.30f))
                        .border(1.5.dp, Sky.accent.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(Sky.accent.copy(alpha = 0.85f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                    Icons.Filled.Lock,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp),
                )
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Apps you turn on show a lock screen instead of opening instantly — and earn ₹10 each toward your wallet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Ink,
                        lineHeight = 18.sp,
                    )
                }


                    Spacer(Modifier.height(14.dp))
                }
            }
            // Search pins to the top once the header has scrolled away, so
            // finding one app never means scrolling back up first.
            stickyHeader(key = "search") {
                AppSearchBar(query) { query = it }
            }
            if (loading) {
                item {
                    Column(
                        Modifier.fillMaxWidth().padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        BlurSpinner(size = 48.dp)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Reading installed apps…",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            if (!loading && shown.isEmpty()) {
                item(key = "nohit") {
                    Text(
                        tr("No app called \"$query\"", "\"$query\" नाम का कोई ऐप नहीं"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                        modifier = Modifier.padding(vertical = 24.dp),
                    )
                }
            }
            items(shown, key = { it.pkg }) { app ->
                val on = app.pkg in draft
                val rank = topRank[app.pkg]
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Tang.fill else CreamCard)
                        .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            val removing = app.pkg in draft
                            if (removing && editLock != null) {
                                haptics.press(); refused = true
                            } else {
                                haptics.tick()
                                draft = if (removing) draft - app.pkg else draft + app.pkg
                            }
                        }
                        .padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AppIcon(app.pkg, size = 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                app.label,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (on) Tang.on else Ink,
                                maxLines = 1,
                                modifier = Modifier.weight(1f, fill = false),
                            )
                            if (rank != null) {
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "#$rank ${tr("TIME SINK", "टाइम सिंक")}",
                                    fontSize = 9.sp, fontWeight = FontWeight.Black, color = Ink,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(Butter.fill)
                                        .border(1.5.dp, Ink, RoundedCornerShape(999.dp))
                                        .padding(horizontal = 6.dp, vertical = 1.dp),
                                )
                            }
                        }
                        Text(
                            buildString {
                                append(app.kind.label)
                                if (app.minutes > 0) {
                                    append(" · ")
                                    append("%dh %02dm this week".format(app.minutes / 60, app.minutes % 60))
                                }
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (on) Tang.on.copy(alpha = 0.75f) else InkMid,
                        )
                    }
                    if (on) {
                        // Showing the price on the row makes the trade explicit
                        // while the user is calm, which is the only time the
                        // number can actually change a decision.
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Coin3D(color = Butter.fill, size = 22.dp)
                            Spacer(Modifier.width(6.dp))
                            Text(
                                Currency.format(10),
                                style = MaterialTheme.typography.titleMedium,
                                color = Tang.on,
                            )
                            Spacer(Modifier.width(8.dp))
                            LockToggle(locked = true)
                        }
                    } else {
                        LockToggle(locked = false)
                    }
                }
                // The cap only appears once the app is blocked, because a cap
                // on an app that is not blocked would never be enforced. Off
                // by default: this tightens the shield, so it is opt in.
                if (on) {
                    val cap = data.dailyCapMinutes[app.pkg]
                    Column(Modifier.padding(start = 14.dp, bottom = 10.dp)) {
                        // "Daily cap" and bare option numbers (15/30/60, "Off")
                        // asked a new user to already know that this app still
                        // opens for a few minutes before it locks, and that
                        // those numbers are minutes. Said in one line instead,
                        // and every option carries its own unit so no pill
                        // needs the row's label to make sense on its own.
                        CapSlider(
                            current = cap,
                            options = listOf(15, 30, 60, null),
                            onSelect = { haptics.tick(); onCap(app.pkg, it) },
                            weeklyMinutes = app.minutes,
                            usedToday = usedToday[app.pkg],
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        SquishButton(
            // Says Save because it now saves. Calling it Done while every tap
            // had already written itself was the honest name for the old
            // behaviour and the wrong one for this.
            label = if (draft == data.blockedPackages) "Done" else "Save",
            sticker = Mint,
            modifier = Modifier.fillMaxWidth(),
        ) {
            // Only the difference is sent, so a locked removal that the draft
            // somehow held would still be refused by the view model.
            (draft - data.blockedPackages).forEach { onToggle(it) }
            (data.blockedPackages - draft).forEach { onToggle(it) }
            onDone()
        }
    }
}

/**
 * The lock-circle toggle from the reference — an open shackle on a muted
 * circle when this app can still be opened freely, closing itself with a
 * small bounce into a solid green circle the moment it's added to the
 * block list. Replaces what used to be a bare outline circle for "off"
 * with no matching mark at all for "on" (the whole row's colour was
 * carrying that alone); the lock is small, but it's the one part of this
 * row that actually says what selecting an app here does.
 */
@Composable
private fun LockToggle(locked: Boolean) {
    // Coin toggle (from Uiverse pixel-coin): an inked coin rolls across a
    // small track and turns its face — glum while the app is free, grinning
    // once it is blocked. Same call sites, same meaning as the old lock.
    val p by animateFloatAsState(
        if (locked) 1f else 0f,
        spring(dampingRatio = 0.55f, stiffness = 420f),
        label = "coin",
    )
    val coinFill by animateColorAsState(
        if (locked) Butter.fill else Color(0xFFB8B4A8), tween(250), label = "coin-fill",
    )
    Canvas(Modifier.size(width = 44.dp, height = 24.dp)) {
        val h = size.height
        val stroke = 2.dp.toPx()
        // track
        drawRoundRect(
            if (locked) Mint.fill.copy(alpha = 0.55f) else Color(0xFFE9E3CF),
            cornerRadius = CornerRadius(h / 2, h / 2),
        )
        drawRoundRect(Ink, cornerRadius = CornerRadius(h / 2, h / 2), style = Stroke(stroke))
        // coin
        val r = h / 2 - 3.dp.toPx()
        val cx = h / 2 + (size.width - h) * p
        val c = Offset(cx, h / 2)
        drawCircle(Ink, r, c + Offset(1.5.dp.toPx(), 1.5.dp.toPx()))
        drawCircle(coinFill, r, c)
        drawCircle(Ink, r, c, style = Stroke(1.6.dp.toPx()))
        // face rolls with the coin (one full turn across the track)
        rotate(degrees = p * 360f, pivot = c) {
            val eye = r * 0.16f
            drawCircle(Ink, eye, Offset(c.x - r * 0.36f, c.y - r * 0.18f))
            drawCircle(Ink, eye, Offset(c.x + r * 0.36f, c.y - r * 0.18f))
            val smile = -0.6f + 1.6f * p          // frown -> grin
            val mouth = Path().apply {
                moveTo(c.x - r * 0.38f, c.y + r * 0.32f)
                quadraticBezierTo(c.x, c.y + r * 0.32f + smile * r * 0.42f, c.x + r * 0.38f, c.y + r * 0.32f)
            }
            drawPath(mouth, Ink, style = Stroke(1.5.dp.toPx(), cap = StrokeCap.Round))
        }
    }
}

/**
 * The budget-slider from the reference — discrete stops rather than a true
 * continuous drag (this reads its own value from taps on each zone, the
 * same mechanism the reference's own radio-driven "slider" actually uses
 * under its continuous-looking track), colour shifting from safe to
 * "danger" as the cap gets more permissive, with the reference's own
 * panic-shake reserved for the most permissive stop — no numeric cap at
 * all, the one place this row and Shield promise the least protection.
 */
@Composable
private fun CapSlider(
    current: Int?,
    options: List<Int?>,
    onSelect: (Int?) -> Unit,
    /** This app's real use over the last week — drives the "what a cap saves you" line. */
    weeklyMinutes: Int = 0,
    /** Minutes used since midnight, or null while unknown. */
    usedToday: Int? = null,
) {
    // v5: Compose port of the uiverse "budget-slider" (owner reference):
    // paper card on a fine grid, double shadow (live colour + ink), live
    // colour that runs safe → warn → danger with the setting, striped glowing
    // fill, a springy thumb with ring + glow, value tooltip while dragging,
    // and at the most permissive stop the card panics — shake, red vignette,
    // shock rings and sparks off the thumb.
    // Positive palette (owner: any cap you set is a win, so nothing here
    // should read as a warning). Tight caps glow mint, looser ones gold, and
    // "no cap yet" is a calm lilac invite instead of a red alarm.
    val safe = Color(0xFF17E88F); val warn = Color(0xFFFFC531); val danger = Color(0xFFB9A7FF)
    val ember = Color(0xFFFF8A1E); val paper = Color(0xFFF7F4EA); val paper2 = Color(0xFFECE7D6); val ink = Color(0xFF0A0A0A)
    // A custom cap (any minutes, not one of the stops) sits on the track
    // between the stops it falls between instead of snapping to 15m.
    val presetIndex = options.indexOf(current)
    val isCustomCap = current != null && presetIndex < 0
    val index = when {
        presetIndex >= 0 -> presetIndex
        current == null -> options.lastIndex
        else -> options.indices.minByOrNull { i -> kotlin.math.abs((options[i] ?: 10_000) - current) } ?: 0
    }
    val target = if (!isCustomCap) index.toFloat() / (options.size - 1).coerceAtLeast(1) else {
        val v = current!!.toFloat()
        when {
            v <= 15f -> 0f
            v <= 30f -> (v - 15f) / 15f / 3f
            v <= 60f -> 1f / 3f + (v - 30f) / 30f / 3f
            else -> 2f / 3f + ((v.coerceAtMost(180f) - 60f) / 120f) * (1f / 3f - 0.06f)
        }
    }
    val f by animateFloatAsState(target, spring(dampingRatio = 0.55f, stiffness = 420f), label = "capF")
    val p1 = (f / 0.6f).coerceIn(0f, 1f)
    val p2 = ((f - 0.6f) / 0.4f).coerceIn(0f, 1f)
    val live = androidx.compose.ui.graphics.lerp(androidx.compose.ui.graphics.lerp(safe, warn, p1), danger, p2)
    // Kept the name for the existing draw code, but nothing panics any more:
    // no shake, no red vignette, no sparks, no error sound at the open stop.
    val noCap = current == null
    val isDanger = false
    val tier = when { noCap -> 2; current!! > 30 -> 1; else -> 0 }

    // The danger effects (shake, vignette, ring, sparks) are retired — a
    // cap is always a win now. Their four infinite transitions kept every
    // cap card ticking a frame clock forever for nothing; constants instead.
    val shakeT = 0f
    val pulse = 1f
    val ring = 0f
    val spark = 0f
    var dragging by remember { mutableStateOf(false) }
    val tip by animateFloatAsState(if (dragging) 1f else 0f, tween(180), label = "tip")

    fun pick(x: Float, w: Float) {
        val i = ((x / w) * (options.size - 1)).roundToInt().coerceIn(0, options.lastIndex)
        if (i != index) {
            Sfx.play(Sound.TICK)
            onSelect(options[i])
        }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .padding(end = 7.dp, bottom = 7.dp)
            .graphicsLayer {
                // shakeT read here only: draw-phase, no per-frame recomposition
                if (isDanger) {
                    translationX = (kotlin.math.sin(shakeT * 6.283f * 2f) * 1.5f).dp.toPx()
                    translationY = (kotlin.math.cos(shakeT * 6.283f * 3f) * 0.9f).dp.toPx()
                    rotationZ = kotlin.math.sin(shakeT * 6.283f * 2f) * 0.4f
                }
            }
            .drawBehind {
                val r = CornerRadius(16.dp.toPx())
                drawRoundRect(ink, Offset(7.dp.toPx(), 7.dp.toPx()), size, r)
                drawRoundRect(live, Offset(3.dp.toPx(), 3.dp.toPx()), size, r)
            }
            .clip(RoundedCornerShape(16.dp))
            .background(paper)
            .drawBehind {
                // fine grid
                val st = 16.dp.toPx(); val c = ink.copy(alpha = 0.035f)
                var x = 0f; while (x < size.width) { drawLine(c, Offset(x, 0f), Offset(x, size.height), 1f); x += st }
                var y = 0f; while (y < size.height) { drawLine(c, Offset(0f, y), Offset(size.width, y), 1f); y += st }
                if (isDanger) drawRect(Brush.radialGradient(listOf(danger.copy(alpha = 0.28f * pulse), Color.Transparent), Offset(size.width / 2, size.height * 0.15f), size.width * 0.65f))
            }
            .border(3.dp, ink, RoundedCornerShape(16.dp))
            .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(tr("Daily limit", "रोज़ की सीमा"), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = ink)
                Text(tr("How long it opens before it locks", "लॉक होने से पहले कितनी देर खुलेगा"), fontSize = 10.sp, color = Color(0xFF767065))
            }
            Row(
                Modifier
                    .drawBehind { drawRoundRect(ink, Offset(1.5.dp.toPx(), 1.5.dp.toPx()), size, CornerRadius(999f)) }
                    .clip(RoundedCornerShape(999.dp)).background(live).border(2.dp, ink, RoundedCornerShape(999.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(when (tier) { 2 -> "+"; 1 -> "⚡"; else -> "★" }, fontSize = 10.sp, fontWeight = FontWeight.Black, color = ink)
                Spacer(Modifier.width(4.dp))
                Text(
                    when {
                        noCap -> tr("SET A CAP", "सीमा लगाओ")
                        current!! <= 15 -> tr("BEAST MODE", "बीस्ट मोड")
                        current <= 30 -> tr("LOCKED IN", "लॉक्ड इन")
                        current <= 60 -> tr("AURA FARMING", "ऑरा फ़ार्मिंग")
                        else -> tr("W START", "बढ़िया शुरुआत")
                    },
                    fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = ink,
                )
            }
        }
        // value
        if (usedToday != null) {
            // Live usage vs limit, with a status dot: green while it still
            // opens today, orange once today's allowance is used up.
            val over = current != null && usedToday >= current
            val live by rememberInfiniteTransition(label = "liveDot").animateFloat(
                0.35f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "liveDotT",
            )
            Row(
                Modifier
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(Color.White.copy(alpha = 0.7f))
                    .border(1.5.dp, ink, RoundedCornerShape(999.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(9.dp)
                        .graphicsLayer { alpha = live }
                        .clip(CircleShape)
                        .background(if (over) Color(0xFFFF6A2E) else Color(0xFF17E88F)),
                )
                Spacer(Modifier.width(7.dp))
                Text(
                    when {
                        current == null -> tr("${usedToday}m spent today · no limit", "आज ${usedToday}m · कोई सीमा नहीं")
                        over -> tr("${usedToday}m spent / ${current}m · Blocking", "${usedToday}m / ${current}m · ब्लॉक")
                        else -> tr("${usedToday}m spent / ${current}m · ${current - usedToday}m left", "${usedToday}m / ${current}m · ${current - usedToday}m बचे")
                    },
                    fontSize = 11.sp, fontWeight = FontWeight.Black, color = ink,
                )
            }
        }
        Row(Modifier.padding(top = 10.dp, bottom = 14.dp), verticalAlignment = Alignment.Bottom) {
            androidx.compose.animation.AnimatedContent(
                targetState = current,
                transitionSpec = {
                    (androidx.compose.animation.slideInVertically(tween(220)) { it } + androidx.compose.animation.fadeIn(tween(220))) togetherWith
                        (androidx.compose.animation.slideOutVertically(tween(160)) { -it } + androidx.compose.animation.fadeOut(tween(160)))
                },
                label = "capVal",
            ) { v ->
                Box {
                    // coloured ghost glow behind the number
                    Text(if (v == null) "∞" else "$v", fontFamily = FontFamily.Monospace, fontSize = 34.sp, fontWeight = FontWeight.Bold, color = live.copy(alpha = 0.35f), modifier = Modifier.offset(2.dp, 2.dp))
                    Text(if (v == null) "∞" else "$v", fontFamily = FontFamily.Monospace, fontSize = 34.sp, fontWeight = FontWeight.Bold, color = ink)
                }
            }
            Spacer(Modifier.width(6.dp))
            Text(
                when {
                    current == null -> tr("no limit", "कोई सीमा नहीं")
                    isCustomCap -> tr("min / day · custom", "मिनट / दिन · अपना")
                    else -> tr("min / day", "मिनट / दिन")
                },
                fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (noCap) Color(0xFF5A3FC0) else Color(0xFF8A8478),
                modifier = Modifier.padding(bottom = 6.dp),
            )
        }
        // slider
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .height(58.dp)
                .pointerInput(index) {
                    detectTapGestures { pick(it.x, size.width.toFloat()) }
                }
                .pointerInput(index) {
                    detectHorizontalDragGestures(
                        onDragStart = { dragging = true; pick(it.x, size.width.toFloat()) },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false },
                    ) { ch, _ -> pick(ch.position.x, size.width.toFloat()) }
                },
        ) {
            val wPx = constraints.maxWidth.toFloat()
            Canvas(Modifier.fillMaxSize()) {
                val trackTop = 29.dp.toPx(); val th = 10.dp.toPx(); val r = CornerRadius(th / 2)
                // tick marks
                for (i in 1 until options.size - 1) {
                    val x = size.width * i / (options.size - 1)
                    drawLine(ink.copy(alpha = 0.18f), Offset(x, trackTop - 7.dp.toPx()), Offset(x, trackTop - 3.dp.toPx()), 1.5.dp.toPx())
                }
                // track
                drawRoundRect(paper2, Offset(0f, trackTop), Size(size.width, th), r)
                val fw = (size.width * f).coerceAtLeast(th)
                // glow + fill + stripes + bright head
                for (g in 1..3) drawRoundRect(live.copy(alpha = 0.12f * (1f - g / 4f)), Offset(-g * 3f, trackTop - g * 3f), Size(fw + g * 6f, th + g * 6f), CornerRadius(th / 2 + g * 3f))
                clipRect(0f, trackTop, fw, trackTop + th) {
                    drawRoundRect(live, Offset(0f, trackTop), Size(fw, th), r)
                    var sx = -th * 2
                    while (sx < fw) {
                        drawLine(Color.White.copy(alpha = 0.28f), Offset(sx, trackTop + th), Offset(sx + th, trackTop), 5f)
                        sx += 10.dp.toPx()
                    }
                    drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.5f)), startX = fw - 12.dp.toPx(), endX = fw), Offset(fw - 12.dp.toPx(), trackTop), Size(12.dp.toPx(), th))
                }
                drawRoundRect(ink, Offset(0f, trackTop), Size(size.width, th), r, style = Stroke(2.dp.toPx()))
                // thumb
                val cx = (size.width * f).coerceIn(10.dp.toPx(), size.width - 10.dp.toPx())
                val cy = trackTop + th / 2
                if (isDanger) {
                    for (k in 0..1) {
                        val rr = ((ring + k * 0.36f) % 1f)
                        drawCircle(danger.copy(alpha = 0.65f * (1f - rr)), 9.dp.toPx() * (0.6f + 1.8f * rr), Offset(cx, cy), style = Stroke(1.5.dp.toPx()))
                    }
                    val dirs = listOf(-20f to -15f, 18f to -18f, -14f to 14f, 15f to 16f, 0f to -23f, -24f to 1f, 23f to 3f, 3f to 19f)
                    dirs.forEachIndexed { i, (dx, dy) ->
                        val ph = (spark + i * 0.09f) % 1f
                        val col = if (i % 3 == 0) ember else danger
                        drawCircle(col.copy(alpha = 1f - ph), (if (i % 2 == 0) 1.75f else 1.25f).dp.toPx(), Offset(cx + dx.dp.toPx() * ph, cy + dy.dp.toPx() * ph))
                    }
                }
                val jit = if (isDanger) 1f + 0.14f * kotlin.math.abs(kotlin.math.sin(shakeT * 12.56f)) else 1f
                val tr0 = 9.5.dp.toPx() * jit
                drawCircle(live.copy(alpha = 0.35f), tr0 + 9.dp.toPx(), Offset(cx, cy))
                drawCircle(paper.copy(alpha = 0.9f), tr0 + 5.dp.toPx(), Offset(cx, cy))
                drawCircle(ink, tr0 + 3.dp.toPx(), Offset(cx, cy))
                drawCircle(Brush.radialGradient(listOf(Color.White, paper), Offset(cx - tr0 * 0.3f, cy - tr0 * 0.4f), tr0), tr0, Offset(cx, cy))
                drawCircle(live, tr0 - 1.5.dp.toPx(), Offset(cx, cy), style = Stroke(3.dp.toPx()))
            }
            // tooltip while dragging
            if (tip > 0.01f) {
                val x = (wPx * f).coerceIn(24f, wPx - 24f)
                Text(
                    if (current == null) "∞" else "${current}m",
                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = paper,
                    modifier = Modifier
                        .offset { IntOffset((x - 18.dp.toPx()).roundToInt(), 0) }
                        .graphicsLayer { alpha = tip; val s = 0.85f + 0.15f * tip; scaleX = s; scaleY = s; translationY = (1f - tip) * -5.dp.toPx() }
                        .clip(RoundedCornerShape(5.dp)).background(ink).padding(horizontal = 7.dp, vertical = 3.dp),
                )
            }
        }
        // stop labels
        Row(Modifier.fillMaxWidth()) {
            options.forEachIndexed { i, o ->
                Text(
                    if (o == null) "∞" else "${o}m",
                    fontSize = 10.sp, fontWeight = if (i == index) FontWeight.Black else FontWeight.Bold,
                    color = if (i == index) ink else Color(0xFF8A8478),
                    textAlign = when (i) { 0 -> TextAlign.Start; options.lastIndex -> TextAlign.End; else -> TextAlign.Center },
                    modifier = Modifier.weight(1f),
                )
            }
        }

        // Why bother capping: this app's own week, turned into time back.
        // Without this the card only ever said DANGER and gave nobody a
        // reason to move the thumb.
        val daily = weeklyMinutes / 7
        fun hm(m: Int) = if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
        val why: String? = when {
            daily <= 0 -> null
            current == null -> tr(
                "You spend ~${hm(daily)}/day here. A 30m cap gives back ~${hm(((daily - 30).coerceAtLeast(0)) * 7)} a week.",
                "यहाँ रोज़ ~${hm(daily)} जाते हैं। 30m की सीमा से हफ़्ते में ~${hm(((daily - 30).coerceAtLeast(0)) * 7)} वापस।",
            )
            daily > current -> tr(
                "Saves ~${hm((daily - current) * 7)} a week vs your usual ${hm(daily)}/day. Aura +.",
                "आपके रोज़ के ${hm(daily)} के मुकाबले हफ़्ते में ~${hm((daily - current) * 7)} बचेंगे।",
            )
            else -> tr(
                "Already under your usual ${hm(daily)}/day. Tight cap, big aura.",
                "आपके रोज़ के ${hm(daily)} से पहले ही कम। बढ़िया।",
            )
        }
        if (why != null) {
            Spacer(Modifier.height(10.dp))
            Text(why, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ink.copy(alpha = 0.8f))
        }

        // Quick fixes + your own number. Any minutes 5..180 work: the
        // blocker reads dailyCapMinutes as a plain Int, presets are only
        // shortcuts. A live pact still refuses loosening in the ViewModel.
        var customOpen by remember { mutableStateOf(false) }
        var customV by remember(current) { mutableIntStateOf(current ?: 45) }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (current == null) {
                CapChip(tr("Try 30m", "30m आज़माएँ"), safe, ink) { onSelect(30) }
            }
            CapChip(
                if (customOpen) tr("Close", "बंद") else tr("Set my own", "अपना सेट करें"),
                if (customOpen) paper2 else Color(0xFFB9A7FF), ink,
            ) { customOpen = !customOpen }
        }
        androidx.compose.animation.AnimatedVisibility(
            visible = customOpen,
            enter = androidx.compose.animation.expandVertically(tween(200)) + androidx.compose.animation.fadeIn(tween(200)),
            exit = androidx.compose.animation.shrinkVertically(tween(160)) + androidx.compose.animation.fadeOut(tween(160)),
        ) {
            Row(
                Modifier.padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                CapChip("−", paper2, ink) { customV = (customV - 5).coerceAtLeast(5) }
                Text(
                    "${customV}m",
                    fontFamily = FontFamily.Monospace, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ink,
                    modifier = Modifier.widthIn(min = 64.dp), textAlign = TextAlign.Center,
                )
                CapChip("+", paper2, ink) { customV = (customV + 5).coerceAtMost(180) }
                Spacer(Modifier.weight(1f))
                CapChip(tr("Set", "सेट"), safe, ink) {
                    onSelect(customV); customOpen = false
                }
            }
        }
    }
}

/** Small inked chip for the cap card: hard shadow, closes into it on press. */
@Composable
private fun CapChip(label: String, fill: Color, ink: Color, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 1f else 0f, Motion.press(), label = "capChip")
    Text(
        label,
        fontSize = 12.sp, fontWeight = FontWeight.Black, color = ink,
        modifier = Modifier
            .drawBehind {
                val d = 2.5.dp.toPx() * (1f - press)
                drawRoundRect(ink, Offset(d, d), size, CornerRadius(999f))
            }
            .graphicsLayer { translationX = 2.5.dp.toPx() * press; translationY = 2.5.dp.toPx() * press }
            .clip(RoundedCornerShape(999.dp))
            .background(fill)
            .border(2.dp, ink, RoundedCornerShape(999.dp))
            .clickableNoRipple(interaction, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp),
    )
}

/**
 * The purple-blue blur spinner from the reference in place of the plain
 * default CircularProgressIndicator — a rotating gradient disc with its
 * own soft glow, for the one wait in this screen (scanning every
 * installed app) that's long enough to actually notice.
 */
@Composable
private fun BlurSpinner(size: Dp) {
    val infinite = rememberInfiniteTransition(label = "blur-spinner")
    val angle by infinite.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(1700, easing = LinearEasing)),
        label = "angle",
    )
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(
            Modifier
                .matchParentSize()
                .blur(10.dp),
        ) {
            drawCircle(
                brush = Brush.radialGradient(listOf(Lilac.fill.copy(alpha = 0.55f), Color.Transparent)),
                radius = this.size.minDimension * 0.62f,
                center = Offset(this.size.width * 0.5f, this.size.height * 0.1f),
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(Sky.fill.copy(alpha = 0.55f), Color.Transparent)),
                radius = this.size.minDimension * 0.62f,
                center = Offset(this.size.width * 0.5f, this.size.height * 0.9f),
            )
        }
        Canvas(Modifier.matchParentSize()) {
            rotate(angle) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(Lilac.fill, Sky.fill, Lilac.fill)),
                    startAngle = 0f,
                    sweepAngle = 300f,
                    useCenter = false,
                    style = Stroke(width = this.size.minDimension * 0.14f, cap = StrokeCap.Round),
                )
            }
        }
    }
}

/** Inked search field, pinned above the app list. */
@Composable
private fun AppSearchBar(query: String, onQuery: (String) -> Unit) {
    val shape = RoundedCornerShape(999.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 10.dp),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .drawBehind {
                    val d = 3.dp.toPx()
                    drawRoundRect(Ink, Offset(d, d), size, CornerRadius(size.height / 2))
                }
                .clip(shape)
                .background(CreamCard)
                .border(Paper.Outline, Ink, shape)
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Search, contentDescription = null, tint = Ink, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text(tr("Search an app to block", "ब्लॉक करने के लिए ऐप खोजें"), style = MaterialTheme.typography.bodyLarge, color = InkLow)
                }
                androidx.compose.foundation.text.BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = Ink),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(Ink),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (query.isNotEmpty()) {
                Icon(
                    Icons.Filled.Close, contentDescription = null, tint = Ink,
                    modifier = Modifier.size(20.dp).clickableNoRipple(remember { MutableInteractionSource() }) { onQuery("") },
                )
            }
        }
    }
}
