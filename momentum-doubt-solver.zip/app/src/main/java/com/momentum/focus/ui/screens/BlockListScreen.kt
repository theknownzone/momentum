package com.momentum.focus.ui.screens

import android.content.Intent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.block.BlockerService
import com.momentum.focus.data.AppCatalog
import com.momentum.focus.data.AppData
import com.momentum.focus.data.CataloguedApp
import com.momentum.focus.data.Currency
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.sin
import com.momentum.focus.ui.components.AppIcon
import com.momentum.focus.ui.components.Coin3D
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

@Composable
fun BlockListScreen(
    data: AppData,
    onToggle: (String) -> Unit,
    onCap: (String, Int?) -> Unit,
    onDone: () -> Unit,
    preselectTop: Boolean = false,
    /** Non-null while removals are refused, and says why. */
    editLock: String? = null,
) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    // A refused tap used to do nothing at all — the row simply did not change
    // and nothing said why, which read as the app being broken rather than
    // holding a line the user had set.
    var refused by remember { mutableStateOf(false) }

    // A draft. Tapping a row used to write straight to the store, so there was
    // no way to change your mind and no moment where the choice felt made —
    // people would tap around, leave, and not be sure what had stuck. Nothing
    // is committed until Save.
    var draft by remember(data.blockedPackages) {
        mutableStateOf(data.blockedPackages)
    }
    LaunchedEffect(refused) {
        if (refused) { kotlinx.coroutines.delay(2600); refused = false }
    }

    // Only apps with a launcher icon. Listing every installed package would
    // bury the four apps anyone actually wants to block.
    // Sorted by how much time each app actually took this week, so the ones
    // that cost the most sit at the top instead of whatever starts with "A".
    // Enumerating every launchable app on the phone (queryIntentActivities,
    // then a label lookup for each) genuinely takes real IO thread time on a
    // phone with 100+ apps installed — already off the main thread, so it
    // was never actually janky, but nothing on screen said so, and a blank
    // list for a second or two reads as the screen having hung. This is
    // purely a "say something's happening" fix; the scan itself is unchanged.
    var loading by remember { mutableStateOf(true) }
    val apps by produceState(initialValue = emptyList<CataloguedApp>()) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                // Phone, contacts, clock and settings are never blockable, so
                // offering them as choices only invites a lockout the pact will
                // then refuse to undo.
                AppCatalog.scan(context)
                    .filterNot { BlockerService.isNeverBlocked(it.pkg) }
            }.getOrDefault(emptyList())
        }
        loading = false
    }

    // The three biggest time sinks are ticked for you. An empty list is the
    // most common way this screen gets skipped, and the apps that hurt most
    // are exactly the ones nobody volunteers to block.
    var preselected by remember { mutableStateOf(false) }
    LaunchedEffect(apps) {
        if (preselectTop && !preselected && apps.isNotEmpty() && draft.isEmpty()) {
            preselected = true
            // Into the draft, not the store — the preselection is a suggestion
            // like any other tap, and Save is still what makes it real.
            draft = draft + apps.filter { it.isDistraction }.take(3).map { it.pkg }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 20.dp),
    ) {
        Text(
            "SHIELD",
            style = MaterialTheme.typography.labelSmall,
            color = Tang.accent,
        )

        if (editLock != null) {
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Paper.ChipRadius))
                    .background(if (refused) Tang.fill else Sunk)
                    .border(Paper.Outline, Ink, RoundedCornerShape(Paper.ChipRadius))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            ) {
                Text(
                    editLock,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (refused) Tang.on else InkMid,
                )
            }
        }
        Text(
            "Your biggest time sinks",
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            "${draft.size} selected · sorted by time spent",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(14.dp))

        // The one thing this screen never actually said: what turning a
        // toggle on does, and why a coin appears next to it. Both facts in
        // one line, once, rather than a user discovering either by trial —
        // opening the app and hitting a lock screen for the first time, or
        // wondering where a stray ₹10 came from.
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Sky.fill.copy(alpha = 0.30f))
                .border(1.5.dp, Sky.accent.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(30.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(Sky.accent.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center,
            ) {
                Text("🔒", fontSize = 15.sp)
            }
            Spacer(Modifier.width(10.dp))
            Text(
                "Apps you turn on show a lock screen instead of opening instantly — and earn ₹10 each toward your wallet.",
                style = MaterialTheme.typography.bodyMedium,
                color = Ink,
                lineHeight = 18.sp,
            )
        }

        Spacer(Modifier.height(14.dp))

        LazyColumn(Modifier.weight(1f)) {
            if (loading) {
                item {
                    Column(
                        Modifier.fillMaxWidth().padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        BlurSpinner(size = 48.dp)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Reading installed apps…",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            items(apps, key = { it.pkg }) { app ->
                val on = app.pkg in draft
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Tang.fill else CreamCard)
                        .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            val removing = app.pkg in draft
                            if (removing && editLock != null) {
                                haptics.press(); refused = true
                            } else {
                                haptics.tick()
                                draft = if (removing) draft - app.pkg else draft + app.pkg
                            }
                        }
                        .padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AppIcon(app.pkg, size = 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            app.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (on) Tang.on else Ink,
                        )
                        Text(
                            buildString {
                                append(app.kind.label)
                                if (app.minutes > 0) {
                                    append(" · ")
                                    append("%dh %02dm this week".format(app.minutes / 60, app.minutes % 60))
                                }
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (on) Tang.on.copy(alpha = 0.75f) else InkMid,
                        )
                    }
                    if (on) {
                        // Showing the price on the row makes the trade explicit
                        // while the user is calm, which is the only time the
                        // number can actually change a decision.
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Coin3D(color = Butter.fill, size = 22.dp)
                            Spacer(Modifier.width(6.dp))
                            Text(
                                Currency.format(10),
                                style = MaterialTheme.typography.titleMedium,
                                color = Tang.on,
                            )
                            Spacer(Modifier.width(8.dp))
                            LockToggle(locked = true)
                        }
                    } else {
                        LockToggle(locked = false)
                    }
                }
                // The cap only appears once the app is blocked, because a cap
                // on an app that is not blocked would never be enforced. Off
                // by default: this tightens the shield, so it is opt in.
                if (on) {
                    val cap = data.dailyCapMinutes[app.pkg]
                    Column(Modifier.padding(start = 14.dp, bottom = 10.dp)) {
                        // "Daily cap" and bare option numbers (15/30/60, "Off")
                        // asked a new user to already know that this app still
                        // opens for a few minutes before it locks, and that
                        // those numbers are minutes. Said in one line instead,
                        // and every option carries its own unit so no pill
                        // needs the row's label to make sense on its own.
                        Text(
                            if (cap == null) "Still opens for a few minutes before it locks"
                            else "Opens for $cap min, then locks for today",
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMid,
                        )
                        Spacer(Modifier.height(10.dp))
                        CapSlider(
                            current = cap,
                            options = listOf(15, 30, 60, null),
                            onSelect = { haptics.tick(); onCap(app.pkg, it) },
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        SquishButton(
            // Says Save because it now saves. Calling it Done while every tap
            // had already written itself was the honest name for the old
            // behaviour and the wrong one for this.
            label = if (draft == data.blockedPackages) "Done" else "Save",
            sticker = Mint,
            modifier = Modifier.fillMaxWidth(),
        ) {
            // Only the difference is sent, so a locked removal that the draft
            // somehow held would still be refused by the view model.
            (draft - data.blockedPackages).forEach { onToggle(it) }
            (data.blockedPackages - draft).forEach { onToggle(it) }
            onDone()
        }
    }
}

/**
 * The lock-circle toggle from the reference — an open shackle on a muted
 * circle when this app can still be opened freely, closing itself with a
 * small bounce into a solid green circle the moment it's added to the
 * block list. Replaces what used to be a bare outline circle for "off"
 * with no matching mark at all for "on" (the whole row's colour was
 * carrying that alone); the lock is small, but it's the one part of this
 * row that actually says what selecting an app here does.
 */
@Composable
private fun LockToggle(locked: Boolean) {
    val bg by animateColorAsState(
        if (locked) Mint.fill else Color(0xFFB8B4A8),
        tween(250),
        label = "lock-bg",
    )
    val shackle by animateFloatAsState(
        if (locked) 1f else 0f,
        spring(dampingRatio = 0.5f, stiffness = 400f),
        label = "lock-shackle",
    )
    val bounce by animateFloatAsState(
        if (locked) 1f else 0.88f,
        spring(dampingRatio = 0.4f, stiffness = 500f),
        label = "lock-bounce",
    )

    Canvas(
        Modifier
            .size(20.dp)
            .graphicsLayer { scaleX = bounce; scaleY = bounce },
    ) {
        val cx = size.width / 2f
        val bodyTop = size.height * 0.48f
        val bodyH = size.height * 0.40f
        val bodyW = size.width * 0.62f

        // The shackle swings from open (rotated left, gap showing) to
        // closed (centred over the body) as `shackle` animates.
        val shackleR = size.width * 0.20f
        val openOffset = (1f - shackle) * size.width * 0.20f
        val shackleCx = cx - openOffset
        rotate(degrees = (1f - shackle) * -35f, pivot = Offset(cx - shackleR, bodyTop)) {
            drawArc(
                color = Ink,
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = Offset(shackleCx - shackleR, bodyTop - shackleR * 1.3f),
                size = Size(shackleR * 2f, shackleR * 2.1f),
                style = Stroke(width = size.width * 0.13f, cap = StrokeCap.Round),
            )
        }
        drawRoundRect(
            color = bg,
            topLeft = Offset(cx - bodyW / 2f, bodyTop),
            size = Size(bodyW, bodyH),
            cornerRadius = CornerRadius(size.width * 0.10f, size.width * 0.10f),
        )
        drawRoundRect(
            color = Ink,
            topLeft = Offset(cx - bodyW / 2f, bodyTop),
            size = Size(bodyW, bodyH),
            cornerRadius = CornerRadius(size.width * 0.10f, size.width * 0.10f),
            style = Stroke(width = 1.4.dp.toPx()),
        )
    }
}

/**
 * The budget-slider from the reference — discrete stops rather than a true
 * continuous drag (this reads its own value from taps on each zone, the
 * same mechanism the reference's own radio-driven "slider" actually uses
 * under its continuous-looking track), colour shifting from safe to
 * "danger" as the cap gets more permissive, with the reference's own
 * panic-shake reserved for the most permissive stop — no numeric cap at
 * all, the one place this row and Shield promise the least protection.
 */
@Composable
private fun CapSlider(
    current: Int?,
    options: List<Int?>,
    onSelect: (Int?) -> Unit,
) {
    val index = options.indexOf(current).coerceAtLeast(0)
    val fraction = index.toFloat() / (options.size - 1).toFloat()
    val danger = index == options.lastIndex

    val shakeX = if (danger) {
        val infinite = rememberInfiniteTransition(label = "cap-danger-shake")
        val t by infinite.animateFloat(
            0f, 1f,
            infiniteRepeatable(tween(320, easing = LinearEasing), RepeatMode.Reverse),
            label = "t",
        )
        (sin(t * 6.28f) * 1.4f)
    } else 0f

    val trackColor by animateColorAsState(
        when {
            danger -> Color(0xFFFF5B5B)
            index == options.lastIndex - 1 -> Color(0xFFFFB020)
            else -> Mint.fill
        },
        tween(250),
        label = "cap-track-color",
    )
    val thumbX by animateFloatAsState(fraction, spring(dampingRatio = 0.7f, stiffness = 300f), label = "cap-thumb-x")

    Column {
        Text(
            options[index]?.let { "${it} minutes" } ?: "No daily limit",
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = if (danger) Color(0xFFB23A3A) else InkMid,
        )
        Spacer(Modifier.height(6.dp))
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .height(28.dp)
                .graphicsLayer { translationX = shakeX },
        ) {
            val trackWidth = maxWidth
            Box(
                Modifier
                    .align(Alignment.CenterStart)
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0x1A000000)),
            )
            Box(
                Modifier
                    .align(Alignment.CenterStart)
                    .width(trackWidth * fraction)
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(trackColor),
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                options.forEachIndexed { i, opt ->
                    Box(
                        Modifier
                            .size(28.dp)
                            .clickableNoRipple(remember { MutableInteractionSource() }) { onSelect(opt) },
                        contentAlignment = Alignment.Center,
                    ) {
                        val selected = i == index
                        Box(
                            Modifier
                                .size(if (selected) 20.dp else 12.dp)
                                .clip(CircleShape)
                                .background(if (selected) trackColor else CreamCard)
                                .border(2.dp, Ink, CircleShape),
                        )
                    }
                }
            }
        }
    }
}

/**
 * The purple-blue blur spinner from the reference in place of the plain
 * default CircularProgressIndicator — a rotating gradient disc with its
 * own soft glow, for the one wait in this screen (scanning every
 * installed app) that's long enough to actually notice.
 */
@Composable
private fun BlurSpinner(size: Dp) {
    val infinite = rememberInfiniteTransition(label = "blur-spinner")
    val angle by infinite.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(1700, easing = LinearEasing)),
        label = "angle",
    )
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(
            Modifier
                .matchParentSize()
                .blur(10.dp),
        ) {
            drawCircle(
                brush = Brush.radialGradient(listOf(Lilac.fill.copy(alpha = 0.55f), Color.Transparent)),
                radius = this.size.minDimension * 0.62f,
                center = Offset(this.size.width * 0.5f, this.size.height * 0.1f),
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(Sky.fill.copy(alpha = 0.55f), Color.Transparent)),
                radius = this.size.minDimension * 0.62f,
                center = Offset(this.size.width * 0.5f, this.size.height * 0.9f),
            )
        }
        Canvas(Modifier.matchParentSize()) {
            rotate(angle) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(Lilac.fill, Sky.fill, Lilac.fill)),
                    startAngle = 0f,
                    sweepAngle = 300f,
                    useCenter = false,
                    style = Stroke(width = this.size.minDimension * 0.14f, cap = StrokeCap.Round),
                )
            }
        }
    }
}
