package com.momentum.focus.ui.i18n

/**
 * The five-step tour a new install gets, once, before the first real screen.
 *
 * This one was never wired to the language switch at all — TourOverlay held
 * five steps of title/body text as Kotlin string literals, written in
 * Hinglish, with no English counterpart anywhere. Someone using the app in
 * English got every other onboarding screen in English and then this one
 * popup in Hinglish, which is exactly the failure [ProfilesStrings]'s own
 * comment describes for three other screens — this is a fourth instance of
 * the same bug, not a new kind of one.
 */
interface TourStrings {
    val step1Title: String
    val step1Body: String
    val step2Title: String
    val step2Body: String
    val step3Title: String
    val step3Body: String
    val step4Title: String
    val step4Body: String
    val step5Title: String
    val step5Body: String
    val next: String
    val start: String
    val skip: String
}

object TourHi : TourStrings {
    override val step1Title = "Padho, phir kamao"
    override val step1Body =
        "Focus tab pe timer chalao. Jitne minute padhoge, utne ₹ wallet mein aayenge. " +
            "Bina padhe kuch nahi milta — yahi poori app ka niyam hai."
    override val step2Title = "Shield apps rokta hai"
    override val step2Body =
        "Jo apps tum chuno, unpe shield lag jaata hai. Khologe to block screen aayegi. " +
            "Wallet se time khareed sakte ho, par apni hi daily limit se aage nahi."
    override val step3Title = "Feeds alag se rukti hain"
    override val step3Body =
        "Shorts, Reels, Stories band ho sakti hain jabki baaki app chalti rahe. " +
            "YouTube pe lecture chalega, Shorts nahi. Iske liye Accessibility on karni padegi."
    override val step4Title = "Pact sirf sakht hota hai"
    override val step4Body =
        "Pact laga do to level girana, shield band karna ya limit dheeli karna band. " +
            "Sirf badha sakte ho. Jo khud se decide kiya, wo kamzor pal mein badla nahi ja sakta."
    override val step5Title = "Numbers sach hote hain"
    override val step5Body =
        "Streak tabhi badhega jab sach mein padhoge. Ginti tabhi shuru hogi jab data hoga. " +
            "Jo yahan dikhega wo kamaya hua hoga, banaya hua nahi."
    override val next = "Aage"
    override val start = "Shuru karo"
    override val skip = "Chhod do"
}

object TourEn : TourStrings {
    override val step1Title = "Study, then earn"
    override val step1Body =
        "Run the timer on the Focus tab. Every minute you study adds ₹ to the wallet. " +
            "Nothing without studying — that's the one rule the whole app runs on."
    override val step2Title = "The shield blocks apps"
    override val step2Body =
        "Whichever apps you pick get the shield. Open one and the block screen shows up. " +
            "You can buy time back from the wallet, but never past your own daily limit."
    override val step3Title = "Feeds are blocked on their own"
    override val step3Body =
        "Shorts, Reels and Stories can be blocked while the rest of the app still works. " +
            "YouTube for the lecture, not for Shorts. This one needs Accessibility turned on."
    override val step4Title = "A pact only tightens"
    override val step4Body =
        "Lock in a pact and you can no longer drop a level, turn off the shield, or loosen a " +
            "limit — only raise them. What you decided sober can't be undone in a weak moment."
    override val step5Title = "The numbers are real"
    override val step5Body =
        "The streak only grows when you actually study. The count only starts once there's " +
            "data. Whatever shows up here was earned, not made up."
    override val next = "Next"
    override val start = "Get started"
    override val skip = "Skip"
}
