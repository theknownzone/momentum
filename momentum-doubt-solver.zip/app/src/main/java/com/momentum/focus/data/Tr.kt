package com.momentum.focus.data

/**
 * Current app language for code with no composition (services, view model,
 * notifications). Set from AppData.lang by the theme and the two services.
 */
object AppLang {
    @Volatile var code: String = "en"
}

/** English or Devanagari Hindi, by the current app language. */
fun tr(en: String, hi: String): String = if (AppLang.code == "hi") hi else en
