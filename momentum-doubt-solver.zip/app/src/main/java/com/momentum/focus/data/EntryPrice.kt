package com.momentum.focus.data

import java.time.LocalTime

/**
 * What it costs to open a blocked app right now, and how long the shield
 * makes you wait first (plans/APP_FEATURES_PLAN.md · B "Reel economy 2.0" +
 * "Countdown badhta jaaye").
 *
 * All Scroll-₹ (banked minutes), never real money. Every rule here is a real,
 * stated rule — no fake urgency, no hidden price:
 *  - HAPPY HOUR: within 10 min of banking a study session, half price.
 *    Earned, so it wins over surge.
 *  - SURGE: 11 PM – 1 AM, double. The hour scrolling eats sleep.
 *  - Wait: 7s on the first shield of the day, 10s on the second, 15s from the
 *    third. The one-sec study (PNAS) found the wait, not a lecture, is what
 *    makes people close the app — so it grows, the copy stays short.
 */
object EntryPrice {
    const val BASE = 10
    /** Minutes of access a purchase buys (unchanged by price). */
    const val ACCESS_MINUTES = 10
    private const val HAPPY_WINDOW_MS = 10 * 60_000L

    enum class Kind { NORMAL, SURGE, HAPPY }

    data class Quote(val price: Int, val kind: Kind)

    fun quote(
        nowMs: Long = System.currentTimeMillis(),
        lastBankedAtMs: Long,
        hour: Int = LocalTime.now().hour,
    ): Quote {
        val since = nowMs - lastBankedAtMs
        return when {
            lastBankedAtMs > 0L && since in 0..HAPPY_WINDOW_MS -> Quote(BASE / 2, Kind.HAPPY)
            hour == 23 || hour == 0 -> Quote(BASE * 2, Kind.SURGE)
            else -> Quote(BASE, Kind.NORMAL)
        }
    }

    /** [showsToday] includes the shield being shown now (1 = first today). */
    fun waitSeconds(showsToday: Int): Int = when {
        showsToday <= 1 -> 7
        showsToday == 2 -> 10
        else -> 15
    }
}
