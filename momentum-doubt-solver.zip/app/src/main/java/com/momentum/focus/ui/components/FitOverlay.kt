package com.momentum.focus.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * The app-wide "fits every screen" rule for popups (owner: buttons hiding
 * under the nav bar / app tab bar, again and again).
 *
 * FitDialog = a full-window Dialog (sits ABOVE the app's own bottom tab bar)
 * that measures the real usable height on THIS phone — status bar on top,
 * and the larger of the nav-bar inset and the system nav-bar height resource
 * at the bottom (some OEM dialogs report 0 insets). Content gets that height
 * as [maxHeight] so it can cap itself and pin its main button.
 */
@Composable
fun rememberSafeBottom(): Dp {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val insetPx = WindowInsets.navigationBars.getBottom(density)
    val resPx = remember {
        val id = ctx.resources.getIdentifier("navigation_bar_height", "dimen", "android")
        if (id > 0) ctx.resources.getDimensionPixelSize(id) else 0
    }
    return with(density) { maxOf(insetPx, resPx).toDp() }
}

@Composable
fun FitDialog(
    onDismiss: () -> Unit,
    content: @Composable BoxScope.(maxHeight: Dp) -> Unit,
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        val bottom = rememberSafeBottom()
        val density = LocalDensity.current
        val top = with(density) { WindowInsets.statusBars.getTop(density).toDp() }
        val screen = LocalConfiguration.current.screenHeightDp.dp
        val usable = (screen - top - bottom - 24.dp).coerceAtLeast(320.dp)
        Box(Modifier.fillMaxSize().padding(top = top, bottom = bottom)) { content(usable) }
    }
}
