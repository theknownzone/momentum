package com.momentum.focus.ui.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import androidx.core.content.FileProvider
import com.momentum.focus.data.ScreenTimeReport
import com.momentum.focus.ui.i18n.RoastStrings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

/**
 * The Screen Time Roast — a 1080x1920 (9:16) story poster built from the real
 * UsageStats week, never an estimate.
 *
 * Same approach as [ShareCard]: drawn straight onto a Bitmap off the main
 * thread, written to cacheDir, handed out through the app's FileProvider. A
 * fixed size means it looks the same on a ₹6k phone and a flagship.
 *
 * Look: the app's paper/comic brand — grid paper, 8px ink outlines, hard
 * offset ink shadows, flat sticker fills, one tilted verdict stamp. No emoji,
 * no clip-art; every mark on it is drawn here.
 *
 * Memory: one ARGB_8888 bitmap (~8 MB) that is recycled right after the PNG is
 * written, so a 2 GB phone never holds two of them.
 */
object RoastCard {

    private const val W = 1080
    private const val H = 1920

    /** 0 = best … 4 = worst, by daily average minutes. */
    fun tier(averageMinutes: Int): Int = when {
        averageMinutes <= 60 -> 0
        averageMinutes <= 120 -> 1
        averageMinutes <= 240 -> 2
        averageMinutes <= 360 -> 3
        else -> 4
    }

    /** Days of a year the current daily average adds up to. */
    fun daysPerYear(averageMinutes: Int): Int = (averageMinutes * 365f / 1440f).roundToInt()

    /** Returns false if nothing could be shared (no data / IO failure). */
    suspend fun share(context: Context, report: ScreenTimeReport, s: RoastStrings): Boolean {
        if (!report.hasData) return false
        val uri = withContext(Dispatchers.IO) {
            runCatching {
                val bmp = render(report, s)
                val file = File(context.cacheDir, "momentum-roast.png")
                try {
                    file.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                } finally {
                    bmp.recycle()
                }
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            }.getOrNull()
        } ?: return false

        return withContext(Dispatchers.Main) {
            runCatching {
                val t = tier(report.averageMinutes)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(
                        Intent.EXTRA_TEXT,
                        s.shareText(daysPerYear(report.averageMinutes), s.tiers[t]),
                    )
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, s.chooserTitle))
                true
            }.getOrDefault(false)
        }
    }

    // ── Palette (mirrors ui/theme/Color.kt) ──
    private val CREAM = Color.parseColor("#FBF3D5")
    private val CARD = Color.parseColor("#FFFDF2")
    private val GRID = Color.parseColor("#E8D98E")
    private val SUNK = Color.parseColor("#F2E7BE")
    private val INK = Color.parseColor("#1A1A1A")
    private val INK_MID = Color.parseColor("#8A7A3E")
    private val MINT = Color.parseColor("#3FE28F")
    private val BUTTER = Color.parseColor("#FFD84D")
    private val TANG = Color.parseColor("#FF8A5C")
    private val LILAC = Color.parseColor("#B9A7FF")
    private val SKY = Color.parseColor("#7FD4FF")
    private val CANDY = Color.parseColor("#FF9EC4")

    /** Tier colour: green when it's good, warming as it gets worse. */
    private val TIER_FILL = intArrayOf(MINT, SKY, BUTTER, TANG, CANDY)

    internal fun render(report: ScreenTimeReport, s: RoastStrings): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        val black = Typeface.create("sans-serif-black", Typeface.NORMAL)
        val bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; color = INK; strokeWidth = 8f
            strokeJoin = Paint.Join.ROUND
        }
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = INK; typeface = bold }

        // Paper.
        c.drawColor(CREAM)
        val gridPaint = Paint().apply { color = GRID; strokeWidth = 2f }
        var g = 0f
        while (g < W) { c.drawLine(g, 0f, g, H.toFloat(), gridPaint); g += 90f }
        g = 0f
        while (g < H) { c.drawLine(0f, g, W.toFloat(), g, gridPaint); g += 90f }

        /** Comic block: hard offset ink shadow, flat fill, ink outline. */
        fun block(r: RectF, color: Int, radius: Float = 36f, shadow: Float = 14f) {
            fill.color = INK
            c.drawRoundRect(RectF(r.left + shadow, r.top + shadow, r.right + shadow, r.bottom + shadow), radius, radius, fill)
            fill.color = color
            c.drawRoundRect(r, radius, radius, fill)
            c.drawRoundRect(r, radius, radius, stroke)
        }

        /** Draws [str] shrunk until it fits [maxW]; returns the size used. */
        fun fitText(str: String, x: Float, y: Float, size: Float, maxW: Float, p: Paint): Float {
            p.textSize = size
            while (p.measureText(str) > maxW && p.textSize > 18f) p.textSize -= 2f
            c.drawText(str, x, y, p)
            return p.textSize
        }

        val avg = report.averageMinutes
        val t = tier(avg)
        val days = daysPerYear(avg)
        val left = 80f
        val right = W - 80f

        // ── Header: wordmark + badge ──
        text.typeface = black; text.color = INK
        fitText("MOMENTUM", left, 150f, 54f, 420f, text)
        text.typeface = bold
        text.textSize = 30f
        val badgeW = text.measureText(s.badge) + 56f
        val badge = RectF(right - badgeW, 100f, right, 160f)
        block(badge, INK, 30f, 0f)
        text.color = BUTTER
        c.drawText(s.badge, badge.left + 28f, 141f, text)

        // ── Hero: X DAYS a year ──
        val hero = RectF(left, 230f, right, 790f)
        block(hero, CARD, 44f, 18f)
        text.color = INK_MID; text.typeface = bold
        fitText(s.kicker, hero.left + 56f, hero.top + 100f, 44f, hero.width() - 112f, text)
        text.color = INK; text.typeface = black
        fitText(s.days(days), hero.left + 48f, hero.top + 370f, 250f, hero.width() - 96f, text)
        // Marker swipe under the number — the app's MarkerTitle, on paper.
        fill.color = TANG
        val swipe = Path().apply {
            moveTo(hero.left + 56f, hero.top + 410f)
            lineTo(hero.right - 120f, hero.top + 398f)
            lineTo(hero.right - 110f, hero.top + 428f)
            lineTo(hero.left + 60f, hero.top + 440f)
            close()
        }
        c.drawPath(swipe, fill)
        text.typeface = bold; text.color = INK
        fitText(s.daysSub, hero.left + 56f, hero.top + 515f, 54f, hero.width() - 112f, text)

        // ── Verdict stamp, tilted like it was slapped on ──
        val stampTop = 850f
        c.save()
        c.rotate(-4f, W / 2f, stampTop + 140f)
        val stamp = RectF(left + 20f, stampTop, right - 20f, stampTop + 280f)
        block(stamp, TIER_FILL[t], 40f, 16f)
        text.color = INK; text.typeface = bold
        fitText(s.auraLabel, stamp.left + 48f, stamp.top + 66f, 34f, 400f, text)
        text.typeface = black
        fitText(s.tiers[t], stamp.left + 44f, stamp.top + 170f, 110f, stamp.width() - 88f, text)
        text.typeface = bold
        fitText(s.tierLines[t], stamp.left + 48f, stamp.top + 238f, 40f, stamp.width() - 96f, text)
        c.restore()

        // ── Three stat tiles ──
        val tileTop = 1275f
        val tileH = 240f
        val gap = 28f
        val tileW = (right - left - gap * 2) / 3f
        val top = report.topApps.firstOrNull()
        val tiles = listOf(
            Triple(s.daily, "%dh %02dm".format(avg / 60, avg % 60), ""),
            Triple(s.pickups, "${report.pickups}x", s.pickupsSub),
            Triple(s.topApp, top?.label ?: s.noApp, top?.let { s.perWeek(it.minutes / 60, it.minutes % 60) } ?: ""),
        )
        val tileFill = intArrayOf(BUTTER, LILAC, SKY)
        tiles.forEachIndexed { i, (label, value, sub) ->
            val x = left + i * (tileW + gap)
            val r = RectF(x, tileTop, x + tileW, tileTop + tileH)
            block(r, tileFill[i], 30f, 10f)
            text.typeface = bold; text.color = INK
            fitText(label, r.left + 26f, r.top + 58f, 28f, tileW - 52f, text)
            text.typeface = black
            fitText(value, r.left + 24f, r.top + 152f, 76f, tileW - 48f, text)
            if (sub.isNotEmpty()) {
                text.typeface = bold; text.color = INK_MID.darker()
                fitText(sub, r.left + 26f, r.top + 204f, 28f, tileW - 52f, text)
            }
        }

        // ── Week bars ──
        val chart = RectF(left, 1570f, right, 1790f)
        block(chart, CARD, 30f, 10f)
        text.typeface = bold; text.color = INK_MID
        fitText(s.week, chart.left + 30f, chart.top + 50f, 28f, 420f, text)
        val peak = (report.dailyMinutes.maxOrNull() ?: 0).coerceAtLeast(60)
        val n = report.dailyMinutes.size.coerceAtLeast(1)
        val barsLeft = chart.left + 30f
        val barsRight = chart.right - 30f
        val barGap = 18f
        val barW = (barsRight - barsLeft - barGap * (n - 1)) / n
        val base = chart.bottom - 26f
        val maxBar = base - (chart.top + 74f)
        report.dailyMinutes.forEachIndexed { i, m ->
            val h = (m.toFloat() / peak * maxBar).coerceAtLeast(10f)
            val x = barsLeft + i * (barW + barGap)
            val r = RectF(x, base - h, x + barW, base)
            fill.color = if (i == report.longestDayIndex) TANG else SKY
            c.drawRoundRect(r, 10f, 10f, fill)
            stroke.strokeWidth = 5f
            c.drawRoundRect(r, 10f, 10f, stroke)
            stroke.strokeWidth = 8f
        }

        // ── 30-year line + footer ──
        text.typeface = bold; text.color = INK
        fitText(s.thirtyYears(report.yearsOverThirty), left, 1228f, 36f, right - left, text)

        fill.color = INK
        c.drawRect(0f, H - 100f, W.toFloat(), H.toFloat(), fill)
        text.color = BUTTER; text.typeface = black
        fitText(s.footer, left, H - 52f, 36f, 640f, text)
        text.color = SUNK; text.typeface = bold
        text.textSize = 26f
        val sub = s.footerSub
        var subSize = 26f
        while (text.measureText(sub) > 300f && subSize > 16f) { subSize -= 1f; text.textSize = subSize }
        c.drawText(sub, right - text.measureText(sub), H - 54f, text)

        return bmp
    }

    private fun Int.darker(): Int = Color.rgb(
        (Color.red(this) * 0.7f).toInt(),
        (Color.green(this) * 0.7f).toInt(),
        (Color.blue(this) * 0.7f).toInt(),
    )
}
