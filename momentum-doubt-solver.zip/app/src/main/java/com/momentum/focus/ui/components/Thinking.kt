package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import kotlin.math.PI
import kotlin.math.sin
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid

/**
 * Three pulsing dots and a word, for the two places the app waits on a model.
 *
 * A spinner would be the obvious thing and the wrong one — there is not one
 * anywhere else in this app, and a Material circle spinning on cut paper reads
 * as a component from a different product that wandered in.
 *
 * Tween rather than a spring, against the usual rule: infiniteRepeatable needs
 * a duration to repeat over, and a spring has none. This is the same exception
 * the skeleton bars already take.
 */
@Composable
fun ThinkingDots(
    label: String,
    modifier: Modifier = Modifier,
    dot: Color = Ink,
    labelColor: Color = InkMid,
) {
    // Thinking letters (from Uiverse loader letters, in ink): the dots pulse
    // and the label's letters lift one after another in a slow wave. One
    // transition, every value read inside graphicsLayer — draw-phase only,
    // where the old .alpha(fade) recomposed the row every frame.
    val transition = rememberInfiniteTransition(label = "think")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing)),
        label = "wave",
    )
    fun lift(phase: Float): Float {
        val x = ((t - phase) % 1f + 1f) % 1f
        return if (x < 0.25f) sin(x / 0.25f * PI.toFloat()) else 0f
    }
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        repeat(3) { i ->
            Spacer(
                Modifier
                    .size(7.dp)
                    .graphicsLayer { alpha = 0.3f + 0.7f * lift(i * 0.1f) }
                    .clip(CircleShape)
                    .background(dot),
            )
            Spacer(Modifier.width(5.dp))
        }
        Spacer(Modifier.width(4.dp))
        label.forEachIndexed { i, ch ->
            Text(
                ch.toString(),
                style = MaterialTheme.typography.bodyMedium,
                color = labelColor,
                modifier = Modifier.graphicsLayer {
                    val k = lift(0.3f + i * 0.045f)
                    translationY = -k * 3.dp.toPx()
                    alpha = 0.55f + 0.45f * k
                },
            )
        }
    }
}
