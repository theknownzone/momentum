package com.momentum.focus.data

import android.content.Context

/**
 * THE one source for "what changed" (owner 2026-10-07: everything must stay
 * in sync — the log kept showing old notes).
 *
 * app/src/main/assets/release_notes.md is read by:
 *   - the "Update landed" card after an update (UpdateLanded.kt)
 *   - the full log's offline fallback / current build (WhatsNewScreen)
 *   - CI, which publishes it as the GitHub release body (build.yml), so
 *     the online history and the in-app updater see the very same words.
 * Update that file in every delivery. Nothing else holds release notes.
 *
 * Format:
 *   ## Section
 *   - Title :: one plain line
 *     hi: शीर्षक :: एक लाइन        (optional Hindi for the item above)
 */
object ReleaseNotes {
    data class Item(val title: String, val sub: String)
    data class Section(val heading: String, val items: List<Item>)

    private class Raw(val heading: String, val items: MutableList<Pair<Item, Item?>>)

    @Volatile private var raw: List<Raw>? = null

    private fun parse(ctx: Context): List<Raw> {
        raw?.let { return it }
        val text = runCatching {
            ctx.assets.open("release_notes.md").bufferedReader().use { it.readText() }
        }.getOrDefault("")
        val out = mutableListOf<Raw>()
        fun item(s: String): Item {
            val parts = s.split("::", limit = 2)
            return Item(parts[0].trim(), parts.getOrNull(1)?.trim().orEmpty())
        }
        text.lines().forEach { line ->
            val t = line.trim()
            when {
                t.startsWith("## ") -> out += Raw(t.removePrefix("## ").trim(), mutableListOf())
                t.startsWith("- ") -> {
                    if (out.isEmpty()) out += Raw("", mutableListOf())
                    out.last().items += item(t.removePrefix("- ")) to null
                }
                t.startsWith("hi:") -> {
                    val sec = out.lastOrNull() ?: return@forEach
                    val last = sec.items.lastOrNull() ?: return@forEach
                    sec.items[sec.items.lastIndex] = last.first to item(t.removePrefix("hi:"))
                }
            }
        }
        return out.filter { it.items.isNotEmpty() }.also { raw = it }
    }

    private fun headingHi(h: String) = when (h.lowercase()) {
        "new" -> "नया"
        "fixed" -> "ठीक किया"
        "better" -> "बेहतर"
        else -> h
    }

    /** Notes in the current app language. Empty if the file is missing. */
    fun sections(ctx: Context): List<Section> {
        val hi = AppLang.code == "hi"
        return parse(ctx).map { r ->
            Section(
                if (hi) headingHi(r.heading) else r.heading,
                r.items.map { (en, h) -> if (hi && h != null) h else en },
            )
        }
    }
}
