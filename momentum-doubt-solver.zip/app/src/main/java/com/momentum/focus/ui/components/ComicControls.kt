package com.momentum.focus.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

// ============================================================================
// Comic-sized controls with chunky mechanics.
//
// HTML lab ke toggle ka baatit: coin slides, tick rotates 360, spring ball.
// YAML ke button ka baatit: press-to-sink, shadow drops, cheeky slip.
//
// Yahan dono mechanic — Android native ke andar, `clickableNoRipple` ke
// oopar banaye hain, jo app ke existing interaction system mein bilkul fit
// hain.
// ============================================================================

/**
 * The pun bump — a button that physically sinks when you press it.
 *
 * HTML lab mein `.btn:active{transform:translate(4px,4px);box-shadow:none}`
 * — wahi mechanic Compose mein: shadow offset translate hota hai aur button
 * neeche dabta hai. Smooth nahi, sudden nahi — `tween(80)` se snappy.
 *
 * @param shadowOffset  kitna px neeche/girna — 5dp standard, 3dp small.
 * @param depth         neeche ke hisaab se dark edge kitna dark ho.
 */
@Composable
fun PowerButton(
    label: String,
    modifier: Modifier = Modifier,
    sticker: Sticker = Mint,
    shadowOffset: Int = 5,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val off = shadowOffset.dp

    // Spring-settle animation on press — not instant, so the shadow does
    // not snap between states like a CSS `:active` that has no transition.
    val pressedProgress by animateFloatAsState(
        if (pressed) 1f else 0f,
        spring(dampingRatio = 0.55f, stiffness = 400f),
        label = "pun-bump",
    )

    Box(
        modifier
            .height(52.dp)
            .fillMaxWidth()
            .then(
                Modifier
                    .clickableNoRipple(interaction) {
                        haptics.press()
                        onClick()
                    }
                    .drawBehind {
                        val shadowDx = off.toPx() * (1f - pressedProgress)
                        val shadowDy = off.toPx() * (1f - pressedProgress)
                        val pushDown = off.toPx() * pressedProgress

                        // Working surface: pure sticker fill pushed down.
                        drawRoundRect(
                            color = sticker.fill,
                            topLeft = Offset(0f, pushDown),
                            size = size.copy(height = size.height - pushDown),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(14.dp.toPx(), 14.dp.toPx()),
                        )

                        // The dark edge: the side of the button that faces
                        // the shadow direction — a darker band that makes the
                        // thickness readable without a blurry shadow.
                        drawRect(
                            color = sticker.on.copy(alpha = 0.18f * (1f - pressedProgress)),
                            topLeft = Offset(pushDown, size.height - off.toPx()),
                            size = size.copy(
                                width = size.width - pushDown,
                                height = off.toPx(),
                            ),
                        )

                        // When not pressed, a hard offset shadow sits behind.
                        if (pressedProgress < 0.95f) {
                            drawRoundRect(
                                color = Color(0xFF2A2A2A).copy(alpha = 1f - pressedProgress),
                                topLeft = Offset(shadowDx, shadowDy),
                                size = size,
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(14.dp.toPx(), 14.dp.toPx()),
                            )
                        }

                        // Always ink outline on the working surface.
                        drawRoundRect(
                            color = Ink,
                            topLeft = Offset(0f, pushDown),
                            size = size.copy(height = size.height - pushDown),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(14.dp.toPx(), 14.dp.toPx()),
                            style = Stroke(2.5f * density),
                        )
                    }
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 16.sp,
            color = sticker.on,
            modifier = Modifier.offset(y = 2.dp * pressedProgress),
        )
    }
}

/**
 * The mechanical snap toggle — a coin/knob that rotates 360° when flipped.
 *
 * HTML lab ke mechanic: `.toggle.on .knob{transform:translateX(34px) rotate(360deg)}`
 * Yahan wahi hai, spring-enforced. Tick mark rotates as it slides, so the
 * knob does not just move — it spins.
 */
@Composable
fun PunBumpToggle(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    trackOn: Color = Mint.fill,
    trackOff: Color = Tang.fill,
) {
    val haptics = rememberHaptics()
    val slide by animateFloatAsState(
        if (checked) 1f else 0f,
        tween(450, easing = FastOutSlowInEasing),
        label = "snap-slide",
    )
    val rotation by animateFloatAsState(
        if (checked) 360f else 0f,
        tween(500, easing = FastOutSlowInEasing),
        label = "snap-spin",
    )
    val trackColor by animateColorAsState(
        if (checked) trackOn else trackOff,
        tween(350),
        label = "snap-track",
    )

    Box(
        modifier
            .width(72.dp)
            .height(38.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp))
            .drawBehind {
                // The track: a recessed channel.
                drawRoundRect(
                    color = trackColor,
                    size = size,
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(20.dp.toPx(), 20.dp.toPx()),
                )
                // Inner shadow line for depth.
                drawRoundRect(
                    color = Color.Black.copy(alpha = 0.15f),
                    topLeft = Offset(0f, 2f * density),
                    size = size.copy(height = size.height - 4f * density),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(18.dp.toPx(), 18.dp.toPx()),
                    style = Stroke(2f * density),
                )
                // Hard ink border.
                drawRoundRect(
                    color = Ink,
                    size = size,
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(20.dp.toPx(), 20.dp.toPx()),
                    style = Stroke(2.5f * density),
                )
            }
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                haptics.tick()
                onCheckedChange(!checked)
            }
            .padding(horizontal = 3.dp, vertical = 3.dp),
    ) {
        val knobPx = 30f * density
        //  72dp total width → 72*ddd − 6px padding = knob max travel
        Box(
            Modifier
                .size(30.dp)
                .offset(
                    x = (42.dp * slide).plus(2.dp) - (slide * 2.dp),
                )
                .drawBehind {
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    // Knob shadow.
                    drawCircle(
                        color = Color.Black.copy(alpha = 0.18f),
                        radius = knobPx * 0.5f + 2f,
                        center = Offset(cx + 2f, cy + 2f),
                    )
                    // Knob face, white.
                    drawCircle(
                        color = Color.White,
                        radius = knobPx * 0.5f,
                        center = Offset(cx, cy),
                    )
                    // Hard outline around knob.
                    drawCircle(
                        color = Ink,
                        radius = knobPx * 0.5f,
                        center = Offset(cx, cy),
                        style = Stroke(2.2f * density),
                    )
                    // Tick mark: short line from centre, rotating with slide.
                    val tickLen = knobPx * 0.28f
                    val angleRad = rotation * (PI / 180f).toFloat()
                    drawLine(
                        color = Ink.copy(alpha = 0.5f),
                        start = Offset(cx, cy),
                        end = Offset(
                            cx + kotlin.math.cos(angleRad) * tickLen,
                            cy + kotlin.math.sin(angleRad) * tickLen,
                        ),
                        strokeWidth = 1.5f * density,
                        cap = StrokeCap.Round,
                    )
                },
        )
    }
}

/**
 * A danger/red action button with its own visual treatment.
 *
 * Used for destructive actions only — reset data, delete session,
 * abandon pact. The sticker is always Tang so the colour alone says
 * "this is different from everything else."
 */
@Composable
fun DangerButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val sunk by animateFloatAsState(
        if (pressed) 1f else 0f,
        spring(dampingRatio = 0.5f, stiffness = 450f),
        label = "danger-press",
    )
    val shake by animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.35f, stiffness = 600f),
        label = "danger-shake",
    )

    val offsetX = sin(shake * 6f) * 3f
    val offsetY = (if (pressed) 2f else 0f) * density

    Box(
        modifier
            .height(48.dp)
            .fillMaxWidth()
            .offset(x = offsetX.dp, y = offsetY.dp)
            .clickableNoRipple(interaction) {
                haptics.reject()
                onClick()
            }
            .drawBehind {
                val pushed = sunk
                val baseY = pushed * 4f * density
                // Slightly muted Tang for danger, never neon.
                val dangerFill = Tang.fill.copy(
                    red = Tang.fill.red * 0.88f,
                    green = Tang.fill.green * 0.55f,
                    blue = Tang.fill.blue * 0.55f,
                )
                // Shadow sits behind.
                if (pushed < 0.95f) {
                    drawRoundRect(
                        color = Color(0xFF3A1A12).copy(alpha = 1f - pushed),
                        topLeft = Offset(3f * density, 3f * density),
                        size = size,
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(14.dp.toPx(), 14.dp.toPx()),
                    )
                }
                drawRoundRect(
                    color = dangerFill,
                    topLeft = Offset(0f, baseY),
                    size = size.copy(height = size.height - baseY),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(14.dp.toPx(), 14.dp.toPx()),
                )
                drawRoundRect(
                    color = Ink,
                    topLeft = Offset(0f, baseY),
                    size = size.copy(height = size.height - baseY),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(14.dp.toPx(), 14.dp.toPx()),
                    style = Stroke(2.5f * density),
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "⚠️ $label",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            color = Color.White,
        )
    }
}
