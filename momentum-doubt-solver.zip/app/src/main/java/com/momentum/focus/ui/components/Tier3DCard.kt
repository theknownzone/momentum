package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Tier3DCard(
    tier: String,
    price: String,
    features: List<String>,
    highlighted: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val targetScale = if (highlighted) 1.025f else 1f
    val cardScale by animateFloatAsState(
        targetValue = targetScale,
        animationSpec = tween(280),
        label = "tierScale"
    )

    val accent = when (tier.lowercase()) {
        "basic" -> Color(0xFF5CAEFF)
        "pro" -> Color(0xFFB9E8FF)
        else -> Color(0xFF9D8CFF)
    }

    Box(
        modifier = modifier
            .scale(cardScale)
            .fillMaxWidth()
            .background(
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF18212C).copy(alpha = 0.98f),
                        Color(0xFF090E14).copy(alpha = 0.98f)
                    )
                ),
                shape = RoundedCornerShape(26.dp)
            )
            .clickable(
                indication = null,
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                onClick = onClick
            )
            .padding(1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Color(0xFF0D141C).copy(alpha = 0.96f),
                    RoundedCornerShape(25.dp)
                )
                .padding(20.dp)
        ) {
            if (highlighted) {
                Text(
                    text = "MOST POPULAR",
                    color = accent,
                    fontSize = 10.sp,
                    letterSpacing = 1.2.sp
                )
                Spacer(Modifier.height(8.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(tier, color = Color.White, fontSize = 22.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(price, color = Color.White, fontSize = 30.sp)
                }

                Box(Modifier.size(88.dp)) {
                    Canvas(Modifier.size(88.dp)) {
                        val c = androidx.compose.ui.geometry.Offset(size.width * 0.58f, size.height * 0.42f)
                        val r = size.minDimension * 0.34f
                        scale(if (highlighted) 1.08f else 1f, pivot = c) {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    listOf(
                                        Color.White.copy(alpha = 0.92f),
                                        accent.copy(alpha = 0.75f),
                                        accent.copy(alpha = 0.18f),
                                        Color.Transparent
                                    ),
                                    center = c,
                                    radius = r * 1.9f
                                ),
                                center = c,
                                radius = r * 1.9f
                            )
                            drawCircle(
                                color = accent.copy(alpha = 0.42f),
                                center = c,
                                radius = r
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            features.take(4).forEach { feature ->
                Text(
                    text = "•  $feature",
                    color = Color.White.copy(alpha = 0.72f),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(vertical = 3.dp)
                )
            }
        }
    }
}