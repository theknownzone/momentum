package com.momentum.focus.ui.i18n

/**
 * The block hub — the one screen where apps, feeds, profiles and the
 * schedule all meet. Never wired to the language system at all before this:
 * every line here, including the three tagline posters that read in English
 * no matter what the rest of the app was set to, was a literal in the
 * screen file. Same bug class as the tour overlay — a screen built once and
 * never connected to [strings].
 */
interface BlockHubStrings {
    val label: String
    val title: String
    val subtitle: String

    val appsTitle: String
    val appsTagline: String
    val appsNone: String
    fun appsBlocked(count: Int): String
    fun appsCapSuffix(count: Int): String

    val feedsTitle: String
    val feedsTagline: String
    val feedsNone: String
    fun feedsBlocked(count: Int): String

    val profilesTitle: String
    val profilesTagline: String
    fun profileActive(name: String): String
    val profilesNone: String
    fun profilesSaved(count: Int): String

    val scheduleTitle: String
    val scheduleTagline: String
    val classHoursOff: String
    fun classHoursOn(startHour: Int, endHour: Int, days: Int): String

    val footer: String
    val done: String
    val brandTagline: String
}

object BlockHubHi : BlockHubStrings {
    override val label = "BLOCK"
    override val title = "Kya band hai"
    override val subtitle = "Rokne wali har cheez yahan hai. Apps, feeds, limits, aur kab lagu ho."

    override val appsTitle = "Apps"
    override val appsTagline = "FOCUS MODE ON"
    override val appsNone = "Koi app band nahi"
    override fun appsBlocked(count: Int) = "$count apps band"
    override fun appsCapSuffix(count: Int) = " \u00b7 $count pe daily limit"

    override val feedsTitle = "Feeds"
    override val feedsTagline = "SCROLL KAM. JEE ZYADA."
    override val feedsNone = "Shorts aur Reels chalu hain"
    override fun feedsBlocked(count: Int) = "$count feeds band \u00b7 app khuli rehti hai"

    override val profilesTitle = "Profiles"
    override val profilesTagline = "PRIVATE RAHO. FOCUSED RAHO."
    override fun profileActive(name: String) = "$name chalu hai"
    override val profilesNone = "Koi profile nahi"
    override fun profilesSaved(count: Int) = "$count saved"

    override val scheduleTitle = "Kab lagu ho"
    override val scheduleTagline = "DISCIPLINE SE HI AZADI."
    override val classHoursOff = "Class hours off"
    override fun classHoursOn(startHour: Int, endHour: Int, days: Int) =
        "$startHour:00\u2013$endHour:00 \u00b7 hafte mein $days din"

    override val footer = "Pact ke dauran in sab ko sirf kas sakte ho \u2014 dheela nahi kar sakte."
    override val done = "Ho gaya"
    override val brandTagline = "Aaj discipline. Kal roshni."
}

object BlockHubEn : BlockHubStrings {
    override val label = "BLOCK"
    override val title = "What's blocked"
    override val subtitle = "Everything that stops something is here. Apps, feeds, limits, and when it applies."

    override val appsTitle = "Apps"
    override val appsTagline = "FOCUS MODE ON"
    override val appsNone = "No apps blocked"
    override fun appsBlocked(count: Int) = "$count apps blocked"
    override fun appsCapSuffix(count: Int) = " \u00b7 $count with a daily limit"

    override val feedsTitle = "Feeds"
    override val feedsTagline = "SCROLL LESS. LIVE MORE."
    override val feedsNone = "Shorts and Reels are on"
    override fun feedsBlocked(count: Int) = "$count feeds blocked \u00b7 app stays open"

    override val profilesTitle = "Profiles"
    override val profilesTagline = "STAY PRIVATE. STAY FOCUSED."
    override fun profileActive(name: String) = "$name is active"
    override val profilesNone = "No profiles yet"
    override fun profilesSaved(count: Int) = "$count saved"

    override val scheduleTitle = "When it applies"
    override val scheduleTagline = "DISCIPLINE BUILDS FREEDOM."
    override val classHoursOff = "Class hours off"
    override fun classHoursOn(startHour: Int, endHour: Int, days: Int) =
        "$startHour:00\u2013$endHour:00 \u00b7 $days days a week"

    override val footer = "During a pact you can only tighten these \u2014 never loosen them."
    override val done = "Done"
    override val brandTagline = "Discipline today. A brighter tomorrow."
}
