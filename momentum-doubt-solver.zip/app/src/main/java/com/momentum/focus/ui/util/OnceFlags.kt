package com.momentum.focus.ui.util

import android.content.Context

/**
 * "Show this only once per install" flags for pure-UI moments (MyAI welcome,
 * small hints). Kept out of AppData on purpose: a data-model field means a
 * store migration for something no other screen ever reads.
 */
object OnceFlags {
    private const val FILE = "momentum_once"
    const val MYAI_WELCOME = "myai_welcome_v2"

    fun seen(ctx: Context, key: String): Boolean =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(key, false)

    fun mark(ctx: Context, key: String) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(key, true).apply()
    }
}
