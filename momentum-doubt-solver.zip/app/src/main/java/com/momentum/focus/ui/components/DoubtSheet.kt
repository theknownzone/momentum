package com.momentum.focus.ui.components

import androidx.compose.foundation.interaction.collectIsPressedAsState
import com.momentum.focus.data.tr
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalClipboardManager
import android.net.Uri
import com.momentum.focus.ai.Attach
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.window.Popup
import androidx.compose.ui.unit.sp
import com.momentum.focus.ai.Ai
import com.momentum.focus.ai.Doubt
import com.momentum.focus.ai.DoubtState
import com.momentum.focus.ai.MyAiMode
import com.momentum.focus.ai.StudyPulse
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import androidx.core.content.FileProvider
import com.momentum.focus.ui.util.ExportChat
import com.momentum.focus.ui.util.rememberHaptics
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Rounded at the top only. The bottom edge is the bottom of the screen. */
private val SheetShape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)

/**
 * How much of the input glow is on when nothing is happening.
 *
 * Not zero: the ring is part of how the composer looks, and a box that only
 * glows while an answer is being written shows the effect for a few seconds at
 * the exact moment the reader is watching the reply instead.
 */
private const val REST = 0.42f

/**
 * The one place in this app where a person types at a model.
 *
 * Everything that could make it a hiding place is on screen rather than in a
 * comment: the questions left, the clock still running, and an answer that
 * ends instead of inviting another. Closing the sheet does not cancel a
 * request in flight — the answer will be waiting when it is reopened — because
 * a request that has already been paid for should not have to be paid for
 * twice.
 */
@Composable
fun DoubtSheet(
    state: DoubtState,
    /** The live countdown, or null when no session is running. */
    clock: String?,
    /** Question, pages, and whether those pages were carried from an earlier turn. */
    onAsk: (String, List<String>, Boolean) -> Unit,
    onRetry: () -> Unit,
    onStop: () -> Unit,
    onClose: () -> Unit,
    mode: MyAiMode = MyAiMode.Study,
    onMode: (MyAiMode) -> Unit = {},
    pulse: StudyPulse? = null,
    embedded: Boolean = false,
    premium: Boolean = false,
    onPlans: () -> Unit = {},
    /** Null hides the drill entirely, same as a build with no key. */
    onMock: ((String?) -> Unit)? = null,
    /** Shown in the greeting. Blank hides it rather than saying "hello, ". */
    name: String = "",
    /** No API key in this build: say so instead of "0 doubts left". */
    aiOff: Boolean = false,
    /** Out of doubts with no session running: one tap to the Focus tab. */
    onStartSession: (() -> Unit)? = null,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val context = LocalContext.current
    var text by rememberSaveable { mutableStateOf("") }
    var pendingJpegs by remember { mutableStateOf<List<String>>(emptyList()) }
    var pendingLabel by remember { mutableStateOf<String?>(null) }
    var lastPages by remember { mutableStateOf<List<String>>(emptyList()) }
    val pendingJpeg = pendingJpegs.firstOrNull()
    val listState = rememberLazyListState()
    val spent = state.left <= 0
    val modeLabel = when (mode) {
        MyAiMode.Study -> str.doubt.modeStudy
        MyAiMode.Friend -> str.doubt.modeFriend
        MyAiMode.Guru -> str.doubt.modeGuru
    }

    // Decoding a photo or rendering a PDF page allocates megabytes and touches
    // disk. Run inline on the picker callback — which is the main thread — it
    // froze the composer for as long as the work took, and on a big photo that
    // is long enough to be an ANR rather than a stutter.
    val scope = rememberCoroutineScope()
    fun ingest(uri: Uri?) {
        if (uri == null) return
        pendingLabel = str.doubt.attaching
        scope.launch {
            withContext(Dispatchers.IO) { runCatching { Attach.fromUri(context, uri) } }
                .onSuccess {
                    pendingJpegs = (pendingJpegs + it.jpegB64).distinct().take(5)
                    pendingLabel = "${pendingJpegs.size}/5"
                    lastPages = pendingJpegs
                    haptics.confirm()
                }
                .onFailure {
                    pendingLabel = it.message ?: str.doubt.attachFailed
                    haptics.reject()
                }
        }
    }

    var shotUri by remember { mutableStateOf<Uri?>(null) }
    // TakePicture writes into a Uri we own rather than returning a bitmap, so
    // no CAMERA permission is needed — the system camera app holds that, and
    // asking for it here would be one more dialog for nothing.
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) ingest(shotUri)
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        uris.take(5 - pendingJpegs.size).forEach { ingest(it) }
    }
    val pickPdf = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { ingest(it) }

    BackHandler { onClose() }

    // Two rules, because one scroll was doing two jobs badly.
    //
    // It followed every change, so scrolling back to re-read something was
    // undone the moment an answer landed. Now it only follows if you were
    // already down at the newest part.
    //
    // And it scrolled to the very end, which for a long answer means the list
    // stops with the last line against the bottom and the first line pushed off
    // the top — the answer arrives already half buried. An answer is scrolled
    // to its own start instead, so it is read from the first word.
    // Chat deliberately has no repeating haptic while the model is thinking.
    // One semantic cue on send is enough; the reply itself is announced by SFX.

    // Straight to the last item, every time, with no condition on it.
    //
    // Every previous version guarded this with "only if they were already at
    // the bottom" and every version of that guard was wrong in a different
    // way — first firstVisibleItemIndex, then the visible-items window — and
    // each one failed exactly when the thread got long enough to matter. The
    // guard was protecting against dragging someone away from something they
    // were re-reading, which is a real thing but a rarer one than the reply
    // simply never appearing. This does the obvious thing instead.
    // state.streaming too, so the view follows the answer down as it is
    // written rather than jumping once at the end.
    // Follow the newest text unless the student dragged up to re-read
    // (owner rule: student first — being yanked down mid-reading irritates).
    // A drag up turns follow off; reaching the bottom or sending a new
    // question turns it back on. Programmatic scrolls go forward only, so
    // lastScrolledBackward can only be the student's own finger.
    var follow by remember { mutableStateOf(true) }
    LaunchedEffect(listState) {
        androidx.compose.runtime.snapshotFlow {
            Triple(listState.isScrollInProgress, listState.canScrollForward, listState.lastScrolledBackward)
        }.collect { (moving, more, back) ->
            if (!more) follow = true
            else if (moving && back) follow = false
        }
    }
    var seenTurns by remember { mutableStateOf(state.thread.size) }
    val openedWith = remember { state.thread.size }
    LaunchedEffect(state.thread.size, state.busy, state.error, state.streaming) {
        if (state.thread.isEmpty()) return@LaunchedEffect
        if (state.thread.size > seenTurns && state.thread.lastOrNull()?.fromUser == true) follow = true
        seenTurns = state.thread.size
        if (!follow) return@LaunchedEffect
        val end = state.thread.size
        listState.animateScrollToItem(end)
        // A second pass after layout: the first lands before a tall new bubble
        // has been measured, so on a long answer it stops short and the last
        // lines sit under the composer.
        delay(140)
        listState.animateScrollToItem(end)
    }

    fun submit() {
        val question = text.trim()
        if ((question.isBlank() && pendingJpegs.isEmpty()) || state.busy || spent) return
        // Its own sound. This used to be confirm(), which is what a completed
        // session sounds like — so asking a question and finishing an hour of
        // study were indistinguishable with your eyes shut.
        haptics.send()
        // Pages carry to the *next* question and no further.
        //
        // They used to stick for the rest of the session: attach a photo once
        // and every message after it re-sent the same photo, forever, with no
        // way to stop. A follow-up like "I still don't get step two" needs the
        // page; the question after that is usually about something else, and
        // silently re-uploading a stale photo makes every later answer worse
        // and every request slower.
        val carried = pendingJpegs.isEmpty() && lastPages.isNotEmpty()
        val pics = pendingJpegs.ifEmpty { lastPages }
        onAsk(question, pics, carried)
        text = ""
        // Consumed here, and this is the fix.
        //
        // The comment above has always said pages carry to the next question
        // "and no further" — and nothing ever cleared lastPages, so they
        // carried to every question for the rest of the session. Attach one
        // screenshot and it rode along with every message after it, which is
        // the same picture stuck to three bubbles in a row.
        //
        // Set from a fresh attach, emptied once it has been spent on a
        // follow-up.
        lastPages = if (pendingJpegs.isNotEmpty()) pendingJpegs else emptyList()
        pendingJpegs = emptyList()
        // The composer empties on send. lastPages keeps the photo as context
        // for a follow-up, but it is no longer *pending* — and the label was
        // still being rebuilt from it, so the thumbnail and the "1/5" stayed
        // sitting in the box after the message had gone. It read as though the
        // send had failed and the picture was still waiting to be sent.
        pendingLabel = null
    }

    // Embedded, this paints nothing of its own. It used to carry an opaque
    // Cream fill across fillMaxSize, which sat on top of the ghost word and
    // the gold aura the MyAi screen draws underneath — both were being
    // rendered and then covered, which is why neither had ever been seen. The
    // screen owns the paper now; the panel is just the layout on it.
    // Remembered out here rather than inside the branch: a remember() reached
    // only on one side of an if is a slot that moves if the condition ever
    // changes.
    val panelTaps = remember { MutableInteractionSource() }
    val panel = Modifier
        .fillMaxWidth()
        .then(
            if (embedded) {
                Modifier.fillMaxSize()
            } else {
                Modifier
                    .fillMaxHeight(0.88f)
                    .clip(SheetShape)
                    .border(Paper.Outline, Ink, SheetShape)
                    .background(Cream)
                    // Swallows taps so they do not reach the scrim's closer
                    // behind the sheet. Only the modal needs it; embedded there
                    // is no scrim to fall through to.
                    .clickableNoRipple(panelTaps) { }
                    .paperGrain()
            },
        )
        .padding(horizontal = 16.dp)
        // Extra room at the top when embedded: MyAi draws its own back arrow
        // up there now, and without this the first bubble slid under it.
        .padding(top = if (embedded) 2.dp else 14.dp, bottom = 10.dp)

    @Composable
    fun Panel() {
            Column(panel) {
                // Embedded there is no title and no close button — the tab bar
                // is the way out — so the header row is skipped rather than
                // laid out empty. It was costing a spacer's worth of height
                // above the counts for nothing.
                if (!embedded) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            str.doubt.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = InkMid,
                        )
                        Text(
                            str.doubt.title,
                            style = MaterialTheme.typography.headlineSmall,
                            color = Ink,
                        )
                    }
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                onClose()
                            }
                            .padding(6.dp),
                    ) {
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = str.doubt.close,
                            tint = Ink,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                }

                // The price, always visible. A limit nobody can see is not a
                // limit, it is a surprise waiting to happen.
                //
                // A translucent tint here was tried once and rejected — on
                // cream paper with a giant ghost word behind it, a see-through
                // green wash was unreadable at any size. LiquidGlass isn't
                // that: it's an opaque white-based surface with a glass-look
                // bevel drawn on top, not a window onto whatever's behind it,
                // so the ghost word underneath never has a chance to fight
                // the text sitting on top of it.
                // Embedded (MyAI tab) the count lives on the LED sign and in
                // the answer sheet; this bar is only for the modal sheet.
                if (!embedded) {
                LiquidGlass(
                    modifier = Modifier.fillMaxWidth(),
                    tint = if (spent) Tang.fill else Mint.fill,
                    radius = 14.dp,
                ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    // LiquidGlass sits on a light, near-white body no matter
                    // what tint it's given — it layers a coloured wash under
                    // a white gradient, not the other way round. The bright
                    // "on dark" colours this bar used against solid Ink
                    // (Mint.fill, Cream) would wash out or vanish here; the
                    // dark "on" variants each Sticker already carries for
                    // sitting on its own light fill are what stay legible.
                    Text(
                        when {
                            aiOff -> tr("AI off", "AI बंद")
                            spent && clock == null -> tr("Start a session to refill", "दोबारा पाने के लिए सेशन शुरू करें")
                            else -> str.doubt.left(state.left)
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (spent) Tang.on else Mint.on,
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        clock?.let { str.doubt.clockRunning(it) } ?: str.doubt.clockPaused,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (clock != null) Tang.on else InkMid,
                    )
                    Spacer(Modifier.weight(1f))
                    if (state.thread.isNotEmpty()) {
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    ExportChat.share(
                                        context = context,
                                        thread = state.thread,
                                        mode = modeLabel,
                                        you = str.doubt.exportYou,
                                        ai = str.doubt.exportAi,
                                    )
                                }
                                .padding(4.dp),
                        ) {
                            Icon(
                                Icons.Filled.IosShare,
                                contentDescription = str.doubt.export,
                                tint = Ink,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                }
                }
                }

                if (!embedded) Spacer(Modifier.height(10.dp))
                // Modes moved to the sheet behind the header's menu button. A
                // permanent row of three, two of them with a "· Pro" suffix,
                // was most of the width of a phone spent on a control touched
                // once a session — and every pixel it held is a pixel the
                // conversation did not get.
                if (!embedded) {
                    ModeRow(mode = mode, onMode = onMode, premium = premium, onPlans = onPlans)
                    Spacer(Modifier.height(10.dp))
                }

                Box(Modifier.weight(1f)) {
                    if (state.thread.isEmpty()) {
                        EmptyThread(name = name, onPick = { text = it }, pulse = pulse)
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            // Only turns that arrive while you watch get the
                            // pop-in; opening the tab shows the thread as-is
                            // (every bubble fading in on entry was the MyAI
                            // "fade" lag, owner 2026-10-07).
                            itemsIndexed(state.thread) { i, turn -> Bubble(turn, fresh = i >= openedWith) }
                            item {
                                Status(
                                    state = state,
                                    onRetry = { haptics.press(); onRetry() },
                                )
                            }
                        }
                        // Scrolled up to re-read: one tap back to the newest.
                        androidx.compose.animation.AnimatedVisibility(
                            visible = !follow && listState.canScrollForward,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp),
                            enter = androidx.compose.animation.fadeIn(tween(180)) +
                                androidx.compose.animation.slideInVertically(tween(220)) { it / 2 },
                            exit = androidx.compose.animation.fadeOut(tween(160)),
                        ) {
                            Row(
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(Ink)
                                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                                        haptics.tick()
                                        follow = true
                                        scope.launch { listState.animateScrollToItem(state.thread.size) }
                                    }
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    Icons.Filled.ArrowDownward,
                                    contentDescription = null,
                                    tint = Cream,
                                    modifier = Modifier.size(15.dp),
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    if (state.busy) tr("Answer is coming", "जवाब आ रहा है") else tr("Latest", "नया"),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Cream,
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                Column(Modifier.imePadding()) {
                if (spent) {
                    // The dead input box is replaced rather than disabled. A
                    // box you can tap that refuses to take a letter reads as a
                    // bug; a sentence saying why reads as a rule.
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(Paper.ChipRadius))
                            .background(Tang.fill)
                            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.ChipRadius))
                            .padding(14.dp),
                    ) {
                        Text(
                            if (aiOff) tr("AI is off for now", "AI अभी बंद है") else str.doubt.noneLeftTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = Tang.on,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (aiOff) tr("This build has no AI key yet, so MyAi can't answer. Everything else in the app works.", "इस बिल्ड में अभी AI की नहीं है, इसलिए MyAi जवाब नहीं दे सकता। ऐप का बाकी सब काम करता है।") else str.doubt.noneLeftBody,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Tang.on,
                        )
                        if (!aiOff && clock == null && onStartSession != null) {
                            Spacer(Modifier.height(10.dp))
                            SquishButton(
                                tr("Start a session", "सेशन शुरू करें"),
                                Mint,
                                Modifier.fillMaxWidth(),
                            ) { onStartSession() }
                        }
                    }
                } else {
                    // Follow-ups only right after a finished answer, never
                    // mid-stream or on an error, and never past the limit.
                    val answered = !state.busy && state.error == null &&
                        state.thread.lastOrNull()?.fromUser == false
                    if (embedded && answered) {
                        FollowUps(enabled = state.left > 0) { q -> onAsk(q, emptyList(), false) }
                    }
                    Composer(
                        text = text,
                        onText = { text = it },
                        busy = state.busy,
                        canSend = text.isNotBlank() || pendingJpegs.isNotEmpty() || lastPages.isNotEmpty(),
                        premium = premium,
                        attachmentLabel = pendingLabel,
                        // Only what is actually pending. Falling back to
                        // lastPages here is what kept a sent photo on screen:
                        // the list the composer displayed and the list waiting
                        // to be sent were not the same list.
                        attachmentJpegs = pendingJpegs,
                        onClearAttach = {
                            pendingJpegs = emptyList()
                            lastPages = emptyList()
                            pendingLabel = null
                        },
                        onRemoveAttach = { i ->
                            val src = pendingJpegs.ifEmpty { lastPages }
                            val next = src.filterIndexed { idx, _ -> idx != i }
                            pendingJpegs = next
                            lastPages = next
                            pendingLabel = next.size.takeIf { it > 0 }?.let { "$it/5" }
                        },
                        onAttach = { what ->
                            when (what) {
                                Attachment.Camera -> {
                                    if (pendingJpegs.size >= 5) return@Composer
                                    val file = File(context.cacheDir, "momentum-shot-${pendingJpegs.size}.jpg")
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        file,
                                    )
                                    shotUri = uri
                                    runCatching { takePhoto.launch(uri) }
                                }
                                Attachment.Photo -> pickImage.launch("image/*")
                                Attachment.Pdf -> pickPdf.launch("application/pdf")
                                Attachment.Mock -> onMock?.invoke(pendingJpegs.firstOrNull())
                            }
                        },
                        onSend = { submit() },
                        onStop = { haptics.reject(); onStop() },
                        onPlans = onPlans,
                    )
                }

                Spacer(Modifier.height(4.dp))
                // One line: Speak (embedded) · disclaimer · tip, and the n/300
                // counter takes the disclaimer's place only while typing.
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (embedded && !spent) {
                        SpeakChip(text, Doubt.MAX_CHARS, enabled = !state.busy) { text = it }
                        Spacer(Modifier.width(8.dp))
                    }
                    if (embedded && text.isNotEmpty()) {
                        Spacer(Modifier.weight(1f))
                        Text(
                            "${text.length} / ${Doubt.MAX_CHARS}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (text.length > Doubt.MAX_CHARS * 0.85f) Tang.accent else InkMid,
                        )
                    } else {
                        Text(
                            str.doubt.disclaimer,
                            style = MaterialTheme.typography.labelSmall,
                            color = InkMid.copy(alpha = 0.85f),
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        Spacer(Modifier.width(6.dp))
                        HowItWorksTip()
                    }
                }
                }
            }
    }

    if (embedded) {
        Box(Modifier.fillMaxSize()) { Panel() }
    } else {
        FrostScrim {
            Box(
                Modifier
                    .fillMaxSize()
                    .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
            )
            Box(
                Modifier.fillMaxSize(),
                contentAlignment = Alignment.BottomCenter,
            ) { Panel() }
        }
    }
}

/**
 * What sits under the last question: the dots, a failure, or an offer to ask
 * it again after a stop.
 */
@Composable
private fun Status(state: DoubtState, onRetry: () -> Unit) {
    val str = strings()
    when {
        // Once text is arriving, the text is the status.
        //
        // The pulse is honest for the second or two before the model starts
        // writing, and a lie after that: it says "being looked at" while the
        // answer already exists and is being withheld. Swapping to the words
        // as soon as there are any is the whole reason streaming was worth
        // doing — the wait stops being a wait and becomes reading.
        state.busy && state.streaming.isNotEmpty() -> {
            val cursor by androidx.compose.animation.core.rememberInfiniteTransition(label = "streamCursor")
                .animateFloat(
                    initialValue = 0.18f,
                    targetValue = 1f,
                    animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                        animation = tween(620),
                        repeatMode = androidx.compose.animation.core.RepeatMode.Reverse,
                    ),
                    label = "cursorAlpha",
                )
            Row(
                verticalAlignment = Alignment.Bottom,
                modifier = Modifier.padding(vertical = 4.dp),
            ) {
                Text(
                    state.streaming,
                    style = MaterialTheme.typography.bodyLarge.copy(lineHeight = 25.sp),
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(Modifier.width(4.dp))
                Box(
                    Modifier
                        .size(width = 2.dp, height = 18.dp)
                        .graphicsLayer { alpha = cursor }
                        .background(LocalSkin.current.accent),
                )
            }
        }

        // The scan, not the three dots. Dots said "loading"; a pulse going out
        // from the middle says the thing you sent is being looked at, which is
        // what is actually happening.
        //
        // The read timeout is 90s and resets on every streamed chunk (see
        // Ai.kt), which is correct for a slow model but looks identical to a
        // hang if the label never changes — a genuinely-working 24-second
        // wait and a stuck one render the same way otherwise. After 12s with
        // nothing back yet, the label says so, so a slow answer doesn't read
        // as a broken one.
        state.busy -> {
            var longWait by remember { mutableStateOf(false) }
            LaunchedEffect(state.busy) {
                longWait = false
                delay(12_000)
                longWait = true
            }
            Column(
                Modifier.fillMaxWidth().padding(vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                PlasmaOrbitLoader()
                Spacer(Modifier.height(10.dp))
                Text(
                    if (longWait) str.doubt.stillThinking else str.doubt.thinking,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                )
            }
        }

        state.error != null -> {
            Column {
                Text(
                    state.error,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
                Spacer(Modifier.height(8.dp))
                SquishButton(str.doubt.retry, Sky, Modifier.fillMaxWidth(0.6f)) { onRetry() }
            }
        }

        state.awaitingRetry -> {
            Column {
                Text(
                    str.doubt.stopped,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                )
                Spacer(Modifier.height(8.dp))
                // Re-asks the question already on screen. Stopping an answer
                // should not cost the typing that led to it.
                SquishButton(str.doubt.retry, Sky, Modifier.fillMaxWidth(0.6f)) { onRetry() }
            }
        }
    }
}

/**
 * The empty sheet.
 *
 * The examples are tappable because the first question sets the size of every
 * one after it, and three one-line doubts teach that faster than an
 * instruction to keep it short.
 */
@Composable
private fun EmptyThread(
    name: String,
    onPick: (String) -> Unit,
    pulse: StudyPulse? = null,
) {
    val str = strings()
    val haptics = rememberHaptics()
    // Scrolls: on a small phone the pulse card + five examples are taller
    // than the space between the bars and the composer.
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(top = 6.dp),
    ) {
        pulse?.let { PulseCard(it) }
        Text(
            str.doubt.intro,
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
        )
        Spacer(Modifier.height(14.dp))
        // Prompt keycaps: each example is a pressable sticker tile.
        val tiles = listOf(Mint, Butter, Sky, Lilac, Tang)
        str.doubt.examples.forEachIndexed { i, example ->
            val st = tiles[i % tiles.size]
            val src = remember { MutableInteractionSource() }
            val pressed by src.collectIsPressedAsState()
            val wall = 4.dp
            Box(
                Modifier
                    .padding(bottom = 10.dp)
                    .fillMaxWidth()
                    .padding(top = if (pressed) wall else 0.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(androidx.compose.ui.graphics.lerp(st.fill, Color.Black, 0.3f))
                    .padding(bottom = if (pressed) 0.dp else wall)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(st.fill)
                        .border(2.dp, Ink, RoundedCornerShape(16.dp))
                        .clickableNoRipple(src) { haptics.tick(); onPick(example) }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(example, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = st.on, modifier = Modifier.weight(1f))
                    Text("↗", fontWeight = FontWeight.Black, color = st.on)
                }
            }
        }
    }
}

/**
 * One message, copyable.
 *
 * Long-press rather than a button on every bubble: a copy icon repeated down
 * the whole thread is a row of clutter for something used once in twenty
 * messages, and long-press-to-copy is what every chat app already trained
 * people to try.
 */
@Composable
private fun Bubble(turn: Ai.Turn, fresh: Boolean = true) {
    val clipboard = LocalClipboardManager.current
    val haptics = rememberHaptics()
    var copied by remember { mutableStateOf(false) }
    // The confirmation disappears on its own. A copied badge that stays is a
    // second thing to dismiss.
    LaunchedEffect(copied) {
        if (copied) { delay(1400); copied = false }
    }
    val appear = remember { Animatable(if (fresh) 0.94f else 1f) }
    LaunchedEffect(Unit) {
        if (fresh) appear.animateTo(1f, tween(220))
    }
    Row(
        Modifier
            .graphicsLayer {
                scaleX = appear.value
                scaleY = appear.value
                alpha = ((appear.value - 0.94f) / 0.06f).coerceIn(0f, 1f)
            }
            .fillMaxWidth(),
        horizontalArrangement = if (turn.fromUser) Arrangement.End else Arrangement.Start,
    ) {
        val shape = RoundedCornerShape(Paper.CardRadius)
        val accent = LocalSkin.current.accent
        // Shared by both branches below: the ring glow behind an AI answer,
        // the width cap, and the long-press-to-copy gesture. Only what's
        // drawn *inside* this differs between a plain user bubble and the
        // glass treatment the AI's own answer gets now.
        val bubbleModifier = Modifier
            .fillMaxWidth(0.88f)
            .then(
                if (!turn.fromUser) Modifier.drawBehind {
                    // Radius taken from the bubble's own corner and grown
                    // with each ring. It was a bare 18f — raw pixels, so
                    // the corners were a different shape on every screen
                    // density, and square against the bubble's rounding.
                    val radius = Paper.CardRadius.toPx()
                    listOf(5.dp to 0.35f, 11.dp to 0.16f).forEach { ring ->
                        val out = ring.first.toPx()
                        drawRoundRect(
                            color = accent.copy(alpha = ring.second),
                            topLeft = Offset(-out, -out),
                            size = Size(size.width + out * 2, size.height + out * 2),
                            cornerRadius = CornerRadius(radius + out, radius + out),
                            style = Stroke(width = 2.dp.toPx()),
                        )
                    }
                } else Modifier
            )
            // detectTapGestures, not combinedClickable. The latter is
            // still @ExperimentalFoundationApi and this project carries no
            // foundation opt-in anywhere — adding one for a long-press
            // would put an experimental annotation on a file for a feature
            // that a pointer handler does exactly as well.
            .pointerInput(turn.text) {
                detectTapGestures(
                    onLongPress = {
                        clipboard.setText(AnnotatedString(turn.text))
                        haptics.confirm()
                        copied = true
                    },
                )
            }

        // New MyAI look: your question is a solid ink card (it's yours,
        // it's short); the answer is paper with a lit LED strip down its
        // edge and a tiny "MYAI" tag — the board's language, carried down.
        if (turn.fromUser) {
            val userShape = RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp)
            Box(
                bubbleModifier
                    .clip(userShape)
                    .background(Ink)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
            ) {
                BubbleContent(turn, copied)
            }
        } else {
            val aiShape = RoundedCornerShape(4.dp, 18.dp, 18.dp, 18.dp)
            Row(
                bubbleModifier
                    // Intrinsic height so the LED strip spans the whole card
                    // (fillMaxHeight inside a lazy list has no bound).
                    .height(androidx.compose.foundation.layout.IntrinsicSize.Min)
                    .clip(aiShape)
                    .background(CreamCard)
                    .border(Paper.Outline, Ink, aiShape),
            ) {
                Box(
                    Modifier
                        .width(6.dp)
                        .fillMaxHeight()
                        .background(Brush.verticalGradient(listOf(Color(0xFF39E26A), Color(0xFF1FA84A))))
                )
                Column(Modifier.padding(start = 12.dp, end = 14.dp, top = 8.dp, bottom = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(Color(0xFF39E26A)))
                        Spacer(Modifier.width(6.dp))
                        Text("MYAI", fontSize = 10.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Black, color = InkMid)
                    }
                    Spacer(Modifier.height(4.dp))
                    BubbleContent(turn, copied)
                }
            }
        }
    }
}

@Composable
private fun BubbleContent(turn: Ai.Turn, copied: Boolean) {
    val str = strings()
    Column {
        // Not on a carried turn. The pages still go up so the model
        // can see the page a follow-up is about, but drawing them here
        // put the same screenshot on a message the user typed without
        // attaching anything — which is the repeat.
        if (turn.allImages.isNotEmpty() && !turn.carried) {
            Row {
                turn.allImages.take(5).forEach { img ->
                    JpegThumb(
                        jpegB64 = img,
                        modifier = Modifier
                            .weight(1f)
                            .height(88.dp)
                            .padding(end = 4.dp),
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        Text(
            turn.text,
            // Larger and looser for the answer. It is a paragraph
            // someone reads once and has to follow; the question is
            // three words they already know.
            style = if (turn.fromUser) MaterialTheme.typography.bodyMedium
            else MaterialTheme.typography.bodyLarge.copy(lineHeight = 25.sp),
            color = if (turn.fromUser) Color(0xFFFFF6DC) else Ink,
        )
        if (copied) {
            Spacer(Modifier.height(4.dp))
            Text(
                str.doubt.copied,
                style = MaterialTheme.typography.labelSmall,
                color = Mint.accent,
            )
        }
    }
}




@Composable
private fun ModeRow(mode: MyAiMode, onMode: (MyAiMode) -> Unit, premium: Boolean, onPlans: () -> Unit) {
    val str = strings()
    val haptics = rememberHaptics()
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MyAiMode.entries.forEach { item ->
            val on = item == mode
            val paid = item != MyAiMode.Study
            val locked = paid && !premium
            val label = when (item) {
                MyAiMode.Study -> str.doubt.modeStudy
                MyAiMode.Friend -> str.doubt.modeFriend
                MyAiMode.Guru -> str.doubt.modeGuru
            }
            val sticker = when (item) {
                MyAiMode.Study -> Mint
                MyAiMode.Friend -> Lilac
                MyAiMode.Guru -> Butter
            }
            val art = when (item) {
                MyAiMode.Study -> TileArt.Journal
                MyAiMode.Friend -> TileArt.Person
                MyAiMode.Guru -> TileArt.Medal
            }

            // The fill floods in from the left rather than switching on, and
            // the chip swells past its size and settles back. Three flat
            // rectangles changing colour told you which was selected and
            // nothing else; this makes the tap feel like it did something,
            // which is the whole reason anyone presses it twice.
            val flood by animateFloatAsState(
                targetValue = if (on) 1f else 0f,
                animationSpec = Motion.settle(),
                label = "flood",
            )
            val swell by animateFloatAsState(
                targetValue = if (on) 1f else 0.96f,
                animationSpec = Motion.bouncy(),
                label = "swell",
            )
            val shape = RoundedCornerShape(20.dp)

            Box(
                Modifier
                    .graphicsLayer { scaleX = swell; scaleY = swell }
                    .clip(shape)
                    .background(CreamCard)
                    .drawBehind {
                        if (flood <= 0.01f) return@drawBehind
                        // A rising level, not a fade. Drawn from the bottom up
                        // so it reads as the chip filling rather than lighting.
                        val h = size.height * flood
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    sticker.fill.copy(alpha = 0.85f),
                                    sticker.fill,
                                ),
                                startY = size.height - h,
                                endY = size.height,
                            ),
                            topLeft = Offset(0f, size.height - h),
                            size = Size(size.width, h),
                        )
                    }
                    .border(if (on) Paper.Outline else 1.5.dp, Ink, shape)
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        when {
                            locked -> { onPlans() }
                            !on -> { onMode(item) }
                        }
                    }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                TileObject(art = art, fill = if (on) sticker.fill else InkLow, size = 18.dp)
                Spacer(Modifier.width(6.dp))
                Text(
                    if (locked) "$label  ·  ${str.doubt.proTag}" else label,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (on) Ink else Ink.copy(alpha = if (locked) 0.45f else 1f),
                )
                }
            }
        }
    }
}

@Composable
private fun PulseCard(pulse: StudyPulse) {
    val str = strings()
    Aura(color = GoldNeon, strength = 0.42f, modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(16.dp),
        ) {
            Text(
                str.doubt.pulseLabel,
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(4.dp))
            Text(pulse.headline, style = MaterialTheme.typography.titleMedium, color = Ink)
            Spacer(Modifier.height(8.dp))
            pulse.lines.forEach { line ->
                Text(line, style = MaterialTheme.typography.bodyMedium, color = InkMid)
            }
            Spacer(Modifier.height(10.dp))
            Text(pulse.next, style = MaterialTheme.typography.bodyMedium, color = Ink)
        }
    }
}

/**
 * The "How it works" tap-tooltip from the reference — a small "?" next to
 * the disclaimer, tap to reveal, tap elsewhere to dismiss. Same pattern
 * already used for Crown Mode's own explainer, rebuilt here rather than
 * shared since that one is private to PermissionsScreen and this needed
 * its own copy anyway.
 */
@Composable
private fun HowItWorksTip() {
    var open by remember { mutableStateOf(false) }
    Box {
        Box(
            Modifier
                .size(16.dp)
                .clip(CircleShape)
                .background(Ink.copy(alpha = 0.12f))
                .clickableNoRipple(remember { MutableInteractionSource() }) { open = !open },
            contentAlignment = Alignment.Center,
        ) {
            Text("?", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = InkMid)
        }
        if (open) {
            Popup(
                alignment = Alignment.BottomStart,
                offset = IntOffset(0, -40),
                onDismissRequest = { open = false },
            ) {
                Box(
                    Modifier
                        .width(230.dp)
                        .shadow(8.dp, RoundedCornerShape(12.dp), clip = false)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Ink)
                        .padding(12.dp),
                ) {
                    Text(
                        "AI processing happens off the device. Your question is sent, an answer comes back — nothing about how it works needs to sit on the main screen.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f),
                    )
                }
            }
        }
    }
}
