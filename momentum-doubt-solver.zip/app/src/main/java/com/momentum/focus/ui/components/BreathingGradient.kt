package com.momentum.focus.ui.components

import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * A slow diagonal light sweep, breathing in intensity, layered on top of
 * whatever a button already looks like — not a new button style. This is
 * additive (`drawContent()` first, the sweep after), so it never touches the
 * button's own colour, border or shape; it composes onto any existing
 * button the same way a shadow or padding modifier would.
 *
 * Built to work on paper as much as on dark glass: [colors] are drawn at
 * fairly low peak alpha and screened over the real button underneath, so a
 * warm amber sweep and a cool violet one both sit believably on cream paper
 * without ever washing it out to a flat tint.
 *
 * Two motions, not one: [strength] governs how visible the sweep gets at its
 * brightest (the "breathing" — intensity rising and falling on a slow
 * sine), while the sweep's *position* drifts continuously left to right on
 * its own independent, slower clock (the "flow"). A sweep that only pulsed
 * in place would read as a glow turning on and off; one that only moved
 * would read as a scan line. Both together is what reads as alive.
 *
 * Meant for the handful of buttons a screen actually wants noticed — a
 * primary CTA, an unlock button, the one action on an empty state — not
 * every tappable element on a screen. Applied to everything at once it
 * stops drawing the eye anywhere in particular, which is the opposite of
 * the point.
 */
fun Modifier.breathingGradient(
    colors: List<Color>,
    strength: Float = 0.34f,
): Modifier = composed {
    val infinite = rememberInfiniteTransition(label = "breathing-gradient")
    val breathe by infinite.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1900, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "breathe",
    )
    val flow by infinite.animateFloat(
        initialValue = -0.3f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(4200, easing = LinearEasing),
        ),
        label = "flow",
    )

    this.drawWithContent {
        drawContent()
        val sweepX = size.width * flow
        val band = size.width * 0.55f
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(
                    Color.Transparent,
                    colors.getOrElse(0) { Color.White }.copy(alpha = strength * breathe),
                    colors.getOrElse(1) { colors.first() }.copy(alpha = strength * 0.8f * breathe),
                    Color.Transparent,
                ),
                start = Offset(sweepX - band, 0f),
                end = Offset(sweepX + band, size.height),
            ),
        )
    }
}
