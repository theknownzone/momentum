package com.momentum.focus.ui.screens

import com.momentum.focus.ui.components.isReal
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.achievements
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.FrostScrim
import com.momentum.focus.ui.components.SkinMark
import com.momentum.focus.ui.components.StreakLadder
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileCard
import com.momentum.focus.ui.components.TileStat
import com.momentum.focus.ui.components.TileObject
import com.momentum.focus.ui.components.SuccessCard
import com.momentum.focus.data.Currency
import com.momentum.focus.data.XP_PER_LEVEL
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.ui.components.CrownMark
import com.momentum.focus.ui.components.Locked
import com.momentum.focus.ui.components.PactBanner
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.AVATAR_COUNT
import com.momentum.focus.ui.components.Avatar3D
import com.momentum.focus.ui.components.StickerCard
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.block.Admin
import com.momentum.focus.ui.util.rememberHaptics

@Composable
fun ProfileScreen(
    data: AppData,
    onCrown: (Boolean) -> Unit,
    onAvatar: (Int, Int) -> Unit,
    onSkin: (Int) -> Unit,
    onPlans: () -> Unit,
    onSettings: () -> Unit = {},
) {
    val str = strings()
    val haptics = rememberHaptics()
    val context = LocalContext.current
    var appearanceOpen by remember { mutableStateOf(false) }
    var lifetimeOpen by remember { mutableStateOf(false) }
    // The glass takes its tint from the skin, so choosing one changes the very
    // screen you chose it on instead of a single card two screens away.
    val skinNow = LocalSkin.current

    // Device admin is granted on a system screen, so the only honest way to
    // know whether it stuck is to re-read it every time this screen resumes.
    val owner = LocalLifecycleOwner.current
    var adminRefresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) adminRefresh++
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    val adminOn = remember(adminRefresh) { Admin.isActive(context) }
    // The switch used to flip the moment it was touched and only then ask for
    // admin. Cancel the system dialog, or have it fail to open at all, and the
    // app claimed the app could not be uninstalled while nothing was stopping
    // it. Crown mode is now whatever the system actually granted.
    LaunchedEffect(adminOn) {
        if (!adminOn && data.crownMode && !data.pactLive) onCrown(false)
    }

    // One root, and the sheets are inside it.
    //
    // This composable used to emit two siblings — the scrolling Column, then
    // the sheet — with no layout of its own. Whatever the parent happened to
    // be decided how they stacked, and in a Column the sheet was *added below*
    // the page rather than laid over it. Picking a theme therefore made the
    // screen grow by a sheet's height and then settle: the "expand" that kept
    // coming back. A Box means the sheet always overlays.
    Box(Modifier.fillMaxSize()) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        PlayerCard(data)

        Spacer(Modifier.height(18.dp))

        PactBanner(data.lockUntilEpochMs, Modifier.fillMaxWidth())

        Spacer(Modifier.height(Paper.Gap))

        // The loudest card on the screen after the player. It sat here in plain
        // cream, quieter than the four tiles beneath it, which made the one
        // thing on this page that is a decision look like a row of settings.
        // Rotating beam border — same technique as the Pro Plus card on
        // Plans, applied here too since this is the other "buy me" moment
        // in the app. Only while unbought: once purchased this should stop
        // advertising itself, same reasoning as the gold-vs-mint fill below.
        val beamAngle by com.momentum.focus.ui.components.ambient(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing)),
            label = "profile-beam-angle",
        )
        Box(Modifier.fillMaxWidth()) {
            if (!data.premium) {
                Canvas(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .matchParentSize()
                        .clip(RoundedCornerShape(Paper.CardRadius)),
                ) {
                    rotate(beamAngle, pivot = Offset(this.size.width / 2f, this.size.height / 2f)) {
                        drawRect(
                            brush = Brush.verticalGradient(listOf(Color(0xFFF4CB5A), Mint.fill, Color(0xFFF4CB5A))),
                            topLeft = Offset(size.width / 2f - size.width * 0.35f, -size.height * 0.2f),
                            size = Size(size.width * 0.7f, size.height * 1.4f),
                        )
                    }
                }
            }
        Aura(
            color = Tang.accent,
            strength = if (data.premium) 0.55f else 0.42f,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    // Inset so the halo has somewhere to land. The aura draws
                    // behind its content, and a card filling the full width
                    // buries it under opaque paint — the glow was rendering
                    // the whole time and simply had no margin to show in.
                    .padding(horizontal = 10.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    // Color.lit() — a top-lit vertical gradient, which is what
                    // this card already had.
                    //
                    // I replaced it with a hand-built Brush.verticalGradient to
                    // "give the card a lit face", not having checked that lit()
                    // returns a Brush and was already doing exactly that:
                    // lighten(0.24) at the top, the colour itself, darken(0.08)
                    // at the bottom. The replacement mixed a Brush and a Color
                    // in one list, which is the List<Any> the compiler rejected.
                    //
                    // Once bought, the card should stop looking like the pitch.
                    // Leaving it gold means the thing someone already paid for
                    // keeps advertising itself at them every time they open
                    // this screen.
                    .background(if (data.premium) Mint.fill.lit() else Butter.fill.lit())
                    .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.tap(); onPlans()
                    }
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(15.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Ink, Ink.copy(alpha = 0.82f)),
                            ),
                        )
                        .border(
                            2.dp,
                            Brush.linearGradient(
                                listOf(
                                    GoldNeon,
                                    GoldNeon.copy(alpha = 0.25f),
                                    GoldNeon.copy(alpha = 0.9f),
                                ),
                            ),
                            RoundedCornerShape(15.dp),
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    // The app's own crown, drawn — not the emoji.
                    //
                    // This used to be "\uD83D\uDC51", a system emoji, on the one
                    // tile that is supposed to be the most valuable thing on the
                    // screen. Every phone renders that glyph differently: Samsung
                    // gives it a flat cartoon, older MIUI a completely different
                    // shape, and none of them carry the light-side/dark-side
                    // shading every other solid in this app has. The most
                    // expensive object in the product was the one thing not drawn
                    // by the product.
                    //
                    // A gradient rim rather than a flat outline, so the edge
                    // catches light along one side and falls off on the other.
                    // That is what makes the reference cards read as lit; it is a
                    // border with two ends, not a glow behind a rectangle.
                    Canvas(Modifier.matchParentSize()) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colorStops = arrayOf(
                                    0f to GoldNeon.copy(alpha = 0.55f),
                                    0.6f to GoldNeon.copy(alpha = 0.18f),
                                    1f to Color.Transparent,
                                ),
                                center = center,
                                radius = size.minDimension * 0.6f,
                            ),
                            radius = size.minDimension * 0.6f,
                        )
                    }
                    CrownMark(size = 28.dp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    // Dark letters on a gold glow, not gold on gold. Set in
                    // GoldNeon it was yellow text on a yellow card and simply
                    // vanished — the glow behind carries the gold, so the
                    // letters themselves have to contrast with the fill.
                    Aura(color = GoldNeon, strength = 0.5f) {
                        Text(
                            if (data.premium) "MEMBER SINCE DAY ONE" else "MOMENTUM PREMIUM",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Butter.on,
                        )
                    }
                    // The promise stays on the card, not only inside the screen
                    // it opens. Someone who never taps through should still be
                    // able to see that nothing protective sits behind the price.
                    Text(
                        if (data.premium) "Thank you — it keeps this thing alive."
                        // The count ties this card to the blurred rows behind
                        // the paywall, so the number and the thing it refers to
                        // are the same number.
                        else "3 locked · blocking always stays free",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Butter.on.copy(alpha = 0.8f),
                    )
                    if (!data.premium) {
                        Spacer(Modifier.height(10.dp))
                        PowBadge()
                    }
                }
                // The price belongs on the card. Without it the only way to
                // learn what this costs is to tap through, so people tap to
                // find out and leave — which reads as a dead end rather than
                // an offer.
                if (!data.premium) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            "\u20B9399",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Butter.on,
                        )
                        // A gold card reads as a subscription until it says
                        // otherwise, and that assumption is the single biggest
                        // reason a student closes this without tapping.
                        Text(
                            "one-time",
                            style = MaterialTheme.typography.labelSmall,
                            color = Butter.on.copy(alpha = 0.7f),
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    "\u203A",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Butter.on,
                )
            }
        }
        }

        Spacer(Modifier.height(10.dp))

        // One card, four columns — the shape the reference uses, and the reason
        // it works: an icon row scans in a glance where stacked text rows have
        // to be read. These four used to be rows inside a section that stays
        // collapsed, which is how Plans stayed invisible for a whole release.

        // Closed by default. Open, this one section — avatars, six themes, a
        // name field, a language pair — was taller than everything else on the
        // screen put together, so Profile opened on a wall of settings instead
        // of on the person. The reference profiles this is modelled on are a
        // short stack of rows you tap into; that only works if the rows are
        // shut.
        Spacer(Modifier.height(Paper.Gap))

        // The score, full width, because it is the one number the rest add up
        // to and a tile would put it level with its own parts.
        SuccessCard(data, Modifier.fillMaxWidth())

        Spacer(Modifier.height(10.dp))

        // Everything else is tiles, two across. A screen of full-width cards
        // is a list you scroll; a grid is something you look at. The four
        // figures are also the four the score is made of, so they belong side
        // by side where two of them can be compared without scrolling.
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // Was a second copy of the streak. Between the player card's chip,
            // this tile and the ladder below, the same number appeared three
            // times on one screen — which reads as an app with only one number
            // to show. Sessions is the figure the streak is built out of and
            // it appears nowhere else.
            TileStat(
                str.common.profileSessions,
                data.sessions.count { it.completed }.toString(),
                Modifier.weight(1f),
                fill = Butter.fill,
                art = TileArt.Flame,
                artFill = Tang.fill,
            )
            // Best streak, not level. The player card two rows up already
            // reads "LEVEL 1 · ROOKIE" in the largest type on the screen, so a
            // tile repeating it was the second duplicate on this page. The
            // best run is the number the current streak is measured against
            // and it appears nowhere else here.
            TileStat(
                str.common.profileBest,
                "${maxOf(data.bestStreak, data.streakDays)}d",
                Modifier.weight(1f),
                fill = Lilac.fill,
                art = TileArt.Medal,
                artFill = Gold.fill,
            )
        }

        Spacer(Modifier.height(10.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            TileStat(
                str.home.statToday,
                "${data.minutesToday / 60}h ${data.minutesToday % 60}m",
                Modifier.weight(1f),
                fill = Sky.fill,
                art = TileArt.Clock,
                artFill = Mint.fill,
            )
            TileStat(
                str.home.statWallet,
                Currency.format(data.balanceMinutes),
                Modifier.weight(1f),
                fill = Mint.fill,
                art = TileArt.Wallet,
                artFill = Emerald.fill,
            )
        }

        Spacer(Modifier.height(Paper.Gap))

        // Above the tiles you tap into, not below them. Everything from here
        // down is something you go and change; everything above is something
        // you have done.
        StreakLadder(data, Modifier.fillMaxWidth())

        Spacer(Modifier.height(Paper.Gap))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            TileCard(
                Modifier.weight(1f),
                fill = CreamCard,
                onClick = { haptics.tap(); appearanceOpen = true },
            ) {
                TileObject(art = TileArt.Palette, fill = skinNow.accent, size = 30.dp)
                Spacer(Modifier.height(8.dp))
                Text(str.common.appearance, style = MaterialTheme.typography.titleMedium, color = Ink)
                Text(
                    str.common.appearanceSub,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                )
            }
            TileCard(
                Modifier.weight(1f),
                fill = CreamCard,
                onClick = { haptics.tap(); lifetimeOpen = true },
            ) {
                TileObject(art = TileArt.Trophy, fill = Sky.fill, size = 30.dp)
                Spacer(Modifier.height(8.dp))
                Text(str.common.lifetime, style = MaterialTheme.typography.titleMedium, color = Ink)
                Text(
                    str.common.lifetimeSub,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        // The one door out of this screen. Everything configurable moved
        // behind it, so Profile is now only ever about the person.
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .clickableNoRipple(remember { MutableInteractionSource() }) {
                    haptics.tap(); onSettings()
                }
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.Filled.Tune,
                contentDescription = null,
                tint = Ink,
                modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    str.common.settings,
                    style = MaterialTheme.typography.titleMedium,
                    color = Ink,
                )
                Text(
                    str.common.settingsSub,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                )
            }
            Icon(
                Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = InkMid,
                modifier = Modifier.size(22.dp),
            )
        }

        Spacer(Modifier.height(24.dp))
    }

        if (appearanceOpen) {
            ProfileSheet(str.common.appearance, { appearanceOpen = false }) {

            // ---- avatar ----
            Text(
                "AVATAR",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(10.dp))
            // v5: one row — your monogram in each colour. The cartoon photos
            // and cube/gem/orb shapes are gone.
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                repeat(6) { i ->
                    val on = data.avatarColor == i
                    val pop by androidx.compose.animation.core.animateFloatAsState(if (on) 1.08f else 1f, androidx.compose.animation.core.spring(0.5f, 500f), label = "av$i")
                    Box(
                        Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .graphicsLayer { scaleX = pop; scaleY = pop }
                            .drawBehind { if (on) drawCircle(stickerFor(i).fill.copy(alpha = 0.35f), size.minDimension / 2 + 6.dp.toPx()) }
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick(); onAvatar(data.avatarShape, i)
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Avatar3D(colorIndex = i, shapeIndex = 0, size = 46.dp)
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            // ---- themes ----
            Text("THEMES", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "Unlocked by levelling up",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(10.dp))
            // Seasonal skins (Rakhi onward) used to be listed here too, next
            // to a header that says "Unlocked by levelling up" — which was
            // never true for them, they all sit at unlockLevel = 1 and exist
            // for HomeScreen's festival-day art overlay, not as something to
            // deliberately pick. Listed here they read as five more themes
            // doing the same job as the five real ones above them. They stay
            // in the Skin enum (HomeScreen still reaches for Skin.DIWALI /
            // Skin.RAKHI / Skin.JANMASHTAMI by name on the day itself) — this
            // is only the picker no longer offering them as a choice.
            Skin.entries.filter { it.ordinal < Skin.RAKHI.ordinal }.forEach { skin ->
                val i = skin.ordinal
                // Premium unlocks every theme immediately. This is the only
                // thing the paid tier actually changes, and it changes it by
                // giving something early rather than by taking anything away —
                // a free user still earns every theme by levelling, exactly as
                // before.
                val open = data.premium || skin.unlockedAt(data.level)
                val on = data.skin == i
                // Frosted rather than merely labelled: a locked theme that
                // looks identical to an unlocked one except for a word at the
                // end reads as available, and people tap it and get nothing.
                // The card draws its own lock now (dimmed sky + LEVEL tag).
                Locked(
                    locked = false,
                    label = "LEVEL ${skin.unlockLevel}",
                    modifier = Modifier.fillMaxWidth(),
                ) {
                ThemePreviewCard(skin = skin, open = open, on = on) {
                    if (open) { haptics.confirm(); onSkin(i) } else haptics.reject()
                }
                }
            }

            Spacer(Modifier.height(20.dp))
            }
        }

        if (lifetimeOpen) {
            ProfileSheet(str.common.lifetime, { lifetimeOpen = false }) {
            // ---- lifetime numbers ----
            StickerCard(sticker = Emerald, modifier = Modifier.fillMaxWidth()) {
                Text("LIFETIME", style = MaterialTheme.typography.labelSmall, color = Mint.on.copy(alpha = 0.75f))
                Spacer(Modifier.height(12.dp))
                // Every line uses the card's own dark-on-hue colour. Giving each
                // row its own accent looked like confetti and was unreadable.
                StatLine("Focused", "${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m")
                StatLine("Spent on distraction", "${data.spentMinutes}m")
                StatLine("Sessions finished", "${data.sessions.count { it.completed }}")
                StatLine("Urges beaten", "${data.urgesSurvived}")
                StatLine("Best streak", "${maxOf(data.bestStreak, data.streakDays)} days")
            }

            Spacer(Modifier.height(Paper.Gap))
            }
        }
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyLarge,
            color = Mint.on.copy(alpha = 0.72f),
            modifier = Modifier.weight(1f),
        )
        Text(value, style = MaterialTheme.typography.titleMedium, color = Mint.on)
    }
}



/** Rank names by level. Numbers alone are a scoreboard; names are an identity. */
private fun rankFor(level: Int): String = when {
    level >= 20 -> "Untouchable"
    level >= 15 -> "Locked in"
    level >= 10 -> "Relentless"
    level >= 6 -> "Consistent"
    level >= 3 -> "Warming up"
    else -> "Rookie"
}

/**
 * The player card. Level ring, rank, XP to next level, and the badges already
 * earned — the things a game shows first, because progress you can see is the
 * only kind that pulls anyone back tomorrow.
 */
@Composable
private fun PlayerCard(data: AppData) {
    val sticker = stickerFor(data.avatarColor)
    // Premium's only visible reward inside the app itself. Everything else the
    // unlock buys is capacity — more profiles, longer history — which is felt
    // rather than seen, so the card someone looks at every day gets the halo.
    val glow = data.premium
    val progress by animateFloatAsState(
        data.xpIntoLevel / XP_PER_LEVEL.toFloat(), Motion.settle(), label = "xp"
    )
    val unlocked = data.achievements().filter { it.unlocked }

    Aura(
        color = if (glow) sticker.fill else Color.Transparent,
        strength = if (glow) 0.38f else 0f,
        modifier = Modifier.fillMaxWidth(),
    ) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(Ink)
            .border(
                if (glow) Paper.Outline else 0.dp,
                if (glow) sticker.fill else Color.Transparent,
                RoundedCornerShape(Paper.CardRadius),
            )
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(76.dp)) {
                    val stroke = 7.dp.toPx()
                    val arc = Size(size.width - stroke, size.height - stroke)
                    val tl = Offset(stroke / 2, stroke / 2)
                    drawArc(
                        InkLow.copy(alpha = 0.3f), -90f, 360f, false, tl, arc,
                        style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                    drawArc(
                        sticker.fill, -90f, 360f * progress, false, tl, arc,
                        style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                }
                Avatar3D(
                    colorIndex = data.avatarColor,
                    shapeIndex = data.avatarShape,
                    size = 48.dp,
                )
            }

            Spacer(Modifier.width(16.dp))

            Column(Modifier.weight(1f)) {
                Text(
                    "LEVEL ${data.level} · ${rankFor(data.level).uppercase()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = sticker.fill,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    data.userName,
                    style = MaterialTheme.typography.headlineSmall,
                    color = CreamCard,
                )
                Text(
                    "${XP_PER_LEVEL - data.xpIntoLevel} xp to level ${data.level + 1}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkLow,
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("${data.earnedMinutes / 60}h focused", Mint)
            Chip("${unlocked.size} badges", Lilac)
        }

        // The chips are three totals with no sense of direction — "14h focused"
        // reads the same whether this week was the best one yet or the first in
        // a fortnight. Seven bars answer that without adding a number to read.
        val today = remember { java.time.LocalDate.now().toEpochDay() }
        val week = remember(data.sessions, today) {
            val b = IntArray(7)
            data.sessions.filter { it.completed }.forEach { s ->
                val ago = (today - s.startedAtEpochDay).toInt()
                if (ago in 0..6) b[6 - ago] += s.minutes
            }
            b.toList()
        }
        if (week.any { it > 0 }) {
            Spacer(Modifier.height(14.dp))
            val peak = week.max().coerceAtLeast(1)
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(38.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                week.forEachIndexed { i, m ->
                    // An empty day still gets a sliver, so the row reads as
                    // seven days rather than as however many were studied.
                    val frac = (m.toFloat() / peak).coerceAtLeast(0.08f)
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight(frac)
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                if (i == 6) sticker.fill
                                else CreamCard.copy(alpha = if (m > 0) 0.55f else 0.18f)
                            )
                    )
                }
            }
        }

        if (unlocked.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                // Was a flat colour square with nothing else — no border, no
                // mark, indistinguishable from a swatch. A star and the same
                // Ink border every other tile on this app has is what turns
                // "coloured block" into "badge".
                unlocked.take(6).forEachIndexed { i, _ ->
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(stickerFor(i).fill)
                            .border(1.5.dp, Ink, RoundedCornerShape(9.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("\u2605", color = stickerFor(i).on, fontSize = 14.sp)
                    }
                }
            }
        }
    }
    }
}

@Composable
private fun Chip(text: String, sticker: Sticker) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(sticker.fill.copy(alpha = 0.18f))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text, style = MaterialTheme.typography.bodyMedium, color = sticker.fill)
    }
}


/**
 * A sheet from the bottom, for the things a row opens.
 *
 * Capped at most of the screen and scrollable inside, because the appearance
 * one holds six themes and a row of avatars — the exact content that made the
 * old accordion swallow the page when it was open.
 */
@Composable
private fun ProfileSheet(title: String, onClose: () -> Unit, body: @Composable () -> Unit) {
    BackHandler(onBack = onClose)
    FrostScrim {
        Box(
            Modifier
                .fillMaxSize()
                .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
        )
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.88f)
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .background(Cream)
                    .border(
                        Paper.Outline,
                        Ink,
                        RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    )
                    .clickableNoRipple(remember { MutableInteractionSource() }) { }
                    .padding(20.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        title,
                        style = MaterialTheme.typography.headlineSmall,
                        color = Ink,
                        modifier = Modifier.weight(1f),
                    )
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() }
                            .padding(6.dp),
                    ) {
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = null,
                            tint = Ink,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Column(Modifier.verticalScroll(rememberScrollState())) { body() }
            }
        }
    }
}

/**
 * Theme picker card (v4): a live miniature of the hero — the theme's own sky,
 * light, and running weather — with its name, a sample balance and its accent
 * button, so you see the theme before you pick it. Selected = accent glow +
 * IN USE sticker. Presses into its ink shadow.
 */
@Composable
private fun ThemePreviewCard(skin: Skin, open: Boolean, on: Boolean, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val p by androidx.compose.animation.core.animateFloatAsState(if (pressed) 1f else 0f, androidx.compose.animation.core.tween(110), label = "themePress")
    val glow by androidx.compose.animation.core.animateFloatAsState(if (on) 1f else 0f, androidx.compose.animation.core.tween(280), label = "themeGlow")
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp, end = 5.dp)
            .height(112.dp)
            .drawBehind {
                if (glow > 0f) for (k in 1..4) {
                    val g = k * 3.dp.toPx()
                    drawRoundRect(skin.accent.copy(alpha = 0.18f * glow * (1f - k / 5f)), androidx.compose.ui.geometry.Offset(-g, -g), androidx.compose.ui.geometry.Size(size.width + 2 * g, size.height + 2 * g), androidx.compose.ui.geometry.CornerRadius(16.dp.toPx() + g))
                }
                val d = 5.dp.toPx() * (1f - p)
                drawRoundRect(Ink, androidx.compose.ui.geometry.Offset(d + 5.dp.toPx() * p, d + 5.dp.toPx() * p), size, androidx.compose.ui.geometry.CornerRadius(16.dp.toPx()))
            }
            .graphicsLayer { translationX = 5.dp.toPx() * p; translationY = 5.dp.toPx() * p }
            .clip(shape)
            .background(Brush.verticalGradient(listOf(skin.heroTop, skin.heroBottom)))
            .clickableNoRipple(src, onClick = onClick),
    ) {
        if (skin.isReal()) com.momentum.focus.ui.components.HeroGrade(skin, Modifier.matchParentSize())
        else com.momentum.focus.ui.components.HeroAtmosphere(skin, Modifier.matchParentSize())
        if (open) {
            if (skin.isReal()) com.momentum.focus.ui.components.RealSkinWeather(skin, Modifier.matchParentSize())
            else com.momentum.focus.ui.components.SkinWeather(skin, Modifier.matchParentSize())
        }
        Row(
            Modifier.matchParentSize().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(skin.label.uppercase(), style = MaterialTheme.typography.titleMedium, fontWeight = androidx.compose.ui.text.font.FontWeight.Black, color = skin.onHero)
                Text(
                    if (!open) "Unlocks at level ${skin.unlockLevel}" else skin.blurb,
                    style = MaterialTheme.typography.bodySmall, color = skin.onHeroMuted, maxLines = 2,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    "₹128",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        brush = Brush.linearGradient(listOf(Color(0xFFFFE9A8), GoldNeon, Color(0xFFC68B1E))),
                    ),
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    if (on) "IN USE" else "Start",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                    color = skin.onAccent,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(skin.accent)
                        .border(2.dp, Ink, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                )
            }
        }
        if (!open) {
            Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.45f)), contentAlignment = Alignment.Center) {
                Text("LEVEL ${skin.unlockLevel}", style = MaterialTheme.typography.labelLarge, fontWeight = androidx.compose.ui.text.font.FontWeight.Black, color = skin.onHero,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(alpha = 0.5f)).border(1.5.dp, skin.onHeroMuted, RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 4.dp))
            }
        }
        // ink edge on top of everything
        Box(Modifier.matchParentSize().border(Paper.Outline, Ink, shape))
    }
}


/**
 * POW badge (comic burst, owner ask): a jagged ink starburst sticker that
 * says what Pro unlocks, tilted, with a hard shadow. Pops in once and does a
 * small slow wobble so it reads alive. Shown only while Pro is locked — once
 * unlocked the card goes back to its original "member" look untouched.
 */
@Composable
private fun PowBadge() {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(250); shown = true }
    val pop by androidx.compose.animation.core.animateFloatAsState(
        if (shown) 1f else 0f, Motion.bouncy(), label = "pow",
    )
    val wob = com.momentum.focus.ui.components.ambient(
        -1f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(2600, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            androidx.compose.animation.core.RepeatMode.Reverse,
        ),
        label = "powWobT",
    )
    Box(
        Modifier
            .graphicsLayer {
                scaleX = pop; scaleY = pop
                rotationZ = -5f + 1.5f * wob.value
            }
            .drawBehind {
                // 16-point burst, alternating long/short spikes
                fun burst(dx: Float, dy: Float): androidx.compose.ui.graphics.Path =
                    androidx.compose.ui.graphics.Path().apply {
                        val cx = size.width / 2 + dx; val cy = size.height / 2 + dy
                        val rx = size.width / 2 + 8.dp.toPx(); val ry = size.height / 2 + 9.dp.toPx()
                        for (i in 0 until 32) {
                            val a = Math.PI * 2 * i / 32
                            val k = if (i % 2 == 0) 1f else 0.74f
                            val x = cx + (kotlin.math.cos(a) * rx * k).toFloat()
                            val y = cy + (kotlin.math.sin(a) * ry * k).toFloat()
                            if (i == 0) moveTo(x, y) else lineTo(x, y)
                        }
                        close()
                    }
                val d = 4.dp.toPx()
                drawPath(burst(d, d), Ink)
                drawPath(burst(0f, 0f), Tang.fill)
                drawPath(burst(0f, 0f), Ink, style = androidx.compose.ui.graphics.drawscope.Stroke(2.5.dp.toPx(), join = androidx.compose.ui.graphics.StrokeJoin.Round))
                // halftone dots inside
                val st = 6.dp.toPx()
                var y = st
                while (y < size.height) {
                    var x = st
                    while (x < size.width) {
                        drawCircle(Ink.copy(alpha = 0.12f), 1.2.dp.toPx(), androidx.compose.ui.geometry.Offset(x, y))
                        x += st
                    }
                    y += st
                }
            }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "POW!",
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                color = Butter.fill,
                style = MaterialTheme.typography.titleMedium.copy(
                    shadow = androidx.compose.ui.graphics.Shadow(Ink, androidx.compose.ui.geometry.Offset(3f, 3f), 0f),
                ),
            )
            Text(
                "UNLOCK THE AURA",
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = androidx.compose.ui.unit.TextUnit(1.1f, androidx.compose.ui.unit.TextUnitType.Sp),
                color = Ink,
            )
        }
    }
}
