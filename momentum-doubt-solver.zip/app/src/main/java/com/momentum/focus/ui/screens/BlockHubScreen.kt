package com.momentum.focus.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.R
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

/**
 * Everything that blocks something, in one place.
 *
 * These controls were scattered by accident rather than design: the app list
 * opened from a Home card, per-app caps were buried inside that list, feeds
 * had their own Home card, profiles and class hours sat in a long settings
 * column next to avatars and exam dates. Four related answers to one question
 * — what is switched off — in four unrelated places.
 *
 * The hub does not own any of them. Each row still opens the screen that does
 * the work, so nothing was rewritten to build this; what changed is that there
 * is now one obvious place to look.
 */
@Composable
fun BlockHubScreen(
    data: AppData,
    onApps: () -> Unit,
    onFeeds: () -> Unit,
    onProfiles: () -> Unit,
    onSchedule: () -> Unit,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 24.dp),
    ) {
        Text("BLOCK", style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Text(
            "Kya band hai",
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            "Rokne wali har cheez yahan hai. Apps, feeds, limits, aur kab lagu ho.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp),
        )

        Spacer(Modifier.height(20.dp))

        HubRow(
            title = "Apps",
            detail = if (data.blockedPackages.isEmpty()) "Koi app band nahi"
            else "${data.blockedPackages.size} apps band" +
                if (data.dailyCapMinutes.isEmpty()) ""
                else " · ${data.dailyCapMinutes.size} pe daily limit",
            tagline = "FOCUS MODE ON",
            sticker = Tang,
            art = R.drawable.welcome_distraction_costs,
        ) { haptics.tap(); onApps() }

        HubRow(
            title = "Feeds",
            detail = if (data.blockedSurfaces.isEmpty()) "Shorts aur Reels chalu hain"
            else "${data.blockedSurfaces.size} feeds band · app khuli rehti hai",
            tagline = "SCROLL LESS. LIVE MORE.",
            sticker = Mint,
            art = R.drawable.welcome_one_tap_out,
        ) { haptics.tap(); onFeeds() }

        HubRow(
            title = "Profiles",
            detail = data.profiles.firstOrNull { it.id == data.activeProfileId }?.let {
                "${it.name} chalu hai"
            } ?: if (data.profiles.isEmpty()) "Koi profile nahi"
            else "${data.profiles.size} saved",
            tagline = "STAY PRIVATE. STAY FOCUSED.",
            sticker = Sky,
            art = R.drawable.welcome_data_local,
        ) { haptics.tap(); onProfiles() }

        HubRow(
            title = "Kab lagu ho",
            detail = if (!data.classHoursOn) "Class hours off"
            else "${data.classStartHour}:00–${data.classEndHour}:00 · " +
                "hafte mein ${data.classDays.size} din",
            tagline = "DISCIPLINE BUILDS FREEDOM.",
            sticker = Butter,
            art = R.drawable.welcome_focus_money,
        ) { haptics.tap(); onSchedule() }

        Spacer(Modifier.height(20.dp))

        Text(
            "Pact ke dauran in sab ko sirf kas sakte ho — dheela nahi kar sakte.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(20.dp))

        SquishButton(
            label = "Done",
            sticker = Emerald,
            modifier = Modifier.fillMaxWidth(),
        ) { haptics.confirm(); onDone() }

        Spacer(Modifier.height(18.dp))

        // The same small brand line the reference target put at the very
        // bottom of this screen — this hub is the one place all four kinds
        // of blocking meet, so it is the one screen that earns closing on
        // the app's own name rather than just ending on the button.
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "MOMENTUM",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = InkLow,
            )
            Text(
                "Discipline today. A brighter tomorrow.",
                style = MaterialTheme.typography.labelSmall,
                color = InkLow,
            )
        }
    }
}

@Composable
private fun HubRow(
    title: String,
    detail: String,
    tagline: String,
    sticker: Sticker,
    art: Int,
    onClick: () -> Unit,
) {
    // Large gradient card with the same photo-real illustration the welcome
    // slides use, bled into the right edge behind a fade rather than boxed
    // as a small separate icon — the flat TileCard-plus-104dp-icon version
    // read as compact and safe next to the target, which wanted these to
    // feel like the biggest thing on the screen.
    val shape = RoundedCornerShape(28.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 14.dp)
            .height(150.dp)
            .drawBehind {
                drawRoundRect(
                    color = Color.Black.copy(alpha = 0.22f),
                    topLeft = Offset(4.dp.toPx(), 6.dp.toPx()),
                    size = Size(size.width - 1.dp.toPx(), size.height - 1.dp.toPx()),
                    cornerRadius = CornerRadius(28.dp.toPx(), 28.dp.toPx()),
                )
            }
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(sticker.fill.lighten(0.18f), sticker.fill, sticker.accent),
                ),
            )
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick),
    ) {
        Image(
            painter = painterResource(art),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .fillMaxWidth(0.52f)
                // drawBehind would put this gradient underneath the image's
                // own opaque bitmap, where it can never be seen. drawWithContent
                // draws the image first, then this fade on top of it, which is
                // what actually blends the illustration's left edge into the
                // card's own colour instead of cutting it off with a hard line.
                .drawWithContent {
                    drawContent()
                    drawRect(
                        Brush.horizontalGradient(
                            listOf(sticker.fill, Color.Transparent),
                            startX = 0f,
                            endX = size.width * 0.55f,
                        ),
                    )
                },
        )
        Column(
            Modifier
                .align(Alignment.CenterStart)
                .fillMaxWidth(0.68f)
                .padding(start = 20.dp, end = 8.dp),
        ) {
            Text(
                tagline,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = sticker.on.copy(alpha = 0.85f),
            )
            Spacer(Modifier.height(2.dp))
            Text(
                title,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = sticker.on,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                detail,
                style = MaterialTheme.typography.bodyMedium,
                color = sticker.on.copy(alpha = 0.82f),
            )
        }
        Text(
            "›",
            style = MaterialTheme.typography.displayMedium,
            color = sticker.on,
            modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp),
        )
    }
}
