package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

/**
 * Saved rule sets.
 *
 * Deliberately snapshots rather than templates: what gets saved is whatever is
 * switched on at that moment, so there is no separate editor to keep in sync
 * and no way for a profile to describe a state the app cannot actually be in.
 */
@Composable
fun ProfilesScreen(
    data: AppData,
    onSave: (String) -> Unit,
    onApply: (String) -> Unit,
    onDelete: (String) -> Unit,
    onDone: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    var name by remember { mutableStateOf("") }
    var nameFocused by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 24.dp),
    ) {
        Text(str.profiles.kicker, style = MaterialTheme.typography.labelSmall, color = Sky.accent)
        Text(
            str.profiles.title,
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            str.profiles.blurb,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp),
        )

        Spacer(Modifier.height(18.dp))

        if (data.pactLive) {
            Text(
                str.profiles.pactLocked,
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.accent,
            )
            Spacer(Modifier.height(12.dp))
        }

        Text(str.profiles.saveHeader, style = MaterialTheme.typography.labelSmall, color = InkMid)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(CreamCard)
                    .border(2.dp, if (nameFocused) Sky.accent else Ink, RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 14.dp),
            ) {
                // The floating-label from the reference — the placeholder
                // shrinks and lifts clear of the text the moment there's
                // something to type over, instead of a placeholder that
                // just vanishes outright the instant a first character
                // lands, which is what happened here before.
                val labelUp = name.isNotBlank() || nameFocused
                val labelOffsetY by animateDpAsState(if (labelUp) (-22).dp else 0.dp, tween(180), label = "name-label-y")
                val labelScale by animateFloatAsState(if (labelUp) 0.72f else 1f, tween(180), label = "name-label-scale")
                Text(
                    str.profiles.namePlaceholder,
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (nameFocused) Sky.accent else InkMid,
                    modifier = Modifier
                        .graphicsLayer {
                            translationY = labelOffsetY.toPx()
                            scaleX = labelScale
                            scaleY = labelScale
                            transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
                        }
                        .alpha(if (name.isBlank() || labelUp) 1f else 0f),
                )
                BasicTextField(
                    value = name,
                    onValueChange = { name = it.take(24) },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = Ink),
                    cursorBrush = SolidColor(Ink),
                    modifier = Modifier
                        .fillMaxWidth()
                        .onFocusChanged { nameFocused = it.isFocused },
                )
            }
            Spacer(Modifier.width(10.dp))
            SquishButton(label = str.profiles.save, sticker = Sky) {
                if (name.isNotBlank()) {
                    haptics.confirm(); onSave(name); name = ""
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        if (data.profiles.isEmpty()) {
            Text(
                str.profiles.emptyState,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            data.profiles.forEach { p ->
                val active = p.id == data.activeProfileId
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .clip(RoundedCornerShape(Paper.CardRadius))
                        .background(if (active) Mint.fill else CreamCard)
                        .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                        .padding(16.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                p.name,
                                style = MaterialTheme.typography.headlineSmall,
                                color = if (active) Mint.on else Ink,
                            )
                            Text(
                                "${p.blockedPackages.size} apps · ${p.blockedSurfaces.size} feeds · " +
                                    "${p.dailyCapMinutes.size} caps",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (active) Mint.on.copy(alpha = 0.75f) else InkMid,
                            )
                            Text(
                                if (p.classHoursOn)
                                    "${p.classStartHour}:00–${p.classEndHour}:00 · ${p.classDays.size} din"
                                else str.profiles.classHoursOff,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (active) Mint.on.copy(alpha = 0.75f) else InkMid,
                            )
                        }
                        if (active) {
                            Text(
                                str.profiles.active,
                                style = MaterialTheme.typography.labelSmall,
                                color = Mint.on,
                            )
                        }
                    }
                    if (!active && !data.pactLive) {
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ApplyPulseButton(label = str.profiles.apply) {
                                haptics.confirm(); onApply(p.id)
                            }
                            DeleteButton(onClick = { haptics.tick(); onDelete(p.id) })
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        SquishButton(
            label = str.profiles.done,
            sticker = Emerald,
            modifier = Modifier.fillMaxWidth(),
        ) { haptics.confirm(); onDone() }
    }
}

/**
 * The circular-to-pill delete button from the reference — a compact red
 * circle with a trash mark that briefly expands to actually say "Delete"
 * before firing, rather than a plain outlined "Remove" text button that
 * looked like any other secondary action on the row. The reference expands
 * on hover; a touch screen has no hover, so this expands on the tap itself,
 * a short beat before the delete actually happens — enough to register as
 * "yes, delete" rather than being indistinguishable from any other tap.
 */
@Composable
private fun DeleteButton(onClick: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val width by animateDpAsState(if (expanded) 100.dp else 40.dp, tween(280), label = "delete-width")
    val scope = rememberCoroutineScope()

    Box(
        Modifier
            .width(width)
            .height(40.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFFFF4545))
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                if (!expanded) {
                    expanded = true
                    scope.launch {
                        delay(450)
                        onClick()
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        if (expanded) {
            Text("Delete", style = MaterialTheme.typography.labelLarge, color = Color.White)
        } else {
            Canvas(Modifier.size(16.dp)) {
                val w = size.width
                drawRoundRect(
                    color = Color.White,
                    topLeft = Offset(w * 0.20f, w * 0.30f),
                    size = Size(w * 0.60f, w * 0.55f),
                    cornerRadius = CornerRadius(w * 0.06f),
                )
                drawLine(Color.White, Offset(w * 0.12f, w * 0.28f), Offset(w * 0.88f, w * 0.28f), strokeWidth = w * 0.08f, cap = StrokeCap.Round)
                drawLine(Color.White, Offset(w * 0.38f, w * 0.18f), Offset(w * 0.62f, w * 0.18f), strokeWidth = w * 0.08f, cap = StrokeCap.Round)
            }
        }
    }
}

/**
 * The install-toggle from the reference — a brief pulse-and-rotate before
 * settling into a confirmed state, in place of a plain SquishButton that
 * just fires immediately. Applying a profile is instant underneath; this
 * gives it the same half-second of "doing it" that installing something
 * really would have, so the tap reads as an actual action taken rather
 * than a label that happened to change.
 */
@Composable
private fun ApplyPulseButton(label: String, onApplied: () -> Unit) {
    var phase by remember { mutableIntStateOf(0) } // 0 idle, 1 pulsing, 2 done
    val scope = rememberCoroutineScope()
    val width by animateDpAsState(if (phase == 0) 96.dp else 40.dp, tween(300), label = "apply-width")

    Box(
        Modifier
            .width(width)
            .height(40.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Emerald.fill)
            .border(2.dp, Ink, RoundedCornerShape(20.dp))
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                if (phase == 0) {
                    phase = 1
                    scope.launch {
                        delay(650)
                        phase = 2
                        onApplied()
                        delay(900)
                        phase = 0
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        when (phase) {
            0 -> Text(label, style = MaterialTheme.typography.titleMedium, color = Emerald.on)
            1 -> {
                val infinite = rememberInfiniteTransition(label = "apply-spin")
                val angle by infinite.animateFloat(0f, 360f, infiniteRepeatable(tween(600, easing = LinearEasing)), label = "angle")
                Canvas(Modifier.size(16.dp)) {
                    rotate(angle) {
                        drawArc(Emerald.on, 0f, 270f, useCenter = false, style = Stroke(width = size.width * 0.16f, cap = StrokeCap.Round))
                    }
                }
            }
            else -> Canvas(Modifier.size(16.dp)) {
                val w = size.width
                drawLine(Emerald.on, Offset(w * 0.15f, w * 0.5f), Offset(w * 0.4f, w * 0.75f), strokeWidth = w * 0.16f, cap = StrokeCap.Round)
                drawLine(Emerald.on, Offset(w * 0.4f, w * 0.75f), Offset(w * 0.88f, w * 0.2f), strokeWidth = w * 0.16f, cap = StrokeCap.Round)
            }
        }
    }
}
