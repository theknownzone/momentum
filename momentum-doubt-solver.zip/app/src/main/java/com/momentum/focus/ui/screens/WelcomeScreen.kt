package com.momentum.focus.ui.screens

import kotlin.math.PI
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.scaleIn
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.tr
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.Strings
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay

/*
 * Onboarding, design system v2 (2026-10-03).
 *
 * The four raster cartoons are gone. Each page now has a code-drawn motion
 * graphic around one shared mint ring, so the art matches the rest of the app,
 * costs no APK weight, and moves. Titles reveal word by word (60ms stagger),
 * pages slide in the direction you are going, and the one button sits in the
 * thumb zone. Skip is always available — nobody should be held hostage by a
 * tutorial.
 */

private data class Page(val kicker: String, val title: String, val body: String)

private fun pages(str: Strings): List<Page> = listOf(
    Page(str.welcome.howItWorksLabel, str.welcome.howItWorksTitle, str.welcome.howItWorksBody),
    Page(str.welcome.catchLabel, str.welcome.catchTitle, str.welcome.catchBody),
    Page(str.welcome.dataLabel, str.welcome.dataTitle, str.welcome.dataBody),
    Page(str.welcome.hardLabel, str.welcome.hardTitle, str.welcome.hardBody),
)

@Composable
fun WelcomeScreen(
    onDone: (String) -> Unit,
) {
    val haptics = rememberHaptics()
    var index by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }

    val str = strings()
    val pages = pages(str)
    val onNamePage = index == pages.size
    val accent = Mint.accent

    fun go(to: Int) {
        if (to == index) return
        Sfx.play(Sound.WHOOSH)
        haptics.tick()
        index = to
    }

    var intro by remember { mutableStateOf(true) }
    // Each page washes the paper in its own sticker colour.
    val tint by androidx.compose.animation.animateColorAsState(
        listOf(Butter.fill, Tang.fill, Sky.fill, Lilac.fill, Mint.fill)[index.coerceIn(0, 4)].copy(alpha = 0.28f),
        tween(420),
        label = "pageTint",
    )
    Box(Modifier.fillMaxSize()) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .background(tint)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 20.dp, bottom = 20.dp),
    ) {
        // Progress + Skip
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(pages.size + 1) { i ->
                    val w by animateFloatAsState(if (i == index) 1f else 0f, tween(240), label = "dot$i")
                    Box(
                        Modifier
                            .height(6.dp)
                            .width(8.dp + 22.dp * w)
                            .clip(RoundedCornerShape(50))
                            .background(if (i <= index) accent else Ink.copy(alpha = 0.10f)),
                    )
                }
            }
            if (!onNamePage) {
                Text(
                    tr("Skip", "छोड़ें"),
                    style = MaterialTheme.typography.labelLarge,
                    color = InkMid,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickableNoRipple(remember { MutableInteractionSource() }) { go(pages.size) }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        AnimatedContent(
            targetState = index,
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { it / 4 * dir } + fadeIn(tween(220))) togetherWith
                    (slideOutHorizontally(tween(200)) { -it / 4 * dir } + fadeOut(tween(160)))
            },
            modifier = Modifier
                .weight(1f)
                .pointerInput(index) {
                    // Swipe between pages, not just the button.
                    var dx = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { dx = 0f },
                        onDragEnd = {
                            val th = 70.dp.toPx()
                            if (dx < -th && index < pages.size) go(index + 1)
                            else if (dx > th && index > 0) go(index - 1)
                        },
                    ) { _, d -> dx += d }
                },
            label = "welcomePage",
        ) { i ->
            if (i == pages.size) {
                NamePage(name = name, onName = { name = it }, str = str)
            } else {
                Column(Modifier.fillMaxSize()) {
                    HeroGraphic(index = i, accent = accent)
                    Spacer(Modifier.height(20.dp))
                    Text(
                        pages[i].kicker,
                        style = MaterialTheme.typography.labelSmall,
                        letterSpacing = 1.6.sp,
                        color = accent,
                    )
                    Spacer(Modifier.height(6.dp))
                    WordReveal(pages[i].title)
                    Spacer(Modifier.height(12.dp))
                    FadeUp(delayMs = 280) {
                        Text(
                            pages[i].body,
                            style = MaterialTheme.typography.bodyLarge,
                            color = InkMid,
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // Buddy (the Focus screen's ink face) rides along the whole tour in
        // a comic speech bubble — the Regain-style mascot, drawn in this
        // app's own ink instead of a 3D render. One persistent composable,
        // so it reacts between pages instead of re-popping on each.
        BuddyBubble(
            mood = when {
                onNamePage && name.isNotBlank() -> BuddyMood.SECURED
                onNamePage -> BuddyMood.IDLE
                index == 1 -> BuddyMood.SAD
                index >= 2 -> BuddyMood.FOCUSED
                else -> BuddyMood.IDLE
            },
            line = when {
                onNamePage && name.isNotBlank() -> tr("${name.trim()}… main character energy. Let's go!", "${name.trim()}… मेन कैरेक्टर वाली वाइब। चलो!")
                onNamePage -> tr("What do I call you, legend?", "तुम्हें क्या बुलाऊँ, लेजेंड?")
                index == 0 -> tr("Yo, I'm Buddy. I keep your phone in check — no cap.", "यो, मैं Buddy। तुम्हारा फ़ोन मैं संभालूँगा — पक्का।")
                index == 1 -> tr("Reels eat hours. We're taking them back.", "रील्स घंटे खा जाती हैं। हम वापस लेंगे।")
                index == 2 -> tr("Your data stays on your phone. Not even I peek.", "तुम्हारा डेटा फ़ोन में ही रहता है। मैं भी नहीं देखता।")
                else -> tr("It gets hard on purpose. That's where the aura is.", "जानबूझकर मुश्किल है। ऑरा वहीं है।")
            },
        )

        Spacer(Modifier.height(12.dp))

        PrimaryButton(
            label = if (onNamePage) tr("Let's go →", "चलो शुरू करें →") else str.welcome.next,
            onClick = {
                if (onNamePage) {
                    haptics.confirm()
                    Sfx.play(Sound.BEGIN)
                    onDone(name.trim())
                } else go(index + 1)
            },
        )
    }
    if (intro) BrandIntro { intro = false }
    }
}

@Composable
private fun NamePage(name: String, onName: (String) -> Unit, str: Strings) {
    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(24.dp))
        Text(
            str.welcome.lastThing,
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.6.sp,
            color = Mint.accent,
        )
        Spacer(Modifier.height(6.dp))
        WordReveal(str.welcome.nameQuestion)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { onName(it.replace(Regex("[^\\p{L}\\p{N}\\s]"), "").take(18)) },
            placeholder = { Text(str.welcome.namePlaceholder) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Ink,
                unfocusedBorderColor = Ink,
                focusedContainerColor = CreamCard,
                unfocusedContainerColor = CreamCard,
            ),
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(16.dp))
        // Live preview of the greeting — the name lands with a soft crossfade.
        Column(
            Modifier
                .fillMaxWidth()
                .brutal(Lilac.fill)
                .padding(18.dp),
        ) {
            Text(str.welcome.youllSee, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(4.dp))
            AnimatedContent(
                targetState = if (name.isBlank()) str.welcome.welcomeBackAnon else str.welcome.welcomeBack(name.trim()),
                transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) },
                label = "greet",
            ) { line ->
                Text(line, style = MaterialTheme.typography.headlineSmall, color = Ink)
            }
        }
    }
}

/** Title that lands one word at a time: fade + 10dp rise, 60ms apart. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun WordReveal(text: String) {
    val words = remember(text) { text.split(" ") }
    LaunchedEffect(text) {
        words.take(6).forEachIndexed { i, _ ->
            kotlinx.coroutines.delay(if (i == 0) 40L else 60L)
            Sfx.play(Sound.TICK)
        }
    }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        words.forEachIndexed { i, w ->
            FadeUp(delayMs = 60 * i, rise = 10) {
                Text(
                    w,
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold,
                    color = Ink,
                )
            }
        }
    }
}

@Composable
internal fun FadeUp(delayMs: Int, rise: Int = 8, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(delayMs.toLong()); shown = true }
    val t by animateFloatAsState(if (shown) 1f else 0f, tween(240, easing = FastOutSlowInEasing), label = "fadeUp")
    Box(Modifier.graphicsLayer { alpha = t; translationY = (1f - t) * rise.dp.toPx() }) { content() }
}

/**
 * Neo-brutalist block: hard ink shadow offset down-right, 3dp ink outline,
 * flat fill. [press] 0..1 slides the block into its shadow.
 */
internal fun Modifier.brutal(
    fill: Color,
    radius: androidx.compose.ui.unit.Dp = Paper.CardRadius,
    shadow: androidx.compose.ui.unit.Dp = 5.dp,
    press: Float = 0f,
): Modifier = this
    .drawBehind {
        val d = shadow.toPx() * (1f - press)
        val o = shadow.toPx() * press
        drawRoundRect(
            Ink,
            topLeft = Offset(o + d, o + d),
            size = size,
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius.toPx()),
        )
    }
    .graphicsLayer {
        translationX = shadow.toPx() * press
        translationY = shadow.toPx() * press
    }
    .clip(RoundedCornerShape(radius))
    .background(fill)
    .border(Paper.Outline, Ink, RoundedCornerShape(radius))

/** The one primary action: big, thumb zone, presses into its ink shadow. */
@Composable
internal fun PrimaryButton(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val p by animateFloatAsState(if (pressed) 1f else 0f, tween(120), label = "cta")
    Box(
        Modifier
            .fillMaxWidth()
            .height(58.dp)
            .brutal(if (enabled) Mint.fill else Sunk, radius = Paper.ChipRadius, press = p)
            .clickableNoRipple(interaction, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            targetState = label,
            transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) },
            label = "ctaLabel",
        ) { l ->
            Text(l.uppercase(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, letterSpacing = 0.8.sp, color = if (enabled) Ink else InkMid)
        }
    }
}

/**
 * Shared ring + glow, with one motion idea per page:
 * 0 — the ring fills and ₹ counts up (focus is money)
 * 1 — three app tiles lock one by one (scrolling costs)
 * 2 — signal ripples that never leave the phone (stays on device)
 * 3 — a lock that clicks shut (one tap out)
 */
@Composable
private fun HeroGraphic(index: Int, accent: Color) {
    val spin = rememberInfiniteTransition(label = "spin")
    val angle by spin.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "angle")
    val glow by spin.animateFloat(0.18f, 0.34f, infiniteRepeatable(tween(2400), RepeatMode.Reverse), label = "glow")
    val fill = remember { Animatable(0f) }
    LaunchedEffect(index) {
        fill.snapTo(0f)
        if (index == 0) fill.animateTo(0.78f, tween(1400, easing = FastOutSlowInEasing))
    }

    Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(230.dp)) {
            val c = Offset(size.width / 2, size.height / 2)
            val stroke = 9.dp.toPx()
            val r = size.minDimension / 2 - stroke
            drawCircle(
                Brush.radialGradient(listOf(accent.copy(alpha = glow), Color.Transparent), c, r * 1.25f),
                r * 1.25f, c,
            )
            drawCircle(Ink, r, c, style = Stroke(stroke + 6f))
            drawCircle(Sunk, r, c, style = Stroke(stroke))
            val tl = Offset(c.x - r, c.y - r)
            val sz = Size(r * 2, r * 2)
            if (index == 0) {
                drawArc(Ink, -90f, 360f * fill.value, false, tl, sz, style = Stroke(stroke + 6f, cap = StrokeCap.Round))
                drawArc(accent, -90f, 360f * fill.value, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            } else {
                rotate(angle, c) {
                    drawArc(
                        Brush.sweepGradient(listOf(Color.Transparent, accent.copy(alpha = 0.9f), Color.Transparent), c),
                        0f, 220f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                }
            }
        }
        when (index) {
            0 -> RupeeCounter(target = 120)
            1 -> FeedDrain()
            2 -> DataDome(accent)
            else -> UrgeWave(accent)
        }
    }
}

@Composable
private fun RupeeCounter(target: Int) {
    val v = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        // Meter feel: a tick every ₹15 as it climbs, a glint when it lands.
        var lastStep = 0
        v.animateTo(target.toFloat(), tween(1400, easing = FastOutSlowInEasing)) {
            val step = (value / 15f).toInt()
            if (step > lastStep) { lastStep = step; Sfx.play(Sound.TICK) }
        }
        Sfx.play(Sound.SHIMMER)
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("₹${v.value.toInt()}", fontSize = 52.sp, fontWeight = FontWeight.Black, color = Ink)
        Text(tr("banked by studying", "पढ़ाई से जमा"), style = MaterialTheme.typography.labelSmall, color = InkMid)
    }
}

@Composable
private fun LockingTiles() {
    val tints = listOf(Candy.fill, Sky.fill, Butter.fill)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        tints.forEachIndexed { i, tint ->
            var locked by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { delay(400L + i * 280L); locked = true }
            val t by animateFloatAsState(if (locked) 1f else 0f, tween(220), label = "tile$i")
            Box(
                Modifier
                    .size(52.dp)
                    .graphicsLayer { scaleX = 1f - 0.06f * t; scaleY = 1f - 0.06f * t }
                    .brutal(lerpColor(tint, Sunk, t), radius = 14.dp, shadow = 4.dp),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.Lock,
                    contentDescription = null,
                    tint = Ink.copy(alpha = t),
                    modifier = Modifier.size(20.dp).graphicsLayer { scaleX = 0.6f + 0.4f * t; scaleY = 0.6f + 0.4f * t },
                )
            }
        }
    }
}

@Composable
private fun PhoneRipple(accent: Color) {
    val wave = rememberInfiniteTransition(label = "wave")
    val p by wave.animateFloat(0f, 1f, infiniteRepeatable(tween(2000, easing = LinearEasing)), label = "p")
    Box(contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(150.dp)) {
            listOf(p, (p + 0.5f) % 1f).forEach { q ->
                drawCircle(accent.copy(alpha = 0.35f * (1f - q)), size.minDimension / 2 * (0.35f + 0.65f * q), style = Stroke(2.dp.toPx()))
            }
        }
        Icon(Icons.Filled.PhoneAndroid, contentDescription = null, tint = Ink, modifier = Modifier.size(56.dp))
    }
}

@Composable
private fun LockSnap(accent: Color) {
    val haptics = rememberHaptics()
    var shut by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(650); shut = true; haptics.tick(); Sfx.play(Sound.SHIELD_ON) }
    val pop by animateFloatAsState(if (shut) 1f else 0.86f, tween(220, easing = FastOutSlowInEasing), label = "pop")
    AnimatedContent(
        targetState = shut,
        transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(120)) },
        label = "lock",
    ) { s ->
        Icon(
            if (s) Icons.Filled.Lock else Icons.Filled.LockOpen,
            contentDescription = null,
            tint = if (s) accent else Ink,
            modifier = Modifier.size(72.dp).graphicsLayer { scaleX = pop; scaleY = pop },
        )
    }
}

private fun lerpColor(a: Color, b: Color, t: Float) = Color(
    red = a.red + (b.red - a.red) * t,
    green = a.green + (b.green - a.green) * t,
    blue = a.blue + (b.blue - a.blue) * t,
    alpha = 1f,
)

// ======================= v4 additions (2026-10-03) ========================

/**
 * Brand moment before the pages: a ring draws itself through the progress
 * ramp, "Welcome to" rises, MOMENTUM stamps in letter by letter with a tilt,
 * the tagline lands, then the whole card lifts away. ~2.4s, tap to skip.
 */
@Composable
internal fun BrandIntro(onDone: () -> Unit) {
    val haptics = rememberHaptics()
    var t by remember { mutableFloatStateOf(0f) }
    var gone by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (t < 2700f) withFrameNanos { now -> t = (now - start) / 1_000_000f }
        if (!gone) { gone = true; onDone() }
    }
    val fired = remember { mutableSetOf<Int>() }
    SideEffect {
        fun beat(id: Int, at: Float, fn: () -> Unit) { if (t >= at && fired.add(id)) fn() }
        for (i in 0 until 8) beat(10 + i, 700f + i * 70f) { Sfx.play(Sound.TICK) }
        beat(1, 1300f) { Sfx.play(Sound.BEGIN); haptics.confirm() }
    }
    fun seg(a: Float, d: Float) = ((t - a) / d).coerceIn(0f, 1f)
    val ring = FastOutSlowInEasing.transform(seg(0f, 900f))
    val exit = FastOutSlowInEasing.transform(seg(2250f, 450f))
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = 1f - exit; translationY = -exit * 60.dp.toPx() }
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .clickableNoRipple(remember { MutableInteractionSource() }) { if (!gone) { gone = true; onDone() } },
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val st = 14.dp.toPx()
                    val tl = Offset(st, st)
                    val sz = Size(size.width - st * 2, size.height - st * 2)
                    val pc = com.momentum.focus.ui.components.progressColor(ring)
                    drawArc(Ink, -90f, 360f, false, tl, sz, style = Stroke(st + 6f))
                    drawArc(Sunk, -90f, 360f, false, tl, sz, style = Stroke(st))
                    for (k in 1..4) drawArc(pc.copy(alpha = 0.12f * (1f - k / 5f)), -90f, 360f * ring, false, tl, sz, style = Stroke(st + k * 6.dp.toPx(), cap = StrokeCap.Round))
                    drawArc(pc, -90f, 360f * ring, false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
                    val burst = seg(1300f, 500f)
                    if (burst in 0.001f..0.999f) drawCircle(pc.copy(alpha = 1f - burst), size.minDimension / 2 + 50.dp.toPx() * burst, style = Stroke(5.dp.toPx() * (1f - burst)))
                }
                Text(
                    "M",
                    fontSize = 54.sp, fontWeight = FontWeight.Black, color = Ink,
                    modifier = Modifier.graphicsLayer { val s = seg(1250f, 200f); alpha = s; scaleX = 1.6f - 0.6f * s; scaleY = scaleX },
                )
            }
            Spacer(Modifier.height(20.dp))
            Text(
                tr("Welcome to", "स्वागत है"),
                fontSize = 16.sp, fontWeight = FontWeight.Bold, color = InkMid,
                modifier = Modifier.graphicsLayer { val s = seg(450f, 260f); alpha = s; translationY = (1f - s) * 10.dp.toPx() },
            )
            Row {
                "MOMENTUM".forEachIndexed { i, ch ->
                    val s = seg(700f + i * 70f, 180f)
                    Text(
                        ch.toString(),
                        fontSize = 44.sp, fontWeight = FontWeight.Black, color = Ink,
                        modifier = Modifier.graphicsLayer {
                            alpha = s
                            val sc = if (s <= 0f) 1.8f else 1.8f - 0.8f * FastOutSlowInEasing.transform(s)
                            scaleX = sc; scaleY = sc
                            rotationZ = (if (i % 2 == 0) -6f else 6f) * (1f - s)
                            translationY = (if (i % 2 == 0) -2f else 2f).dp.toPx() * s
                        },
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                tr("Study a minute. Bank a minute.", "एक मिनट पढ़ो। एक मिनट जमा।"),
                fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Ink,
                modifier = Modifier
                    .graphicsLayer { val s = seg(1450f, 300f); alpha = s; rotationZ = -2f; scaleX = 0.9f + 0.1f * s; scaleY = scaleX }
                    .brutal(Butter.fill, radius = 8.dp, shadow = 4.dp)
                    .padding(horizontal = 10.dp, vertical = 4.dp),
            )
        }
        Text(
            tr("tap to skip", "छोड़ने के लिए टैप करें"),
            fontSize = 9.sp, color = Ink.copy(alpha = 0.3f),
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 10.dp),
        )
    }
}

/** Page 2: a feed scrolls on a phone and drains a red balance — until a lock slams on. */
@Composable
private fun FeedDrain() {
    val haptics = rememberHaptics()
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (t < 2600f) withFrameNanos { now -> t = (now - start) / 1_000_000f }
    }
    val fired = remember { mutableSetOf<Int>() }
    SideEffect {
        if (t >= 1700f && fired.add(1)) { Sfx.play(Sound.SHIELD_ON); haptics.unlock() }
    }
    val lockAt = 1700f
    val scroll = (minOf(t, lockAt) / 1000f) * 2.2f                  // feed speed, stops at the lock
    val balance = (120 - (minOf(t, lockAt) / lockAt * 74f)).toInt()   // draining
    val slam = ((t - lockAt) / 260f).coerceIn(0f, 1f)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.width(118.dp).height(196.dp)
                .brutal(CreamCard, radius = 22.dp, shadow = 5.dp)
                .padding(8.dp),
        ) {
            Canvas(Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)).background(Sunk)) {
                val cardH = 58.dp.toPx()
                val gap = 8.dp.toPx()
                val off = (scroll * (cardH + gap)) % (cardH + gap)
                val tints = listOf(Candy.fill, Sky.fill, Butter.fill, Lilac.fill)
                var y = -off
                var i = (scroll).toInt()
                while (y < size.height) {
                    drawRoundRect(tints[((i % 4) + 4) % 4], Offset(6.dp.toPx(), y + 6.dp.toPx()), Size(size.width - 12.dp.toPx(), cardH - 6.dp.toPx()), CornerRadius(8.dp.toPx()))
                    drawRoundRect(Ink.copy(alpha = 0.25f), Offset(12.dp.toPx(), y + cardH - 18.dp.toPx()), Size(size.width * 0.5f, 4.dp.toPx()), CornerRadius(2.dp.toPx()))
                    y += cardH + gap; i++
                }
                if (slam > 0f) drawRect(Ink.copy(alpha = 0.45f * slam))
            }
            if (slam > 0f) {
                Box(
                    Modifier.align(Alignment.Center).size(56.dp)
                        .graphicsLayer { val s = 1.8f - 0.8f * FastOutSlowInEasing.transform(slam); scaleX = s; scaleY = s; alpha = slam; rotationZ = -8f }
                        .brutal(Mint.fill, radius = 16.dp, shadow = 4.dp),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Lock, null, tint = Ink, modifier = Modifier.size(28.dp)) }
            }
        }
        Spacer(Modifier.width(18.dp))
        Column {
            Text(tr("WALLET", "वॉलेट"), fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.6.sp, color = InkMid)
            Text(
                "₹$balance",
                fontSize = 40.sp, fontWeight = FontWeight.Black,
                color = if (slam > 0f) Ink else Color(0xFFE5401F),
                modifier = Modifier.graphicsLayer { translationX = if (t < lockAt) kotlin.math.sin(t / 30f) * 1.5f else 0f },
            )
            Text(
                if (slam > 0f) tr("Saved.", "बच गया।") else tr("−₹1 per 3 min", "−₹1 हर 3 मिनट"),
                fontSize = 13.sp, fontWeight = FontWeight.Bold,
                color = if (slam > 0f) Mint.accent else Color(0xFFE5401F),
            )
        }
    }
}

/** Page 3: data packets try to leave the phone and bounce off a shield dome. */
@Composable
private fun DataDome(accent: Color) {
    val loop = rememberInfiniteTransition(label = "dome")
    val p by loop.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "p")
    Box(contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(190.dp)) {
            val c = center
            val r = size.minDimension / 2 - 6.dp.toPx()
            // dome
            drawCircle(accent.copy(alpha = 0.10f), r, c)
            drawCircle(Ink, r, c, style = Stroke(3.dp.toPx()))
            drawCircle(Color.White.copy(alpha = 0.6f), r - 7.dp.toPx(), c, style = Stroke(1.5.dp.toPx()))
            // packets: out to the wall, bounce back
            for (i in 0 until 6) {
                val ph = (p + i / 6f) % 1f
                val a = (i * 60f + 20f) * PI.toFloat() / 180f
                val d = (if (ph < 0.5f) ph * 2f else 2f - ph * 2f) * (r - 10.dp.toPx())
                val pos = c + Offset(kotlin.math.cos(a) * d, kotlin.math.sin(a) * d)
                drawRoundRect(accent, pos - Offset(5.dp.toPx(), 4.dp.toPx()), Size(10.dp.toPx(), 8.dp.toPx()), CornerRadius(2.dp.toPx()))
                drawRoundRect(Ink, pos - Offset(5.dp.toPx(), 4.dp.toPx()), Size(10.dp.toPx(), 8.dp.toPx()), CornerRadius(2.dp.toPx()), style = Stroke(1.5.dp.toPx()))
                val hit = 1f - kotlin.math.abs(ph - 0.5f) * 10f
                if (hit > 0f) {
                    val wall = c + Offset(kotlin.math.cos(a) * r, kotlin.math.sin(a) * r)
                    drawCircle(accent.copy(alpha = hit), 10.dp.toPx() * hit + 4.dp.toPx(), wall, style = Stroke(2.dp.toPx()))
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.PhoneAndroid, null, tint = Ink, modifier = Modifier.size(46.dp))
            Text(tr("0 bytes out", "0 बाइट बाहर"), fontSize = 11.sp, fontWeight = FontWeight.Black, color = Ink)
        }
    }
}

/** Page 4: the urge spikes, Panic is pressed, the wave decays to flat. */
@Composable
private fun UrgeWave(accent: Color) {
    val haptics = rememberHaptics()
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (t < 3200f) withFrameNanos { now -> t = (now - start) / 1_000_000f }
    }
    val fired = remember { mutableSetOf<Int>() }
    SideEffect { if (t >= 900f && fired.add(1)) { Sfx.play(Sound.POP); haptics.tick() } }
    val press = ((t - 900f) / 200f).coerceIn(0f, 1f)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.width(240.dp).height(120.dp)) {
            val n = 80
            val path = Path()
            val drawn = (t / 2600f).coerceIn(0f, 1f)
            for (k in 0..(n * drawn).toInt()) {
                val x = k / n.toFloat()
                // rise to a peak at ~0.3, then decay after the press
                val env = if (x < 0.3f) x / 0.3f else kotlin.math.exp(-(x - 0.3f) * 4.5f)
                val y = size.height * 0.5f - kotlin.math.sin(x * 38f) * env * size.height * 0.42f
                if (k == 0) path.moveTo(0f, y) else path.lineTo(x * size.width, y)
            }
            drawLine(Ink.copy(alpha = 0.15f), Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 1.5.dp.toPx())
            drawPath(path, com.momentum.focus.ui.components.progressColor((t / 2600f).coerceIn(0f, 1f)), style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
            drawPath(path, Ink.copy(alpha = 0.35f), style = Stroke(1.dp.toPx()))
        }
        Spacer(Modifier.height(10.dp))
        Text(
            tr("PANIC", "पैनिक"),
            fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp, color = Ink,
            modifier = Modifier
                .brutal(if (press > 0f) Mint.fill else Tang.fill, radius = 12.dp, shadow = 4.dp, press = if (press in 0.01f..0.99f) 1f else 0f)
                .padding(horizontal = 18.dp, vertical = 8.dp),
        )
        Text(
            if (t > 2600f) tr("Ridden out.", "निकल गया।") else tr("~10 min to peak", "~10 मिनट में चरम"),
            fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (t > 2600f) accent else InkMid,
            modifier = Modifier.padding(top = 8.dp),
        )
    }
}

/** Buddy + a comic speech bubble whose line swaps with a small pop. */
@Composable
private fun BuddyBubble(mood: BuddyMood, line: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        FocusBuddy(mood)
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier
                .weight(1f)
                .drawBehind {
                    // tail pointing at Buddy
                    val tail = androidx.compose.ui.graphics.Path().apply {
                        moveTo(0f, size.height * 0.45f)
                        lineTo(-9.dp.toPx(), size.height * 0.55f)
                        lineTo(0f, size.height * 0.68f)
                        close()
                    }
                    drawPath(tail, Ink)
                    val d = 3.dp.toPx() * com.momentum.focus.ui.theme.Vibe.shadow
                    drawRoundRect(Ink, Offset(d, d), size, androidx.compose.ui.geometry.CornerRadius(16.dp.toPx()))
                }
                .clip(RoundedCornerShape(16.dp))
                .background(CreamCard)
                .border(2.dp, Ink, RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            AnimatedContent(
                targetState = line,
                transitionSpec = {
                    (fadeIn(tween(200)) + scaleIn(tween(220), initialScale = 0.92f)) togetherWith fadeOut(tween(120))
                },
                label = "buddyLine",
            ) { l ->
                Text(l, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Ink)
            }
        }
    }
}
