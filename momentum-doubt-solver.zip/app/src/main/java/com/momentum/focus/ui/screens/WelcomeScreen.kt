package com.momentum.focus.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.momentum.focus.R
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.LiquidGlass
import com.momentum.focus.ui.components.LiquidGlassButton
import com.momentum.focus.ui.i18n.Strings
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

private data class Page(
    val kicker: String,
    val title: String,
    val body: String,
    val sticker: Sticker,
)

/**
 * Built per call rather than held in a top-level val, because the copy now
 * comes from the string table and a static list is fixed at class-init — long
 * before anyone has chosen a language.
 */
private fun pages(str: Strings): List<Page> = listOf(
    Page(
        str.welcome.howItWorksLabel,
        str.welcome.howItWorksTitle,
        str.welcome.howItWorksBody,
        Emerald,
    ),
    Page(
        str.welcome.catchLabel,
        str.welcome.catchTitle,
        str.welcome.catchBody,
        Gold,
    ),
    Page(
        str.welcome.dataLabel,
        str.welcome.dataTitle,
        str.welcome.dataBody,
        Ice,
    ),
    Page(
        str.welcome.hardLabel,
        str.welcome.hardTitle,
        str.welcome.hardBody,
        Ember,
    ),
)

@Composable
fun WelcomeScreen(
    onDone: (String) -> Unit,
) {
    val haptics = rememberHaptics()
    var index by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }

    val str = strings()
    val pages = pages(str)
    val onNamePage = index == pages.size

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 32.dp, bottom = 24.dp),
    ) {
        // Progress dots. Four steps is short enough that people finish it.
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(pages.size + 1) { i ->
                Box(
                    Modifier
                        .height(4.dp)
                        .weight(1f)
                        .clip(RoundedCornerShape(50))
                        .background(
                            if (i <= index) Mint.fill
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                )
            }
        }

        Spacer(Modifier.weight(1f))

        if (onNamePage) {
            Text(
                str.welcome.lastThing,
                style = MaterialTheme.typography.labelSmall,
                color = Lilac.on,
            )
            Text(
                str.welcome.nameQuestion,
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(18) },
                placeholder = { Text(str.welcome.namePlaceholder) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            )

            // Typing into an empty box gives no sense of what the name is for.
            // Showing the greeting as it is typed makes the field feel like it
            // is wiring something up rather than collecting a field.
            Spacer(Modifier.height(16.dp))
            LiquidGlass(
                modifier = Modifier.fillMaxWidth(),
                tint = Lilac.fill,
                radius = Paper.CardRadius,
            ) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(
                        str.welcome.youllSee,
                        style = MaterialTheme.typography.labelSmall,
                        color = InkMid,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (name.isBlank()) str.welcome.welcomeBackAnon
                        else str.welcome.welcomeBack(name.trim()),
                        style = MaterialTheme.typography.headlineSmall,
                        color = Ink,
                    )
                }
            }
        } else {
            val page = pages[index]

            // The illustration. This screen used to show none at all — four
            // slides that were a kicker, a headline and a paragraph, with
            // nothing pictorial anywhere on them. A first-run flow that is
            // meant to teach the app's shape at a glance cannot do that in
            // straight text; this draws a small scene per slide in the same
            // shadow-plus-gradient-plus-outline technique TileObject already
            // uses everywhere else in the app, so it reads as this app's own
            // art rather than a bolted-on stock icon.
            //
            // AnimatedContent rather than a hard cut on `index` changing —
            // each illustration used to just appear, mid-frame, the instant
            // the page turned. Fading the old one out while the new one
            // fades and scales in is the difference between a slideshow and
            // something that feels considered.
            AnimatedContent(
                targetState = index,
                transitionSpec = {
                    (fadeIn(tween(360)) + scaleIn(tween(360), initialScale = 0.92f))
                        .togetherWith(fadeOut(tween(200)))
                },
                label = "welcomeIllustration",
            ) { i ->
                WelcomeIllustration(index = i, tone = pages[i].sticker)
            }
            Spacer(Modifier.height(18.dp))

            // The step number sits in its own small pane so it reads as an
            // object on the page rather than a bullet in a list.
            LiquidGlass(
                modifier = Modifier.size(64.dp),
                tint = page.sticker.fill,
                radius = 20.dp,
            ) {
                Text(
                    "${index + 1}",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                )
            }
            Spacer(Modifier.height(22.dp))
            LiquidGlass(
                modifier = Modifier.fillMaxWidth(),
                tint = page.sticker.fill,
                radius = Paper.CardRadius,
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text(
                        page.kicker,
                        style = MaterialTheme.typography.labelSmall,
                        color = InkMid,
                    )
                    Text(
                        page.title,
                        style = MaterialTheme.typography.displayMedium,
                        color = Ink,
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        page.body,
                        style = MaterialTheme.typography.bodyLarge,
                        color = InkMid,
                    )
                }
            }
        }

        Spacer(Modifier.weight(1f))

        LiquidGlassButton(
            tint = if (onNamePage) Emerald.fill else Ice.fill,
            onClick = {
                haptics.confirm()
                if (onNamePage) onDone(name.trim()) else index++
            },
        ) {
            Text(
                if (onNamePage) str.welcome.start else str.welcome.next,
                style = MaterialTheme.typography.titleMedium,
                color = Ink,
            )
        }
    }
}

/**
 * One illustration per slide — timer-and-coin, a cracked phone pinned under
 * a padlock, a shield, an alert button breaking distracting apps' chains —
 * rather than four slides that only differ by their words.
 *
 * These are lit 3D renders on a near-black background, not the flat cream
 * illustration style the rest of the app draws in — dropping one straight
 * onto this cream screen would read as a hole punched in the page. A soft
 * radial glow behind each one, tinted to that slide's own sticker colour,
 * is what makes the dark square look like it is glowing on the paper rather
 * than sitting on top of it. Not the shared [Aura] composable — that one is
 * reserved for paid surfaces, and onboarding is still the free flow.
 */
@Composable
private fun WelcomeIllustration(index: Int, tone: Sticker) {
    val art = when (index) {
        0 -> R.drawable.welcome_focus_money
        1 -> R.drawable.welcome_distraction_costs
        2 -> R.drawable.welcome_data_local
        else -> R.drawable.welcome_one_tap_out
    }
    Box(
        Modifier.fillMaxWidth().height(150.dp),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.matchParentSize()) {
            val r = size.minDimension * 0.66f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(tone.fill.copy(alpha = 0.40f), Color.Transparent),
                    center = Offset(size.width / 2f, size.height / 2f),
                    radius = r,
                ),
                radius = r,
                center = Offset(size.width / 2f, size.height / 2f),
            )
        }
        Image(
            painter = painterResource(art),
            contentDescription = null,
            modifier = Modifier
                .size(140.dp)
                .clip(RoundedCornerShape(22.dp))
                .border(Paper.Outline, Ink, RoundedCornerShape(22.dp)),
            contentScale = ContentScale.Crop,
        )
    }
}
