package com.momentum.focus.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.tr
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.Strings
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay

/*
 * Onboarding, design system v2 (2026-10-03).
 *
 * The four raster cartoons are gone. Each page now has a code-drawn motion
 * graphic around one shared mint ring, so the art matches the rest of the app,
 * costs no APK weight, and moves. Titles reveal word by word (60ms stagger),
 * pages slide in the direction you are going, and the one button sits in the
 * thumb zone. Skip is always available — nobody should be held hostage by a
 * tutorial.
 */

private data class Page(val kicker: String, val title: String, val body: String)

private fun pages(str: Strings): List<Page> = listOf(
    Page(str.welcome.howItWorksLabel, str.welcome.howItWorksTitle, str.welcome.howItWorksBody),
    Page(str.welcome.catchLabel, str.welcome.catchTitle, str.welcome.catchBody),
    Page(str.welcome.dataLabel, str.welcome.dataTitle, str.welcome.dataBody),
    Page(str.welcome.hardLabel, str.welcome.hardTitle, str.welcome.hardBody),
)

@Composable
fun WelcomeScreen(
    onDone: (String) -> Unit,
) {
    val haptics = rememberHaptics()
    var index by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }

    val str = strings()
    val pages = pages(str)
    val onNamePage = index == pages.size
    val accent = Mint.accent

    fun go(to: Int) {
        if (to == index) return
        Sfx.play(Sound.WHOOSH)
        haptics.tick()
        index = to
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 20.dp, bottom = 20.dp),
    ) {
        // Progress + Skip
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(pages.size + 1) { i ->
                    val w by animateFloatAsState(if (i == index) 1f else 0f, tween(240), label = "dot$i")
                    Box(
                        Modifier
                            .height(6.dp)
                            .width(8.dp + 22.dp * w)
                            .clip(RoundedCornerShape(50))
                            .background(if (i <= index) accent else Ink.copy(alpha = 0.10f)),
                    )
                }
            }
            if (!onNamePage) {
                Text(
                    tr("Skip", "छोड़ें"),
                    style = MaterialTheme.typography.labelLarge,
                    color = InkMid,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickableNoRipple(remember { MutableInteractionSource() }) { go(pages.size) }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        AnimatedContent(
            targetState = index,
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { it / 4 * dir } + fadeIn(tween(220))) togetherWith
                    (slideOutHorizontally(tween(200)) { -it / 4 * dir } + fadeOut(tween(160)))
            },
            modifier = Modifier.weight(1f),
            label = "welcomePage",
        ) { i ->
            if (i == pages.size) {
                NamePage(name = name, onName = { name = it }, str = str)
            } else {
                Column(Modifier.fillMaxSize()) {
                    HeroGraphic(index = i, accent = accent)
                    Spacer(Modifier.height(20.dp))
                    Text(
                        pages[i].kicker,
                        style = MaterialTheme.typography.labelSmall,
                        letterSpacing = 1.6.sp,
                        color = accent,
                    )
                    Spacer(Modifier.height(6.dp))
                    WordReveal(pages[i].title)
                    Spacer(Modifier.height(12.dp))
                    FadeUp(delayMs = 280) {
                        Text(
                            pages[i].body,
                            style = MaterialTheme.typography.bodyLarge,
                            color = InkMid,
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        PrimaryButton(
            label = if (onNamePage) tr("Let's go →", "चलो शुरू करें →") else str.welcome.next,
            onClick = {
                if (onNamePage) {
                    haptics.confirm()
                    Sfx.play(Sound.BEGIN)
                    onDone(name.trim())
                } else go(index + 1)
            },
        )
    }
}

@Composable
private fun NamePage(name: String, onName: (String) -> Unit, str: Strings) {
    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(24.dp))
        Text(
            str.welcome.lastThing,
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.6.sp,
            color = Mint.accent,
        )
        Spacer(Modifier.height(6.dp))
        WordReveal(str.welcome.nameQuestion)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { onName(it.replace(Regex("[^\\p{L}\\p{N}\\s]"), "").take(18)) },
            placeholder = { Text(str.welcome.namePlaceholder) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Ink,
                unfocusedBorderColor = Ink,
                focusedContainerColor = CreamCard,
                unfocusedContainerColor = CreamCard,
            ),
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(16.dp))
        // Live preview of the greeting — the name lands with a soft crossfade.
        Column(
            Modifier
                .fillMaxWidth()
                .brutal(Lilac.fill)
                .padding(18.dp),
        ) {
            Text(str.welcome.youllSee, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(4.dp))
            AnimatedContent(
                targetState = if (name.isBlank()) str.welcome.welcomeBackAnon else str.welcome.welcomeBack(name.trim()),
                transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) },
                label = "greet",
            ) { line ->
                Text(line, style = MaterialTheme.typography.headlineSmall, color = Ink)
            }
        }
    }
}

/** Title that lands one word at a time: fade + 10dp rise, 60ms apart. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun WordReveal(text: String) {
    val words = remember(text) { text.split(" ") }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        words.forEachIndexed { i, w ->
            FadeUp(delayMs = 60 * i, rise = 10) {
                Text(
                    w,
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold,
                    color = Ink,
                )
            }
        }
    }
}

@Composable
internal fun FadeUp(delayMs: Int, rise: Int = 8, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(delayMs.toLong()); shown = true }
    val t by animateFloatAsState(if (shown) 1f else 0f, tween(240, easing = FastOutSlowInEasing), label = "fadeUp")
    Box(Modifier.graphicsLayer { alpha = t; translationY = (1f - t) * rise.dp.toPx() }) { content() }
}

/**
 * Neo-brutalist block: hard ink shadow offset down-right, 3dp ink outline,
 * flat fill. [press] 0..1 slides the block into its shadow.
 */
internal fun Modifier.brutal(
    fill: Color,
    radius: androidx.compose.ui.unit.Dp = Paper.CardRadius,
    shadow: androidx.compose.ui.unit.Dp = 5.dp,
    press: Float = 0f,
): Modifier = this
    .drawBehind {
        val d = shadow.toPx() * (1f - press)
        val o = shadow.toPx() * press
        drawRoundRect(
            Ink,
            topLeft = Offset(o + d, o + d),
            size = size,
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius.toPx()),
        )
    }
    .graphicsLayer {
        translationX = shadow.toPx() * press
        translationY = shadow.toPx() * press
    }
    .clip(RoundedCornerShape(radius))
    .background(fill)
    .border(Paper.Outline, Ink, RoundedCornerShape(radius))

/** The one primary action: big, thumb zone, presses into its ink shadow. */
@Composable
internal fun PrimaryButton(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val p by animateFloatAsState(if (pressed) 1f else 0f, tween(120), label = "cta")
    Box(
        Modifier
            .fillMaxWidth()
            .height(58.dp)
            .brutal(if (enabled) Mint.fill else Sunk, radius = Paper.ChipRadius, press = p)
            .clickableNoRipple(interaction, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            targetState = label,
            transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) },
            label = "ctaLabel",
        ) { l ->
            Text(l.uppercase(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, letterSpacing = 0.8.sp, color = if (enabled) Ink else InkMid)
        }
    }
}

/**
 * Shared ring + glow, with one motion idea per page:
 * 0 — the ring fills and ₹ counts up (focus is money)
 * 1 — three app tiles lock one by one (scrolling costs)
 * 2 — signal ripples that never leave the phone (stays on device)
 * 3 — a lock that clicks shut (one tap out)
 */
@Composable
private fun HeroGraphic(index: Int, accent: Color) {
    val spin = rememberInfiniteTransition(label = "spin")
    val angle by spin.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "angle")
    val glow by spin.animateFloat(0.18f, 0.34f, infiniteRepeatable(tween(2400), RepeatMode.Reverse), label = "glow")
    val fill = remember { Animatable(0f) }
    LaunchedEffect(index) {
        fill.snapTo(0f)
        if (index == 0) fill.animateTo(0.78f, tween(1400, easing = FastOutSlowInEasing))
    }

    Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(230.dp)) {
            val c = Offset(size.width / 2, size.height / 2)
            val stroke = 9.dp.toPx()
            val r = size.minDimension / 2 - stroke
            drawCircle(
                Brush.radialGradient(listOf(accent.copy(alpha = glow), Color.Transparent), c, r * 1.25f),
                r * 1.25f, c,
            )
            drawCircle(Ink, r, c, style = Stroke(stroke + 6f))
            drawCircle(Sunk, r, c, style = Stroke(stroke))
            val tl = Offset(c.x - r, c.y - r)
            val sz = Size(r * 2, r * 2)
            if (index == 0) {
                drawArc(Ink, -90f, 360f * fill.value, false, tl, sz, style = Stroke(stroke + 6f, cap = StrokeCap.Round))
                drawArc(accent, -90f, 360f * fill.value, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            } else {
                rotate(angle, c) {
                    drawArc(
                        Brush.sweepGradient(listOf(Color.Transparent, accent.copy(alpha = 0.9f), Color.Transparent), c),
                        0f, 220f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                }
            }
        }
        when (index) {
            0 -> RupeeCounter(target = 120)
            1 -> LockingTiles()
            2 -> PhoneRipple(accent)
            else -> LockSnap(accent)
        }
    }
}

@Composable
private fun RupeeCounter(target: Int) {
    val v = remember { Animatable(0f) }
    LaunchedEffect(Unit) { v.animateTo(target.toFloat(), tween(1400, easing = FastOutSlowInEasing)) }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("₹${v.value.toInt()}", fontSize = 52.sp, fontWeight = FontWeight.Black, color = Ink)
        Text(tr("banked by studying", "पढ़ाई से जमा"), style = MaterialTheme.typography.labelSmall, color = InkMid)
    }
}

@Composable
private fun LockingTiles() {
    val tints = listOf(Candy.fill, Sky.fill, Butter.fill)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        tints.forEachIndexed { i, tint ->
            var locked by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { delay(400L + i * 280L); locked = true }
            val t by animateFloatAsState(if (locked) 1f else 0f, tween(220), label = "tile$i")
            Box(
                Modifier
                    .size(52.dp)
                    .graphicsLayer { scaleX = 1f - 0.06f * t; scaleY = 1f - 0.06f * t }
                    .brutal(lerpColor(tint, Sunk, t), radius = 14.dp, shadow = 4.dp),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.Lock,
                    contentDescription = null,
                    tint = Ink.copy(alpha = t),
                    modifier = Modifier.size(20.dp).graphicsLayer { scaleX = 0.6f + 0.4f * t; scaleY = 0.6f + 0.4f * t },
                )
            }
        }
    }
}

@Composable
private fun PhoneRipple(accent: Color) {
    val wave = rememberInfiniteTransition(label = "wave")
    val p by wave.animateFloat(0f, 1f, infiniteRepeatable(tween(2000, easing = LinearEasing)), label = "p")
    Box(contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(150.dp)) {
            listOf(p, (p + 0.5f) % 1f).forEach { q ->
                drawCircle(accent.copy(alpha = 0.35f * (1f - q)), size.minDimension / 2 * (0.35f + 0.65f * q), style = Stroke(2.dp.toPx()))
            }
        }
        Icon(Icons.Filled.PhoneAndroid, contentDescription = null, tint = Ink, modifier = Modifier.size(56.dp))
    }
}

@Composable
private fun LockSnap(accent: Color) {
    val haptics = rememberHaptics()
    var shut by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(650); shut = true; haptics.tick(); Sfx.play(Sound.SHIELD_ON) }
    val pop by animateFloatAsState(if (shut) 1f else 0.86f, tween(220, easing = FastOutSlowInEasing), label = "pop")
    AnimatedContent(
        targetState = shut,
        transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(120)) },
        label = "lock",
    ) { s ->
        Icon(
            if (s) Icons.Filled.Lock else Icons.Filled.LockOpen,
            contentDescription = null,
            tint = if (s) accent else Ink,
            modifier = Modifier.size(72.dp).graphicsLayer { scaleX = pop; scaleY = pop },
        )
    }
}

private fun lerpColor(a: Color, b: Color, t: Float) = Color(
    red = a.red + (b.red - a.red) * t,
    green = a.green + (b.green - a.green) * t,
    blue = a.blue + (b.blue - a.blue) * t,
    alpha = 1f,
)
