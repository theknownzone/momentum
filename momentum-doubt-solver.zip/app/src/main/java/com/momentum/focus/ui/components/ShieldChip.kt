package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.InkLow
import com.momentum.focus.ui.theme.Mint

/**
 * Shield status in Home's hero, beside the bell (2026-10-07). Replaces the
 * draggable floating pill that hovered over content on every tab. Static —
 * no breathing halo — so it costs nothing per frame.
 */
@Composable
fun ShieldChip(count: Int, active: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .clip(shape)
            .background(if (active) Mint.fill.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.10f))
            .border(1.5.dp, if (active) Mint.fill else Color.White.copy(alpha = 0.18f), shape)
            .clickableNoRipple(remember { MutableInteractionSource() }) { onClick() }
            .padding(start = 9.dp, end = 11.dp, top = 7.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box {
            Icon(
                Icons.Filled.Shield,
                contentDescription = null,
                tint = if (active) Mint.fill else InkLow,
                modifier = Modifier.size(17.dp),
            )
            if (active) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(Mint.fill),
                )
            }
        }
        Spacer(Modifier.width(5.dp))
        Text(
            "$count",
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            color = if (active) CreamCard else InkLow,
        )
    }
}
