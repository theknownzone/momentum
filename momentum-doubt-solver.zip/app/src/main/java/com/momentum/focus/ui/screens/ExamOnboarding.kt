package com.momentum.focus.ui.screens

import android.app.DatePickerDialog
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.ExamCatalog
import com.momentum.focus.data.tr
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import java.time.LocalDate
import kotlin.math.roundToInt

/**
 * Exam onboarding (plans/APP_FEATURES_PLAN.md · A5): "Kaunsa exam?" → "Kab
 * hai?" → a loss-framed countdown built from the user's OWN screen-time
 * average: "Boards in 130 days. At this pace your phone eats 38 of them."
 *
 * Three short steps, each one tap. Skippable from every step (not everyone
 * has an exam). Picks go through vm.setExam, so the exam's subject pack and
 * the Sarkari-notice feed light up exactly as if it were set in Settings.
 *
 * Motion: each step slides in once (220 ms); the countdown numbers count up
 * once (700 ms). No loops.
 */
@Composable
fun ExamOnboarding(
    averageMinutes: Int,
    onPick: (name: String, epochDay: Long) -> Unit,
    onSkip: () -> Unit,
) {
    val haptics = rememberHaptics()
    var exam by remember { mutableStateOf<String?>(null) }
    var day by remember { mutableStateOf<Long?>(null) }
    val step = when { exam == null -> 0; day == null -> 1; else -> 2 }

    BackHandler(enabled = step > 0) {
        if (step == 2) day = null else exam = null
    }

    val enter = remember { Animatable(0f) }
    LaunchedEffect(step) {
        enter.snapTo(0f)
        enter.animateTo(1f, tween(220, easing = FastOutSlowInEasing))
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 20.dp, bottom = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(3) { i ->
                    Box(
                        Modifier
                            .height(6.dp)
                            .width(28.dp)
                            .clip(RoundedCornerShape(50))
                            .background(if (i <= step) Tang.fill else Sunk)
                            .border(if (i == step) 2.5.dp else 1.dp, Ink, RoundedCornerShape(50))
                    )
                }
            }
            TextButton(onClick = { haptics.tick(); onSkip() }) {
                Text(tr("No exam? Skip", "कोई एग्ज़ाम नहीं? छोड़ें"), color = InkMid)
            }
        }
        Spacer(Modifier.height(18.dp))

        Box(
            Modifier
                .weight(1f)
                .graphicsLayer {
                    alpha = enter.value
                    translationX = (1f - enter.value) * 28.dp.toPx()
                }
        ) {
            when (step) {
                0 -> PickExam { exam = it; haptics.confirm() }
                1 -> PickDate(exam!!) { day = it; haptics.confirm() }
                else -> Countdown(exam!!, day!!, averageMinutes)
            }
        }

        if (step == 2) {
            SquishButton(
                label = tr("Lock in for ${exam!!}", "${exam!!} के लिए लॉक इन"),
                sticker = Tang,
                modifier = Modifier.fillMaxWidth(),
            ) {
                haptics.confirm()
                onPick(exam!!, day!!)
            }
        }
    }
}

private val QUICK = listOf("CBSE Class 12", "CBSE Class 10", "JEE Main", "NEET UG", "SSC CGL", "REET", "UPSC CSE", "RRB NTPC")

@Composable
private fun PickExam(onPick: (String) -> Unit) {
    val context = LocalContext.current
    val all = remember { ExamCatalog.bundled(context) }
    var query by remember { mutableStateOf("") }

    Column(Modifier.verticalScroll(rememberScrollState())) {
        Text(tr("ONE QUICK THING", "बस एक बात"), style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Text(tr("Which exam are you fighting for?", "किस एग्ज़ाम की तैयारी है?"), style = MaterialTheme.typography.displayMedium, color = Ink)
        Spacer(Modifier.height(16.dp))

        // Quick picks: 2-column keycaps, the common ones one tap away.
        QUICK.chunked(2).forEachIndexed { row, pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEachIndexed { i, name ->
                    val st = StickerCycle[(row * 2 + i) % StickerCycle.size]
                    SquishButton(label = name, sticker = st, modifier = Modifier.weight(1f)) { onPick(name) }
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text(tr("Other exam? Search…", "दूसरा एग्ज़ाम? खोजें…"), color = InkLow) },
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Ink, unfocusedBorderColor = Ink,
                focusedContainerColor = CreamCard, unfocusedContainerColor = CreamCard,
                focusedTextColor = Ink, unfocusedTextColor = Ink,
            ),
            modifier = Modifier.fillMaxWidth(),
        )
        if (query.isNotBlank()) {
            val hits = remember(query, all) { ExamCatalog.search(all, query).take(20) }
            LazyColumn(Modifier.heightIn(max = 220.dp).padding(top = 8.dp)) {
                items(hits, key = { it.id }) { e ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onPick(e.name) }
                            .padding(horizontal = 10.dp, vertical = 12.dp)
                    ) {
                        Text(e.name, style = MaterialTheme.typography.titleMedium, color = Ink, modifier = Modifier.weight(1f))
                        Text(e.regionLabel, style = MaterialTheme.typography.bodySmall, color = InkMid)
                    }
                }
            }
        }
    }
}

@Composable
private fun PickDate(exam: String, onPick: (Long) -> Unit) {
    val context = LocalContext.current
    val today = remember { LocalDate.now() }
    val options = listOf(
        tr("1 month", "1 महीना") to 30L,
        tr("2 months", "2 महीने") to 60L,
        tr("3 months", "3 महीने") to 90L,
        tr("6 months", "6 महीने") to 182L,
        tr("1 year", "1 साल") to 365L,
    )
    Column {
        Text(exam.uppercase(), style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Text(tr("How far away is it?", "कितने दूर है?"), style = MaterialTheme.typography.displayMedium, color = Ink)
        Spacer(Modifier.height(6.dp))
        Text(tr("Rough is fine — change it anytime in Settings.", "अंदाज़ा काफ़ी है — Settings में कभी भी बदलो।"),
            style = MaterialTheme.typography.bodyMedium, color = InkMid)
        Spacer(Modifier.height(16.dp))
        options.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { (label, days) ->
                    SquishButton(label = label, sticker = Butter, modifier = Modifier.weight(1f)) {
                        onPick(today.toEpochDay() + days)
                    }
                }
                if (pair.size == 1) {
                    SquishButton(label = tr("Exact date", "सही तारीख़"), sticker = Sky, modifier = Modifier.weight(1f)) {
                        val start = today.plusDays(90)
                        DatePickerDialog(
                            context,
                            { _, y, m, d -> onPick(LocalDate.of(y, m + 1, d).toEpochDay()) },
                            start.year, start.monthValue - 1, start.dayOfMonth,
                        ).apply {
                            datePicker.minDate = System.currentTimeMillis()
                        }.show()
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun Countdown(exam: String, epochDay: Long, averageMinutes: Int) {
    val left = (epochDay - LocalDate.now().toEpochDay()).toInt().coerceAtLeast(0)
    // Days the phone takes out of that window at the current daily average.
    val eaten = (averageMinutes.toFloat() * left / 1440f).roundToInt()
    val count = remember { Animatable(0f) }
    LaunchedEffect(left) { count.animateTo(1f, tween(700, easing = FastOutSlowInEasing)) }

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Spacer(Modifier.height(12.dp))
        Text(exam.uppercase(), style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Text("${(left * count.value).roundToInt()}", style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Black, color = Ink)
        Text(tr("days left", "दिन बाकी"), style = MaterialTheme.typography.titleMedium, color = InkMid)

        if (averageMinutes > 0 && eaten > 0) {
            Spacer(Modifier.height(24.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .background(Tang.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(tr("AT YOUR CURRENT PACE", "अभी की रफ़्तार से"), style = MaterialTheme.typography.labelSmall, color = Tang.on)
                Text(
                    tr("your phone eats ${(eaten * count.value).roundToInt()} of them", "फ़ोन इनमें से ${(eaten * count.value).roundToInt()} दिन खा जाएगा"),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    color = Tang.on,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    tr("${averageMinutes / 60}h ${averageMinutes % 60}m a day, every day till the exam.",
                        "रोज़ ${averageMinutes / 60}h ${averageMinutes % 60}m, एग्ज़ाम तक हर दिन।"),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.on.copy(alpha = 0.8f),
                )
            }
            Spacer(Modifier.height(14.dp))
            Text(
                tr("Win back even half and that's ${eaten / 2} extra study days.", "आधा भी वापस लो तो ${eaten / 2} दिन ज़्यादा पढ़ाई।"),
                style = MaterialTheme.typography.titleMedium,
                color = Mint.accent,
            )
        }
    }
}
