package com.momentum.focus.ui.components

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import com.momentum.focus.ui.util.Sfx
import java.util.Locale

/**
 * "Welcome to Crown Mode." — owner: the voice didn't play in v3.
 *
 * Why it failed: the TTS engine was created when the cinematic started and
 * spoken ~2.5 s later. First-time engine init on many phones takes longer
 * than that, so speak() hit a null engine and the line was silently dropped.
 *
 * Now: warmed up when the Crown brief opens (the user is reading / holding
 * for seconds anyway), kept on the app context, and if it still isn't ready
 * at the beat the line is queued and spoken the moment it is. Falls back to
 * generic English if the US voice data isn't installed. Respects sound off.
 */
object CrownVoice {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var pending: String? = null

    fun warm(context: Context) {
        if (tts != null) return
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status != TextToSpeech.SUCCESS) return@TextToSpeech
            val engine = tts ?: return@TextToSpeech
            val r = engine.setLanguage(Locale.US)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                engine.setLanguage(Locale.ENGLISH)
            }
            engine.setPitch(0.85f)
            engine.setSpeechRate(0.9f)
            ready = true
            pending?.let { say(it) }
            pending = null
        }
    }

    fun speak(context: Context, line: String) {
        if (!Sfx.enabled) return
        warm(context)
        if (ready) say(line) else pending = line
    }

    /** Drop a queued line (cinematic closed before the engine was ready). */
    fun cancelPending() { pending = null }

    private fun say(line: String) {
        runCatching {
            tts?.speak(line, TextToSpeech.QUEUE_FLUSH, Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1f) }, "crown")
        }
    }
}
