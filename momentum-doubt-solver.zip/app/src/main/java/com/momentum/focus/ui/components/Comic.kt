package com.momentum.focus.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.drawscope.rotate
import com.momentum.focus.ui.theme.*
import androidx.compose.ui.graphics.drawscope.withTransform
import kotlinx.coroutines.delay
import kotlin.math.*

// ============================================================================
// Comic UI primitives — halftones, starbursts, speed lines, ink shadows.
//
// The current paperGrain + Ink border is the right foundation, but a comic
// is defined by its *secondary* marks: the dots behind a flat colour, the
// burst around a surprise, the lines that say something is moving. These
// are those marks, kept separable so any screen can pick up exactly the
// ones it needs without inheriting a whole comic skin it isn't using.
// ============================================================================

/**
 * The classic Ben-Day dot screen. A flat colour reads as printed ink; the
 * dots on top read as the same ink applied with a cheaper screen, which is
 * exactly the visual shorthand comic books use for "this is a tone, not a
 * photograph."
 *
 * Drawn as a pattern rather than a bitmap so it stays sharp at every density.
 *
 * @param dotSize   centre-to-centre spacing. 4dp is tight, 8dp is loose.
 * @param tint      the ink colour the dots are printed in.
 * @param coverage  0f = transparent, 1f = solid halftone.
 */
fun Modifier.halftone(
    dotSize: Float = 6f,
    tint: Color = Ink,
    coverage: Float = 0.35f,
): Modifier = drawBehind {
    val dotPx = dotSize * density
    val r = dotPx * 0.34f
    val yStep = dotPx * 0.866f
    var rowY = 0f
    var evenRow = true
    while (rowY < size.height + yStep) {
        var colX = if (evenRow) 0f else dotPx * 0.5f
        while (colX < size.width + dotPx) {
            drawCircle(
                color = tint.copy(alpha = coverage),
                radius = r,
                center = Offset(colX, rowY),
            )
            colX += dotPx
        }
        rowY += yStep
        evenRow = !evenRow
    }
}

/**
 * A panel border with a deliberately imperfect ink edge.
 *
 * Smooth RoundedCornerShape reads as vector-perfect, which is the opposite
 * of hand-printed. This adds a ~1.5px wobble to the stroke path so the
 * line looks like it came from a brush, not a CAD tool.
 *
 * Kept as an overlay rather than a replacement shape so the clipped content
 * stays clean and only the border carries the imperfection.
 */
fun Modifier.inkBorder(
    color: Color = Ink,
    width: Float = Paper.Outline.value,
    corner: Float = Paper.CardRadius.value,
    wobble: Float = 0.7f,
): Modifier = drawBehind {
    val w = size.width
    val h = size.height
    val c = corner * density
    val stroke = width * density

    fun roughly(from: Offset, to: Offset) {
        val dx = to.x - from.x
        val dy = to.y - from.y
        val len = sqrt(dx * dx + dy * dy)
        val segs = (len / 12f).toInt().coerceAtLeast(3)
        val rng = kotlin.random.Random((from.x * 73 + from.y * 19).toInt())

        val path = Path().apply {
            moveTo(from.x, from.y)
            repeat(segs) { i ->
                val t = (i + 1) / segs.toFloat()
                val base = Offset(from.x + dx * t, from.y + dy * t)
                val offX = if (i < segs - 1) (rng.nextFloat() - 0.5f) * wobble * density else 0f
                val offY = if (i < segs - 1) (rng.nextFloat() - 0.5f) * wobble * density else 0f
                lineTo(base.x + offX, base.y + offY)
            }
        }
        drawPath(path, color, style = Stroke(stroke, cap = StrokeCap.Round))
    }

    // Four sides with rounded corners implied by starting inset.
    roughly(Offset(c, 0f), Offset(w - c, 0f))
    roughly(Offset(w, c), Offset(w, h - c))
    roughly(Offset(w - c, h), Offset(c, h))
    roughly(Offset(0f, h - c), Offset(0f, c))
}

/**
 * The hard drop shadow every comic panel carries — a flat duplicate, offset
 * down and right, with no blur at all. A Gaussian shadow reads as digital;
 * this reads as ink on a separate pass.
 */
fun Modifier.comicShadow(
    color: Color = Ink,
    offset: Float = 4f,
): Modifier = drawBehind {
    val d = offset * density
    drawRect(
        color = color,
        topLeft = Offset(d, d),
        size = size,
    )
}

/**
 * A radial burst of lines behind something — the comic shorthand for
 * "look here". Used for level-up celebrations, achievement unlocks, and
 * anywhere a sticker alone is not enough excitement.
 *
 * Drawn as lines, not a bitmap, so it can animate its rotation forever
 * without pixels degrading.
 *
 * @param spokeCount  how many rays. 24 is dense, 12 is sparse.
 * @param innerGap    dead zone in the centre so text on top stays clean.
 */
@Composable
fun Starburst(
    modifier: Modifier = Modifier,
    spokeCount: Int = 20,
    innerGap: Float = 32f,
    tint: Color = Tang.fill,
) {
    val rotation by rememberInfiniteTransition(label = "burst").animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(
            tween(24_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "spin",
    )
    Canvas(modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val outer = min(cx, cy) * 1.15f
        val inner = innerGap * density

        rotate(rotation, pivot = Offset(cx, cy)) {
            repeat(spokeCount) { i ->
                val a = (i / spokeCount.toFloat()) * 2f * PI.toFloat()
                val x0 = cx + cos(a) * inner
                val y0 = cy + sin(a) * inner
                val x1 = cx + cos(a) * outer
                val y1 = cy + sin(a) * outer
                drawLine(tint, Offset(x0, y0), Offset(x1, y1), strokeWidth = 2.5f * density)
            }
        }
    }
}

/**
 * Horizontal speed lines that say "this button is arriving" or "this card
 * just slid in". A light version goes behind content; a heavy one replaces
 * a background.
 *
 * @param direction  1f = left-to-right, -1f = right-to-left.
 * @param thickness  line width in dp. 2f is subtle, 5f is bold.
 */
fun Modifier.speedLines(
    direction: Float = 1f,
    tint: Color = Ink.copy(alpha = 0.08f),
    thickness: Float = 2.5f,
    spacing: Float = 18f,
    skew: Float = 0.3f,
): Modifier = drawBehind {
    val step = spacing * density
    val thick = thickness * density
    var y = -size.height * skew
    val dx = size.width * direction
    while (y < size.height * (1f + skew)) {
        drawLine(
            tint,
            Offset(if (direction > 0) 0f else size.width, y),
            Offset(if (direction > 0) dx else 0f, y + size.height * skew),
            strokeWidth = thick,
        )
        y += step
    }
}

/**
 * A speech balloon with a hand-drawn feel. The tail is a small triangle
 * that roughly points; making it mathematically exact is what makes it
 * read as clip-art rather than ink.
 *
 * Used for the first-run tutorial tips, nudges, and any inline help.
 */
@Composable
fun SpeechBubble(
    text: String,
    sticker: Sticker = Butter,
    tailAt: Alignment = Alignment.BottomCenter,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(sticker.fill)
            .inkBorder(color = Ink, corner = Paper.CardRadius.value)
            // Halftone inside the balloon, lighter than a full panel.
            .halftone(dotSize = 5f, tint = sticker.on, coverage = 0.12f)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            color = sticker.on,
            textAlign = TextAlign.Center,
        )
    }
}

/**
 * A "POW!" burst that scales in with a spring and holds for a moment.
 * Fired once on level-up, streak milestone, or premium unlock.
 *
 * This is the one component that directly runs its own animation; every
 * other comic mark here is static or infinite-rotating so the caller
 * decides when it fires.
 */
@Composable
fun PowBurst(
    visible: Boolean,
    word: String = "LEVEL UP!",
    onDone: () -> Unit = {},
) {
    val scale by animateFloatAsState(
        if (visible) 1f else 0f,
        spring(dampingRatio = 0.45f, stiffness = 280f),
        label = "pow",
    )
    val alpha by animateFloatAsState(
        if (visible) 1f else 0f,
        tween(if (visible) 180 else 600),
        label = "pow-fade",
    )

    LaunchedEffect(visible) {
        if (visible) {
            delay(1_800)
            onDone()
        }
    }

    if (alpha <= 0f) return

    Box(
        Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    this.alpha = alpha
                }
                .size(240.dp),
        ) {
            // Jagged star shape behind the word.
            Canvas(Modifier.fillMaxSize()) {
                val spikes = 12
                val path = Path()
                val cx = size.width / 2f
                val cy = size.height / 2f
                val outerR = min(cx, cy) * 0.95f
                val innerR = outerR * 0.55f
                repeat(spikes * 2) { i ->
                    val r = if (i % 2 == 0) outerR else innerR
                    val a = (i / (spikes * 2f)) * 2f * PI.toFloat() - PI / 2f
                    val x = cx + cos(a) * r
                    val y = cy + sin(a) * r
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                drawPath(path, Tang.fill)
                drawPath(path, Ink, style = Stroke(4f * density, cap = StrokeCap.Round))
                // Halftone fills the star body at low density.
                val dotPx = 5f * density
                val r = dotPx * 0.34f
                var rowY = 0f
                var even = true
                val yStep = dotPx * 0.866f
                while (rowY < size.height + yStep) {
                    var colX = if (even) 0f else dotPx * 0.5f
                    while (colX < size.width + dotPx) {
                        if (path.contains(Offset(colX, rowY))) {
                            drawCircle(
                                Ink.copy(alpha = 0.25f), r, center = Offset(colX, rowY),
                            )
                        }
                        colX += dotPx
                    }
                    rowY += yStep
                    even = !even
                }
            }
            Text(
                word,
                Modifier.align(Alignment.Center),
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontSize = 28.sp,
                    letterSpacing = (-1.2).sp,
                ),
                color = Tang.on,
                textAlign = TextAlign.Center,
            )
        }
    }
}

/**
 * The jagged torn edge at the bottom of a receipt or a "clipped" coupon.
 * Extends [Receipt.tornEdge] into a reusable modifier.
 *
 * @param peak    height of each zigzag tooth in dp.
 * @param period  width of each tooth in dp.
 */
fun Modifier.tornEdge(
    edge: Edge = Edge.BOTTOM,
    peak: Float = 12f,
    period: Float = 22f,
): Modifier = drawWithContent {
    drawContent()
    val p = Path()
    val h = size.height
    val w = size.width
    val toothH = peak * density
    val toothW = period * density

    when (edge) {
        Edge.BOTTOM -> {
            p.moveTo(0f, h)
            var x = 0f
            var up = true
            while (x < w) {
                x += toothW
                p.lineTo(x.coerceAtMost(w), if (up) h - toothH else h)
                up = !up
            }
            p.lineTo(w, h)
            p.lineTo(0f, h)
        }
        Edge.TOP -> {
            p.moveTo(0f, 0f)
            var x = 0f
            var down = true
            while (x < w) {
                x += toothW
                p.lineTo(x.coerceAtMost(w), if (down) toothH else 0f)
                down = !down
            }
            p.lineTo(w, 0f)
            p.lineTo(0f, 0f)
        }
        else -> { /* left/right not implemented */ }
    }
    drawPath(p, Color.Transparent, blendMode = BlendMode.Clear)
}

enum class Edge { TOP, BOTTOM, START, END }

/**
 * A total surface wrapper: paper grain, hard shadow, ink border, and
 * optional halftone fill. The fastest way to turn any plain Compose
 * layout into a comic panel.
 */
@Composable
fun ComicPanel(
    modifier: Modifier = Modifier,
    sticker: Sticker? = null,
    shadow: Boolean = true,
    halftone: Boolean = false,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier
            .then(if (shadow) Modifier.comicShadow() else Modifier)
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(sticker?.fill ?: CreamCard)
            .then(if (halftone) Modifier.halftone(tint = sticker?.on ?: Ink) else Modifier)
            .inkBorder()
            .padding(Paper.ScreenPad - Paper.Outline),
        contentAlignment = Alignment.TopStart,
        content = content,
    )
}
