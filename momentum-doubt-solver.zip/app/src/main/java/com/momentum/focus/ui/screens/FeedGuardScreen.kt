package com.momentum.focus.ui.screens

import com.momentum.focus.data.tr
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.Icon
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.RepeatMode
import com.momentum.focus.ui.components.BackPill
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import android.content.Intent
import android.provider.Settings
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.momentum.focus.data.AppData
import com.momentum.focus.data.FeedSurfaces
import com.momentum.focus.ui.components.AppMark
import com.momentum.focus.ui.components.PillToggle
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.rememberHaptics

/**
 * The feeds inside apps you still need.
 *
 * Kept apart from the blocklist on purpose: that screen answers "which apps
 * are off", this one answers "which parts of an app are off". Mixing them made
 * the second question invisible, and the second question is the one most
 * people actually came for.
 */
@Composable
fun FeedGuardScreen(
    data: AppData,
    onToggleSurface: (String) -> Unit,
    onDone: () -> Unit,
    onStudyOnly: (Boolean) -> Unit = {},
    onAddChannel: (String) -> Unit = {},
    onRemoveChannel: (String) -> Unit = {},
) {
    val str = strings()
    var newChannel by remember { mutableStateOf("") }
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val owner = LocalLifecycleOwner.current

    var refresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) refresh++
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val guardOn = remember(refresh) { Perms.isShortsGuardOn(context) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 24.dp),
    ) {
        BackPill(onBack = onDone)
        Spacer(Modifier.height(14.dp))
        Text(
            str.feedGuard.feeds.uppercase(),
            fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.6.sp, color = Ink,
            modifier = Modifier.graphicsLayer { rotationZ = -2f }
                .clip(RoundedCornerShape(6.dp)).background(Tang.fill)
                .border(2.dp, Ink, RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 2.dp),
        )
        Spacer(Modifier.height(10.dp))
        Text(
            str.feedGuard.title,
            fontSize = 38.sp, lineHeight = 40.sp, fontWeight = FontWeight.Black, letterSpacing = (-1).sp,
            color = Ink,
        )
        Text(
            str.feedGuard.body,
            fontSize = 15.sp, lineHeight = 21.sp,
            color = Ink.copy(alpha = 0.62f),
            modifier = Modifier.padding(top = 8.dp),
        )

        Spacer(Modifier.height(18.dp))

        // Setup / how-it-works (owner: "instructions acche nahi"). Off: three
        // numbered steps, each with its own button, the greyed-switch fix
        // inline. On: what each switch does in one line + a "test it now".
        GuardGuide(guardOn, studyOnly = data.studyOnlyYouTube)
        Spacer(Modifier.height(16.dp))

        FeedSurfaces.all.groupBy { it.app }.forEach { (app, surfaces) ->
            // Mark, then name, at title weight.
            //
            // This was the app name in labelSmall with wide tracking, in the
            // muted variant colour — so on the dark themes the one word telling
            // you which switches belong to which app was the faintest thing on
            // the screen, and it sat above its group looking like a caption for
            // the group before it. A shape is recognised before a word is read;
            // the name beside it at full contrast does the rest.
            Row(
                Modifier.padding(bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AppMark(app)
                Spacer(Modifier.width(8.dp))
                Text(
                    app,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
            surfaces.forEach { s ->
                val on = s.key in data.blockedSurfaces
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(CreamCard)
                        .background(if (on) Brush.horizontalGradient(listOf(Mint.fill.copy(alpha = 0.55f), Mint.fill.copy(alpha = 0.12f))) else Brush.horizontalGradient(listOf(CreamCard, CreamCard)))
                        .border(2.5.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onToggleSurface(s.key)
                        }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(s.label, fontSize = 17.sp, fontWeight = FontWeight.Black, color = Ink)
                        Text(s.note, fontSize = 13.sp, color = Ink.copy(alpha = 0.58f))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        val knob by animateFloatAsState(if (on) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 520f), label = "sw${s.key}")
                        Box(
                            Modifier.size(52.dp, 30.dp).clip(RoundedCornerShape(999.dp))
                                .background(androidx.compose.ui.graphics.lerp(Color(0xFFE4DFCF), Mint.accent, knob))
                                .border(2.dp, Ink, RoundedCornerShape(999.dp)).padding(3.dp),
                        ) {
                            Box(
                                Modifier.offset(x = 22.dp * knob).size(24.dp).clip(CircleShape).background(Color.White).border(2.dp, Ink, CircleShape),
                                contentAlignment = Alignment.Center,
                            ) {
                                if (knob > 0.5f) Icon(Icons.Filled.Lock, null, tint = Ink, modifier = Modifier.size(12.dp))
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (on) str.feedGuard.blockedLabel else str.feedGuard.runningLabel,
                            fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp,
                            color = if (on) Mint.on else Ink.copy(alpha = 0.45f),
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        // Only worth saying when it is actually true. This used to sit here
        // permanently, so it read as "do this after every update" — which is
        // wrong, and is exactly the kind of standing instruction people learn
        // to ignore. The guard being off is the only time it matters.
        if (!guardOn) {
            Text(
                str.feedGuard.reToggleTitle,
                style = MaterialTheme.typography.headlineSmall,
                color = Ink,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                str.feedGuard.reToggleBody,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
        }

        Spacer(Modifier.height(20.dp))

        // Deliberately a watch-page check, not a feed overlay. Blurring rows in
        // a scrolling feed means chasing them as they move, and the lag flashes
        // the very video being hidden. Catching the video when it opens is a
        // single state change, which is why the rest of this guard is reliable.
        Text(str.feedGuard.studyOnly, style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(Mint.fill.lit())
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    str.feedGuard.studyOnlyTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = Mint.on,
                )
                Text(
                    str.feedGuard.studyOnlyBody,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mint.on.copy(alpha = 0.8f),
                )
            }
            PillToggle(
                checked = data.studyOnlyYouTube,
                onCheckedChange = { onStudyOnly(it) },
            )
        }

        if (data.studyOnlyYouTube) {
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = newChannel,
                    onValueChange = { newChannel = it.take(30) },
                    placeholder = { Text(str.feedGuard.channelNameHint) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Mint.fill)
                        .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            if (newChannel.isNotBlank()) {
                                haptics.tap(); onAddChannel(newChannel); newChannel = ""
                            }
                        }
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                ) {
                    Text(
                        str.feedGuard.add,
                        style = MaterialTheme.typography.titleMedium,
                        color = Mint.on,
                    )
                }
            }

            if (data.allowedChannels.isEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    str.feedGuard.noChannels,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }

            data.allowedChannels.sorted().forEach { c ->
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(Paper.ChipRadius))
                        .background(CreamCard)
                        .border(2.dp, Ink, RoundedCornerShape(Paper.ChipRadius))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(c, style = MaterialTheme.typography.bodyLarge, color = Ink, modifier = Modifier.weight(1f))
                    Text(
                        str.feedGuard.remove,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Tang.accent,
                        modifier = Modifier
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tap(); onRemoveChannel(c)
                            }
                            .padding(4.dp),
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                str.feedGuard.handleHint,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Spacer(Modifier.height(20.dp))

        Text(
            str.feedGuard.footnote,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(16.dp))

        SquishButton(
            label = str.feedGuard.done,
            sticker = Emerald,
            modifier = Modifier.fillMaxWidth(),
        ) { haptics.confirm(); onDone() }
    }
}

@Composable
private fun GuardGuide(guardOn: Boolean, studyOnly: Boolean) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    fun go(i: Intent) { haptics.tick(); runCatching { context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    val shape = RoundedCornerShape(Paper.CardRadius)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (guardOn) Mint.fill.copy(alpha = 0.35f) else Tang.fill)
            .border(Paper.Outline, Ink, shape)
            .padding(16.dp)
    ) {
        Text(
            if (guardOn) tr("GUARD IS ON", "गार्ड चालू है") else tr("GUARD IS OFF — 3 STEPS", "गार्ड बंद है — 3 स्टेप"),
            fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp, color = Ink,
        )
        Spacer(Modifier.height(8.dp))
        if (!guardOn) {
            val steps = listOf(
                Triple(
                    tr("Open Accessibility", "Accessibility खोलो"),
                    tr("Installed apps → Momentum → turn ON → Allow.", "Installed apps → Momentum → ON → Allow."),
                    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
                ),
                Triple(
                    tr("Switch greyed out?", "स्विच धुंधला है?"),
                    tr("App info → ⋮ (top right) → Allow restricted settings. Then step 1 again.", "App info → ⋮ (ऊपर दाएँ) → Allow restricted settings. फिर स्टेप 1।"),
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:${context.packageName}")),
                ),
                Triple(
                    tr("Come back here", "यहाँ वापस आओ"),
                    tr("This card turns green when it worked.", "काम हुआ तो ये कार्ड हरा हो जाएगा।"),
                    null,
                ),
            )
            steps.forEachIndexed { i, (title, body, intent) ->
                Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
                    Box(Modifier.size(26.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
                        Text("${i + 1}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Butter.fill)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, fontSize = 15.sp, fontWeight = FontWeight.Black, color = Tang.on)
                        Text(body, fontSize = 13.sp, lineHeight = 18.sp, color = Tang.on.copy(alpha = 0.85f))
                        if (intent != null) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                tr("Open →", "खोलो →"), fontSize = 12.sp, fontWeight = FontWeight.Black, color = Tang.fill,
                                modifier = Modifier.clip(RoundedCornerShape(999.dp)).background(Ink)
                                    .clickableNoRipple(remember { MutableInteractionSource() }) { go(intent) }
                                    .padding(horizontal = 12.dp, vertical = 5.dp),
                            )
                        }
                    }
                }
            }
        } else {
            val rows = listOf(
                tr("BLOCKED feeds bounce you out the moment they open.", "BLOCKED फ़ीड खुलते ही बाहर कर देती है।"),
                tr("Chat, search and your own profile keep working.", "चैट, सर्च और प्रोफ़ाइल चलते रहते हैं।"),
                if (studyOnly) tr("Study-only YouTube: lectures are spotted automatically (PW, Unacademy, “chapter”, “one shot”…). Everything else is shut.",
                                  "Study-only YouTube: लेक्चर अपने आप पहचाने जाते हैं (PW, Unacademy, “chapter”, “one shot”…)। बाकी सब बंद।")
                else tr("Want YouTube for lectures only? Turn on Study-only below.", "YouTube सिर्फ़ लेक्चर के लिए? नीचे Study-only ON करो।"),
            )
            rows.forEach { r ->
                Row(Modifier.padding(vertical = 3.dp)) {
                    Text("•", fontWeight = FontWeight.Black, color = Ink)
                    Spacer(Modifier.width(8.dp))
                    Text(r, fontSize = 13.sp, lineHeight = 18.sp, color = Ink)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                tr("Test it: open Instagram Reels →", "टेस्ट करो: Instagram Reels खोलो →"),
                fontSize = 12.sp, fontWeight = FontWeight.Black, color = Mint.fill,
                modifier = Modifier.clip(RoundedCornerShape(999.dp)).background(Ink)
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        context.packageManager.getLaunchIntentForPackage("com.instagram.android")?.let { go(it) }
                    }
                    .padding(horizontal = 12.dp, vertical = 5.dp),
            )
        }
    }
}
