package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.tr
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

/**
 * Quick modes (Opal's scene cards, redrawn in our paper style): three named
 * presets with a tiny drawn scene — no photos, no network, ~0 cost. A tap
 * sets the timer length; Start stays the user's own tap. Selected card gets
 * the hard ink shadow. Static drawings, no animation.
 */
@Composable
fun QuickModes(current: Int, onPick: (Int) -> Unit) {
    val haptics = rememberHaptics()
    data class Mode(val name: String, val sub: String, val minutes: Int, val sky: Color, val ground: Color, val kind: Int)
    val modes = listOf(
        Mode(tr("Sprint", "स्प्रिंट"), "25m", 25, Color(0xFFFFE6A8), Color(0xFFFF8A5C), 0),
        Mode(tr("Deep work", "गहरा काम"), "90m", 90, Color(0xFFCFE9FF), Color(0xFF7FD4FF), 1),
        Mode(tr("Touch grass", "घास छुओ"), "2h", 120, Color(0xFFE6F7D9), Color(0xFF3FE28F), 2),
    )
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        modes.forEach { m ->
            val sel = current == m.minutes
            val shape = RoundedCornerShape(16.dp)
            Column(
                Modifier
                    .width(118.dp)
                    .then(if (sel) Modifier.padding(end = 3.dp, bottom = 3.dp) else Modifier)
                    .clip(shape)
                    .background(CreamCard)
                    .border(if (sel) 3.dp else 2.dp, Ink, shape)
                    .clickableNoRipple(remember { MutableInteractionSource() }) { haptics.tick(); onPick(m.minutes) }
            ) {
                Canvas(Modifier.fillMaxWidth().height(58.dp)) {
                    drawRect(Brush.verticalGradient(listOf(m.sky, Color.White)))
                    val w = size.width; val h = size.height
                    when (m.kind) {
                        0 -> { // sun + speed lines
                            drawCircle(m.ground, h * 0.22f, Offset(w * 0.72f, h * 0.42f))
                            drawCircle(Ink, h * 0.22f, Offset(w * 0.72f, h * 0.42f), style = Stroke(2.dp.toPx()))
                            repeat(3) { i -> drawLine(Ink, Offset(w * 0.12f, h * (0.3f + i * 0.18f)), Offset(w * (0.42f - i * 0.06f), h * (0.3f + i * 0.18f)), 2.dp.toPx()) }
                        }
                        1 -> { // mountain
                            val p = Path().apply { moveTo(0f, h); lineTo(w * 0.38f, h * 0.25f); lineTo(w * 0.6f, h * 0.6f); lineTo(w * 0.75f, h * 0.4f); lineTo(w, h); close() }
                            drawPath(p, m.ground); drawPath(p, Ink, style = Stroke(2.dp.toPx()))
                        }
                        else -> { // hill + tree
                            drawCircle(m.ground, w * 0.6f, Offset(w * 0.5f, h * 1.45f))
                            drawCircle(Ink, w * 0.6f, Offset(w * 0.5f, h * 1.45f), style = Stroke(2.dp.toPx()))
                            drawLine(Ink, Offset(w * 0.7f, h * 0.9f), Offset(w * 0.7f, h * 0.55f), 2.dp.toPx())
                            drawCircle(m.ground, h * 0.16f, Offset(w * 0.7f, h * 0.45f))
                            drawCircle(Ink, h * 0.16f, Offset(w * 0.7f, h * 0.45f), style = Stroke(2.dp.toPx()))
                        }
                    }
                }
                Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                    Text(m.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black, color = Ink)
                    Text(m.sub, style = MaterialTheme.typography.bodySmall, color = InkMid)
                }
            }
        }
    }
}
