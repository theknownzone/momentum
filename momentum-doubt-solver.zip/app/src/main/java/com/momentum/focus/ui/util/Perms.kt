package com.momentum.focus.ui.util

import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.getSystemService

/**
 * Every permission this app needs, what it unlocks, and how to ask for it.
 *
 * Three of these cannot be granted by a normal dialog — usage access, overlay
 * and battery exemption all require sending the user into a system settings
 * page. So the app has to explain the reason first, then hand them off, then
 * re-check when they come back.
 */
enum class Perm(
    val title: String,
    val why: String,
    val required: Boolean,
) {
    NOTIFICATIONS(
        "Notifications",
        "Session reminders and streak milestones",
        required = false,
    ),
    USAGE_ACCESS(
        "Usage access",
        "Lets the app see which app is open, so it can block distractions",
        required = true,
    ),
    OVERLAY(
        "Display over other apps",
        "Draws the shield screen on top when you open a blocked app",
        required = true,
    ),
    BATTERY(
        "Unrestricted battery",
        "Stops Android killing the blocker in the background",
        required = true,
    );
}

object Perms {

    fun granted(context: Context, perm: Perm): Boolean = when (perm) {
        Perm.NOTIFICATIONS ->
            NotificationManagerCompat.from(context).areNotificationsEnabled()

        Perm.USAGE_ACCESS -> hasUsageAccess(context)

        Perm.OVERLAY -> Settings.canDrawOverlays(context)

        Perm.BATTERY -> context.getSystemService<PowerManager>()
            ?.isIgnoringBatteryOptimizations(context.packageName) ?: false
    }

    /**
     * There is no permission check for usage access — it has to be read out of
     * AppOps, which is the only place the grant is recorded.
     */
    private fun hasUsageAccess(context: Context): Boolean = runCatching {
        val ops = context.getSystemService<AppOpsManager>() ?: return false
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                context.packageName,
            )
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                context.packageName,
            )
        }
        mode == AppOpsManager.MODE_ALLOWED
    }.getOrDefault(false)

    /** Returns the settings intent for a permission, or null if it uses a dialog. */
    fun intentFor(context: Context, perm: Perm): Intent? = when (perm) {
        // Notification permission is handled by the in-app Allow all / No
        // prompt and Android's runtime permission dialog. Never send the user
        // into a second settings screen from this permission flow.
        Perm.NOTIFICATIONS -> null

        Perm.USAGE_ACCESS -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

        Perm.OVERLAY -> Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}"),
        )

        Perm.BATTERY -> Intent(
            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            Uri.parse("package:${context.packageName}"),
        )
    }

    fun allRequiredGranted(context: Context): Boolean =
        Perm.entries.filter { it.required }.all { granted(context, it) }

    /**
     * True when the ShortsGuard accessibility service is switched on. Read out
     * of Secure settings because there is no API that asks the question
     * directly, and the flag is a colon separated list of component names.
     */
    fun isShortsGuardOn(context: Context): Boolean = runCatching {
        val flat = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false
        val me = "${context.packageName}/${context.packageName}.block.ShortsGuard"
        val meShort = "${context.packageName}/.block.ShortsGuard"
        flat.split(':').any { it.equals(me, true) || it.equals(meShort, true) }
    }.getOrDefault(false)
}

/**
 * Autostart is an OEM feature, not an Android one. There is no permission to
 * check and no API to read it — the only thing the app can do is open the
 * right screen and say plainly that it cannot verify the result.
 *
 * Each vendor buries it in a different activity inside a different app, and
 * the names change between skin versions, so this walks a list until one of
 * them actually launches and drops back to App info if none do.
 */
object OemStartup {

    private val MIUI = listOf(
        "com.miui.securitycenter" to
            "com.miui.permcenter.autostart.AutoStartManagementActivity",
    )

    private val COLOR_OS = listOf(
        "com.coloros.safecenter" to
            "com.coloros.safecenter.permission.startup.StartupAppListActivity",
        "com.coloros.safecenter" to
            "com.coloros.safecenter.startupapp.StartupAppListActivity",
        "com.oppo.safe" to
            "com.oppo.safe.permission.startup.StartupAppListActivity",
    )

    private val FUNTOUCH = listOf(
        "com.vivo.permissionmanager" to
            "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
        "com.iqoo.secure" to
            "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
    )

    /** Xiaomi, Redmi and Poco all ship MIUI or HyperOS. */
    val isXiaomi: Boolean
        get() = Build.MANUFACTURER.equals("Xiaomi", true) ||
            Build.BRAND.equals("Redmi", true) ||
            Build.BRAND.equals("Poco", true)

    private val isOppo: Boolean
        get() = listOf("OPPO", "realme", "OnePlus")
            .any { Build.MANUFACTURER.equals(it, true) || Build.BRAND.equals(it, true) }

    private val isVivo: Boolean
        get() = Build.MANUFACTURER.equals("vivo", true) || Build.BRAND.equals("vivo", true)

    /** True when this phone is one of the skins that kills background services. */
    val isAffected: Boolean
        get() = isXiaomi || isOppo || isVivo

    /** Where the user has to go, in words, because the screen cannot be verified. */
    val path: String
        get() = when {
            isXiaomi -> "Security → Permissions → Autostart → Momentum ON"
            isOppo -> "Settings → Battery → Auto start → Momentum ON"
            isVivo -> "Settings → Battery → Background power → Momentum ON"
            else -> "Settings → Apps → Momentum → allow background activity"
        }

    /**
     * Opens the vendor autostart screen. Returns false when every candidate
     * failed and the caller only managed to open plain App info, so the UI can
     * tell the user to walk there by hand instead of pretending it worked.
     */
    fun open(context: Context): Boolean {
        val candidates = when {
            isXiaomi -> MIUI
            isOppo -> COLOR_OS
            isVivo -> FUNTOUCH
            else -> emptyList()
        }
        for ((pkg, cls) in candidates) {
            val ok = runCatching {
                context.startActivity(
                    Intent().apply {
                        component = ComponentName(pkg, cls)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
            }.isSuccess
            if (ok) return true
        }
        runCatching {
            context.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", context.packageName, null)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        }
        return false
    }
}
