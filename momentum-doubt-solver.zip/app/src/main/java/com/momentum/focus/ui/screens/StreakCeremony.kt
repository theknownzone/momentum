package com.momentum.focus.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.tr
import com.momentum.focus.ui.components.GlowProgressBar
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import java.time.LocalDate
import kotlin.math.PI
import kotlin.math.sin

/*
 * Streak milestone — "Ignite" (2026-10-03).
 *
 * Dark room, an ember. It catches, the flame grows to a size that depends on
 * how long the streak is (day 1 is a match, day 30 is a bonfire), the day
 * counter flips from yesterday's number to today's, then this week's seven
 * days stamp in one by one from the real session history, and the bar to the
 * next rung fills. One clock, every beat with its sound. Tap skips.
 */

private const val END = 4300f
private val Coal = Color(0xFF120C0A)
private val RUNG_LIST = listOf(3, 7, 14, 30, 60, 90, 180, 365)

private fun c01(x: Float) = x.coerceIn(0f, 1f)
private fun seg(t: Float, a: Float, d: Float) = c01((t - a) / d)
private fun ease(x: Float) = FastOutSlowInEasing.transform(c01(x))

@Composable
internal fun StreakCeremony(data: AppData, count: Int, onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val today = remember { LocalDate.now() }
    val week = remember(data.sessions.size) {
        (6 downTo 0).map { back ->
            val d = today.minusDays(back.toLong())
            d to data.sessions.any { it.startedAtEpochDay == d.toEpochDay() && it.completed }
        }
    }
    val prevRung = RUNG_LIST.lastOrNull { it <= count } ?: 0
    val nextRung = RUNG_LIST.firstOrNull { it > count } ?: (count + 30)
    val toNext = c01((count - prevRung).toFloat() / (nextRung - prevRung).coerceAtLeast(1))
    // Flame size grows with the streak, on a log-ish curve so day 1 is small
    // and day 30+ is near full.
    val heat = c01(0.35f + 0.65f * (kotlin.math.ln(count.toFloat() + 1f) / kotlin.math.ln(31f)))

    var t by remember { mutableFloatStateOf(0f) }
    var skipped by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }
    fun finish() { if (!done) { done = true; onDone() } }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (t < END && !skipped) withFrameNanos { now -> if (!skipped) t = (now - start) / 1_000_000f }
    }
    BackHandler { finish() }

    val fired = remember { mutableSetOf<Int>() }
    SideEffect {
        fun beat(id: Int, at: Float, fn: () -> Unit) { if (t >= at && fired.add(id) && !skipped) fn() }
        beat(1, 500f) { Sfx.playOnce(Sound.CRACK); haptics.unlock() }
        beat(2, 1300f) { Sfx.play(Sound.STREAK); haptics.confirm() }
        for (i in 0 until 7) beat(100 + i, 2000f + i * 120f) { if (week[i].second) { Sfx.play(Sound.TICK); haptics.tick() } }
        beat(3, 3050f) { Sfx.play(Sound.LEVEL) }
    }

    val amb = rememberInfiniteTransition(label = "fire")
    val flick by amb.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "flick")

    val ignite = ease(seg(t, 500f, 700f))
    val flip = ease(seg(t, 1250f, 420f))
    val label = ease(seg(t, 1600f, 300f))
    val bar = seg(t, 3000f, 300f)
    val cta = ease(seg(t, 3650f, 320f))
    val roomGlow = ignite * heat

    Box(
        Modifier
            .fillMaxSize()
            .background(Coal)
            .pointerInput(Unit) { detectTapGestures { if (t < END) { skipped = true; t = END } } },
    ) {
        // warm light thrown by the fire
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Brush.radialGradient(listOf(Color(0xFFFF7A2E).copy(alpha = 0.32f * roomGlow), Color.Transparent), Offset(size.width / 2, size.height * 0.34f), size.width * (0.6f + 0.3f * heat)))
        }
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 22.dp).padding(top = 24.dp, bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                tr("STREAK", "स्ट्रीक"),
                fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 2.6.sp,
                color = Color(0xFFFFC27A).copy(alpha = 0.7f),
            )
            // ---- flame
            Box(Modifier.size(230.dp), contentAlignment = Alignment.BottomCenter) {
                Canvas(Modifier.fillMaxSize()) {
                    // sparks
                    if (ignite > 0f) for (i in 0 until 12) {
                        val ph = (flick * (0.6f + (i % 4) * 0.2f) + i * 0.083f) % 1f
                        val x = size.width / 2 + sin((i * 2.3f + ph * 3f)) * size.width * 0.18f * heat
                        val y = size.height * 0.80f - ph * size.height * 0.75f * heat
                        drawCircle(Color(0xFFFFD27A).copy(alpha = (1f - ph) * 0.8f * ignite), (1.2f + (i % 3) * 0.7f).dp.toPx(), Offset(x, y))
                    }
                    flame(ignite * heat, flick)
                    // ember / log base
                    drawRoundRect(Color(0xFF3A2216), Offset(size.width * 0.30f, size.height * 0.88f), androidx.compose.ui.geometry.Size(size.width * 0.40f, 12.dp.toPx()), CornerRadius(6.dp.toPx()))
                    drawRoundRect(Ink, Offset(size.width * 0.30f, size.height * 0.88f), androidx.compose.ui.geometry.Size(size.width * 0.40f, 12.dp.toPx()), CornerRadius(6.dp.toPx()), style = Stroke(2.5.dp.toPx()))
                    if (ignite <= 0f) drawCircle(Color(0xFFFF7A2E), 4.dp.toPx() * (0.6f + 0.4f * sin(t / 90f)), Offset(size.width / 2, size.height * 0.86f))
                }
            }
            // ---- flip counter
            Box(Modifier.height(96.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    "${(count - 1).coerceAtLeast(0)}",
                    fontSize = 84.sp, fontWeight = FontWeight.Black, color = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier.graphicsLayer { translationY = -flip * 60.dp.toPx(); alpha = 1f - flip; rotationX = flip * 70f },
                )
                Text(
                    "$count",
                    fontSize = 84.sp, fontWeight = FontWeight.Black,
                    style = androidx.compose.ui.text.TextStyle(brush = Brush.verticalGradient(listOf(Color(0xFFFFF1C2), Color(0xFFFFB347), Color(0xFFFF6A2E)))),
                    modifier = Modifier.graphicsLayer {
                        translationY = (1f - flip) * 60.dp.toPx(); alpha = flip; rotationX = (1f - flip) * -70f
                        val s = 1f + 0.12f * sin(flip * PI.toFloat()); scaleX = s; scaleY = s
                    },
                )
            }
            Text(
                if (count == 1) tr("Day one. The fire's lit.", "पहला दिन। आग जल गई।") else tr("$count days. Don't let it go out.", "$count दिन। इसे बुझने मत देना।"),
                fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.85f * label), textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { translationY = (1f - label) * 10.dp.toPx() },
            )
            Spacer(Modifier.height(22.dp))
            // ---- this week, stamped day by day from real sessions
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                week.forEachIndexed { i, (day, hit) ->
                    val p = seg(t, 2000f + i * 120f, 220f)
                    val isToday = i == 6
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(36.dp)
                                .graphicsLayer { val s = if (p <= 0f) 0.5f else 0.5f + 0.5f * ease(p) + 0.12f * sin(p * PI.toFloat()); scaleX = s; scaleY = s; alpha = c01(p * 2f) }
                                .clip(CircleShape)
                                .background(if (hit) Color(0xFFFF6A2E) else Color.White.copy(alpha = 0.08f))
                                .border(if (isToday) 2.5.dp else 1.5.dp, if (hit) Ink else Color.White.copy(alpha = 0.18f), CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (hit) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.height(5.dp))
                        Text(
                            day.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale.getDefault()).take(3),
                            fontSize = 11.sp, color = Color.White.copy(alpha = if (isToday) 0.9f else 0.45f),
                        )
                    }
                }
            }
            Spacer(Modifier.height(22.dp))
            // ---- next rung
            Column(Modifier.fillMaxWidth().graphicsLayer { alpha = bar }) {
                Row {
                    Text(tr("NEXT: $nextRung DAYS", "अगला: $nextRung दिन"), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.6.sp, color = Color.White.copy(alpha = 0.55f), modifier = Modifier.weight(1f))
                    Text(tr("${nextRung - count} to go", "${nextRung - count} बाकी"), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.8f))
                }
                Spacer(Modifier.height(8.dp))
                if (bar > 0f) GlowProgressBar(progress = toNext, height = 10.dp, dark = true)
            }
            Spacer(Modifier.weight(1f))
            Box(Modifier.graphicsLayer { alpha = cta; translationY = (1f - cta) * 20.dp.toPx() }) {
                PrimaryButton(tr("Keep it burning →", "जलाए रखें →")) {
                    if (cta > 0.5f) { haptics.confirm(); Sfx.play(Sound.DONE); finish() }
                }
            }
        }
        if (t < END) {
            Text(
                tr("tap to skip", "छोड़ने के लिए टैप करें"),
                fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Color.White.copy(alpha = 0.3f),
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 2.dp),
            )
        }
    }
}

/** Three-layer comic flame with an ink outline; [k] 0..1 sets its size. */
private fun DrawScope.flame(k: Float, flick: Float) {
    if (k <= 0.01f) return
    val cx = size.width / 2
    val base = size.height * 0.88f
    fun layer(scale: Float, sway: Float): Path {
        val h = size.height * 0.80f * k * scale
        val w = size.width * 0.30f * (0.6f + 0.4f * k) * scale
        val wob = sin((flick * 2f * PI.toFloat()) + sway) * w * 0.12f
        return Path().apply {
            moveTo(cx, base)
            cubicTo(cx - w * 1.15f, base - h * 0.08f, cx - w * 1.05f, base - h * 0.55f, cx - w * 0.25f + wob, base - h * 0.72f)
            cubicTo(cx - w * 0.05f + wob, base - h * 0.82f, cx - w * 0.10f + wob * 1.5f, base - h * 0.92f, cx + wob * 1.8f, base - h)
            cubicTo(cx + w * 0.55f + wob, base - h * 0.80f, cx + w * 1.15f, base - h * 0.55f, cx + w * 1.0f, base - h * 0.25f)
            cubicTo(cx + w * 0.95f, base - h * 0.05f, cx + w * 0.4f, base, cx, base)
            close()
        }
    }
    val outer = layer(1f, 0f)
    drawPath(outer, Brush.verticalGradient(listOf(Color(0xFFFFB347), Color(0xFFFF6A2E), Color(0xFFE5401F)), startY = base - size.height * 0.8f * k, endY = base))
    drawPath(outer, Ink, style = Stroke(3.dp.toPx()))
    drawPath(layer(0.66f, 1.3f), Brush.verticalGradient(listOf(Color(0xFFFFF1C2), Color(0xFFFFD23F)), startY = base - size.height * 0.55f * k, endY = base))
    drawPath(layer(0.34f, 2.4f), Color.White.copy(alpha = 0.9f))
}
