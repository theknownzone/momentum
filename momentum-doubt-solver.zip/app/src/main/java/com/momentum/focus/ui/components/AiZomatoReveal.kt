package com.momentum.focus.ui.components

import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * The AI entry choreography, rebuilt frame-for-frame off a screen recording
 * of a food app's own "AI is thinking" reveal: a near-black takeover, a
 * cluster of small dots that fly in from scattered positions and assemble
 * into a four-armed sparkle at the centre, two soft colour blooms breathing
 * in and out from opposite corners behind it, and a status line under the
 * sparkle that swaps once partway through. Nothing here is a glossy sphere
 * or an orbiting comet — the reference was plainer than that, and plainer
 * read as more expensive, so plainer is what got built.
 *
 * Runs 3.6s on a single linear `progress` clock, same clock the sound beats
 * below read from, so nothing can drift out of sync with what's on screen.
 */
@Composable
fun AiZomatoReveal(
    name: String = "",
    onFinished: () -> Unit,
) {
    val haptics = rememberHaptics()
    val str = strings()
    val infinite = rememberInfiniteTransition(label = "orb")

    val breathe by infinite.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "breathe",
    )

    val drift by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(6400, easing = LinearEasing),
        ),
        label = "drift",
    )

    // The sparkle's 13 dots, target positions fixed (a plus with four short
    // diagonal points — a compass rose, not a grid), scatter origins random
    // but seeded once so the assemble animation is the same shape every
    // time rather than reshuffling on recomposition.
    val targets = remember {
        listOf(
            0 to 0,
            0 to -1, 0 to -2, 0 to 1, 0 to 2,
            1 to 0, 2 to 0, -1 to 0, -2 to 0,
            1 to -1, -1 to -1, 1 to 1, -1 to 1,
        )
    }
    val scatter = remember {
        val rnd = kotlin.random.Random(42)
        targets.map { Offset(rnd.nextFloat() * 2f - 1f, rnd.nextFloat() * 2f - 1f) * 9f }
    }

    var progress by remember { mutableFloatStateOf(0f) }
    var alive by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        // Sound and haptics on their own launch, reading the same
        // `progress` fractions the canvas below reads — one wall clock,
        // not two timers that can drift apart from each other.
        launch {
            fun at(f: Float) = (3600 * f).toLong()
            delay(at(0.05f)); Sfx.playOnce(Sound.RISER)
            delay(at(0.30f - 0.05f)); haptics.tick()
            delay(at(0.62f - 0.30f)); Sfx.playOnce(Sound.REPLY)
            delay(at(0.88f - 0.62f)); Sfx.playOnce(Sound.SHIMMER); haptics.press()
        }

        val start = withFrameNanos { it }
        while (progress < 1f) {
            withFrameNanos { now ->
                progress = ((now - start) / 3600_000_000f).coerceIn(0f, 1f)
            }
        }
        alive = false
        onFinished()
    }

    if (!alive) return

    val p = progress
    // Dots assemble over the first fifth of the clock — eased out so they
    // decelerate into place rather than arriving at a constant speed.
    val assemble = (p / 0.22f).coerceIn(0f, 1f)
    val assembleEased = 1f - (1f - assemble) * (1f - assemble) * (1f - assemble)
    val statusAlpha = (((p - 0.04f) / 0.10f).coerceIn(0f, 1f)) *
        (1f - ((p - 0.82f) / 0.12f).coerceIn(0f, 1f))
    val secondLine = p > 0.45f
    val greetingAlpha = (1f - ((p - 0.55f) / 0.30f)).coerceIn(0f, 1f)
    val cardsAlpha = ((p - 0.25f) / 0.30f).coerceIn(0f, 1f)
    val composerAlpha = ((p - 0.55f) / 0.25f).coerceIn(0f, 1f)
    val exitAlpha = ((p - 0.85f) / 0.15f).coerceIn(0f, 1f)
    // A dim, not a blackout: capped well under full opacity so the chat
    // screen underneath still shows through, faintly, the whole time. A
    // solid black takeover was tried and rejected — it read as the screen
    // going dead rather than as something loading on top of it.
    val scrim = (0.62f - exitAlpha * 0.62f).coerceIn(0f, 0.62f)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF07060B).copy(alpha = scrim)),
        contentAlignment = Alignment.Center,
    ) {
        // Paper gets its own palette rather than a dimmed copy of the dark
        // one. MyAiScreen sits on MaterialTheme.colorScheme.background,
        // which is the paper/cream surface on a light skin — cool
        // purple/blue there just reads as a dark-mode effect that wandered
        // onto the wrong page. Warm amber/terracotta/honey is what actually
        // belongs on paper; dark skins keep the original cool palette.
        val isLight = MaterialTheme.colorScheme.background.luminance() > 0.5f
        val bloomColors = remember(isLight) {
            if (isLight) {
                listOf(
                    Color(0xFFD68C3C), Color(0xFFC85A46),
                    Color(0xFFE1AA5A), Color(0xFFBE7864),
                )
            } else {
                listOf(
                    Lilac.accent, Sky.accent,
                    Color(0xFFFF82BE), Color(0xFF82BEFF),
                )
            }
        }
        Canvas(
            modifier = Modifier.fillMaxSize().alpha(1f - exitAlpha),
        ) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val unit = min(size.width, size.height) / 15f
            val t = drift * 6.4f

            // Water, not two lights swapping brightness in a fixed spot:
            // each blob follows a Lissajous path (independent, non-matching
            // sine speeds on x and y) rather than a clean orbit, which is
            // what keeps it from reading as mechanical no matter how slow
            // it moves. Four overlapping blobs so their edges blend into
            // each other in passing, the way liquid folds rather than two
            // separate lights crossing.
            val bloomA = 0.5f + 0.5f * sin(drift * 6.2831853f)
            val bloomB = 0.5f + 0.5f * sin(drift * 6.2831853f + PI.toFloat())
            fun bloom(cxF: Float, cyF: Float, radius: Float, color: Color, alpha: Float) {
                drawRect(
                    brush = Brush.radialGradient(
                        listOf(color.copy(alpha = alpha), Color.Transparent),
                        center = Offset(cxF, cyF),
                        radius = radius,
                    ),
                )
            }
            bloom(
                size.width * 0.08f + sin(t * 0.33f) * size.width * 0.13f,
                size.height * 0.82f + cos(t * 0.21f) * size.height * 0.08f,
                size.width * 1.35f, bloomColors[0], 0.34f * bloomA,
            )
            bloom(
                size.width * 0.94f + cos(t * 0.27f) * size.width * 0.13f,
                size.height * 0.22f + sin(t * 0.19f) * size.height * 0.08f,
                size.width * 1.35f, bloomColors[1], 0.32f * bloomB,
            )
            bloom(
                size.width * 0.5f + sin(t * 0.24f + 1.7f) * size.width * 0.10f,
                size.height * 0.10f + cos(t * 0.30f + 0.6f) * size.height * 0.07f,
                size.width * 1.05f, bloomColors[2],
                0.16f * (0.5f + 0.5f * sin(drift * 6.2831853f + 2f)),
            )
            bloom(
                size.width * 0.5f + cos(t * 0.18f + 2.4f) * size.width * 0.11f,
                size.height * 0.85f + sin(t * 0.26f + 1.1f) * size.height * 0.07f,
                size.width * 0.95f, bloomColors[3],
                0.14f * (0.5f + 0.5f * sin(drift * 6.2831853f + 4f)),
            )

            // The sparkle: 13 square dots, scattered-to-assembled, then a
            // slow living spin plus a brightness ripple that radiates
            // outward from the centre — each dot's phase depends on its
            // distance from the middle, so the wave visibly travels rather
            // than every dot flickering independently in place.
            val rotAngle = sin(t * 0.18f) * 0.35f
            val cosR = cos(rotAngle)
            val sinR = sin(rotAngle)
            targets.forEachIndexed { i, (col, row) ->
                val baseX = col * unit * 1.5f
                val baseY = row * unit * 1.5f
                val rx = baseX * cosR - baseY * sinR
                val ry = baseX * sinR + baseY * cosR
                val pos = androidx.compose.ui.geometry.lerp(scatter[i], Offset(rx, ry), assembleEased)
                val radius = kotlin.math.sqrt((col * col + row * row).toFloat())
                val ripple = 0.5f + 0.5f * sin(drift * 6.2831853f * 2.4f - radius * 1.3f + i * 0.15f)
                val dotAlpha = assembleEased * (0.45f + 0.55f * ripple)
                val dotSize = unit * 0.30f * (0.55f + 0.55f * ripple) * (0.6f + 0.4f * assembleEased) * breathe
                drawRoundRect(
                    color = Color.White.copy(alpha = dotAlpha),
                    topLeft = Offset(cx + pos.x - dotSize / 2f, cy + pos.y - dotSize / 2f),
                    size = Size(dotSize, dotSize),
                    cornerRadius = CornerRadius(dotSize * 0.3f, dotSize * 0.3f),
                )
            }

            // A faint halo directly behind the sparkle, so it sits on a
            // small pool of its own light rather than flat on the black —
            // tinted from the same palette as the blooms.
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(
                        bloomColors[0].copy(alpha = 0.24f * assembleEased),
                        bloomColors[1].copy(alpha = 0.12f * assembleEased),
                        Color.Transparent,
                    ),
                    radius = unit * 5.5f,
                    center = Offset(cx, cy),
                ),
                radius = unit * 5.5f,
                center = Offset(cx, cy),
            )

            // Final pop when the reveal completes.
            if (p > 0.88f) {
                val pop = ((p - 0.88f) / 0.12f).coerceIn(0f, 1f)
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(
                            Color(0x66FFFFFF),
                            bloomColors[0].copy(alpha = 0.22f),
                            Color.Transparent,
                        ),
                        center = Offset(cx, cy),
                        radius = unit * (7f + pop * 5f),
                    ),
                    radius = unit * (7f + pop * 5f),
                    center = Offset(cx, cy),
                    alpha = (1f - pop) * 0.65f,
                )
            }
        }

        // The status line, pinned just under the sparkle regardless of
        // where the greeting/cards column below happens to sit — this is
        // the one piece of on-screen text the reference video actually
        // shows during the reveal itself.
        Box(
            Modifier
                .align(Alignment.Center)
                .offset(y = 40.dp)
                .alpha(statusAlpha * (1f - exitAlpha)),
        ) {
            Text(
                if (secondLine) str.doubt.preparing else str.doubt.thinking,
                fontSize = 15.sp,
                color = Color.White.copy(alpha = 0.65f),
            )
        }

        // The greeting, skeleton preview and composer box this screen fades
        // into.
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp)
                .alpha(greetingAlpha.coerceAtLeast(composerAlpha) * (1f - exitAlpha)),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                if (name.isBlank()) "Hi!" else "Hi, $name!",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = 0.96f),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "What would you like to know?",
                fontSize = 17.sp,
                color = Color.White.copy(alpha = 0.86f),
            )

            Spacer(Modifier.height(72.dp))

            Column(
                Modifier
                    .fillMaxWidth()
                    .alpha(cardsAlpha * (1f - exitAlpha))
                    .scale(0.96f + cardsAlpha * 0.04f),
            ) {
                SkeletonCard()
                Spacer(Modifier.height(12.dp))
                SkeletonCard(short = true)
            }

            Spacer(Modifier.height(18.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .alpha(composerAlpha * (1f - exitAlpha))
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.White.copy(alpha = 0.07f)),
            )
        }
    }
}

@Composable
private fun SkeletonCard(short: Boolean = false) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(if (short) 88.dp else 116.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.065f))
            .padding(16.dp),
    ) {
        Column {
            Box(
                Modifier
                    .fillMaxWidth(0.58f)
                    .height(12.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White.copy(alpha = 0.08f)),
            )
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(if (short) 42.dp else 64.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Sky.fill.copy(alpha = 0.035f),
                                Lilac.fill.copy(alpha = 0.055f),
                                GoldNeon.copy(alpha = 0.035f),
                            ),
                        ),
                    ),
            )
        }
    }
}
