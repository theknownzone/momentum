package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.Candy
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Sky
import kotlin.math.sin

/**
 * Short, Zomato-inspired AI entry choreography: dim the existing screen,
 * centre the greeting, bloom a chromatic AI core, reveal two soft skeletons,
 * then hand the screen back. It deliberately stops after 3.2s; the chat itself
 * is the product, not a loading screen.
 */
@Composable
fun AiZomatoReveal(
    name: String,
    onFinished: () -> Unit,
) {
    val phase = remember { Animatable(0f) }
    var alive by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        phase.animateTo(0.28f, tween(650, easing = FastOutSlowInEasing))
        phase.animateTo(0.56f, tween(700, easing = FastOutSlowInEasing))
        phase.animateTo(0.78f, tween(700, easing = FastOutSlowInEasing))
        phase.animateTo(1f, tween(1150, easing = LinearEasing))
        alive = false
        onFinished()
    }

    if (!alive) return

    val p = phase.value
    val greetingAlpha = (1f - ((p - 0.55f) / 0.35f)).coerceIn(0f, 1f)
    val cardsAlpha = ((p - 0.28f) / 0.35f).coerceIn(0f, 1f)
    val composerAlpha = ((p - 0.56f) / 0.28f).coerceIn(0f, 1f)
    val exitAlpha = ((p - 0.82f) / 0.18f).coerceIn(0f, 1f)
    val scrim = (0.82f - exitAlpha * 0.82f).coerceIn(0f, 0.82f)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0E14).copy(alpha = scrim)),
        contentAlignment = Alignment.Center,
    ) {
        // Cheap Canvas primitives only. No blur, no per-frame text measuring,
        // no infinite transition: this is intentionally light on mid-range phones.
        //
        // Second pass, built off reference art (a glass marble with an
        // iridescent swirl and a rim highlight, not a flat tinted disc). The
        // old version was a flat-gradient dot with three rings of orbiting
        // particles circling it — busy, and the particles read as
        // decoration rather than the AI itself. This is one sphere: a dark
        // glass body lit from one side, two counter-rotating sweeps of
        // colour clipped inside it so the swirl looks like it is inside the
        // glass rather than painted on top, and a single bright crescent
        // where the rim catches the light. Fewer elements, each doing more.
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width * 0.5f
            val cy = size.height * 0.47f
            val fade = 1f - exitAlpha
            val breathe = 1f + 0.05f * sin(p * Math.PI * 3.0).toFloat()
            val radius = size.minDimension * (0.058f + 0.045f * cardsAlpha) * breathe

            // Wide ambient bloom behind the sphere, its own colour drifting
            // slowly across the reveal so the light itself feels alive.
            val drift = (sin(p * Math.PI * 1.4).toFloat() * 0.5f + 0.5f)
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(
                        androidx.compose.ui.graphics.lerp(Sky.fill, Lilac.fill, drift).copy(alpha = 0.20f * fade),
                        Lilac.fill.copy(alpha = 0.08f * fade),
                        Color.Transparent,
                    ),
                    radius = radius * 8.5f,
                ),
                radius = radius * 8.5f,
                center = Offset(cx, cy),
            )

            val sphere = Path().apply { addOval(Rect(center = Offset(cx, cy), radius = radius)) }
            clipPath(sphere) {
                // Dark glass body, highlight offset toward the top-left so it
                // reads as lit from one direction rather than glowing evenly.
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0xFF20203A).copy(alpha = fade), Color(0xFF07070F).copy(alpha = fade)),
                        center = Offset(cx - radius * 0.35f, cy - radius * 0.35f),
                        radius = radius * 1.7f,
                    ),
                    radius = radius,
                    center = Offset(cx, cy),
                )
                // Two sweeps turning opposite ways so the swirl reads as
                // depth inside the glass instead of one flat ring of colour.
                rotate(degrees = p * 260f, pivot = Offset(cx, cy)) {
                    drawCircle(
                        brush = Brush.sweepGradient(
                            listOf(Sky.fill, Candy.fill, Lilac.fill, Color.White, Sky.fill),
                            center = Offset(cx, cy),
                        ),
                        radius = radius,
                        center = Offset(cx, cy),
                        alpha = 0.5f * fade,
                    )
                }
                rotate(degrees = -p * 160f, pivot = Offset(cx, cy)) {
                    drawCircle(
                        brush = Brush.sweepGradient(
                            listOf(Color.Transparent, Lilac.fill, Color.Transparent, Sky.fill, Color.Transparent),
                            center = Offset(cx, cy),
                        ),
                        radius = radius,
                        center = Offset(cx, cy),
                        alpha = 0.35f * fade,
                    )
                }
            }

            // The crescent rim light: a bright arc hugging the sphere's own
            // edge, fixed as if lit from the top-left. This is what makes it
            // read as glass — the fill above gives colour, this gives shine.
            rotate(degrees = -35f, pivot = Offset(cx, cy)) {
                drawCircle(
                    brush = Brush.sweepGradient(
                        listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.85f * fade),
                            Color.Transparent,
                            Color.Transparent,
                        ),
                        center = Offset(cx, cy),
                    ),
                    radius = radius,
                    center = Offset(cx, cy),
                    style = Stroke(width = radius * 0.09f),
                )
            }
        }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp)
                .alpha(greetingAlpha.coerceAtLeast(composerAlpha) * (1f - exitAlpha)),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                if (name.isBlank()) "Hi!" else "Hi, $name!",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = 0.96f),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "What would you like to know?",
                fontSize = 17.sp,
                color = Color.White.copy(alpha = 0.86f),
            )

            Spacer(Modifier.height(72.dp))

            Column(
                Modifier
                    .fillMaxWidth()
                    .alpha(cardsAlpha * (1f - exitAlpha))
                    .scale(0.96f + cardsAlpha * 0.04f),
            ) {
                SkeletonCard()
                Spacer(Modifier.height(12.dp))
                SkeletonCard(short = true)
            }

            Spacer(Modifier.height(18.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .alpha(composerAlpha * (1f - exitAlpha))
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.White.copy(alpha = 0.07f)),
            )
        }
    }
}

@Composable
private fun SkeletonCard(short: Boolean = false) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(if (short) 88.dp else 116.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.065f))
            .padding(16.dp),
    ) {
        Column {
            Box(
                Modifier
                    .fillMaxWidth(0.58f)
                    .height(12.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White.copy(alpha = 0.08f)),
            )
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(if (short) 42.dp else 64.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Sky.fill.copy(alpha = 0.035f),
                                Lilac.fill.copy(alpha = 0.055f),
                                GoldNeon.copy(alpha = 0.035f),
                            ),
                        ),
                    ),
            )
        }
    }
}
