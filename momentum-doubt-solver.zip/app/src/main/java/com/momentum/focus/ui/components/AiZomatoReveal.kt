package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * The MyAi entry reveal, rebuilt against an actual capture of the reference
 * rather than a guess at what "Zomato-style" means.
 *
 * The capture is not a chromatic burst of orbiting dots — that was the
 * previous version's invention, not anything the reference does. What it
 * actually is: a dark screen, a plain "Hi, name!" header, two skeleton
 * blocks with a diagonal shimmer sweeping across them, a static composer
 * placeholder, and a footer disclaimer. The "reveal" is skeletons standing
 * in for content that has not arrived yet, the same pattern LinkedIn,
 * Instagram and most loading states already use — not a light show.
 *
 * This only builds the entry screen (the reference's first moment). The
 * reference's second moment — a small four-point sparkle made of dots next
 * to "Hunting for the perfect spots" once something is actually sent — is a
 * different component for a different trigger (a reply in flight, not entry)
 * and is intentionally not built here.
 */
@Composable
fun AiZomatoReveal(
    name: String,
    onFinished: () -> Unit,
) {
    var alive by remember { mutableStateOf(true) }
    val alpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        alpha.animateTo(1f, tween(260))
        // Long enough to register as a screen, short enough that nobody is
        // sitting through a loading state for content that was never really
        // loading in the first place.
        delay(1400)
        alive = false
        onFinished()
    }
    if (!alive) return

    // A Popup, not a Box in the normal composition tree.
    //
    // Moving this to be a sibling of MyAiScreen's own statusBarsPadding'd Box
    // was the fix tried first, and it did not work — confirmed on video, the
    // cream strip was still there. The actual constraint was one level
    // further up than that: MainActivity hosts every screen inside a
    // Scaffold, and Scaffold's own padding already reserves the status bar's
    // height before MyAiScreen is even composed. No amount of restructuring
    // inside MyAiScreen can undo space an ancestor already claimed — the
    // Box handed to MyAiScreen was never the full window to begin with.
    // Popup renders directly against the window root, outside the Scaffold's
    // own layout entirely, which is the one place in Compose that actually
    // escapes an ancestor's padding rather than just moving around inside it.
    androidx.compose.ui.window.Popup(
        alignment = Alignment.TopStart,
        properties = androidx.compose.ui.window.PopupProperties(
            focusable = false,
            dismissOnBackPress = false,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false,
        ),
    ) {
    Box(
        Modifier
            .fillMaxSize()
            .alpha(alpha.value)
            .background(Color(0xFF121016))
            .drawWithContent {
                drawContent()
                // A soft ambient pool behind the greeting, in the app's own
                // Tang/Lilac pair rather than a flat dark rectangle. The
                // plain version had nothing happening except two grey boxes
                // -- this is the one warm thing in the scene, sitting still
                // rather than competing with the shimmer for attention.
                drawCircle(
                    brush = Brush.radialGradient(
                        colorStops = arrayOf(
                            0f to Color(0xFFFF8A5C).copy(alpha = 0.16f),
                            0.6f to Color(0xFFB9A7FF).copy(alpha = 0.08f),
                            1f to Color.Transparent,
                        ),
                        center = Offset(size.width * 0.5f, size.height * 0.12f),
                        radius = size.width * 0.9f,
                    ),
                    radius = size.width * 0.9f,
                    center = Offset(size.width * 0.5f, size.height * 0.12f),
                )
            },
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(56.dp))
            Text(
                if (name.isBlank()) "Hi!" else "Hi, $name!",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.fillMaxWidth(),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            Spacer(Modifier.height(28.dp))
            // Two cards, not two identical ones -- an icon placeholder on
            // each, the way a real suggestion card has something to look at
            // beyond a text bar and an image block.
            ShimmerCard(icon = true)
            Spacer(Modifier.height(16.dp))
            ShimmerCard(icon = false)
            Spacer(Modifier.weight(1f))
            // A static composer placeholder -- this does not shimmer, since
            // nothing about the input itself is "loading". Only content
            // blocks shimmer; chrome does not.
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.06f)),
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "AI-powered responses. Please check important details.",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.35f),
                modifier = Modifier.fillMaxWidth(),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))
        }
    }
    }
}

/**
 * One skeleton block: a short label bar, a large body block, a small pill --
 * the same three-part shape the reference's own cards use. A single diagonal
 * shimmer band sweeps across the whole card as one pass, rather than each
 * piece shimmering on its own clock, so the three parts read as one card
 * loading instead of three unrelated ones.
 */
@Composable
private fun ShimmerCard(icon: Boolean) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val sweep by transition.animateFloat(
        initialValue = -0.4f,
        targetValue = 1.4f,
        animationSpec = infiniteRepeatable(
            tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "sweep",
    )
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .padding(16.dp),
    ) {
        if (icon) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                ShimmerBlock(Modifier.size(28.dp).clip(CircleShape), sweep)
                Spacer(Modifier.width(10.dp))
                ShimmerBlock(Modifier.width(96.dp).height(14.dp), sweep)
            }
            Spacer(Modifier.height(14.dp))
        } else {
            ShimmerBlock(Modifier.width(120.dp).height(14.dp), sweep)
            Spacer(Modifier.height(14.dp))
        }
        ShimmerBlock(Modifier.fillMaxWidth().height(120.dp), sweep)
        Spacer(Modifier.height(12.dp))
        ShimmerBlock(Modifier.width(80.dp).height(18.dp), sweep)
    }
}

@Composable
private fun ShimmerBlock(modifier: Modifier, sweep: Float) {
    Box(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .drawWithContent {
                drawContent()
                // The diagonal band: a light streak crossing the block at an
                // angle, positioned by `sweep` which runs from just off the
                // left edge to just off the right, on an infinite clock. Each
                // block reads its own width/height, so the same `sweep`
                // fraction still looks like one continuous sheet of light
                // moving across differently-sized pieces together.
                val bandWidth = size.width * 0.35f
                val x = size.width * sweep
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.10f),
                            Color.Transparent,
                        ),
                        start = Offset(x - bandWidth, 0f),
                        end = Offset(x + bandWidth, size.height),
                    ),
                )
            },
    )
}
