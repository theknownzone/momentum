package com.momentum.focus.ui.components

import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * The AI entry choreography: dark glass sphere, blue/purple/pink refraction
 * turning inside it, connected aura ribbons drifting around it, a bright
 * lower horizon and bloom, a rim highlight — the orb itself is a straight
 * carry-over of a Canvas source given directly for this, not a
 * redescription of it. Only the package line and the surrounding
 * integration (this app's own [Sfx]/haptics beats, and the greeting +
 * skeleton preview that fades in over it) were adapted to fit here.
 *
 * Runs 3.6s on a single linear `progress` clock, same clock the sound beats
 * below read from, so nothing can drift out of sync with what's on screen.
 */
@Composable
fun AiZomatoReveal(
    name: String = "",
    onFinished: () -> Unit,
) {
    val haptics = rememberHaptics()
    val infinite = rememberInfiniteTransition(label = "orb")

    val breathe by infinite.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "breathe",
    )

    val auraRotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(9000, easing = LinearEasing),
        ),
        label = "auraRotation",
    )

    var progress by remember { mutableFloatStateOf(0f) }
    var alive by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        // Sound and haptics on their own launch, reading the same
        // `progress` fractions the canvas below reads — the same fix
        // CrownCinematic already uses for its own beats: one wall clock,
        // not two timers that can drift apart from each other.
        launch {
            fun at(f: Float) = (3600 * f).toLong()
            delay(at(0.05f)); Sfx.playOnce(Sound.RISER)
            delay(at(0.30f - 0.05f)); haptics.tick()
            delay(at(0.62f - 0.30f)); Sfx.playOnce(Sound.REPLY)
            delay(at(0.88f - 0.62f)); Sfx.playOnce(Sound.SHIMMER); haptics.press()
        }

        val start = withFrameNanos { it }
        while (progress < 1f) {
            withFrameNanos { now ->
                progress = ((now - start) / 3600_000_000f).coerceIn(0f, 1f)
            }
        }
        alive = false
        onFinished()
    }

    if (!alive) return

    val p = progress
    val greetingAlpha = (1f - ((p - 0.55f) / 0.30f)).coerceIn(0f, 1f)
    val cardsAlpha = ((p - 0.25f) / 0.30f).coerceIn(0f, 1f)
    val composerAlpha = ((p - 0.55f) / 0.25f).coerceIn(0f, 1f)
    val exitAlpha = ((p - 0.85f) / 0.15f).coerceIn(0f, 1f)
    val scrim = (0.82f - exitAlpha * 0.82f).coerceIn(0f, 0.82f)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0E14).copy(alpha = scrim)),
        contentAlignment = Alignment.Center,
    ) {
        // The orb itself never faded before -- only the greeting/cards below
        // it did, via their own alpha multiplied by (1f - exitAlpha). The
        // sphere, aura ribbons and glow stayed fully opaque right up to the
        // frame this composable was removed from composition, so however
        // gracefully everything else faded, the orb itself still popped out
        // of existence. Same fade applied here closes that gap.
        Canvas(
            modifier = Modifier.fillMaxSize().alpha(1f - exitAlpha),
        ) {
            val cx = size.width / 2f
            val cy = size.height / 2f

            val baseRadius = min(size.width, size.height) * 0.19f
            val radius = baseRadius * breathe

            /*
             * Background atmosphere
             */
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x221A7CFF),
                        Color(0x101A4BFF),
                        Color.Transparent,
                    ),
                    center = Offset(cx, cy),
                    radius = radius * 3.2f,
                ),
            )

            /*
             * Flowing connected aura ribbons
             */
            repeat(7) { i ->
                val phase =
                    auraRotation * PI.toFloat() / 180f +
                        i * (PI.toFloat() * 2f / 7f)

                val path = Path()

                val points = 80

                for (pt in 0..points) {
                    val t = pt / points.toFloat()

                    val angle =
                        t * PI.toFloat() * 2f +
                            phase

                    val wave =
                        sin(t * PI.toFloat() * 5f + phase * 1.4f) *
                            radius * 0.12f

                    val rr =
                        radius * (1.35f + t * 0.55f) +
                            wave

                    val x = cx + cos(angle) * rr
                    val y = cy + sin(angle) * rr * 0.58f

                    if (pt == 0) {
                        path.moveTo(x, y)
                    } else {
                        path.lineTo(x, y)
                    }
                }

                drawPath(
                    path = path,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0x556C5CE7),
                            Color(0x774AA3FF),
                            Color(0x44FF4FD8),
                            Color.Transparent,
                        ),
                    ),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                        width = radius * 0.018f,
                    ),
                    alpha = 0.75f,
                )
            }

            /*
             * Outer atmospheric glow
             */
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x223C8CFF),
                        Color(0x182C55FF),
                        Color.Transparent,
                    ),
                    center = Offset(cx, cy),
                    radius = radius * 1.8f,
                ),
                radius = radius * 1.8f,
                center = Offset(cx, cy),
            )

            /*
             * Main dark glass sphere
             */
            drawCircle(
                brush = Brush.radialGradient(
                    colorStops = arrayOf(
                        0.0f to Color(0xFF17202E),
                        0.42f to Color(0xFF101722),
                        0.76f to Color(0xFF080D14),
                        1.0f to Color(0xFF03060A),
                    ),
                    center = Offset(
                        cx - radius * 0.22f,
                        cy - radius * 0.28f,
                    ),
                    radius = radius * 1.25f,
                ),
                radius = radius,
                center = Offset(cx, cy),
            )

            /*
             * Internal iridescent refraction
             */
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        Color(0x665C7CFF),
                        Color(0x5547D7FF),
                        Color(0x664D5DFF),
                        Color(0x66D54DFF),
                        Color(0x6648B8FF),
                        Color(0x665C7CFF),
                    ),
                    center = Offset(cx, cy),
                ),
                radius = radius * 0.94f,
                center = Offset(cx, cy),
                alpha = 0.55f,
            )

            /*
             * Soft inner highlight
             */
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x4469B6FF),
                        Color(0x223E73FF),
                        Color.Transparent,
                    ),
                    center = Offset(
                        cx - radius * 0.30f,
                        cy - radius * 0.38f,
                    ),
                    radius = radius * 0.9f,
                ),
                radius = radius * 0.9f,
                center = Offset(cx, cy),
            )

            /*
             * Glass specular streak
             */
            val streak = Path().apply {
                moveTo(
                    cx - radius * 0.64f,
                    cy - radius * 0.42f,
                )
                cubicTo(
                    cx - radius * 0.35f,
                    cy - radius * 0.72f,
                    cx + radius * 0.10f,
                    cy - radius * 0.76f,
                    cx + radius * 0.46f,
                    cy - radius * 0.52f,
                )
            }

            drawPath(
                path = streak,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color(0x88FFFFFF),
                        Color.Transparent,
                    ),
                ),
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = radius * 0.025f,
                    cap = StrokeCap.Round,
                ),
            )

            /*
             * Bright lower rim / horizon
             */
            val horizon = Path().apply {
                arcTo(
                    rect = androidx.compose.ui.geometry.Rect(
                        cx - radius * 1.02f,
                        cy - radius * 1.02f,
                        cx + radius * 1.02f,
                        cy + radius * 1.02f,
                    ),
                    startAngleDegrees = 18f,
                    sweepAngleDegrees = 144f,
                    forceMoveTo = false,
                )
            }

            drawPath(
                path = horizon,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color(0xFF4C9CFF),
                        Color(0xFFB56CFF),
                        Color.Transparent,
                    ),
                ),
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = radius * 0.035f,
                    cap = StrokeCap.Round,
                ),
                alpha = 0.9f,
            )

            /*
             * Horizon bloom
             */
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x553E8FFF),
                        Color(0x222E68FF),
                        Color.Transparent,
                    ),
                    center = Offset(
                        cx,
                        cy + radius * 0.82f,
                    ),
                    radius = radius * 0.75f,
                ),
                radius = radius * 0.75f,
                center = Offset(
                    cx,
                    cy + radius * 0.82f,
                ),
            )

            /*
             * Final pop when animation completes
             */
            if (p > 0.88f) {
                val pop =
                    ((p - 0.88f) / 0.12f)
                        .coerceIn(0f, 1f)

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0x66FFFFFF),
                            Color(0x223D9BFF),
                            Color.Transparent,
                        ),
                        center = Offset(cx, cy),
                        radius = radius * (1.2f + pop * 0.8f),
                    ),
                    radius = radius * (1.2f + pop * 0.8f),
                    center = Offset(cx, cy),
                    alpha = (1f - pop) * 0.65f,
                )
            }
        }

        // The greeting, skeleton preview and composer box this screen fades
        // into — kept from the previous version rather than dropped, since
        // the orb source given was the sphere alone. Alphas now read off
        // the new linear `progress` instead of the old eased `phase`, at
        // roughly the same fractions so the handoff still lands the same
        // places: greeting up front, cards and composer arriving as the
        // sphere settles, everything out together by the final pop.
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp)
                .alpha(greetingAlpha.coerceAtLeast(composerAlpha) * (1f - exitAlpha)),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                if (name.isBlank()) "Hi!" else "Hi, $name!",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = 0.96f),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "What would you like to know?",
                fontSize = 17.sp,
                color = Color.White.copy(alpha = 0.86f),
            )

            Spacer(Modifier.height(72.dp))

            Column(
                Modifier
                    .fillMaxWidth()
                    .alpha(cardsAlpha * (1f - exitAlpha))
                    .scale(0.96f + cardsAlpha * 0.04f),
            ) {
                SkeletonCard()
                Spacer(Modifier.height(12.dp))
                SkeletonCard(short = true)
            }

            Spacer(Modifier.height(18.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .alpha(composerAlpha * (1f - exitAlpha))
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.White.copy(alpha = 0.07f)),
            )
        }
    }
}

@Composable
private fun SkeletonCard(short: Boolean = false) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(if (short) 88.dp else 116.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.065f))
            .padding(16.dp),
    ) {
        Column {
            Box(
                Modifier
                    .fillMaxWidth(0.58f)
                    .height(12.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White.copy(alpha = 0.08f)),
            )
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(if (short) 42.dp else 64.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Sky.fill.copy(alpha = 0.035f),
                                Lilac.fill.copy(alpha = 0.055f),
                                GoldNeon.copy(alpha = 0.035f),
                            ),
                        ),
                    ),
            )
        }
    }
}
