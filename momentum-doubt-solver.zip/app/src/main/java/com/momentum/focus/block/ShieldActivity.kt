package com.momentum.focus.block

import com.momentum.focus.data.EntryPrice
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppStore
import com.momentum.focus.data.Currency
import androidx.compose.material3.Divider
import com.momentum.focus.ui.components.Coin3D
import com.momentum.focus.ui.components.FrostScrim
import com.momentum.focus.ui.components.FrostSheet
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * The shield. Deliberately hard to leave and easy to obey.
 *
 * The "spend minutes" button is locked for a few seconds after the screen
 * appears. That pause is the whole mechanism: a craving fades in seconds, and
 * a button you cannot press yet is the difference between a decision and a
 * reflex.
 */
class ShieldActivity : ComponentActivity() {

    companion object {
        const val EXTRA_PACKAGE = "pkg"
        const val LOCK_SECONDS = 7
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Shows over the lock screen and keeps the screen on: a shield that
        // vanishes when the display sleeps is not a shield.
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val pkg = intent.getStringExtra(EXTRA_PACKAGE) ?: ""
        val store = AppStore(applicationContext)

        setContent {
            MomentumTheme {
                val scope = rememberCoroutineScope()
                val haptics = rememberHaptics()

                var balance by remember { mutableIntStateOf(0) }
                var streak by remember { mutableIntStateOf(0) }
                var crown by remember { mutableStateOf(false) }
                var countdown by remember { mutableIntStateOf(LOCK_SECONDS) }
                var waitTotal by remember { mutableIntStateOf(LOCK_SECONDS) }
                var attempt by remember { mutableIntStateOf(1) }
                var peak by remember { mutableStateOf(false) }
                var quote by remember { mutableStateOf(EntryPrice.Quote(EntryPrice.BASE, EntryPrice.Kind.NORMAL)) }
                val price = quote.price
                var confirmPay by remember { mutableStateOf(false) }
                val label = remember(pkg) { appLabel(pkg) }
                val isSettings = remember(pkg) {
                    pkg == "com.android.settings" ||
                        pkg.startsWith("com.android.settings.")
                }

                LaunchedEffect(Unit) {
                    // Count this show (singleTask: repeat launches while it is
                    // up land in onNewIntent, so onCreate = one real attempt).
                    val today = java.time.LocalDate.now().toEpochDay()
                    store.update {
                        if (it.shieldDay == today) it.copy(shieldShowsToday = it.shieldShowsToday + 1)
                        else it.copy(shieldDay = today, shieldShowsToday = 1)
                    }
                    val data = store.data.first()
                    balance = data.balanceMinutes
                    streak = data.streakDays
                    crown = data.crownMode
                    quote = EntryPrice.quote(lastBankedAtMs = data.lastBankedAtMs)
                    attempt = data.shieldShowsToday.coerceAtLeast(1)
                    // Predictive friction: +5 s inside this person's own
                    // predicted peak hour (UrgePredictor).
                    peak = runCatching { com.momentum.focus.data.UrgePredictor.isPeak(this@ShieldActivity) }.getOrDefault(false)
                    waitTotal = EntryPrice.waitSeconds(attempt) + if (peak) 5 else 0
                    countdown = waitTotal
                    while (countdown > 0) {
                        delay(1000)
                        countdown--
                    }
                    haptics.tick()
                }

                Column(
                    Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .paperGrain()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(horizontal = Paper.ScreenPad)
                        .padding(top = 40.dp, bottom = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        "BLOCKED",
                        style = MaterialTheme.typography.labelSmall,
                        color = Tang.accent,
                    )
                    Text(
                        label,
                        style = MaterialTheme.typography.displayMedium,
                        color = Ink,
                        textAlign = TextAlign.Center,
                    )

                    Spacer(Modifier.height(28.dp))

                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(Paper.CardRadius))
                            .background(Mint.fill)
                            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                            .padding(20.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Coin3D(color = Butter.fill, size = 26.dp)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "WALLET BALANCE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Mint.on.copy(alpha = 0.75f),
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                Currency.format(balance),
                                style = MaterialTheme.typography.displayMedium,
                                color = Mint.on,
                            )

                            Spacer(Modifier.height(14.dp))
                            Divider(color = Mint.on.copy(alpha = 0.25f))
                            Spacer(Modifier.height(12.dp))

                            // A receipt, not a warning. Seeing the balance
                            // after the purchase is what makes the cost land.
                            PriceRow(quote)
                            ReceiptRow(
                                "Left after this",
                                Currency.format((balance - price).coerceAtLeast(0)),
                                Mint.on,
                            )
                            ReceiptRow("Streak", "$streak days", Mint.on.copy(alpha = 0.8f))
                            PriceNote(quote.kind)
                        }
                    }

                    // "Study on YouTube?" (idea from Regain): when the blocked app
                    // has a feed we can block on its own, offer the middle path —
                    // app back, feed gone. Refused while a pact or Crown is live,
                    // because that is loosening, and the pact's whole job is to
                    // stop loosening.
                    val feeds = remember(pkg) { com.momentum.focus.data.FeedSurfaces.all.filter { it.pkg == pkg } }
                    if (feeds.isNotEmpty() && !isSettings) {
                        var refused by remember { mutableStateOf(false) }
                        Spacer(Modifier.height(16.dp))
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(Sky.fill.copy(alpha = 0.35f))
                                .border(2.dp, Ink, RoundedCornerShape(16.dp))
                                .padding(14.dp),
                        ) {
                            Text(
                                com.momentum.focus.data.tr("Need $label to study?", "पढ़ाई के लिए $label चाहिए?"),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                                color = Ink,
                            )
                            Text(
                                if (refused) com.momentum.focus.data.tr("Pact is live — you can only tighten until it ends.", "पैक्ट चालू है — ख़त्म होने तक सिर्फ़ सख़्त कर सकते हैं।")
                                else com.momentum.focus.data.tr(
                                    "Block only ${feeds.joinToString(" + ") { it.label }}. The app opens, the endless scroll doesn't.",
                                    "सिर्फ़ ${feeds.joinToString(" + ") { it.label }} बंद करें। ऐप खुलेगा, अनंत स्क्रॉल नहीं।",
                                ),
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (refused) Tang.accent else Ink.copy(alpha = 0.75f),
                            )
                            Spacer(Modifier.height(10.dp))
                            SquishButton(
                                label = com.momentum.focus.data.tr("Switch to feed-only", "सिर्फ़ फ़ीड बंद करें"),
                                sticker = Sky,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                scope.launch {
                                    val d = store.data.first()
                                    if (d.pactLive || d.crownMode) {
                                        haptics.reject(); refused = true
                                    } else {
                                        haptics.confirm()
                                        store.update {
                                            it.copy(
                                                blockedPackages = it.blockedPackages - pkg,
                                                blockedSince = it.blockedSince - pkg,
                                                blockedSurfaces = it.blockedSurfaces + feeds.map { f -> f.key },
                                                surfacesSeeded = true,
                                            )
                                        }
                                        // Without the accessibility guard nothing blocks a
                                        // feed, so say it plainly instead of failing silently.
                                        if (!com.momentum.focus.ui.util.Perms.isShortsGuardOn(this@ShieldActivity)) {
                                            android.widget.Toast.makeText(
                                                this@ShieldActivity,
                                                com.momentum.focus.data.tr(
                                                    "Feed block needs Accessibility — turn it on in Momentum → Permissions.",
                                                    "फ़ीड ब्लॉक के लिए Accessibility चालू करें — Momentum → Permissions।",
                                                ),
                                                android.widget.Toast.LENGTH_LONG,
                                            ).show()
                                        }
                                        finish()
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.weight(1f))

                    SquishButton(
                        label = "Close it",
                        sticker = Mint,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        haptics.confirm()
                        goHome()
                    }

                    Spacer(Modifier.height(12.dp))

                    val affordable = balance >= price
                    val unlocked = countdown == 0

                    // Settings is only ever blocked while a Crown session is
                    // running, and it is the one place you go to switch this
                    // app off — so the way out has to be spelled out rather
                    // than left to be discovered. Ending the session unblocks
                    // it at once, and partial time is still banked, so this
                    // costs the session and nothing else.
                    if (isSettings) {
                        Text(
                            "Settings is locked while a Crown session runs.\n\n" +
                                "Need it now? Open Momentum and press " +
                                "\"Give up — log partial time\". Settings comes " +
                                "straight back and your minutes so far are kept.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = Tang.accent,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(12.dp))
                        SquishButton(
                            label = "Open Momentum",
                            sticker = Tang,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            haptics.tick()
                            runCatching {
                                packageManager.getLaunchIntentForPackage(packageName)
                                    ?.let { startActivity(it) }
                            }
                            finish()
                        }
                    } else if (crown) {
                        Text(
                            "Crown mode is on. No buying your way in.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = Tang.accent,
                            textAlign = TextAlign.Center,
                        )
                    } else if (!unlocked) {
                        WaitMeter(countdown, waitTotal, attempt, peak)
                    } else if (!affordable) {
                        Text(
                            "Not enough in the wallet. Go earn ${Currency.format(price)}.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                    } else {
                        SquishButton(
                            label = "Pay ${Currency.format(price)}",
                            sticker = Tang,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            haptics.tick()
                            confirmPay = true
                        }
                    }
                }

                if (confirmPay) {
                    FrostScrim {
                        Box(
                            Modifier
                                .fillMaxSize()
                                .padding(horizontal = Paper.ScreenPad),
                            contentAlignment = Alignment.BottomCenter,
                        ) {
                            FrostSheet(Modifier.padding(bottom = 28.dp)) {
                                Column(Modifier.padding(20.dp)) {
                                    Text(
                                        "Spend ${Currency.format(price)}?",
                                        style = MaterialTheme.typography.headlineSmall,
                                        color = Ink,
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        "Wallet will drop to ${Currency.format((balance - price).coerceAtLeast(0))}.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Ink.copy(alpha = 0.7f),
                                    )
                                    Spacer(Modifier.height(16.dp))
                                    SquishButton(
                                        label = "Pay and open",
                                        sticker = Tang,
                                        modifier = Modifier.fillMaxWidth(),
                                    ) {
                                        haptics.reject()
                                        scope.launch {
                                            store.update {
                                                it.copy(
                                                    spentMinutes = it.spentMinutes + price,
                                                    pendingReflectionMinutes = EntryPrice.ACCESS_MINUTES,
                                                )
                                            }
                                            BlockerService.allow(pkg, EntryPrice.ACCESS_MINUTES)
                                            finish()
                                        }
                                    }
                                    Spacer(Modifier.height(10.dp))
                                    SquishButton(
                                        label = "Keep blocked",
                                        sticker = Mint,
                                        modifier = Modifier.fillMaxWidth(),
                                    ) { confirmPay = false }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Entry price with its rule on show. SURGE / HAPPY HOUR get an ink tag
     * that stamps in once (240 ms, after the card lands) and the base price
     * struck through beside the live one — the change is never hidden.
     */
    @Composable
    private fun PriceRow(q: EntryPrice.Quote) {
        val stamp = remember { androidx.compose.animation.core.Animatable(0f) }
        LaunchedEffect(q.kind) {
            stamp.snapTo(0f)
            if (q.kind != EntryPrice.Kind.NORMAL) {
                delay(320)
                stamp.animateTo(1f, androidx.compose.animation.core.tween(240, easing = androidx.compose.animation.core.FastOutSlowInEasing))
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Entry price",
                style = MaterialTheme.typography.bodyLarge,
                color = Mint.on.copy(alpha = 0.75f),
            )
            if (q.kind != EntryPrice.Kind.NORMAL) {
                val surge = q.kind == EntryPrice.Kind.SURGE
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .graphicsLayer {
                            val v = stamp.value
                            alpha = v
                            scaleX = 1.3f - 0.3f * v
                            scaleY = 1.3f - 0.3f * v
                            rotationZ = -4f * v
                        }
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (surge) Ink else Butter.fill)
                        .border(2.dp, Ink, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        if (surge) "SURGE 2×" else "HAPPY HOUR ½",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                        color = if (surge) Butter.fill else Ink,
                    )
                }
            }
            Spacer(Modifier.weight(1f))
            if (q.price != EntryPrice.BASE) {
                Text(
                    Currency.format(EntryPrice.BASE),
                    style = MaterialTheme.typography.bodyMedium.copy(
                        textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough,
                    ),
                    color = Mint.on.copy(alpha = 0.5f),
                )
                Spacer(Modifier.width(6.dp))
            }
            Text("−${Currency.format(q.price)}", style = MaterialTheme.typography.titleMedium, color = Mint.on)
        }
    }

    @Composable
    private fun PriceNote(kind: EntryPrice.Kind) {
        if (kind == EntryPrice.Kind.NORMAL) return
        Spacer(Modifier.height(8.dp))
        Text(
            if (kind == EntryPrice.Kind.SURGE)
                com.momentum.focus.data.tr("11 PM – 1 AM: scrolling costs double. Sleep is free.", "रात 11 – 1: स्क्रॉल का दाम डबल। नींद फ़्री है।")
            else
                com.momentum.focus.data.tr("You just studied — 10 minutes at half price. Earned it.", "अभी पढ़ाई की — 10 मिनट आधे दाम में। कमाया है।"),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            color = Mint.on,
        )
    }

    /**
     * The wait, made visible: seconds left, a hatched ink bar that drains at
     * the real pace (one linear tween, no loop), and which attempt this is.
     * Copy stays one line — the wait does the work, not a lecture.
     */
    @Composable
    private fun WaitMeter(left: Int, total: Int, attempt: Int, peak: Boolean = false) {
        val drain = remember { androidx.compose.animation.core.Animatable(1f) }
        LaunchedEffect(total) {
            drain.snapTo(1f)
            drain.animateTo(0f, androidx.compose.animation.core.tween(total * 1000, easing = androidx.compose.animation.core.LinearEasing))
        }
        // Breathe while you wait (Opal-style calm): an ink ring that swells
        // over 4 s and settles over 4 s, with one word. Slow on purpose —
        // the wait should feel like a pause, not a punishment. Still frame on
        // cheap phones (lowEndLoop).
        val breath by com.momentum.focus.ui.components.lowEndLoop(
            0f, 1f,
            androidx.compose.animation.core.infiniteRepeatable(
                androidx.compose.animation.core.tween(4000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
                androidx.compose.animation.core.RepeatMode.Reverse,
            ),
            "shield-breath",
        )
        val low = remember { com.momentum.focus.ui.util.DeviceProfile.isLowEnd(this@ShieldActivity) }
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                    val r = size.minDimension / 2f * (0.62f + 0.32f * breath)
                    drawCircle(Mint.fill.copy(alpha = 0.35f), r)
                    drawCircle(Ink, r, style = androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx()))
                }
                Text(
                    when {
                        low -> com.momentum.focus.data.tr("breathe", "साँस लो")
                        breath > 0.5f -> com.momentum.focus.data.tr("in", "अंदर")
                        else -> com.momentum.focus.data.tr("out", "बाहर")
                    },
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                    color = Ink,
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                com.momentum.focus.data.tr("Unlocking in ${left}s", "${left}s में खुलेगा"),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                color = Ink,
            )
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(12.dp)
                    .clip(RoundedCornerShape(50))
                    .background(com.momentum.focus.ui.theme.Sunk)
                    .border(2.dp, Ink, RoundedCornerShape(50))
                    .drawBehind {
                        val w = size.width * drain.value
                        drawRect(Tang.fill, size = androidx.compose.ui.geometry.Size(w, size.height))
                        // Ink hatch over the draining fill — the app's paper look.
                        val step = 7.dp.toPx()
                        var x = -size.height
                        while (x < w) {
                            drawLine(
                                Ink.copy(alpha = 0.22f),
                                androidx.compose.ui.geometry.Offset(x, size.height),
                                androidx.compose.ui.geometry.Offset(x + size.height, 0f),
                                strokeWidth = 1.5.dp.toPx(),
                            )
                            x += step
                        }
                    }
            )
            if (peak) {
                Spacer(Modifier.height(6.dp))
                Text(
                    com.momentum.focus.data.tr("Your danger hour · +5s", "तुम्हारा खतरे का घंटा · +5s"),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                    color = Tang.accent,
                )
            }
            if (attempt >= 2) {
                Spacer(Modifier.height(6.dp))
                Text(
                    com.momentum.focus.data.tr(
                        "Attempt #$attempt today · the wait grows 7s → 10s → 15s",
                        "आज कोशिश #$attempt · इंतज़ार बढ़ता है 7s → 10s → 15s",
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }

    @Composable
    private fun ReceiptRow(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                label,
                style = MaterialTheme.typography.bodyLarge,
                color = color.copy(alpha = 0.75f),
                modifier = Modifier.weight(1f),
            )
            Text(value, style = MaterialTheme.typography.titleMedium, color = color)
        }
    }

    private fun appLabel(pkg: String): String = runCatching {
        val info = packageManager.getApplicationInfo(pkg, 0)
        packageManager.getApplicationLabel(info).toString()
    }.getOrDefault(pkg)

    /** Send the user to the launcher rather than back into the blocked app. */
    private fun goHome() {
        val home = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(home)
        finish()
    }

    @Deprecated("Back must not dismiss the shield")
    override fun onBackPressed() {
        goHome()
    }
}
