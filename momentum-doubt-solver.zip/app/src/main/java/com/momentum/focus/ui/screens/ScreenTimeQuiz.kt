package com.momentum.focus.ui.screens

import androidx.compose.animation.slideInVertically
import androidx.compose.animation.fadeOut
import androidx.compose.animation.fadeIn
import androidx.compose.animation.togetherWith
import androidx.compose.animation.AnimatedContent
import com.momentum.focus.data.tr
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.Sfx
import kotlinx.coroutines.launch
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import com.momentum.focus.ui.components.RoastShareButton
import kotlinx.coroutines.delay
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.ScreenTimeReport
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.roundToInt

/**
 * The guess-then-reveal sequence.
 *
 * Asking for a guess before showing the truth is the entire mechanism. A
 * number shown cold gets shrugged off; the same number shown next to your own
 * underestimate is impossible to argue with, and nobody had to be lectured.
 */
@Composable
fun ScreenTimeQuiz(
    report: ScreenTimeReport,
    onDone: (guessHours: Int, guessPickups: Int) -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    var step by remember { mutableIntStateOf(0) }
    var guessHours by remember { mutableFloatStateOf(4f) }
    var guessPickups by remember { mutableFloatStateOf(60f) }

    val steps = 4

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 20.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(steps) { i ->
                val active = i == step
                val done = i < step
                Box(
                    Modifier
                        .height(6.dp)
                        .weight(1f)
                        .clip(RoundedCornerShape(50))
                        .background(when {
                            active -> Tang.fill
                            done -> Mint.fill
                            else -> Sunk
                        })
                        .border(if (active) 2.5.dp else 1.dp, Ink, RoundedCornerShape(50))
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        Box(Modifier.weight(1f)) {
            when (step) {
                0 -> GuessStep(
                    question = str.quiz.hoursQuestion,
                    value = guessHours,
                    range = 0f..12f,
                    display = str.quiz.hrs(guessHours.roundToInt()),
                    onChange = { guessHours = it },
                )
                1 -> GuessStep(
                    question = str.quiz.pickupsQuestion,
                    value = guessPickups,
                    range = 0f..300f,
                    display = str.quiz.pickups(guessPickups.roundToInt()),
                    onChange = { guessPickups = it },
                )
                2 -> ReportStep(report, guessHours.roundToInt(), guessPickups.roundToInt())
                3 -> ProjectionStep(report)
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            if (step > 0) {
                TextButton(
                    onClick = { step-- },
                    colors = ButtonDefaults.textButtonColors(contentColor = InkMid),
                    modifier = Modifier.wrapContentWidth(),
                ) { Text("← Back") }
            }
            SquishButton(
                label = if (step == steps - 1) str.quiz.wantItBack else str.quiz.continueLabel,
                sticker = if (step >= 2) Tang else Mint,
                modifier = Modifier.weight(1f),
            ) {
                haptics.confirm()
                if (step == steps - 1) onDone(guessHours.roundToInt(), guessPickups.roundToInt())
                else step++
            }
        }
    }
}

@Composable
private fun GuessStep(
    question: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    display: String,
    onChange: (Float) -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    // Heat 0..1 across the range drives colour, reaction and feel — the
    // slider should feel like it's pushing back as the number gets ugly.
    val heat = ((value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)
    val heatColor = when {
        heat < 0.25f -> androidx.compose.ui.graphics.lerp(Mint.accent, Butter.accent, heat / 0.25f)
        heat < 0.6f -> androidx.compose.ui.graphics.lerp(Butter.accent, Tang.accent, (heat - 0.25f) / 0.35f)
        else -> androidx.compose.ui.graphics.lerp(Tang.accent, Candy.accent, ((heat - 0.6f) / 0.4f).coerceIn(0f, 1f))
    }
    val pop = remember { androidx.compose.animation.core.Animatable(1f) }
    val scope = rememberCoroutineScope()
    var lastInt by remember { mutableIntStateOf(value.roundToInt()) }
    var lastSound by remember { mutableLongStateOf(0L) }
    val reaction = when {
        heat < 0.2f -> tr("Rookie numbers. Respect.", "बहुत कम। इज़्ज़त।")
        heat < 0.45f -> tr("Hmm. Being honest?", "हम्म। सच बोल रहे हो?")
        heat < 0.7f -> tr("That's a part-time job.", "ये तो पार्ट-टाइम नौकरी है।")
        else -> tr("Bro… that's a full shift.", "भाई… ये तो पूरी शिफ़्ट है।")
    }
    Column {
        Text(
            str.quiz.roughGuess,
            style = MaterialTheme.typography.labelSmall,
            color = InkMid,
        )
        Text(
            question,
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )

        Spacer(Modifier.height(40.dp))

        Text(
            display,
            style = MaterialTheme.typography.displayLarge,
            color = heatColor,
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer { scaleX = pop.value; scaleY = pop.value; rotationZ = (pop.value - 1f) * -20f },
            textAlign = TextAlign.Center,
        )
        AnimatedContent(
            targetState = reaction,
            transitionSpec = { (fadeIn(tween(180)) + slideInVertically(tween(180)) { it / 3 }) togetherWith fadeOut(tween(120)) },
            label = "reaction",
            modifier = Modifier.fillMaxWidth(),
        ) { r ->
            Text(r, style = MaterialTheme.typography.titleMedium, color = InkMid, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }

        Spacer(Modifier.height(20.dp))

        Slider(
            value = value,
            onValueChange = {
                onChange(it)
                // Feedback only on a real step, not every pixel of drag.
                val i = it.roundToInt()
                if (i != lastInt) {
                    lastInt = i
                    haptics.tick()
                    val now = System.currentTimeMillis()
                    if (now - lastSound > 55) { lastSound = now; Sfx.play(Sound.TICK) }
                    scope.launch {
                        pop.snapTo(1.14f)
                        pop.animateTo(1f, androidx.compose.animation.core.spring(dampingRatio = 0.45f, stiffness = 600f))
                    }
                }
            },
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Ink,
                activeTrackColor = heatColor,
                inactiveTrackColor = Sunk,
            ),
        )
    }
}

@Composable
private fun ReportStep(report: ScreenTimeReport, guessHours: Int, guessPickups: Int) {
    val str = strings()
    val avg = report.averageMinutes
    val peak = report.dailyMinutes.maxOrNull()?.coerceAtLeast(60) ?: 60

    Column(Modifier.verticalScroll(rememberScrollState())) {
        Text(str.quiz.last7Days, style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Text(str.quiz.heresTheTruth, style = MaterialTheme.typography.displayMedium, color = Ink)

        Spacer(Modifier.height(18.dp))

        GuessVsReal(
            guessLabel = str.quiz.youGuessedHours(guessHours),
            realLabel = "%02dh %02dm".format(avg / 60, avg % 60),
            caption = str.quiz.actualDailyAverage,
        )

        Spacer(Modifier.height(18.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .height(120.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            report.dailyMinutes.forEachIndexed { i, minutes ->
                val frac by animateFloatAsState(
                    minutes.toFloat() / peak, Motion.bouncy(), label = "d$i"
                )
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight(frac.coerceAtLeast(0.04f))
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (i == report.longestDayIndex) Tang.fill else Sky.fill)
                        .border(2.dp, Ink, RoundedCornerShape(6.dp))
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            str.quiz.longestDay(
                report.longestDayMinutes / 60, report.longestDayMinutes % 60
            ),
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
        )

        Spacer(Modifier.height(20.dp))

        GuessVsReal(
            guessLabel = str.quiz.youGuessedPickups(guessPickups),
            realLabel = "${report.pickups}x",
            caption = str.quiz.pickedUpYesterday,
        )

        if (report.topApps.isNotEmpty()) {
            Spacer(Modifier.height(22.dp))
            Text(str.quiz.topDistractions, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(10.dp))
            val worst = report.topApps.first().minutes.coerceAtLeast(1)
            report.topApps.forEach { app ->
                Column(Modifier.padding(bottom = 12.dp)) {
                    Row {
                        Text(
                            app.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = Ink,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            "%dh %02dm".format(app.minutes / 60, app.minutes % 60),
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMid,
                        )
                    }
                    Spacer(Modifier.height(5.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Sunk)
                            .border(2.dp, Ink, RoundedCornerShape(50))
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth((app.minutes.toFloat() / worst).coerceIn(0f, 1f))
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(50))
                                .background(Tang.fill)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GuessVsReal(guessLabel: String, realLabel: String, caption: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Box(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(Sunk)
                .border(2.dp, Ink, RoundedCornerShape(50))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(guessLabel, style = MaterialTheme.typography.bodyMedium, color = InkMid)
        }
        Spacer(Modifier.height(8.dp))
        Text(realLabel, style = MaterialTheme.typography.displayLarge, color = Ink)
        Text(caption, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}

@Composable
private fun ProjectionStep(report: ScreenTimeReport) {
    val str = strings()
    val years = report.yearsOverThirty
    val avg = report.averageMinutes
    val withApp = (avg * 0.2f).roundToInt()

    Column(
        Modifier.verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            str.quiz.aDay(avg / 60, avg % 60),
            style = MaterialTheme.typography.headlineSmall,
            color = Ink,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            str.quiz.years(years),
            style = MaterialTheme.typography.displayLarge,
            color = Tang.accent,
        )
        Text(
            str.quiz.ofYourLife,
            style = MaterialTheme.typography.bodyLarge,
            color = InkMid,
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.height(28.dp))

        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(16.dp)
        ) {
            Text(str.quiz.whatItCouldBe, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(12.dp))

            Bar(str.quiz.now, "%02dh %02dm".format(avg / 60, avg % 60), 1f, Tang)
            Spacer(Modifier.height(12.dp))
            Bar(str.quiz.target, "%02dh %02dm".format(withApp / 60, withApp % 60), 0.2f, Mint)

            Spacer(Modifier.height(12.dp))
            Text(
                str.quiz.targetNote,
                style = MaterialTheme.typography.bodyMedium,
                color = InkMid,
            )
        }

        // Screen Time Roast: the moment the number lands is the moment people
        // want to post it. Slides up once, after the projection has settled.
        val rise = remember { Animatable(0f) }
        LaunchedEffect(Unit) {
            delay(450)
            rise.animateTo(1f, tween(240, easing = FastOutSlowInEasing))
        }
        Spacer(Modifier.height(18.dp))
        RoastShareButton(
            report,
            Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    alpha = rise.value
                    translationY = (1f - rise.value) * 24.dp.toPx()
                },
        )
    }
}

@Composable
private fun Bar(label: String, value: String, fraction: Float, sticker: Sticker) {
    Column {
        Row {
            Text(
                label,
                style = MaterialTheme.typography.titleMedium,
                color = Ink,
                modifier = Modifier.weight(1f),
            )
            Text(value, style = MaterialTheme.typography.titleMedium, color = Ink)
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(18.dp)
                .clip(RoundedCornerShape(50))
                .background(Sunk)
                .border(2.dp, Ink, RoundedCornerShape(50))
        ) {
            Box(
                Modifier
                    .fillMaxWidth(fraction)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(50))
                    .background(sticker.fill)
            )
        }
    }
}
