package com.momentum.focus.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.ProMoment
import com.momentum.focus.data.tr
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics

/**
 * The Pro offer at a moment that earns it (see data/ProMoments.kt).
 *
 * Paper sheet on the frost scrim; rises once (240 ms) and a ink tag stamps
 * on (220 ms, after). One line of why-now, three real perks from the Plans
 * table, "See Pro" opens the same key-based Plans screen. "Later" is always
 * one tap — no countdown, no guilt copy.
 */
@Composable
fun ProMomentSheet(
    moment: ProMoment,
    data: AppData,
    onSeePro: () -> Unit,
    onLater: () -> Unit,
) {
    val haptics = rememberHaptics()
    val rise = remember { Animatable(0f) }
    val stamp = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        rise.animateTo(1f, tween(240, easing = FastOutSlowInEasing))
        stamp.animateTo(1f, tween(220, easing = FastOutSlowInEasing))
    }

    BackHandler { onLater() }
    val deep = moment == ProMoment.DEEP_SESSION
    val tag = if (deep) tr("50 MIN · LOCKED IN", "50 मिनट · लॉक्ड इन")
              else tr("${data.daysToExam ?: 30} DAYS LEFT", "${data.daysToExam ?: 30} दिन बाकी")
    val title = if (deep) tr("That was a Pro-level sit.", "ये Pro लेवल की पढ़ाई थी।")
                else tr("${data.examName.ifBlank { "Exam" }} is close. Go all in.", "${data.examName.ifBlank { "एग्ज़ाम" }} पास है। पूरा ज़ोर लगाओ।")
    val line = if (deep) tr("Keep that energy: more doubts per session, photo & PDF doubts, mock drills.",
                            "यही एनर्जी रखो: हर सेशन ज़्यादा डाउट, फ़ोटो और PDF से डाउट, मॉक ड्रिल।")
               else tr("Crown mode locks uninstall till the exam. Plus mock drills from your own pages.",
                       "Crown मोड एग्ज़ाम तक अनइंस्टॉल लॉक करता है। साथ में अपने पेज से मॉक ड्रिल।")
    val perks = if (deep) listOf(tr("More doubts", "ज़्यादा डाउट"), tr("Photo + PDF", "फ़ोटो + PDF"), tr("Mock test", "मॉक टेस्ट"))
                else listOf(tr("Crown mode", "Crown मोड"), tr("Mock test", "मॉक टेस्ट"), tr("All themes", "सारे थीम"))

    FrostScrim {
        Box(
            Modifier.fillMaxSize().padding(horizontal = Paper.ScreenPad),
            contentAlignment = Alignment.BottomCenter,
        ) {
            FrostSheet(
                Modifier
                    .navigationBarsPadding()
                    .padding(bottom = 24.dp)
                    .graphicsLayer {
                        alpha = rise.value
                        translationY = (1f - rise.value) * 40.dp.toPx()
                    },
            ) {
                Column(Modifier.padding(20.dp)) {
                    Box(
                        Modifier
                            .graphicsLayer {
                                val v = stamp.value
                                alpha = v
                                scaleX = 1.25f - 0.25f * v
                                scaleY = 1.25f - 0.25f * v
                                rotationZ = -3f * v
                            }
                            .clip(RoundedCornerShape(8.dp))
                            .background(Ink)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(tag, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, color = Butter.fill)
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, color = Ink)
                    Spacer(Modifier.height(6.dp))
                    Text(line, style = MaterialTheme.typography.bodyMedium, color = Ink.copy(alpha = 0.72f))
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        perks.forEachIndexed { i, p ->
                            val st = listOf(Mint, Sky, Lilac)[i]
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(st.fill)
                                    .border(2.dp, Ink, RoundedCornerShape(50))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) { Text(p, style = MaterialTheme.typography.labelSmall, color = st.on) }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    SquishButton(
                        label = tr("See Pro", "Pro देखो"),
                        sticker = Butter,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        haptics.confirm(); Sfx.play(Sound.POP); onSeePro()
                    }
                    TextButton(onClick = onLater, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Text(tr("Later", "बाद में"), color = InkMid)
                    }
                }
            }
        }
    }
}
