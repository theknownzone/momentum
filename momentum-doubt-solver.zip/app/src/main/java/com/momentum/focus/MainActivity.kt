package com.momentum.focus

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.focus.ai.Ai
import com.momentum.focus.ai.Doubt
import com.momentum.focus.ui.AppViewModel
import com.momentum.focus.ui.nav.PaperBottomBar
import com.momentum.focus.ui.nav.Tab
import com.momentum.focus.ui.screens.*
import com.momentum.focus.ui.screens.Changelog
import com.momentum.focus.ui.i18n.Lang
import com.momentum.focus.ui.theme.MomentumTheme
import com.momentum.focus.ui.theme.Skin
import com.momentum.focus.ui.theme.skinFor
import com.momentum.focus.ui.util.CrashReporter
import com.momentum.focus.block.BlockerService
import com.momentum.focus.data.ScreenTime
import com.momentum.focus.data.achievements
import com.momentum.focus.ui.components.TourOverlay
import com.momentum.focus.ui.components.StreakWeekRow
import com.momentum.focus.ui.components.UnlockReceipt
import com.momentum.focus.ui.components.MockSheet
import com.momentum.focus.ui.components.shapeOnly
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.SystemVoice
import com.momentum.focus.ui.util.StudyNudge
import com.momentum.focus.ui.util.ShakeToPanic
import com.momentum.focus.ui.util.rememberHaptics

/**
 * Where the buy button sends people.
 *
 * Payment happens off-device on purpose. A sideloaded build cannot use Play
 * Billing, and wiring a card form into the app would mean handling money and
 * PCI scope for a student project. The store page issues a licence key, the
 * key unlocks the app offline, and nothing sensitive ever touches this code.
 *
 * The real URL is injected at build time as `store.url` / `MOMENTUM_STORE_URL`.
 */
/** Paper cream, matching windowBackground in themes.xml. */
private const val PAPER_ARGB = 0xFFFBF3D5.toInt()

// Injected with MOMENTUM_STORE_URL / local.properties `store.url`.
// A fake URL is worse than a disabled purchase button: it looks functional and
// sends a buyer to a dead page.

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) {
            Sfx.release()
            // The engine holds a service connection. Left open it survives the
            // activity and shows up as a leak.
            SystemVoice.release()
        }
    }

    /**
     * Keeps the notification working when the app is already open.
     *
     * With singleTop, a second launch reuses this instance and the original
     * intent never changes — so the effect below would read a stale action and
     * the offer would silently do nothing for anyone who had the app in the
     * background. Storing the flag here is what makes the tap behave the same
     * whether the app was running or not.
     */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == StudyNudge.ACTION_START) startRequested = true
    }

    private var startRequested by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashReporter.install(applicationContext)
        Sfx.init(applicationContext)
        val startupCrash = CrashReporter.lastCrash(this)
        // Explicit light styling on both bars. The no-argument form uses
        // SystemBarStyle.auto, which follows the system's dark mode — so on a
        // phone with dark mode on, the status and navigation icons flipped to
        // light and became nearly invisible against cream paper. The app has
        // one palette and the bars should match it, not the system's mood.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(PAPER_ARGB, PAPER_ARGB),
            navigationBarStyle = SystemBarStyle.light(PAPER_ARGB, PAPER_ARGB),
        )

        setContent {
            // Hoisted above the theme so the chosen skin can colour it. Read
            // inside, it could only ever tint what sat below the one screen
            // that happened to look it up.
            val loaded by vm.data.collectAsStateWithLifecycle()
            MomentumTheme(
                skin = loaded?.let { skinFor(it.skin) } ?: Skin.SAKURA,
                lang = Lang.from(loaded?.lang ?: ""),
            ) {

                var splashDone by remember { mutableStateOf(false) }
                // The splash also covers the DataStore read, so there is never
                // a frame where the app is guessing what state it is in.
                if (!splashDone || loaded == null) {
                    SplashScreen { splashDone = true }
                    return@MomentumTheme
                }
                val data = loaded!!
                // The stored preference is the truth; Sfx only holds a copy for
                // the life of the process, so it has to be told on every launch
                // or the switch reads on while nothing plays.
                LaunchedEffect(data.soundOn) { Sfx.enabled = data.soundOn }

                var crash by remember { mutableStateOf(startupCrash) }
                val shownCrash = crash
                if (shownCrash != null) {
                    CrashScreen(trace = shownCrash) {
                        CrashReporter.clear(this@MainActivity)
                        crash = null
                    }
                    return@MomentumTheme
                }

                val timer by vm.timer.collectAsStateWithLifecycle()
                val finished by vm.sessionFinished.collectAsStateWithLifecycle()
                val haptics = rememberHaptics()

                var tab by remember { mutableStateOf(Tab.HOME) }
                var celebratePremium by remember { mutableStateOf(false) }
                // The receipt used to just dismiss straight back to Plans
                // when it finished — no "you're in" moment, just the printer
                // sequence ending and the screen behind it reappearing. This
                // sequences a proper welcome after the receipt lifts away,
                // the same two-step onboarding already does with setupWon
                // after BlockListScreen.
                var premiumWelcome by remember { mutableStateOf(false) }
                                var panicOpen by remember { mutableStateOf(false) }
                var profileOpen by remember { mutableStateOf(false) }
                var permsOpen by remember { mutableStateOf(false) }
                var blockListOpen by remember { mutableStateOf(false) }
                var plansOpen by remember { mutableStateOf(false) }
                var settingsOpen by remember { mutableStateOf(false) }
                var mockOpen by remember { mutableStateOf(false) }
                var mockFromPage by remember { mutableStateOf(false) }
                var changelogOpen by remember { mutableStateOf(false) }
                var supportOpen by remember { mutableStateOf(false) }
                var feedGuardOpen by remember { mutableStateOf(false) }
                var profilesOpen by remember { mutableStateOf(false) }
                var blockHubOpen by remember { mutableStateOf(false) }
                var permsRecheck by remember { mutableIntStateOf(0) }
                val permsStillGranted = remember(permsRecheck, data.onboarded) {
                    !data.onboarded || Perms.allRequiredGranted(this@MainActivity)
                }
                DisposableEffect(Unit) {
                    val obs = LifecycleEventObserver { _, e ->
                        if (e == Lifecycle.Event.ON_RESUME) permsRecheck++
                    }
                    lifecycle.addObserver(obs)
                    onDispose { lifecycle.removeObserver(obs) }
                }

                // Shown once per version: if the installed build is newer than
                // the one last acknowledged, the changelog comes up first.
                val version = remember { Updater.currentVersion(this@MainActivity) }
                var newsOpen by remember(data.lastSeenVersion, data.lastSeenChangelog, version) {
                    mutableStateOf(
                        data.onboarded && (
                            data.lastSeenVersion != version ||
                                data.lastSeenChangelog < Changelog.LATEST
                            )
                    )
                }

                // The service only ever runs with the user's current choices,
                // so both the list and the on/off switch push straight into it.
                // Keyed on the whole snapshot, not a hand-written list of
                // fields. The list had drifted out of date twice: dailyCaps,
                // streakDays and classDays were all pushed into the service
                // from inside this block while none of them was a key, so
                // changing a per-app cap left the service running on the old
                // one until some unrelated field happened to change. The body
                // is a handful of assignments, so re-running it on any change
                // costs nothing and this class of bug cannot come back.
                LaunchedEffect(data, timer.running) {
                    // Seeding only at onboarding meant every install that
                    // already existed kept an empty surface set forever, so the
                    // guard ran and matched nothing. Seeding is idempotent.
                    if (data.onboarded && !data.surfacesSeeded) vm.seedSurfaces()
                    BlockerService.blocked = data.blockedPackages
                    BlockerService.dailyCaps = data.dailyCapMinutes
                    BlockerService.balanceMinutes = data.balanceMinutes
                    BlockerService.earnedTodayMinutes = data.minutesToday
                    BlockerService.streakDays = data.streakDays
                    BlockerService.studyPackages = data.studyPackages
                    BlockerService.sessionRunning = timer.running
                    BlockerService.pactLive = data.pactLive
                    BlockerService.crownActive = data.focusLevel >= 3 && data.crownMode
                    // Clears the offer the moment a session starts, so the
                    // notification cannot sit there suggesting something the
                    // user has already done.
                    if (timer.running) StudyNudge.clear(this@MainActivity)
                    val hourNow = java.time.LocalTime.now().hour
                    val dayNow = java.time.LocalDate.now().dayOfWeek.value
                    val inClass = data.classHoursOn &&
                        dayNow in data.classDays &&
                        hourNow >= data.classStartHour && hourNow < data.classEndHour
                    val shieldNow = data.shieldOn || (inClass && data.focusLevel >= 2)
                    if (shieldNow && data.blockedPackages.isNotEmpty() &&
                        Perms.allRequiredGranted(this@MainActivity)
                    ) {
                        BlockerService.start(this@MainActivity)
                    } else {
                        BlockerService.stop(this@MainActivity)
                    }
                }

                // Onboarding is two stages: explain the idea, then ask for the
                // permissions. Asking first, before anyone knows what the app
                // does, is how permission prompts get denied.
                var explained by remember(data.onboarded) { mutableStateOf(data.onboarded) }

                var sessionWon by remember { mutableStateOf(false) }
                LaunchedEffect(finished) {
                    if (finished > 0) {
                        haptics.sessionComplete()
                        sessionWon = true
                        vm.consumeSessionFinished()
                    }
                }

                // Streak count itself, not a boolean — 0 means nothing to
                // show. Held separately from sessionWon so the two screens
                // can queue one after the other instead of one clobbering
                // the other when a session both pays and extends the streak,
                // which is the common case.
                val streakUp by vm.streakUp.collectAsStateWithLifecycle()
                var streakWon by remember { mutableStateOf(false) }
                var streakCount by remember { mutableIntStateOf(0) }
                LaunchedEffect(streakUp) {
                    if (streakUp > 0) {
                        streakCount = streakUp
                        streakWon = true
                        // Consumed immediately, not when the screen is
                        // dismissed. The count it carried is already latched
                        // into streakCount above, and leaving the signal set
                        // means any recomposition that restarts this effect
                        // replays a celebration that has already happened.
                        vm.consumeStreakUp()
                    }
                }

                LaunchedEffect(Unit) { vm.stampFirstOpen() }

                // The notification promised a timer, so tapping it has to start
                // one. Opening the app to the Focus tab with the clock still
                // stopped would be the offer not keeping its word.
                LaunchedEffect(startRequested) {
                    val cold = intent?.action == StudyNudge.ACTION_START
                    if (cold || startRequested) {
                        intent?.action = null
                        startRequested = false
                        StudyNudge.clear(this@MainActivity)
                        tab = Tab.FOCUS
                        if (!vm.timer.value.running) vm.toggleTimer()
                    }
                }

                // Before every other full-screen gate: a celebration or a
                // reflection prompt makes no sense to someone who has not been
                // told what the app does yet.
                if (data.onboarded && !data.tourSeen) {
                    TourOverlay { vm.markTourSeen() }
                    return@MomentumTheme
                }

                // Shake twice to reach panic from anywhere. During a craving
                // nobody navigates menus, and the gesture works with the screen
                // barely looked at.
                ShakeToPanic(enabled = !panicOpen) {
                    haptics.press()
                    panicOpen = true
                }

                // The receipt and the welcome after it were sitting inside
                // the Scaffold's own padded content box, the same one every
                // tab screen scrolls inside. That box pads its top edge by
                // the status-bar inset before painting its background, so
                // the receipt's own full-bleed black only ever reached from
                // there down — the inset strip above it kept showing the
                // Scaffold's cream containerColor straight through a screen
                // that is supposed to read as a dim, dedicated print bay.
                // sessionWon and streakWon below already dodge this by
                // returning before the Scaffold exists at all; this joins
                // them for the same reason.
                if (celebratePremium) {
                    // The receipt, not the old fade-and-scale card.
                    //
                    // A licence is a purchase. PremiumIntro was a logo
                    // pulsing on cream — pleasant, and it handed back
                    // nothing. This prints a slip with the key on it
                    // and writes a copy to Downloads, so the moment
                    // leaves behind a record the buyer actually keeps.
                    UnlockReceipt(data = data) {
                        celebratePremium = false
                        premiumWelcome = true
                    }
                    return@MomentumTheme
                }
                if (premiumWelcome) {
                    // The actual "you're in" moment, held on its own screen
                    // rather than folded into the receipt's last frame —
                    // same shout-and-confetti beat every other reward in
                    // this app gets.
                    CelebrationScreen(
                        kicker = "PREMIUM",
                        title = "Welcome to Momentum Premium.",
                        body = "Every theme, the AI, and the crown are yours now. Blocking was always free — this is everything else.",
                        colorIndex = 1,
                        shapeIndex = shapeOnly(1),
                    ) { premiumWelcome = false }
                    return@MomentumTheme
                }

                // Finishing a session is the behaviour the whole app exists to
                // produce, so it gets the loud screen too.
                if (sessionWon) {
                    CelebrationScreen(
                        kicker = "SESSION BANKED",
                        title = "+₹${(timer.totalSeconds / 60) / data.effectiveRatio.coerceAtLeast(1)}",
                        body = "${timer.totalSeconds / 60} min studied. In the wallet now.",
                        colorIndex = 0,
                        shapeIndex = shapeOnly(0),
                    ) { sessionWon = false }
                    return@MomentumTheme
                }

                // Checked after sessionWon, not instead of it — a session that
                // both pays and pushes the streak forward shows the money
                // first and the streak second, one screen at a time, rather
                // than trying to say both things at once.
                if (streakWon) {
                    CelebrationScreen(
                        kicker = "STREAK",
                        title = "$streakCount",
                        body = if (streakCount == 1) "Day streak. Day one starts here." else "Days streak. The compound effect is real.",
                        colorIndex = 2,
                        shapeIndex = shapeOnly(2),
                        extra = { StreakWeekRow(data) },
                    ) { streakWon = false }
                    return@MomentumTheme
                }

                // Reward first, honesty second, then the app.
                val badges = remember(data) { data.achievements().count { it.unlocked } }
                if (data.onboarded && data.level > data.lastCelebratedLevel) {
                    CelebrationScreen(
                        kicker = "LEVEL UP",
                        title = "Level ${data.level}",
                        body = "Every minute of this was earned. Nobody handed it to you.",
                        colorIndex = data.avatarColor,
                        shapeIndex = data.avatarShape,
                    ) { vm.markCelebrated(data.level, badges) }
                    return@MomentumTheme
                }
                // Which badge was just earned cannot be read off a count, and
                // achievements() is ordered by theme rather than by when it
                // unlocks — so last { it.unlocked } was picking whichever badge
                // happened to sit lowest in the list, not the new one.
                val unlocked = remember(data) { data.achievements().filter { it.unlocked } }
                val seeded = data.celebratedBadgeIds.isNotEmpty() ||
                    data.lastCelebratedBadges == 0
                LaunchedEffect(seeded) {
                    if (!seeded) vm.seedCelebratedBadges(unlocked.map { it.id }.toSet())
                }
                val newest = if (!seeded) null
                    else unlocked.firstOrNull { it.id !in data.celebratedBadgeIds }
                if (data.onboarded && newest != null) {
                    CelebrationScreen(
                        kicker = "${newest.tier.label} UNLOCKED",
                        title = newest.title,
                        body = newest.reward,
                        colorIndex = newest.tier.ordinal + 1,
                        shapeIndex = shapeOnly(newest.tier.ordinal),
                    ) { vm.markBadgeCelebrated(newest.id, badges) }
                    return@MomentumTheme
                }

                if (data.onboarded && data.pendingReflectionMinutes > 0) {
                    SlipReflectionScreen(
                        minutes = data.pendingReflectionMinutes,
                        onAnswer = vm::logSlip,
                        onSkip = vm::skipReflection,
                    )
                    return@MomentumTheme
                }

                if (!explained) {
                    WelcomeScreen { name ->
                        if (name.isNotBlank()) vm.setName(name)
                        explained = true
                    }
                    return@MomentumTheme
                }

                if (!data.onboarded) {
                    // Order matters. Permissions first, because without usage
                    // access there is no real data and the quiz has nothing to
                    // reveal. Then guess-then-truth. Then pick the apps, once
                    // the person has just seen which ones cost them most.
                    var permsDone by remember { mutableStateOf(false) }
                    var quizDone by remember { mutableStateOf(false) }
                    // The whole flow — welcome, permissions, quiz, app picks —
                    // used to end by just... landing on Home, mid-scroll, with
                    // nothing marking the moment. Every other win in this app
                    // gets the loud CelebrationScreen; finishing setup itself
                    // was the one exception, which is backwards for the app
                    // whose entire pitch is that finishing things pays off.
                    var setupWon by remember { mutableStateOf(false) }

                    when {
                        !permsDone -> PermissionsScreen(onDone = { permsDone = true })

                        !quizDone -> {
                            val report = remember {
                                ScreenTime.report(this@MainActivity)
                            }
                            if (!report.hasData) {
                                // No usage access granted, so skip rather than
                                // show a screen full of zeroes.
                                LaunchedEffect(Unit) { quizDone = true }
                            } else {
                                ScreenTimeQuiz(report) { hours, picks ->
                                    vm.saveBaseline(hours, picks, report.averageMinutes)
                                    quizDone = true
                                }
                            }
                        }

                        setupWon -> CelebrationScreen(
                            kicker = "SHIELD UP",
                            title = "You're set.",
                            body = "Distractions are blocked, the timer's ready. " +
                                "First session whenever you are.",
                            colorIndex = 0,
                            shapeIndex = shapeOnly(3),
                        ) {
                            vm.completeOnboarding()
                        }

                        else -> BlockListScreen(
                            data = data,
                            preselectTop = true,
                            onToggle = vm::toggleBlocked,
                            onCap = vm::setDailyCap,
                            onDone = {
                                vm.setShield(true)
                                vm.seedStudyApps()
                                vm.seedSurfaces()
                                vm.markVersionSeen(version, Changelog.LATEST)
                                setupWon = true
                            },
                        )
                    }
                    return@MomentumTheme
                }

                // The changelog no longer stands in front of the app.
                //
                // It used to open full screen on every update and return early
                // from the whole tree, so the first thing after installing was
                // a wall of release notes and a Got it button somewhere past
                // the fold. Nobody reads that. They scroll to the bottom and
                // dismiss it, which means the one update that mattered got the
                // same treatment as the twenty that did not.
                //
                // It is a strip at the top of Home now, dismissed in place, and
                // the full log is still in Settings for anyone who wants it.

                // Full-screen modes deliberately hide the tab bar: during a
                // craving or a settings edit there is nowhere else to go.
                val fullScreen = panicOpen || profileOpen || settingsOpen || permsOpen ||
                    blockListOpen || feedGuardOpen || profilesOpen || blockHubOpen ||
                    plansOpen || changelogOpen || supportOpen

                // Back was doing nothing on every overlay, so the only way out
                // of Profile was to kill the app. Innermost layer closes first.
                BackHandler(enabled = fullScreen) {
                    when {
                        // Order matters and mirrors how deep each screen is:
                        // a child closes back to the hub, and the hub closes
                        // last. Duplicated branches here would be dead code
                        // and would strand the user one level down.
                        permsOpen -> permsOpen = false
                        supportOpen -> supportOpen = false
                        changelogOpen -> changelogOpen = false
                        plansOpen -> plansOpen = false
                        blockListOpen -> blockListOpen = false
                        feedGuardOpen -> feedGuardOpen = false
                        profilesOpen -> profilesOpen = false
                        blockHubOpen -> blockHubOpen = false
                        settingsOpen -> settingsOpen = false
                        profileOpen -> profileOpen = false
                        panicOpen -> panicOpen = false
                    }
                }

                // On a tab other than Home, back returns Home rather than
                // dropping the user out of the app entirely.
                BackHandler(enabled = !fullScreen && tab != Tab.HOME) {
                    tab = Tab.HOME
                }

                val density = LocalDensity.current
                val imeVisible = WindowInsets.ime.getBottom(density) > 0
                // MyAi takes the whole screen. The tab bar was eating eighty
                // pixels off the bottom of a conversation and the thread is the
                // one screen in this app that is only ever too short. The way
                // out is the back arrow in its own header, which is where the
                // apps this is modelled on put it.
                val hideBar = tab == Tab.MYAI

                // The bar gets out of the way while you are reading down a
                // screen, and comes back the moment you scroll up.
                //
                // Five tabs plus their padding is about eighty pixels held
                // permanently, on screens — Stats, Plans, the notice feed —
                // that are only ever too short. Scrolling down is the one
                // gesture that reliably means "I am reading, not navigating",
                // so it is the right moment to hand the space back.
                var barVisible by remember { mutableStateOf(true) }
                // A tab change always brings it back. Landing on a new screen
                // with no way to leave it would be a trap, and the state is
                // otherwise sticky across the switch.
                LaunchedEffect(tab) { barVisible = true }
                val barScroll = remember {
                    object : NestedScrollConnection {
                        override fun onPreScroll(
                            available: Offset,
                            source: NestedScrollSource,
                        ): Offset {
                            // A threshold, not a sign test. Every list emits
                            // tiny deltas in both directions while a finger
                            // rests on it, and reacting to those makes the bar
                            // flicker on and off under the thumb.
                            if (available.y < -8f) barVisible = false
                            if (available.y > 8f) barVisible = true
                            return Offset.Zero
                        }
                    }
                }
                Scaffold(
                    bottomBar = {
                        // Two different reasons to be gone, and only one of
                        // them animates.
                        //
                        // MyAi and the full-screen states drop the bar outright,
                        // in the same frame as the screen changes. Sliding it
                        // out instead leaves a tab bar sitting on top of the
                        // chat composer for a third of a second every time the
                        // tab is opened — which is the bar-over-the-thread
                        // frame in the recording.
                        //
                        // The scroll-driven hide is the one worth animating: it
                        // happens under the thumb, on a screen that is not
                        // changing, and a bar that vanishes without moving
                        // there reads as a glitch rather than as a choice.
                        if (!fullScreen && !hideBar) {
                            AnimatedVisibility(
                                visible = barVisible,
                                enter = slideInVertically { it } + fadeIn(),
                                exit = slideOutVertically { it } + fadeOut(),
                            ) {
                                PaperBottomBar(current = tab, onSelect = { tab = it })
                            }
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.background,
                ) { padding ->
                    // MyAi: keep bar padding while the bar is on screen.
                    // Only drop the bottom inset when the keyboard hid the bar,
                    // otherwise the composer sits under the tabs.
                    val contentPad = if (hideBar) {
                        PaddingValues(
                            start = padding.calculateStartPadding(androidx.compose.ui.unit.LayoutDirection.Ltr),
                            end = padding.calculateEndPadding(androidx.compose.ui.unit.LayoutDirection.Ltr),
                            top = padding.calculateTopPadding(),
                            bottom = 0.dp,
                        )
                    } else padding
                    Box(
                        Modifier
                            .fillMaxSize()
                            // Every screen inside here scrolls with its own
                            // verticalScroll or LazyColumn, and each of those
                            // offers its delta to this connection before
                            // consuming it. Listening once at the top means the
                            // bar reacts to all of them without a single screen
                            // having to know the bar exists.
                            .nestedScroll(barScroll)
                            .padding(contentPad)
                            .background(MaterialTheme.colorScheme.background)
                    ) {
                        when {
                            // Revoking usage access or overlay after setup left
                            // the shield dead and the app cheerfully pretending
                            // otherwise. Grants are re-checked on every resume,
                            // and a missing one puts this screen back in front
                            // of everything until it is fixed.
                            !permsStillGranted -> PermissionsScreen(
                                onDone = { permsRecheck++ }
                            )

                            permsOpen -> PermissionsScreen(onDone = { permsOpen = false })

                            profilesOpen -> ProfilesScreen(
                                data = data,
                                onSave = vm::saveProfile,
                                onApply = vm::applyProfile,
                                onDelete = vm::deleteProfile,
                                onDone = { profilesOpen = false },
                            )

                            feedGuardOpen -> FeedGuardScreen(
                                data = data,
                                onToggleSurface = vm::toggleSurface,
                                onStudyOnly = vm::toggleStudyOnly,
                                onAddChannel = vm::addChannel,
                                onRemoveChannel = vm::removeChannel,
                                onDone = { feedGuardOpen = false },
                            )

                            supportOpen -> SupportScreen(
                                data = data,
                                onDone = { supportOpen = false },
                            )

                            changelogOpen -> WhatsNewScreen(version = version) {
                                changelogOpen = false
                            }

                            plansOpen -> PlansScreen(
                                data = data,
                                // Buying happens outside the app. Sideloaded
                                // builds cannot use Play Billing, so the button
                                // hands off to the store page and the buyer
                                // comes back with a key.
                                onBuy = {
                                    val url = BuildConfig.STORE_URL.trim()
                                    if (url.startsWith("https://") || url.startsWith("http://")) {
                                        runCatching {
                                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                        }
                                    }
                                },
                                onRedeem = { key ->
                                    val ok = vm.redeem(key)
                                    if (ok) celebratePremium = true
                                    ok
                                },
                                onRemove = { vm.clearLicense() },
                                onDone = { plansOpen = false },
                            )

                            blockListOpen -> BlockListScreen(
                                data = data,
                                onToggle = vm::toggleBlocked,
                                editLock = vm.blockEditLock(),
                                onCap = vm::setDailyCap,
                                onDone = { blockListOpen = false },
                            )

                            // Below its children on purpose. The hub stays
                            // open underneath while one of them is showing, so
                            // matching it first meant tapping a row set the
                            // child's flag and nothing changed on screen.
                            blockHubOpen -> BlockHubScreen(
                                data = data,
                                onApps = { blockListOpen = true },
                                onFeeds = { feedGuardOpen = true },
                                onProfiles = { profilesOpen = true },
                                onSchedule = { blockHubOpen = false; profileOpen = true },
                                onDone = { blockHubOpen = false },
                            )

                            // Settings before Profile, and the order is the
                            // whole fix. Settings is opened *from* Profile, so
                            // profileOpen is still true when it opens — with
                            // Profile's branch first this when matched it every
                            // time and Settings was unreachable. It compiled,
                            // scan passed, and the button did nothing.
                            settingsOpen -> SettingsScreen(
                                data = data,
                                onSound = vm::setSound,
                                onNotify = vm::setNotify,
                                onRatio = vm::setEarnRatio,
                                onExam = vm::setExam,
                                onWeekend = vm::setWeekendRelaxed,
                                onGoal = vm::setGoal,
                                onPermissions = { permsOpen = true },
                                onChangelog = { changelogOpen = true },
                                onSupport = { supportOpen = true },
                                onBlockList = { blockHubOpen = true },
                                onShield = vm::setShield,
                                onSubjects = vm::setSubjects,
                                onClassHours = vm::setClassHours,
                                onClassDay = vm::toggleClassDay,
                                onName = vm::setName,
                                onLang = vm::setLang,
                                onBack = { settingsOpen = false },
                            )

                            profileOpen -> ProfileScreen(
                                data = data,
                                onCrown = vm::setCrown,
                                onAvatar = vm::setAvatar,
                                onSkin = vm::setSkin,
                                onPlans = { plansOpen = true },
                                onSettings = { settingsOpen = true },
                            )

                            panicOpen -> PanicScreen(
                                onSurvived = { vm.logUrge(survived = true) },
                                onRelapsed = { vm.logUrge(survived = false); vm.resetStreak() },
                                onDone = { panicOpen = false },
                            )

                            tab == Tab.HOME -> HomeScreen(
                                data = data,
                                onStartFocus = { tab = Tab.FOCUS },
                                onPanic = { panicOpen = true },
                                onJournal = { tab = Tab.JOURNAL },
                                onProfile = { profileOpen = true },
                                onShield = { blockHubOpen = true },
                                onFeeds = { blockHubOpen = true },
                                onRewards = { tab = Tab.REWARDS },
                                onNotify = vm::setNotify,
                                onPerms = { permsOpen = true },
                                updatedVersion = version.takeIf { newsOpen },
                                onOpenChangelog = { changelogOpen = true },
                                onDismissUpdate = {
                                    vm.markVersionSeen(version, Changelog.LATEST)
                                    newsOpen = false
                                },
                            )

                            tab == Tab.FOCUS -> {
                                FocusScreen(
                                    data = data,
                                    timer = timer,
                                    onToggle = vm::toggleTimer,
                                    onAbandon = vm::abandon,
                                    onDuration = vm::setDuration,
                                    onSubject = vm::setSubject,
                                    onFocusLevel = vm::setFocusLevel,
                                    onCrown = vm::setCrown,
                                    premium = data.premium,
                                    onPlans = { plansOpen = true },
                                    onToggleStudy = vm::toggleStudyApp,
                                    onExtendPact = vm::extendPact,
                                    onSubjects = vm::setSubjects,
                                    startBlocked = vm.startBlocked(),
                                    onCrownIntroSeen = vm::markCrownIntroSeen,
                                )
                            }

                            tab == Tab.MYAI -> {
                                val doubt by vm.doubt.collectAsStateWithLifecycle()
                                val mode by vm.myAiMode.collectAsStateWithLifecycle()
                                val pulse by vm.pulse.collectAsStateWithLifecycle()
                                androidx.compose.runtime.LaunchedEffect(tab, data.sessions.size) {
                                    vm.refreshPulse()
                                }
                                MyAiScreen(
                                    state = if (Ai.enabled) {
                                        doubt.copy(left = Doubt.left(data.doubtsUsed, data.premium))
                                    } else {
                                        doubt.copy(left = 0)
                                    },
                                    clock = if (timer.running) timer.label else null,
                                    mode = mode,
                                    onMode = vm::setMyAiMode,
                                    pulse = pulse,
                                    onAsk = { q, imgs, carried ->
                                        vm.askDoubt(q, imgs.firstOrNull(), imgs.drop(1), carried)
                                    },
                                    onRetry = vm::retryDoubt,
                                    onStop = vm::stopDoubt,
                                    onClose = { tab = Tab.HOME },
                                    premium = data.premium,
                                    onPlans = { plansOpen = true },
                                    name = data.userName,
                                    onMock = if (Ai.enabled) {
                                        { page ->
                                            mockFromPage = page != null
                                            mockOpen = true
                                            // A page is its own brief — the
                                            // questions come from what is on
                                            // it, so there is nothing to pick.
                                            // Without one the sheet asks first
                                            // instead of guessing, which is
                                            // what used to hand a Maths
                                            // student a Biology paper.
                                            if (page != null) vm.startMock(page)
                                        }
                                    } else {
                                        null
                                    },
                                )
                            }

                            tab == Tab.WALLET -> WalletScreen(
                                data = data,
                                onEarn = { tab = Tab.FOCUS },
                            )

                            tab == Tab.STATS -> {
                                val coachBusy by vm.coachBusy.collectAsStateWithLifecycle()
                                val coachError by vm.coachError.collectAsStateWithLifecycle()
                                StatsScreen(
                                    data = data,
                                    coachBusy = coachBusy,
                                    coachError = coachError,
                                    onRunCoach = { vm.runCoach(force = true) },
                                )
                            }

                            tab == Tab.REWARDS -> AchievementsScreen(data = data)

                            tab == Tab.JOURNAL -> JournalScreen(
                                data = data,
                                onSave = vm::saveJournal,
                            )
                        }
                        if (mockOpen) {
                            val mock by vm.mock.collectAsStateWithLifecycle()
                            MockSheet(
                                state = mock,
                                // A page only counts as the source if one was
                                // actually attached when the drill was asked for.
                                fromPage = mock.items.isNotEmpty() && mockFromPage,
                                subjects = data.subjects.filter { it.isNotBlank() },
                                awaitingPick = !mockFromPage,
                                weakest = data.weakestDrill,
                                onChoose = vm::chooseMock,
                                onSubmit = vm::submitMock,
                                onBuild = { subject, topic ->
                                    vm.startMock(null, subject, topic)
                                },
                                onAgain = { vm.clearMock(); mockFromPage = false },
                                onClose = { mockOpen = false; vm.clearMock() },
                            )
                        }
                    }
                }
            }
        }
    }
}
