package com.momentum.focus.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * "Checking for updates" — the gradient wash + dot-cluster pulse from the
 * reference video and the artifact preview it was first proven in.
 *
 * The dot cluster was quietly simplified somewhere between that preview and
 * this file: five dots twinkling in place, no rotation, no wave — the
 * compass reduced to its own crosshair. Restored to the original 13-dot
 * diamond here, with the two things that made it read as "scanning" rather
 * than "blinking": the whole cluster turns slowly, and each dot's twinkle
 * is phased by its distance from the centre, so the sparkle visibly
 * radiates outward rather than flickering at random.
 *
 * Meant to sit over one card while a background refresh is in flight (exam
 * news, on Home), not take over the screen — a data sync is not the same
 * size event as the AI reveal, and shouldn't borrow its full-screen
 * treatment.
 *
 * [visible] drives an AnimatedVisibility fade; the wash and dots inside
 * only animate while composed, so nothing keeps running once the sync
 * has actually finished and this has faded out.
 */
@Composable
fun SyncPulse(visible: Boolean, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(250)),
        exit = fadeOut(tween(400)),
        modifier = modifier,
    ) {
        val infinite = rememberInfiniteTransition(label = "sync-pulse")
        val drift by infinite.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing)),
            label = "drift",
        )
        // A slow, independent turn for the whole cluster — its own clock so
        // one full rotation and one wash cycle don't stay locked in step
        // and start looking like a single repeating frame.
        val spin by infinite.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing)),
            label = "spin",
        )

        Box(
            Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val wash = 0.5f + 0.5f * sin(drift * 2f * kotlin.math.PI.toFloat())
                drawRect(
                    brush = Brush.linearGradient(
                        listOf(
                            Color(0xFFE0366E).copy(alpha = 0.14f * wash),
                            Color(0xFFA83CB4).copy(alpha = 0.12f * wash),
                            Color(0xFF5A46DC).copy(alpha = 0.14f * wash),
                        ),
                    ),
                )
                val unit = min(size.width, size.height) / 9f
                val cx = size.width / 2f
                val cy = size.height / 2f
                // The 13-dot diamond from the original preview — a single
                // centre, four arms of three, the four corner points that
                // turn a plain plus into a compass.
                val targets = listOf(
                    0 to 0,
                    0 to -1, 1 to 0, 0 to 1, -1 to 0,
                    -1 to -1, 1 to -1, 1 to 1, -1 to 1,
                    0 to -2, 2 to 0, 0 to 2, -2 to 0,
                )
                val spinRad = spin * kotlin.math.PI.toFloat() / 180f
                val cosR = cos(spinRad)
                val sinR = sin(spinRad)
                targets.forEachIndexed { i, (col, row) ->
                    // Phased by distance from centre rather than by index, so
                    // the twinkle is a ring expanding outward each cycle
                    // instead of a fixed per-dot flicker.
                    val dist = sqrt((col * col + row * row).toFloat())
                    val twinkle = 0.5f + 0.5f * sin(drift * 2f * kotlin.math.PI.toFloat() * 2.2f - dist * 1.4f)
                    // Rotate the (col, row) lattice point itself, then place
                    // it — the dots orbit the centre as a rigid cluster.
                    val rx = col * cosR - row * sinR
                    val ry = col * sinR + row * cosR
                    val x = cx + rx * unit
                    val y = cy + ry * unit
                    val dotSize = unit * 0.34f * (0.6f + 0.4f * twinkle)
                    drawRect(
                        color = Color.White.copy(alpha = 0.35f + 0.5f * twinkle),
                        topLeft = Offset(x - dotSize / 2f, y - dotSize / 2f),
                        size = Size(dotSize, dotSize),
                    )
                }
            }
            // The word-cycling loader from the reference — this box never
            // had any text in it at all, just the dot cluster, so "syncing"
            // never actually got said anywhere near it.
            val words = listOf("Checking\u2026", "Syncing\u2026", "Almost there\u2026")
            var wordIndex by remember { mutableIntStateOf(0) }
            LaunchedEffect(Unit) {
                while (true) {
                    delay(1100)
                    wordIndex = (wordIndex + 1) % words.size
                }
            }
            androidx.compose.animation.AnimatedContent(
                targetState = wordIndex,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp),
                transitionSpec = {
                    (slideInVertically { it } + fadeIn()) togetherWith (slideOutVertically { -it } + fadeOut())
                },
                label = "sync-word",
            ) { i ->
                Text(
                    words[i],
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.75f),
                )
            }
        }
    }
}
