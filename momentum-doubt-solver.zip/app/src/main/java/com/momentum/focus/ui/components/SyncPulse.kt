package com.momentum.focus.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.min
import kotlin.math.sin

/**
 * "Checking for updates" — the gradient wash + dot-cluster pulse from the
 * reference video, actually built this time rather than left in the HTML
 * preview it started in. Meant to sit over one card while a background
 * refresh is in flight (exam news, on Home), not take over the screen —
 * a data sync is not the same size event as the AI reveal, and shouldn't
 * borrow its full-screen treatment.
 *
 * [visible] drives an AnimatedVisibility fade; the wash and dots inside
 * only animate while composed, so nothing keeps running once the sync
 * has actually finished and this has faded out.
 */
@Composable
fun SyncPulse(visible: Boolean, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(250)),
        exit = fadeOut(tween(400)),
        modifier = modifier,
    ) {
        val infinite = rememberInfiniteTransition(label = "sync-pulse")
        val drift by infinite.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing)),
            label = "drift",
        )

        Box(
            Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val wash = 0.5f + 0.5f * sin(drift * 2f * kotlin.math.PI.toFloat())
                drawRect(
                    brush = Brush.linearGradient(
                        listOf(
                            Color(0xFFE0366E).copy(alpha = 0.14f * wash),
                            Color(0xFFA83CB4).copy(alpha = 0.12f * wash),
                            Color(0xFF5A46DC).copy(alpha = 0.14f * wash),
                        ),
                    ),
                )
                val unit = min(size.width, size.height) / 9f
                val cx = size.width / 2f
                val cy = size.height / 2f
                val targets = listOf(
                    0 to 0, 0 to -1, 1 to 0, 0 to 1, -1 to 0,
                )
                targets.forEachIndexed { i, (col, row) ->
                    val twinkle = 0.5f + 0.5f * sin(drift * 2f * kotlin.math.PI.toFloat() * 2.2f + i * 0.9f)
                    val x = cx + col * unit
                    val y = cy + row * unit
                    val dotSize = unit * 0.34f * (0.6f + 0.4f * twinkle)
                    drawRect(
                        color = Color.White.copy(alpha = 0.35f + 0.5f * twinkle),
                        topLeft = Offset(x - dotSize / 2f, y - dotSize / 2f),
                        size = Size(dotSize, dotSize),
                    )
                }
            }
        }
    }
}
