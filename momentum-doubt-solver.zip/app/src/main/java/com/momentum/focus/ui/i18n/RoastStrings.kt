package com.momentum.focus.ui.i18n

/**
 * Copy for the Screen Time Roast card (the 9:16 story poster) and its buttons.
 *
 * Roasts the phone habit, never the person: every verdict is something a
 * student would happily post about themselves. Minors use this app, so nothing
 * here should land as shame (plans/APP_FEATURES_PLAN.md guardrails).
 */
interface RoastStrings {
    /** Button on the quiz's last step and on Stats. */
    val shareCta: String
    /** Button label while the poster is being drawn. */
    val cooking: String
    /** Stats entry card. */
    val statsTitle: String
    val statsSub: String

    // ── On the poster ──
    val badge: String
    val kicker: String
    fun days(n: Int): String
    val daysSub: String
    val auraLabel: String
    /** Five tiers, best (index 0) to worst (index 4). */
    val tiers: List<String>
    val tierLines: List<String>
    val daily: String
    val pickups: String
    val pickupsSub: String
    val topApp: String
    fun perWeek(h: Int, m: Int): String
    val week: String
    fun thirtyYears(years: Double): String
    val footer: String
    val footerSub: String
    val noApp: String

    /** Text that rides along with the image in the share sheet. */
    fun shareText(days: Int, tier: String): String
    val chooserTitle: String
}

object RoastEn : RoastStrings {
    override val shareCta = "Roast my screen time"
    override val cooking = "Cooking your roast…"
    override val statsTitle = "SCREEN TIME ROAST"
    override val statsSub = "Your week as a story card. Post it, then fix it."

    override val badge = "SCREEN TIME ROAST"
    override val kicker = "EVERY YEAR, I GIVE"
    override fun days(n: Int) = "$n DAYS"
    override val daysSub = "to my phone. Gone."
    override val auraLabel = "AURA CHECK"
    override val tiers = listOf(
        "MAIN CHARACTER", "LOCKED IN-ISH", "SIDE QUEST ERA", "CERTIFIED NPC", "FULL BRAINROT",
    )
    override val tierLines = listOf(
        "My phone barely knows me. Rare.",
        "Disciplined. Mostly. Suspiciously.",
        "Half my day is a side quest.",
        "The algorithm has my timetable memorised.",
        "My thumb ran a marathon this week.",
    )
    override val daily = "DAILY"
    override val pickups = "PICKUPS"
    override val pickupsSub = "yesterday"
    override val topApp = "TOP TIME SINK"
    override fun perWeek(h: Int, m: Int) = "%dh %02dm this week".format(h, m)
    override val week = "LAST 7 DAYS"
    override fun thirtyYears(years: Double) = "At this pace: %.1f years of my next 30, on a screen.".format(years)
    override val footer = "Taking it back with Momentum"
    override val footerSub = "Roast yours. Then lock in."
    override val noApp = "—"

    override fun shareText(days: Int, tier: String) =
        "I give $days days a year to my phone. Aura: $tier. Taking it back with Momentum."
    override val chooserTitle = "Share your roast"
}

object RoastHi : RoastStrings {
    override val shareCta = "Meri screen time roast karo"
    override val cooking = "Roast ban raha hai…"
    override val statsTitle = "SCREEN TIME ROAST"
    override val statsSub = "Tumhara hafta, ek story card mein. Post karo, phir sudharo."

    override val badge = "SCREEN TIME ROAST"
    override val kicker = "HAR SAAL MERE"
    override fun days(n: Int) = "$n DIN"
    override val daysSub = "phone kha jaata hai."
    override val auraLabel = "AURA CHECK"
    override val tiers = listOf(
        "MAIN CHARACTER", "LOCKED IN-ISH", "SIDE QUEST ERA", "CERTIFIED NPC", "FULL BRAINROT",
    )
    override val tierLines = listOf(
        "Phone mujhe pehchanta bhi nahi. Rare.",
        "Disciplined hoon. Mostly. Shak hai.",
        "Aadha din side quest mein ja raha.",
        "Algorithm ko mera timetable yaad hai.",
        "Is hafte angoothe ne marathon daud li.",
    )
    override val daily = "ROZ"
    override val pickups = "PICKUPS"
    override val pickupsSub = "kal"
    override val topApp = "SABSE BADA TIME SINK"
    override fun perWeek(h: Int, m: Int) = "is hafte %dh %02dm".format(h, m)
    override val week = "PICHHLE 7 DIN"
    override fun thirtyYears(years: Double) = "Isi speed se: agle 30 mein se %.1f saal screen pe.".format(years)
    override val footer = "Ab Momentum se wapas lena hai"
    override val footerSub = "Apna roast karo. Phir lock in."
    override val noApp = "—"

    override fun shareText(days: Int, tier: String) =
        "Saal ke $days din mere phone ko jaate hain. Aura: $tier. Ab Momentum se wapas."
    override val chooserTitle = "Roast share karo"
}
