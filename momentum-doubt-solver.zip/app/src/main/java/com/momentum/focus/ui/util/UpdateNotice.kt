package com.momentum.focus.ui.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import com.momentum.focus.MainActivity
import com.momentum.focus.R

/**
 * Tells the user a new build exists, with a sound.
 *
 * A separate channel from the shield: the shield notification is silent and
 * permanent, this one fires once and should be heard. Sharing a channel would
 * force both to the same importance and one of them would be wrong.
 */
object UpdateNotice {

    private const val CHANNEL = "momentum_updates"
    private const val ID = 77
    private const val PREFS = "update_notice"
    private const val KEY_LAST_VERSION = "last_notified_version"

    /**
     * Fires once per version, not once per call. The doc above already said
     * "fires once" — the promise a caller re-running on every Home visit
     * (UpdateCard's LaunchedEffect(Unit) re-executes every time HomeScreen is
     * disposed and recomposed on a tab switch, which is every tab switch)
     * broke without anything here actually checking it. DEFAULT_SOUND and
     * DEFAULT_VIBRATE plus this object's own Sfx.play meant every one of
     * those re-runs re-alerted with both a system sound and this app's own,
     * which is what "notifies again and again" actually was.
     */
    fun show(context: Context, version: String) {
        if (!canPost(context)) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getString(KEY_LAST_VERSION, null) == version) return
        prefs.edit().putString(KEY_LAST_VERSION, version).apply()

        val manager = context.getSystemService<NotificationManager>() ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL,
                "Updates",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "A new version is ready to install"
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                    null,
                )
                enableVibration(true)
            }
            manager.createNotificationChannel(channel)
        }

        val open = PendingIntent.getActivity(
            context,
            1,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Momentum $version is ready")
            .setContentText("Tap to install the update")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setDefaults(NotificationCompat.DEFAULT_SOUND or NotificationCompat.DEFAULT_VIBRATE)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(ID, notification)
        }
        Sfx.play(Sound.SUCCESS)
    }

    fun clear(context: Context) = runCatching {
        NotificationManagerCompat.from(context).cancel(ID)
    }

    private fun canPost(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
}
