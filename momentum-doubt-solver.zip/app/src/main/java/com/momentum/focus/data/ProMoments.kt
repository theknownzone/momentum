package com.momentum.focus.data

import java.time.LocalDate

/**
 * Paywall timing (plans/APP_FEATURES_PLAN.md · C1): show Pro only at moments
 * it actually means something, never at random.
 *
 * - DEEP_SESSION: right after the FIRST 50-minute+ session is banked.
 * - EXAM_CLOSE: once per exam, when it is 30 days out or closer.
 * (The doubts-ran-out wall already opens Plans on its own — unchanged.)
 *
 * Guardrails: never for Pro users, at most one a day, each moment once. Same
 * key flow as always — this only decides WHEN Plans is offered. No fake
 * urgency: the exam countdown is the user's own date.
 */
enum class ProMoment { DEEP_SESSION, EXAM_CLOSE }

object ProMoments {
    const val DEEP_MINUTES = 50

    private fun today() = LocalDate.now().toEpochDay()
    fun examKey(d: AppData) = "${d.examName}|${d.examEpochDay}"

    private fun allowed(d: AppData) = !d.premium && d.proNudgeDay != today()

    /** Call after the session ceremony closes. */
    fun afterSession(d: AppData): ProMoment? {
        if (!allowed(d) || d.proNudgeDeepDone) return null
        val last = d.sessions.lastOrNull { it.completed } ?: return null
        return if (last.minutes >= DEEP_MINUTES) ProMoment.DEEP_SESSION else null
    }

    /** Call when the main app is showing. */
    fun onOpen(d: AppData): ProMoment? {
        if (!allowed(d) || !d.onboarded) return null
        return if (d.examIsClose && d.examEpochDay != 0L && examKey(d) != d.proNudgeExamKey)
            ProMoment.EXAM_CLOSE else null
    }

    /** Marks the moment as used (shown or dismissed — it never repeats). */
    fun consume(d: AppData, m: ProMoment): AppData = when (m) {
        ProMoment.DEEP_SESSION -> d.copy(proNudgeDay = today(), proNudgeDeepDone = true)
        ProMoment.EXAM_CLOSE -> d.copy(proNudgeDay = today(), proNudgeExamKey = examKey(d))
    }
}
