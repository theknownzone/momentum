package com.momentum.focus.block

/**
 * Is this YouTube video study? Used by study-only mode so lectures work
 * without the user hand-adding every channel (Regain-style auto-detect).
 *
 * Errs towards blocking: a known study channel, or at least TWO study words
 * in the title area, are needed — one stray "class" in a vlog title shouldn't
 * open the gate. Words cover English + Hinglish + Hindi exam vocabulary.
 */
object StudyDetect {
    private val CHANNELS = listOf(
        "physicswallah", "physics wallah", "pw ", "unacademy", "vedantu", "khan academy", "khanacademy",
        "byju", "magnet brains", "magnetbrains", "adda247", "studyiq", "study iq", "next toppers",
        "apni kaksha", "competishun", "mohit tyagi", "etoos", "motion", "allen", "aakash", "infinity learn",
        "exampur", "testbook", "drishti", "sanskriti ias", "only ias", "neso academy", "gate smashers",
        "freecodecamp", "mit opencourseware", "nptel", "3blue1brown", "crashcourse", "crash course",
        "shiksha house", "rojgar with ankit", "wifistudy", "utkarsh", "career will", "careerwill",
    )
    private val WORDS = listOf(
        "lecture", "class ", "chapter", "one shot", "oneshot", "full chapter", "revision", "pyq", "previous year",
        "solution", "solutions", "ncert", "syllabus", "jee", "neet", "upsc", "ssc", "cbse", "board exam", "boards",
        "physics", "chemistry", "maths", "mathematics", "biology", "history", "geography", "polity", "economics",
        "accountancy", "grammar", "reasoning", "aptitude", "quant", "tutorial", "course", "practice", "mock test",
        "numericals", "derivation", "formula", "concept", "notes", "padhai", "kaksha", "adhyay", "प्रश्न", "अध्याय",
        "कक्षा", "भौतिकी", "रसायन", "गणित", "इतिहास", "पाठ", "परीक्षा",
    )

    fun looksLikeStudy(channel: String, texts: List<String>): Boolean {
        val ch = channel.lowercase()
        if (CHANNELS.any { ch.contains(it.trim()) }) return true
        val blob = texts.joinToString(" ").lowercase() + " "
        return WORDS.count { blob.contains(it) } >= 2
    }
}
