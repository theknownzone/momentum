package com.momentum.focus.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.CrownMark
import com.momentum.focus.ui.components.PowBurst
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.util.PremiumClip
import com.momentum.focus.ui.util.PremiumSfx
import com.momentum.focus.ui.util.PrintSound
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlin.math.hypot
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------
// Palette lifted straight from the "Premium Welcome — redesign" reference.
// HTML is the literal spec (CLAUDE_PROJECT_RULES.md, rule 1), so these are the
// reference's own values, not near-matches from the theme.
// ---------------------------------------------------------------------------
private val Gold1 = Color(0xFFF4CB5A)
private val Gold2 = Color(0xFFC68B1E)
private val ScreenBg = Color(0xFF14110B)
private val ReceiptCream = Color(0xFFFFFCF4)
private val Muted = Color(0xFFA89A6E)
private val LabelTan = Color(0xFF8A7C50)
private val SubGrey = Color(0xFF6B6455)
private val PaidGreen = Color(0xFF1C9E5D)

/**
 * The premium unlock celebration — a full ceremony, not a toast.
 *
 *   1. POW burst + haptic unlock pattern
 *   2. Receipt prints with thermal printer sound
 *   3. Gold badge + headline settle in
 *   4. Everything-unlocked list and the CTA arrive
 *
 * The *settled* screen is the reference HTML, element for element: gold
 * diamond badge, "You're Premium!", the ruled receipt on its gold-to-violet
 * plate with the zig-zag tear and crown seal, the three-line unlocked list,
 * falling confetti, the gold CTA and the rainbow ring running the screen edge.
 *
 * Why the receipt values used to vanish: `comicShadow()` is a solid Ink
 * rectangle drawn behind its node, and it sat *after* `.background(CreamCard)`
 * in the chain, so it painted over the cream. Only the 4dp sliver above and to
 * the left survived, and Ink-coloured values (Plan / Holder / Amount) were
 * dark-on-dark. The card here builds its plate first and its paper on top.
 */
@Composable
fun PremiumWelcomeScreen(
    data: AppData,
    onShareReceipt: () -> Unit,
    onStart: () -> Unit,
    onDismiss: () -> Unit = {},
) {
    val haptics = rememberHaptics()

    var phase by remember { mutableIntStateOf(0) } // 0=POW, 1=receipt, 2=badge+headline, 3=list+CTA

    LaunchedEffect(Unit) {
        Sfx.playOnce(Sound.BOOM)
        PremiumSfx.play(PremiumClip.CELEBRATE)
        haptics.unlock()
        delay(1_800)
        phase = 1

        PrintSound.play(loop = true)
        delay(1_200)
        PrintSound.stop()
        phase = 2
        delay(600)

        Sfx.playOnce(Sound.SHIMMER)
        haptics.confirm()
        delay(800)
        phase = 3
    }

    // One wall-clock for the ring and the confetti, read only inside draw
    // blocks so a frame invalidates drawing and never recomposes the screen.
    val clock = remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { clock.longValue = (it - start) / 1_000_000L }
        }
    }

    val titleAlpha by animateFloatAsState(if (phase >= 2) 1f else 0f, tween(600), label = "title-alpha")
    val listAlpha by animateFloatAsState(if (phase >= 3) 1f else 0f, tween(500), label = "list-alpha")
    val ctaAlpha by animateFloatAsState(if (phase >= 3) 1f else 0f, tween(400), label = "cta-alpha")

    Box(
        Modifier
            .fillMaxSize()
            .background(ScreenBg)
            // .glowbg — radial-gradient(circle at 50% 30%, gold .25, transparent 60%)
            .drawBehind {
                val c = Offset(size.width / 2f, size.height * 0.30f)
                val reach = hypot(size.width / 2f, size.height * 0.70f)
                drawRect(
                    Brush.radialGradient(
                        0f to Gold1.copy(alpha = 0.25f),
                        0.6f to Gold1.copy(alpha = 0f),
                        center = c,
                        radius = reach,
                    ),
                )
            }
            // .edge-rgb — a 4dp ring; only the gradient turns, the ring never
            // moves. 3s a lap, linear, as specified.
            .drawWithCache {
                val inset = 4.dp.toPx()
                val outerR = 28.dp.toPx()
                val ring = Path().apply {
                    fillType = PathFillType.EvenOdd
                    addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(outerR)))
                    addRoundRect(
                        RoundRect(
                            inset, inset, size.width - inset, size.height - inset,
                            CornerRadius(outerR - inset),
                        ),
                    )
                }
                val centre = Offset(size.width / 2f, size.height / 2f)
                val reach = hypot(size.width, size.height)
                val sweep = Brush.sweepGradient(
                    listOf(
                        Color(0xFFFF003C), Color(0xFFFF8A00), Color(0xFFFFEE00),
                        Color(0xFF4FE8A0), Color(0xFF00C3FF), Color(0xFF7B2FFF),
                        Color(0xFFFF003C),
                    ),
                    centre,
                )
                onDrawWithContent {
                    drawContent()
                    val angle = (clock.longValue % 3000L) / 3000f * 360f
                    clipPath(ring) {
                        rotate(angle, centre) {
                            drawRect(
                                brush = sweep,
                                topLeft = Offset(centre.x - reach, centre.y - reach),
                                size = Size(reach * 2f, reach * 2f),
                            )
                        }
                    }
                }
            },
    ) {
        // Confetti sits behind the content, exactly where the reference puts it.
        Confetti(clock, Modifier.fillMaxSize())

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, end = 18.dp),
                horizontalArrangement = Arrangement.End,
            ) {
                Text(
                    "✕",
                    Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onDismiss()
                        }
                        .padding(8.dp),
                    fontSize = 22.sp,
                    color = Muted,
                )
            }

            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                // Badge slot: fixed height so the POW burst hands over to the
                // badge without anything below it moving.
                Box(Modifier.fillMaxWidth().height(130.dp), contentAlignment = Alignment.Center) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = phase == 0,
                        enter = scaleIn(spring(dampingRatio = 0.45f, stiffness = 280f)),
                        exit = fadeOut(tween(600)),
                    ) {
                        PowBurst(visible = true, word = "UNLOCKED!", onDone = {})
                    }
                    if (phase >= 2) PremiumBadge(Modifier.size(110.dp))
                }

                Column(
                    Modifier.graphicsLayer {
                        alpha = titleAlpha
                        translationY = (1f - titleAlpha) * 24.dp.toPx()
                    },
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        "You're Premium!",
                        fontSize = 44.sp,
                        fontFamily = FontFamily.Cursive,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                    )
                    Text(
                        "focus, banked — for real this time",
                        fontSize = 14.sp,
                        color = Muted,
                        textAlign = TextAlign.Center,
                    )
                }

                Spacer(Modifier.height(26.dp))

                AnimatedVisibility(
                    visible = phase >= 1,
                    enter = expandVertically(tween(800), expandFrom = Alignment.Top) + fadeIn(tween(400)),
                ) {
                    ReceiptCard(data)
                }

                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 22.dp, bottom = 16.dp)
                        .graphicsLayer { alpha = listAlpha },
                ) {
                    Text(
                        "Everything unlocked",
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Cursive,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                    )
                    Spacer(Modifier.height(10.dp))
                    PremiumFeature("Unlimited MyAI — Friend + Guru")
                    PremiumFeature("Crown mode — uninstall lock")
                    PremiumFeature("Every theme, no levelling")
                }
            }

            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 22.dp)
                    .padding(top = 6.dp, bottom = 12.dp)
                    .graphicsLayer {
                        alpha = ctaAlpha
                        translationY = (1f - ctaAlpha) * 40.dp.toPx()
                    },
            ) {
                GoldCta(
                    label = "Start focusing →",
                    enabled = phase >= 3,
                    onClick = {
                        haptics.confirm()
                        Sfx.play(Sound.SUCCESS)
                        onStart()
                    },
                )
                Text(
                    "Share Receipt",
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }, enabled = phase >= 3) {
                            haptics.tick(); onShareReceipt()
                        }
                        .padding(vertical = 10.dp),
                    fontSize = 13.sp,
                    color = Muted,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}

/** .badge — a 70dp gold diamond, 8dp corners, a wide gold glow, ink star. */
@Composable
private fun PremiumBadge(modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height / 2f)
            // box-shadow: 0 0 30px rgba(244,203,90,.7)
            val glowR = 62.dp.toPx()
            drawCircle(
                brush = Brush.radialGradient(
                    0f to Gold1.copy(alpha = 0.60f),
                    0.55f to Gold1.copy(alpha = 0.32f),
                    1f to Gold1.copy(alpha = 0f),
                    center = c,
                    radius = glowR,
                ),
                radius = glowR,
                center = c,
            )
            val side = 70.dp.toPx()
            rotate(45f, c) {
                drawRoundRect(
                    brush = Brush.linearGradient(
                        listOf(Gold1, Gold2),
                        start = Offset(c.x - side / 2f, c.y - side / 2f),
                        end = Offset(c.x + side / 2f, c.y + side / 2f),
                    ),
                    topLeft = Offset(c.x - side / 2f, c.y - side / 2f),
                    size = Size(side, side),
                    cornerRadius = CornerRadius(8.dp.toPx()),
                )
            }
        }
        Text("★", fontSize = 28.sp, color = Ink)
    }
}

/**
 * The receipt's outline: rounded top, straight sides, and a bottom edge that
 * zig-zags between 94% and 100% of the height in twenty steps — the reference's
 * clip-path polygon, as a real Shape so the ink border follows the tear
 * instead of being cut off by it.
 */
private object ReceiptZigzagShape : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val r = with(density) { 16.dp.toPx() }
        val w = size.width
        val h = size.height
        val valley = h * 0.94f
        val path = Path().apply {
            moveTo(0f, r)
            arcTo(Rect(0f, 0f, r * 2f, r * 2f), 180f, 90f, false)
            lineTo(w - r, 0f)
            arcTo(Rect(w - r * 2f, 0f, w, r * 2f), 270f, 90f, false)
            lineTo(w, valley)
            for (i in 1..20) {
                lineTo(w - w * 0.05f * i, if (i % 2 == 1) h else valley)
            }
            close()
        }
        return Outline.Generic(path)
    }
}

@Composable
private fun ReceiptCard(data: AppData) {
    Box(Modifier.fillMaxWidth().padding(end = 8.dp)) {
        // .receipt-back — the gold→orange→pink→violet plate, 7dp down and right.
        Box(
            Modifier
                .matchParentSize()
                .offset(7.dp, 7.dp)
                .clip(ReceiptZigzagShape)
                .background(
                    Brush.linearGradient(
                        0f to Gold1,
                        0.35f to Color(0xFFFF8A5C),
                        0.65f to Color(0xFFFF3D6E),
                        1f to Color(0xFF7B3FE4),
                    ),
                ),
        )
        // .receipt — cream paper, 7% gold wash, 20dp ruled grid, 3dp ink border.
        Column(
            Modifier
                .fillMaxWidth()
                .clip(ReceiptZigzagShape)
                .background(ReceiptCream)
                .drawBehind {
                    drawRect(Gold1.copy(alpha = 0.07f))
                    val step = 20.dp.toPx()
                    val line = Color(0xFF1A1712).copy(alpha = 0.05f)
                    var y = 0f
                    while (y < size.height) {
                        drawLine(line, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                        y += step
                    }
                    var x = 0f
                    while (x < size.width) {
                        drawLine(line, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                        x += step
                    }
                }
                .border(3.dp, Ink, ReceiptZigzagShape)
                .padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "MOMENTUM",
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp,
                color = LabelTan,
            )
            Text("premium receipt", fontSize = 13.sp, color = SubGrey)
            Spacer(Modifier.height(12.dp))
            ReceiptRow("Plan", "Lifetime")
            ReceiptRow("Holder", data.userName.ifBlank { "friend" })
            ReceiptRow("Amount", "₹499")
            Spacer(Modifier.height(10.dp))
            Text("✓ PAID", fontSize = 18.sp, fontWeight = FontWeight.Black, color = PaidGreen)
        }
        // .seal — gold coin, crown, tipped 12° off the top-right corner.
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .offset(x = 10.dp, y = (-14).dp)
                .size(52.dp)
                .graphicsLayer { rotationZ = 12f }
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Gold1, Gold2)))
                .border(2.dp, Ink, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            CrownMark(size = 26.dp)
        }
    }
}

@Composable
private fun ReceiptRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 14.sp, color = LabelTan)
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1A1712))
    }
}

@Composable
private fun PremiumFeature(text: String) {
    Row(
        Modifier.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("◆", fontSize = 14.sp, color = Gold1)
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 14.sp, color = Color(0xFFDDDDDD))
    }
}

/** .cta — gold slab, 3dp ink border, 4dp hard shadow that closes when pressed. */
@Composable
private fun GoldCta(label: String, enabled: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 1f else 0f, tween(80), label = "cta-press")
    Box(
        Modifier
            .fillMaxWidth()
            .padding(end = 4.dp, bottom = 4.dp)
            .drawBehind {
                val d = 4.dp.toPx() * (1f - press)
                drawRoundRect(
                    color = Ink,
                    topLeft = Offset(d, d),
                    size = size,
                    cornerRadius = CornerRadius(16.dp.toPx()),
                )
            }
            .offset { IntOffset((4.dp.toPx() * press).roundToInt(), (4.dp.toPx() * press).roundToInt()) }
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(Gold1, Gold2)))
            .border(3.dp, Ink, RoundedCornerShape(16.dp))
            .clickableNoRipple(interaction, enabled = enabled, onClick = onClick)
            .padding(14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 16.sp, fontWeight = FontWeight.Black, color = Ink)
    }
}

/**
 * .confetti — 26 slips, 8×14dp, gold / mint / orange / white, each falling
 * 820dp on its own 2.5–4.5s linear loop with a 0–2s head start, turning one
 * full revolution per fall. Positions are seeded, so it looks the same every
 * time this screen opens.
 */
@Composable
private fun Confetti(clock: LongState, modifier: Modifier = Modifier) {
    class Piece(val fx: Float, val top: Float, val color: Color, val dur: Float, val delay: Float)
    val pieces = remember {
        val palette = listOf(Gold1, Color(0xFF4FE8A0), Color(0xFFFF8A5C), Color.White)
        val rnd = kotlin.random.Random(29)
        List(26) { i ->
            Piece(
                fx = rnd.nextFloat(),
                top = -20f - rnd.nextFloat() * 200f,
                color = palette[i % palette.size],
                dur = 2.5f + rnd.nextFloat() * 2f,
                delay = rnd.nextFloat() * 2f,
            )
        }
    }
    Canvas(modifier) {
        val t = clock.longValue / 1000f
        pieces.forEach { p ->
            val local = t - p.delay
            val prog = if (local < 0f) 0f else (local % p.dur) / p.dur
            val x = size.width * p.fx
            val y = (p.top + prog * 820f).dp.toPx()
            rotate(prog * 360f, Offset(x, y)) {
                drawRect(
                    color = p.color.copy(alpha = 0.9f),
                    topLeft = Offset(x - 4.dp.toPx(), y - 7.dp.toPx()),
                    size = Size(8.dp.toPx(), 14.dp.toPx()),
                )
            }
        }
    }
}
