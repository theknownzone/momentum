package com.momentum.focus.ui.screens

import androidx.compose.material3.Icon
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.Icons
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.draw.drawWithContent
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.components.paperGrain
import androidx.activity.compose.BackHandler
import com.momentum.focus.data.tr
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.CrownMark
import com.momentum.focus.ui.components.PowBurst
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.util.PremiumClip
import com.momentum.focus.ui.util.PremiumSfx
import com.momentum.focus.ui.util.PrintSound
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlin.math.hypot
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------
// Palette lifted straight from the "Premium Welcome — redesign" reference.
// HTML is the literal spec (CLAUDE_PROJECT_RULES.md, rule 1), so these are the
// reference's own values, not near-matches from the theme.
// ---------------------------------------------------------------------------
private val Gold1 = Color(0xFFF4CB5A)
private val Gold2 = Color(0xFFC68B1E)
private val ScreenBg = Color(0xFF14110B)
private val ReceiptCream = Color(0xFFFFFCF4)
private val Muted = Color(0xFFA89A6E)
private val LabelTan = Color(0xFF8A7C50)
private val SubGrey = Color(0xFF6B6455)
private val PaidGreen = Color(0xFF1C9E5D)

/**
 * The premium unlock celebration — a full ceremony, not a toast.
 *
 *   1. POW burst + haptic unlock pattern
 *   2. Receipt prints with thermal printer sound
 *   3. Gold badge + headline settle in
 *   4. Everything-unlocked list and the CTA arrive
 *
 * The *settled* screen is the reference HTML, element for element: gold
 * diamond badge, "You're Premium!", the ruled receipt on its gold-to-violet
 * plate with the zig-zag tear and crown seal, the three-line unlocked list,
 * falling confetti, the gold CTA and the rainbow ring running the screen edge.
 *
 * Why the receipt values used to vanish: `comicShadow()` is a solid Ink
 * rectangle drawn behind its node, and it sat *after* `.background(CreamCard)`
 * in the chain, so it painted over the cream. Only the 4dp sliver above and to
 * the left survived, and Ink-coloured values (Plan / Holder / Amount) were
 * dark-on-dark. The card here builds its plate first and its paper on top.
 */
@Composable
fun PremiumWelcomeScreen(
    data: AppData,
    onShareReceipt: () -> Unit,
    onStart: () -> Unit,
    onDismiss: () -> Unit = {},
) {
    // v3 (2026-10-03): rebuilt in the app's neo-brutalist print language.
    // A gold ticket flips in, an UNLOCKED stamp slams onto it, the perks
    // land as sticker rows. The ticket only states what the app actually
    // knows — holder, key, status. The old receipt printed "Lifetime ₹499"
    // for every buyer whatever they paid; that is gone.
    val haptics = rememberHaptics()
    var step by remember { mutableIntStateOf(0) }
    val shake = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        Sfx.playOnce(Sound.BOOM)
        PremiumSfx.play(PremiumClip.CELEBRATE)
        haptics.unlock()
        delay(80); step = 1                         // ticket flips in
        delay(520); step = 2                        // stamp
        Sfx.playOnce(Sound.CRACK); haptics.confirm()
        listOf(10f, -8f, 5f, -2f, 0f).forEach { shake.animateTo(it, tween(40)) }
        delay(160); step = 3                        // headline
        Sfx.playOnce(Sound.SHIMMER)
        delay(320); step = 4                        // perks + CTA
    }
    BackHandler { onDismiss() }

    val flip by animateFloatAsState(if (step >= 1) 1f else 0f, tween(380, easing = FastOutSlowInEasing), label = "flip")
    val stamp by animateFloatAsState(if (step >= 2) 1f else 0f, tween(200, easing = FastOutSlowInEasing), label = "stamp")
    val gold = Brush.linearGradient(listOf(Color(0xFFFFE9A8), Color(0xFFF4CB5A), Color(0xFFC68B1E)))

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .graphicsLayer { translationX = shake.value },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(top = 28.dp, bottom = 20.dp),
        ) {
            // ---- the ticket
            Box(
                Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        rotationY = 90f * (1f - flip)
                        rotationZ = -2f * flip
                        alpha = if (flip > 0.02f) 1f else 0f
                        cameraDistance = 14f * density
                    },
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(end = 7.dp, bottom = 7.dp)
                        .drawBehind {
                            val d = 7.dp.toPx()
                            drawRoundRect(Ink, topLeft = Offset(d, d), size = size, cornerRadius = CornerRadius(18.dp.toPx()))
                        }
                        .clip(RoundedCornerShape(18.dp))
                        .background(gold)
                        .border(3.dp, Ink, RoundedCornerShape(18.dp))
                        // Ticket perforation notches on both sides.
                        .drawWithContent {
                            drawContent()
                            val r = 11.dp.toPx(); val y = size.height * 0.62f
                            drawCircle(Color(0xFFFBF3D5), r, Offset(0f, y)); drawCircle(Ink, r, Offset(0f, y), style = Stroke(3.dp.toPx()))
                            drawCircle(Color(0xFFFBF3D5), r, Offset(size.width, y)); drawCircle(Ink, r, Offset(size.width, y), style = Stroke(3.dp.toPx()))
                            var x = r * 2
                            while (x < size.width - r * 2) {
                                drawLine(Ink.copy(alpha = 0.5f), Offset(x, y), Offset(x + 6.dp.toPx(), y), 2.dp.toPx()); x += 12.dp.toPx()
                            }
                        }
                        .padding(20.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CrownMark(size = 30.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("MOMENTUM", fontWeight = FontWeight.Black, fontSize = 15.sp, letterSpacing = 2.sp, color = Ink)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(tr("PREMIUM", "प्रीमियम"), fontWeight = FontWeight.Black, fontSize = 46.sp, lineHeight = 48.sp, color = Ink)
                    Spacer(Modifier.height(30.dp))
                    TicketRow(tr("HOLDER", "धारक"), data.userName.ifBlank { tr("friend", "दोस्त") })
                    if (data.licenseKey.isNotBlank()) {
                        TicketRow(tr("KEY", "की"), "•••• " + data.licenseKey.takeLast(4).uppercase())
                    }
                    TicketRow(tr("STATUS", "स्थिति"), tr("ACTIVE", "सक्रिय"))
                }
                // UNLOCKED stamp slams onto the ticket.
                Text(
                    tr("UNLOCKED", "अनलॉक"),
                    fontWeight = FontWeight.Black,
                    fontSize = 22.sp,
                    color = Tang.accent,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 18.dp, end = 22.dp)
                        .graphicsLayer {
                            val sc = 2.2f - 1.2f * stamp
                            scaleX = sc; scaleY = sc; alpha = stamp; rotationZ = 12f
                        }
                        .border(3.dp, Tang.accent, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                )
            }

            Spacer(Modifier.height(26.dp))
            if (step >= 3) {
                WordReveal(tr("You're Premium.", "आप प्रीमियम हैं।"))
                Spacer(Modifier.height(6.dp))
                FadeUp(delayMs = 200) {
                    Text(tr("Locked in. For real this time.", "अब पूरा फ़ोकस। इस बार सच में।"), style = MaterialTheme.typography.bodyLarge, color = InkMid)
                }
            }
            Spacer(Modifier.height(18.dp))
            val perks = listOf(
                Triple(Icons.Filled.AutoAwesome, tr("Unlimited MyAI — Friend + Guru", "असीमित MyAI — Friend + Guru"), Lilac.fill),
                Triple(Icons.Filled.Lock, tr("Crown mode — uninstall lock", "क्राउन मोड — अनइंस्टॉल लॉक"), Butter.fill),
                Triple(Icons.Filled.Palette, tr("Every theme, no levelling", "हर थीम, बिना लेवलिंग"), Mint.fill),
            )
            perks.forEachIndexed { i, (g, label, fill) ->
                var on by remember { mutableStateOf(false) }
                LaunchedEffect(step >= 4) { if (step >= 4) { delay(i * 90L); on = true; Sfx.play(Sound.TICK) } }
                val t by animateFloatAsState(if (on) 1f else 0f, tween(220, easing = FastOutSlowInEasing), label = "perk$i")
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp, end = 4.dp)
                        .graphicsLayer { alpha = t; translationX = (1f - t) * -60.dp.toPx() }
                        .drawBehind {
                            val d = 4.dp.toPx()
                            drawRoundRect(Ink, topLeft = Offset(d, d), size = size, cornerRadius = CornerRadius(12.dp.toPx()))
                        }
                        .clip(RoundedCornerShape(12.dp))
                        .background(fill)
                        .border(2.5.dp, Ink, RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(g, contentDescription = null, tint = Ink, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black, color = Ink)
                }
            }

            Spacer(Modifier.height(16.dp))
            val ctaIn by animateFloatAsState(if (step >= 4) 1f else 0f, tween(280, delayMillis = 300), label = "cta")
            Column(Modifier.graphicsLayer { alpha = ctaIn; translationY = (1f - ctaIn) * 20.dp.toPx() }) {
                PrimaryButton(tr("Lock in →", "शुरू करें →")) {
                    if (ctaIn > 0.5f) { haptics.confirm(); Sfx.play(Sound.BEGIN); onStart() }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    tr("Share receipt", "रसीद शेयर करें"),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = InkMid,
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .clickableNoRipple(remember { MutableInteractionSource() }) { haptics.tick(); onShareReceipt() }
                        .padding(10.dp),
                )
            }
        }
    }
}

@Composable
private fun TicketRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp, color = Ink.copy(alpha = 0.6f), modifier = Modifier.width(76.dp))
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.Black, color = Ink, maxLines = 1)
    }
}

/** .badge — a 70dp gold diamond, 8dp corners, a wide gold glow, ink star. */
@Composable
private fun PremiumBadge(modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height / 2f)
            // box-shadow: 0 0 30px rgba(244,203,90,.7)
            val glowR = 62.dp.toPx()
            drawCircle(
                brush = Brush.radialGradient(
                    0f to Gold1.copy(alpha = 0.60f),
                    0.55f to Gold1.copy(alpha = 0.32f),
                    1f to Gold1.copy(alpha = 0f),
                    center = c,
                    radius = glowR,
                ),
                radius = glowR,
                center = c,
            )
            val side = 70.dp.toPx()
            rotate(45f, c) {
                drawRoundRect(
                    brush = Brush.linearGradient(
                        listOf(Gold1, Gold2),
                        start = Offset(c.x - side / 2f, c.y - side / 2f),
                        end = Offset(c.x + side / 2f, c.y + side / 2f),
                    ),
                    topLeft = Offset(c.x - side / 2f, c.y - side / 2f),
                    size = Size(side, side),
                    cornerRadius = CornerRadius(8.dp.toPx()),
                )
            }
        }
        Text("★", fontSize = 28.sp, color = Ink)
    }
}

/**
 * The receipt's outline: rounded top, straight sides, and a bottom edge that
 * zig-zags between 94% and 100% of the height in twenty steps — the reference's
 * clip-path polygon, as a real Shape so the ink border follows the tear
 * instead of being cut off by it.
 */
private object ReceiptZigzagShape : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val r = with(density) { 16.dp.toPx() }
        val w = size.width
        val h = size.height
        val valley = h * 0.94f
        val path = Path().apply {
            moveTo(0f, r)
            arcTo(Rect(0f, 0f, r * 2f, r * 2f), 180f, 90f, false)
            lineTo(w - r, 0f)
            arcTo(Rect(w - r * 2f, 0f, w, r * 2f), 270f, 90f, false)
            lineTo(w, valley)
            for (i in 1..20) {
                lineTo(w - w * 0.05f * i, if (i % 2 == 1) h else valley)
            }
            close()
        }
        return Outline.Generic(path)
    }
}

@Composable
private fun ReceiptCard(data: AppData) {
    Box(Modifier.fillMaxWidth().padding(end = 8.dp)) {
        // .receipt-back — the gold→orange→pink→violet plate, 7dp down and right.
        Box(
            Modifier
                .matchParentSize()
                .offset(7.dp, 7.dp)
                .clip(ReceiptZigzagShape)
                .background(
                    Brush.linearGradient(
                        0f to Gold1,
                        0.35f to Color(0xFFFF8A5C),
                        0.65f to Color(0xFFFF3D6E),
                        1f to Color(0xFF7B3FE4),
                    ),
                ),
        )
        // .receipt — cream paper, 7% gold wash, 20dp ruled grid, 3dp ink border.
        Column(
            Modifier
                .fillMaxWidth()
                .clip(ReceiptZigzagShape)
                .background(ReceiptCream)
                .drawBehind {
                    drawRect(Gold1.copy(alpha = 0.07f))
                    val step = 20.dp.toPx()
                    val line = Color(0xFF1A1712).copy(alpha = 0.05f)
                    var y = 0f
                    while (y < size.height) {
                        drawLine(line, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                        y += step
                    }
                    var x = 0f
                    while (x < size.width) {
                        drawLine(line, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                        x += step
                    }
                }
                .border(3.dp, Ink, ReceiptZigzagShape)
                .padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "MOMENTUM",
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp,
                color = LabelTan,
            )
            Text("premium receipt", fontSize = 13.sp, color = SubGrey)
            Spacer(Modifier.height(12.dp))
            ReceiptRow("Plan", "Lifetime")
            ReceiptRow("Holder", data.userName.ifBlank { "friend" })
            ReceiptRow("Amount", "₹499")
            Spacer(Modifier.height(10.dp))
            Text("✓ PAID", fontSize = 18.sp, fontWeight = FontWeight.Black, color = PaidGreen)
        }
        // .seal — gold coin, crown, tipped 12° off the top-right corner.
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .offset(x = 10.dp, y = (-14).dp)
                .size(52.dp)
                .graphicsLayer { rotationZ = 12f }
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Gold1, Gold2)))
                .border(2.dp, Ink, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            CrownMark(size = 26.dp)
        }
    }
}

@Composable
private fun ReceiptRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 14.sp, color = LabelTan)
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1A1712))
    }
}

@Composable
private fun PremiumFeature(text: String, index: Int = 0, shown: Boolean = true) {
    // Lines arrive one after another, 90ms apart, sliding in from the left.
    val t by animateFloatAsState(
        if (shown) 1f else 0f,
        tween(240, delayMillis = index * 90),
        label = "feature$index",
    )
    Row(
        Modifier
            .padding(vertical = 8.dp)
            .graphicsLayer { alpha = t; translationX = (1f - t) * -16.dp.toPx() },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("◆", fontSize = 14.sp, color = Gold1)
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 14.sp, color = Color(0xFFDDDDDD))
    }
}

/** .cta — gold slab, 3dp ink border, 4dp hard shadow that closes when pressed. */
@Composable
private fun GoldCta(label: String, enabled: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 1f else 0f, tween(150), label = "cta-press")
    Box(
        Modifier
            .fillMaxWidth()
            .padding(end = 4.dp, bottom = 4.dp)
            .drawBehind {
                val d = 4.dp.toPx() * (1f - press)
                drawRoundRect(
                    color = Ink,
                    topLeft = Offset(d, d),
                    size = size,
                    cornerRadius = CornerRadius(16.dp.toPx()),
                )
            }
            .offset { IntOffset((4.dp.toPx() * press).roundToInt(), (4.dp.toPx() * press).roundToInt()) }
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(Gold1, Gold2)))
            .border(3.dp, Ink, RoundedCornerShape(16.dp))
            .clickableNoRipple(interaction, enabled = enabled, onClick = onClick)
            .padding(14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 16.sp, fontWeight = FontWeight.Black, color = Ink)
    }
}

/**
 * .confetti — 26 slips, 8×14dp, gold / mint / orange / white, each falling
 * 820dp on its own 2.5–4.5s linear loop with a 0–2s head start, turning one
 * full revolution per fall. Positions are seeded, so it looks the same every
 * time this screen opens.
 */
@Composable
private fun Confetti(clock: LongState, modifier: Modifier = Modifier) {
    class Piece(val fx: Float, val top: Float, val color: Color, val dur: Float, val delay: Float)
    val pieces = remember {
        val palette = listOf(Gold1, Color(0xFF4FE8A0), Color(0xFFFF8A5C), Color.White)
        val rnd = kotlin.random.Random(29)
        List(26) { i ->
            Piece(
                fx = rnd.nextFloat(),
                top = -20f - rnd.nextFloat() * 200f,
                color = palette[i % palette.size],
                dur = 2.5f + rnd.nextFloat() * 2f,
                delay = rnd.nextFloat() * 2f,
            )
        }
    }
    Canvas(modifier) {
        val t = clock.longValue / 1000f
        pieces.forEach { p ->
            val local = t - p.delay
            val prog = if (local < 0f) 0f else (local % p.dur) / p.dur
            val x = size.width * p.fx
            val y = (p.top + prog * 820f).dp.toPx()
            rotate(prog * 360f, Offset(x, y)) {
                drawRect(
                    color = p.color.copy(alpha = 0.9f),
                    topLeft = Offset(x - 4.dp.toPx(), y - 7.dp.toPx()),
                    size = Size(8.dp.toPx(), 14.dp.toPx()),
                )
            }
        }
    }
}
