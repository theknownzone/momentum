package com.momentum.focus.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.*
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Haptics
import com.momentum.focus.ui.util.PremiumSfx
import com.momentum.focus.ui.util.PremiumClip
import com.momentum.focus.ui.util.PrintSound
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.*

/**
 * The premium unlock celebration — a full ceremony, not a toast.
 *
 * When someone pays ₹499, the app owes them a moment that feels like
 * something was received, not just a switch flipped. The sequence:
 *
 *   1. POW burst + confetti + haptic unlock pattern
 *   2. Receipt prints with thermal printer sound
 *   3. Premium badge glows with breathing aura
 *   4. Features list slides in
 *   5. "Start Premium" CTA — chunky 3D press
 *
 * Built entirely from the comic paper system + Aura effects.
 */
@Composable
fun PremiumWelcomeScreen(
    data: AppData,
    onShareReceipt: () -> Unit,
    onStart: () -> Unit,
    onDismiss: () -> Unit = {},
) {
    val str = strings()
    val haptics = rememberHaptics()

    var phase by remember { mutableIntStateOf(0) }
    val phases = 4 // 0=POW, 1=receipt print, 2=badge reveal, 3=features

    // Phase auto-advance with sound sync.
    LaunchedEffect(Unit) {
        // Phase 0: POW burst + confetti
        Sfx.playOnce(Sound.BOOM)
        PremiumSfx.play(PremiumClip.CELEBRATE)
        haptics.unlock()
        delay(1_800)
        phase = 1

        // Phase 1: Print sound starts
        PrintSound.play(loop = true)
        delay(1_200)
        PrintSound.stop()
        phase = 2
        delay(600)

        // Phase 2: Badge reveal chime
        Sfx.playOnce(Sound.SHIMMER)
        haptics.confirm()
        delay(800)
        phase = 3
    }

    val edgeAngle by rememberInfiniteTransition(label = "edge").animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart),
        label = "edge-angle",
    )
    Column(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .drawWithContent {
                drawContent()
                rotate(edgeAngle) {
                    drawRoundRect(
                        brush = Brush.sweepGradient(
                            listOf(
                                Color(0xFFFF8FA8), Color(0xFFFFD59E), Color(0xFFFFF4A3),
                                Color(0xFFA8F0C6), Color(0xFFA0DFFF), Color(0xFFC9B3FF),
                                Color(0xFFFF8FA8),
                            ),
                        ),
                        style = Stroke(width = 3.dp.toPx()),
                    )
                }
            }
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // Dismiss X top-right.
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
        ) {
            Text(
                "✕",
                Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.tick(); onDismiss()
                    }
                    .padding(8.dp),
                style = MaterialTheme.typography.titleMedium,
                color = InkLow.copy(alpha = 0.6f),
            )
        }

        Spacer(Modifier.height(8.dp))

        // ---- PHASE 0: POW burst ----
        Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
            if (phase == 0) {
                ConfettiBurst(Modifier.matchParentSize())
            }
            if (phase >= 0) {
                // Fully-qualified: nested inside this Box, the outer
                // Column's own ColumnScope.AnimatedVisibility overload was
                // also an implicit-receiver candidate here, and Kotlin
                // won't pick between two scopes' extensions on its own —
                // this is the plain, scope-agnostic AnimatedVisibility the
                // simple show/hide below actually wants.
                androidx.compose.animation.AnimatedVisibility(
                    visible = phase == 0,
                    enter = scaleIn(spring(dampingRatio = 0.45f, stiffness = 280f)),
                    exit = fadeOut(tween(600)),
                ) {
                    PowBurst(visible = true, word = "UNLOCKED!", onDone = {})
                }
            }
            if (phase >= 2) {
                // Premium badge with breathing aura.
                PremiumBadge(Modifier.size(140.dp))
            }
        }

        Spacer(Modifier.height(12.dp))

        // ---- PHASE 2: Headline ----
        AnimatedVisibility(
            visible = phase >= 2,
            enter = fadeIn(tween(600)) + slideInVertically(tween(500), initialOffsetY = { it / 3 }),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Sky.fill.copy(alpha = 0.28f), Sky.fill.copy(alpha = 0.05f)),
                        ),
                    )
                    .padding(vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    "Premium",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 48.sp,
                        fontFamily = FontFamily.Cursive,
                    ),
                    fontWeight = FontWeight.Bold,
                    color = Sky.accent,
                    textAlign = TextAlign.Center,
                )
                Text(
                    "focus, banked",
                    style = MaterialTheme.typography.bodyLarge,
                    color = InkLow,
                    textAlign = TextAlign.Center,
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        // ---- PHASE 1: Receipt print animation ----
        AnimatedVisibility(
            visible = phase >= 1,
            enter = expandVertically(tween(800)) + fadeIn(tween(400)),
        ) {
            ReceiptPreview(data)
        }

        Spacer(Modifier.height(20.dp))

        // ---- PHASE 3: Features list ----
        AnimatedVisibility(
            visible = phase >= 3,
            enter = fadeIn(tween(500)),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .background(CreamCard.copy(alpha = 0.08f))
                    .comicShadow()
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .inkBorder(color = InkLow.copy(alpha = 0.4f))
                    .halftone(coverage = 0.06f)
                    .padding(18.dp),
            ) {
                Text(
                    "Everything unlocked",
                    style = MaterialTheme.typography.titleMedium,
                    color = Cream,
                )
                Spacer(Modifier.height(10.dp))
                PremiumFeature("Unlimited AI Coach", Mint)
                PremiumFeature("Advanced App Blocking", Tang)
                PremiumFeature("10 Comic Themes", Sky)
                PremiumFeature("Deep Weekly Analytics", Lilac)
                PremiumFeature("Export Share Cards", Butter)
                PremiumFeature("Family Share (5 devices)", Candy)
            }
        }

        Spacer(Modifier.weight(1f))

        // ---- CTA ----
        AnimatedVisibility(
            visible = phase >= 3,
            enter = slideInVertically(tween(400), initialOffsetY = { it }) + fadeIn(tween(300)),
        ) {
            Column {
                PowerButton(
                    label = "Start Premium",
                    sticker = Sky,
                    onClick = {
                        haptics.confirm()
                        Sfx.play(Sound.SUCCESS)
                        onStart()
                    },
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    "Share Receipt",
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); onShareReceipt()
                        }
                        .padding(vertical = 12.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkLow.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun PremiumBadge(modifier: Modifier = Modifier) {
    val rotation by rememberInfiniteTransition(label = "badge").animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(20_000, easing = LinearEasing), RepeatMode.Restart),
        label = "spin",
    )

    Box(modifier, contentAlignment = Alignment.Center) {
        // Outer aura.
        BreathingOrb(
            Modifier.fillMaxSize(),
            tint = Sky.accent,
        )
        // Starburst rays behind.
        Starburst(
            Modifier.fillMaxSize(),
            spokeCount = 16,
            tint = Sky.fill.copy(alpha = 0.25f),
        )
        // Badge diamond shape.
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val r = min(cx, cy) * 0.78f
            val path = Path().apply {
                moveTo(cx, cy - r)
                lineTo(cx + r, cy)
                lineTo(cx, cy + r)
                lineTo(cx - r, cy)
                close()
            }
            drawPath(path, Sky.fill)
            drawPath(path, Ink, style = Stroke(3.5f * density))
            // Same Region-based containment as Comic.kt's star — Path
            // .contains(Offset) isn't public Compose API, so nothing was
            // ever going to import cleanly here.
            val androidPath = path.asAndroidPath()
            val pathBounds = android.graphics.RectF()
            androidPath.computeBounds(pathBounds, true)
            val fillRegion = android.graphics.Region()
            fillRegion.setPath(
                androidPath,
                android.graphics.Region(
                    pathBounds.left.toInt(), pathBounds.top.toInt(),
                    pathBounds.right.toInt() + 1, pathBounds.bottom.toInt() + 1,
                ),
            )
            // Halftone fill inside.
            val dotPx = 4.5f * density
            val dotR = dotPx * 0.34f
            var rowY = 0f
            var even = true
            val yStep = dotPx * 0.866f
            while (rowY < size.height + yStep) {
                var colX = if (even) 0f else dotPx * 0.5f
                while (colX < size.width + dotPx) {
                    if (fillRegion.contains(colX.toInt(), rowY.toInt())) {
                        drawCircle(
                            Ink.copy(alpha = 0.18f),
                            dotR,
                            center = Offset(colX, rowY),
                        )
                    }
                    colX += dotPx
                }
                rowY += yStep
                even = !even
            }
        }
        Text(
            "★",
            style = MaterialTheme.typography.displayLarge.copy(fontSize = 38.sp),
            color = Ink,
        )
    }
}

@Composable
private fun ReceiptPreview(data: AppData) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CreamCard)
            .comicShadow()
            .clip(RoundedCornerShape(14.dp))
            .inkBorder()
            .tornEdge(Edge.BOTTOM, peak = 8f, period = 16f)
            .padding(horizontal = 18.dp)
            .padding(top = 16.dp, bottom = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "MOMENTUM",
            style = MaterialTheme.typography.labelSmall.copy(
                letterSpacing = 3.sp,
                fontWeight = FontWeight.Bold,
            ),
            color = InkMid,
        )
        Text(
            "premium receipt",
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Plan", style = MaterialTheme.typography.bodyMedium, color = InkMid)
            Text("Lifetime", style = MaterialTheme.typography.bodyMedium, color = Ink)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Holder", style = MaterialTheme.typography.bodyMedium, color = InkMid)
            Text(data.userName.ifBlank { "friend" }, style = MaterialTheme.typography.bodyMedium, color = Ink)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Amount", style = MaterialTheme.typography.bodyMedium, color = InkMid)
            Text("₹499", style = MaterialTheme.typography.bodyMedium, color = Ink, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "PAID",
            style = MaterialTheme.typography.titleMedium.copy(
                color = Mint.fill,
                fontWeight = FontWeight.ExtraBold,
            ),
        )
    }
}

@Composable
private fun PremiumFeature(text: String, sticker: Sticker) {
    Row(
        Modifier.padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "✦",
            style = MaterialTheme.typography.bodyMedium,
            color = sticker.accent,
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            color = Cream.copy(alpha = 0.9f),
        )
    }
}

@Composable
private fun ConfettiBurst(modifier: Modifier = Modifier) {
    val colors = listOf(Butter.fill, Mint.fill, Tang.fill, Color.White, Sky.fill)
    data class Piece(val fx: Float, val delayMs: Int, val durMs: Int, val color: Color, val rot: Float)
    val pieces = remember {
        List(22) {
            Piece(
                fx = (it * 47 % 100) / 100f,
                delayMs = (it * 37 % 600),
                durMs = 900 + (it * 53 % 700),
                color = colors[it % colors.size],
                rot = (it * 61 % 360).toFloat(),
            )
        }
    }
    val t by rememberInfiniteTransition(label = "confetti").animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2200, easing = LinearEasing)),
        label = "confetti-t",
    )
    Canvas(modifier) {
        pieces.forEach { p ->
            val localT = (((t * 2200).toInt() - p.delayMs).coerceAtLeast(0) % p.durMs) / p.durMs.toFloat()
            val y = -20f + localT * (size.height + 40f)
            val x = size.width * p.fx
            val alpha = if (localT > 0.85f) (1f - localT) / 0.15f else 1f
            withTransform({
                translate(x, y)
                rotate(p.rot + localT * 360f)
            }) {
                drawRect(
                    color = p.color.copy(alpha = alpha.coerceIn(0f, 1f)),
                    topLeft = Offset(-4.dp.toPx(), -6.dp.toPx()),
                    size = Size(8.dp.toPx(), 12.dp.toPx()),
                )
            }
        }
    }
}
