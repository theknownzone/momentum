package com.momentum.focus.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.sin

/**
 * The reference look -- a dark pane of glass with one soft light pooling
 * behind whatever sits on it, and a fine grain across the whole surface.
 *
 * This is a different material to [CeramicPanel] on purpose, not a second
 * attempt at the same one. Ceramic is milk-white and printed-paper-adjacent --
 * right for a surface sitting on this app's cream background all day, like
 * the composer. This is for the moment that is meant to feel like it dropped
 * in from somewhere else: dark base, one glowing accent colour, a texture
 * closer to noise than to the halftone dots the rest of the app draws.
 *
 * Three layers make the reference photo read as glass rather than as a dark
 * rounded rectangle:
 * - A halo: one soft radial light, off-centre, in the panel's own tint.
 * - Grain: a scatter of near-invisible dots across the whole surface. Real
 *   frosted glass has texture even in the dark parts; a flat dark fill looks
 *   like a solid colour swatch next to it.
 * - A lit rim: bright along the top-left, the way a curved glass edge
 *   catches whatever light is above it, fading out by the bottom-right.
 *
 * No Modifier.blur anywhere -- this app supports API 26, where blur is a
 * no-op, so the material has to read as glass from gradients and grain alone
 * or it looks like plain glass on old phones and only sometimes-glass on new
 * ones.
 */
@Composable
fun HaloGlass(
    modifier: Modifier = Modifier,
    tint: Color = Color(0xFF7FD4FF),
    radius: Dp = 26.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(radius)
    Box(
        modifier
            .clip(shape)
            .drawBehind { glass(radius.toPx(), tint) },
        content = content,
    )
}

private fun DrawScope.glass(r: Float, tint: Color) {
    // Base: near-black with the tint mixed in.
    //
    // 0.06 was tuned by eye against a full-size preview and never checked
    // against how this actually looks on the pill it is used on — a compact,
    // single-line capsule maybe 34dp tall. At that size, with video
    // compression on top, 6% tint reads as flat black; a screenshot back
    // confirmed it looks like a plain dark rounded rectangle with no visible
    // colour at all. 0.22 is a real, legible tint -- still dark enough for
    // white text to sit on, but the pill is now recognisably Lilac-tinted or
    // Butter-tinted rather than indistinguishable from Ink.
    val base = lerp(Color(0xFF0B0B10), tint, 0.22f)
    drawRect(color = base)

    // The halo. Off-centre and upper-left of true centre, matching where the
    // reference's glow sits relative to its icon -- dead-centre reads as a
    // spotlight, off-centre reads as ambient light already in the room.
    //
    // Alpha raised alongside the base tint for the same reason: 0.55/0.22
    // barely registered at this pill's real size. 0.85/0.40 is a genuine
    // bright core with visible falloff, not a suggestion of one.
    val haloCentre = Offset(size.width * 0.38f, size.height * 0.32f)
    val haloRadius = size.minDimension * 0.9f
    drawCircle(
        brush = Brush.radialGradient(
            colorStops = arrayOf(
                0f to tint.copy(alpha = 0.85f),
                0.4f to tint.copy(alpha = 0.40f),
                1f to Color.Transparent,
            ),
            center = haloCentre,
            radius = haloRadius,
        ),
        radius = haloRadius,
        center = haloCentre,
    )

    // Grain. Deterministic, not Random() -- a fresh random seed every
    // recomposition would make the noise crawl instead of sit still, which
    // reads as a rendering glitch rather than as texture.
    val dots = 130  // more grain for a denser frosted read
    for (i in 0 until dots) {
        val fx = pseudo(i, 12.9898f)
        val fy = pseudo(i, 78.233f)
        val x = fx * size.width
        val y = fy * size.height
        val a = 0.03f + 0.05f * pseudo(i, 45.16f)
        drawCircle(
            color = Color.White.copy(alpha = a),
            radius = 1.1f,
            center = Offset(x, y),
        )
    }

    // A diagonal sheen, the way glass photographed under one light source
    // always carries a soft streak across it. This is a linear gradient with
    // a bright band in its middle stop rather than at either end, so it reads
    // as a reflection crossing the panel instead of a lit corner (that is
    // what the rim below already does).
    drawRect(
        brush = Brush.linearGradient(
            colorStops = arrayOf(
                0f to Color.Transparent,
                0.38f to Color.Transparent,
                0.5f to Color.White.copy(alpha = 0.12f),
                0.62f to Color.Transparent,
                1f to Color.Transparent,
            ),
            start = Offset(0f, size.height),
            end = Offset(size.width, 0f),
        ),
    )

    // The lit rim: bright top-left, gone by bottom-right, drawn as a stroke
    // just inside the shape's own bounds.
    drawRoundRect(
        brush = Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.70f),
                Color.White.copy(alpha = 0.14f),
                Color.Transparent,
            ),
            start = Offset(0f, 0f),
            end = Offset(size.width * 0.8f, size.height * 0.8f),
        ),
        cornerRadius = CornerRadius(r, r),
        style = Stroke(width = 1.8.dp.toPx()),
    )
}

/** A stable pseudo-random value in 0..1 from an index and a seed. */
private fun pseudo(i: Int, seed: Float): Float {
    val v = sin(i * seed) * 43758.5453f
    return v - kotlin.math.floor(v)
}
