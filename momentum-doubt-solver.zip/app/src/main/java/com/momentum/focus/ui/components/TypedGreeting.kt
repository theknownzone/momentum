package com.momentum.focus.ui.components

import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay
import java.time.LocalTime

/**
 * Greeting that types itself, once per app launch — each letter arriving
 * with a genuine blur-in, not just a fade.
 *
 * The trailing cursor and per-character delay are what make it read as being
 * addressed rather than labelled. Repeating it on every recomposition would
 * turn a nice touch into a stutter, so the animation is keyed to the name and
 * runs a single time.
 *
 * The opener itself is picked at random from a short list for whichever part
 * of the day it is, rather than always being the one fixed line for that
 * bucket — the same reason a person doesn't say "good morning" identically
 * every day. It is picked once per launch (inside `remember`, no key), not
 * re-rolled on every recomposition, so the greeting does not change out from
 * under itself mid-type.
 *
 * Each letter is its own small Text rather than one string, because that is
 * the only way to blur one letter without blurring the ones already
 * settled — a single Text has one paint call, one blur or none for the
 * whole run. `RenderEffect.createBlurEffect` is API 31+, so below that this
 * still types in with the fade and the settle-in slide alone; nothing
 * crashes, the letters just arrive a little flatter on those phones.
 */
@Composable
fun TypedGreeting(
    name: String,
    modifier: Modifier = Modifier,
    nameColor: Color = MaterialTheme.colorScheme.onBackground,
    labelColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    // True once this has already typed itself out once this app session —
    // set by the caller from state that survives HomeScreen being disposed
    // and recomposed on every tab switch, which this composable's own
    // `remember` does not. Without it, "once per launch" was actually
    // "once per visit to this tab", the retype and reblur firing again
    // every time — see HomeSession in HomeScreen.kt.
    alreadyPlayed: Boolean = false,
) {
    val greeting = remember {
        val options = when (LocalTime.now().hour) {
            in 5..11 -> listOf("Good morning", "Morning", "Rise and shine")
            in 12..16 -> listOf("Good afternoon", "Afternoon", "Hey")
            in 17..20 -> listOf("Good evening", "Evening", "Hey")
            else -> listOf("Good night", "Up late?", "Still going")
        }
        options.random()
    }

    val full = remember(name, greeting) { "$greeting, $name" }
    var shown by remember(full) { mutableIntStateOf(if (alreadyPlayed) full.length else 0) }
    var done by remember(full) { mutableStateOf(alreadyPlayed) }

    LaunchedEffect(full) {
        if (alreadyPlayed) return@LaunchedEffect
        shown = 0
        done = false
        // A short lead-in so the text is not already typing before the screen
        // has settled into place.
        delay(220)
        while (shown < full.length) {
            delay(38)
            shown++
        }
        delay(400)
        done = true
    }

    Box(modifier) {
        // The finished string, laid out invisibly, purely to fix the height.
        //
        // Without it this composable is one line tall on the first frame and
        // two lines tall a second later: at headlineSmall, in the column that
        // is left over after the avatar and the bell, "Good afternoon, <name>"
        // wraps partway through the typing. That second line grew the Row, the
        // Row grew the hero, and because SkinWeather is matchParentSize the
        // weather re-laid-out with it — which is the theme band that "stretches
        // once and settles" when you land on Home. Reserving the final height
        // up front means the box the weather draws into never changes size.
        //
        // Sized on "$full|" rather than full, because the cursor is still
        // appended for the 400ms after the last character lands.
        Text(
            text = "$full|",
            style = MaterialTheme.typography.headlineSmall,
            color = Color.Transparent,
        )
        Row {
            for (i in full.indices) {
                key(i) {
                    ArrivingChar(char = full[i], visible = i < shown, color = nameColor)
                }
            }
            if (!done) {
                Text("|", style = MaterialTheme.typography.headlineSmall, color = nameColor)
            }
        }
    }
}

@Composable
private fun ArrivingChar(char: Char, visible: Boolean, color: Color) {
    val t by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(190, easing = LinearOutSlowInEasing),
        label = "char",
    )
    if (t <= 0f) return
    Text(
        char.toString(),
        style = MaterialTheme.typography.headlineSmall,
        color = color,
        modifier = Modifier
            .alpha(t)
            .graphicsLayer {
                translationX = (1f - t) * -6f
                if (Build.VERSION.SDK_INT >= 31) {
                    val radius = ((1f - t) * 7f).coerceAtLeast(0.01f)
                    renderEffect = RenderEffect
                        .createBlurEffect(radius, radius, Shader.TileMode.CLAMP)
                        .asComposeRenderEffect()
                }
            },
    )
}
