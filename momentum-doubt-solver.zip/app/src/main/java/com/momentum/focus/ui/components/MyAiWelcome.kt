package com.momentum.focus.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.tr
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Sticker
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val Night = Color(0xFF0B0A10)

/**
 * MyAI's first-time welcome (replaces AiZomatoReveal, 2026-10-07).
 *
 * The old reveal ran on EVERY tab open, said "Thinking… / Getting your answer
 * ready" before anything had been asked, stacked "Hi, name" on top of the
 * status line, let taps fall through to the blurred chat, and was English
 * only. Owner: "MyAI start is broken".
 *
 * This one plays ONCE per install (OnceFlags), and only says true things:
 *
 *   0.00  dark stage; 13 dots fly in and lock into a sparkle    BLOOM pad
 *   0.70  sparkle glides up to the top third
 *   0.90  "Hi Rahul," rises          1.15  "I'm MyAI…" rises
 *   1.75 / 2.05 / 2.35  three promises rise, one each           CHIME ×3, climbing
 *   2.80  "Ask my first doubt" settles in (pinned above nav bar)
 *
 * Motion is fade + 14dp rise on a cubic ease-out, 420ms — paced, no pops.
 * Nothing auto-closes: the student reads, then taps. Skip (top right) and
 * Back close it at any time. LOW tier drops the glow halos.
 */
@Composable
fun MyAiWelcome(name: String, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val haptics = rememberHaptics()
    val rich = remember { DeviceProfile.tier(ctx) != DeviceProfile.Tier.LOW }
    var t by remember { mutableFloatStateOf(0f) }
    var closing by remember { mutableStateOf(false) }
    fun close() {
        if (closing) return
        closing = true
        haptics.confirm()
        Sfx.play(Sound.DONE)
        onDone()
    }
    BackHandler { close() }

    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        // Runs a little past the last beat so the idle breathing keeps going.
        while (true) {
            withFrameNanos { now -> t = (now - start) / 1_000_000f }
            if (closing) break
        }
    }
    val fired = remember { mutableSetOf<Int>() }
    SideEffect {
        fun beat(id: Int, at: Float, fn: () -> Unit) { if (t >= at && fired.add(id)) fn() }
        beat(0, 80f) { Sfx.playOnce(Sound.BLOOM) }
        beat(1, 640f) { haptics.tick() }
        beat(2, 1750f) { Sfx.playOnce(Sound.CHIME, 1.0f) }
        beat(3, 2050f) { Sfx.playOnce(Sound.CHIME, 1.12f) }
        beat(4, 2350f) { Sfx.playOnce(Sound.CHIME, 1.26f) }
    }

    fun seg(a: Float, d: Float) = ((t - a) / d).coerceIn(0f, 1f)
    fun ease(x: Float) = 1f - (1f - x) * (1f - x) * (1f - x)
    fun rise(a: Float) = ease(seg(a, 420f))

    val greet = if (name.isBlank()) tr("Hi there,", "नमस्ते,") else tr("Hi $name,", "नमस्ते $name,")

    Box(
        Modifier
            .fillMaxSize()
            .background(Night.copy(alpha = 0.97f))
            // Swallows every tap: nothing may reach the chat underneath.
            .clickableNoRipple(remember { MutableInteractionSource() }) { },
    ) {
        val assemble = ease(seg(0f, 640f))
        val glide = ease(seg(700f, 600f))
        val breathe = 1f + 0.035f * sin(t / 1000f * 2f * PI.toFloat() / 1.8f)

        val k = t / 1000f
        if (rich) {
            Canvas(Modifier.fillMaxSize()) {
                drawRect(
                    Brush.radialGradient(
                        listOf(Lilac.accent.copy(alpha = 0.30f), Color.Transparent),
                        center = Offset(size.width * (0.1f + 0.06f * sin(k * 0.5f)), size.height * 0.85f),
                        radius = size.width * 1.2f,
                    ),
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(Sky.accent.copy(alpha = 0.26f), Color.Transparent),
                        center = Offset(size.width * (0.92f + 0.05f * cos(k * 0.4f)), size.height * 0.12f),
                        radius = size.width * 1.1f,
                    ),
                )
            }
        }

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(bottom = rememberSafeBottom())
                .padding(horizontal = 26.dp),
        ) {
            // Scrolls on a tiny phone / huge font, so the button below can
            // never be pushed off screen.
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Spacer(Modifier.height(44.dp))
                // The sparkle assembles lower down, then glides up into its
                // slot as the words arrive.
                Canvas(
                    Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .graphicsLayer { translationY = (1f - glide) * 150.dp.toPx() },
                ) {
                    val unit = 9.dp.toPx()
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    if (rich) {
                        drawCircle(
                            Brush.radialGradient(
                                listOf(Butter.fill.copy(alpha = 0.24f * assemble), Color.Transparent),
                                center = Offset(cx, cy),
                                radius = unit * 7f,
                            ),
                            radius = unit * 7f,
                            center = Offset(cx, cy),
                        )
                    }
                    val turn = sin(k * 0.6f) * 0.25f
                    val cr = cos(turn)
                    val sr = sin(turn)
                    SPARKLE.forEachIndexed { i, (col, row) ->
                        val bx = col * unit * 1.6f
                        val by = row * unit * 1.6f
                        val tx = bx * cr - by * sr
                        val ty = bx * sr + by * cr
                        val from = SCATTER[i] * unit
                        val px = from.x + (tx - from.x) * assemble
                        val py = from.y + (ty - from.y) * assemble
                        val r = kotlin.math.sqrt((col * col + row * row).toFloat())
                        val ripple = 0.5f + 0.5f * sin(k * 5.2f - r * 1.3f)
                        val s = unit * 0.42f * (0.6f + 0.5f * ripple) * breathe
                        drawRoundRect(
                            Color.White.copy(alpha = assemble * (0.5f + 0.5f * ripple)),
                            topLeft = Offset(cx + px - s / 2f, cy + py - s / 2f),
                            size = Size(s, s),
                            cornerRadius = CornerRadius(s * 0.3f),
                        )
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text(
                    greet,
                    fontSize = 28.sp,
                    lineHeight = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    modifier = Modifier.riseIn(rise(900f)),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    tr("I'm MyAI. Stuck on a question? I'll walk you through it.",
                        "मैं MyAI हूँ। कोई सवाल अटका? मैं स्टेप-बाय-स्टेप समझाऊँगा।"),
                    fontSize = 17.sp,
                    lineHeight = 23.sp,
                    color = Color.White.copy(alpha = 0.78f),
                    modifier = Modifier.riseIn(rise(1150f)),
                )
                Spacer(Modifier.height(26.dp))
                Promise(Icons.Filled.PhotoCamera, Mint,
                    tr("Snap the question, get the steps", "सवाल की फ़ोटो लो, स्टेप्स पाओ"),
                    Modifier.riseIn(rise(1750f)))
                Spacer(Modifier.height(12.dp))
                Promise(Icons.Filled.Translate, Sky,
                    tr("Ask in English or Hinglish", "इंग्लिश या हिंग्लिश, जैसे चाहो पूछो"),
                    Modifier.riseIn(rise(2050f)))
                Spacer(Modifier.height(12.dp))
                Promise(Icons.Filled.Bolt, Butter,
                    tr("Study sessions refill your questions", "पढ़ाई के सेशन से सवाल फिर भरते हैं"),
                    Modifier.riseIn(rise(2350f)))
                Spacer(Modifier.height(20.dp))
            }
            Box(Modifier.riseIn(rise(2800f))) {
                SquishButton(
                    tr("Ask my first doubt", "पहला सवाल पूछो"),
                    Butter,
                    Modifier.fillMaxWidth(),
                    enabled = t > 2800f,
                ) { close() }
            }
            Spacer(Modifier.height(14.dp))
        }

        // Skip — available from the first second, never hidden.
        Text(
            tr("Skip", "छोड़ें"),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White.copy(alpha = 0.62f * seg(500f, 400f)),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(8.dp)
                .clip(RoundedCornerShape(50))
                .clickableNoRipple(remember { MutableInteractionSource() }) { close() }
                .padding(horizontal = 14.dp, vertical = 8.dp),
        )
    }
}

@Composable
private fun Promise(icon: ImageVector, sticker: Sticker, text: String, modifier: Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(sticker.fill)
                .border(2.dp, Color.Black, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = sticker.on, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text(text, fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold, color = Color.White.copy(alpha = 0.92f))
    }
}

/** Fade + 14dp rise, driven by an already-eased 0..1. Draw-phase only. */
private fun Modifier.riseIn(p: Float): Modifier = graphicsLayer {
    alpha = p
    translationY = (1f - p) * 14.dp.toPx()
}

private val SPARKLE = listOf(
    0 to 0,
    0 to -1, 0 to -2, 0 to 1, 0 to 2,
    1 to 0, 2 to 0, -1 to 0, -2 to 0,
    1 to -1, -1 to -1, 1 to 1, -1 to 1,
)
private val SCATTER: List<Offset> = run {
    val rnd = kotlin.random.Random(42)
    SPARKLE.map { Offset(rnd.nextFloat() * 2f - 1f, rnd.nextFloat() * 2f - 1f) * 9f }
}
