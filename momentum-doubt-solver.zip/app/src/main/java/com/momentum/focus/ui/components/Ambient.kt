package com.momentum.focus.ui.components

import androidx.compose.animation.core.InfiniteRepeatableSpec
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.momentum.focus.ui.theme.Vibe
import com.momentum.focus.ui.util.DeviceProfile

/**
 * An idle, looping animation that is decoration, not information (glows,
 * sweeps, pulses, slow spins).
 *
 * LAG FIX: Home is one long scrolling Column, so every looping effect on it
 * kept the frame clock running and redrew its part of the screen 60×/s for
 * as long as Home was open — on screen or scrolled far away. Seven of them at
 * once is what the owner felt as lag.
 *
 * These now run only in the playful (Pro) look and never on low-end phones;
 * otherwise they rest at [initialValue] and cost nothing.
 */
@Composable
fun ambient(
    initialValue: Float,
    targetValue: Float,
    animationSpec: InfiniteRepeatableSpec<Float>,
    label: String = "ambient",
): State<Float> {
    val ctx = LocalContext.current
    val low = remember { DeviceProfile.isLowEnd(ctx) }
    return if (Vibe.playful && !low) {
        rememberInfiniteTransition(label).animateFloat(initialValue, targetValue, animationSpec, label)
    } else {
        remember { mutableFloatStateOf(initialValue) }
    }
}
