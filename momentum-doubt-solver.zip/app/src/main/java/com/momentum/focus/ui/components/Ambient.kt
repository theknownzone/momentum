package com.momentum.focus.ui.components

import androidx.compose.animation.core.InfiniteRepeatableSpec
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.blur
import androidx.compose.ui.platform.LocalContext
import com.momentum.focus.ui.theme.Vibe
import com.momentum.focus.ui.util.DeviceProfile

/**
 * An idle, looping animation that is decoration, not information (glows,
 * sweeps, pulses, slow spins).
 *
 * LAG FIX: Home is one long scrolling Column, so every looping effect on it
 * kept the frame clock running and redrew its part of the screen 60×/s for
 * as long as Home was open — on screen or scrolled far away. Seven of them at
 * once is what the owner felt as lag.
 *
 * These now run only in the playful (Pro) look and never on low-end phones;
 * otherwise they rest at [initialValue] and cost nothing.
 */
@Composable
fun ambient(
    initialValue: Float,
    targetValue: Float,
    animationSpec: InfiniteRepeatableSpec<Float>,
    label: String = "ambient",
): State<Float> {
    val ctx = LocalContext.current
    val low = remember { DeviceProfile.isLowEnd(ctx) }
    return if (Vibe.playful && !low) {
        rememberInfiniteTransition(label).animateFloat(initialValue, targetValue, animationSpec, label)
    } else {
        remember { mutableFloatStateOf(initialValue) }
    }
}

/**
 * Whether a real RenderEffect blur is worth drawing here.
 *
 * Blur is API 31+ (a silent no-op below), and on a cheap phone it is the
 * single most expensive thing a frame can do — a full offscreen pass per
 * blurred layer, every frame it is animated. Low-end phones skip it and each
 * caller keeps its own non-blur fallback (a radial gradient, a dimmer, or
 * nothing for pure decoration). Settled once per composition site.
 */
@Composable
fun rememberCanBlur(): Boolean {
    val ctx = LocalContext.current
    return remember { android.os.Build.VERSION.SDK_INT >= 31 && !DeviceProfile.isLowEnd(ctx) }
}

/** [androidx.compose.ui.draw.blur] only when [on]; otherwise the modifier is untouched. */
fun androidx.compose.ui.Modifier.blurIf(on: Boolean, radius: androidx.compose.ui.unit.Dp): androidx.compose.ui.Modifier =
    if (on) this.then(androidx.compose.ui.Modifier.blur(radius)) else this

/**
 * Like [ambient], but keeps running in the Minimal (free) look — for loops
 * that carry meaning (a live session's halo, a "scanning" beam) rather than
 * pure Pro decoration. Only cheap phones get the still frame.
 */
@Composable
fun lowEndLoop(
    initialValue: Float,
    targetValue: Float,
    animationSpec: InfiniteRepeatableSpec<Float>,
    label: String = "loop",
): State<Float> {
    val ctx = LocalContext.current
    val low = remember { DeviceProfile.isLowEnd(ctx) }
    return if (!low) {
        rememberInfiniteTransition(label).animateFloat(initialValue, targetValue, animationSpec, label)
    } else {
        remember { mutableFloatStateOf(initialValue) }
    }
}


/**
 * Loop that runs only when the phone's tier is at least [min]
 * (DeviceProfile.Tier: HIGH all, MID signature, LOW the essentials).
 */
@Composable
fun tierLoop(
    min: DeviceProfile.Tier,
    initialValue: Float,
    targetValue: Float,
    animationSpec: InfiniteRepeatableSpec<Float>,
    label: String = "tier-loop",
): State<Float> {
    val ctx = LocalContext.current
    val on = remember { DeviceProfile.tier(ctx) >= min }
    return if (on) rememberInfiniteTransition(label).animateFloat(initialValue, targetValue, animationSpec, label)
    else remember { mutableFloatStateOf(initialValue) }
}
