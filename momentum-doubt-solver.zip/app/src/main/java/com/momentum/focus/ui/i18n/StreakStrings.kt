package com.momentum.focus.ui.i18n

/** Streak 2.0 copy: freezes, the first-week run, the "freeze saved it" notice. */
interface StreakStrings {
    val freezeTitle: String
    fun equipped(n: Int, cap: Int): String
    val freezeHow: String
    fun buy(price: String): String
    val full: String
    fun needMore(price: String): String
    val bought: String
    fun savedTitle(days: Int): String
    val savedSub: String
    val firstWeekStart: String
    fun firstWeekDay(n: Int): String
}

object StreakEn : StreakStrings {
    override val freezeTitle = "STREAK FREEZE"
    override fun equipped(n: Int, cap: Int) = "$n/$cap equipped"
    override val freezeHow = "Miss a day? A freeze covers it automatically. Bought with Scroll-₹, never real money."
    override fun buy(price: String) = "Buy · $price"
    override val full = "Fully stocked"
    override fun needMore(price: String) = "Earn $price to buy one"
    override val bought = "Freeze equipped. Streak insured."
    override fun savedTitle(days: Int) = "FREEZE USED · $days-DAY STREAK SAFE"
    override val savedSub = "Tap to dismiss"
    override val firstWeekStart = "Start your 7-day run"
    override fun firstWeekDay(n: Int) = "Day $n of 7"
}

object StreakHi : StreakStrings {
    override val freezeTitle = "STREAK FREEZE"
    override fun equipped(n: Int, cap: Int) = "$n/$cap ready"
    override val freezeHow = "Ek din chhoot gaya? Freeze khud cover kar dega. Scroll-₹ se milta hai, asli paise se nahi."
    override fun buy(price: String) = "Lo · $price"
    override val full = "Full stock"
    override fun needMore(price: String) = "$price kamao, phir lo"
    override val bought = "Freeze ready. Streak insured."
    override fun savedTitle(days: Int) = "FREEZE LAGA · $days-DIN KI STREAK BACH GAYI"
    override val savedSub = "Hatane ke liye tap karo"
    override val firstWeekStart = "7 din ka run shuru karo"
    override fun firstWeekDay(n: Int) = "Din $n / 7"
}
