package com.momentum.focus.ui.i18n

interface WelcomeStrings {
    val howItWorksLabel: String
    val howItWorksTitle: String
    val howItWorksBody: String

    val catchLabel: String
    val catchTitle: String
    val catchBody: String

    val dataLabel: String
    val dataTitle: String
    val dataBody: String

    val hardLabel: String
    val hardTitle: String
    val hardBody: String

    val lastThing: String
    val nameQuestion: String
    val namePlaceholder: String
    val youllSee: String
    fun welcomeBack(name: String): String
    val welcomeBackAnon: String

    val start: String
    val next: String
    val skip: String
}

object WelcomeHi : WelcomeStrings {
    override val howItWorksLabel = "यह कैसे काम करता है"
    override val howItWorksTitle = "फ़ोकस ही पैसा है।"
    override val howItWorksBody = "1 मिनट पढ़ाई = 1 मिनट जमा। इसे सिर्फ़ पढ़ाई भरती है।"

    override val catchLabel = "शर्त"
    override val catchTitle = "स्क्रॉल महँगा है।"
    override val catchBody = "रील्स आपका बैलेंस ख़र्च करती हैं। वॉलेट ख़ाली, ऐप लॉक। क़ीमत अभी तय करें, जब मन शांत है।"

    override val dataLabel = "आपका डेटा"
    override val dataTitle = "फ़ोन पर ही रहता है।"
    override val dataBody = "कोई सर्वर नहीं। कोई लॉगिन नहीं। स्क्रीन एक्सेस सिर्फ़ यह देखता है कि Shorts खुला है या नहीं। कुछ बाहर नहीं जाता।"

    override val hardLabel = "जब मुश्किल हो"
    override val hardTitle = "एक टैप में बाहर।"
    override val hardBody = "तलब ~10 मिनट में चरम पर होती है। Panic दबाएँ, निकल जाने दें। चूक दर्ज होती है, उस पर फ़ैसला नहीं।"

    override val lastThing = "आख़िरी बात"
    override val nameQuestion = "आपको क्या बुलाऊँ?"
    override val namePlaceholder = "आपका नाम"
    override val youllSee = "आप देखेंगे"
    override fun welcomeBack(name: String) = "फिर से स्वागत है, $name।"
    override val welcomeBackAnon = "फिर से स्वागत है।"

    override val start = "शुरू करें"
    override val next = "आगे"
    override val skip = "छोड़ें"
}

object WelcomeEn : WelcomeStrings {
    override val howItWorksLabel = "HOW IT WORKS"
    override val howItWorksTitle = "Focus is money."
    override val howItWorksBody = "1 minute studied = 1 minute banked. Only studying fills it."

    override val catchLabel = "THE CATCH"
    override val catchTitle = "Scrolling costs."
    override val catchBody = "Reels spend your balance. Empty wallet, locked app. Set the price now, while you're calm."

    override val dataLabel = "YOUR DATA"
    override val dataTitle = "Stays on your phone."
    override val dataBody = "No server. No login. Screen access only checks if Shorts is open. Nothing leaves."

    override val hardLabel = "WHEN IT'S HARD"
    override val hardTitle = "One tap out."
    override val hardBody = "Urges peak in ~10 min. Hit Panic, ride it out. Slips get logged, not judged."

    override val lastThing = "LAST THING"
    override val nameQuestion = "What should I call you?"
    override val namePlaceholder = "Your name"
    override val youllSee = "YOU'LL SEE"
    override fun welcomeBack(name: String) = "Welcome back, $name."
    override val welcomeBackAnon = "Welcome back."

    override val start = "Start"
    override val next = "Next"
    override val skip = "Skip"
}

interface PermissionStrings {
    val setup: String
    val title: String
    val body: String
    fun progress(done: Int, total: Int): String
    val required: String
    val optional: String
    val crownExtras: String
    val on: String
    val requiredForCrown: String

    val deviceAdmin: String
    val deviceAdminOn: String
    val deviceAdminOff: String

    val shortsGuard: String
    val shortsGuardOn: String
    val shortsGuardOff: String
    val shortsGuardHint: String

    val killsBackground: String
    val autostart: String
    val autostartBody: String

    val start: String
    val grantFirst: String
    val mustHave: String
    val grant: String
}

object PermissionHi : PermissionStrings {
    override val setup = "SETUP"
    override val title = "Give it control"
    override val body =
        "Blocking apps needs real permissions. Nothing leaves your phone — " +
            "there is no server."
    override fun progress(done: Int, total: Int) = "$done / $total zaroori"
    override val required = "REQUIRED"
    override val optional = "OPTIONAL"
    override val crownExtras = "HARD / CROWN — ye do bhi chahiye"
    override val on = "ON"
    override val requiredForCrown = "REQUIRED FOR CROWN"

    override val deviceAdmin = "Device admin"
    override val deviceAdminOn =
        "Uninstall ke liye pehle yahi permission band karni padegi. " +
            "Ek extra kadam, deewar nahi."
    override val deviceAdminOff =
        "Crown mode iske bina on nahi hoga. Uninstall mushkil " +
            "banata hai — factory reset phir bhi kaam karta hai."

    override val shortsGuard = "Shorts / Reels guard"
    override val shortsGuardOn =
        "Shorts aur Reels band, lecture aur chat chalti rahegi."
    override val shortsGuardOff =
        "Iske bina baaki sab chalega — sirf Shorts aur Reels nahi rukengi. " +
            "Poori app band karni ho to wo Block se hota hai."
    override val shortsGuardHint =
        "Toggle wapas off ho jaaye to: App info → ⋮ upar right → " +
            "\"Allow restricted settings\" → phir dobara try karo."

    override val killsBackground = "THIS PHONE KILLS BACKGROUND APPS"
    override val autostart = "Autostart"
    override val autostartBody =
        "Iske bina Shield raat mein chup ho jaati hai. Android is switch ko " +
            "padhne nahi deta, isliye app confirm nahi kar sakta — khud check karna."

    override val start = "Start"
    override val grantFirst = "Grant required first"
    override val mustHave = "Usage + overlay + battery — teeno must. Tab tak aage nahi."
    override val grant = "GRANT"
}

object PermissionEn : PermissionStrings {
    override val setup = "SETUP"
    override val title = "Give it control"
    override val body =
        "Blocking apps needs real permissions. Nothing leaves your phone — " +
            "there is no server."
    override fun progress(done: Int, total: Int) = "$done / $total required"
    override val required = "REQUIRED"
    override val optional = "OPTIONAL"
    override val crownExtras = "HARD / CROWN — these two as well"
    override val on = "ON"
    override val requiredForCrown = "REQUIRED FOR CROWN"

    override val deviceAdmin = "Device admin"
    override val deviceAdminOn =
        "Uninstalling means turning this permission off first. " +
            "One extra step, not a wall."
    override val deviceAdminOff =
        "Crown mode won't turn on without this. It makes uninstalling hard — " +
            "a factory reset still works."

    override val shortsGuard = "Shorts / Reels guard"
    override val shortsGuardOn =
        "Shorts and Reels blocked; lectures and chat keep working."
    override val shortsGuardOff =
        "Everything else still works without this — only Shorts and Reels " +
            "won't be stopped. To block a whole app, use Block instead."
    override val shortsGuardHint =
        "If the toggle flips back off: App info → ⋮ top right → " +
            "\"Allow restricted settings\" → then try again."

    override val killsBackground = "THIS PHONE KILLS BACKGROUND APPS"
    override val autostart = "Autostart"
    override val autostartBody =
        "Without this, Shield goes quiet overnight. Android won't let the app " +
            "read this switch, so it can't confirm — check it yourself."

    override val start = "Start"
    override val grantFirst = "Grant required first"
    override val mustHave = "Usage + overlay + battery — all three. No further until then."
    override val grant = "GRANT"
}
