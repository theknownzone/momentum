package com.momentum.focus.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.util.DeviceProfile
import kotlin.math.sin

private val Space1 = Color(0xFF07051A)
private val Space2 = Color(0xFF1B0F3F)
private val NebViolet = Color(0xFF7B3CFF)
private val NebPink = Color(0xFFFF3DAE)
private val NebCyan = Color(0xFF3DE7FF)

/**
 * The update download bar, galactic edition (owner 2026-10-07: "update
 * downloaded bar galactic"). Replaces the mint "web" bar.
 *
 *  - the empty track is deep space: two layers of stars drifting left at
 *    different speeds (parallax), each twinkling on its own phase
 *  - the filled part is a nebula — violet → pink → cyan — with two slow
 *    colour clouds swirling inside it
 *  - a comet rides the leading edge: white core, cyan bloom, a tail of
 *    sparks streaming back into the nebula
 *  - violet light spills outside the bar (drawn before the clip)
 *  - the percentage sits in the middle in white mono
 * LOW tier: fewer stars, no outer glow, fewer sparks.
 */
@Composable
fun GalaxyBar(progress: Float, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val rich = remember { DeviceProfile.tier(ctx) != DeviceProfile.Tier.LOW }
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) withFrameNanos { now -> t = (now - start) / 1_000_000_000f }
    }
    val stars = remember(rich) {
        val r = kotlin.random.Random(5)
        List(if (rich) 46 else 22) {
            floatArrayOf(r.nextFloat(), r.nextFloat(), r.nextFloat(), if (r.nextFloat() < 0.5f) 0f else 1f)
        }
    }
    val p = progress.coerceIn(0f, 1f)
    val shape = RoundedCornerShape(50)

    Box(
        modifier
            .fillMaxWidth()
            .height(26.dp)
            .drawBehind {
                if (!rich) return@drawBehind
                val w = size.width * p
                if (w <= 1f) return@drawBehind
                for (k in 1..3) {
                    val s = k * 3.5.dp.toPx()
                    drawRoundRect(
                        NebViolet.copy(alpha = 0.16f - k * 0.04f),
                        topLeft = Offset(-s, -s),
                        size = Size(w + s * 2, size.height + s * 2),
                        cornerRadius = CornerRadius(size.height),
                    )
                }
            }
            .clip(shape)
            .drawBehind {
                val w = size.width * p
                val h = size.height
                // Space.
                drawRect(Brush.horizontalGradient(listOf(Space1, Space2, Space1)))
                stars.forEach { s ->
                    val layer = s[3]
                    val speed = if (layer == 0f) 0.010f else 0.026f
                    val x = (((s[0] - t * speed) % 1f) + 1f) % 1f * size.width
                    val y = (0.12f + s[1] * 0.76f) * h
                    val tw = 0.35f + 0.65f * (0.5f + 0.5f * sin(t * (2f + s[2] * 3f) + s[2] * 20f))
                    val r = (if (layer == 0f) 0.6f else 1.0f).dp.toPx()
                    drawCircle(Color.White.copy(alpha = tw * (if (layer == 0f) 0.5f else 0.9f)), r, Offset(x, y))
                }
                if (w <= 1f) return@drawBehind
                // Nebula fill.
                clipRect(right = w) {
                    drawRect(Brush.horizontalGradient(listOf(NebViolet, NebPink, NebCyan), startX = 0f, endX = maxOf(w, h)))
                    val c1 = Offset(w * (0.3f + 0.15f * sin(t * 0.7f)), h * 0.4f)
                    val c2 = Offset(w * (0.7f + 0.12f * sin(t * 0.9f + 2f)), h * 0.7f)
                    drawCircle(
                        Brush.radialGradient(listOf(Color.White.copy(alpha = 0.28f), Color.Transparent), center = c1, radius = h * 1.6f),
                        h * 1.6f, c1,
                    )
                    drawCircle(
                        Brush.radialGradient(listOf(NebViolet.copy(alpha = 0.55f), Color.Transparent), center = c2, radius = h * 1.4f),
                        h * 1.4f, c2,
                    )
                    // Faint stars still visible through the gas.
                    stars.forEach { s ->
                        val x = (((s[0] - t * 0.02f) % 1f) + 1f) % 1f * size.width
                        if (x < w) drawCircle(Color.White.copy(alpha = 0.35f), 0.7.dp.toPx(), Offset(x, (0.12f + s[1] * 0.76f) * h))
                    }
                }
                // Comet tail: sparks streaming back from the head.
                val sparks = if (rich) 10 else 5
                for (i in 0 until sparks) {
                    val f = ((i / sparks.toFloat()) + t * 1.6f) % 1f
                    val x = w - f * h * 3.5f
                    if (x < 0f) continue
                    val y = h / 2f + sin(i * 2.3f + t * 6f) * h * 0.22f * f
                    drawLine(
                        Color.White.copy(alpha = (1f - f) * 0.8f),
                        Offset(x, y), Offset(x - h * 0.35f * (1f - f), y),
                        (1.6f * (1f - f) + 0.4f).dp.toPx(), StrokeCap.Round,
                    )
                }
                // Comet head.
                val head = Offset(w, h / 2f)
                drawCircle(
                    Brush.radialGradient(listOf(NebCyan.copy(alpha = 0.9f), NebCyan.copy(alpha = 0.25f), Color.Transparent), center = head, radius = h * 1.3f),
                    h * 1.3f, head,
                )
                drawCircle(Color.White, h * 0.22f, head)
            }
            .border(2.5.dp, Ink, shape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "${(p * 100).toInt()}%",
            style = TextStyle(
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                shadow = Shadow(Color.Black.copy(alpha = 0.7f), Offset(0f, 1f), 4f),
            ),
        )
    }
}
