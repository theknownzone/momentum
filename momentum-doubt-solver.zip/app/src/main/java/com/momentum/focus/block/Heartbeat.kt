package com.momentum.focus.block

import android.content.Context

/**
 * A kill by MIUI, ColorOS or Funtouch is silent. The process is torn down
 * without onDestroy(), so no code of ours runs at the moment it happens and
 * there is nothing to catch in the act.
 *
 * The only honest signal is a gap. While the service is alive it stamps the
 * clock every few seconds; if the app later opens and finds the shield was
 * supposed to be on but the last stamp is minutes old, the service was killed
 * and the user was unprotected for that whole window.
 *
 * This is deliberately not DataStore. The write happens inside the 350ms poll
 * loop and must not allocate a coroutine or touch a flow on every beat.
 */
object Heartbeat {

    private const val FILE = "momentum_heartbeat"
    private const val KEY_BEAT = "last_beat"
    private const val KEY_ARMED = "armed"
    private const val KEY_REPORTED = "reported_gap"

    /** A gap wider than this cannot be normal scheduling jitter. */
    private const val DEAD_AFTER_MS = 3 * 60 * 1000L

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** Called from the poll loop. Cheap, synchronous, no coroutine. */
    fun beat(context: Context) {
        prefs(context).edit()
            .putLong(KEY_BEAT, System.currentTimeMillis())
            .putBoolean(KEY_ARMED, true)
            .apply()
    }

    /** Called when the user turns the shield off on purpose. Gaps after this are expected. */
    fun disarm(context: Context) {
        prefs(context).edit()
            .putBoolean(KEY_ARMED, false)
            .remove(KEY_REPORTED)
            .apply()
    }

    /**
     * Minutes the shield was down without the user asking for it, or 0 when
     * nothing went wrong. Only meaningful while the shield is meant to be on.
     */
    fun deadMinutes(context: Context): Int {
        val p = prefs(context)
        if (!p.getBoolean(KEY_ARMED, false)) return 0
        val last = p.getLong(KEY_BEAT, 0L)
        if (last <= 0L) return 0
        val gap = System.currentTimeMillis() - last
        // A clock moved backwards produces a negative gap, which is not a kill.
        if (gap < DEAD_AFTER_MS) return 0
        return (gap / 60000L).toInt().coerceAtLeast(1)
    }

    // ── Outage record (owner bug: swipe-kill → nothing blocked, and the app
    // never said why). The live gap above vanishes the moment the service
    // restarts and beats again, which is exactly when the app opens — so the
    // gap is captured at restart and kept until the user has seen it.
    private const val KEY_OUT_MIN = "outage_min"
    private const val KEY_OUT_AT = "outage_at"

    fun isArmed(context: Context): Boolean = prefs(context).getBoolean(KEY_ARMED, false)

    /** Call at service start, BEFORE the first beat. */
    fun recordIfDead(context: Context) {
        val m = deadMinutes(context)
        if (m > 0) prefs(context).edit()
            .putInt(KEY_OUT_MIN, m)
            .putLong(KEY_OUT_AT, System.currentTimeMillis())
            .apply()
    }

    /** Minutes of the last unseen outage, or 0. Falls back to a live gap. */
    fun outageMinutes(context: Context): Int =
        prefs(context).getInt(KEY_OUT_MIN, 0).takeIf { it > 0 } ?: deadMinutes(context)

    fun clearOutage(context: Context) {
        prefs(context).edit().remove(KEY_OUT_MIN).remove(KEY_OUT_AT).apply()
    }
}
