package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkLow
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Tang
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * What tapping Shield on Home used to skip straight past: the actual
 * answer to "which apps did I turn on", shown here rather than only inside
 * the full edit screen. [onManage] is the one door out of this popup that
 * still leads to BlockHub, for when the answer to looking is "change one".
 *
 * [dailyCapMinutes] is the same map BlockListScreen reads to show its own
 * per-app cap, passed through here so this popup can say what happens when
 * you tap the app, not just that it's on the list — a blocked app with no
 * cap entry is a hard lock; one with an entry still opens for that many
 * minutes first.
 */
@Composable
fun BlockedAppsPopup(
    blockedPackages: Set<String>,
    dailyCapMinutes: Map<String, Int> = emptyMap(),
    blockedSince: Map<String, Long> = emptyMap(),
    onManage: () -> Unit,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    val labels = remember(blockedPackages) { mutableStateMapOf<String, String>() }
    LaunchedEffect(blockedPackages) {
        withContext(Dispatchers.IO) {
            blockedPackages.forEach { pkg ->
                val label = runCatching {
                    context.packageManager.getApplicationLabel(
                        context.packageManager.getApplicationInfo(pkg, 0),
                    ).toString()
                }.getOrDefault(pkg)
                labels[pkg] = label
            }
        }
    }

    Dialog(onDismissRequest = onClose) {
        // MATCH TO REFERENCE, LITERALLY: .sheet in the HTML has no border
        // and no shadow of its own — it's a plain paper-grid background.
        // Every visible edge in the reference (top-bar, each app-row, the
        // streak-strip, both buttons) is its own independently bordered and
        // shadowed card sitting on that background. The previous version of
        // this file nested all of that inside one big outer card instead —
        // which is not in the HTML anywhere; it was an addition, and the
        // instruction is to build what's there and nothing that isn't.
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(CreamCard)
                .paperGrain()
                .padding(16.dp),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .drawBehind {
                        val d = 6.dp.toPx()
                        drawRoundRect(
                            color = Ink,
                            topLeft = Offset(d, d),
                            size = size,
                            cornerRadius = CornerRadius(18.dp.toPx(), 18.dp.toPx()),
                        )
                    }
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.linearGradient(listOf(Mint.fill, Mint.accent)))
                    .border(3.dp, Ink, RoundedCornerShape(18.dp))
                    .padding(horizontal = 18.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "\uD83D\uDEE1\uFE0F SHIELD",
                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 26.sp, letterSpacing = 0.5.sp),
                    fontWeight = FontWeight.Black,
                    color = Mint.on,
                )
                Box(
                    Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(Ink)
                        .border(2.dp, Ink, RoundedCornerShape(999.dp))
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                ) {
                    Text(
                        "${blockedPackages.size} blocked",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Black,
                        color = Mint.fill,
                    )
                }
            }
            Spacer(Modifier.height(18.dp))

            if (blockedPackages.isEmpty()) {
                Column(
                    Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Lock3D(color = Mint.fill, size = 44.dp)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Nothing blocked yet",
                        style = MaterialTheme.typography.titleMedium,
                        color = Ink,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Pick a few apps and Shield actually has something to hold the line on.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                        textAlign = TextAlign.Center,
                    )
                }
            } else {
                LazyColumn(
                    Modifier.heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 4.dp),
                ) {
                    items(blockedPackages.toList(), key = { it }) { pkg ->
                        val cap = dailyCapMinutes[pkg]
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .drawBehind {
                                    val d = 4.dp.toPx()
                                    drawRoundRect(
                                        color = Ink,
                                        topLeft = Offset(d, d),
                                        size = size,
                                        cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx()),
                                    )
                                }
                                .clip(RoundedCornerShape(16.dp))
                                .background(CreamCard)
                                .border(2.5.dp, Ink, RoundedCornerShape(16.dp))
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box {
                                Box(
                                    Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(2.dp, Ink, RoundedCornerShape(12.dp)),
                                ) {
                                    AppIcon(pkg, size = 34.dp)
                                }
                                // Small red "off-limits" badge, corner-anchored on
                                // the icon — separate from the black lock pill at
                                // the row's end, which stays as the tap target.
                                Box(
                                    Modifier
                                        .align(Alignment.TopEnd)
                                        .offset(x = 4.dp, y = (-4).dp)
                                        .size(20.dp)
                                        .clip(CircleShape)
                                        .background(Tang.fill)
                                        .border(1.5.dp, Ink, CircleShape),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text("\uD83D\uDEAB", fontSize = 11.sp)
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    labels[pkg] ?: pkg,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Ink,
                                )
                                Text(
                                    "\uD83D\uDD12 " + if (cap == null) "Locked outright" else "Opens for $cap min, then locks",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Tang.accent,
                                )
                                // Live elapsed time since this package was
                                // actually blocked — not decorative: ticks for
                                // real off blockedSince, re-reading the clock
                                // once a minute rather than once at composition.
                                val since = blockedSince[pkg]
                                if (since != null) {
                                    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
                                    LaunchedEffect(since) {
                                        while (true) {
                                            nowMs = System.currentTimeMillis()
                                            delay(60_000L)
                                        }
                                    }
                                    val mins = ((nowMs - since) / 60_000L).coerceAtLeast(0)
                                    val label = when {
                                        mins < 1 -> "Blocked just now"
                                        mins < 60 -> "Blocked for ${mins}m"
                                        else -> "Blocked for ${mins / 60}h ${mins % 60}m"
                                    }
                                    Text(
                                        label,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = InkLow,
                                    )
                                }
                            }
                            Spacer(Modifier.width(8.dp))
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(Ink)
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                            ) {
                                Text("\uD83D\uDD12", fontSize = 11.sp, color = Mint.fill)
                            }
                        }
                    }
                }

                // The streak tie-in strip is new as of this pass, and the
                // hand-written "new!" callout above it is only worth
                // showing while it's actually new — a prefs-backed counter
                // caps it at 3 views total, then it never draws again.
                val prefs = remember { context.getSharedPreferences("momentum_hints", 0) }
                var streakHintShown by remember {
                    mutableStateOf(prefs.getInt("shield_streak_hint_shown", 0))
                }
                LaunchedEffect(Unit) {
                    if (streakHintShown < 3) {
                        prefs.edit().putInt("shield_streak_hint_shown", streakHintShown + 1).apply()
                    }
                }
                val glow by rememberInfiniteTransition(label = "hint-glow").animateFloat(
                    initialValue = 0.35f,
                    targetValue = 0.8f,
                    animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
                    label = "glow",
                )

                if (streakHintShown < 3) {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 14.dp, end = 34.dp),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "new!",
                            fontFamily = FontFamily.Cursive,
                            fontWeight = FontWeight.Bold,
                            fontSize = 30.sp,
                            color = Color(0xFF2255CC).copy(alpha = glow),
                            modifier = Modifier.graphicsLayer { rotationZ = -8f },
                        )
                        Spacer(Modifier.width(4.dp))
                        Canvas(Modifier.size(30.dp, 22.dp)) {
                            val col = Color(0xFF2255CC).copy(alpha = glow)
                            val path = Path().apply {
                                moveTo(size.width * 0.1f, size.height * 0.1f)
                                cubicTo(
                                    size.width * 0.3f, size.height * 0.3f,
                                    size.width * 0.25f, size.height * 0.65f,
                                    size.width * 0.5f, size.height * 0.55f,
                                )
                                cubicTo(
                                    size.width * 0.7f, size.height * 0.45f,
                                    size.width * 0.6f, size.height * 0.85f,
                                    size.width * 0.85f, size.height,
                                )
                            }
                            drawPath(path, col, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
                            drawLine(col, Offset(size.width * 0.65f, size.height * 0.9f), Offset(size.width * 0.85f, size.height), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(col, Offset(size.width * 0.78f, size.height * 0.65f), Offset(size.width * 0.85f, size.height), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                } else {
                    Spacer(Modifier.height(18.dp))
                }

                Row(
                    Modifier
                        .fillMaxWidth()
                        .drawBehind {
                            val d = 4.dp.toPx()
                            drawRoundRect(
                                color = Ink,
                                topLeft = Offset(d, d),
                                size = size,
                                cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx()),
                            )
                        }
                        .clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFFFFE9A8), Color(0xFFFFFCF4))))
                        .border(2.5.dp, Ink, RoundedCornerShape(14.dp))
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("\uD83D\uDD25", fontSize = 22.sp)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        buildAnnotatedString {
                            append("Every locked app adds to today\u2019s ")
                            withStyle(SpanStyle(color = Tang.accent)) { append("focus streak") }
                        },
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = Ink,
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    Modifier
                        .weight(1f)
                        .drawBehind {
                            val d = 4.dp.toPx()
                            drawRoundRect(
                                color = Ink,
                                topLeft = Offset(d, d),
                                size = size,
                                cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx()),
                            )
                        }
                        .clip(RoundedCornerShape(16.dp))
                        .background(CreamCard)
                        .border(3.dp, Ink, RoundedCornerShape(16.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClose)
                        .padding(vertical = 15.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("Close", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = Ink)
                }
                SlideFillButton(label = "Manage", modifier = Modifier.weight(1f), onClick = { onClose(); onManage() })
            }
        }
    }
}

/**
 * The dark-button-with-sliding-fill from the reference ("LET'S TALK") —
 * a black pill that fills with colour on press, its arrow rotating from
 * a diagonal to straight-ahead as it does, rather than a flat coloured
 * button with no motion of its own. Used for "Manage" specifically since
 * it's the button that actually goes somewhere else (BlockHub); "Close"
 * next to it goes nowhere, so it keeps the plainer outline treatment.
 */
@Composable
private fun SlideFillButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val fill by animateFloatAsState(if (pressed) 1f else 0f, tween(280), label = "slide-fill")
    val arrowRotation by animateFloatAsState(if (pressed) 0f else -45f, tween(280), label = "slide-arrow")

    Box(
        modifier
            .height(56.dp)
            .drawBehind {
                val d = 4.dp.toPx()
                drawRoundRect(
                    color = Ink,
                    topLeft = Offset(d, d),
                    size = size,
                    cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx()),
                )
            }
            .clip(RoundedCornerShape(16.dp))
            .background(Ink)
            .drawBehind {
                if (fill > 0f) {
                    drawRect(
                        color = Mint.fill,
                        topLeft = Offset(size.width * (1f - fill), 0f),
                        size = Size(size.width * fill, size.height),
                    )
                }
            }
            .border(3.dp, Ink, RoundedCornerShape(16.dp))
            .clickableNoRipple(interaction, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                label,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (pressed) Mint.on else Mint.fill,
            )
            Spacer(Modifier.width(8.dp))
            Canvas(
                Modifier
                    .size(16.dp)
                    .graphicsLayer { rotationZ = arrowRotation },
            ) {
                val w = size.width
                val col = if (pressed) Mint.on else Mint.fill
                drawLine(col, Offset(w * 0.1f, w * 0.5f), Offset(w * 0.9f, w * 0.5f), strokeWidth = w * 0.12f, cap = StrokeCap.Round)
                drawLine(col, Offset(w * 0.55f, w * 0.15f), Offset(w * 0.9f, w * 0.5f), strokeWidth = w * 0.12f, cap = StrokeCap.Round)
                drawLine(col, Offset(w * 0.55f, w * 0.85f), Offset(w * 0.9f, w * 0.5f), strokeWidth = w * 0.12f, cap = StrokeCap.Round)
            }
        }
    }
}
