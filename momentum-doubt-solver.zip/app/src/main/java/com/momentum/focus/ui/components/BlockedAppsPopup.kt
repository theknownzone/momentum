package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkLow
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * What tapping Shield on Home used to skip straight past: the actual
 * answer to "which apps did I turn on", shown here rather than only inside
 * the full edit screen. [onManage] is the one door out of this popup that
 * still leads to BlockHub, for when the answer to looking is "change one".
 *
 * [dailyCapMinutes] is the same map BlockListScreen reads to show its own
 * per-app cap, passed through here so this popup can say what happens when
 * you tap the app, not just that it's on the list — a blocked app with no
 * cap entry is a hard lock; one with an entry still opens for that many
 * minutes first.
 */
@Composable
fun BlockedAppsPopup(
    blockedPackages: Set<String>,
    dailyCapMinutes: Map<String, Int> = emptyMap(),
    onManage: () -> Unit,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    val labels = remember(blockedPackages) { mutableStateMapOf<String, String>() }
    LaunchedEffect(blockedPackages) {
        withContext(Dispatchers.IO) {
            blockedPackages.forEach { pkg ->
                val label = runCatching {
                    context.packageManager.getApplicationLabel(
                        context.packageManager.getApplicationInfo(pkg, 0),
                    ).toString()
                }.getOrDefault(pkg)
                labels[pkg] = label
            }
        }
    }

    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius)),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Mint.fill)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("SHIELD", style = MaterialTheme.typography.labelSmall, color = Mint.on)
                Text(
                    "${blockedPackages.size} blocked",
                    style = MaterialTheme.typography.labelSmall,
                    color = Mint.on,
                )
            }
            Box(Modifier.fillMaxWidth().height(Paper.Outline).background(Ink))

            if (blockedPackages.isEmpty()) {
                Column(
                    Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Lock3D(color = Mint.fill, size = 44.dp)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Nothing blocked yet",
                        style = MaterialTheme.typography.titleMedium,
                        color = Ink,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Pick a few apps and Shield actually has something to hold the line on.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                        textAlign = TextAlign.Center,
                    )
                }
            } else {
                LazyColumn(
                    Modifier
                        .padding(horizontal = 14.dp, vertical = 14.dp)
                        .heightIn(max = 340.dp),
                ) {
                    items(blockedPackages.toList(), key = { it }) { pkg ->
                        val cap = dailyCapMinutes[pkg]
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AppIcon(pkg, size = 32.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    labels[pkg] ?: pkg,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = Ink,
                                )
                                Text(
                                    if (cap == null) "Locked outright" else "Opens for $cap min, then locks",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = InkLow,
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            Lock3D(color = if (cap == null) Ink else Mint.fill, size = 26.dp)
                        }
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .border(2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClose)
                        .padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("Close", style = MaterialTheme.typography.titleMedium, color = Ink)
                }
                SquishButton(
                    label = "Manage",
                    sticker = Mint,
                    modifier = Modifier.weight(1f),
                    onClick = { onClose(); onManage() },
                )
            }
        }
    }
}
