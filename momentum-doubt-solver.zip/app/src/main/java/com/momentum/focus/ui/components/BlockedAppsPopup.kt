package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * What tapping Shield on Home used to skip straight past: the actual
 * answer to "which apps did I turn on", shown here rather than only inside
 * the full edit screen. [onManage] is the one door out of this popup that
 * still leads to BlockHub, for when the answer to looking is "change one".
 *
 * Resolves each package's label directly rather than through
 * AppCatalog.scan — that walks every launchable app on the phone to build
 * the pick-list BlockHub needs, real work worth doing once, not paying
 * again just to print a handful of names this dialog already has the
 * packages for.
 */
@Composable
fun BlockedAppsPopup(
    blockedPackages: Set<String>,
    onManage: () -> Unit,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    val labels = remember(blockedPackages) { mutableStateMapOf<String, String>() }
    LaunchedEffect(blockedPackages) {
        withContext(Dispatchers.IO) {
            blockedPackages.forEach { pkg ->
                val label = runCatching {
                    context.packageManager.getApplicationLabel(
                        context.packageManager.getApplicationInfo(pkg, 0),
                    ).toString()
                }.getOrDefault(pkg)
                labels[pkg] = label
            }
        }
    }

    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius)),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Mint.fill)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("SHIELD", style = MaterialTheme.typography.labelSmall, color = Mint.on)
                Text(
                    "${blockedPackages.size} blocked",
                    style = MaterialTheme.typography.labelSmall,
                    color = Mint.on,
                )
            }
            Box(Modifier.fillMaxWidth().height(Paper.Outline).background(Ink))

            if (blockedPackages.isEmpty()) {
                Column(Modifier.padding(20.dp)) {
                    Text(
                        "Nothing blocked yet",
                        style = MaterialTheme.typography.titleMedium,
                        color = Ink,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Pick a few apps and Shield actually has something to hold the line on.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                    )
                }
            } else {
                LazyColumn(
                    Modifier
                        .padding(horizontal = 14.dp, vertical = 14.dp)
                        .heightIn(max = 320.dp),
                ) {
                    items(blockedPackages.toList(), key = { it }) { pkg ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AppIcon(pkg, size = 32.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(
                                labels[pkg] ?: pkg,
                                style = MaterialTheme.typography.bodyLarge,
                                color = Ink,
                            )
                        }
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .border(2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, onClick = onClose)
                        .padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("Close", style = MaterialTheme.typography.titleMedium, color = Ink)
                }
                SquishButton(
                    label = "Manage",
                    sticker = Mint,
                    modifier = Modifier.weight(1f),
                    onClick = { onClose(); onManage() },
                )
            }
        }
    }
}
