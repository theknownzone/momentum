package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkLow
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * What tapping Shield on Home used to skip straight past: the actual
 * answer to "which apps did I turn on", shown here rather than only inside
 * the full edit screen. [onManage] is the one door out of this popup that
 * still leads to BlockHub, for when the answer to looking is "change one".
 *
 * [dailyCapMinutes] is the same map BlockListScreen reads to show its own
 * per-app cap, passed through here so this popup can say what happens when
 * you tap the app, not just that it's on the list — a blocked app with no
 * cap entry is a hard lock; one with an entry still opens for that many
 * minutes first.
 */
@Composable
fun BlockedAppsPopup(
    blockedPackages: Set<String>,
    dailyCapMinutes: Map<String, Int> = emptyMap(),
    onManage: () -> Unit,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    val labels = remember(blockedPackages) { mutableStateMapOf<String, String>() }
    LaunchedEffect(blockedPackages) {
        withContext(Dispatchers.IO) {
            blockedPackages.forEach { pkg ->
                val label = runCatching {
                    context.packageManager.getApplicationLabel(
                        context.packageManager.getApplicationInfo(pkg, 0),
                    ).toString()
                }.getOrDefault(pkg)
                labels[pkg] = label
            }
        }
    }

    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius)),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Mint.fill)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("SHIELD", style = MaterialTheme.typography.labelSmall, color = Mint.on)
                Text(
                    "${blockedPackages.size} blocked",
                    style = MaterialTheme.typography.labelSmall,
                    color = Mint.on,
                )
            }
            Box(Modifier.fillMaxWidth().height(Paper.Outline).background(Ink))

            if (blockedPackages.isEmpty()) {
                Column(
                    Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Lock3D(color = Mint.fill, size = 44.dp)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Nothing blocked yet",
                        style = MaterialTheme.typography.titleMedium,
                        color = Ink,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Pick a few apps and Shield actually has something to hold the line on.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                        textAlign = TextAlign.Center,
                    )
                }
            } else {
                LazyColumn(
                    Modifier
                        .padding(horizontal = 14.dp, vertical = 14.dp)
                        .heightIn(max = 340.dp),
                ) {
                    items(blockedPackages.toList(), key = { it }) { pkg ->
                        val cap = dailyCapMinutes[pkg]
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AppIcon(pkg, size = 32.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    labels[pkg] ?: pkg,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = Ink,
                                )
                                Text(
                                    if (cap == null) "Locked outright" else "Opens for $cap min, then locks",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = InkLow,
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            Lock3D(color = if (cap == null) Ink else Mint.fill, size = 26.dp)
                        }
                    }
                }

                // The streak tie-in strip is new as of this pass, and the
                // hand-written "new!" callout above it is only worth
                // showing while it's actually new — a prefs-backed counter
                // caps it at 3 views total, then it never draws again.
                val prefs = remember { context.getSharedPreferences("momentum_hints", 0) }
                var streakHintShown by remember {
                    mutableStateOf(prefs.getInt("shield_streak_hint_shown", 0))
                }
                LaunchedEffect(Unit) {
                    if (streakHintShown < 3) {
                        prefs.edit().putInt("shield_streak_hint_shown", streakHintShown + 1).apply()
                    }
                }
                val glow by rememberInfiniteTransition(label = "hint-glow").animateFloat(
                    initialValue = 0.35f,
                    targetValue = 0.8f,
                    animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
                    label = "glow",
                )

                Column(Modifier.padding(horizontal = 14.dp)) {
                    if (streakHintShown < 3) {
                        Row(
                            Modifier.align(Alignment.End).padding(end = 20.dp, bottom = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                "new!",
                                fontFamily = FontFamily.Cursive,
                                fontWeight = FontWeight.Bold,
                                fontSize = 30.sp,
                                color = Color(0xFF2255CC).copy(alpha = glow),
                                modifier = Modifier.graphicsLayer { rotationZ = -8f },
                            )
                            Spacer(Modifier.width(4.dp))
                            Canvas(Modifier.size(30.dp, 22.dp)) {
                                val col = Color(0xFF2255CC).copy(alpha = glow)
                                val path = Path().apply {
                                    moveTo(size.width * 0.1f, size.height * 0.1f)
                                    cubicTo(
                                        size.width * 0.3f, size.height * 0.3f,
                                        size.width * 0.25f, size.height * 0.65f,
                                        size.width * 0.5f, size.height * 0.55f,
                                    )
                                    cubicTo(
                                        size.width * 0.7f, size.height * 0.45f,
                                        size.width * 0.6f, size.height * 0.85f,
                                        size.width * 0.85f, size.height,
                                    )
                                }
                                drawPath(path, col, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
                                drawLine(col, Offset(size.width * 0.65f, size.height * 0.9f), Offset(size.width * 0.85f, size.height), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                                drawLine(col, Offset(size.width * 0.78f, size.height * 0.65f), Offset(size.width * 0.85f, size.height), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                            }
                        }
                    }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFFFFE9A8))
                            .border(2.dp, Ink, RoundedCornerShape(14.dp))
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("\uD83D\uDD25", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Every locked app adds to today's focus streak",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = Ink,
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .border(2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClose)
                        .padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("Close", style = MaterialTheme.typography.titleMedium, color = Ink)
                }
                SlideFillButton(label = "Manage", modifier = Modifier.weight(1f), onClick = { onClose(); onManage() })
            }
        }
    }
}

/**
 * The dark-button-with-sliding-fill from the reference ("LET'S TALK") —
 * a black pill that fills with colour on press, its arrow rotating from
 * a diagonal to straight-ahead as it does, rather than a flat coloured
 * button with no motion of its own. Used for "Manage" specifically since
 * it's the button that actually goes somewhere else (BlockHub); "Close"
 * next to it goes nowhere, so it keeps the plainer outline treatment.
 */
@Composable
private fun SlideFillButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val fill by animateFloatAsState(if (pressed) 1f else 0f, tween(280), label = "slide-fill")
    val arrowRotation by animateFloatAsState(if (pressed) 0f else -45f, tween(280), label = "slide-arrow")

    Box(
        modifier
            .height(48.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Ink)
            .drawBehind {
                if (fill > 0f) {
                    drawRect(
                        color = Mint.fill,
                        topLeft = Offset(size.width * (1f - fill), 0f),
                        size = Size(size.width * fill, size.height),
                    )
                }
            }
            .clickableNoRipple(interaction, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                label,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (pressed) Mint.on else Color.White,
            )
            Spacer(Modifier.width(8.dp))
            Canvas(
                Modifier
                    .size(16.dp)
                    .graphicsLayer { rotationZ = arrowRotation },
            ) {
                val w = size.width
                val col = if (pressed) Mint.on else Color.White
                drawLine(col, Offset(w * 0.1f, w * 0.5f), Offset(w * 0.9f, w * 0.5f), strokeWidth = w * 0.12f, cap = StrokeCap.Round)
                drawLine(col, Offset(w * 0.55f, w * 0.15f), Offset(w * 0.9f, w * 0.5f), strokeWidth = w * 0.12f, cap = StrokeCap.Round)
                drawLine(col, Offset(w * 0.55f, w * 0.85f), Offset(w * 0.9f, w * 0.5f), strokeWidth = w * 0.12f, cap = StrokeCap.Round)
            }
        }
    }
}
