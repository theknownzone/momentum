package com.momentum.focus.ui.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import com.momentum.focus.R

/** A real recorded clip, same reasoning [PrintSound] already gives for the
 * printer texture: some cues are recordings rather than tones. Five clips
 * from a licensed professional pack, each picked for a spot that already
 * fires but had nothing but a synthesised tone under it — an unlock, a
 * reply landing, a screen change, a coin spent, a streak celebration —
 * kept to exactly these five so the shipped-clip footprint stays
 * deliberate rather than becoming a second sound system running next to
 * [Sfx]. */
enum class PremiumClip { UNLOCK, REPLY, WHOOSH, SPEND, CELEBRATE }

/**
 * Shipped professional SFX, played over [Sfx]'s own tone for the same
 * event where one is called for the moment specifically wants a recorded
 * clip's texture rather than a synthesised tone — same relationship
 * [PrintSound] already has with the receipt screen's printer sound.
 *
 * Follows [PrintSound] exactly: MediaPlayer per clip, prepared once at
 * init rather than on every play so decoding never lands the sound late,
 * gated on the physical silent switch and on [Sfx.enabled] both, since
 * these are UI sounds in the same sense every [Sfx] tone is.
 */
object PremiumSfx {

    private val players = mutableMapOf<PremiumClip, MediaPlayer>()
    private var audioManager: AudioManager? = null

    fun init(context: Context) {
        if (players.isNotEmpty()) return
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        runCatching {
            players[PremiumClip.UNLOCK] = MediaPlayer.create(context.applicationContext, R.raw.sfx_unlock, attrs, 0)
            players[PremiumClip.REPLY] = MediaPlayer.create(context.applicationContext, R.raw.sfx_reply, attrs, 0)
            players[PremiumClip.WHOOSH] = MediaPlayer.create(context.applicationContext, R.raw.sfx_whoosh, attrs, 0)
            players[PremiumClip.SPEND] = MediaPlayer.create(context.applicationContext, R.raw.sfx_spend, attrs, 0)
            players[PremiumClip.CELEBRATE] = MediaPlayer.create(context.applicationContext, R.raw.sfx_celebrate, attrs, 0)
        }
    }

    fun play(clip: PremiumClip) {
        if (!Sfx.enabled) return
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val p = players[clip] ?: return
        runCatching {
            if (p.isPlaying) {
                p.pause()
                p.seekTo(0)
            }
            p.start()
        }
    }

    fun release() {
        players.values.forEach { runCatching { it.release() } }
        players.clear()
        audioManager = null
    }
}
