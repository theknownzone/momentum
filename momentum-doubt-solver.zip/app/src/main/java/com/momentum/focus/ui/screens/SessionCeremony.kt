package com.momentum.focus.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.Currency
import com.momentum.focus.data.tr
import com.momentum.focus.ui.components.GlowProgressBar
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.util.LockInReel
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.progressColor
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/*
 * Session complete — "Ring → Coins → Wallet → Receipt" (2026-10-03).
 *
 * Picks up exactly where the Focus screen left off: the same timer ring
 * closes its last sliver and reads DONE. Then the ring pays out — coins arc
 * on real parabolas into the wallet, whose balance rolls from what it was to
 * what it is now. The wallet prints a receipt line by line (subject, minutes,
 * your rate, earned) and the daily goal bar fills. One clock, every beat with
 * its sound; tap anywhere to skip.
 *
 * All numbers are real: minutes and rate come from the session just banked,
 * the balance from the wallet. The coins are a picture of the payout (capped
 * at 18 so a 4-hour session doesn't spray 80 sprites) — the counter is the
 * actual amount.
 */

private const val END = 4500f
private val GoldHi = Color(0xFFFFE89E)
private val Gold = Color(0xFFF2C34D)
private val GoldLo = Color(0xFFC68B1E)

private fun c01(x: Float) = x.coerceIn(0f, 1f)
private fun seg(t: Float, a: Float, d: Float) = c01((t - a) / d)
private fun ease(x: Float) = FastOutSlowInEasing.transform(c01(x))

@Composable
internal fun SessionCeremony(
    data: AppData,
    fallbackMinutes: Int,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()
    val last = remember(data.sessions.size) { data.sessions.lastOrNull { it.completed } }
    val minutes = last?.minutes ?: fallbackMinutes
    val ratio = (last?.ratio ?: data.effectiveRatio).coerceAtLeast(1)
    val earned = minutes / ratio
    val subject = last?.subject?.ifBlank { null }
    val after = data.balanceMinutes
    val before = (after - earned).coerceAtLeast(0)
    val goal = c01(data.minutesToday / 180f)
    val coins = earned.coerceIn(3, 18)

    var t by remember { mutableFloatStateOf(0f) }
    var skipped by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }
    fun finish() { if (!done) { done = true; onDone() } }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (t < END && !skipped) withFrameNanos { now -> if (!skipped) t = (now - start) / 1_000_000f }
    }
    BackHandler { finish() }

    val coinStart = 1000f
    val coinGap = 55f
    val coinFly = 520f
    val coinsEnd = coinStart + (coins - 1) * coinGap + coinFly

    val fired = remember { mutableSetOf<Int>() }
    SideEffect {
        fun beat(id: Int, at: Float, fn: () -> Unit) { if (t >= at && fired.add(id) && !skipped) fn() }
        beat(1, 120f) { Sfx.play(Sound.SESSION) }
        beat(2, coinStart) { Sfx.play(Sound.SPEND); haptics.unlock() }
        for (i in 0 until coins) beat(100 + i, coinStart + i * coinGap + coinFly) {
            Sfx.play(Sound.TICK); if (i % 3 == 0) haptics.tick()
        }
        beat(3, coinsEnd + 60f) { Sfx.play(Sound.SUCCESS); haptics.confirm() }
        beat(4, 2750f) { Sfx.play(Sound.SEND) }
        for (r in 0 until 4) beat(200 + r, 2950f + r * 160f) { Sfx.play(Sound.TICK) }
        beat(5, 3650f) { Sfx.play(Sound.LEVEL) }
    }

    // timeline
    val close = ease(seg(t, 0f, 700f))           // ring closes its last sliver
    val doneIn = ease(seg(t, 650f, 250f))
    val roll = ease(seg(t, coinStart + coinFly, coinsEnd - coinStart - coinFly + 1f))
    val gainPop = seg(t, coinsEnd, 300f)
    val paper = ease(seg(t, 2750f, 600f))
    val goalIn = seg(t, 3600f, 300f)
    val cta = ease(seg(t, 4050f, 320f))

    var ringC by remember { mutableStateOf(Offset.Zero) }
    var slot by remember { mutableStateOf(Offset.Zero) }
    // wallet bumps a little with each landing
    val sinceLanding = (0 until coins).map { t - (coinStart + it * coinGap + coinFly) }.filter { it >= 0f }.minOrNull()
    val walletBump = if (sinceLanding != null && sinceLanding < 120f) 1f - sinceLanding / 120f else 0f

    Box(
        Modifier
            .fillMaxSize()
            .background(Cream)
            .paperGrain()
            .pointerInput(Unit) { detectTapGestures { if (t < END) { skipped = true; t = END } } },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 22.dp)
                .padding(top = 20.dp, bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                (tr("SESSION CLOSED", "सेशन पूरा") + (subject?.let { " · ${it.uppercase()}" } ?: "")),
                fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp,
                letterSpacing = 2.4.sp, color = InkMid, maxLines = 1,
            )
            Spacer(Modifier.height(14.dp))

            // ---- the ring, continuing from the Focus screen
            Box(
                Modifier.size(170.dp).onGloballyPositioned {
                    val p = it.positionInRoot(); ringC = Offset(p.x + it.size.width / 2f, p.y + it.size.height / 2f)
                },
                contentAlignment = Alignment.Center,
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val st = 18.dp.toPx()
                    val tl = Offset(st / 2, st / 2)
                    val sz = Size(size.width - st, size.height - st)
                    val sweep = 360f * (0.93f + 0.07f * close)
                    val pc = progressColor(0.93f + 0.07f * close)
                    drawArc(Ink, -90f, 360f, false, tl, sz, style = Stroke(st + 6f))
                    drawArc(Sunk, -90f, 360f, false, tl, sz, style = Stroke(st))
                    for (k in 1..5) drawArc(pc.copy(alpha = 0.10f * (1f - k / 6f)), -90f, sweep, false, tl, sz, style = Stroke(st + k * 6.dp.toPx(), cap = StrokeCap.Round))
                    drawArc(pc, -90f, sweep, false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
                    // payout burst ring when the coins leave
                    val burst = seg(t, coinStart, 450f)
                    if (burst in 0.001f..0.999f) drawCircle(Gold.copy(alpha = 1f - burst), size.minDimension / 2 + 40.dp.toPx() * burst, style = Stroke(4.dp.toPx() * (1f - burst)))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "%d:%02d".format(minutes, 0),
                        fontSize = 34.sp, fontWeight = FontWeight.Black, color = Ink,
                    )
                    Text(
                        tr("DONE", "पूरा"),
                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 2.sp,
                        color = progressColor(1f).copy(alpha = doneIn),
                        modifier = Modifier.graphicsLayer { scaleX = 0.6f + 0.4f * doneIn; scaleY = scaleX },
                    )
                }
            }

            Spacer(Modifier.height(26.dp))

            // ---- the wallet (dark, like the Home hero) with its coin slot
            Column(
                Modifier
                    .fillMaxWidth()
                    .graphicsLayer { val b = 1f + 0.025f * walletBump; scaleX = b; scaleY = b; translationY = walletBump * 2.dp.toPx() }
                    .drawBehind { drawRoundRect(Ink, Offset(6.dp.toPx(), 6.dp.toPx()), size, CornerRadius(18.dp.toPx())) }
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF2C2210), Color(0xFF15100A))))
                    .border(Paper.Outline, Ink, RoundedCornerShape(18.dp))
                    .padding(horizontal = 18.dp, vertical = 14.dp),
            ) {
                // the slot coins drop into
                Box(
                    Modifier.align(Alignment.CenterHorizontally).width(84.dp).height(7.dp)
                        .clip(RoundedCornerShape(4.dp)).background(Color.Black)
                        .onGloballyPositioned { val p = it.positionInRoot(); slot = Offset(p.x + it.size.width / 2f, p.y + it.size.height / 2f) },
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("WALLET", "वॉलेट"), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 2.sp, color = InkLow)
                        Text(
                            Currency.format((before + (after - before) * roll).roundToInt()),
                            style = androidx.compose.material3.MaterialTheme.typography.displaySmall.copy(
                                brush = Brush.linearGradient(listOf(GoldHi, GoldNeon, GoldLo)),
                            ),
                            fontWeight = FontWeight.Black,
                        )
                    }
                    if (gainPop > 0f) {
                        val s = if (gainPop < 0.6f) 1.6f - 0.7f * ease(gainPop / 0.6f) else 0.9f + 0.1f * ease((gainPop - 0.6f) / 0.4f)
                        Text(
                            "+" + Currency.format(earned),
                            fontSize = 16.sp, fontWeight = FontWeight.Black, color = Ink,
                            modifier = Modifier
                                .padding(bottom = 8.dp)
                                .graphicsLayer { scaleX = s; scaleY = s; rotationZ = -4f; alpha = c01(gainPop * 3f) }
                                .clip(RoundedCornerShape(8.dp)).background(Mint.fill)
                                .border(2.dp, Ink, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp),
                        )
                    }
                }
            }

            // ---- the receipt the wallet prints
            Column(
                Modifier
                    .padding(horizontal = 14.dp)
                    .fillMaxWidth()
                    .graphicsLayer { transformOrigin = TransformOrigin(0.5f, 0f); scaleY = paper; alpha = c01(paper * 4f) }
                    .drawBehind { drawRect(Ink.copy(alpha = 0.25f), Offset(4.dp.toPx(), 4.dp.toPx()), size) }
                    .background(CreamCard)
                    .drawBehind {
                        // torn zig-zag bottom edge
                        val z = 6.dp.toPx(); var x = 0f
                        while (x < size.width) {
                            drawLine(Ink.copy(alpha = 0.35f), Offset(x, size.height), Offset(x + z / 2, size.height - z / 2), 1.dp.toPx())
                            drawLine(Ink.copy(alpha = 0.35f), Offset(x + z / 2, size.height - z / 2), Offset(x + z, size.height), 1.dp.toPx())
                            x += z
                        }
                    }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
            ) {
                val rows = listOf(
                    tr("Subject", "विषय") to (subject ?: tr("Just focus", "सिर्फ़ फ़ोकस")),
                    tr("Studied", "पढ़ाई") to tr("$minutes min", "$minutes मिनट"),
                    tr("Rate", "दर") to tr("₹1 / $ratio min", "₹1 / $ratio मिनट"),
                    tr("Earned", "कमाई") to "+" + Currency.format(earned),
                )
                rows.forEachIndexed { i, (k, v) ->
                    val a = seg(t, 2950f + i * 160f, 160f)
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).graphicsLayer { alpha = a; translationX = (1f - a) * -8.dp.toPx() }) {
                        Text(k, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = InkMid, modifier = Modifier.weight(1f))
                        Text(
                            v, fontFamily = FontFamily.Monospace, fontSize = 12.sp, maxLines = 1,
                            fontWeight = if (i == 3) FontWeight.Black else FontWeight.Bold,
                            color = if (i == 3) Mint.accent else Ink,
                        )
                    }
                }
            }

            Spacer(Modifier.weight(1f))

            // ---- today's goal fills
            Column(Modifier.fillMaxWidth().graphicsLayer { alpha = goalIn }) {
                Row {
                    Text(tr("TODAY'S GOAL · 3H", "आज का लक्ष्य · 3 घंटे"), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.6.sp, color = InkMid, modifier = Modifier.weight(1f))
                    Text("${(goal * 100).roundToInt()}%", fontWeight = FontWeight.Black, fontSize = 12.sp, color = Ink)
                }
                Spacer(Modifier.height(6.dp))
                if (goalIn > 0f) GlowProgressBar(progress = goal, height = 12.dp)
            }
            Spacer(Modifier.height(16.dp))
            Column(Modifier.graphicsLayer { alpha = cta; translationY = (1f - cta) * 20.dp.toPx() }) {
                PrimaryButton(tr("Bank it →", "जमा करें →")) {
                    if (cta > 0.5f) { haptics.confirm(); Sfx.play(Sound.DONE); finish() }
                }
                // Lock-in Reel: only for a real sit-down (10m+), only on tap.
                // Renders on its own low-priority thread; leaving cancels it.
                if (minutes >= 10) {
                    Spacer(Modifier.height(10.dp))
                    ReelButton(
                        LockInReel.Info(minutes, subject, earned, data.streakDays),
                        enabled = cta > 0.5f,
                    )
                }
            }
        }

        // ---- coins in flight (root coordinates, drawn over everything)
        if (t in coinStart..(coinsEnd + 1f) && ringC != Offset.Zero && slot != Offset.Zero) {
            Canvas(Modifier.fillMaxSize()) {
                for (i in 0 until coins) {
                    val p = seg(t, coinStart + i * coinGap, coinFly)
                    if (p <= 0f || p >= 1f) continue
                    val a = (i * 137.5f) * PI.toFloat() / 180f
                    val start = ringC + Offset(cos(a) * 60.dp.toPx(), sin(a) * 60.dp.toPx())
                    val lift = 120.dp.toPx() + (i % 4) * 18.dp.toPx()
                    val x = start.x + (slot.x - start.x) * p
                    val y = start.y + (slot.y - start.y) * p - lift * 4f * p * (1f - p)
                    val r = 11.dp.toPx() * (1f - 0.35f * p)
                    val flip = kotlin.math.abs(cos((p * 3f + i * 0.3f) * PI.toFloat()))
                    val w = r * (0.25f + 0.75f * flip)
                    drawOval(Ink, Offset(x - w - 1.5f, y - r - 1.5f), Size((w + 1.5f) * 2, (r + 1.5f) * 2))
                    drawOval(Brush.linearGradient(listOf(GoldHi, Gold, GoldLo), Offset(x - w, y - r), Offset(x + w, y + r)), Offset(x - w, y - r), Size(w * 2, r * 2))
                    drawOval(GoldLo, Offset(x - w * 0.55f, y - r * 0.55f), Size(w * 1.1f, r * 1.1f), style = Stroke(1.5.dp.toPx()))
                }
            }
        }

        if (t < END) {
            Text(
                tr("tap to skip", "छोड़ने के लिए टैप करें"),
                fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Ink.copy(alpha = 0.3f),
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 2.dp),
            )
        }
    }
}


/** "Make my Lock-in Reel" → "Cooking reel 42%" → share sheet. */
@Composable
private fun ReelButton(info: LockInReel.Info, enabled: Boolean) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptics = rememberHaptics()
    var progress by remember { mutableFloatStateOf(-1f) }   // -1 idle
    var failed by remember { mutableStateOf(false) }
    val busy = progress >= 0f
    SquishButton(
        label = when {
            busy -> tr("Cooking reel ${(progress * 100).roundToInt()}%", "रील बन रही ${(progress * 100).roundToInt()}%")
            failed -> tr("This phone said no — try again", "फ़ोन ने मना किया — फिर कोशिश करें")
            else -> tr("Make my Lock-in Reel", "मेरी लॉक-इन रील बनाओ")
        },
        sticker = Butter,
        enabled = enabled && !busy,
        modifier = Modifier.fillMaxWidth(),
    ) {
        if (busy) return@SquishButton
        haptics.confirm()
        failed = false
        progress = 0f
        scope.launch {
            val file = LockInReel.make(context, info) { p -> progress = p }
            progress = -1f
            if (file != null) { Sfx.play(Sound.SEND); LockInReel.share(context, file) }
            else { failed = true; haptics.reject() }
        }
    }
}
