package com.momentum.focus.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Skins are earned, never bought or given.
 *
 * A cosmetic that unlocks at a level is the cheapest honest reward there is:
 * it costs nothing to run, it is visible every single time the app opens, and
 * it cannot be faked. Handing them all out at install would remove the only
 * thing that makes them worth anything.
 */
enum class Skin(
    val label: String,
    val unlockLevel: Int,
    val petal: Color,
    val heroTop: Color,
    val heroBottom: Color,
    val accent: Color,
    val blurb: String,
) {
    SAKURA(
        label = "Sakura",
        unlockLevel = 1,
        petal = Color(0xFFFFB7C5),
        heroTop = Color(0xFF2B1A27),
        heroBottom = Color(0xFF120C12),
        accent = Color(0xFFFF4F8B),
        blurb = "Where everyone starts.",
    ),
    MONSOON(
        label = "Monsoon",
        unlockLevel = 3,
        petal = Color(0xFF9FD8FF),
        heroTop = Color(0xFF16283A),
        heroBottom = Color(0xFF090F16),
        accent = Color(0xFF22C7FF),
        blurb = "Rain on the window, nothing else to do.",
    ),
    EMBER(
        label = "Ember",
        unlockLevel = 6,
        petal = Color(0xFFFFA24B),
        heroTop = Color(0xFF2E1610),
        heroBottom = Color(0xFF110706),
        accent = Color(0xFFFF6A2E),
        blurb = "For the last hour before an exam.",
    ),
    MIDNIGHT(
        label = "Midnight",
        unlockLevel = 10,
        petal = Color(0xFFB9A7FF),
        heroTop = Color(0xFF1C1A3D),
        heroBottom = Color(0xFF09081A),
        accent = Color(0xFF9D7BFF),
        blurb = "Earned by people who study after everyone sleeps.",
    ),
    GOLD(
        label = "Gold",
        unlockLevel = 15,
        petal = Color(0xFFFFD84D),
        heroTop = Color(0xFF2C2210),
        heroBottom = Color(0xFF110D05),
        accent = Color(0xFFFFC531),
        blurb = "Rare on purpose.",
    ),
    RAKHI(
        label = "Rakhi",
        unlockLevel = 1,
        petal = Color(0xFFFF8FB1),
        heroTop = Color(0xFF2A1218),
        heroBottom = Color(0xFF1A0B10),
        accent = Color(0xFFFF5D8F),
        blurb = "Seasonal. Thread and promise.",
    ),
    DIWALI(
        label = "Diwali",
        unlockLevel = 1,
        petal = Color(0xFFFFD84D),
        heroTop = Color(0xFF2A1A08),
        heroBottom = Color(0xFF140C04),
        accent = Color(0xFFFFB703),
        blurb = "Seasonal. Light the house, then sit down.",
    ),
    HOLI(
        label = "Holi",
        unlockLevel = 1,
        petal = Color(0xFFFF9EC4),
        heroTop = Color(0xFF1A1020),
        heroBottom = Color(0xFF0E0814),
        accent = Color(0xFFFF6B9D),
        blurb = "Seasonal. Colour first, phone later.",
    ),
    TIRANGA(
        label = "Tiranga",
        unlockLevel = 1,
        petal = Color(0xFFFF9933),
        heroTop = Color(0xFF0B1F14),
        heroBottom = Color(0xFF07140D),
        accent = Color(0xFF2FD15A),
        blurb = "Seasonal. 15 Aug and 26 Jan.",
    ),

    /**
     * Appended rather than inserted. skinFor() indexes Skin.entries by
     * position, so slotting a new skin in above this one would silently
     * repaint everybody who had picked a theme that sits after it.
     *
     * Krishna is born at midnight, so the hero goes darker than any other
     * skin here, with peacock for the feather and a lamp-gold accent.
     */
    JANMASHTAMI(
        label = "Janmashtami",
        unlockLevel = 1,
        petal = Color(0xFF6FD3E0),
        heroTop = Color(0xFF0B1230),
        heroBottom = Color(0xFF060A1C),
        accent = Color(0xFFFFC94D),
        blurb = "Seasonal. Midnight for the aarti, morning for the books.",
    );

    fun unlockedAt(level: Int): Boolean = level >= unlockLevel
}

fun skinFor(index: Int): Skin = Skin.entries[Math.floorMod(index, Skin.entries.size)]

// ---- v4 theme tokens (2026-10-03) -----------------------------------------
// One strong accent per theme (above), plus three derived tokens so every
// surface on a hero reads the same way on every theme:
/** Text on the dark hero: warm white, never pure. */
val Skin.onHero: Color get() = Color(0xFFF7F2E8)
/** Secondary text on the hero — still AA-readable on every hero colour. */
val Skin.onHeroMuted: Color get() = Color(0xFFF7F2E8).copy(alpha = 0.66f)
/** Glass surface on the hero, tinted by the theme's accent. */
val Skin.glass: Color get() = Color.White.copy(alpha = 0.07f)
/** Text/ink to put ON the accent colour. */
val Skin.onAccent: Color get() = if (this == Skin.MIDNIGHT || this == Skin.TIRANGA) Color(0xFF0B0B10) else Color(0xFF1A1A1A)
