package com.momentum.focus.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Skins are earned, never bought or given.
 *
 * A cosmetic that unlocks at a level is the cheapest honest reward there is:
 * it costs nothing to run, it is visible every single time the app opens, and
 * it cannot be faked. Handing them all out at install would remove the only
 * thing that makes them worth anything.
 */
enum class Skin(
    val label: String,
    val unlockLevel: Int,
    val petal: Color,
    val heroTop: Color,
    val heroBottom: Color,
    val accent: Color,
    val blurb: String,
) {
    SAKURA(
        label = "Sakura",
        unlockLevel = 1,
        petal = Color(0xFFFFB7C5),
        heroTop = Color(0xFF2B1A27),
        heroBottom = Color(0xFF120C12),
        accent = Color(0xFF3FE28F),
        blurb = "Where everyone starts.",
    ),
    MONSOON(
        label = "Monsoon",
        unlockLevel = 3,
        petal = Color(0xFF9FD8FF),
        heroTop = Color(0xFF16283A),
        heroBottom = Color(0xFF090F16),
        accent = Color(0xFF7FD4FF),
        blurb = "Rain on the window, nothing else to do.",
    ),
    EMBER(
        label = "Ember",
        unlockLevel = 6,
        petal = Color(0xFFFFA24B),
        heroTop = Color(0xFF2E1610),
        heroBottom = Color(0xFF110706),
        accent = Color(0xFFFF8A5C),
        blurb = "For the last hour before an exam.",
    ),
    MIDNIGHT(
        label = "Midnight",
        unlockLevel = 10,
        petal = Color(0xFFB9A7FF),
        heroTop = Color(0xFF1C1A3D),
        heroBottom = Color(0xFF09081A),
        accent = Color(0xFFB9A7FF),
        blurb = "Earned by people who study after everyone sleeps.",
    ),
    GOLD(
        label = "Gold",
        unlockLevel = 15,
        petal = Color(0xFFFFD84D),
        heroTop = Color(0xFF2C2210),
        heroBottom = Color(0xFF110D05),
        accent = Color(0xFFFFD84D),
        blurb = "Rare on purpose.",
    ),
    RAKHI(
        label = "Rakhi",
        unlockLevel = 1,
        petal = Color(0xFFFF8FB1),
        heroTop = Color(0xFF2A1218),
        heroBottom = Color(0xFF1A0B10),
        accent = Color(0xFFFF5D8F),
        blurb = "Seasonal. Thread and promise.",
    ),
    DIWALI(
        label = "Diwali",
        unlockLevel = 1,
        petal = Color(0xFFFFD84D),
        heroTop = Color(0xFF2A1A08),
        heroBottom = Color(0xFF140C04),
        accent = Color(0xFFFFB703),
        blurb = "Seasonal. Light the house, then sit down.",
    ),
    HOLI(
        label = "Holi",
        unlockLevel = 1,
        petal = Color(0xFFFF9EC4),
        heroTop = Color(0xFF1A1020),
        heroBottom = Color(0xFF0E0814),
        accent = Color(0xFFFF6B9D),
        blurb = "Seasonal. Colour first, phone later.",
    ),
    TIRANGA(
        label = "Tiranga",
        unlockLevel = 1,
        petal = Color(0xFFFF9933),
        heroTop = Color(0xFF0B1F14),
        heroBottom = Color(0xFF07140D),
        accent = Color(0xFF138808),
        blurb = "Seasonal. 15 Aug and 26 Jan.",
    ),

    /**
     * Appended rather than inserted. skinFor() indexes Skin.entries by
     * position, so slotting a new skin in above this one would silently
     * repaint everybody who had picked a theme that sits after it.
     *
     * Krishna is born at midnight, so the hero goes darker than any other
     * skin here, with peacock for the feather and a lamp-gold accent.
     */
    JANMASHTAMI(
        label = "Janmashtami",
        unlockLevel = 1,
        petal = Color(0xFF6FD3E0),
        heroTop = Color(0xFF0B1230),
        heroBottom = Color(0xFF060A1C),
        accent = Color(0xFFFFC94D),
        blurb = "Seasonal. Midnight for the aarti, morning for the books.",
    );

    fun unlockedAt(level: Int): Boolean = level >= unlockLevel
}

fun skinFor(index: Int): Skin = Skin.entries[Math.floorMod(index, Skin.entries.size)]
