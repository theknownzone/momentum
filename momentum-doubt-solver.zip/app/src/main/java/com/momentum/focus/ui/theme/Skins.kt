package com.momentum.focus.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Skins are earned, never bought or given.
 *
 * A cosmetic that unlocks at a level is the cheapest honest reward there is:
 * it costs nothing to run, it is visible every single time the app opens, and
 * it cannot be faked. Handing them all out at install would remove the only
 * thing that makes them worth anything.
 */
enum class Skin(
    val label: String,
    val unlockLevel: Int,
    val petal: Color,
    val heroTop: Color,
    val heroBottom: Color,
    val accent: Color,
    val page: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val onSurface: Color,
    val onSurfaceVariant: Color,
    val outline: Color,
    val blurb: String,
) {
    SAKURA(
        label = "Sakura",
        unlockLevel = 1,
        petal = Color(0xFFFFB7C5),
        heroTop = Color(0xFF1A1A1A),
        heroBottom = Color(0xFF241A1E),
        accent = Color(0xFF3FE28F),
        page = Color(0xFFFBF3D5),
        surface = Color(0xFFFFFDF2),
        surfaceVariant = Color(0xFFF2E7BE),
        onSurface = Color(0xFF1A1A1A),
        onSurfaceVariant = Color(0xFF8A7A3E),
        outline = Color(0xFF1A1A1A),
        blurb = "Where everyone starts.",
    ),
    MONSOON(
        label = "Monsoon",
        unlockLevel = 3,
        petal = Color(0xFF9FD8FF),
        heroTop = Color(0xFF10171F),
        heroBottom = Color(0xFF0B1119),
        accent = Color(0xFF4BBFEF),
        page = Color(0xFFEAF7FF),
        surface = Color(0xFFF8FDFF),
        surfaceVariant = Color(0xFFD9EEF8),
        onSurface = Color(0xFF10222C),
        onSurfaceVariant = Color(0xFF58707C),
        outline = Color(0xFF163541),
        blurb = "Rain on the window, nothing else to do.",
    ),
    EMBER(
        label = "Ember",
        unlockLevel = 6,
        petal = Color(0xFFFFA24B),
        heroTop = Color(0xFF1F1310),
        heroBottom = Color(0xFF140B09),
        accent = Color(0xFFFF7040),
        page = Color(0xFFFFEFE7),
        surface = Color(0xFFFFF8F4),
        surfaceVariant = Color(0xFFF4D9CD),
        onSurface = Color(0xFF2A120B),
        onSurfaceVariant = Color(0xFF795447),
        outline = Color(0xFF2A120B),
        blurb = "For the last hour before an exam.",
    ),
    MIDNIGHT(
        label = "Midnight",
        unlockLevel = 10,
        petal = Color(0xFFB9A7FF),
        heroTop = Color(0xFF14121F),
        heroBottom = Color(0xFF0A0912),
        accent = Color(0xFFB9A7FF),
        page = Color(0xFF10111A),
        surface = Color(0xFF1A1C27),
        surfaceVariant = Color(0xFF25283A),
        onSurface = Color(0xFFF5F1FF),
        onSurfaceVariant = Color(0xFFB9B3C8),
        outline = Color(0xFFE1DAF7),
        blurb = "Earned by people who study after everyone sleeps.",
    ),
    GOLD(
        label = "Gold",
        unlockLevel = 15,
        petal = Color(0xFFFFD84D),
        heroTop = Color(0xFF1E1808),
        heroBottom = Color(0xFF120E04),
        accent = Color(0xFFE5B900),
        page = Color(0xFFFFF7D9),
        surface = Color(0xFFFFFCF0),
        surfaceVariant = Color(0xFFF1E5B6),
        onSurface = Color(0xFF2B2208),
        onSurfaceVariant = Color(0xFF75642C),
        outline = Color(0xFF2B2208),
        blurb = "Rare on purpose.",
    ),
    RAKHI(
        label = "Rakhi",
        unlockLevel = 1,
        petal = Color(0xFFFF8FB1),
        heroTop = Color(0xFF2A1218),
        heroBottom = Color(0xFF1A0B10),
        accent = Color(0xFFFF4F83),
        page = Color(0xFFFFEAF1),
        surface = Color(0xFFFFF7FA),
        surfaceVariant = Color(0xFFF6D7E2),
        onSurface = Color(0xFF32121F),
        onSurfaceVariant = Color(0xFF805064),
        outline = Color(0xFF32121F),
        blurb = "Seasonal. Thread and promise.",
    ),
    DIWALI(
        label = "Diwali",
        unlockLevel = 1,
        petal = Color(0xFFFFD84D),
        heroTop = Color(0xFF2A1A08),
        heroBottom = Color(0xFF140C04),
        accent = Color(0xFFFFA800),
        page = Color(0xFFFFF0D4),
        surface = Color(0xFFFFFAEF),
        surfaceVariant = Color(0xFFF4DEB7),
        onSurface = Color(0xFF2E1B05),
        onSurfaceVariant = Color(0xFF765A2D),
        outline = Color(0xFF2E1B05),
        blurb = "Seasonal. Light the house, then sit down.",
    ),
    HOLI(
        label = "Holi",
        unlockLevel = 1,
        petal = Color(0xFFFF9EC4),
        heroTop = Color(0xFF1A1020),
        heroBottom = Color(0xFF0E0814),
        accent = Color(0xFFFF5C95),
        page = Color(0xFFFFECF5),
        surface = Color(0xFFFFF8FC),
        surfaceVariant = Color(0xFFF3D9E6),
        onSurface = Color(0xFF301522),
        onSurfaceVariant = Color(0xFF7B5264),
        outline = Color(0xFF301522),
        blurb = "Seasonal. Colour first, phone later.",
    ),
    TIRANGA(
        label = "Tiranga",
        unlockLevel = 1,
        petal = Color(0xFFFF9933),
        heroTop = Color(0xFF0B1F14),
        heroBottom = Color(0xFF07140D),
        accent = Color(0xFF138808),
        page = Color(0xFFEAF5EC),
        surface = Color(0xFFF7FCF8),
        surfaceVariant = Color(0xFFD9EBDD),
        onSurface = Color(0xFF102317),
        onSurfaceVariant = Color(0xFF55715D),
        outline = Color(0xFF102317),
        blurb = "Seasonal. 15 Aug and 26 Jan.",
    ),

    /**
     * Appended rather than inserted. skinFor() indexes Skin.entries by
     * position, so slotting a new skin in above this one would silently
     * repaint everybody who had picked a theme that sits after it.
     *
     * Krishna is born at midnight, so the hero goes darker than any other
     * skin here, with peacock for the feather and a lamp-gold accent.
     */
    JANMASHTAMI(
        label = "Janmashtami",
        unlockLevel = 1,
        petal = Color(0xFF6FD3E0),
        heroTop = Color(0xFF0B1230),
        heroBottom = Color(0xFF060A1C),
        accent = Color(0xFFFFC94D),
        page = Color(0xFFE9EDFF),
        surface = Color(0xFFF7F8FF),
        surfaceVariant = Color(0xFFDDE1F5),
        onSurface = Color(0xFF11152B),
        onSurfaceVariant = Color(0xFF5B6380),
        outline = Color(0xFF11152B),
        blurb = "Seasonal. Midnight for the aarti, morning for the books.",
    );

    fun unlockedAt(level: Int): Boolean = level >= unlockLevel
}

fun skinFor(index: Int): Skin = Skin.entries[Math.floorMod(index, Skin.entries.size)]
