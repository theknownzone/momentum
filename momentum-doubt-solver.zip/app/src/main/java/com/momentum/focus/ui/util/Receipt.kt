package com.momentum.focus.ui.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * The unlock receipt -- a thermal-printer slip, rendered and saved to the
 * device's Downloads folder.
 *
 * Drawn rather than composed because the output is a file, not a screen. A
 * Compose surface would have to be captured to a bitmap anyway, and capture
 * pulls in view-tree plumbing that only exists while something is on screen;
 * a plain Canvas has neither problem and produces the same pixels whether the
 * app is foregrounded or not.
 *
 * The look is deliberately a till receipt: monospace, centred header, dotted
 * rules, a torn zigzag bottom edge. A licence is a purchase, and a purchase
 * that hands back something shaped like a receipt reads as settled in a way
 * that a "Thank you!" card does not.
 */
object Receipt {

    private const val W = 720
    private const val PAD = 56f

    /** Depth of the zig-zag tear, shared by the drawing and the height maths. */
    private const val TEAR = 22f

    /**
     * Renders the slip and writes it to Downloads.
     *
     * Returns the display name on success, null on any failure. Null rather
     * than an exception because the caller is an animation: a receipt that
     * could not be saved should cost the user nothing more than a missing
     * file, never a crash on the screen that just took their money.
     */
    suspend fun saveToDownloads(context: Context, data: AppData): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = render(data)
                val name = "momentum-receipt-${System.currentTimeMillis()}.png"
                if (Build.VERSION.SDK_INT >= 29) {
                    // MediaStore on API 29+, because scoped storage means a
                    // direct write to the public Downloads path is denied.
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, "image/png")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val uri = resolver.insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, values,
                    ) ?: return@runCatching null
                    resolver.openOutputStream(uri)?.use {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                } else {
                    // Pre-29 the public directory is writable directly, and
                    // MediaStore.Downloads does not exist yet.
                    @Suppress("DEPRECATION")
                    val dir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS,
                    )
                    dir.mkdirs()
                    File(dir, name).outputStream().use {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                }
                name
            }.getOrNull()
        }

    /**
     * Two passes over one drawing routine: a dry run on a throwaway canvas to
     * learn where the last line ends, then the real draw on a bitmap cut to
     * exactly that height.
     *
     * The height used to be a hand-added constant (`PAD * 2 + 300 + rows * 46 +
     * ...`). It fell short of the real content by about a hundred pixels, so
     * the saved PNG lost both closing lines ("Blocking stays free. Always." and
     * "Keep this key. It moves phones.") off the bottom, and the licence caption
     * under the barcode sat inside the torn edge and was half erased by it.
     * Measuring cannot drift out of sync with the layout the way a constant can.
     */
    private fun render(data: AppData): Bitmap = renderNote(data)

    /** v4 print slip, kept for reference; [renderNote] is what gets saved now. */
    @Suppress("unused")
    private fun renderSlip(data: AppData): Bitmap {
        val probe = Bitmap.createBitmap(W, 8, Bitmap.Config.ARGB_8888)
        val endY = paint(Canvas(probe), data)
        probe.recycle()
        // Last baseline + descender + the depth of the tear + a breath of paper.
        val h = (endY + 22f + TEAR + 26f).toInt()
        val bitmap = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap)
        val last = paint(c, data)
        check(last <= h) { "receipt content overran its bitmap" }
        tornEdge(c, h.toFloat())
        return bitmap
    }

    /** Draws the whole slip and returns the baseline of its last line. */
    private fun paint(c: Canvas, data: AppData): Float {
        val mono = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        val monoBold = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

        // The app's own paper, not thermal-till white.
        //
        // Plain black-on-white was the honest thermal-printer reference, and
        // it was also the one file in the whole app that carried none of its
        // colour language — every card everywhere else is cream paper with a
        // hard Ink border and one accent colour doing the talking. A receipt
        // that looks like it printed from a different app is a strange thing
        // to hand someone as proof of what they bought here.
        val cream = Color.rgb(0xFF, 0xFD, 0xF2)
        val tang = Color.rgb(0xFF, 0x8A, 0x5C)
        val sky = Color.rgb(0x7F, 0xD4, 0xFF)
        val mint = Color.rgb(0x3F, 0xE2, 0x8F)

        val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            typeface = mono
            textSize = 26f
        }
        val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            typeface = monoBold
            textSize = 30f
        }
        val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            typeface = monoBold
            textSize = 54f
            textAlign = Paint.Align.CENTER
        }
        val centre = Paint(ink).apply { textAlign = Paint.Align.CENTER }
        val right = Paint(ink).apply { textAlign = Paint.Align.RIGHT }

        c.drawColor(cream)

        // A Tang band behind the header, the same move every screen in the
        // app makes to say "this is the part you look at first".
        val headerH = PAD + 100f
        c.drawRect(0f, 0f, W.toFloat(), headerH, Paint().apply { color = tang })

        var y = PAD + 40f
        c.drawText("MOMENTUM", W / 2f, y, Paint(big).apply { color = Color.BLACK })
        y += 40f
        c.drawText("focus, banked", W / 2f, y, Paint(centre).apply { color = Color.BLACK })
        y = headerH + 46f

        val stamp = LocalDateTime.now()
            .format(DateTimeFormatter.ofPattern("EEE, dd MMM yyyy  HH:mm:ss"))
        c.drawText(stamp, W / 2f, y, centre)
        y += 50f

        dotted(c, y); y += 46f

        // The key, boxed the way a token is boxed on a real slip.
        //
        // The box's top edge used to be computed as (y - 78f) after two
        // cumulative += steps past this label — which worked out to 4px
        // below the label's own baseline, not above its top. The dashed line
        // was drawn straight through "LICENCE KEY" rather than framing it,
        // which is exactly the strikethrough visible on the saved PNG. Named
        // the label's y position explicitly here so the box's edges are
        // computed from a fixed point instead of by re-deriving it through
        // two additions made for unrelated reasons.
        val labelY = y
        c.drawText("LICENCE KEY", W / 2f, labelY, centre)
        y += 44f
        val keyText = License.pretty(data.licenseKey)
        c.drawText(keyText, W / 2f, y, Paint(bold).apply { textAlign = Paint.Align.CENTER })
        // Sky fill inside the box, drawn before the dashed border so the
        // border still reads as a border rather than being buried under it.
        c.drawRoundRect(
            PAD - 8f, labelY - 34f, W - PAD + 8f, y + 22f, 10f, 10f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { color = sky; alpha = 70 },
        )
        dashedBox(c, labelY - 34f, y + 22f)
        y += 78f

        dotted(c, y); y += 46f

        fun row(label: String, value: String, valuePaint: Paint = right) {
            c.drawText(label, PAD, y, ink)
            c.drawText(value, W - PAD, y, valuePaint)
            y += 46f
        }

        row("Item", "Lifetime")
        row("Plan", "Momentum Premium")
        row("Holder", data.userName.ifBlank { "friend" })
        row("Focused", "${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m")
        row("Streak", "${data.streakDays} days")
        // PAID in Mint bold, the same colour this app already uses for
        // anything confirmed and settled -- Home's earned-today line, the
        // owned-premium header. One coloured word here does more than a
        // whole page of black text to say "this went through".
        row("Status", "PAID", Paint(bold).apply { color = mint; textAlign = Paint.Align.RIGHT })

        // The app's own mark as an actual stamp — angled, visible, mint —
        // near the paid line the way a real receipt's approval stamp sits
        // by the total, not a watermark faint enough to miss. Ring and its
        // closing dot, the same shape as the launcher icon, drawn with the
        // native Canvas this whole file already uses rather than mixed in
        // with the Compose drawing the animated printer sequence does.
        run {
            // Was overlapping the Focused/Streak/Status rows directly above
            // — stampCy sat 90px *above* the current y, which put its radius
            // right through three lines of text still being drawn there.
            // Moved below the rows instead, using the one row's worth of
            // slack already built into the height formula, and shrunk so it
            // reads as a stamp beside the text rather than printed over them.
            val stampCx = W - PAD - 60f
            val stampCy = y + 24f
            val stampR = 40f
            c.save()
            c.rotate(-14f, stampCx, stampCy)
            val stampPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = mint
                alpha = 130
                style = Paint.Style.STROKE
                strokeWidth = 7f
                strokeCap = Paint.Cap.ROUND
            }
            c.drawArc(
                stampCx - stampR, stampCy - stampR, stampCx + stampR, stampCy + stampR,
                -110f, 320f, false, stampPaint,
            )
            val dotAngle = Math.toRadians(-110.0)
            c.drawCircle(
                (stampCx + Math.cos(dotAngle).toFloat() * stampR),
                (stampCy + Math.sin(dotAngle).toFloat() * stampR),
                9f,
                Paint(Paint.ANTI_ALIAS_FLAG).apply { color = mint; alpha = 130 },
            )
            c.drawText(
                "MOMENTUM",
                stampCx, stampCy + 10f,
                Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = mint
                    alpha = 150
                    typeface = monoBold
                    textSize = 13f
                    textAlign = Paint.Align.CENTER
                },
            )
            c.restore()
        }
        y += 68f

        dotted(c, y); y += 50f

        // The ticket-stub barcode from the reference — a perforated line,
        // then a barcode with the licence key as its human-readable ID
        // underneath, in place of just ending on the two closing lines. A
        // paid receipt reading like an admit-one stub is closer to what
        // this actually is than a plain printed slip: proof to keep, not
        // just proof to glance at once.
        run {
            val perfY = y
            val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(80, 0, 0, 0)
                strokeWidth = 2f
            }
            var dx = PAD
            while (dx < W - PAD) {
                c.drawLine(dx, perfY, dx + 10f, perfY, dash)
                dx += 18f
            }
            y += 36f

            val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
            val barcodeSeed = data.licenseKey.hashCode()
            var bx = PAD
            val barTop = y
            val barH = 60f
            var seedState = barcodeSeed
            while (bx < W - PAD) {
                seedState = seedState * 1103515245 + 12345
                val wide = (seedState ushr 16) % 3 == 0
                val bw = if (wide) 5f else 2f
                // A bar that would cross the right margin is dropped, not
                // clipped: a half bar reads as a printing fault.
                if (bx + bw > W - PAD) break
                if ((seedState ushr 8) % 5 != 0) {
                    c.drawRect(bx, barTop, bx + bw, barTop + barH, barPaint)
                }
                bx += bw + 3f
            }
            // 34px under the bars, not 18: with 60px bars and a 20px caption
            // the old gap left the caption's ascenders touching the barcode.
            y += barH + 34f
            c.drawText(
                License.pretty(data.licenseKey).ifBlank { "MOM-00000-00000-00000" },
                W / 2f, y,
                Paint(ink).apply { textAlign = Paint.Align.CENTER; textSize = 22f; letterSpacing = 0.08f },
            )
            y += 52f
        }

        c.drawText("Blocking stays free. Always.", W / 2f, y, centre)
        y += 40f
        c.drawText("Keep this key. It moves phones.", W / 2f, y, centre)
        return y
    }

    private fun dotted(c: Canvas, y: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            strokeWidth = 2f
        }
        var x = PAD
        while (x < W - PAD) {
            c.drawLine(x, y, x + 6f, y, p)
            x += 14f
        }
    }

    private fun dashedBox(c: Canvas, top: Float, bottom: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2f
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f, 8f), 0f)
        }
        c.drawRect(PAD - 8f, top, W - PAD + 8f, bottom, p)
    }

    /** The zigzag tear at the bottom, the way a slip leaves the printer. */
    private fun tornEdge(c: Canvas, h: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.TRANSPARENT }
        p.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR)
        val path = Path().apply {
            moveTo(0f, h)
            var x = 0f
            var up = true
            moveTo(0f, h - TEAR)
            while (x < W) {
                x += 24f
                lineTo(x, if (up) h else h - TEAR)
                up = !up
            }
            lineTo(W.toFloat(), h)
            lineTo(0f, h)
            close()
        }
        c.drawPath(path, p)
    }

    // ------------------------------------------------------------------
    // v5 receipt (2026-10-03): a torn notebook note on a dark green-lit
    // scene — spiral punch holes, glowing check badge, handwritten notes,
    // flying green confetti. 1080x1620, shareable as-is. States only what
    // the app knows: holder, key, date. No invented price or plan length.
    // ------------------------------------------------------------------
    private fun fmtKey(k: String): String {
        if (k.contains('-') || k.length < 8) return k
        val head = k.take(3); val rest = k.drop(3)
        return head + "-" + rest.chunked(5).joinToString("-")
    }

    private fun renderNote(data: AppData): Bitmap {
        val w = 1080; val h = 1620
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val G = Color.parseColor("#2EE07A"); val GD = Color.parseColor("#0E7A3E"); val GL = Color.parseColor("#9BFFC4")
        val rnd = java.util.Random(data.licenseKey.hashCode().toLong() xor 0x5EED)
        fun blur(r: Float) = android.graphics.BlurMaskFilter(r, android.graphics.BlurMaskFilter.Blur.NORMAL)
        fun shader(p: Paint, s: android.graphics.Shader) = p.apply { shader = s }

        // ---- scene: black with a green bloom high in the frame
        c.drawColor(Color.parseColor("#050806"))
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), shader(Paint(Paint.ANTI_ALIAS_FLAG),
            android.graphics.RadialGradient(540f, 260f, 760f, intArrayOf(Color.argb(120, 30, 160, 80), Color.argb(40, 20, 120, 60), Color.TRANSPARENT), floatArrayOf(0f, 0.4f, 1f), android.graphics.Shader.TileMode.CLAMP)))

        // ---- depth-of-field confetti: blurred far flakes, sharp near ones
        val flake = Paint(Paint.ANTI_ALIAS_FLAG)
        repeat(60) {
            val x = rnd.nextFloat() * w; val y = rnd.nextFloat() * h
            val far = rnd.nextFloat() < 0.35f
            val fw = if (far) 40f + rnd.nextFloat() * 40f else 12f + rnd.nextFloat() * 22f
            val fh = fw * (0.3f + rnd.nextFloat() * 0.35f)
            flake.color = if (far) Color.argb(90, 46, 224, 122) else Color.argb(200 + rnd.nextInt(55), 60 + rnd.nextInt(40), 230, 130)
            flake.maskFilter = if (far) blur(14f) else null
            c.save(); c.rotate(rnd.nextFloat() * 360f, x, y)
            c.drawRoundRect(x - fw / 2, y - fh / 2, x + fw / 2, y + fh / 2, 3f, 3f, flake)
            c.restore()
        }
        // ---- a blurred banknote drifting at the left edge
        c.save(); c.rotate(24f, 70f, 720f)
        val note = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 96, 170, 110); maskFilter = blur(10f) }
        c.drawRoundRect(-60f, 640f, 200f, 790f, 10f, 10f, note)
        note.color = Color.argb(110, 160, 220, 170); c.drawCircle(70f, 715f, 34f, note)
        c.restore()
        // ---- sparkle dust around the top badge
        val dust = Paint(Paint.ANTI_ALIAS_FLAG)
        repeat(70) {
            val a = rnd.nextFloat() * 6.283f; val d = 110f + rnd.nextFloat() * 160f
            dust.color = Color.argb(80 + rnd.nextInt(170), 120, 255, 170)
            c.drawCircle(540f + kotlin.math.cos(a) * d, 205f + kotlin.math.sin(a) * d * 0.7f, 1.5f + rnd.nextFloat() * 2.5f, dust)
        }

        // ---- the badge (drawn twice: big above the note, smaller on it)
        fun badge(cx: Float, cy: Float, r: Float, glowA: Int) {
            c.drawCircle(cx, cy, r * 1.9f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(glowA, 46, 224, 122); maskFilter = blur(r * 0.8f) })
            c.drawCircle(cx, cy + r * 0.06f, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(160, 0, 0, 0); maskFilter = blur(r * 0.18f) })
            c.drawCircle(cx, cy, r, shader(Paint(Paint.ANTI_ALIAS_FLAG), android.graphics.RadialGradient(cx - r * 0.35f, cy - r * 0.4f, r * 1.35f, intArrayOf(GL, G, GD), floatArrayOf(0f, 0.45f, 1f), android.graphics.Shader.TileMode.CLAMP)))
            // halftone grain on the badge
            val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(45, 0, 40, 10) }
            val rr = java.util.Random(r.toLong())
            repeat((r * 2.2f).toInt()) {
                val a = rr.nextFloat() * 6.283f; val d = rr.nextFloat() * r * 0.95f
                c.drawCircle(cx + kotlin.math.cos(a) * d, cy + kotlin.math.sin(a) * d, 1.6f, dot)
            }
            // glossy rim + dotted outer ring
            c.drawCircle(cx, cy, r - 3f, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.argb(140, 220, 255, 230) })
            c.drawCircle(cx, cy, r + r * 0.16f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = r * 0.035f + 1f; color = G
                pathEffect = android.graphics.DashPathEffect(floatArrayOf(3f, r * 0.07f + 4f), 0f)
            })
            val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = r * 0.17f; color = Color.WHITE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
            c.drawPath(Path().apply { moveTo(cx - r * 0.42f, cy + r * 0.02f); lineTo(cx - r * 0.1f, cy + r * 0.33f); lineTo(cx + r * 0.46f, cy - r * 0.3f) }, tick)
            // specular glint
            c.drawCircle(cx - r * 0.38f, cy - r * 0.42f, r * 0.12f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 255, 255, 255); maskFilter = blur(r * 0.08f) })
        }

        // ---- the note: crumpled, torn, punched, turned a little
        val nl = 210f; val nt = 330f; val nr = 870f; val nb = 1130f
        c.save(); c.rotate(-2.5f, 540f, 730f)
        val torn = Path().apply {
            moveTo(nl, nt); lineTo(nr, nt); lineTo(nr + 6f, nb)
            var x = nr; val tr = java.util.Random(91)
            while (x > nl) { x -= 8f + tr.nextFloat() * 22f; lineTo(maxOf(x, nl), nb + (tr.nextFloat() - 0.5f) * 34f) }
            lineTo(nl - 4f, nt); close()
        }
        c.drawPath(torn, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 0, 0, 0); maskFilter = blur(26f) }.also { c.save(); c.translate(14f, 22f) })
        c.restore()
        c.drawPath(torn, shader(Paint(Paint.ANTI_ALIAS_FLAG), android.graphics.LinearGradient(nl, nt, nr, nb, Color.parseColor("#F3F2EE"), Color.parseColor("#DCDAD3"), android.graphics.Shader.TileMode.CLAMP)))
        c.save(); c.clipPath(torn)
        // crumple: soft light and shadow facets
        val facet = Paint(Paint.ANTI_ALIAS_FLAG).apply { maskFilter = blur(18f) }
        val cr = java.util.Random(23)
        repeat(26) {
            val px = nl + cr.nextFloat() * (nr - nl); val py = nt + cr.nextFloat() * (nb - nt)
            facet.color = if (it % 2 == 0) Color.argb(26, 0, 0, 0) else Color.argb(40, 255, 255, 255)
            c.drawPath(Path().apply {
                moveTo(px, py); lineTo(px + (cr.nextFloat() - 0.5f) * 260f, py + (cr.nextFloat() - 0.5f) * 220f)
                lineTo(px + (cr.nextFloat() - 0.5f) * 260f, py + (cr.nextFloat() - 0.5f) * 220f); close()
            }, facet)
        }
        val crease = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 1.4f; color = Color.argb(30, 0, 0, 0) }
        repeat(14) {
            val x0 = nl + cr.nextFloat() * (nr - nl); val y0 = nt + cr.nextFloat() * (nb - nt)
            c.drawLine(x0, y0, x0 + (cr.nextFloat() - 0.5f) * 300f, y0 + (cr.nextFloat() - 0.5f) * 200f, crease)
        }
        val grain = Paint().apply { color = Color.argb(16, 0, 0, 0) }
        repeat(2600) { c.drawCircle(nl + cr.nextFloat() * (nr - nl), nt + cr.nextFloat() * (nb - nt), 1.1f, grain) }
        c.restore()
        // fibrous torn edge highlight
        c.drawPath(torn, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = Color.argb(90, 255, 255, 255) })
        // spiral punches with the paper curl over each hole
        var hx = nl + 34f
        val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#050806") }
        val curl = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.parseColor("#EDEBE6"); strokeCap = Paint.Cap.ROUND }
        while (hx < nr - 24f) {
            c.drawCircle(hx, nt + 30f, 10f, hole)
            c.drawArc(hx - 12f, nt - 2f, hx + 12f, nt + 22f, 200f, 140f, false, curl)
            hx += 46f
        }
        badge(540f, 470f, 82f, 70)
        val ink = Color.parseColor("#151515")
        fun tp(size: Float, bold: Boolean = false, mono: Boolean = false, col: Int = ink) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; color = col; textAlign = Paint.Align.CENTER
            typeface = Typeface.create(if (mono) Typeface.MONOSPACE else Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        c.drawText("PREMIUM", 540f, 655f, tp(92f, bold = true))
        c.drawText((data.userName.ifBlank { "Friend" }) + " unlocked", 540f, 722f, tp(40f))
        c.drawText("Momentum Premium", 540f, 790f, tp(56f, bold = true))
        if (data.licenseKey.isNotBlank()) c.drawText(fmtKey(data.licenseKey), 540f, 850f, tp(36f, mono = true, col = Color.parseColor("#333333")))
        c.drawLine(nl + 40f, 905f, nr - 40f, 905f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#3A3A3A"); strokeWidth = 3f; pathEffect = android.graphics.DashPathEffect(floatArrayOf(16f, 10f), 0f) })
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("d MMM yyyy, h:mma")).replace("AM", "am").replace("PM", "pm")
        c.drawText("$stamp  •  focus, banked.", 540f, 975f, tp(34f, col = Color.parseColor("#2A2A2A")))
        c.restore()

        // big glowing badge above the note, overlapping its top edge
        badge(540f, 205f, 118f, 120)

        // ---- handwriting
        fun hand(size: Float, col: Int, align: Paint.Align = Paint.Align.LEFT) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; color = col; textAlign = align; typeface = Typeface.create("cursive", Typeface.NORMAL)
        }
        c.save(); c.rotate(-16f, 160f, 230f)
        c.drawText("Unlocked", 70f, 220f, hand(50f, Color.WHITE)); c.drawText("for real", 95f, 275f, hand(50f, Color.WHITE))
        c.restore()
        val arrow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.WHITE; strokeCap = Paint.Cap.ROUND }
        c.drawPath(Path().apply { moveTo(150f, 320f); quadTo(140f, 400f, 205f, 440f) }, arrow)
        c.drawPath(Path().apply { moveTo(178f, 446f); lineTo(207f, 442f); lineTo(196f, 414f) }, arrow)
        c.save(); c.rotate(-10f, 900f, 180f)
        c.drawText("One step", 840f, 170f, hand(40f, Color.argb(150, 255, 255, 255))); c.drawText("closer ♡", 860f, 216f, hand(40f, Color.argb(150, 255, 255, 255)))
        c.restore()
        c.save(); c.rotate(-7f, 540f, 1250f)
        c.drawText("Focus, banked ♡", 540f, 1250f, hand(62f, Color.parseColor("#7CF2AE"), Paint.Align.CENTER))
        c.drawLine(380f, 1275f, 690f, 1262f, Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 3f; color = Color.parseColor("#7CF2AE"); strokeCap = Paint.Cap.ROUND })
        c.restore()
        c.save(); c.rotate(-18f, 140f, 1480f)
        c.drawText("Chhote sessions", 40f, 1450f, hand(34f, Color.argb(95, 255, 255, 255))); c.drawText("badi baatein ♡", 60f, 1495f, hand(34f, Color.argb(95, 255, 255, 255)))
        c.restore()
        c.save(); c.rotate(-18f, 930f, 1460f)
        c.drawText("Same phone", 830f, 1440f, hand(34f, Color.argb(95, 255, 255, 255))); c.drawText("more life", 860f, 1485f, hand(34f, Color.argb(95, 255, 255, 255)))
        c.restore()
        // ---- footer
        val brand = tp(48f, bold = true, col = Color.argb(150, 255, 255, 255))
        c.drawText("Unlocked with Momentum", 540f, 1370f, brand)
        c.drawText("FOCUS  •  BANKED  •  DESI", 540f, 1425f, tp(26f, bold = true, col = Color.argb(150, 255, 255, 255)).apply { letterSpacing = 0.25f })
        c.drawText("Keep this key. It moves phones.", 540f, 1560f, tp(30f, col = Color.argb(170, 255, 255, 255)))
        return bmp
    }

}
