package com.momentum.focus.ui.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * The unlock receipt -- a thermal-printer slip, rendered and saved to the
 * device's Downloads folder.
 *
 * Drawn rather than composed because the output is a file, not a screen. A
 * Compose surface would have to be captured to a bitmap anyway, and capture
 * pulls in view-tree plumbing that only exists while something is on screen;
 * a plain Canvas has neither problem and produces the same pixels whether the
 * app is foregrounded or not.
 *
 * The look is deliberately a till receipt: monospace, centred header, dotted
 * rules, a torn zigzag bottom edge. A licence is a purchase, and a purchase
 * that hands back something shaped like a receipt reads as settled in a way
 * that a "Thank you!" card does not.
 */
object Receipt {

    private const val W = 900
    private const val PAD = 72f

    /**
     * Renders the slip and writes it to Downloads.
     *
     * Returns the display name on success, null on any failure. Null rather
     * than an exception because the caller is an animation: a receipt that
     * could not be saved should cost the user nothing more than a missing
     * file, never a crash on the screen that just took their money.
     */
    suspend fun saveToDownloads(context: Context, data: AppData): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = render(data)
                val name = "momentum-receipt-${System.currentTimeMillis()}.png"
                if (Build.VERSION.SDK_INT >= 29) {
                    // MediaStore on API 29+, because scoped storage means a
                    // direct write to the public Downloads path is denied.
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, "image/png")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val uri = resolver.insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, values,
                    ) ?: return@runCatching null
                    resolver.openOutputStream(uri)?.use {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                } else {
                    // Pre-29 the public directory is writable directly, and
                    // MediaStore.Downloads does not exist yet.
                    @Suppress("DEPRECATION")
                    val dir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS,
                    )
                    dir.mkdirs()
                    File(dir, name).outputStream().use {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                }
                name
            }.getOrNull()
        }

    private fun render(data: AppData): Bitmap {
        val mono = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        val monoBold = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        val cream = Color.rgb(0xFF, 0xFD, 0xF2)
        val ink = Color.rgb(0x17, 0x1A, 0x18)
        val mint = Color.rgb(0x3F, 0xE2, 0x8F)

        val H = 1180
        val pad = PAD
        val bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap)
        c.drawColor(cream)

        val regular = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ink
            typeface = mono
            textSize = 27f
        }
        val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ink
            typeface = monoBold
            textSize = 31f
        }
        val centre = Paint(regular).apply { textAlign = Paint.Align.CENTER }
        val big = Paint(bold).apply { textAlign = Paint.Align.CENTER; textSize = 78f }
        val small = Paint(regular).apply { textAlign = Paint.Align.CENTER; textSize = 22f }

        // Green success header, with the same punched/receipt silhouette as the
        // supplied reference. The green is intentionally confined to the
        // success mark and header rather than turning the whole slip into a
        // coloured card.
        c.drawRect(0f, 0f, W.toFloat(), 210f, Paint().apply { color = mint })

        // Top tear/punch details.
        val holePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0x09, 0x10, 0x0C) }
        var hx = 48f
        while (hx < W - 30f) {
            c.drawCircle(hx, 28f, 13f, holePaint)
            hx += 56f
        }

        // Glowing check, visually matching the hero reference.
        val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = mint; alpha = 60 }
        c.drawCircle(W / 2f, 112f, 78f, glow)
        c.drawCircle(W / 2f, 112f, 60f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = cream })
        c.drawCircle(W / 2f, 112f, 56f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = mint })
        val check = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 10f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val path = Path().apply {
            moveTo(W / 2f - 27f, 113f)
            lineTo(W / 2f - 7f, 133f)
            lineTo(W / 2f + 34f, 91f)
        }
        c.drawPath(path, check)

        var y = 258f
        c.drawText("₹399", W / 2f, y, big)
        y += 54f
        c.drawText("Momentum Premium Paid", W / 2f, y, Paint(bold).apply { textSize = 31f })
        y += 42f
        c.drawText("Lifetime access", W / 2f, y, centre)
        y += 62f

        dotted(c, y, W, PAD)
        y += 54f

        val holder = data.userName.ifBlank { "Momentum member" }
        c.drawText("Paid by", pad, y, regular)
        c.drawText(holder, W - pad, y, Paint(regular).apply { textAlign = Paint.Align.RIGHT })
        y += 48f
        c.drawText("Item", pad, y, regular)
        c.drawText("Lifetime Premium", W - pad, y, Paint(regular).apply { textAlign = Paint.Align.RIGHT })
        y += 48f
        c.drawText("Status", pad, y, regular)
        c.drawText("PAID", W - pad, y, Paint(bold).apply { textAlign = Paint.Align.RIGHT; color = Color.rgb(0x1B, 0x9E, 0x55) })
        y += 62f

        dotted(c, y, W, PAD)
        y += 52f

        // Key is the useful payload of this receipt. It is boxed and isolated
        // like the amount in the reference rather than buried in a paragraph.
        c.drawText("LICENCE KEY", W / 2f, y, centre)
        y += 45f
        val key = License.pretty(data.licenseKey).ifBlank { "MOM-KEY-PENDING" }
        val boxTop = y - 34f
        val boxBottom = y + 34f
        c.drawRoundRect(
            pad - 8f, boxTop, W - pad + 8f, boxBottom, 14f, 14f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { color = mint; alpha = 80 },
        )
        dashedBox(c, boxTop, boxBottom, W, PAD)
        c.drawText(key, W / 2f, y + 10f, Paint(bold).apply { textAlign = Paint.Align.CENTER; textSize = 29f })
        y += 92f

        dotted(c, y, W, PAD)
        y += 48f
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm"))
        c.drawText(stamp, W / 2f, y, centre)
        y += 40f
        c.drawText("Transaction completed on device", W / 2f, y, small)
        y += 68f

        c.drawText("Payment successful", W / 2f, y, Paint(bold).apply { textAlign = Paint.Align.CENTER; color = Color.rgb(0x1B, 0x9E, 0x55) })
        y += 42f
        c.drawText("Keep this receipt with your licence key.", W / 2f, y, small)
        y += 45f
        c.drawText("Blocking stays free.", W / 2f, y, small)

        tornEdge(c, H.toFloat())
        return bitmap
    }

    private fun dotted(c: Canvas, y: Float, width: Int, pad: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            strokeWidth = 2f
        }
        var x = pad
        while (x < width - pad) {
            c.drawLine(x, y, x + 6f, y, p)
            x += 14f
        }
    }

    private fun dashedBox(c: Canvas, top: Float, bottom: Float, width: Int, pad: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2f
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f, 8f), 0f)
        }
        c.drawRect(pad - 8f, top, width - pad + 8f, bottom, p)
    }

    /** The zigzag tear at the bottom, the way a slip leaves the printer. */
    private fun tornEdge(c: Canvas, h: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.TRANSPARENT }
        p.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR)
        val path = Path().apply {
            moveTo(0f, h)
            var x = 0f
            var up = true
            moveTo(0f, h - 22f)
            while (x < W) {
                x += 24f
                lineTo(x, if (up) h else h - 22f)
                up = !up
            }
            lineTo(W.toFloat(), h)
            lineTo(0f, h)
            close()
        }
        c.drawPath(path, p)
    }
}
