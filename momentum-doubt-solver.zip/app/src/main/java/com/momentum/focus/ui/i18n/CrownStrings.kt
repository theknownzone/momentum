package com.momentum.focus.ui.i18n

/**
 * Crown mode's cutscene and its brief.
 *
 * The brief's lines are the important half. Crown takes device admin and makes
 * the app hard to remove, and a person should read what that means in plain
 * words before they agree to it — not discover it afterwards as a reveal.
 */
interface CrownStrings {
    val entered: String
    val subtitle: String
    val skip: String

    /**
     * The spoken line.
     *
     * English in both tables, deliberately. The engine is set to US English —
     * a Hinglish line in Latin script fed to an English voice comes out as
     * nonsense syllables, and switching the engine to Hindi would need voice
     * data most phones do not have installed.
     */
    val voiceLine: String
}

object CrownHi : CrownStrings {
    override val entered = "Crown chalu"
    override val subtitle = "Ab phone tumhara nahi, session ka hai."
    override val skip = "Tap karke aage badho"
    override val voiceLine = "Welcome to Crown Mode."

}

object CrownEn : CrownStrings {
    override val entered = "CROWN MODE"
    override val subtitle = "The phone belongs to the session now."
    override val skip = "Tap to continue"
    override val voiceLine = "Welcome to Crown Mode."

}
