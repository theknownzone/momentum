package com.momentum.focus.ui.screens

import com.momentum.focus.ui.components.PillToggle

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.momentum.focus.block.Admin
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.CeramicPanel
import com.momentum.focus.ui.components.FeedDebugDialog
import com.momentum.focus.ui.components.GlassSection
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.Lang
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.momentum.focus.data.ExamCatalog
import com.momentum.focus.data.ExamEntry
import com.momentum.focus.data.FocusLevels
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.rememberHaptics

/**
 * One column in the Profile action row.
 *
 * The badge under the icon carries live state — how many things are blocked,
 * whether permissions still need fixing — so the row answers "is anything
 * wrong" without opening anything. A Fix badge turns the tile orange, which is
 * the only reason it is coloured at all.
 */
@Composable
private fun ActionTile(
    icon: ImageVector,
    title: String,
    badge: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Column(
        modifier
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(sticker.fill.lit())
                .border(Paper.Outline, Ink, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = sticker.on,
                modifier = Modifier.size(22.dp),
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(title, style = MaterialTheme.typography.labelSmall, color = Ink)
        Text(badge, style = MaterialTheme.typography.labelSmall, color = InkMid)
    }
}

/**
 * Everything the app does, as opposed to everything the person is.
 *
 * Split out of Profile, which had grown to eleven hundred lines holding two
 * unrelated jobs at once: who you are and how you are doing, stacked on top of
 * what the app should block, when it should pay, and which permissions it
 * needs. Nobody opens a screen to do both, and having to scroll past your own
 * badges to change the earn rate is how a settings screen becomes one nobody
 * finds twice.
 *
 * ActionTile lives here too. It was left behind in ProfileScreen when this
 * screen was first carved out, which meant a file about a person still held a
 * component only the settings screen used.
 */
@Composable
fun SettingsScreen(
    data: AppData,
    onSound: (Boolean) -> Unit,
    onHapticIntensity: (Float) -> Unit = {},
    onNotify: (Boolean) -> Unit = {},
    onExam: (String, Long) -> Unit,
    onWeekend: (Boolean) -> Unit,
    onRatio: (Int) -> Unit,
    onGoal: (Int) -> Unit,
    onPermissions: () -> Unit,
    onChangelog: () -> Unit,
    onSupport: () -> Unit,
    onBlockList: () -> Unit,
    onShield: (Boolean) -> Unit,
    onSubjects: (List<String>) -> Unit = {},
    onClassHours: (Boolean, Int, Int) -> Unit = { _, _, _ -> },
    onClassDay: (Int) -> Unit = {},
    onName: (String) -> Unit = {},
    onLang: (String) -> Unit = {},
    onBack: () -> Unit = {},
) {
    val str = strings()
    val haptics = rememberHaptics()
    val context = LocalContext.current
    val sound = data.soundOn
    var name by remember(data.userName) { mutableStateOf(data.userName) }
    var feedDebug by remember { mutableStateOf(false) }
    val skinNow = LocalSkin.current
    // Whether the rules a pact enforces should currently hold — declared once,
    // used everywhere a control could weaken them: the earn rate, the weekend
    // easing, class hours, the shield switch itself. This used to be
    // data.pactLive alone, which only ever went true mid-session — so Crown
    // mode, active or not, left every one of these controls exactly as
    // editable as on the free tier the moment no session happened to be
    // running. A tap on the level picker to drop to L1 was the entire
    // "commitment." Crown now holds the same lock permanently, not only
    // while a session is live, because a device-admin lock that still lets
    // you loosen every rule around it from Settings was never actually a
    // commitment device — see FocusScreen for the matching change to what
    // it takes to leave Crown once it is on.
    val locked = data.pactLive || data.crownMode

    // Admin is granted on a system screen, so the only honest way to know
    // whether it stuck is to re-read it every time this screen resumes.
    val owner = LocalLifecycleOwner.current
    var adminRefresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) adminRefresh++
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    val adminOn = remember(adminRefresh) { Admin.isActive(context) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.tick(); onBack()
                    }
                    .padding(6.dp),
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = str.common.back,
                    tint = Ink,
                    modifier = Modifier.size(22.dp),
                )
            }
            Spacer(Modifier.width(6.dp))
            Text(
                str.common.settings,
                style = MaterialTheme.typography.headlineSmall,
                color = Ink,
            )
        }

        Spacer(Modifier.height(14.dp))

        // Name and language, in the open, above everything else. They were
        // inside a collapsed accordion called "App" — a field someone changes
        // once, buried two taps deep behind a heading that gives no hint it is
        // in there. The most-looked-for thing on a settings screen belongs at
        // the top of it, not filed under a category.
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(16.dp),
        ) {
        // ---- editable name ----
        Text(
            "NAME",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(18); onName(it.trim()) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(Paper.Gap))

        // ---- language ----
        // Sits with the theme rather than under App, because this is a
        // preference about how the app reads to you, not about what it
        // blocks. Both labels stay in their own language so the option you
        // are not using is still legible.
        Text(
            str.common.languageTitle.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            str.common.languageSubtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Lang.entries.forEach { option ->
                val on = data.lang == option.code
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(Paper.ChipRadius))
                        // petal, not accent: the Independence skin's accent
                        // is a dark green, and Ink on it is unreadable.
                        // Every petal is a pastel, so the label survives
                        // whichever skin is on.
                        .background(
                            if (on) skinNow.petal else MaterialTheme.colorScheme.surface
                        )
                        .border(
                            if (on) Paper.Outline else 1.dp,
                            Ink,
                            RoundedCornerShape(Paper.ChipRadius),
                        )
                        .clickableNoRipple(remember(option) { MutableInteractionSource() }) {
                            haptics.tick(); onLang(option.code)
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        option.label,
                        style = MaterialTheme.typography.titleMedium,
                        color = Ink,
                    )
                }
            }
        }

        }

        Spacer(Modifier.height(Paper.Gap))

        var blockDenied by remember { mutableStateOf(false) }
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            val permsOk = Perms.allRequiredGranted(context)
            ActionTile(
                Icons.Filled.Shield,
                "Block",
                "${data.blockedPackages.size + data.blockedSurfaces.size}",
                Mint,
                Modifier.weight(1f),
            ) {
                // The list itself, not just the rules above it. Loosening the
                // earn rate was locked; walking in here and un-checking the
                // one app someone actually needed blocked is the same
                // loophole in a different shape, and it was still wide open.
                if (locked) {
                    haptics.tick()
                    blockDenied = true
                } else {
                    haptics.tap(); onBlockList()
                }
            }
            ActionTile(
                Icons.Filled.VerifiedUser,
                "Perms",
                if (permsOk) "OK" else "Fix",
                if (permsOk) Sky else Tang,
                Modifier.weight(1f),
            ) { haptics.tap(); onPermissions() }
            ActionTile(
                Icons.Filled.ChatBubble,
                "Help",
                "Likho",
                Lilac,
                Modifier.weight(1f),
            ) { haptics.tap(); onSupport() }
            ActionTile(
                Icons.Filled.BugReport,
                "Feed IDs",
                "Debug",
                Butter,
                Modifier.weight(1f),
            ) { haptics.tap(); feedDebug = true }
        }

        if (blockDenied) {
            LaunchedEffect(Unit) {
                kotlinx.coroutines.delay(1800)
                blockDenied = false
            }
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Tang.fill.copy(alpha = 0.22f))
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("🔒", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.width(8.dp))
                Text(
                    "Pact chal raha hai — blocked apps abhi edit nahi ho sakte.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
        }


        GlassSection("Target", "Kitna padhna hai aur kis liye", tint = skinNow.accent, initiallyOpen = true) {

            // ---- streak goal ----
            Text(
                "STREAK GOAL",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 60, 90, 180).forEach { days ->
                    val on = data.streakGoal == days
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (on) Butter.fill
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick(); onGoal(days)
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            "$days",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (on) Butter.on
                                    else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // ---- exam ----
            Text("EXAM", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            var examName by remember(data.examName) { mutableStateOf(data.examName) }
            var catalog by remember { mutableStateOf(ExamCatalog.bundled(context)) }
            LaunchedEffect(Unit) {
                catalog = ExamCatalog.refresh(context)
            }
            OutlinedTextField(
                value = examName,
                onValueChange = { examName = it.take(32) },
                placeholder = { Text("Search JEE, NEET, SSC…") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )
            val hits = remember(examName, catalog) { ExamCatalog.search(catalog, examName) }
            if (hits.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                hits.forEach { exam: ExamEntry ->
                    val selected = examName.equals(exam.name, ignoreCase = true)
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (selected) Tang.fill
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .border(2.dp, Ink, RoundedCornerShape(12.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick()
                                examName = exam.name
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                    ) {
                        Text(
                            "${exam.name}  ·  ${exam.regionLabel}",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (selected) Tang.on
                            else MaterialTheme.colorScheme.onBackground,
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 60, 90, 180).forEach { days ->
                    val target = java.time.LocalDate.now().plusDays(days.toLong()).toEpochDay()
                    val on = data.examEpochDay == target
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (on) Tang.fill else MaterialTheme.colorScheme.surfaceVariant)
                            .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick(); onExam(examName, target)
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            "${days}d",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (on) Tang.on else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            data.daysToExam?.let {
                if (it >= 0) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "$it days left · Crown switches on inside ${data.examCrownDays} days",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Text("3 SUBJECTS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "Exam pack start. Apna naam likh — PCM forced nahi.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            var sub0 by remember(data.subjects) { mutableStateOf(data.subjects.getOrElse(0) { "" }) }
            var sub1 by remember(data.subjects) { mutableStateOf(data.subjects.getOrElse(1) { "" }) }
            var sub2 by remember(data.subjects) { mutableStateOf(data.subjects.getOrElse(2) { "" }) }
            listOf(0 to sub0, 1 to sub1, 2 to sub2).forEach { (i, _) ->
                val value = when (i) { 0 -> sub0; 1 -> sub1; else -> sub2 }
                OutlinedTextField(
                    value = value,
                    onValueChange = {
                        val v = it.take(18).trim()
                        when (i) { 0 -> sub0 = v; 1 -> sub1 = v; else -> sub2 = v }
                        onSubjects( listOf(if (i==0) v else sub0, if (i==1) v else sub1, if (i==2) v else sub2)
                            .mapIndexed { idx, s -> s.ifBlank { "Paper ${idx + 1}" } } )
                    },
                    singleLine = true,
                    placeholder = { Text("Subject ${i + 1}") },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                )
            }

        }

        GlassSection("Rules", "Kab shield lage aur ₹ kaise mile", tint = skinNow.petal) {
            // The banner this whole section was missing.
            //
            // The crown brief tells whoever just armed a pact "Settings stay
            // locked while a session runs" — that line is what makes agreeing
            // to Crown mean something, because otherwise the fix for "I don't
            // want the pact anymore" is just to come here and loosen the rule
            // instead of dropping the level honestly. Nothing in this screen
            // ever checked data.pactLive; every control below worked exactly
            // the same whether a pact was live or not. The promise was made
            // on one screen and never kept on this one.
            if (locked) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Tang.fill.copy(alpha = 0.22f))
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("🔒", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Pact chal raha hai — rules lock hain jab tak khatam na ho.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                }
            }

            // ---- earn ratio ----
            Text(
                "EARN RATE",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "${data.earnRatio} min of study buys 1 min of scrolling",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.alpha(if (locked) 0.45f else 1f),
            ) {
                listOf(4, 6, 8, 12).forEach { r ->
                    val on = data.earnRatio == r
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (on) Mint.fill else MaterialTheme.colorScheme.surfaceVariant)
                            .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                // Swallowed rather than removing the click
                                // handler entirely, so the chip does not need
                                // a second, disabled-look visual state on top
                                // of the alpha fade above.
                                if (locked) return@clickableNoRipple
                                haptics.tick(); onRatio(r)
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            "${r}:1",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (on) Mint.on else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            // ---- weekend ----
            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Easier weekends",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        "Halves the earn rate on Sat and Sun",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                PillToggle(
                    checked = data.weekendRelaxed,
                    enabled = !locked,
                    onCheckedChange = { onWeekend(it) },
                )
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Class hours",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        "${data.classStartHour}:00–${data.classEndHour}:00 · ${FocusLevels.SHIELD}+ pe Shield khud ON",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (data.classHoursOn) {
                        Spacer(Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.alpha(if (locked) 0.45f else 1f),
                        ) {
                            listOf("M", "T", "W", "T", "F", "S", "S")
                                .forEachIndexed { i, letter ->
                                    val day = i + 1
                                    val on = day in data.classDays
                                    Box(
                                        Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(if (on) Sky.fill else CreamCard)
                                            .border(2.dp, Ink, CircleShape)
                                            .clickableNoRipple(
                                                remember { MutableInteractionSource() }
                                            ) {
                                                if (locked) return@clickableNoRipple
                                                haptics.tick(); onClassDay(day)
                                            },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Text(
                                            letter,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (on) Sky.on else InkMid,
                                        )
                                    }
                                }
                        }
                    }
                }
                PillToggle(
                    checked = data.classHoursOn,
                    enabled = !locked,
                    onCheckedChange = {
                        onClassHours(it, data.classStartHour, data.classEndHour)
                    },
                )
            }

            // Profiles and the app list used to sit here, one row below avatars
            // and exam dates. They are blocking controls, not identity, and they
            // now live together in the Block hub — one row that goes there beats
            // three unrelated ones scattered down this column.
        }

        GlassSection("App", "Blocking aur permissions", tint = skinNow.accent) {
            // ---- toggles ----
            // On a ceramic slab rather than bare inside the section. These two
            // switches are the only things on this screen that change how the
            // app behaves rather than what it knows, and the surface is what
            // says so — everything else here is a field or a list.
            CeramicPanel(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                radius = 18.dp,
                tint = skinNow.accent,
            ) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Notifications",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        // Says what it does not cover, because a switch called
                        // Notifications that leaves one running looks broken.
                        "Exam alerts, weekly read, streak warnings. Not the session timer.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                FaceToggle(
                    on = data.notifyOn,
                    onToggle = { onNotify(it); haptics.tick() },
                )
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Sound effects",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        "Silent mode always wins",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                SparkleToggle(
                    on = sound,
                    onToggle = { onSound(it); haptics.tick() },
                )
            }
            }
            }

            Spacer(Modifier.height(18.dp))
            // Real, wired setting that had no slider anywhere to move it —
            // onHapticIntensity and data.hapticIntensity already existed
            // end to end (Haptics.intensity synced from it in MainActivity),
            // just nothing in this screen ever called the callback.
            Column {
                Text(
                    "Haptic intensity",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Spacer(Modifier.height(10.dp))
                Slider(
                    value = data.hapticIntensity,
                    onValueChange = { onHapticIntensity(it); haptics.tick() },
                    valueRange = 0.2f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = Ink,
                        activeTrackColor = Tang.fill,
                        inactiveTrackColor = Tang.fill.copy(alpha = 0.25f),
                    ),
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Soft", style = MaterialTheme.typography.bodySmall, color = InkMid)
                    Text("Strong", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Ink)
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Shield",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        "Blocks your chosen apps in the background",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                PillToggle(
                    checked = data.shieldOn,
                    enabled = !locked,
                    onCheckedChange = { onShield(it); haptics.shield(it) },
                )
            }

        }

        Spacer(Modifier.height(40.dp))

        // The full stop at the bottom of the scroll: oversized, low contrast,
        // with the version underneath. Reaching it should feel like the end of
        // something made rather than a list running out.
        Column(
            Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "momentum",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontFamily = FontFamily.Serif,
                ),
                color = InkLow.copy(alpha = 0.45f),
            )
            Text(
                "v${Updater.currentVersion(context)}",
                style = MaterialTheme.typography.bodyLarge,
                color = InkLow.copy(alpha = 0.55f),
                modifier = Modifier
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.tap(); onChangelog()
                    }
                    .padding(6.dp),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Earned, not claimed.",
                style = MaterialTheme.typography.bodyMedium,
                color = InkLow.copy(alpha = 0.45f),
            )
        }

        Spacer(Modifier.height(24.dp))
    }

    if (feedDebug) FeedDebugDialog { feedDebug = false }
}

/**
 * The pixel-coin toggle from the reference, in Momentum's own colours —
 * a coin sliding between two states with a sad or happy face on it,
 * rather than a bare Material Switch that says on/off with a colour
 * change alone. This is the main "notify me" switch specifically because
 * it's the one setting on this whole screen that decides whether the app
 * gets to say anything to someone at all; the others don't need a face.
 */
@Composable
private fun FaceToggle(on: Boolean, onToggle: (Boolean) -> Unit) {
    val haptics = rememberHaptics()
    val slide by animateFloatAsState(if (on) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 300f), label = "face-slide")
    val trackColor by animateColorAsState(if (on) Mint.fill else Tang.fill, tween(300), label = "face-track")

    Box(
        Modifier
            .width(58.dp)
            .height(32.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF17151F))
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .clickableNoRipple(remember { MutableInteractionSource() }) { onToggle(!on) }
            .padding(3.dp),
    ) {
        Box(
            Modifier
                .size(24.dp)
                .graphicsLayer { translationX = slide * 26.dp.toPx() },
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                drawCircle(trackColor, radius = w / 2f)
                drawCircle(Ink, radius = w / 2f, style = Stroke(width = 1.5.dp.toPx()))
                // A plain bell mark instead of a cartoon face — this is a
                // notification toggle, and a bell says that in the same
                // icon language the rest of a serious app would use.
                val cx = w * 0.5f
                val bellPath = Path().apply {
                    moveTo(cx - w * 0.20f, w * 0.56f)
                    quadraticBezierTo(cx - w * 0.20f, w * 0.30f, cx, w * 0.30f)
                    quadraticBezierTo(cx + w * 0.20f, w * 0.30f, cx + w * 0.20f, w * 0.56f)
                    lineTo(cx + w * 0.26f, w * 0.64f)
                    lineTo(cx - w * 0.26f, w * 0.64f)
                    close()
                }
                drawPath(bellPath, Ink, style = Stroke(width = w * 0.055f, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
                drawLine(Ink, Offset(cx - w * 0.06f, w * 0.68f), Offset(cx + w * 0.06f, w * 0.68f), strokeWidth = w * 0.055f, cap = StrokeCap.Round)
            }
        }
    }
}

/**
 * The sparkle toggle from the reference — small particles that streak
 * across the thumb once, the moment it turns on, rather than a Switch
 * that just moves. Used here specifically because turning sound ON is
 * the one settings toggle where a small delighted flourish actually fits
 * what it's turning on; the others are plainer preferences.
 */
@Composable
private fun SparkleToggle(on: Boolean, onToggle: (Boolean) -> Unit) {
    val slide by animateFloatAsState(if (on) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 300f), label = "sparkle-slide")
    val trackColor by animateColorAsState(if (on) Mint.fill else Color(0xFFB8B4A8), tween(250), label = "sparkle-track")

    var burstId by remember { mutableIntStateOf(0) }
    var burstT by remember { mutableFloatStateOf(1f) }
    LaunchedEffect(on) {
        if (on) {
            burstId++
            burstT = 0f
            val start = withFrameNanos { it }
            while (burstT < 1f) {
                withFrameNanos { now -> burstT = ((now - start) / 1_000_000f / 500f).coerceIn(0f, 1f) }
            }
        }
    }

    Box(
        Modifier
            .width(58.dp)
            .height(32.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF17151F))
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .clickableNoRipple(remember { MutableInteractionSource() }) { onToggle(!on) }
            .padding(3.dp),
    ) {
        Box(Modifier.size(24.dp).graphicsLayer { translationX = slide * 26.dp.toPx() }) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                drawCircle(trackColor, radius = w / 2f)
                drawCircle(Ink, radius = w / 2f, style = Stroke(width = 1.5.dp.toPx()))
                if (burstT < 1f) {
                    val fade = 1f - burstT
                    repeat(6) { i ->
                        val ang = (i / 6f) * 2f * kotlin.math.PI.toFloat()
                        val dist = burstT * w * 0.9f
                        drawCircle(
                            color = Color.White.copy(alpha = fade),
                            radius = w * 0.06f * fade,
                            center = Offset(
                                w / 2f + kotlin.math.cos(ang) * dist,
                                w / 2f + kotlin.math.sin(ang) * dist,
                            ),
                        )
                    }
                }
            }
        }
    }
}
