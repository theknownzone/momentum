package com.momentum.focus.ui.screens

import com.momentum.focus.ui.components.BackPill
import com.momentum.focus.data.tr
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.GlassSection
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.rememberHaptics

/** Support inbox. Replace if this ever moves to a domain address. */
private const val SUPPORT_EMAIL = "barrytbrooks2@gmail.com"

/**
 * Help, feedback and the plain facts about what the app does with data.
 *
 * The device and build details are filled into the email body automatically.
 * Asking someone to find their Android version and app build before they can
 * report a bug is how bug reports stop arriving.
 */
@Composable
fun SupportScreen(data: AppData, onDone: () -> Unit) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val skin = LocalSkin.current

    fun mail(subject: String) {
        val body = buildString {
            append("\n\n\n---\n")
            append(tr("Please keep these lines, they help find the problem.\n", "कृपया ये पंक्तियाँ रहने दें, इनसे समस्या ढूँढने में आसानी होती है।\n"))
            append("App: Momentum ${Updater.currentVersion(context)}\n")
            append("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
            append("Device: ${Build.MANUFACTURER} ${Build.MODEL}\n")
            append("Plan: ${if (data.premium) "Lifetime" else "Free"}\n")
        }
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$SUPPORT_EMAIL"))
                    .putExtra(Intent.EXTRA_SUBJECT, subject)
                    .putExtra(Intent.EXTRA_TEXT, body)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        BackPill(onBack = onDone)
        Spacer(Modifier.height(14.dp))
        Text(tr("HELP", "सहायता"), style = MaterialTheme.typography.labelSmall, color = InkMid)
        Text(
            tr("Stuck on something?", "कहीं अटके हैं?"),
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            tr("Just write in. A person replies, not a bot.", "सीधे लिखें। जवाब एक इंसान देगा, बॉट नहीं।"),
            style = MaterialTheme.typography.bodyLarge,
            color = InkMid,
        )

        GlassSection(tr("Talk to us", "बात करें"), tr("Email, bug, suggestion", "ईमेल, बग, सुझाव"), tint = skin.accent, initiallyOpen = true) {
            SupportRow(
                tr("Something's broken", "कुछ टूटा है"),
                tr("Send a bug report — device details are added automatically", "बग रिपोर्ट भेजें — डिवाइस की जानकारी अपने आप जुड़ जाएगी"),
            ) { haptics.tap(); mail("Momentum — bug") }
            SupportRow(
                tr("Want something", "कुछ चाहिए"),
                tr("Suggest a new feature or a change", "नया फ़ीचर या बदलाव सुझाएँ"),
            ) { haptics.tap(); mail("Momentum — feature") }
            SupportRow(
                tr("Payment trouble", "भुगतान की समस्या"),
                tr("Key didn't work, or a payment question", "की नहीं चली, या भुगतान से जुड़ा सवाल"),
            ) { haptics.tap(); mail("Momentum — licence") }
        }

        GlassSection(tr("Your data", "आपका डेटा"), tr("Where it goes", "कहाँ जाता है"), tint = skin.petal) {
            Fact(
                tr("Everything stays on this phone", "सब कुछ इसी फ़ोन पर है"),
                tr("There's no server. No account, no login. What you make stays here, and goes away when the app is uninstalled.", "कोई सर्वर नहीं है। न अकाउंट, न लॉगिन। आपने जो बनाया वह यहीं रहता है, और ऐप अनइंस्टॉल करने पर हट जाता है।"),
            )
            Fact(
                tr("The screen-reading permission", "स्क्रीन पढ़ने वाली अनुमति"),
                tr("Accessibility is only used to see whether Shorts or Reels is open. It sends nothing and saves nothing.", "Accessibility सिर्फ़ यह देखने के लिए है कि Shorts या Reels खुले हैं या नहीं। यह कुछ भेजता नहीं, कुछ सेव नहीं करता।"),
            )
            Fact(
                tr("When internet is used", "इंटरनेट कब लगता है"),
                tr("Only to check for updates. The rest of the app works offline.", "सिर्फ़ अपडेट जाँचने के लिए। बाकी पूरा ऐप ऑफ़लाइन चलता है।"),
            )
        }

        Spacer(Modifier.height(20.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                .clickableNoRipple(remember { MutableInteractionSource() }) {
                    haptics.tap(); onDone()
                }
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(tr("Back", "वापस"), style = MaterialTheme.typography.titleMedium, color = Ink)
        }
    }
}

@Composable
private fun SupportRow(title: String, note: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
            Text(note, style = MaterialTheme.typography.bodyMedium, color = InkMid)
        }
        Text("\u203A", style = MaterialTheme.typography.headlineSmall, color = InkMid)
    }
}

@Composable
private fun Fact(title: String, body: String) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
        Text(body, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}
