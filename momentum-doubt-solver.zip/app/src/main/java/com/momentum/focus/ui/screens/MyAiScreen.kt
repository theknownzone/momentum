package com.momentum.focus.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.momentum.focus.ai.DoubtState
import com.momentum.focus.ai.MyAiMode
import com.momentum.focus.ai.StudyPulse
import com.momentum.focus.ui.components.AnswerStyleSheet
import com.momentum.focus.ui.components.DoubtSheet
import com.momentum.focus.ui.components.LedState
import com.momentum.focus.ui.components.MyAiControlBar
import com.momentum.focus.ui.components.MyAiTopBar
import com.momentum.focus.ui.components.MyAiWelcome
import com.momentum.focus.ui.components.ledCanShow
import com.momentum.focus.ui.components.ledWord
import com.momentum.focus.ui.components.ledIcon
import com.momentum.focus.ui.components.ledColor
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.util.ExportChat
import com.momentum.focus.ui.util.OnceFlags
import kotlinx.coroutines.delay

/**
 * MyAI, 2026-10-07 redesign (owner: start broken, page cramped, mode
 * switcher in a bad place, wants a premium first-time welcome).
 *
 *  - Two slim rows on top (MyAiTopBar + MyAiControlBar, ~84dp); the chat
 *    gets everything else. The old count bar, LED board, toggle row and
 *    speak row (~190dp together) are gone or folded in.
 *  - The LED sign is the greeting AND the status: an idle marquee
 *    "WELCOME, RAHUL • ASK ANY DOUBT • 7 LEFT", then THINKING / WRITING /
 *    SOLVED / RETRY while a question runs, "GURU MODE" for 2s on a switch.
 *  - MyAiWelcome plays once per install, never on a normal tab open. A
 *    normal open is just the LED booting from a dark board.
 */
@Composable
fun MyAiScreen(
    state: DoubtState,
    clock: String?,
    mode: MyAiMode,
    onMode: (MyAiMode) -> Unit,
    pulse: StudyPulse?,
    onAsk: (String, List<String>, Boolean) -> Unit,
    onRetry: () -> Unit,
    onStop: () -> Unit,
    onClose: () -> Unit,
    premium: Boolean = false,
    onPlans: () -> Unit = {},
    onMock: ((String?) -> Unit)? = null,
    name: String = "",
    aiOff: Boolean = false,
    onStartSession: (() -> Unit)? = null,
) {
    val ctx = LocalContext.current
    val str = strings()
    var welcome by remember { mutableStateOf(!OnceFlags.seen(ctx, OnceFlags.MYAI_WELCOME)) }
    var styleOpen by remember { mutableStateOf(false) }

    // "GURU MODE" on the sign for 2s after a switch. Keyed on a counter so
    // switching back and forth quickly still restarts the 2s.
    var modeFlash by remember { mutableStateOf(0) }
    var flashing by remember { mutableStateOf(false) }
    LaunchedEffect(modeFlash) {
        if (modeFlash == 0) return@LaunchedEffect
        flashing = true
        delay(2000)
        flashing = false
    }
    // SOLVED shows for 2.5s after an answer lands, then the sign goes back
    // to the gentle welcome ticker instead of shouting SOLVED forever.
    var solvedHold by remember { mutableStateOf(false) }
    LaunchedEffect(state.thread.size, state.busy) {
        if (!state.busy && state.thread.lastOrNull()?.fromUser == false) {
            solvedHold = true
            delay(2500)
        }
        solvedHold = false
    }

    val firstName = name.trim().substringBefore(' ')
    val idle = buildString {
        append(if (firstName.isNotBlank() && ledCanShow(firstName)) "WELCOME, $firstName" else "WELCOME")
        when {
            aiOff -> append(" • MYAI IS OFFLINE")
            state.left <= 0 -> append(" • 0 LEFT • STUDY TO REFILL")
            else -> {
                append(" • ASK ANY DOUBT • ")
                append(state.left)
                append(" LEFT")
            }
        }
        append(" • ")
        append(mode.ledWord())
        append(" MODE")
    }
    // The sign: status words while a question runs; otherwise the mode's
    // pixel emoji + colour (book / smiley / crown) with the welcome ticker,
    // and "GURU MODE" + crown for 2s right after a switch.
    val ledText: String
    val ledState: LedState
    val marquee: Boolean
    var signIcon: Int? = null
    var signColor: androidx.compose.ui.graphics.Color? = null
    when {
        state.error != null -> { ledText = "RETRY"; ledState = LedState.RETRY; marquee = false }
        state.busy && state.streaming.isEmpty() -> { ledText = "THINKING"; ledState = LedState.THINKING; marquee = false }
        state.busy -> { ledText = "WRITING"; ledState = LedState.WRITING; marquee = false }
        flashing -> {
            ledText = "${mode.ledWord()} MODE"; ledState = LedState.ASK; marquee = false
            signIcon = mode.ledIcon(); signColor = mode.ledColor()
        }
        solvedHold -> { ledText = "SOLVED"; ledState = LedState.SOLVED; marquee = false }
        else -> {
            ledText = idle; ledState = LedState.ASK; marquee = true
            signIcon = mode.ledIcon(); signColor = mode.ledColor()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain(),
    ) {
        // Nav-bar + keyboard inset here (the tab bar is hidden on MyAI, so
        // nobody else pads it): the Speak line was sitting under the phone's
        // back/home buttons. Consumed, so DoubtSheet's imePadding adds 0.
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .windowInsetsPadding(WindowInsets.navigationBars.union(WindowInsets.ime)),
        ) {
            MyAiTopBar(
                ledText = ledText,
                ledState = ledState,
                marquee = marquee,
                ledIcon = signIcon,
                ledColor = signColor,
                canShare = state.thread.isNotEmpty(),
                onBack = onClose,
                onShare = {
                    ExportChat.share(
                        context = ctx,
                        thread = state.thread,
                        mode = mode.labelPlain(str),
                        you = str.doubt.exportYou,
                        ai = str.doubt.exportAi,
                    )
                },
            )
            MyAiControlBar(
                mode = mode,
                premium = premium,
                onMode = { onMode(it); modeFlash++ },
                onPlans = onPlans,
                onStyle = { styleOpen = true },
            )
            Box(Modifier.fillMaxWidth().weight(1f)) {
                DoubtSheet(
                    aiOff = aiOff,
                    onStartSession = onStartSession,
                    state = state,
                    clock = clock,
                    onAsk = onAsk,
                    onRetry = onRetry,
                    onStop = onStop,
                    onClose = onClose,
                    mode = mode,
                    onMode = onMode,
                    pulse = pulse,
                    embedded = true,
                    premium = premium,
                    onPlans = onPlans,
                    onMock = onMock,
                    name = name,
                )
            }
        }

        if (styleOpen) {
            AnswerStyleSheet(
                mode = mode,
                premium = premium,
                left = state.left,
                aiOff = aiOff,
                onMode = { onMode(it); modeFlash++ },
                onPlans = onPlans,
                onClose = { styleOpen = false },
            )
        }

        AnimatedVisibility(
            visible = welcome,
            exit = fadeOut(tween(380)) + scaleOut(targetScale = 1.04f, animationSpec = tween(380)),
        ) {
            MyAiWelcome(name = firstName) {
                OnceFlags.mark(ctx, OnceFlags.MYAI_WELCOME)
                welcome = false
            }
        }
    }
}

/** Non-composable label for the export header. */
private fun MyAiMode.labelPlain(str: com.momentum.focus.ui.i18n.Strings): String = when (this) {
    MyAiMode.Study -> str.doubt.modeStudy
    MyAiMode.Friend -> str.doubt.modeFriend
    MyAiMode.Guru -> str.doubt.modeGuru
}
