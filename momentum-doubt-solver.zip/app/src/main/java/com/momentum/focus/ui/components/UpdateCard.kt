package com.momentum.focus.ui.components

import kotlinx.coroutines.launch
import com.momentum.focus.data.tr
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.geometry.Size
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.UpdateNotice
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.roundToInt

/**
 * Update card with a real install button and a real progress bar.
 *
 * The previous version was one big tappable strip with no button and no
 * feedback, so a tap anywhere started a silent download that looked like
 * nothing had happened. Here the button is the only tap target, the bar fills
 * with measured bytes, and the sound fires when the installer opens.
 */
@Composable
fun UpdateCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val haptics = rememberHaptics()

    var release by remember { mutableStateOf(Updater.cached) }
    val updScope = rememberCoroutineScope()
    // Read from the Updater, not from local state — see the note there. A tab
    // switch used to lose the download that was still running.
    val progress = Updater.progress

    // Re-attach to a download that kept running while the app was closed
    // (owner bug: notification moved, in-app bar stayed dead after restart).
    LaunchedEffect(Unit) { Updater.resume(context) }
    LaunchedEffect(Unit) {
        val found = Updater.check(context) ?: Updater.cached
        release = found
        if (found != null) UpdateNotice.show(context, found.version)
    }

    val found = release
    AnimatedVisibility(
        visible = found != null,
        enter = fadeIn() + slideInVertically { -it },
        modifier = modifier,
    ) {
        if (found == null) return@AnimatedVisibility
        val downloading = progress >= 0f
        val animated by animateFloatAsState(
            targetValue = progress.coerceAtLeast(0f),
            animationSpec = Motion.settle(),
            label = "dl",
        )

        var open by remember { mutableStateOf(false) }
        var notes by remember { mutableStateOf(found.notes) }
        LaunchedEffect(open) {
            if (open && notes.isBlank()) {
                notes = Updater.notesOrCommits().orEmpty()
            }
        }
        // Rays stay *inside* the clipped panel. Drawing them in drawBehind
        // painted a sunburst across the hero above this card.
        Box(Modifier.fillMaxWidth()) {
            // A glow spilling out from the card's own bottom edge — the
            // reference's card reads as floating just above a light source
            // rather than sitting flat on the page, which neither the
            // corner glow nor the progress-bar glow (both already here)
            // actually gave it; those live inside the card, this is the
            // one piece that was meant to live outside it.
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .offset(y = 22.dp)
                    .fillMaxWidth(0.82f)
                    .height(46.dp)
                    .blurIf(rememberCanBlur(), 26.dp)
                    .background(
                        Brush.radialGradient(
                            listOf(Tang.accent.copy(alpha = 0.55f), Color.Transparent),
                        ),
                    ),
            )
        Box(
            Modifier
                .fillMaxWidth()
                .drawBehind {
                    val d = 6.dp.toPx() * com.momentum.focus.ui.theme.Vibe.shadow
                    drawRoundRect(
                        color = Ink,
                        topLeft = Offset(d, d),
                        size = size,
                        cornerRadius = CornerRadius(
                            Paper.CardRadius.toPx(),
                            Paper.CardRadius.toPx(),
                        ),
                    )
                },
        ) {
        // A quiet corner glow that breathes, rather than the card yanking
        // attention back every time it happens to recompose — the actual
        // "again and again" fix is in UpdateNotice (it now fires once per
        // version, full stop); this is the softer, ongoing "something's
        // here" cue for as long as the update sits unactioned.
        val cornerGlow = rememberInfiniteTransition(label = "update-glow")
        val glowAlpha by cornerGlow.animateFloat(
            initialValue = 0.35f,
            targetValue = 0.85f,
            animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Reverse),
            label = "glow",
        )
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .offset(x = 20.dp, y = (-20).dp)
                .size(100.dp)
                .background(
                    Brush.radialGradient(
                        listOf(Tang.accent.copy(alpha = glowAlpha), Tang.fill.copy(alpha = glowAlpha * 0.4f), Color.Transparent),
                    ),
                    CircleShape,
                ),
        )
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(
                    Brush.verticalGradient(
                        listOf(
                            lerp(Butter.fill, Color.White, 0.30f),
                            Butter.fill,
                            lerp(Butter.fill, Color.Black, 0.06f),
                        ),
                    ),
                )
                .border(3.5.dp, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(16.dp)
        ) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Tang.fill)
                    .border(2.dp, Ink, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 3.dp),
            ) {
                Text(
                    "NEW!",
                    style = MaterialTheme.typography.labelSmall,
                    color = Tang.on,
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Version ${found.version}",
                style = MaterialTheme.typography.headlineSmall,
                color = Butter.on,
            )
            Text(
                if (open) tr("What's in this build", "इस बिल्ड में क्या आया") else tr("What's new — tap to see", "नया क्या है — टैप करके देखें"),
                style = MaterialTheme.typography.bodyMedium,
                color = Butter.on.copy(alpha = 0.8f),
                modifier = Modifier
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.tap()
                        open = !open
                    }
                    .padding(top = 2.dp, bottom = 4.dp),
            )
            AnimatedVisibility(visible = open) {
                Text(
                    notes.ifBlank { tr("• Camera / Photo now use real glyphs\n• Attach preview + 5 photos\n• Block tiles get their own silhouettes\n• Comic print stays inside the page", "• कैमरा / फ़ोटो अब असली ग्लिफ़\n• अटैच प्रीव्यू + 5 फ़ोटो\n• ब्लॉक टाइल्स के अलग आकार\n• कॉमिक प्रिंट पेज के अंदर, बाहर नहीं") },
                    style = MaterialTheme.typography.bodyMedium,
                    color = Butter.on,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
            }

            if (downloading) {
                Spacer(Modifier.height(12.dp))
                // Galactic bar (2026-10-07) — see GalaxyBar.kt.
                GalaxyBar(progress = animated)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (animated >= 1f) {
                        // The reference's morph-to-checkmark moment — a
                        // small drawn check rather than just swapping text,
                        // so the download actually finishing reads as an
                        // event and not just a label change.
                        var checkT by remember { mutableFloatStateOf(0f) }
                        LaunchedEffect(Unit) {
                            val start = withFrameNanos { it }
                            while (checkT < 1f) {
                                withFrameNanos { now ->
                                    checkT = ((now - start) / 1_000_000f / 320f).coerceIn(0f, 1f)
                                }
                            }
                        }
                        Canvas(Modifier.size(16.dp)) {
                            val w = size.width
                            val p1 = Offset(w * 0.15f, w * 0.52f)
                            val p2 = Offset(w * 0.42f, w * 0.78f)
                            val p3 = Offset(w * 0.88f, w * 0.22f)
                            val strokeW = w * 0.16f
                            if (checkT <= 0.5f) {
                                val t = checkT / 0.5f
                                drawLine(
                                    Mint.accent, p1,
                                    Offset(p1.x + (p2.x - p1.x) * t, p1.y + (p2.y - p1.y) * t),
                                    strokeWidth = strokeW, cap = StrokeCap.Round,
                                )
                            } else {
                                drawLine(Mint.accent, p1, p2, strokeWidth = strokeW, cap = StrokeCap.Round)
                                val t = (checkT - 0.5f) / 0.5f
                                drawLine(
                                    Mint.accent, p2,
                                    Offset(p2.x + (p3.x - p2.x) * t, p2.y + (p3.y - p2.y) * t),
                                    strokeWidth = strokeW, cap = StrokeCap.Round,
                                )
                            }
                        }
                        Spacer(Modifier.width(6.dp))
                    }
                    Text(
                        if (animated >= 1f) com.momentum.focus.data.tr("Opening Downloads…", "Downloads खुल रहा है…")
                        else "${(animated * 100).roundToInt()}%",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                        color = Butter.on,
                    )
                }
            } else {
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier
                        .clip(RoundedCornerShape(Paper.ChipRadius))
                        .background(Mint.fill)
                        .border(Paper.Outline, Ink, RoundedCornerShape(Paper.ChipRadius))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.confirm()
                            // Hands off to the browser. There is no progress to
                            // show any more because the download is no longer
                            // ours — the browser owns it, and it reports its own.
                            // In-app download with real progress (system
                            // DownloadManager); browser only as the fallback.
                            UpdateNotice.clear(context)
                            Sfx.play(Sound.SUCCESS)
                            updScope.launch {
                                if (!Updater.downloadInApp(context, found)) Updater.openDownload(context, found)
                            }
                        }
                        .padding(horizontal = 22.dp, vertical = 11.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "Download update",
                        style = MaterialTheme.typography.titleMedium,
                        color = Mint.on,
                    )
                }
            }
        }
        }
        }
    }
}
