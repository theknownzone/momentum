package com.momentum.focus.ui.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class Sound {
    POP, TICK, SUCCESS, ERROR, WHOOSH,
    // Cutscene.
    RISER, CRACK, BOOM, SHIMMER,
    // One per event, because two events sharing a sound is two events the ear
    // cannot tell apart. Celebrating a streak used to make the same noise as
    // logging a session, and sending a question to MyAi made the same noise as
    // both of them.
    SEND, REPLY, LEVEL, FESTIVE, SESSION, RIGHT, WRONG, UNLOCK, STREAK,
    // The events that mean something. Generic taps stay on POP and TICK — an
    // app where every tap sounds different is not expressive, it is noisy —
    // but nothing that changes the state of a session, a shield or a wallet
    // should share a noise with tapping a chip.
    BEGIN, PANIC, SHIELD_ON, SHIELD_OFF, SPEND, SLIP,
}

/**
 * UI sounds generated as raw PCM at startup instead of shipped as .wav files.
 *
 * Two reasons: no binary assets to manage, and the tones can be tuned by
 * changing a number rather than re-exporting audio. Each sound is a sine with
 * an exponential decay envelope — a decay is what separates a "pop" from a
 * "beep", since a flat envelope always sounds like a cheap alarm.
 */
object Sfx {

    private const val RATE = 44100
    private val tracks = mutableMapOf<Sound, AudioTrack>()
    private var audioManager: AudioManager? = null
    /**
     * Off unless the user turns it on.
     *
     * A tick on every tap is fine once and grating by the fiftieth. The sounds
     * stay in the build for anyone who wants them, but nobody should have to
     * find the switch to stop them.
     */
    var enabled: Boolean = false

    fun init(context: Context) {
        if (tracks.isNotEmpty()) return
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        runCatching {
            // A pure sine is thin and plasticky. Adding a quiet octave and a
            // fifth above the root gives every sound a body, the same way a
            // real object resonates instead of beeping.
            // ---- one root per sound -------------------------------------
            // Every tone here sits on a frequency nothing else uses. They were
            // built from a handful of shared chords, so nine different events
            // arrived as the same beep at slightly different lengths — which
            // is the same as having one sound and playing it nine times.
            //
            // Roots, low to high, so it is obvious at a glance that none
            // repeat: SLIP 165 · PANIC 208 · WRONG 233 · BOOM 62 · BEGIN 294 ·
            // SESSION 349 · WHOOSH noise · STREAK 494/617/1109 · REPLY 523 ·
            // SUCCESS 622/1046 · SEND 784 · POP 466 · SHIELD 175/740 ·
            // SPEND 698 · TICK 1568 · FESTIVE 831 · RIGHT 988 ·
            // LEVEL 554/880 · UNLOCK 155/740
            //
            // SUCCESS and LEVEL were rebuilt on the glass() technique (see
            // below) instead of chord() — a three-note rising chord climb
            // is the exact melodic shape of a video-game "level up" jingle,
            // which read as more gamified than this app otherwise is. Glass
            // keeps the brightness without the arcade shape.

            // A tap. Highest and quietest thing in the file, because it plays
            // more often than everything else combined.
            // ---- v2 sound pack (2026-10-03) ---------------------------------
            // The old set leaned on inharmonic bell partials and low pitch-drop
            // tones, which read as eerie on a phone speaker. v2 is one family:
            // soft harmonic plucks on a C-major pentatonic (nothing can clash),
            // a 4ms attack so nothing clicks, and a short room tail so it feels
            // like an object, not a beep. Rising = good, falling = no — never
            // a growl. Cutscene sounds (RISER/CRACK/BOOM) are unchanged.
            tracks[Sound.TICK] = build(pluck(1568f, 0.035f, decay = 95f, level = 0.05f))
            tracks[Sound.POP] = build(pluck(784f, 0.07f, decay = 48f, level = 0.10f))
            tracks[Sound.SUCCESS] = build(room(
                pluck(659f, 0.07f, decay = 30f, level = 0.16f) +
                    pluck(988f, 0.22f, decay = 16f, level = 0.17f)
            ))
            tracks[Sound.ERROR] = build(room(
                pluck(440f, 0.07f, decay = 34f, level = 0.13f) +
                    pluck(370f, 0.16f, decay = 22f, level = 0.12f)
            ))
            tracks[Sound.WHOOSH] = build(air(0.22f, level = 0.10f))

            tracks[Sound.RISER] = build(riser(1.75f))
            tracks[Sound.CRACK] = build(crack(0.16f))
            tracks[Sound.BOOM] = build(boom(1.1f))
            tracks[Sound.SHIMMER] = build(room(
                pluck(1319f, 0.06f, decay = 34f, level = 0.10f) +
                    pluck(1760f, 0.06f, decay = 30f, level = 0.10f) +
                    pluck(2093f, 0.20f, decay = 18f, level = 0.09f)
            ))

            tracks[Sound.SEND] = build(air(0.09f, level = 0.06f) + pluck(880f, 0.09f, decay = 36f, level = 0.12f))
            tracks[Sound.REPLY] = build(room(
                pluck(659f, 0.06f, decay = 34f, level = 0.12f) +
                    pluck(880f, 0.16f, decay = 22f, level = 0.13f)
            ))

            tracks[Sound.LEVEL] = build(room(
                pluck(523f, 0.07f, decay = 28f, level = 0.15f) +
                    pluck(784f, 0.07f, decay = 28f, level = 0.15f) +
                    pluck(1047f, 0.30f, decay = 12f, level = 0.17f)
            ))
            tracks[Sound.STREAK] = build(room(
                pluck(587f, 0.06f, decay = 30f, level = 0.14f) +
                    pluck(784f, 0.06f, decay = 30f, level = 0.14f) +
                    pluck(880f, 0.06f, decay = 30f, level = 0.15f) +
                    pluck(1175f, 0.32f, decay = 11f, level = 0.17f)
            ))
            tracks[Sound.FESTIVE] = build(room(
                pluck(1047f, 0.05f, decay = 40f, level = 0.12f) +
                    pluck(1319f, 0.16f, decay = 22f, level = 0.13f)
            ))
            tracks[Sound.SESSION] = build(room(
                pluck(523f, 0.08f, decay = 26f, level = 0.15f) +
                    pluck(659f, 0.08f, decay = 26f, level = 0.15f) +
                    pluck(784f, 0.08f, decay = 26f, level = 0.16f) +
                    pluck(1047f, 0.40f, decay = 9f, level = 0.18f)
            ))
            tracks[Sound.RIGHT] = build(room(pluck(1047f, 0.16f, decay = 22f, level = 0.15f)))
            tracks[Sound.WRONG] = build(
                pluck(440f, 0.06f, decay = 36f, level = 0.12f) +
                    pluck(392f, 0.12f, decay = 26f, level = 0.11f)
            )
            tracks[Sound.UNLOCK] = build(room(
                pluck(2093f, 0.02f, decay = 160f, level = 0.07f) + rest(0.03f) +
                    pluck(659f, 0.07f, decay = 28f, level = 0.15f) +
                    pluck(988f, 0.07f, decay = 26f, level = 0.15f) +
                    pluck(1319f, 0.30f, decay = 12f, level = 0.16f)
            ))

            // "Locked in": a soft air swell into a rising triad.
            tracks[Sound.BEGIN] = build(room(
                air(0.12f, level = 0.07f) +
                    pluck(523f, 0.07f, decay = 28f, level = 0.15f) +
                    pluck(659f, 0.07f, decay = 28f, level = 0.15f) +
                    pluck(784f, 0.28f, decay = 12f, level = 0.17f)
            ))
            tracks[Sound.PANIC] = build(room(
                pluck(523f, 0.08f, decay = 26f, level = 0.12f) +
                    pluck(440f, 0.20f, decay = 16f, level = 0.12f)
            ))
            tracks[Sound.SHIELD_ON] = build(room(
                pluck(587f, 0.06f, decay = 34f, level = 0.14f) +
                    pluck(880f, 0.16f, decay = 20f, level = 0.15f)
            ))
            tracks[Sound.SHIELD_OFF] = build(
                pluck(880f, 0.06f, decay = 34f, level = 0.12f) +
                    pluck(587f, 0.12f, decay = 24f, level = 0.11f)
            )
            tracks[Sound.SPEND] = build(room(
                pluck(1568f, 0.04f, decay = 60f, level = 0.10f) +
                    pluck(1175f, 0.12f, decay = 28f, level = 0.12f)
            ))
            tracks[Sound.SLIP] = build(pluck(392f, 0.14f, decay = 22f, level = 0.10f))
        }
    }

    /**
     * A sound that plays whether or not the UI-sound switch is on.
     *
     * That switch exists because a chirp on every tap is grating by the
     * fiftieth time — its own note says so. A cutscene that runs once in the
     * lifetime of an install is not what it was written to silence. The silent
     * switch is still obeyed, because that one always wins.
     */
    fun playOnce(sound: Sound) {
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val track = tracks[sound] ?: return
        runCatching {
            track.stop()
            track.reloadStaticData()
            track.play()
        }
    }

    fun play(sound: Sound) {
        if (!enabled) return
        // Respect the physical silent switch. Nothing annoys people faster than
        // an app that chirps in a library.
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val track = tracks[sound] ?: return
        runCatching {
            track.stop()
            track.reloadStaticData()
            track.play()
        }
    }

    fun release() {
        tracks.values.forEach { runCatching { it.release() } }
        tracks.clear()
    }

    // ---- synthesis --------------------------------------------------------

    /**
     * v2 voice: a soft harmonic pluck (kalimba / glass-marimba family).
     * Harmonic partials only, 4ms attack, so it is warm instead of eerie.
     */
    private fun pluck(freq: Float, seconds: Float, decay: Float, level: Float = 0.14f): ShortArray {
        val n = (RATE * seconds).toInt()
        val partials = listOf(1f to 1f, 2f to 0.32f, 3f to 0.10f, 4f to 0.04f)
        val norm = partials.sumOf { it.second.toDouble() }
        val attackN = RATE * 0.004f
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            var sum = 0.0
            partials.forEach { (ratio, weight) ->
                sum += sin(2.0 * PI * freq * ratio * t) * exp(-decay * (0.6f + 0.4f * ratio) * t) * weight
            }
            val attack = (i / attackN).coerceAtMost(1f)
            (sum / norm * attack * Short.MAX_VALUE * level).toInt().toShort()
        }
    }

    /** Soft band-limited air: smoothed noise under a raised-cosine swell. */
    private fun air(seconds: Float, level: Float = 0.08f): ShortArray {
        val n = (RATE * seconds).toInt()
        val rnd = java.util.Random(11)
        var lp = 0.0
        return ShortArray(n) { i ->
            lp += (rnd.nextGaussian() - lp) * 0.08
            val env = 0.5 - 0.5 * kotlin.math.cos(2.0 * PI * i / n)
            (lp * env * Short.MAX_VALUE * level * 2.2).toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
    }

    /** Short room tail (two early reflections) so plucks feel physical. */
    private fun room(dry: ShortArray): ShortArray {
        val tail = (RATE * 0.14f).toInt()
        val out = IntArray(dry.size + tail)
        for (i in dry.indices) out[i] = dry[i].toInt()
        val d1 = (RATE * 0.037f).toInt()
        val d2 = (RATE * 0.061f).toInt()
        for (i in out.indices) {
            if (i >= d1) out[i] += (out[i - d1] * 0.24f).toInt()
            if (i >= d2) out[i] += (out[i - d2] * 0.14f).toInt()
        }
        return ShortArray(out.size) { out[it].coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort() }
    }

    /** Root plus an octave and a fifth, mixed low so it reads as timbre. */
    private fun chord(
        freq: Float,
        seconds: Float,
        decay: Float,
        pitchDrop: Float = 0f,
    ): ShortArray {
        val root = tone(freq, seconds, decay, pitchDrop, level = 0.24f)
        val octave = tone(freq * 2f, seconds, decay * 1.4f, pitchDrop, level = 0.09f)
        val fifth = tone(freq * 1.5f, seconds, decay * 1.2f, pitchDrop, level = 0.06f)
        return ShortArray(root.size) { i ->
            (root[i] + octave[i] + fifth[i]).coerceIn(
                Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()
            ).toShort()
        }
    }

    /**
     * A struck-glass note: a fundamental with inharmonic partials above it.
     *
     * This is the difference between the app sounding cheap and sounding
     * finished, and it is not volume or length — it is harmonics. Every cue in
     * here was a single sine, and a single sine is a test tone. Nothing in the
     * physical world makes one: a struck glass, a chime, a key on a rhodes all
     * ring at a fundamental plus a stack of partials, and the ear identifies
     * "an object was struck" from the partials, not the fundamental.
     *
     * The partials are deliberately not whole-number multiples. Integer
     * harmonics give a brassy, musical tone; slightly stretched ones (2.76,
     * 5.40) are what bells and glass actually do, and are why a real chime
     * sounds like an object rather than a synthesiser.
     *
     * Each partial also decays faster than the one below it, which is what
     * happens in a struck object — the high frequencies bleed out first and the
     * fundamental hangs on. A stack that decays uniformly sounds like an organ.
     */
    private fun glass(
        freq: Float,
        seconds: Float,
        decay: Float,
        level: Float = 0.22f,
    ): ShortArray {
        val n = (RATE * seconds).toInt()
        // Partial ratio to relative loudness. The top one is quiet on purpose:
        // it is there to be heard as brightness in the first few milliseconds,
        // not as a note.
        val partials = listOf(
            1.00f to 1.00f,
            2.76f to 0.42f,
            5.40f to 0.16f,
            8.93f to 0.06f,
        )
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            var sum = 0.0
            partials.forEach { (ratio, weight) ->
                // Higher partials die sooner — ratio scales the decay.
                val env = exp(-decay * ratio * 0.55f * t)
                sum += sin(2.0 * PI * freq * ratio * t) * env * weight
            }
            // Normalised by the total weight so adding a partial does not
            // make the cue louder, only richer.
            val norm = sum / partials.sumOf { it.second.toDouble() }
            val attack = (i / 90f).coerceAtMost(1f)
            (norm * attack * Short.MAX_VALUE * level).toInt().toShort()
        }
    }

    private fun tone(
        freq: Float,
        seconds: Float,
        decay: Float,
        pitchDrop: Float = 0f,
        level: Float = 0.28f,
    ): ShortArray {
        val n = (RATE * seconds).toInt()
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            // Sliding the frequency down over the note gives the sound a body,
            // like something physical settling.
            val f = freq * (1f - pitchDrop * (i.toFloat() / n))
            val envelope = exp(-decay * t)
            // A short fade-in kills the click that a hard start produces.
            val attack = (i / 140f).coerceAtMost(1f)
            (sin(2.0 * PI * f * t) * envelope * attack * Short.MAX_VALUE * level)
                .toInt().toShort()
        }
    }

    /**
     * A climb. Frequency rises, and so does the level — the swell is what makes
     * it read as something coming rather than something leaving.
     */
    private fun riser(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(11)
        return ShortArray(n) { i ->
            val p = i.toFloat() / n
            val t = i.toFloat() / RATE
            // Curved, not linear: a straight sweep sounds like a test tone.
            val f = 110f + 700f * p * p
            val swell = p * p
            val body = sin(2.0 * PI * f * t) * 0.6
            val air = (rng.nextFloat() * 2 - 1) * 0.25f * p
            ((body + air) * swell * Short.MAX_VALUE * 0.30).toInt().toShort()
        }
    }

    /** Short, bright, ugly on purpose. Something giving way. */
    private fun crack(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(7)
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            val envelope = exp(-70f * t)
            val snap = (rng.nextFloat() * 2 - 1)
            val ring = sin(2.0 * PI * 2400f * t) * 0.4
            ((snap + ring) * envelope * Short.MAX_VALUE * 0.30).toInt().toShort()
        }
    }

    /**
     * The hit. Low sine sliding down, with a noise transient on the front.
     *
     * Phone speakers cannot reproduce 45Hz, so the fundamental is felt more
     * than heard — the octave above it is what carries on a small speaker,
     * which is why it is mixed in rather than left to chance.
     */
    private fun boom(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(3)
        return ShortArray(n) { i ->
            val p = i.toFloat() / n
            val t = i.toFloat() / RATE
            val f = 62f * (1f - 0.35f * p)
            val envelope = exp(-4.2f * t)
            val sub = sin(2.0 * PI * f * t) * 0.75
            val octave = sin(2.0 * PI * f * 2 * t) * 0.30
            val transient = (rng.nextFloat() * 2 - 1) * exp(-60f * t) * 0.5f
            ((sub + octave + transient) * envelope * Short.MAX_VALUE * 0.34)
                .toInt().toShort()
        }
    }

    private fun noise(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(4)
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            // Low-passed noise: averaging consecutive samples removes the
            // hiss and leaves the soft rush of air.
            val envelope = exp(-26f * t)
            val n = (rng.nextFloat() * 2 - 1) * 0.5f + (rng.nextFloat() * 2 - 1) * 0.5f
            (n * envelope * Short.MAX_VALUE * 0.13).toInt().toShort()
        }
    }

    private operator fun ShortArray.plus(other: ShortArray): ShortArray {
        val out = ShortArray(size + other.size)
        copyInto(out)
        other.copyInto(out, size)
        return out
    }

    /**
     * Pure silence, the missing ingredient for actual rhythm.
     *
     * Every multi-note cue in this file concatenates notes back-to-back with
     * zero gap — which is not a rhythm, it is a legato run. A real rhythmic
     * phrase needs rests between hits, the same way a drum pattern is
     * defined as much by the silence as the hit. Short rests (0.02–0.05s)
     * read as a groove; zero reads as one long blurred tone.
     */
    private fun rest(seconds: Float): ShortArray = ShortArray((RATE * seconds).toInt())

    private fun build(samples: ShortArray): AudioTrack {
        val bytes = samples.size * 2
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bytes)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(samples, 0, samples.size)
        return track
    }
}
