package com.momentum.focus.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.scale

@Composable
fun AtmosphereGlow(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "premiumAtmosphere")
    val breath by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(3600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breath"
    )
    val alpha by transition.animateFloat(
        initialValue = 0.18f,
        targetValue = 0.32f,
        animationSpec = infiniteRepeatable(
            animation = tween(3600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val center = Offset(size.width * 0.5f, size.height * 1.02f)
        scale(breath, pivot = center) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFEAF6FF).copy(alpha = alpha),
                        Color(0xFF55B7FF).copy(alpha = alpha * 0.72f),
                        Color(0xFF1976D2).copy(alpha = alpha * 0.24f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = size.minDimension * 0.72f
                ),
                center = center,
                radius = size.minDimension * 0.72f
            )
        }
    }
}