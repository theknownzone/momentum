package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.StreakLadder
import com.momentum.focus.ui.components.StreakWeekRow
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.i18n.Lang
import com.momentum.focus.ui.i18n.strings

/** A real destination for streaks; the old app buried the only streak view in Profile. */
@Composable
fun StreakScreen(data: AppData) {
    val str = strings()
    val current = data.streakDays
    val title = if (str.lang == Lang.HI) "Tumhari streak" else "Your streak"
    val subtitle = if (str.lang == Lang.HI)
        "Consistency completed focus days se measure hoti hai, app open karne se nahi."
    else
        "Consistency is measured in completed focus days, not app opens."
    val best = maxOf(data.bestStreak, current)
    val next = listOf(7, 14, 30, 60, 90).firstOrNull { it > current }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        Text(str.success.streakLabel, style = MaterialTheme.typography.labelSmall, color = Mint.on)
        Text(title, style = MaterialTheme.typography.displayMedium, color = Ink)
        Text(
            subtitle,
            style = MaterialTheme.typography.bodyLarge,
            color = InkMid,
            modifier = Modifier.padding(top = 6.dp),
        )

        Spacer(Modifier.height(18.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            Metric("CURRENT", "$current ${str.success.streakDays}", Mint.fill, Modifier.weight(1f))
            Metric("BEST", "$best ${str.success.streakDays}", Tang.fill, Modifier.weight(1f))
        }

        Spacer(Modifier.height(Paper.Gap))
        StreakWeekRow(data, Modifier.fillMaxWidth())
        Spacer(Modifier.height(Paper.Gap))
        StreakLadder(data, Modifier.fillMaxWidth())

        if (next != null) {
            Spacer(Modifier.height(12.dp))
            Text(
                str.success.toNextRung(next - current, next),
                style = MaterialTheme.typography.bodyMedium,
                color = InkMid,
            )
        } else {
            Spacer(Modifier.height(12.dp))
            Text(if (str.lang == Lang.HI) "90 din ka milestone ho gaya. Streak ko alive rakho." else "90-day milestone reached. Keep the chain alive.", style = MaterialTheme.typography.bodyMedium, color = InkMid)
        }
    }
}

@Composable
private fun Metric(label: String, value: String, fill: Color, modifier: Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(
                Brush.linearGradient(listOf(fill.copy(alpha = 0.30f), CreamCard))
            )
            .padding(16.dp),
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = InkMid)
        Text(value, style = MaterialTheme.typography.headlineSmall, color = Ink)
    }
}
