package com.momentum.focus.ui.components

import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Paper

/**
 * A section of settings that stays shut until it is asked for.
 *
 * The Profile screen's real problem was never which control sat in which
 * group — it was that every control was open at once, so a screen with four
 * concerns read as one undifferentiated scroll. Closing three of the four is
 * the only change that actually shortens it.
 *
 * The glass is faked the same way [FrostCard] fakes it: layered translucent
 * washes plus a bright sweep, never `Modifier.blur`. Blur is API 31+ and this
 * app ships to API 26, where it silently does nothing — a real blur here would
 * look like glass on a new phone and like flat grey on an old one.
 */
/**
 * The same frosted surface as [GlassSection] without the header or the drawer.
 *
 * Light glass, not dark: the references for this are panels sitting on a pale
 * background with a bright top edge and a faint colour bleed, which is what
 * cream paper can actually carry. A dark glass panel on cream would just be a
 * hole in the page.
 */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(Paper.CardRadius)
    Column(
        modifier
            .clip(shape)
            .background(CreamCard)
            .background(tint.copy(alpha = 0.22f))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.55f),
                        Color.White.copy(alpha = 0.04f),
                        Color.White.copy(alpha = 0.16f),
                    )
                )
            )
            // The bright top edge is what makes a flat panel read as glass —
            // it is the highlight where a real pane would catch the light.
            .drawWithContent {
                drawContent()
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.65f), Color.Transparent),
                        endY = 6.dp.toPx(),
                    ),
                    size = androidx.compose.ui.geometry.Size(size.width, 6.dp.toPx()),
                )
            }
            .border(Paper.Outline, Ink, shape),
        content = content,
    )
}

@Composable
fun GlassSection(
    title: String,
    note: String,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    initiallyOpen: Boolean = false,
    /** v4: stagger slot (0,1,2…) — each section rises in 80ms after the last. */
    index: Int = 0,
    /** v4: optional icon in a sticker chip before the title. */
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    var entered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(180L + index * 80L); entered = true }
    val rise by animateFloatAsState(if (entered) 1f else 0f, androidx.compose.animation.core.tween(280, easing = androidx.compose.animation.core.FastOutSlowInEasing), label = "secRise")
    // v3: neo-brutal block — hard ink shadow, tinted header strip, chevron that
    // turns over 220ms, body that unfolds instead of popping in. The header
    // presses into its shadow like every other button in the app.
    var open by rememberSaveable(title) { mutableStateOf(initiallyOpen) }
    val turn by animateFloatAsState(if (open) 90f else 0f, androidx.compose.animation.core.tween(220), label = "chevron")
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val p by animateFloatAsState(if (pressed) 1f else 0f, androidx.compose.animation.core.tween(110), label = "secPress")
    val shape = RoundedCornerShape(Paper.CardRadius)

    Column(
        modifier
            .fillMaxWidth()
            .padding(top = 16.dp, end = 5.dp)
            .graphicsLayer { alpha = rise; translationY = (1f - rise) * 22.dp.toPx() }
            .drawBehind {
                val d = 5.dp.toPx() * (1f - p)
                drawRoundRect(
                    Ink,
                    topLeft = androidx.compose.ui.geometry.Offset(d + 5.dp.toPx() * p, d + 5.dp.toPx() * p),
                    size = size,
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(Paper.CardRadius.toPx()),
                )
            }
            .graphicsLayer { translationX = 5.dp.toPx() * p; translationY = 5.dp.toPx() * p }
            .clip(shape)
            .background(CreamCard)
            .border(Paper.Outline, Ink, shape),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(tint.copy(alpha = if (open) 0.55f else 0.30f))
                .clickableNoRipple(interaction) { open = !open }
                .padding(horizontal = 16.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (icon != null) {
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(tint)
                        .border(2.dp, Ink, RoundedCornerShape(11.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    androidx.compose.material3.Icon(icon, contentDescription = null, tint = Ink, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    title.uppercase(),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                    color = Ink,
                )
                Text(note, style = MaterialTheme.typography.bodyMedium, color = Ink.copy(alpha = 0.65f))
            }
            Box(
                Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(if (open) Ink else CreamCard)
                    .border(2.dp, Ink, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "\u203A",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                    color = if (open) CreamCard else Ink,
                    modifier = Modifier.rotate(turn),
                )
            }
        }
        androidx.compose.animation.AnimatedVisibility(
            visible = open,
            enter = androidx.compose.animation.expandVertically(androidx.compose.animation.core.tween(240)) +
                androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(200)),
            exit = androidx.compose.animation.shrinkVertically(androidx.compose.animation.core.tween(200)) +
                androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(150)),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .drawBehind { drawLine(Ink, androidx.compose.ui.geometry.Offset(0f, 0f), androidx.compose.ui.geometry.Offset(size.width, 0f), 2.dp.toPx()) }
                    .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 18.dp),
                content = content,
            )
        }
    }
}

/**
 * v5 back button for full-screen pages: brutal round pill with an arrow,
 * presses into its shadow. Top-left, thumb-reachable, consistent everywhere.
 */
@Composable
fun BackPill(onBack: () -> Unit, modifier: Modifier = Modifier) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val p by animateFloatAsState(if (pressed) 1f else 0f, androidx.compose.animation.core.tween(110), label = "backPill")
    Box(
        modifier
            .size(44.dp)
            .drawBehind {
                val d = 3.dp.toPx() * (1f - p)
                drawCircle(Ink, size.minDimension / 2, center + androidx.compose.ui.geometry.Offset(d + 3.dp.toPx() * p, d + 3.dp.toPx() * p))
            }
            .graphicsLayer { translationX = 3.dp.toPx() * p; translationY = 3.dp.toPx() * p }
            .clip(CircleShape)
            .background(CreamCard)
            .border(2.5.dp, Ink, CircleShape)
            .clickableNoRipple(src) { onBack() },
        contentAlignment = Alignment.Center,
    ) {
        androidx.compose.material3.Icon(
            androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = com.momentum.focus.data.tr("Back", "वापस"),
            tint = Ink,
            modifier = Modifier.size(22.dp),
        )
    }
}
