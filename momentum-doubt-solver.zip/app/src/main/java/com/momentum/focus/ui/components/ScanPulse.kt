package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Candy
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.LocalSkin
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import kotlin.math.cos
import kotlin.math.sin

/**
 * Lightweight AI thinking indicator. The reference choreography uses a small
 * dotted field that breathes and shifts colour, not a giant glowing orb. One
 * animation clock drives the whole canvas to keep CPU/GPU work predictable.
 *
 * Second pass adds depth a flat dot grid didn't have: an ambient glow behind
 * the field so it reads as a light source rather than a sticker, colour that
 * travels across the dots instead of sitting fixed per-position, a slow
 * wobble so the cluster never looks frozen between breaths, and a three-point
 * comet tail on the scanning highlight instead of one blob. Still one shared
 * clock and a fixed dot count, so the frame cost barely moves.
 */
@Composable
fun ScanPulse(label: String, modifier: Modifier = Modifier) {
    val accent = LocalSkin.current.accent
    val transition = rememberInfiniteTransition(label = "aiDots")
    val phase = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing)),
        label = "aiDotsPhase",
    )
    val breath = transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "aiDotsBreath",
    )
    // Colour travel and the wobble each get their own slow clock — tying them
    // to `phase` (1800ms) made every visual change land on the same beat as
    // the dot pulse, which reads as one thing blinking rather than several
    // things quietly alive at once.
    val drift = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(5200, easing = LinearEasing)),
        label = "aiDotsDrift",
    )
    val wobble = transition.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3400), RepeatMode.Reverse),
        label = "aiDotsWobble",
    )

    Column(
        modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(112.dp)) {
            Canvas(Modifier.matchParentSize()) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val unit = size.minDimension / 10f
                val p = phase.value
                val b = breath.value
                val colors = listOf(accent, Sky.fill, Lilac.fill, Candy.fill, GoldNeon, Mint.fill)

                // Ambient wash behind the whole cluster. Without this the
                // dots sat on flat card colour and read as a sticker; one
                // soft radial pass behind them makes the field itself look
                // like the thing giving off light.
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(accent.copy(alpha = 0.16f * b), Color.Transparent),
                        radius = unit * 4.6f,
                        center = Offset(cx, cy),
                    ),
                    radius = unit * 4.6f,
                    center = Offset(cx, cy),
                )

                // A couple of degrees of drift, not a spin — enough that the
                // cluster never looks pinned in place between breaths, not so
                // much it reads as a loading wheel.
                rotate(degrees = wobble.value * 3.5f, pivot = Offset(cx, cy)) {
                    // 7x7 dotted core. Each dot has a tiny phase offset so the
                    // field feels fluid without drawing rings/blur every frame.
                    for (row in -3..3) {
                        for (col in -3..3) {
                            val d = kotlin.math.sqrt((row * row + col * col).toFloat())
                            val falloff = (1f - d / 5f).coerceIn(0f, 1f)
                            if (falloff <= 0f) continue
                            val local = (p + (row + col + 6) * 0.045f) % 1f
                            val pulse = 0.55f + 0.45f * sin(local * 6.2831853f)
                            val r = (1.6f + 2.0f * falloff * b * (0.72f + 0.28f * pulse))
                            val x = cx + col * unit * 0.82f
                            val y = cy + row * unit * 0.82f
                            // Colour now travels across the grid instead of
                            // sitting fixed per cell — `shift` is continuous,
                            // so a dot cross-fades to the next hue rather than
                            // jump-cutting to it.
                            val shift = drift.value * colors.size + (row - col + 12)
                            val i0 = shift.toInt()
                            val f = shift - i0
                            val c = lerp(
                                colors[Math.floorMod(i0, colors.size)],
                                colors[Math.floorMod(i0 + 1, colors.size)],
                                f,
                            )
                            drawCircle(c.copy(alpha = 0.22f + 0.58f * falloff), r, Offset(x, y))
                        }
                    }
                }

                // A moving highlight gives the cluster the same scanning
                // character as the reference without a full-screen sweep. A
                // short three-point tail behind the head reads as something
                // sweeping through the field rather than a blob teleporting
                // around it.
                repeat(3) { k ->
                    val trailP = ((p - k * 0.05f) % 1f + 1f) % 1f
                    val ta = trailP * 6.2831853f
                    val hx = cx + cos(ta) * unit * 2.5f
                    val hy = cy + sin(ta * 1.3f) * unit * 2.5f
                    val fade = 1f - k * 0.34f
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(
                                Color.White.copy(alpha = 0.78f * fade),
                                accent.copy(alpha = 0.30f * fade),
                                Color.Transparent,
                            ),
                            radius = unit * (2.2f - k * 0.35f),
                            center = Offset(hx, hy),
                        ),
                        radius = unit * (2.2f - k * 0.35f),
                        center = Offset(hx, hy),
                    )
                }
            }
        }
        Spacer(Modifier.height(2.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}
