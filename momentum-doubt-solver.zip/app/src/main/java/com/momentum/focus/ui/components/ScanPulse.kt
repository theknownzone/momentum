package com.momentum.focus.ui.components

import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.InkMid
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * The AI thinking indicator — breathing fluid rings, a rotating aura and a
 * bright core, the same source given directly for the orb reveal, sized
 * down for inline use. Carried over as given; only the package line changed
 * and a [label] parameter was put back around it, because every call site
 * of this (the doubt sheet's "Thinking…", the mock builder's "Building…")
 * passes one and reads it printed underneath — dropping that parameter
 * would have meant going and rewriting both of those call sites instead of
 * this one.
 */
@Composable
fun ScanPulse(label: String, modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "scan")

    val pulse by infinite.animateFloat(
        initialValue = 0.72f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1700, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulse",
    )

    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(7000, easing = LinearEasing),
        ),
        label = "rotation",
    )

    Column(
        modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Canvas(
            modifier = Modifier.size(112.dp),
        ) {
            val cx = size.width / 2f
            val cy = size.height / 2f

            val base = min(size.width, size.height) * 0.12f

            // Breathing fluid rings
            repeat(4) { i ->
                val r =
                    base * (1.4f + i * 0.32f) * pulse

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0x443F8CFF),
                            Color.Transparent,
                        ),
                        center = Offset(cx, cy),
                        radius = r,
                    ),
                    radius = r,
                    center = Offset(cx, cy),
                    alpha = 0.30f - i * 0.05f,
                )
            }

            // Rotating aura
            repeat(6) { i ->
                val angle =
                    rotation * PI.toFloat() / 180f +
                        i * PI.toFloat() / 3f

                val r = base * 1.8f * pulse

                val x = cx + cos(angle) * r
                val y = cy + sin(angle) * r

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0x886EA8FF),
                            Color.Transparent,
                        ),
                        center = Offset(x, y),
                        radius = base * 0.45f,
                    ),
                    radius = base * 0.45f,
                    center = Offset(x, y),
                )
            }

            // Core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFE8F2FF),
                        Color(0xFF6EA8FF),
                        Color(0xFF304BFF),
                        Color.Transparent,
                    ),
                ),
                radius = base * 0.48f,
                center = Offset(cx, cy),
            )
        }
        Spacer(Modifier.height(2.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}
