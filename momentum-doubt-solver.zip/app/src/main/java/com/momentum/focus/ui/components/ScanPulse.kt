package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.LocalSkin
import kotlin.math.cos
import kotlin.math.sin

/**
 * AI waiting state inspired by modern food/assistant search surfaces.
 *
 * This is deliberately not a spinner or a generic three-dot loader. The centre
 * is a four-point sparkle, with a soft halo, expanding rings and small orbiting
 * glyph-dots. The animation is continuous but restrained: the user can tell
 * that the request is alive without staring at a progress indicator.
 */
@Composable
fun ScanPulse(
    label: String,
    modifier: Modifier = Modifier,
) {
    val accent = LocalSkin.current.accent
    val transition = rememberInfiniteTransition(label = "aiSearch")
    val phase = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "phase",
    )
    val breathe = transition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            tween(900, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "breathe",
    )
    val spin = transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(5200, easing = LinearEasing)),
        label = "spin",
    )

    Column(
        modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier
                .size(138.dp)
                .drawBehind {
                    val centre = Offset(size.width / 2f, size.height / 2f)
                    val min = size.minDimension
                    val t = phase.value
                    val breathScale = breathe.value

                    // Soft pooled light behind the glyph.
                    drawCircle(
                        brush = Brush.radialGradient(
                            colorStops = arrayOf(
                                0f to accent.copy(alpha = 0.30f),
                                0.38f to accent.copy(alpha = 0.13f),
                                1f to Color.Transparent,
                            ),
                            center = centre,
                            radius = min * 0.48f * breathScale,
                        ),
                        radius = min * 0.48f * breathScale,
                        center = centre,
                    )

                    // Two expanding rings. They reset softly instead of
                    // snapping, giving the same "search is alive" impression as
                    // a radar/glow treatment.
                    repeat(2) { ring ->
                        val local = (t + ring * 0.5f) % 1f
                        val radius = min * (0.22f + local * 0.31f)
                        val alpha = (1f - local) * 0.26f
                        drawCircle(
                            color = accent.copy(alpha = alpha),
                            radius = radius,
                            center = centre,
                            style = Stroke(width = 1.5.dp.toPx()),
                        )
                    }

                    // Four-point sparkle. The points stretch and contract with
                    // the same breath as the halo, so it feels like one object.
                    val star = Path()
                    val outer = min * 0.20f * breathScale
                    val inner = outer * 0.16f
                    for (i in 0 until 8) {
                        val r = if (i % 2 == 0) outer else inner
                        val a = (-90.0 + i * 45.0) * Math.PI / 180.0
                        val x = centre.x + cos(a).toFloat() * r
                        val y = centre.y + sin(a).toFloat() * r
                        if (i == 0) star.moveTo(x, y) else star.lineTo(x, y)
                    }
                    star.close()
                    drawPath(star, color = Color.White.copy(alpha = 0.98f))
                    drawPath(
                        star,
                        color = accent.copy(alpha = 0.85f),
                        style = Stroke(width = 1.8.dp.toPx()),
                    )

                    // Small orbiting particles. Their angular speed is slightly
                    // different from the outer rings, which prevents the whole
                    // scene from looking like one rigid rotating wheel.
                    rotate(spin.value, pivot = centre) {
                        val radii = floatArrayOf(0.34f, 0.43f, 0.39f, 0.46f, 0.32f, 0.44f)
                        val angles = floatArrayOf(0f, 58f, 126f, 194f, 248f, 316f)
                        radii.forEachIndexed { i, radiusFrac ->
                            val a = Math.toRadians(angles[i].toDouble())
                            val x = centre.x + cos(a).toFloat() * min * radiusFrac
                            val y = centre.y + sin(a).toFloat() * min * radiusFrac
                            val pulse = 0.45f + 0.45f * ((sin((t * 6f + i) * Math.PI * 2).toFloat() + 1f) / 2f)
                            val dot = (if (i % 3 == 0) 4.2f else 3.0f) * pulse
                            drawCircle(
                                color = accent.copy(alpha = 0.24f + 0.55f * pulse),
                                radius = dot,
                                center = Offset(x, y),
                            )
                        }
                    }

                    // Tiny four-corner glints, deliberately sparse.
                    val glint = min * 0.43f
                    listOf(0f, 90f, 180f, 270f).forEachIndexed { i, angle ->
                        val a = Math.toRadians((angle + spin.value * 0.22f).toDouble())
                        val x = centre.x + cos(a).toFloat() * glint
                        val y = centre.y + sin(a).toFloat() * glint
                        drawCircle(
                            color = Color.White.copy(alpha = 0.30f + 0.22f * ((i + 1) % 2)),
                            radius = 1.8.dp.toPx(),
                            center = Offset(x, y),
                        )
                    }
                },
        )
        Spacer(Modifier.height(4.dp))
        Text(
            label,
            fontSize = 14.sp,
            color = LocalSkin.current.onSurfaceVariant,
        )
    }
}
