package com.momentum.focus.ui.components

import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.InkMid
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * The AI thinking indicator — breathing fluid rings, a rotating aura and a
 * bright core. Every colour here was pushed further toward a saturated
 * iOS-style blue (was translucent enough to read as grey-blue on a small
 * phone screen) and the whole canvas sits on a genuine [blur] glow behind
 * it now, not just soft-edged radial gradients doing all the work — the
 * same "real glass, not just a gradient standing in for it" fix already
 * applied to the Plans cards, here on the one piece of this screen that
 * runs every single time a question is asked, not just once.
 */
@Composable
fun ScanPulse(label: String, modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "scan")

    val pulse by infinite.animateFloat(
        initialValue = 0.72f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1700, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulse",
    )

    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(7000, easing = LinearEasing),
        ),
        label = "rotation",
    )

    Column(
        modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(contentAlignment = Alignment.Center) {
            // A soft, genuinely blurred glow sitting behind the sharp
            // canvas — real RenderEffect blur (API 31+, silent no-op below
            // that, same rule as everywhere else this is used), not another
            // radial gradient layer standing in for one.
            Canvas(
                modifier = Modifier.size(130.dp).blur(22.dp),
            ) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF6EA8FF).copy(alpha = 0.55f * pulse),
                            Color(0xFF3F6BFF).copy(alpha = 0.30f * pulse),
                            Color.Transparent,
                        ),
                        center = Offset(cx, cy),
                    ),
                    radius = size.minDimension * 0.42f,
                    center = Offset(cx, cy),
                )
            }
            Canvas(
                modifier = Modifier.size(112.dp),
            ) {
            val cx = size.width / 2f
            val cy = size.height / 2f

            val base = min(size.width, size.height) * 0.12f

            // Breathing fluid rings — deeper, more saturated blue than
            // before (0x44 alpha grey-blue read as almost nothing on a
            // bright screen; this is closer to what an iOS activity glow
            // actually looks like).
            repeat(4) { i ->
                val r =
                    base * (1.4f + i * 0.32f) * pulse

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF5B8DFF).copy(alpha = 0.55f),
                            Color.Transparent,
                        ),
                        center = Offset(cx, cy),
                        radius = r,
                    ),
                    radius = r,
                    center = Offset(cx, cy),
                    alpha = 0.40f - i * 0.06f,
                )
            }

            // Rotating aura
            repeat(6) { i ->
                val angle =
                    rotation * PI.toFloat() / 180f +
                        i * PI.toFloat() / 3f

                val r = base * 1.8f * pulse

                val x = cx + cos(angle) * r
                val y = cy + sin(angle) * r

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF8FC1FF).copy(alpha = 0.85f),
                            Color.Transparent,
                        ),
                        center = Offset(x, y),
                        radius = base * 0.50f,
                    ),
                    radius = base * 0.50f,
                    center = Offset(x, y),
                )
            }

            // Core — brighter white-hot centre, richer blue falloff.
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFF3F8FF),
                        Color(0xFF8FC1FF),
                        Color(0xFF3F6BFF),
                        Color(0xFF1E3AFF).copy(alpha = 0.4f),
                        Color.Transparent,
                    ),
                ),
                radius = base * 0.52f,
                center = Offset(cx, cy),
            )
        }
        }
        Spacer(Modifier.height(2.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}
