package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/**
 * The orbit-plus-colour-shift half of the Uiverse "plasma loader" idea,
 * without the SVG gooey-merge half — that half needs a contrast-threshold
 * filter this platform has no cheap equivalent for below API 33, so rather
 * than ship something that only looks right on the newest phones, this
 * keeps the part that was ~90% confident to match everywhere: four blobs
 * orbiting a centre point, each a soft-edged radial gradient (not a hard
 * circle plus a blur effect, which would need RenderEffect and silently do
 * nothing below API 31 — a gradient fades in software on every device this
 * app supports, all the way back to the API 26 floor), tinted through a
 * slow warm colour cycle in place of CSS's hue-rotate.
 *
 * Drop this in wherever MyAI's "thinking" state ends up living — there
 * isn't a live chat-message loop in this codebase yet for it to sit in.
 */
@Composable
fun PlasmaOrbitLoader(modifier: Modifier = Modifier, size: Dp = 56.dp) {
    val transition = rememberInfiniteTransition(label = "plasma")
    val orbitAngle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2000, easing = LinearEasing)),
        label = "orbit",
    )
    // Stands in for CSS's hue-rotate: eases back and forth between two warm
    // tones rather than sweeping the full colour wheel, which suits a small
    // loader better than a rainbow would.
    val colorT by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2250, easing = LinearEasing), RepeatMode.Reverse),
        label = "colour",
    )
    val amber = Color(0xFFFFBF48)
    val rust = Color(0xFFBE4A1D)
    val tone = lerp(amber, rust, colorT)

    data class Blob(val radiusFraction: Float, val sizeFraction: Float, val speed: Float, val phase: Float)
    val blobs = remember {
        listOf(
            Blob(0.16f, 0.62f, 1f, 0f),
            Blob(0.24f, 0.42f, -1.35f, 90f),
            Blob(0.20f, 0.34f, 1.15f, 200f),
            Blob(0.30f, 0.30f, -0.9f, 300f),
        )
    }

    Canvas(modifier.size(size)) {
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        blobs.forEach { blob ->
            val angle = Math.toRadians((orbitAngle * blob.speed + blob.phase).toDouble())
            val orbitRadiusPx = this.size.minDimension * blob.radiusFraction
            val bx = cx + cos(angle).toFloat() * orbitRadiusPx
            val by = cy + sin(angle).toFloat() * orbitRadiusPx
            val blobRadiusPx = this.size.minDimension * blob.sizeFraction / 2f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(tone.copy(alpha = 0.9f), tone.copy(alpha = 0f)),
                    center = Offset(bx, by),
                    radius = blobRadiusPx,
                ),
                radius = blobRadiusPx,
                center = Offset(bx, by),
            )
        }
    }
}
