package com.momentum.focus.ui.components

import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.Sfx
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import com.momentum.focus.ui.components.clickableNoRipple
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.util.PrintSound
import com.momentum.focus.ui.util.Receipt
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * A deliberately long 20-second premium unlock sequence.
 *
 * This is not a generic "premium" splash. It behaves like a tiny product
 * reveal: boot -> calibrate -> print -> colour pass -> verify -> settle.
 * The receipt is physically fed out while a scan beam and printer indicators
 * track the same playhead. The result is longer, but every second has a job.
 */
private const val RUN_MS = 20_000L
private const val FEED_START = 0.15f
private const val FEED_END = 0.62f

@Composable
fun UnlockReceipt(data: AppData, onDone: () -> Unit) {
    // v5 (2026-10-03): ~4s print ceremony that matches the saved PNG — a dark
    // green-lit scene, a printer that feeds a torn notebook note out of a
    // glowing slot, a tear-off snap, the check badge stamping with a ring
    // burst and confetti, handwritten notes writing themselves in. One clock,
    // every beat with sound + haptic, tap to skip. The PNG is saved to
    // Downloads in the background as before.
    val haptics = rememberHaptics()
    val context = LocalContext.current
    var saved by remember { mutableStateOf<String?>(null) }
    var t by remember { mutableFloatStateOf(0f) }
    var skipped by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }
    val end = 4200f
    fun finish() { if (!done) { done = true; PrintSound.stop(); onDone() } }

    LaunchedEffect(Unit) {
        PrintSound.init(context)
        launch { saved = Receipt.saveToDownloads(context, data) }
        val st = withFrameNanos { it }
        while (t < end && !skipped) withFrameNanos { now -> if (!skipped) t = (now - st) / 1_000_000f }
    }
    DisposableEffect(Unit) { onDispose { PrintSound.stop() } }
    BackHandler { finish() }

    val fired = remember { mutableSetOf<Int>() }
    SideEffect {
        fun beat(id: Int, at: Float, fn: () -> Unit) { if (t >= at && fired.add(id) && !skipped) fn() }
        beat(1, 250f) { haptics.unlock() }
        beat(2, 450f) { PrintSound.play(loop = true) }
        for (i in 0 until 6) beat(10 + i, 600f + i * 260f) { haptics.tick() }
        beat(3, 2150f) { PrintSound.stop(); Sfx.playOnce(Sound.CRACK); haptics.press() }
        beat(4, 2450f) { Sfx.play(Sound.SUCCESS); haptics.confirm() }
        beat(5, 3000f) { Sfx.play(Sound.SHIMMER) }
    }

    fun seg(a: Float, d: Float) = ((t - a) / d).coerceIn(0f, 1f)
    val ease = FastOutSlowInEasing
    val sceneIn = seg(0f, 400f)
    val feed = ease.transform(seg(450f, 1700f))          // paper out of the slot
    val tear = seg(2150f, 380f)                           // snap + drop
    val stamp = seg(2400f, 300f)
    val burst = seg(2400f, 1300f)
    val write = seg(2950f, 650f)
    val ctaIn = ease.transform(seg(3500f, 400f))
    val green = Color(0xFF2EE07A)
    val led by rememberInfiniteTransition(label = "led").animateFloat(0.3f, 1f, infiniteRepeatable(tween(260), RepeatMode.Reverse), label = "ledT")

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF070A08))
            .pointerInput(Unit) { detectTapGestures { if (t < end) { skipped = true; t = end; PrintSound.stop() } } }
            .graphicsLayer { alpha = sceneIn },
    ) {
        // green bloom that swells when the badge lands
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2, size.height * 0.36f)
            drawCircle(Brush.radialGradient(listOf(green.copy(alpha = 0.18f + 0.22f * stamp), Color.Transparent), c, size.width * 0.9f), size.width * 0.9f, c)
        }
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 26.dp).padding(top = 18.dp, bottom = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // ---- the printer
            Box(
                Modifier
                    .fillMaxWidth(0.88f)
                    .height(54.dp)
                    .graphicsLayer { translationY = -tear * 4.dp.toPx() }
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF26302A), Color(0xFF111613))))
                    .border(1.5.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp)),
            ) {
                Row(Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 14.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(green.copy(alpha = if (feed in 0.01f..0.99f) led else 0.9f)))
                    Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFFFFC94D).copy(alpha = 0.7f)))
                }
                // glowing slot
                Box(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp).fillMaxWidth(0.82f).height(6.dp)
                        .clip(RoundedCornerShape(3.dp)).background(Color.Black)
                        .drawBehind { drawRect(green.copy(alpha = if (feed in 0.01f..0.99f) 0.35f * led else 0.1f)) },
                )
            }
            // ---- the note feeding out of the slot
            BoxWithConstraints(Modifier.fillMaxWidth(0.80f).height(420.dp)) {
                val noteH = maxHeight - 20.dp
                val shown = noteH * feed
                val sway = if (feed in 0.01f..0.99f) kotlin.math.sin(t / 140f) * 1.2f else 0f
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(noteH)
                        .graphicsLayer {
                            // feed: slide down from behind the slot, clipped to what has printed
                            translationY = (shown - noteH).toPx() + tear * 18.dp.toPx()
                            rotationZ = sway - 2.2f * tear
                            clip = false
                        }
                        .drawWithContent {
                            clipRect(top = size.height - shown.toPx() - 1f) { this@drawWithContent.drawContent() }
                        },
                ) {
                    ReceiptNote(data, stamp = stamp, burst = burst)
                }
            }
            Spacer(Modifier.height(10.dp))
            // ---- handwriting
            Text(
                com.momentum.focus.data.tr("Focus, banked ♡", "फ़ोकस, जमा ♡"),
                fontFamily = FontFamily.Cursive, fontSize = 30.sp, color = green,
                modifier = Modifier
                    .graphicsLayer { rotationZ = -5f }
                    .drawWithContent { clipRect(right = size.width * write) { this@drawWithContent.drawContent() } },
            )
            Spacer(Modifier.weight(1f))
            Column(Modifier.graphicsLayer { alpha = ctaIn; translationY = (1f - ctaIn) * 18.dp.toPx() }, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (saved != null) com.momentum.focus.data.tr("Saved to Downloads · keep this key", "Downloads में सेव · यह की संभालें")
                    else com.momentum.focus.data.tr("Saving your receipt…", "रसीद सेव हो रही है…"),
                    fontSize = 12.sp, color = Color.White.copy(alpha = 0.55f),
                )
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier
                        .width(220.dp).height(54.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(Brush.verticalGradient(listOf(Color(0xFF173A24), Color(0xFF0C1D12))))
                        .border(1.5.dp, green.copy(alpha = 0.7f), RoundedCornerShape(999.dp))
                        .drawBehind { drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.Transparent), endY = size.height * 0.5f)) }
                        .clickableNoRipple(remember { MutableInteractionSource() }) { if (ctaIn > 0.5f) { haptics.confirm(); finish() } },
                    contentAlignment = Alignment.Center,
                ) { Text(com.momentum.focus.data.tr("Done  →", "हो गया  →"), fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White) }
            }
        }
        // confetti burst from the badge
        if (burst in 0.001f..0.999f) {
            Canvas(Modifier.fillMaxSize()) {
                val o = Offset(size.width / 2, size.height * 0.30f)
                for (i in 0 until 30) {
                    val a = (i * 137.5f) * (Math.PI.toFloat() / 180f)
                    val v = (0.6f + (i % 5) * 0.18f) * size.width * 0.55f
                    val x = o.x + kotlin.math.cos(a) * v * burst
                    val y = o.y + kotlin.math.sin(a) * v * burst * 0.8f + size.height * 0.5f * burst * burst
                    val fw = (8f + (i % 4) * 5f).dp.toPx(); val fh = fw * 0.42f
                    rotate(i * 47f + burst * 720f, Offset(x, y)) {
                        drawRoundRect(green.copy(alpha = (1f - burst) * if (i % 6 == 0) 0.35f else 0.9f), Offset(x - fw / 2, y - fh / 2), androidx.compose.ui.geometry.Size(fw, fh), CornerRadius(2.dp.toPx()))
                    }
                }
            }
        }
        if (t < end) Text(
            com.momentum.focus.data.tr("tap to skip", "छोड़ने के लिए टैप करें"),
            fontSize = 9.sp, color = Color.White.copy(alpha = 0.3f),
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 2.dp),
        )
    }
}

/** On-screen twin of the saved PNG note. */
@Composable
private fun ReceiptNote(data: AppData, stamp: Float, burst: Float) {
    val green = Color(0xFF2EE07A)
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val torn = androidx.compose.ui.graphics.Path().apply {
                moveTo(0f, 0f); lineTo(size.width, 0f); lineTo(size.width, size.height - 10.dp.toPx())
                var x = size.width; var k = 0
                while (x > 0f) { x -= (5 + (k * 7) % 6).dp.toPx(); lineTo(maxOf(x, 0f), size.height - ((k * 13) % 9).dp.toPx()); k++ }
                close()
            }
            drawPath(torn, Brush.linearGradient(listOf(Color(0xFFF4F1EA), Color(0xFFE2DDD0)), Offset.Zero, Offset(size.width, size.height)))
            // punch holes
            var hx = 18.dp.toPx()
            while (hx < size.width - 10.dp.toPx()) { drawCircle(Color(0xFF070A08), 5.5.dp.toPx(), Offset(hx, 14.dp.toPx())); hx += 26.dp.toPx() }
            // dashed rule
            var x = 20.dp.toPx(); val y = size.height * 0.80f
            while (x < size.width - 20.dp.toPx()) { drawLine(Color(0xFF555555), Offset(x, y), Offset(x + 9.dp.toPx(), y), 1.5.dp.toPx()); x += 14.dp.toPx() }
        }
        Column(Modifier.fillMaxSize().padding(top = 36.dp, start = 18.dp, end = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            // badge stamps in with a ring burst
            Box(Modifier.size(110.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    if (burst in 0.001f..0.999f) drawCircle(green.copy(alpha = 1f - burst), size.minDimension / 2 * (0.6f + 0.8f * burst), style = Stroke(4.dp.toPx() * (1f - burst)))
                    drawCircle(Brush.radialGradient(listOf(green.copy(alpha = 0.45f * stamp), Color.Transparent)), size.minDimension / 2)
                }
                val sc = if (stamp <= 0f) 1.9f else 1.9f - 0.9f * FastOutSlowInEasing.transform(stamp)
                Canvas(Modifier.size(78.dp).graphicsLayer { scaleX = sc; scaleY = sc; alpha = (stamp * 2f).coerceAtMost(1f) }) {
                    drawCircle(Brush.radialGradient(listOf(green, Color(0xFF0B7A3B)), Offset(size.width * 0.35f, size.height * 0.35f), size.width * 0.75f))
                    drawCircle(green, size.minDimension / 2 + 6.dp.toPx(), style = Stroke(2.dp.toPx(), pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(3f, 8f))))
                    val p = androidx.compose.ui.graphics.Path().apply {
                        moveTo(size.width * 0.30f, size.height * 0.52f); lineTo(size.width * 0.45f, size.height * 0.67f); lineTo(size.width * 0.72f, size.height * 0.36f)
                    }
                    drawPath(p, Color.White, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
                }
            }
            Text("PREMIUM", fontSize = 40.sp, fontWeight = FontWeight.Black, color = Color(0xFF1A1A1A))
            Text((data.userName.ifBlank { "Friend" }) + " unlocked", fontSize = 15.sp, color = Color(0xFF333333))
            Text("Momentum Premium", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1A1A1A))
            if (data.licenseKey.isNotBlank()) Text(data.licenseKey, fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color(0xFF3A3A3A))
            Spacer(Modifier.weight(1f))
            Text(
                java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("d MMM yyyy, h:mma")) + "  •  focus, banked.",
                fontSize = 12.sp, color = Color(0xFF333333), modifier = Modifier.padding(bottom = 30.dp),
            )
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawUnlockAtmosphere(p: Float) {
    // A ghost of the app's own mark — the streak ring and its closing dot,
    // the same shape the launcher icon is — huge and almost invisible
    // behind the receipt, the way a letterhead has a watermark rather than
    // empty space. Book-shadow was the other option raised; the app's own
    // mark reads as "this app, this receipt" without needing a second
    // motif this file would have had to invent from nothing.
    val ghostCx = size.width * 0.5f
    val ghostCy = size.height * 0.40f
    val ghostR = size.minDimension * 0.62f
    drawArc(
        color = Mint.fill.copy(alpha = 0.05f),
        startAngle = -110f,
        sweepAngle = 320f,
        useCenter = false,
        topLeft = Offset(ghostCx - ghostR, ghostCy - ghostR),
        size = Size(ghostR * 2f, ghostR * 2f),
        style = Stroke(ghostR * 0.16f),
    )
    drawCircle(
        color = Color(0xFFF2F2F5).copy(alpha = 0.06f),
        radius = ghostR * 0.16f,
        center = Offset(
            ghostCx + kotlin.math.cos(-110f * kotlin.math.PI.toFloat() / 180f) * ghostR,
            ghostCy + kotlin.math.sin(-110f * kotlin.math.PI.toFloat() / 180f) * ghostR,
        ),
    )

    val pulse = 0.55f + 0.45f * kotlin.math.sin(p * kotlin.math.PI.toFloat() * 12f).let { (it + 1f) / 2f }
    val r = size.minDimension * (0.25f + 0.16f * pulse)
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                GoldNeon.copy(alpha = 0.08f + 0.05f * pulse),
                Sky.fill.copy(alpha = 0.045f),
                Color.Transparent,
            ),
            center = Offset(size.width * 0.50f, size.height * 0.44f),
            radius = r,
        ),
        radius = r,
        center = Offset(size.width * 0.50f, size.height * 0.44f),
    )
    // End burst: sparse rays instead of a particle storm, so the receipt stays
    // readable and the final beat still feels expensive rather than noisy.
    if (p > 0.88f) {
        val q = ((p - 0.88f) / 0.12f).coerceIn(0f, 1f)
        val cx = size.width / 2f
        val cy = size.height * 0.44f
        repeat(18) { i ->
            val a = i / 18f * kotlin.math.PI.toFloat() * 2f
            val inner = size.minDimension * (0.12f + 0.04f * q)
            val outer = inner + size.minDimension * 0.11f * q
            drawLine(
                color = listOf(GoldNeon, Sky.fill, Lilac.fill, Mint.fill, Tang.fill)[i % 5].copy(alpha = 0.72f * (1f - q * 0.35f)),
                start = Offset(cx + kotlin.math.cos(a) * inner, cy + kotlin.math.sin(a) * inner),
                end = Offset(cx + kotlin.math.cos(a) * outer, cy + kotlin.math.sin(a) * outer),
                strokeWidth = 2.dp.toPx(),
            )
        }
    }
}

/**
 * The slip itself. Monospace and dotted rules, matching the saved PNG.
 *
 * [printed] is the same feed value driving the outer translation. Slip masks
 * its own lower portion in white while printed < 1, so the paper is not just
 * sliding into frame already finished -- each line's turn to appear tracks
 * the same motor pulse the haptics are ticking to.
 */
@Composable
private fun Slip(data: AppData, printed: Float) {
    val stamp = remember {
        LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy · HH:mm"))
    }
    // The app's own paper, not thermal-till white.
    //
    // Plain black-on-white was the honest thermal reference, and it was also
    // the one screen in the whole app with none of its colour language on
    // it -- every card elsewhere is cream with a coloured header band and one
    // accent doing the talking. A Tang header and a Sky-tinted key box are
    // the same move Plans and Home already make; this just brings the
    // receipt in line with them instead of leaving it looking imported.
    Column(
        Modifier
            .width(272.dp)
            .clip(RoundedCornerShape(10.dp))
            .drawWithContent {
                drawContent()
                if (printed < 0.999f) {
                    // The unprinted portion, covered in whichever background
                    // that band actually is -- Tang behind the header, cream
                    // everywhere else -- so the reveal never flashes the
                    // wrong colour over a region it has not reached yet.
                    val cut = (size.height * (printed + 0.06f)).coerceAtMost(size.height)
                    val headerPx = 64.dp.toPx()
                    if (cut < headerPx) {
                        drawRect(
                            color = Tang.fill,
                            topLeft = Offset(0f, cut),
                            size = Size(size.width, headerPx - cut),
                        )
                        drawRect(
                            color = CreamCard,
                            topLeft = Offset(0f, headerPx),
                            size = Size(size.width, size.height - headerPx),
                        )
                    } else {
                        drawRect(
                            color = CreamCard,
                            topLeft = Offset(0f, cut),
                            size = Size(size.width, size.height - cut),
                        )
                    }
                    // The moving edge itself, drawn right where the mask
                    // above stops -- a thin warm line sitting exactly on
                    // the boundary between printed and not-yet-printed, so
                    // there is one clear place the eye can watch new lines
                    // arrive from rather than reading the reveal as a flat
                    // curtain dropping.
                    drawRect(
                        color = Tang.accent.copy(alpha = 0.55f),
                        topLeft = Offset(0f, (cut - 1.5.dp.toPx()).coerceAtLeast(0f)),
                        size = Size(size.width, 1.5.dp.toPx()),
                    )
                }
            },
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(Tang.fill, Tang.accent)))
                .padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("\uD83C\uDF1F", fontSize = 18.sp)
                Spacer(Modifier.width(6.dp))
                Text(
                    "MOMENTUM",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = Ink,
                )
                Spacer(Modifier.width(6.dp))
                Text("\uD83C\uDF1F", fontSize = 18.sp)
            }
            Text(
                "focus, banked",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Ink.copy(alpha = 0.75f),
            )
        }

        Column(
            Modifier
                .background(CreamCard)
                .padding(horizontal = 18.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(stamp, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = InkMid)

            Spacer(Modifier.height(12.dp))
            DottedRule()
            Spacer(Modifier.height(12.dp))

            Text(
                "LICENCE KEY",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = InkMid,
            )
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Sky.fill.copy(alpha = 0.30f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            ) {
                Text(
                    License.pretty(data.licenseKey),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Ink,
                )
            }

            Spacer(Modifier.height(14.dp))
            DottedRule()
            Spacer(Modifier.height(12.dp))

            SlipRow("Item", "Lifetime")
            SlipRow("Holder", data.userName.ifBlank { "friend" })
            SlipRow("Focused", "${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m")
            // PAID in Mint -- the same colour this app already reaches for
            // whenever something is confirmed and settled.
            SlipRow("Status", "PAID", valueColor = Mint.accent)

            Spacer(Modifier.height(12.dp))
            DottedRule()
            Spacer(Modifier.height(10.dp))
            Text(
                "Blocking stays free. Always.",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = InkMid,
            )
        }
    }
}

@Composable
private fun SlipRow(label: String, value: String, valueColor: Color = Ink) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = InkMid)
        Text(
            value,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = valueColor,
        )
    }
}

@Composable
private fun DottedRule() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(1.dp)
            .drawBehind {
                var x = 0f
                while (x < size.width) {
                    drawRect(
                        color = Ink.copy(alpha = 0.45f),
                        topLeft = Offset(x, 0f),
                        size = androidx.compose.ui.geometry.Size(3f, size.height),
                    )
                    x += 7f
                }
            },
    )
}
