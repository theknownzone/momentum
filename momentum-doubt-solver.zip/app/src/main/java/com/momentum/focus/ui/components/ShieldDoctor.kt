package com.momentum.focus.ui.components

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.momentum.focus.data.tr
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.OemStartup
import com.momentum.focus.ui.util.Perm
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.rememberHaptics

/**
 * Shield Doctor — "why did the shield go off, and how do I stop it".
 *
 * Owner bug: swipe the app away → nothing blocks, and reopening said nothing.
 * This is the proper error + instruction structure: a headline with the most
 * likely CAUSE first (read from the real state, not guessed), then every
 * check as its own row: status pill (OK / FIX / CHECK), one-line why, and
 * when broken, 2–3 numbered steps and a button straight to the right system
 * screen. Re-reads on resume, so a row flips to OK the moment it's fixed.
 *
 * Paper sheet, rows rise in one after another (40 ms stagger, 220 ms each).
 * No loops.
 */
@Composable
fun ShieldDoctor(outageMinutes: Int, onClose: () -> Unit) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val owner = LocalLifecycleOwner.current
    var refresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) refresh++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    data class Check(
        val title: String,
        val why: String,
        /** true OK, false FIX, null = can't be read (CHECK). */
        val ok: Boolean?,
        val steps: List<String>,
        val open: () -> Unit,
    )

    val checks = remember(refresh) {
        fun go(i: Intent?) { i?.let { runCatching { context.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } } }
        listOf(
            Check(
                tr("Usage access", "यूसेज एक्सेस"),
                tr("Lets the shield see which app is open.", "शील्ड देख पाती है कौन सा ऐप खुला है।"),
                Perms.granted(context, Perm.USAGE_ACCESS),
                listOf(tr("Tap Fix", "Fix दबाओ"), tr("Find Momentum", "Momentum ढूँढो"), tr("Turn the switch ON", "स्विच ON करो")),
            ) { go(Perms.intentFor(context, Perm.USAGE_ACCESS)) },
            Check(
                tr("Display over other apps", "दूसरे ऐप्स के ऊपर दिखाना"),
                tr("Without it the shield decides to block but can't show up.", "इसके बिना शील्ड ब्लॉक करना चाहती है पर दिख नहीं पाती।"),
                Perms.granted(context, Perm.OVERLAY),
                listOf(tr("Tap Fix", "Fix दबाओ"), tr("Turn 'Allow' ON", "'Allow' ON करो")),
            ) { go(Perms.intentFor(context, Perm.OVERLAY)) },
            Check(
                tr("Battery: Unrestricted", "बैटरी: Unrestricted"),
                tr("Battery saver is the #1 reason Android kills blockers.", "बैटरी सेवर ब्लॉकर को बंद करने की सबसे बड़ी वजह है।"),
                Perms.granted(context, Perm.BATTERY),
                listOf(tr("Tap Fix", "Fix दबाओ"), tr("Choose 'Allow' / 'Unrestricted'", "'Allow' / 'Unrestricted' चुनो")),
            ) { go(Perms.intentFor(context, Perm.BATTERY)) },
            Check(
                tr("Auto-restart guard", "ऑटो-रीस्टार्ट गार्ड"),
                tr("Accessibility guard brings the shield back if you swipe Momentum away.", "Momentum स्वाइप करने पर भी Accessibility गार्ड शील्ड वापस लाता है।"),
                Perms.isShortsGuardOn(context),
                listOf(
                    tr("Tap Fix → Installed apps → Momentum", "Fix → Installed apps → Momentum"),
                    tr("Turn it ON", "ON करो"),
                    tr("Greyed out? App info → ⋮ → Allow restricted settings", "स्विच धुंधला? App info → ⋮ → Allow restricted settings"),
                ),
            ) { go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            Check(
                tr("Autostart (Xiaomi, Vivo, Oppo, Realme…)", "Autostart (Xiaomi, Vivo, Oppo, Realme…)"),
                tr("Phone makers block restarts unless this is ON. Android won't tell us its state.", "ये ON न हो तो फ़ोन रीस्टार्ट रोक देता है। Android इसकी स्थिति नहीं बताता।"),
                null,
                listOf(tr("Tap Open", "Open दबाओ"), tr("Find Momentum → turn Autostart ON", "Momentum → Autostart ON")),
            ) { runCatching { OemStartup.open(context) } },
        )
    }

    // Most likely cause, from the real state.
    val firstBroken = checks.firstOrNull { it.ok == false }
    val cause = when {
        firstBroken != null -> tr("Most likely: ${firstBroken.title} is off.", "सबसे संभावित वजह: ${firstBroken.title} बंद है।")
        else -> tr("Most likely: your phone closed Momentum in the background (swiped from Recents or battery saver).",
            "सबसे संभावित वजह: फ़ोन ने Momentum को बैकग्राउंड में बंद किया (Recents से स्वाइप या बैटरी सेवर)।")
    }

    val rise = remember { Animatable(0f) }
    LaunchedEffect(Unit) { rise.animateTo(1f, tween(240, easing = FastOutSlowInEasing)) }

    // A Dialog, not inline: Home is a scrolling Column, where a fill-max
    // overlay would have no height to fill.
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onClose,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
    // Owner bug: "Done" sat under the nav bar and couldn't be pressed. Now:
    // solid sheet capped at 82% of the screen, checks scroll inside, Done is
    // PINNED below the scroll area and always reachable.
    val maxH = (androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp * 0.82f).dp
    Box(
        Modifier.fillMaxSize().background(Ink.copy(alpha = 0.45f)),
        contentAlignment = Alignment.BottomCenter,
    ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(horizontal = 12.dp, vertical = 12.dp)
                    .heightIn(max = maxH)
                    .graphicsLayer { alpha = rise.value; translationY = (1f - rise.value) * 40.dp.toPx() }
                    .clip(RoundedCornerShape(24.dp))
                    .background(Cream)
                    .border(Paper.Outline, Ink, RoundedCornerShape(24.dp)),
            ) {
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(20.dp)) {
                    Box(
                        Modifier.clip(RoundedCornerShape(8.dp)).background(Ink).padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(tr("SHIELD DOCTOR", "शील्ड डॉक्टर"), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, color = Butter.fill)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        if (outageMinutes > 0) {
                            val h = outageMinutes / 60; val m = outageMinutes % 60
                            val t = if (h > 0) "${h}h ${m}m" else "${m}m"
                            tr("Your shield was off for $t.", "तुम्हारी शील्ड $t बंद रही।")
                        } else tr("Is your shield bulletproof?", "क्या तुम्हारी शील्ड पक्की है?"),
                        style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, color = Ink,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(cause, style = MaterialTheme.typography.bodyMedium, color = Tang.accent, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))

                    checks.forEachIndexed { i, c ->
                        val inA = remember { Animatable(0f) }
                        LaunchedEffect(Unit) {
                            kotlinx.coroutines.delay(120L + i * 40L)
                            inA.animateTo(1f, tween(220, easing = FastOutSlowInEasing))
                        }
                        val (pill, st) = when (c.ok) {
                            true -> tr("OK", "ठीक") to Mint
                            false -> tr("FIX", "ठीक करो") to Tang
                            null -> tr("CHECK", "जाँचो") to Butter
                        }
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .graphicsLayer { alpha = inA.value; translationY = (1f - inA.value) * 14.dp.toPx() }
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (c.ok == true) CreamCard else st.fill.copy(alpha = 0.22f))
                                .border(2.dp, Ink, RoundedCornerShape(14.dp))
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(c.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                                Box(
                                    Modifier.clip(RoundedCornerShape(50)).background(st.fill).border(1.5.dp, Ink, RoundedCornerShape(50))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) { Text(pill, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, color = st.on) }
                            }
                            Text(c.why, style = MaterialTheme.typography.bodySmall, color = InkMid)
                            if (c.ok != true) {
                                Spacer(Modifier.height(6.dp))
                                c.steps.forEachIndexed { n, s ->
                                    Text("${n + 1}. $s", style = MaterialTheme.typography.bodySmall, color = Ink)
                                }
                                Spacer(Modifier.height(8.dp))
                                SquishButton(
                                    label = if (c.ok == null) tr("Open", "खोलो") else tr("Fix", "ठीक करो"),
                                    sticker = st,
                                    modifier = Modifier.fillMaxWidth(),
                                ) { haptics.confirm(); c.open() }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
                Box(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 16.dp, top = 4.dp)) {
                    SquishButton(
                        label = tr("Done", "हो गया"),
                        sticker = Mint,
                        modifier = Modifier.fillMaxWidth(),
                    ) { haptics.tap(); onClose() }
                }
            }
    }
}
}
