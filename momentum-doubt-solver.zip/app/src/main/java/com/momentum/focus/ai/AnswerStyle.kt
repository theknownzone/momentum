package com.momentum.focus.ai

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * How the user wants MyAI to answer: length + Hinglish. Set in MyAI's
 * answer sheet (AnswerStyleSheet, MyAiBars.kt), read once per question when the system prompt
 * is built (AppViewModel → Doubt.answer). In-memory on purpose: it's a
 * per-sitting preference, and "Normal / app language" is the safe default.
 */
object AnswerStyle {
    const val SHORT = 0
    const val NORMAL = 1
    const val DEEP = 2

    var length by mutableIntStateOf(NORMAL)
    var hinglish by mutableStateOf(false)

    fun promptLines(): String = buildString {
        when (length) {
            SHORT -> append("\nANSWER LENGTH: Short — 3 to 4 lines at most. Lead with the answer itself, no preamble.")
            DEEP -> append("\nANSWER LENGTH: Detailed — the idea, then numbered steps, one worked example, and one exam tip. Short headings.")
        }
        if (hinglish) append("\nLANGUAGE: Reply in simple Hinglish (Hindi in Latin script, keep subject terms in English).")
    }
}
