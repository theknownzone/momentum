package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

val SLIP_REASONS = listOf("Bored", "Stressed", "Just habit", "Actually wanted to")

/**
 * Asked after the craving has passed, never during it.
 *
 * Two taps, no typing. Asked mid-craving the answer would be a justification;
 * asked afterwards it is the truth, and the difference between those two is
 * the entire value of the data.
 */
@Composable
fun SlipReflectionScreen(
    minutes: Int,
    onAnswer: (reason: String, regretted: Boolean) -> Unit,
    onSkip: () -> Unit,
) {
    val haptics = rememberHaptics()
    var reason by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 40.dp, bottom = 26.dp),
    ) {
        Text("YOU SPENT ${minutes}m", style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Text(
            if (reason == null) "What sent you there?" else "Worth it?",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
            "Two taps. It builds the only insight this app can give you.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp),
        )

        Spacer(Modifier.height(28.dp))

        if (reason == null) {
            SLIP_REASONS.forEachIndexed { i, r ->
                val sticker = stickerFor(i)
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .clip(RoundedCornerShape(Paper.CardRadius))
                        .background(sticker.fill)
                        .border(Paper.Outline, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(Paper.CardRadius))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tap(); reason = r
                        }
                        .padding(18.dp),
                ) {
                    Text(r, style = MaterialTheme.typography.headlineSmall, color = sticker.on)
                }
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Answer("Regret it", Tang, Modifier.weight(1f)) {
                    haptics.reject(); onAnswer(reason!!, true)
                }
                Answer("No regret", Mint, Modifier.weight(1f)) {
                    haptics.confirm(); onAnswer(reason!!, false)
                }
            }
        }

        Spacer(Modifier.weight(1f))

        Text(
            "Skip",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onSkip)
                .padding(12.dp),
        )
    }
}

@Composable
private fun Answer(
    label: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(sticker.fill)
            .border(Paper.Outline, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(Paper.CardRadius))
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
            .padding(vertical = 26.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.headlineSmall, color = sticker.on)
    }
}
