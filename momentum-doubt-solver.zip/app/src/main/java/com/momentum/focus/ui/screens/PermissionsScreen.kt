package com.momentum.focus.ui.screens

import android.Manifest
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Icon
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.tr
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.window.Popup
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.LiquidGlass
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.StickerCard
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.block.Admin
import com.momentum.focus.data.AppStore
import com.momentum.focus.ui.util.OemStartup
import com.momentum.focus.ui.util.Perm
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.rememberHaptics

@Composable
fun PermissionsScreen(onDone: () -> Unit, onPlans: () -> Unit = {}) {
    val str = strings()
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val owner = LocalLifecycleOwner.current
    val store = remember { AppStore(context) }

    var refresh by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                scope.launch {
                    delay(250)
                    refresh++
                }
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    val statuses = remember(refresh) {
        Perm.entries.associateWith { Perms.granted(context, it) }
    }
    val readyToGo = remember(refresh) { Perms.allRequiredGranted(context) }
    val requiredPerms = Perm.entries.filter { it.required }
    val doneCount = requiredPerms.count { statuses[it] == true }
    val left = requiredPerms.size - doneCount

    // All required green while the screen is up: one rising chime, once.
    var wasReady by remember { mutableStateOf(readyToGo) }
    LaunchedEffect(readyToGo) {
        if (readyToGo && !wasReady) { Sfx.play(Sound.SUCCESS); haptics.confirm() }
        wasReady = readyToGo
    }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { refresh++ }

    val guardOn = remember(refresh) { Perms.isShortsGuardOn(context) }
    val data by store.data.collectAsStateWithLifecycle(initialValue = null)
    val hardLevel = (data?.focusLevel ?: 0) >= 3 || data?.crownMode == true
    val adminOn = remember(refresh) { Admin.isActive(context) }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain(),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 28.dp, bottom = 120.dp),
        ) {
            Text(
                str.perms.setup,
                style = MaterialTheme.typography.labelSmall,
                letterSpacing = 1.6.sp,
                color = Mint.accent,
            )
            Spacer(Modifier.height(6.dp))
            WordReveal(str.perms.title)
            Spacer(Modifier.height(8.dp))
            FadeUp(delayMs = 200) {
                Text(
                    tr("Three switches. Zero servers. Everything stays on this phone.",
                        "तीन स्विच। कोई सर्वर नहीं। सब कुछ इसी फ़ोन पर।"),
                    style = MaterialTheme.typography.bodyLarge,
                    color = InkMid,
                )
            }

            Spacer(Modifier.height(20.dp))
            ProgressHeader(done = doneCount, total = requiredPerms.size, ready = readyToGo, left = left)
            Spacer(Modifier.height(18.dp))

            Perm.entries.forEachIndexed { i, perm ->
                val on = statuses[perm] == true
                FadeUp(delayMs = 260 + i * 70) {
                    PermCard(
                        icon = permIcon(perm),
                        tag = when {
                            on -> str.perms.on
                            perm.required -> str.perms.required
                            else -> str.perms.optional
                        },
                        tagColor = when {
                            on -> Mint.on
                            perm.required -> Tang.accent
                            else -> InkMid
                        },
                        title = permTitle(perm),
                        body = permWhy(perm),
                        hint = if (perm == Perm.USAGE_ACCESS && !on && Build.VERSION.SDK_INT >= 33) tr(
                            "Switch greyed out? Open App info → ⋮ → Allow restricted settings, then come back.",
                            "स्विच धुंधला है? App info → ⋮ → Allow restricted settings, फिर वापस आएँ।",
                        ) else null,
                        actionLabel = null,
                        on = on,
                        onClick = if (on) null else {
                            {
                                if (perm == Perm.NOTIFICATIONS && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    Perms.intentFor(context, perm)?.let {
                                        runCatching { context.startActivity(it) }
                                    }
                                }
                            }
                        },
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Text(
                tr("EXTRA PROTECTION", "अतिरिक्त सुरक्षा"),
                style = MaterialTheme.typography.labelSmall,
                letterSpacing = 1.4.sp,
                color = InkMid,
            )
            Spacer(Modifier.height(10.dp))

            PermCard(
                icon = Icons.Filled.AdminPanelSettings,
                tag = when {
                    adminOn -> str.perms.on
                    hardLevel -> str.perms.requiredForCrown
                    else -> str.perms.optional
                },
                tagColor = if (adminOn) Mint.on else if (hardLevel) Tang.accent else InkMid,
                title = str.perms.deviceAdmin,
                body = if (adminOn) str.perms.deviceAdminOn else str.perms.deviceAdminOff,
                on = adminOn,
                titleExtra = {
                    InfoTooltip(
                        text = tr(
                            "Once this is on, Momentum can't be uninstalled or force-stopped until you turn Crown Mode off first — that's the whole point.",
                            "यह चालू होने पर, क्राउन मोड बंद किए बिना Momentum अनइंस्टॉल या फ़ोर्स-स्टॉप नहीं होगा — यही इसका मक़सद है।",
                        ),
                    )
                },
                onClick = when {
                    adminOn -> null
                    data?.premium == true -> {
                        { runCatching { context.startActivity(Admin.requestIntent(context)) } }
                    }
                    else -> { { haptics.tick(); onPlans() } }
                },
            )

            PermCard(
                icon = Icons.Filled.Block,
                tag = if (guardOn) str.perms.on else str.perms.optional,
                tagColor = if (guardOn) Mint.on else InkMid,
                title = str.perms.shortsGuard,
                body = if (guardOn) str.perms.shortsGuardOn else str.perms.shortsGuardOff,
                hint = if (!guardOn && Build.VERSION.SDK_INT >= 33) str.perms.shortsGuardHint else null,
                on = guardOn,
                onClick = if (guardOn) null else {
                    { runCatching { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
                },
            )

            if (OemStartup.isAffected) {
                PermCard(
                    icon = Icons.Filled.RestartAlt,
                    tag = str.perms.killsBackground,
                    tagColor = Tang.accent,
                    title = str.perms.autostart,
                    body = OemStartup.path,
                    hint = str.perms.autostartBody,
                    on = false,
                    actionLabel = tr("Open", "खोलें"),
                    onClick = { OemStartup.open(context) },
                )
            }
        }

        // Pinned CTA in the thumb zone. Not ready = quiet grey + a shake on tap.
        val shake = remember { Animatable(0f) }
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, MaterialTheme.colorScheme.background.copy(alpha = 0.95f), MaterialTheme.colorScheme.background),
                    ),
                )
                .navigationBarsPadding()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 24.dp, bottom = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.graphicsLayer { translationX = shake.value }) {
                PrimaryButton(
                    label = if (readyToGo) tr("Lock in →", "शुरू करें →") else str.perms.grantFirst,
                    enabled = readyToGo,
                ) {
                    if (!readyToGo) {
                        haptics.reject()
                        Sfx.play(Sound.ERROR)
                        scope.launch {
                            listOf(14f, -12f, 8f, -5f, 0f).forEach { shake.animateTo(it, tween(45)) }
                        }
                    } else {
                        haptics.confirm()
                        onDone()
                    }
                }
            }
            AnimatedVisibility(visible = !readyToGo, enter = fadeIn(tween(200)), exit = fadeOut(tween(150))) {
                Text(
                    str.perms.mustHave,
                    style = MaterialTheme.typography.labelSmall,
                    color = InkMid,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}

/** Ring + one punchy line. The ring fills as switches go green. */
@Composable
private fun ProgressHeader(done: Int, total: Int, ready: Boolean, left: Int) {
    val p by animateFloatAsState(
        if (total == 0) 1f else done.toFloat() / total,
        tween(420, easing = FastOutSlowInEasing),
        label = "permRing",
    )
    val pop by animateFloatAsState(if (ready) 1.06f else 1f, tween(220), label = "permPop")
    Row(
        Modifier
            .fillMaxWidth()
            .brutal(if (ready) Mint.fill else Butter.fill)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(54.dp).graphicsLayer { scaleX = pop; scaleY = pop }, contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val st = 6.dp.toPx()
                val tl = Offset(st / 2, st / 2)
                val sz = Size(size.width - st, size.height - st)
                drawArc(Ink, 0f, 360f, false, tl, sz, style = Stroke(st + 4f))
                drawArc(CreamCard, 0f, 360f, false, tl, sz, style = Stroke(st))
                val pc = com.momentum.focus.ui.components.progressColor(p)
                for (k in 1..4) drawArc(pc.copy(alpha = 0.14f * (1f - k / 5f)), -90f, 360f * p, false, tl, sz, style = Stroke(st + k * 4.dp.toPx(), cap = StrokeCap.Round))
                drawArc(pc, -90f, 360f * p, false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
            }
            Text("$done/$total", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Ink)
        }
        Spacer(Modifier.width(14.dp))
        AnimatedContent(
            targetState = ready to left,
            transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(140)) },
            label = "permLine",
        ) { (r, l) ->
            Column {
                Text(
                    when {
                        r -> tr("All green. Locked and loaded.", "सब हरा। पूरी तरह तैयार।")
                        l == 1 -> tr("One more tap.", "बस एक टैप और।")
                        else -> tr("$l taps to lock in.", "$l टैप और, फिर लॉक इन।")
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Ink,
                )
                Text(
                    if (r) tr("Blocker's armed. Let's go.", "ब्लॉकर तैयार है। चलिए।")
                    else tr("Tap a card, flip the switch, come back.", "कार्ड टैप करें, स्विच चालू करें, वापस आएँ।"),
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                )
            }
        }
    }
}

/** v2 permission row: white card, icon chip, state pill. Granted = mint, collapses its explainer. */
@Composable
private fun PermCard(
    icon: ImageVector,
    tag: String,
    tagColor: Color,
    title: String,
    body: String,
    on: Boolean,
    onClick: (() -> Unit)?,
    hint: String? = null,
    actionLabel: String? = null,
    titleExtra: (@Composable () -> Unit)? = null,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val p by animateFloatAsState(if (pressed) 1f else 0f, tween(120), label = "permPress")
    val bg by animateColorAsState(if (on) Mint.fill else CreamCard, tween(240), label = "bg")
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp, end = 5.dp)
            .brutal(bg, press = p)
            .then(if (onClick != null) Modifier.clickableNoRipple(interaction, onClick = onClick) else Modifier)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(if (on) CreamCard else Butter.fill)
                .border(2.dp, Ink, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = Ink, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(tag.uppercase(), style = MaterialTheme.typography.labelSmall, letterSpacing = 1.2.sp, color = tagColor)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ink)
                if (titleExtra != null) { Spacer(Modifier.width(6.dp)); titleExtra() }
            }
            AnimatedVisibility(visible = !on, enter = fadeIn(tween(200)) + expandVertically(tween(220)), exit = fadeOut(tween(150)) + shrinkVertically(tween(200))) {
                Column {
                    Text(body, style = MaterialTheme.typography.bodyMedium, color = InkMid)
                    if (hint != null) {
                        Spacer(Modifier.height(4.dp))
                        Text(hint, style = MaterialTheme.typography.bodySmall, color = Tang.accent)
                    }
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        StatePill(on = on, actionLabel = actionLabel)
    }
}

@Composable
private fun StatePill(on: Boolean, actionLabel: String?) {
    val str = strings()
    AnimatedContent(
        targetState = on,
        transitionSpec = {
            (fadeIn(tween(200)) + scaleIn(tween(220), initialScale = 0.6f)) togetherWith (fadeOut(tween(120)) + scaleOut(tween(120)))
        },
        label = "statePill",
    ) { granted ->
        if (granted) {
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(Ink),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Check, contentDescription = str.perms.on, tint = Mint.fill, modifier = Modifier.size(20.dp))
            }
        } else {
            Text(
                actionLabel ?: str.perms.grant,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Ink)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
    }
}

private fun permIcon(p: Perm): ImageVector = when (p) {
    Perm.NOTIFICATIONS -> Icons.Filled.Notifications
    Perm.USAGE_ACCESS -> Icons.Filled.QueryStats
    Perm.OVERLAY -> Icons.Filled.Layers
    Perm.BATTERY -> Icons.Filled.BatteryChargingFull
}

private fun permTitle(p: Perm): String = when (p) {
    Perm.NOTIFICATIONS -> tr(p.title, "सूचनाएँ")
    Perm.USAGE_ACCESS -> tr(p.title, "उपयोग की जानकारी")
    Perm.OVERLAY -> tr(p.title, "दूसरे ऐप्स के ऊपर दिखाना")
    Perm.BATTERY -> tr(p.title, "बैटरी पर रोक नहीं")
}

private fun permWhy(p: Perm): String = when (p) {
    Perm.NOTIFICATIONS -> tr("Session pings + streak wins.", "सेशन की याद + स्ट्रीक की ख़बर।")
    Perm.USAGE_ACCESS -> tr("Sees which app is open, so it can block the bad ones.", "देखता है कौन-सा ऐप खुला है, ताकि ग़लत वाले रोक सके।")
    Perm.OVERLAY -> tr("Puts the lock screen over a blocked app.", "ब्लॉक ऐप के ऊपर लॉक स्क्रीन दिखाता है।")
    Perm.BATTERY -> tr("Stops Android killing the blocker.", "Android को ब्लॉकर बंद करने से रोकता है।")
}
/**
 * The hover-info tooltip from the reference, adapted for a touch screen —
 * tap the mark instead of hovering it, tap anywhere else to dismiss. Built
 * for exactly one spot: Crown Mode's own permission card, the one
 * permission on this whole screen serious enough (an actual uninstall
 * lock) that "what does turning this on actually do" deserves its own
 * answer right there, not just the shorter line already under the title.
 */
@Composable
private fun InfoTooltip(text: String) {
    var open by remember { mutableStateOf(false) }
    Box {
        Box(
            Modifier
                .size(18.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.5f))
                .border(1.5.dp, Ink, CircleShape)
                .clickableNoRipple(remember { MutableInteractionSource() }) { open = !open },
            contentAlignment = Alignment.Center,
        ) {
            Text("?", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Ink)
        }
        if (open) {
            Popup(
                alignment = Alignment.TopStart,
                offset = IntOffset(0, 40),
                onDismissRequest = { open = false },
            ) {
                Box(
                    Modifier
                        .width(240.dp)
                        .shadow(8.dp, RoundedCornerShape(12.dp), clip = false)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF17151F))
                        .border(1.dp, Violet.fill.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                ) {
                    Text(text, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
                }
            }
        }
    }
}
