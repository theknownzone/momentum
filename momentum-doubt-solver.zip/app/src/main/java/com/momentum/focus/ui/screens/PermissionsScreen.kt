package com.momentum.focus.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.window.Popup
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.LiquidGlass
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.StickerCard
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.block.Admin
import com.momentum.focus.data.AppStore
import com.momentum.focus.ui.util.OemStartup
import com.momentum.focus.ui.util.Perm
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.rememberHaptics

@Composable
fun PermissionsScreen(onDone: () -> Unit, onPlans: () -> Unit = {}) {
    val str = strings()
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val owner = LocalLifecycleOwner.current
    val store = remember { AppStore(context) }

    // Grants happen in system settings, outside this app. The only way to know
    // the result is to re-read every status when the screen resumes.
    //
    // Battery specifically needed more than an immediate re-read: right after
    // returning from the "Allow" dialog, PowerManager could still answer with
    // the pre-grant state for a beat — Android hasn't finished propagating it
    // yet — so the first resume's check read stale and showed red, and it
    // only turned green once a second resume happened to land after the OS
    // caught up. A short settle delay before reading, rather than reading the
    // instant resume fires, is what removed the need to tap it 2-3 times.
    var refresh by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                scope.launch {
                    delay(250)
                    refresh++
                }
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    val statuses = remember(refresh) {
        Perm.entries.associateWith { Perms.granted(context, it) }
    }
    val readyToGo = remember(refresh) { Perms.allRequiredGranted(context) }

    // Notifications gets its own launcher above rather than going through
    // Perms.intentFor like the rest of this list — it is Android's own
    // Allow/Don't-allow dialog, not a settings screen to navigate to.

    Box(Modifier.fillMaxSize()) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 40.dp, bottom = 28.dp),
    ) {
        Text(
            str.perms.setup,
            style = MaterialTheme.typography.labelSmall,
            color = Mint.on,
        )
        Text(
            str.perms.title,
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            str.perms.body,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp),
        )

        Spacer(Modifier.height(20.dp))

        // Four cards with no running total left people scrolling back up to
        // count what they had done. The bar answers "how much more" without
        // being read.
        val requiredPerms = Perm.entries.filter { it.required }
        val doneCount = requiredPerms.count { statuses[it] == true }
        val progress by animateFloatAsState(
            // Guarded on both sides. An empty required list would divide by
            // zero and hand fillMaxWidth a NaN, which throws rather than
            // drawing nothing — and fillMaxWidth only accepts 0..1 anyway.
            targetValue = if (requiredPerms.isEmpty()) 1f
            else (doneCount.toFloat() / requiredPerms.size).coerceIn(0f, 1f),
            label = "setupProgress",
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                str.perms.progress(doneCount, requiredPerms.size),
                style = MaterialTheme.typography.labelSmall,
                color = if (readyToGo) Mint.on else Tang.accent,
            )
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier
                    .weight(1f)
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(2.dp, Ink, RoundedCornerShape(5.dp)),
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(progress)
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(if (readyToGo) Mint.fill else Tang.fill)
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        val notifLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission(),
        ) { }

        Perm.entries.forEachIndexed { i, perm ->
            val on = statuses[perm] == true
            val sticker = if (on) Emerald else stickerFor(i + 1)

            StickerCard(
                sticker = sticker,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = Paper.Gap),
                onClick = if (on) null else {
                    {
                        // Notifications is the one permission here that is
                        // Android's own runtime dialog, not a settings
                        // screen — POST_NOTIFICATIONS on API 33+. Sending it
                        // through Perms.intentFor took someone to the app's
                        // notification settings page instead, an extra trip
                        // through Android's own UI for what should be one
                        // Allow/Don't allow tap in front of them.
                        if (perm == Perm.NOTIFICATIONS && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            Perms.intentFor(context, perm)?.let {
                                runCatching { context.startActivity(it) }
                            }
                        }
                    }
                },
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (perm.required) str.perms.required else str.perms.optional,
                            style = MaterialTheme.typography.labelSmall,
                            color = sticker.on,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            perm.title,
                            style = MaterialTheme.typography.headlineSmall,
                            color = sticker.on,
                        )
                        Text(
                            perm.why,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    StateChip(on)
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        val guardOn = remember(refresh) { Perms.isShortsGuardOn(context) }
        // Above Hard the pact leans on two grants that are optional at lower
        // levels. Nothing here is force-granted — the screen just stops calling
        // them optional once the user has picked a level that needs them.
        val data by store.data.collectAsStateWithLifecycle(initialValue = null)
        val hardLevel = (data?.focusLevel ?: 0) >= 3 || data?.crownMode == true
        val adminOn = remember(refresh) { Admin.isActive(context) }

        // Not gated on the level any more. It used to appear only once Crown
        // was already on, but Crown cannot turn on until admin is granted —
        // so the one card that grants it was invisible exactly when it was
        // needed, and the toggle in Profile was the only way in.
        run {
            if (hardLevel) {
                Text(
                    str.perms.crownExtras,
                    style = MaterialTheme.typography.labelSmall,
                    color = Tang.accent,
                )
                Spacer(Modifier.height(8.dp))
            }
            StickerCard(
                sticker = if (adminOn) Emerald else Violet,
                modifier = Modifier.fillMaxWidth().padding(bottom = Paper.Gap),
                // The card used to call Admin.requestIntent directly here with
                // no check at all — Crown's uninstall-lock is a paid feature
                // everywhere else it's offered (FocusScreen redirects a
                // non-premium tap on Crown straight to Plans), but this one
                // entry point handed out the same system-level protection for
                // free. A free install could self-report as "can't be
                // uninstalled" without ever paying for it. Same rule here now:
                // premium grants it, anyone else gets sent to Plans instead.
                onClick = when {
                    adminOn -> null
                    data?.premium == true -> {
                        { runCatching { context.startActivity(Admin.requestIntent(context)) } }
                    }
                    else -> { { haptics.tick(); onPlans() } }
                },
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            when {
                                adminOn -> str.perms.on
                                hardLevel -> str.perms.requiredForCrown
                                else -> str.perms.optional
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (adminOn) Emerald.on else Violet.on,
                        )
                        Spacer(Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                str.perms.deviceAdmin,
                                style = MaterialTheme.typography.headlineSmall,
                                color = if (adminOn) Emerald.on else Violet.on,
                            )
                            Spacer(Modifier.width(6.dp))
                            InfoTooltip(
                                text = "Once this is on, Momentum can't be uninstalled or force-stopped until you turn Crown Mode off first — that's the whole point, and also why it needs this specific permission.",
                            )
                        }
                        Text(
                            if (adminOn)
                                str.perms.deviceAdminOn
                            else
                                str.perms.deviceAdminOff,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    StateChip(adminOn)
                }
            }
        }

        StickerCard(
            sticker = if (guardOn) Emerald else Lilac,
            modifier = Modifier.fillMaxWidth().padding(bottom = Paper.Gap),
            onClick = {
                if (guardOn) return@StickerCard
                runCatching { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            },
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (guardOn) str.perms.on else str.perms.optional,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (guardOn) Emerald.on else Lilac.on,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        str.perms.shortsGuard,
                        style = MaterialTheme.typography.headlineSmall,
                        color = if (guardOn) Emerald.on else Lilac.on,
                    )
                    Text(
                        if (guardOn)
                            str.perms.shortsGuardOn
                        else
                            str.perms.shortsGuardOff,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (!guardOn && Build.VERSION.SDK_INT >= 33) {
                        Spacer(Modifier.height(6.dp))
                        // The single most common reason this grant fails. The
                        // toggle appears, accepts the tap, and silently flips
                        // back, because Android blocks accessibility for
                        // sideloaded apps until restricted settings are opened.
                        Text(
                            str.perms.shortsGuardHint,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Tang.accent,
                        )
                    }
                }
                StateChip(guardOn)
            }
        }

        // Autostart is the one thing on this screen the app genuinely cannot
        // verify. There is no API for it, so the card never claims a state —
        // it opens the vendor screen and spells out the path in words.
        if (OemStartup.isAffected) {
            Text(
                str.perms.killsBackground,
                style = MaterialTheme.typography.labelSmall,
                color = Tang.accent,
            )
            Spacer(Modifier.height(8.dp))
            StickerCard(
                sticker = Tang,
                modifier = Modifier.fillMaxWidth().padding(bottom = Paper.Gap),
                onClick = { OemStartup.open(context) },
            ) {
                Text(
                    str.perms.autostart,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Tang.on,
                )
                Text(
                    OemStartup.path,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.on,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    str.perms.autostartBody,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        SquishButton(
            label = if (readyToGo) str.perms.start else str.perms.grantFirst,
            sticker = if (readyToGo) Emerald else Violet,
            modifier = Modifier.fillMaxWidth(),
        ) {
            if (!readyToGo) {
                haptics.reject()
                return@SquishButton
            }
            haptics.confirm()
            onDone()
        }

        if (!readyToGo) {
            Spacer(Modifier.height(10.dp))
            Text(
                str.perms.mustHave,
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.accent,
            )
        }
    }

    }
}

/**
 * Whether a permission is on, said in a way that survives a glance.
 *
 * This used to be a 12dp dot whose only difference between granted and not was
 * its fill colour. On a cream card, at arm's length, both states read as
 * "there is a dot there" — people could not tell what they had already done,
 * so they either re-tapped grants they had or skipped ones they had not.
 *
 * A word plus a mark is unambiguous even for someone who cannot separate the
 * two greens.
 */
@Composable
private fun StateChip(on: Boolean) {
    val str = strings()
    val shape = RoundedCornerShape(Paper.ChipRadius)
    if (on) {
        Row(
            Modifier
                .clip(shape)
                .background(Mint.fill)
                .border(2.dp, Mint.edge, shape)
                .padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("✓", style = MaterialTheme.typography.titleMedium, color = Mint.on)
            Spacer(Modifier.width(6.dp))
            Text(str.perms.on, style = MaterialTheme.typography.labelSmall, color = Mint.on)
        }
    } else {
        // Glass on the chip someone still needs to tap, not the one that's
        // already done — a chip inviting a tap is exactly the kind of small,
        // frequently-touched control the specular highlight was built for;
        // a settled confirmation badge has nothing left to invite.
        LiquidGlass(radius = Paper.ChipRadius, tint = Violet.fill) {
            Row(
                Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("→", style = MaterialTheme.typography.titleMedium, color = Violet.on)
                Spacer(Modifier.width(6.dp))
                Text(str.perms.grant, style = MaterialTheme.typography.labelSmall, color = Violet.on)
            }
        }
    }
}

/**
 * The hover-info tooltip from the reference, adapted for a touch screen —
 * tap the mark instead of hovering it, tap anywhere else to dismiss. Built
 * for exactly one spot: Crown Mode's own permission card, the one
 * permission on this whole screen serious enough (an actual uninstall
 * lock) that "what does turning this on actually do" deserves its own
 * answer right there, not just the shorter line already under the title.
 */
@Composable
private fun InfoTooltip(text: String) {
    var open by remember { mutableStateOf(false) }
    Box {
        Box(
            Modifier
                .size(18.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.5f))
                .border(1.5.dp, Ink, CircleShape)
                .clickableNoRipple(remember { MutableInteractionSource() }) { open = !open },
            contentAlignment = Alignment.Center,
        ) {
            Text("?", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Ink)
        }
        if (open) {
            Popup(
                alignment = Alignment.TopStart,
                offset = IntOffset(0, 40),
                onDismissRequest = { open = false },
            ) {
                Box(
                    Modifier
                        .width(240.dp)
                        .shadow(8.dp, RoundedCornerShape(12.dp), clip = false)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF17151F))
                        .border(1.dp, Violet.fill.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                ) {
                    Text(text, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
                }
            }
        }
    }
}
