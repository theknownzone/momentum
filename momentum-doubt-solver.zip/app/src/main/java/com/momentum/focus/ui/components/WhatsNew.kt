package com.momentum.focus.ui.components

import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.tr
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay

/**
 * "What's new" after an update: a liquid-glass card that drops in from the top
 * once per version, plus small NEW tags on the new things for 7 days.
 *
 * Glass on capable phones = translucent white, a bright rim, and one diagonal
 * sheen that sweeps across ONCE on arrival (no loop). Cheap phones get the
 * same card as solid paper — same content, no sheen pass.
 *
 * Motion: spring drop (medium bounce) → sheen 700 ms → items rise in with a
 * 50 ms stagger. Auto-hides after 9 s; tap "Got it" or swipe-free tap anywhere
 * on the card to close.
 */
object WhatsNew {
    private const val PREFS = "momentum_whatsnew"
    private const val KEY_SEEN = "seen_version"
    private const val KEY_SINCE = "new_since"
    private const val NEW_FOR_MS = 7L * 24 * 60 * 60 * 1000

    /** What this build added. Keep it to the few things a user can see. */
    val items: List<Pair<String, String>>
        get() = listOf(
            tr("Urge Predictor", "अर्ज प्रेडिक्टर") to tr("Learns your danger hours. Warns 10 min before.", "तुम्हारे खतरे के घंटे सीखता है। 10 मिनट पहले बताता है।"),
            tr("Screen Time Roast", "स्क्रीन टाइम रोस्ट") to tr("Your week as a story card. Stats tab.", "तुम्हारा हफ़्ता, एक स्टोरी कार्ड। Stats टैब।"),
            tr("Lock-in Reel", "लॉक-इन रील") to tr("15-sec study reel after a 10m+ session.", "10 मिनट+ सेशन के बाद 15 सेकंड की रील।"),
            tr("Momentum Score", "Momentum स्कोर") to tr("One number on Home. Tap for the breakdown.", "Home पर एक नंबर। टैप करो पूरा देखने को।"),
            tr("Shield Doctor", "शील्ड डॉक्टर") to tr("If blocking ever stops, it tells you why + fixes it.", "ब्लॉकिंग रुके तो वजह बताकर ठीक करवाता है।"),
            tr("Fair pay", "सही कमाई") to tr("Phone-down study now earns. Night scrolls cost 2×.", "फ़ोन रखकर पढ़ाई अब कमाती है। रात की स्क्रॉल 2×।"),
        )

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** True once per installed version (never on a fresh install). */
    fun shouldShow(c: Context): Boolean {
        val v = Updater.currentVersion(c)
        val p = prefs(c)
        val seen = p.getString(KEY_SEEN, null)
        if (seen == v) return false
        p.edit().putString(KEY_SEEN, v).putLong(KEY_SINCE, System.currentTimeMillis()).apply()
        return seen != null
    }

    /** NEW tags show for 7 days after this version first opened. */
    fun isFresh(c: Context): Boolean {
        val since = prefs(c).getLong(KEY_SINCE, 0L)
        return since > 0L && System.currentTimeMillis() - since < NEW_FOR_MS
    }
}

@Composable
fun WhatsNewPopup(onDone: () -> Unit) {
    val glass = rememberCanBlur()
    val haptics = rememberHaptics()
    val drop = remember { Animatable(0f) }
    val sheen = remember { Animatable(-0.4f) }
    LaunchedEffect(Unit) {
        Sfx.play(Sound.WHOOSH)
        drop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
        if (glass) sheen.animateTo(1.4f, tween(700, easing = FastOutSlowInEasing))
    }
    LaunchedEffect(Unit) { delay(9000); onDone() }

    val shape = RoundedCornerShape(26.dp)
    Box(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
        Column(
            Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    translationY = (1f - drop.value) * -260.dp.toPx()
                    alpha = drop.value.coerceIn(0f, 1f)
                }
                .clip(shape)
                .background(
                    if (glass) Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.82f), Color.White.copy(alpha = 0.62f)))
                    else Brush.verticalGradient(listOf(CreamCard, CreamCard))
                )
                .border(1.5.dp, if (glass) Color.White else Ink, shape)
                .border(0.5.dp, Ink.copy(alpha = 0.25f), shape)
                .drawWithContent {
                    drawContent()
                    if (glass && sheen.value in -0.3f..1.3f) {
                        val x = size.width * sheen.value
                        drawRect(
                            Brush.linearGradient(
                                listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent),
                                start = Offset(x - 120f, 0f), end = Offset(x + 120f, size.height),
                            )
                        )
                    }
                }
                .clickableNoRipple(remember { MutableInteractionSource() }) { haptics.tap(); onDone() }
                .padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                NewTag()
                Spacer(Modifier.width(8.dp))
                Text(tr("What's new in Momentum", "Momentum में नया क्या है"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = Ink, modifier = Modifier.weight(1f))
                Text(tr("Got it", "ठीक है"), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Tang.accent)
            }
            Spacer(Modifier.height(10.dp))
            WhatsNew.items.forEachIndexed { i, (title, sub) ->
                val a = remember { Animatable(0f) }
                LaunchedEffect(Unit) { delay(280L + i * 50L); a.animateTo(1f, tween(220, easing = FastOutSlowInEasing)) }
                Row(
                    Modifier.padding(vertical = 4.dp).graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 10.dp.toPx() },
                    verticalAlignment = Alignment.Top,
                ) {
                    Box(Modifier.padding(top = 6.dp).size(8.dp).clip(RoundedCornerShape(50)).background(StickerCycle[i % StickerCycle.size].fill).border(1.dp, Ink, RoundedCornerShape(50)))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Ink)
                        Text(sub, style = MaterialTheme.typography.bodySmall, color = InkMid)
                    }
                }
            }
        }
    }
}

/** Small ink "NEW" tag. */
@Composable
fun NewTag(modifier: Modifier = Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(6.dp)).background(Ink).padding(horizontal = 6.dp, vertical = 1.dp)
    ) {
        Text(tr("NEW", "नया"), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, color = Butter.fill)
    }
}

/** NEW tag that only appears for 7 days after the update that added it. */
@Composable
fun NewBadge(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val fresh = remember { WhatsNew.isFresh(ctx) }
    if (fresh) NewTag(modifier)
}
