package com.momentum.focus.ui.components

import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.tr
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay

/**
 * NEW tags for 7 days after an update. The old glass "What's new" popup and
 * its hand-written item list (stale for builds at a time) were removed on
 * 2026-10-07: UpdateLanded + assets/release_notes.md replace them.
 */
object WhatsNew {
    private const val PREFS = "momentum_whatsnew"
    private const val KEY_SEEN = "seen_version"
    private const val KEY_SINCE = "new_since"
    private const val NEW_FOR_MS = 7L * 24 * 60 * 60 * 1000

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Starts the 7-day NEW-tag window for this version (UpdateLanded). */
    fun markShown(c: Context) {
        val v = Updater.currentVersion(c)
        val p = prefs(c)
        if (p.getString(KEY_SEEN, null) == v) return
        p.edit().putString(KEY_SEEN, v).putLong(KEY_SINCE, System.currentTimeMillis()).apply()
    }

    /** NEW tags show for 7 days after this version first opened. */
    fun isFresh(c: Context): Boolean {
        val since = prefs(c).getLong(KEY_SINCE, 0L)
        return since > 0L && System.currentTimeMillis() - since < NEW_FOR_MS
    }
}

/** Small ink "NEW" tag. */
@Composable
fun NewTag(modifier: Modifier = Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(6.dp)).background(Ink).padding(horizontal = 6.dp, vertical = 1.dp)
    ) {
        Text(tr("NEW", "नया"), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, color = Butter.fill)
    }
}

/** NEW tag that only appears for 7 days after the update that added it. */
@Composable
fun NewBadge(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val fresh = remember { WhatsNew.isFresh(ctx) }
    if (fresh) NewTag(modifier)
}
