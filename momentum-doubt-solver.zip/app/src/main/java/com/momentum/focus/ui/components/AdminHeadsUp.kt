package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.tr
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

/**
 * Shown right before Android's device-admin screen when Crown is armed.
 *
 * Owner recording: the system "Activate device admin app?" page, then on
 * Xiaomi/Poco/Redmi a red DANGER page ("Erase all data…") with an 8-second
 * OK countdown, appeared with no warning — scary enough to make a student
 * back out. Three plain steps, said first, so it's expected, not alarming.
 * Built on FitDialog, so the button is always on screen.
 */
@Composable
fun AdminHeadsUp(onContinue: () -> Unit, onCancel: () -> Unit) {
    val haptics = rememberHaptics()
    FitDialog(onCancel) { maxH ->
        Box(
            Modifier.fillMaxSize().background(Ink.copy(alpha = 0.55f)).clickable(onClick = onCancel),
            contentAlignment = Alignment.BottomCenter,
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                    .heightIn(max = maxH)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Cream)
                    .border(Paper.Outline, Ink, RoundedCornerShape(24.dp))
                    .clickable(enabled = false) {},
            ) {
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(20.dp)) {
                    Text(tr("One last step", "बस एक आख़िरी स्टेप"), style = MaterialTheme.typography.labelSmall, color = Tang.accent)
                    Text(
                        tr("Your phone will ask to stop uninstalling Momentum.", "फ़ोन पूछेगा कि Momentum अनइंस्टॉल रोकना है या नहीं।"),
                        style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, color = Ink,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        tr("That's the whole point of Crown. Some phones make it look scary — it isn't. Momentum can't read or erase anything.",
                           "यही Crown का काम है। कुछ फ़ोन इसे डरावना दिखाते हैं — डरने की बात नहीं। Momentum कुछ पढ़ या मिटा नहीं सकता।"),
                        style = MaterialTheme.typography.bodyMedium, color = InkMid,
                    )
                    Spacer(Modifier.height(14.dp))
                    listOf(
                        tr("Tap \"Activate this device admin app\".", "\"Activate this device admin app\" दबाओ।"),
                        tr("Xiaomi / Redmi / Poco: a red \"Danger\" page shows. Tick the box at the bottom.", "Xiaomi / Redmi / Poco: लाल \"Danger\" पेज आएगा। नीचे का बॉक्स टिक करो।"),
                        tr("Wait for the OK timer to finish, then tap OK. You'll come right back.", "OK का टाइमर ख़त्म होने दो, फिर OK दबाओ। आप वापस यहीं आ जाओगे।"),
                    ).forEachIndexed { i, step ->
                        Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
                            Box(Modifier.size(24.dp).clip(CircleShape).background(Ink), contentAlignment = Alignment.Center) {
                                Text("${i + 1}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, color = Butter.fill)
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(step, style = MaterialTheme.typography.bodyMedium, color = Ink, modifier = Modifier.weight(1f))
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        tr("You can switch Crown off from Focus once the lock ends.", "लॉक ख़त्म होने के बाद Focus से Crown बंद कर सकते हो।"),
                        style = MaterialTheme.typography.bodySmall, color = InkMid,
                    )
                }
                Column(Modifier.padding(start = 20.dp, end = 20.dp, bottom = 16.dp)) {
                    SquishButton(tr("Continue", "आगे बढ़ो"), Marigold, Modifier.fillMaxWidth()) { haptics.confirm(); onContinue() }
                    Text(
                        tr("Not now", "अभी नहीं"),
                        style = MaterialTheme.typography.bodyMedium, color = InkMid,
                        modifier = Modifier.align(Alignment.CenterHorizontally).clickable(onClick = onCancel).padding(10.dp),
                    )
                }
            }
        }
    }
}
