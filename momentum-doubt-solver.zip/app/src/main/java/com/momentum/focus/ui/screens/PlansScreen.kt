package com.momentum.focus.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.composed
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.ai.Doubt
import com.momentum.focus.ai.Mock
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.ui.components.breathingGradient
import com.momentum.focus.ui.components.AtmosphereGlow
import com.momentum.focus.ui.components.CrownMark
import com.momentum.focus.ui.components.GhostTypography
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileObject
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Three tiers now: Free, Pro, Pro Plus.
 *
 * IMPORTANT — read before wiring a real purchase to the Pro button:
 * the licence system in this codebase (data/License.kt, AppData.premium) has
 * exactly one paid state — a boolean. There is no tier field anywhere. So as
 * shipped here, both the Pro and Pro Plus buttons call the same [onBuy] and
 * both flip the same [AppData.premium] flag — buying "Pro" currently grants
 * everything Pro Plus lists too, because there is nothing downstream able to
 * grant less. The feature split below is real and intentional (see the
 * comment above [ProPlusExtra]), but it is a pricing-page split only until
 * License carries a tier and Ai.kt / FocusScreen.kt check it. Wiring that is
 * a real follow-up, not a checkbox on this file.
 *
 * Free stays exactly what it was: nothing that blocks a distraction costs
 * money — the shield, the feed guard, pact and panic are free and stay free.
 */
private const val GHOST = "PLANS"

/**
 * A glossy sphere for the icon badges — the "real 3D" pass on this screen.
 *
 * Four layers, every one a plain radial or linear gradient, nothing blurred:
 * a soft ambient shadow underneath (built from a handful of concentric
 * rings rather than [androidx.compose.ui.draw.blur], which is API 31+ and
 * silently does nothing below that — see [Aura] for the same rule), a base
 * fill lit from the upper-left, a bright rim arc on the lower-right where
 * the light wraps round the far edge, and a small specular highlight where
 * a real glass sphere would catch the light source directly. Content sits
 * on top, centred, like an object resting inside the sphere rather than
 * printed on a flat disc.
 */
@Composable
private fun Orb3D(
    size: Dp,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    // Off specifically for the one call site that wraps this in
    // ChromaticRing — that ring already carries its own visual weight
    // around the orb, and Orb3D's own five-ring ambient shadow, sized to
    // spill a little past its own edge, was landing inside the ring's
    // small 12dp margin and reading as one blurred, overlapping mess
    // rather than two distinct effects.
    dropShadow: Boolean = true,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val r = this.size.minDimension / 2f
            val c = Offset(this.size.width / 2f, this.size.height / 2f)
            val lightCenter = Offset(c.x - r * 0.38f, c.y - r * 0.42f)

            // Ambient shadow: rings fading outward instead of a blur, so it
            // reads soft on every API level this app ships to.
            if (dropShadow) {
                val shadowCenter = Offset(c.x + r * 0.10f, c.y + r * 0.32f)
                for (i in 5 downTo 1) {
                    drawCircle(
                        color = Color.Black.copy(alpha = 0.045f * i),
                        radius = r * (1f + 0.06f * i),
                        center = shadowCenter,
                    )
                }
            }

            // Base fill, lit from the upper-left corner.
            val top = colors.first()
            val bottom = colors.last()
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(top.lighten(0.30f), top, bottom.darken(0.30f)),
                    center = lightCenter,
                    radius = r * 1.9f,
                ),
                radius = r,
                center = c,
            )

            // Volume: a dark wash creeping in from the edge opposite the
            // light, so the sphere reads round rather than flat and tinted.
            drawCircle(
                brush = Brush.radialGradient(
                    0f to Color.Transparent,
                    0.6f to Color.Transparent,
                    1f to Color.Black.copy(alpha = 0.22f),
                    center = c,
                    radius = r,
                ),
                radius = r,
                center = c,
            )

            // Rim light: the edge glow you get where a lit sphere meets its
            // own shadowed side, always on the far side from lightCenter.
            drawArc(
                color = Color.White.copy(alpha = 0.30f),
                startAngle = 15f,
                sweepAngle = 110f,
                useCenter = false,
                topLeft = Offset(c.x - r * 0.92f, c.y - r * 0.92f),
                size = Size(r * 1.84f, r * 1.84f),
                style = Stroke(width = r * 0.09f),
            )

            // Specular highlight — the one thing that makes it read as
            // glass/glossy rather than a painted flat gradient circle.
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White.copy(alpha = 0.65f), Color.Transparent),
                    center = lightCenter,
                    radius = r * 0.5f,
                ),
                radius = r * 0.5f,
                center = lightCenter,
            )
        }
        content()
    }
}

@Composable
fun PlansScreen(
    data: AppData,
    onBuy: () -> Unit,
    onRedeem: suspend (String) -> Boolean,
    onRemove: () -> Unit,
    onDone: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    var keyOpen by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Color(0xFF060612))) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.radialGradient(
                    listOf(Sky.fill.copy(alpha = 0.20f), Color.Transparent),
                    center = Offset(size.width * 0.18f, 0f),
                    radius = size.width * 0.9f,
                ),
            )
            drawRect(
                brush = Brush.radialGradient(
                    listOf(Lilac.fill.copy(alpha = 0.16f), Color.Transparent),
                    center = Offset(size.width * 0.88f, size.height * 0.35f),
                    radius = size.width * 0.85f,
                ),
            )
            drawRect(
                brush = Brush.radialGradient(
                    listOf(GoldNeon.copy(alpha = 0.10f), Color.Transparent),
                    center = Offset(size.width * 0.5f, size.height * 0.9f),
                    radius = size.width * 0.95f,
                ),
            )
        }

        Box(Modifier.fillMaxSize().padding(top = 260.dp)) {
            GhostTypography(word = "PREMIUM", modifier = Modifier.fillMaxSize())
        }
        AtmosphereGlow(modifier = Modifier.fillMaxSize())

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 24.dp, bottom = 28.dp),
        ) {
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val density = LocalDensity.current
            val measurer = rememberTextMeasurer()
            val tracking = 0.42.em
            val ghostSize = remember(maxWidth, density) {
                val probe = 40.sp
                val measured = measurer.measure(
                    GHOST,
                    TextStyle(
                        fontSize = probe,
                        letterSpacing = tracking,
                        fontWeight = FontWeight.Bold,
                    ),
                ).size.width.toFloat()
                val trailing = with(density) { probe.toPx() } * 0.42f
                val target = with(density) { maxWidth.toPx() }
                if (measured <= trailing) probe else probe * (target / (measured - trailing))
            }
            Text(
                GHOST,
                fontSize = ghostSize,
                lineHeight = ghostSize,
                letterSpacing = tracking,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Clip,
                color = Tang.accent.copy(alpha = 0.13f),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .offset(y = (-18).dp),
            )
        Column(Modifier.fillMaxWidth()) {
            Text(str.plans.kicker, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.55f))
            Spacer(Modifier.height(2.dp))
            Text(
                str.plans.title,
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                str.plans.subtitle,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.6f),
            )
        }
        }

        Spacer(Modifier.height(26.dp))

        // Three cards, one swipe apart, instead of one long scroll — a
        // pricing decision is a comparison, and comparing means holding two
        // things in view at once mentally even if only one is on screen; a
        // vertical scroll buries the other two below the fold the moment
        // you land on any one of them. Motion blur scales with how fast the
        // page is moving (pageOffset), not a fixed duration, so a flick
        // blurs hard and a slow drag barely blurs at all — the same
        // relationship a real camera has to speed, not an animation
        // pretending to.
        val pagerState = androidx.compose.foundation.pager.rememberPagerState(initialPage = 0) { 3 }
        val pagerScope = rememberCoroutineScope()
        FloatingPlanNav(
            pagerState = pagerState,
            labels = listOf("Pro Plus", "Pro", "Free"),
            onSelect = { i ->
                haptics.tick()
                pagerScope.launch { pagerState.animateScrollToPage(i) }
            },
        )
        Spacer(Modifier.height(14.dp))
        androidx.compose.foundation.pager.HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxWidth(),
            pageSpacing = 4.dp,
        ) { page ->
            val pageOffset = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)
            val absOffset = kotlin.math.abs(pageOffset).coerceIn(0f, 1f)
            Box(
                Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        alpha = 1f - absOffset * 0.30f
                        scaleX = 1f - absOffset * 0.06f
                        scaleY = 1f - absOffset * 0.06f
                        if (android.os.Build.VERSION.SDK_INT >= 31) {
                            val blurPx = absOffset * 16f
                            renderEffect = if (blurPx > 0.4f) {
                                android.graphics.RenderEffect
                                    .createBlurEffect(blurPx, blurPx, android.graphics.Shader.TileMode.CLAMP)
                                    .asComposeRenderEffect()
                            } else null
                        }
                    },
            ) {
                when (page) {
                    0 -> {
        // ---- Pro Plus — the tier the screen is built to sell --------------
        Box(Modifier.fillMaxWidth()) {
            Aura(
                color = if (data.premium) Mint.accent else GoldNeon,
                strength = if (data.premium) 0.30f else 0.55f,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp)
                        .shadow(18.dp, RoundedCornerShape(26.dp), clip = false, ambientColor = Color.Black, spotColor = Color.Black)
                        .clip(RoundedCornerShape(26.dp))
                        .border(
                            1.4.dp,
                            (if (data.premium) Mint.accent else GoldNeon).copy(alpha = 0.55f),
                            RoundedCornerShape(26.dp),
                        )
                        .livingBorder(color = if (data.premium) Mint.accent else GoldNeon),
                ) {
                    // Real glass, not a gradient standing in for it: two
                    // colour blobs, genuinely blurred (Modifier.blur is a
                    // RenderEffect — API 31+, a documented no-op below that,
                    // same rule the rest of this codebase already follows
                    // for Aura/GlassPanel), sitting under a translucent
                    // wash rather than the old fully-opaque one. Below API
                    // 31 the blur silently drops out and this is exactly
                    // the two solid blobs it always was — never broken,
                    // just plainer on the phones that can't render it.
                    Box(
                        Modifier
                            .matchParentSize()
                            .blur(30.dp),
                    ) {
                        Box(
                            Modifier
                                .align(Alignment.TopStart)
                                .offset(x = (-30).dp, y = (-20).dp)
                                .size(160.dp)
                                .background(
                                    (if (data.premium) Mint.accent else GoldNeon).copy(alpha = 0.45f),
                                    CircleShape,
                                ),
                        )
                        Box(
                            Modifier
                                .align(Alignment.BottomEnd)
                                .offset(x = 30.dp, y = 30.dp)
                                .size(180.dp)
                                .background(
                                    (if (data.premium) Sky.fill else Tang.fill).copy(alpha = 0.40f),
                                    CircleShape,
                                ),
                        )
                    }
                    Box(
                        Modifier
                            .matchParentSize()
                            .background(
                                if (data.premium) {
                                    // The actual leaderboard-gold from the
                                    // reference — the whole card filled and
                                    // vivid, the way its #1 row is a solid
                                    // wash top to bottom, not a dark card
                                    // wearing a highlight. Kept in this
                                    // app's own Mint (its established
                                    // "yours / unlocked" colour everywhere
                                    // else) rather than switching this one
                                    // card to literal gold. Saturated and
                                    // dark enough, not bright-light mint,
                                    // because the card's white text needed
                                    // to stay readable on it.
                                    Brush.verticalGradient(
                                        listOf(Mint.accent, Color(0xFF0B3D26)),
                                    )
                                } else {
                                    Brush.verticalGradient(
                                        listOf(Color(0xFF242032).copy(alpha = 0.82f), Color(0xFF15121D).copy(alpha = 0.88f)),
                                    )
                                },
                            ),
                    )
                    if (data.premium) {
                        // A brighter sheen along the very top, the way the
                        // reference's #1 row still catches extra light at
                        // its own upper edge even though the whole row is
                        // already gold.
                        Box(
                            Modifier
                                .matchParentSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.White.copy(alpha = 0.22f), Color.Transparent),
                                        endY = 90f,
                                    ),
                                ),
                        )
                        Box(
                            Modifier
                                .align(Alignment.TopCenter)
                                .fillMaxWidth(0.7f)
                                .height(2.dp)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(Color.Transparent, Color.White.copy(alpha = 0.85f), Color.Transparent),
                                    ),
                                ),
                        )
                    }
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top,
                    ) {
                        ChromaticRing(size = 52.dp) {
                            Orb3D(
                                size = 52.dp,
                                colors = if (data.premium) listOf(Mint.fill, Mint.accent) else listOf(GoldNeon, Tang.fill),
                                dropShadow = false,
                            ) {
                                CrownMark(size = 25.dp)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                if (data.premium) str.plans.yours else "\u20b9399",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                            )
                            if (!data.premium) {
                                Text(
                                    "One-time \u00b7 yours forever",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.55f),
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Text(
                        "${str.plans.productName} PLUS",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "Everything in Pro, and nothing left locked.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.55f),
                    )

                    Spacer(Modifier.height(16.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.08f)))
                    Spacer(Modifier.height(16.dp))

                    // Pro Plus exclusive: everything Pro has, plus the two
                    // things this codebase can actually gate hardest — full
                    // mode access and a doubt from a photo — plus Crown, which
                    // is a commitment device, not a blocker, so it belongs on
                    // the top tier rather than the free one.
                    PlanLine(str.plans.allModes, str.plans.allModesNote, highlight = true)
                    PlanLine(str.plans.photoPdf)
                    PlanLine(str.plans.crownMode, str.plans.crownNote)
                    PlanLine(str.plans.allThemes, str.plans.allThemesNote)
                    PlanLine(str.plans.mockTest, str.plans.mockNote(Mock.COUNT))
                    PlanLine(str.plans.posterBackdrop)
                    PlanLine(str.plans.perSessionLabel, str.plans.perSession(Doubt.PER_SESSION, Doubt.FREE_SESSION))

                    Spacer(Modifier.height(18.dp))
                    val buyInteraction = remember { MutableInteractionSource() }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .then(
                                if (data.premium) Modifier
                                else Modifier.shadow(10.dp, RoundedCornerShape(16.dp), clip = false),
                            )
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (data.premium) SolidColor(Color.White.copy(alpha = 0.06f))
                                else Brush.horizontalGradient(listOf(GoldNeon, Tang.fill)),
                            )
                            .then(
                                if (data.premium) Modifier
                                else Modifier.breathingGradient(colors = listOf(Color.White, Mint.accent)),
                            )
                            .border(
                                1.dp,
                                if (data.premium) Color.White.copy(alpha = 0.14f) else Color.Transparent,
                                RoundedCornerShape(16.dp),
                            )
                            .clickableNoRipple(
                                buyInteraction,
                                enabled = !data.premium,
                            ) { haptics.confirm(); onBuy() }
                            .padding(vertical = 15.dp, horizontal = 18.dp),
                    ) {
                        Text(
                            if (data.premium) str.plans.unlocked else str.plans.unlockLifetime,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (data.premium) Color.White.copy(alpha = 0.85f) else Ink,
                            modifier = Modifier.align(Alignment.Center),
                        )
                        if (!data.premium) {
                            // The icon-reveal button from the reference — a
                            // small circle that widens toward the button's
                            // own edge on press, an arrow appearing as it
                            // does, rather than the icon just always sitting
                            // there or never appearing at all.
                            val buyPressed by buyInteraction.collectIsPressedAsState()
                            val revealW by animateDpAsState(if (buyPressed) 34.dp else 22.dp, tween(220), label = "buy-reveal")
                            Box(
                                Modifier
                                    .align(Alignment.CenterEnd)
                                    .size(width = revealW, height = 22.dp)
                                    .clip(RoundedCornerShape(11.dp))
                                    .background(Color.White),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("\u2192", color = Ink, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    if (data.premium) {
                        var confirmRemove by remember { mutableStateOf(false) }
                        Text(
                            "Key: ${License.pretty(data.licenseKey)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.55f),
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    haptics.tap(); confirmRemove = true
                                }
                                .padding(6.dp),
                        )
                        if (confirmRemove) {
                            Dialog(onDismissRequest = { confirmRemove = false }) {
                                Column(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(24.dp))
                                        .background(Color(0xFF1B1826))
                                        .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(24.dp))
                                        .padding(18.dp),
                                ) {
                                    Text(
                                        "Key hatao?",
                                        style = MaterialTheme.typography.headlineSmall,
                                        color = Color.White,
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        "Premium is phone se hat jayega. Wahi key doosre " +
                                            "phone pe daal sakte ho.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White.copy(alpha = 0.6f),
                                    )
                                    Spacer(Modifier.height(16.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(
                                            Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(Mint.fill)
                                                .clickableNoRipple(
                                                    remember { MutableInteractionSource() },
                                                ) { haptics.tap(); confirmRemove = false }
                                                .padding(vertical = 12.dp),
                                            contentAlignment = Alignment.Center,
                                        ) {
                                            Text("Rehne do", style = MaterialTheme.typography.titleMedium, color = Mint.on)
                                        }
                                        Box(
                                            Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(14.dp))
                                                .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(14.dp))
                                                .clickableNoRipple(
                                                    remember { MutableInteractionSource() },
                                                ) {
                                                    haptics.press()
                                                    confirmRemove = false
                                                    onRemove()
                                                }
                                                .padding(vertical = 12.dp),
                                            contentAlignment = Alignment.Center,
                                        ) {
                                            Text("Hatao", style = MaterialTheme.typography.titleMedium, color = Tang.accent)
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Box(
                            Modifier
                                .align(Alignment.CenterHorizontally)
                                .clip(RoundedCornerShape(999.dp))
                                .border(1.dp, Sky.accent.copy(alpha = 0.55f), RoundedCornerShape(999.dp))
                                .background(Color.White.copy(alpha = 0.04f))
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    haptics.tap(); keyOpen = true
                                }
                                .padding(horizontal = 16.dp, vertical = 9.dp),
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.VpnKey,
                                    contentDescription = null,
                                    tint = Sky.accent,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(Modifier.width(7.dp))
                                Text(
                                    str.plans.haveKey,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Sky.accent,
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(20.dp))
                    Box {
                        // The glass-on-blurred-glow background from the
                        // reference, taken more literally this time — one
                        // large, overlapping swirl of colour reading as a
                        // single abstract glow behind the glass, not three
                        // separate small dots that stayed legible as three
                        // separate circles even after blurring. Bigger,
                        // more overlap, and a heavier blur radius is what
                        // actually fuses them into one shape the way the
                        // reference's smoke-like glow reads as one thing.
                        Box(Modifier.matchParentSize().blur(60.dp)) {
                            Box(
                                Modifier
                                    .align(Alignment.TopStart)
                                    .offset(x = (-40).dp, y = (-10).dp)
                                    .size(180.dp)
                                    .background(Lilac.fill.copy(alpha = 0.40f), CircleShape),
                            )
                            Box(
                                Modifier
                                    .align(Alignment.TopEnd)
                                    .offset(x = 30.dp, y = 20.dp)
                                    .size(160.dp)
                                    .background(Sky.fill.copy(alpha = 0.38f), CircleShape),
                            )
                            Box(
                                Modifier
                                    .align(Alignment.CenterStart)
                                    .offset(x = 10.dp)
                                    .size(150.dp)
                                    .background(Candy.fill.copy(alpha = 0.30f), CircleShape),
                            )
                            Box(
                                Modifier
                                    .align(Alignment.BottomEnd)
                                    .offset(x = 20.dp, y = 30.dp)
                                    .size(190.dp)
                                    .background(Mint.fill.copy(alpha = 0.34f), CircleShape),
                            )
                        }
                    Column {
                    Text(
                        if (data.premium) str.plans.ownedHeader else str.plans.lockedHeader,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.45f),
                    )
                    Spacer(Modifier.height(10.dp))

                    PremiumPeek(
                        locked = !data.premium,
                        title = str.plans.peekModesTitle,
                        body = str.plans.peekModesBody,
                        art = TileArt.Person,
                        tone = Lilac,
                    )
                    Spacer(Modifier.height(8.dp))
                    PremiumPeek(
                        locked = !data.premium,
                        title = str.plans.peekPageTitle,
                        body = str.plans.peekPageBody,
                        art = TileArt.Camera,
                        tone = Sky,
                    )
                    Spacer(Modifier.height(8.dp))
                    PremiumPeek(
                        locked = !data.premium,
                        title = str.plans.peekThemesTitle,
                        body = str.plans.peekThemesBody,
                        art = TileArt.Palette,
                        tone = Mint,
                    )
                    }
                    }

                    Spacer(Modifier.height(14.dp))
                    Text(
                        str.plans.nothingBlocked,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.align(Alignment.CenterHorizontally),
                    )
                    }
                }
            }

            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (-13).dp),
            ) {
                Tag(if (data.premium) str.plans.yours.uppercase() else str.plans.bestValue, if (data.premium) Mint else Butter, crown = true)
            }
        }
                    }
                    1 -> {
        // ---- Pro — the middle tier ------------------------------------------
        // No aura, thinner accent border: enough to read as a paid tier
        // without competing with Pro Plus above it for the eye.
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp)
                .clip(RoundedCornerShape(22.dp))
                .border(1.dp, Sky.accent.copy(alpha = 0.35f), RoundedCornerShape(22.dp)),
        ) {
            Box(Modifier.matchParentSize().blur(24.dp)) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 20.dp, y = (-16).dp)
                        .size(120.dp)
                        .background(Sky.accent.copy(alpha = 0.35f), CircleShape),
                )
            }
            Box(Modifier.matchParentSize().background(Color(0xFF191726).copy(alpha = 0.86f)))
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Orb3D(size = 38.dp, colors = listOf(Sky.fill, Sky.accent)) {
                        TileObject(art = TileArt.Medal, fill = Color.White, size = 17.dp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Sky.fill.copy(alpha = 0.18f))
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                    ) {
                        Text("PRO", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Sky.accent)
                    }
                }
                Text("\u20b9199", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(Modifier.height(2.dp))
            Text(
                "One-time \u00b7 study tools without the full unlock",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.5f),
            )
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.08f)))
            Spacer(Modifier.height(12.dp))
            PlanLine(str.plans.allThemes, str.plans.allThemesNote)
            PlanLine(str.plans.mockTest, str.plans.mockNote(Mock.COUNT))
            PlanLine(str.plans.posterBackdrop)
            PlanLine(str.plans.perSessionLabel, str.plans.perSession(Doubt.PER_SESSION, Doubt.FREE_SESSION))
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White.copy(alpha = 0.06f))
                    .border(1.dp, Sky.accent.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                    .clickableNoRipple(
                        remember { MutableInteractionSource() },
                        enabled = !data.premium,
                    ) { haptics.confirm(); onBuy() }
                    .padding(vertical = 13.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (data.premium) str.plans.unlocked else "Get Pro",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (data.premium) Color.White.copy(alpha = 0.7f) else Sky.accent,
                )
            }
            }
        }
                    }
                    else -> {
        // ---- Free — flat, quiet, no glow -----------------------------------
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF121019))
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(22.dp))
                .padding(18.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Orb3D(size = 34.dp, colors = listOf(Color(0xFF6A6878), Color(0xFF38364A))) {
                        TileObject(art = TileArt.Shield, fill = Color.White.copy(alpha = 0.85f), size = 15.dp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White.copy(alpha = 0.08f))
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                    ) {
                        Text("BASIC", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.75f))
                    }
                }
                if (!data.premium) Tag(str.plans.youreOnThis, Mint)
            }
            Spacer(Modifier.height(10.dp))
            Text("\u20b90", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.08f)))
            Spacer(Modifier.height(12.dp))
            PlanLine(str.plans.freeBlocking)
            PlanLine(str.plans.freeFeeds)
            PlanLine(str.plans.freeTimer)
            PlanLine(str.plans.freePact)
            PlanLine(str.plans.freePanic)
            PlanLine(str.plans.freeExamAlerts)
            PlanLine(str.plans.freeStats)
            PlanLine(str.plans.freeStudyMode, str.plans.freeStudyNote(Doubt.FREE_SESSION))
            PlanLine(str.plans.freePoster)
            Spacer(Modifier.height(8.dp))
            Text(
                str.plans.freeThemesNote,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.45f),
            )
        }
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        // Which of the three cards this is — a scroll position has no
        // equivalent of this, which is exactly the "which page am I on"
        // question a swipe interface has to answer that a scroll never
        // needed to.
        Row(
            Modifier.align(Alignment.CenterHorizontally),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            repeat(3) { i ->
                Box(
                    Modifier
                        .size(if (pagerState.currentPage == i) 8.dp else 6.dp)
                        .clip(CircleShape)
                        .background(
                            if (pagerState.currentPage == i) Color.White else Color.White.copy(alpha = 0.25f),
                        ),
                )
            }
        }

        if (keyOpen) {
            LicenseDialog(
                onRedeem = onRedeem,
                onClose = { keyOpen = false },
            )
        }

        Spacer(Modifier.height(20.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                .clickableNoRipple(remember { MutableInteractionSource() }) {
                    haptics.tap(); onDone()
                }
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(str.plans.back, style = MaterialTheme.typography.titleMedium, color = Color.White)
        }
        }
    }
}

@Composable
private fun PlanLine(text: String, note: String? = null, highlight: Boolean = false) {
    Row(
        Modifier.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(18.dp)
                .clip(CircleShape)
                .background(Mint.fill.copy(alpha = 0.92f)),
            contentAlignment = Alignment.Center,
        ) {
            Text("\u2713", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Mint.on)
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text,
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White.copy(alpha = 0.92f),
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.weight(1f, fill = false),
        )
        if (note != null) {
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(GoldNeon.copy(alpha = 0.18f))
                    .border(1.dp, GoldNeon.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 7.dp, vertical = 2.dp),
            ) {
                Text(
                    note,
                    maxLines = 1,
                    softWrap = false,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = GoldNeon,
                )
            }
        }
    }
}

@Composable
private fun Tag(label: String, sticker: Sticker, crown: Boolean = false) {
    Box(
        Modifier
            .shadow(8.dp, RoundedCornerShape(999.dp), clip = false)
            .clip(RoundedCornerShape(999.dp))
            // Glossy pill: lit at the top, darker at the bottom, same idea
            // as the orb badges — a flat sticker fill read as a paper cutout
            // again once the rest of the screen went glass.
            .background(
                Brush.verticalGradient(
                    listOf(sticker.fill.lighten(0.22f), sticker.fill.darken(0.12f)),
                ),
            )
            .drawBehind {
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.45f), Color.Transparent),
                        endY = size.height * 0.5f,
                    ),
                    size = Size(size.width, size.height * 0.5f),
                )
            }
            .padding(horizontal = 14.dp, vertical = 6.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        if (crown) {
            CrownMark(size = 13.dp)
            Spacer(Modifier.width(5.dp))
        }
        Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = sticker.on)
      }
    }
}

@Composable
private fun LicenseDialog(
    onRedeem: suspend (String) -> Boolean,
    onClose: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onClose) {
        Box {
            // The three corner accent dots from the reference glass pill —
            // peeking out from behind the card's rounded edges rather than
            // sitting on top of it, which is what makes them read as light
            // behind glass instead of stickers stuck on the corners.
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .offset(x = (-8).dp, y = (-8).dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Mint.accent),
            )
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 8.dp, y = (-8).dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Lilac.fill),
            )
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .offset(y = 10.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Sky.accent),
            )
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF1B1826))
                .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(24.dp))
                .padding(20.dp),
        ) {
            Text(str.plans.keyTitle, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.5f))
            Spacer(Modifier.height(4.dp))
            Text(
                str.plans.keyHint,
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
            )
            Spacer(Modifier.height(14.dp))

            val keyInteraction = remember { MutableInteractionSource() }
            val keyFocused by keyInteraction.collectIsFocusedAsState()
            val keyGlow by animateFloatAsState(if (keyFocused) 1f else 0f, tween(300), label = "key-glow")
            Box(
                Modifier
                    .fillMaxWidth()
                    .drawBehind {
                        if (keyGlow > 0f) {
                            drawRoundRect(
                                color = Mint.accent.copy(alpha = keyGlow * 0.5f),
                                topLeft = Offset(-6.dp.toPx(), -6.dp.toPx()),
                                size = Size(size.width + 12.dp.toPx(), size.height + 12.dp.toPx()),
                                cornerRadius = CornerRadius(18.dp.toPx()),
                                style = Stroke(width = 3.dp.toPx()),
                            )
                        }
                    },
            ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(24); error = false },
                placeholder = { Text(str.plans.keyPlaceholder, color = Color.White.copy(alpha = 0.35f)) },
                singleLine = true,
                isError = error,
                shape = RoundedCornerShape(14.dp),
                interactionSource = keyInteraction,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Mint.accent,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.22f),
                    cursorColor = Mint.accent,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            }

            if (error) {
                Spacer(Modifier.height(8.dp))
                Text(
                    str.plans.keyWrong,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClose)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(str.plans.cancel, style = MaterialTheme.typography.titleMedium, color = Color.White)
                }
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Mint.fill)
                        .clickableNoRipple(
                            remember { MutableInteractionSource() },
                            enabled = !checking && text.isNotBlank(),
                        ) {
                            checking = true
                            scope.launch {
                                val ok = onRedeem(text)
                                checking = false
                                if (ok) { haptics.confirm(); onClose() }
                                else { haptics.press(); error = true }
                            }
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (checking) str.plans.checking else str.plans.unlock,
                        style = MaterialTheme.typography.titleMedium,
                        color = Mint.on,
                    )
                }
            }
        }
        }
    }
}

@Composable
private fun PremiumPeek(
    locked: Boolean,
    title: String,
    body: String,
    art: TileArt,
    tone: Sticker,
) {
    val chroma = rememberInfiniteTransition(label = "premium-chroma")
    val shift by chroma.animateFloat(
        initialValue = -0.25f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(4200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "premium-chroma-shift",
    )

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .drawBehind {
                // The destination-card wash from the reference — a stronger,
                // single-tone diagonal gradient from the card's own colour,
                // layered under the existing shift-sweep rather than
                // replacing it, so the card reads as "about this colour"
                // at a glance the way a photo card reads as "about this
                // place" before you've read a word of the title.
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            tone.accent.copy(alpha = if (locked) 0.16f else 0.30f),
                            tone.fill.copy(alpha = if (locked) 0.05f else 0.10f),
                            Color.Transparent,
                        ),
                        start = Offset(0f, 0f),
                        end = Offset(size.width * 0.8f, size.height),
                    ),
                )
                val travel = size.width * shift
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Sky.fill.copy(alpha = if (locked) 0.06f else 0.12f),
                            Lilac.fill.copy(alpha = if (locked) 0.07f else 0.13f),
                            Candy.fill.copy(alpha = if (locked) 0.05f else 0.10f),
                            GoldNeon.copy(alpha = if (locked) 0.05f else 0.09f),
                            Sky.fill.copy(alpha = if (locked) 0.06f else 0.12f),
                        ),
                        start = Offset(travel - size.width * 1.25f, 0f),
                        end = Offset(travel + size.width * 1.25f, size.height),
                    ),
                )
                val sheenX = travel - size.width * 0.16f
                drawRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.08f),
                            Color.Transparent,
                        ),
                        startX = sheenX - size.width * 0.16f,
                        endX = sheenX + size.width * 0.16f,
                    ),
                )
            }
            .border(1.dp, Color.White.copy(alpha = if (locked) 0.08f else 0.16f), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .height(72.dp)
            .alpha(if (locked) 0.72f else 1f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Orb3D(size = 46.dp, colors = listOf(tone.fill, tone.accent)) {
            TileObject(art = art, fill = Color.White, size = 21.dp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(1.dp))
            Text(
                body,
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.6f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (locked) {
            Spacer(Modifier.width(8.dp))
            // A real child of the row now, not a Box overlaid on top of it —
            // it used to sit at CenterEnd regardless of how much room the
            // title/body Column actually needed, so a longer body ("Send a
            // page, get an an...") ran its text straight under the badge
            // instead of wrapping before it, since the Column's weight(1f)
            // had no idea the badge was there to leave room for. A shine
            // sweep instead of a flat fill, because "PRO" gating six-figure
            // discovery is worth more than a flat grey tag.
            Box(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Brush.horizontalGradient(listOf(GoldNeon, Color(0xFFB8860B))))
                    .drawBehind {
                        val sheenX = size.width * shift
                        drawRect(
                            brush = Brush.horizontalGradient(
                                colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent),
                                startX = sheenX - size.width * 0.4f,
                                endX = sheenX + size.width * 0.4f,
                            ),
                        )
                    }
                    .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            ) {
                Text("PRO", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Ink)
            }
        }
    }
}

/**
 * The rotating conic-gradient border from the reference — a full ring of
 * colour continuously turning around the card, rather than laserEdge's own
 * short travelling segment. Kept as a separate modifier instead of changing
 * laserEdge itself, since laserEdge is tuned for a subtler "something is
 * happening at the edge" read and this is deliberately the louder,
 * always-on "this card is special" version — the two read as different
 * things and were built for different cards to begin with.
 */
private fun Modifier.livingBorder(color: Color, strokeWidthDp: Dp = 2.dp): Modifier = composed {
    val infinite = rememberInfiniteTransition(label = "living-border")
    val angle by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(3200, easing = LinearEasing)),
        label = "living-angle",
    )
    this.drawWithContent {
        drawContent()
        val strokePx = strokeWidthDp.toPx()
        val inset = strokePx / 2f
        rotate(angle) {
            drawRoundRect(
                brush = Brush.sweepGradient(
                    listOf(
                        Color.Transparent,
                        color.copy(alpha = 0.9f),
                        Color.White,
                        color.copy(alpha = 0.9f),
                        Color.Transparent,
                    ),
                ),
                topLeft = Offset(inset, inset),
                size = Size(size.width - strokePx, size.height - strokePx),
                cornerRadius = CornerRadius(26.dp.toPx() - inset, 26.dp.toPx() - inset),
                style = Stroke(width = strokePx),
            )
        }
    }
}

/**
 * A bright point travelling continuously around a card's own border — the
 * animated ring effect from the reference clip, run along a rectangle's
 * edge instead of a circle's. PathMeasure walks the exact rounded-rect path
 * the border itself follows, so the light rides the actual curve at the
 * corners rather than jumping across them.
 */
private fun Modifier.laserEdge(color: Color, strokeWidthDp: Dp = 1.4.dp): Modifier = composed {
    val infinite = rememberInfiniteTransition(label = "laser-edge")
    val progress by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing)),
        label = "laser-progress",
    )
    this.drawWithContent {
        drawContent()
        val strokePx = strokeWidthDp.toPx()
        val inset = strokePx / 2f
        val cornerPx = 26.dp.toPx() - inset
        val path = Path().apply {
            addRoundRect(
                RoundRect(
                    rect = Rect(inset, inset, size.width - inset, size.height - inset),
                    cornerRadius = CornerRadius(cornerPx, cornerPx),
                ),
            )
        }
        val measure = PathMeasure().apply { setPath(path, forceClosed = true) }
        val len = measure.length
        if (len > 0f) {
            val segment = len * 0.16f
            val start = progress * len
            val end = (start + segment).let { if (it > len) it - len else it }
            val extracted = Path()
            if (end > start) {
                measure.getSegment(start, end, extracted, startWithMoveTo = true)
            } else {
                measure.getSegment(start, len, extracted, startWithMoveTo = true)
                measure.getSegment(0f, end, extracted, startWithMoveTo = true)
            }
            drawPath(
                extracted,
                brush = Brush.linearGradient(listOf(Color.Transparent, color, Color.White)),
                style = Stroke(width = strokePx * 1.8f, cap = StrokeCap.Round),
            )
        }
    }
}

/**
 * The spinning iridescent ring from the reference clip — a Home-button
 * badge there, the Pro Plus crown here, same idea: a sweep gradient
 * rotating continuously around whatever sits inside it, standing in for a
 * physical object catching light rather than a flat colour ring.
 */
@Composable
private fun ChromaticRing(size: Dp, content: @Composable () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "chroma-ring")
    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(3400, easing = LinearEasing)),
        label = "chroma-rotation",
    )
    Box(Modifier.size(size + 12.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            rotate(rotation) {
                drawCircle(
                    brush = Brush.sweepGradient(
                        listOf(
                            Sky.accent, Lilac.fill, Candy.fill, GoldNeon,
                            Mint.fill, Sky.accent,
                        ),
                    ),
                    radius = this.size.minDimension / 2f,
                    style = Stroke(width = 2.2.dp.toPx()),
                )
            }
        }
        content()
    }
}


/**
 * The floating glass pill nav from the reference — a tab bar at the top of
 * Plans, tappable to jump straight to a tier instead of only swiping. A
 * glow breathes behind the glass the whole time, and the active segment
 * gets its own soft highlight plus a haptic tick on every switch, tap or
 * swipe alike, since a swipe already changes [pagerState.currentPage] the
 * same way a tap does.
 */
@Composable
private fun FloatingPlanNav(
    pagerState: androidx.compose.foundation.pager.PagerState,
    labels: List<String>,
    onSelect: (Int) -> Unit,
) {
    val infinite = rememberInfiniteTransition(label = "plan-nav-glow")
    val glow by infinite.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.75f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Reverse),
        label = "glow",
    )
    val current = pagerState.currentPage

    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .size(width = 260.dp, height = 90.dp)
                .blur(36.dp)
                .background(
                    Brush.radialGradient(
                        listOf(Sky.accent.copy(alpha = glow * 0.5f), Color.Transparent),
                    ),
                ),
        )
        Row(
            Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF17151F).copy(alpha = 0.85f))
                .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(20.dp))
                .padding(4.dp),
        ) {
            labels.forEachIndexed { i, label ->
                val selected = i == current
                val bg by animateFloatAsState(if (selected) 1f else 0f, tween(220), label = "seg$i")
                // Tier-tinted like the reference's own Silver/Gold/Platinum
                // glass-radio, rather than every segment lighting up the
                // same flat white — Pro Plus reads as the platinum option,
                // Pro as gold, Free as plain silver, each its own colour
                // the moment it's the selected one.
                val tierColor = when (label) {
                    "Pro Plus" -> Color(0xFFA0D8FF)
                    "Pro" -> Color(0xFFFFD700)
                    else -> Color(0xFFC0C0C0)
                }
                Box(
                    Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(tierColor.copy(alpha = 0.22f * bg))
                        .then(
                            if (selected) Modifier.border(1.dp, tierColor.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                            else Modifier,
                        )
                        .clickableNoRipple(remember { MutableInteractionSource() }) { onSelect(i) }
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                ) {
                    Text(
                        label,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        color = if (selected) tierColor else Color.White.copy(alpha = 0.55f),
                    )
                }
            }
        }
    }
}
