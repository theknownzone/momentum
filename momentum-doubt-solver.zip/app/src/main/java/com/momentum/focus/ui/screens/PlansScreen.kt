package com.momentum.focus.ui.screens

import com.momentum.focus.ui.components.BackPill
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.Sfx
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Lock
import com.momentum.focus.data.tr
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.ai.Doubt
import com.momentum.focus.ai.Mock
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.R
import com.momentum.focus.ui.components.CrownMark
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileObject
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.glowEdge
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.components.ScanningBeam
import com.momentum.focus.ui.components.PowerButton
import com.momentum.focus.ui.components.tierLoop
import com.momentum.focus.ui.components.BreathingOrb
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.launch

/**
 * Three tiers: Free, Pro, Pro Plus — one column, top to bottom, instead of
 * three swipeable pages.
 *
 * REBUILD NOTE — why the pager got removed:
 * The previous version of this screen put Free/Pro/Pro Plus on a
 * HorizontalPager inside a fixed-height box, sharing ONE scroll position
 * that belonged to the outer Column, not to whichever page happened to be
 * showing. Pro Plus carries seven feature lines plus three locked-preview
 * rows; Free and Pro are a third of that height. The moment someone
 * scrolled deep into Pro Plus and then swiped to Free or Pro, the shorter
 * page didn't reach as far down as the leftover scroll offset did, so the
 * screen showed a stretch of blank paper-grid where a card should have
 * been — reproduced on video: switching tabs mid-scroll left an empty gap,
 * and the Pro tab could even render fully blank on first landing. A single
 * scrolling column cannot desync from itself this way: every card sits
 * exactly where its own content places it, always. That is the actual
 * "new structure" this pass delivers — not a re-skin of the old one.
 *
 * Two more fixes that came out of the same recording:
 * - The locked-feature preview rows on Pro Plus were truncating their own
 *   titles ("Friend and…", "Send a pa…") because the title Text capped at
 *   one line. [PremiumPeek] now wraps to two.
 * - Pro and Pro Plus used to share the exact same badge (Medal, on a
 *   coloured circle) — the one spot on the screen where two different
 *   tiers looked like the same product. Pro Plus now gets its own mark:
 *   the app's existing hand-drawn [CrownMark] on a dark roundel.
 *
 * Everything below the header (urgency banner, countdown, social proof,
 * spots-left bar) is unchanged — that content was already right, only the
 * cards under it were rebuilt.
 *
 * IMPORTANT — read before wiring a real purchase to the Pro button:
 * the licence system in this codebase (data/License.kt, AppData.premium) has
 * exactly one paid state — a boolean. There is no tier field anywhere. So as
 * shipped here, both the Pro and Pro Plus buttons call the same [onBuy] and
 * both flip the same [AppData.premium] flag — buying "Pro" currently grants
 * everything Pro Plus lists too, because there is nothing downstream able to
 * grant less. The feature split below is real and intentional, but it is a
 * pricing-page split only until License carries a tier and Ai.kt /
 * FocusScreen.kt check it. Wiring that is a real follow-up, not a checkbox
 * on this file.
 *
 * Free stays exactly what it was: nothing that blocks a distraction costs
 * money — the shield, the feed guard, pact and panic are free and stay free.
 *
 * SECOND PASS — closing gaps against the actual reference file, not memory
 * of it: the first pass kept this screen's existing header copy and dropped
 * the segmented tab bar for the pager-bug reasons above, but never checked
 * those two choices against what the reference mockup actually shows.
 * It shows a "Stop scrolling. / Start winning." headline with a rotated
 * gold chip, a pulsing dot and boxed digit-pairs on the countdown, circular
 * (not plain-emoji) proof avatars, and a Pro Plus/Pro/Free segmented pill.
 * All four are now built to match. The pill is real here too — [SegTabs] —
 * just wired to scroll the one column to a card's position instead of
 * switching pages, which is what keeps it from reopening the bug this file
 * was rebuilt to close.
 */
private const val GHOST = "PLANS"

/**
 * A flat sticker circle with an ink outline and an icon centred inside —
 * every icon badge elsewhere in this app (Settings' action tiles, MyAi's
 * mode picker) is exactly this.
 */
@Composable
private fun PlanIcon(
    sticker: Sticker,
    art: TileArt,
    size: Dp = 40.dp,
    iconSize: Dp = size * 0.42f,
) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(sticker.fill)
            .border(Paper.Outline, Ink, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        TileObject(art = art, fill = sticker.on, size = iconSize)
    }
}

/**
 * Pro Plus's own badge, instead of the Medal it used to borrow from the Pro
 * card. [CrownMark] is the app's existing hand-drawn crown — a hard offset
 * shadow, a pale-to-deep gold gradient body, a highlight band and three
 * lit studs — already used for Crown Mode elsewhere in the app, and it is
 * exactly the "real crown with points and a base band" a flat glyph can't
 * be. The roundel behind it is dark ink, not the tier's own gold fill,
 * because a gold crown painted on a gold circle has no edge to read —
 * the one thing this badge has to do is separate Pro Plus from Pro at a
 * glance, and gold-on-gold does the opposite.
 */
@Composable
private fun ProPlusIcon(accent: Sticker, size: Dp = 48.dp) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(0xFF14110B))
            .border(Paper.Outline, accent.fill, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        CrownMark(size = size * 0.52f)
    }
}

/** The reference's own `.urgency-dot` — a small dot that breathes in place. */
@Composable
private fun PulseDot(color: Color = Color.White, size: Dp = 8.dp) {
    val scale by tierLoop(com.momentum.focus.ui.util.DeviceProfile.Tier.HIGH, 
        initialValue = 1f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(tween(600), repeatMode = RepeatMode.Reverse),
        label = "pulse-scale",
    )
    val alphaV by tierLoop(com.momentum.focus.ui.util.DeviceProfile.Tier.HIGH, 
        initialValue = 1f,
        targetValue = 0.45f,
        animationSpec = infiniteRepeatable(tween(600), repeatMode = RepeatMode.Reverse),
        label = "pulse-alpha",
    )
    Box(
        Modifier
            .size(size)
            .graphicsLayer { scaleX = scale; scaleY = scale; alpha = alphaV }
            .clip(CircleShape)
            .background(color),
    )
}

/**
 * Plans backdrop (v5): four soft colour fields (butter, lilac, mint, candy)
 * drifting on slow, continuous orbits behind the cards, a fine halftone
 * shading the lower page, and a mild parallax against the scroll — the page
 * feels alive without anything competing with the prices.
 */
@Composable
private fun PlansAurora(scroll: () -> Int) {
    var secs by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val st = withFrameNanos { it }
        while (true) withFrameNanos { secs = (it - st) / 1_000_000_000f }
    }
    Canvas(Modifier.fillMaxSize().graphicsLayer { translationY = -scroll() * 0.15f }) {
        val w = size.width
        val h = size.height
        val fields = listOf(
            Triple(Color(0xFFFFD84D), 0.20f, 0.18f),
            Triple(Color(0xFFB9A7FF), 0.80f, 0.30f),
            Triple(Color(0xFF3FE28F), 0.25f, 0.62f),
            Triple(Color(0xFFFF9EC4), 0.78f, 0.82f),
        )
        fields.forEachIndexed { i, (c, fx, fy) ->
            val ox = kotlin.math.sin(secs * (0.06f + i * 0.015f) + i * 1.9f) * w * 0.12f
            val oy = kotlin.math.cos(secs * (0.05f + i * 0.012f) + i * 1.3f) * h * 0.05f
            val center = Offset(w * fx + ox, h * fy + oy)
            val r = w * 0.75f
            drawCircle(Brush.radialGradient(listOf(c.copy(alpha = 0.22f), c.copy(alpha = 0.06f), Color.Transparent), center, r), r, center)
        }
        // halftone shading the lower half of the page
        val step = 12.dp.toPx()
        var y = h * 0.45f
        var row = 0
        while (y < h) {
            var x = if (row % 2 == 0) 0f else step / 2
            val k = (y - h * 0.45f) / (h * 0.55f)
            while (x < w) { drawCircle(Ink.copy(alpha = 0.035f), (0.5f + 1.3f * k) * 1.dp.toPx(), Offset(x, y)); x += step }
            y += step; row++
        }
    }
}

/**
 * Honest maths: the yearly price as a daily price, next to the person's own
 * real phone time. No fake scarcity — just the comparison that sells itself.
 */
@Composable
private fun TimeMath() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val avg by produceState<Int?>(null) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching { com.momentum.focus.data.ScreenTime.report(context).let { if (it.hasData) it.averageMinutes else 0 } }.getOrDefault(0)
        }
    }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(450); shown = true }
    val k by androidx.compose.animation.core.animateFloatAsState(if (shown) 1f else 0f, tween(700, easing = FastOutSlowInEasing), label = "timeMath")
    val pro = 199f / 365f
    val plus = 399f / 365f
    // Its own living colour: four soft dye blobs drift under the paper on
    // slow, out-of-step orbits, so the fade keeps moving like ink in water.
    // One transition, read only in the draw phase.
    val flow = tierLoop(com.momentum.focus.ui.util.DeviceProfile.Tier.HIGH, 
        0f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(
            tween(14000, easing = androidx.compose.animation.core.LinearEasing),
        ),
        label = "mathFlowT",
    )
    Column(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { alpha = k; translationY = (1f - k) * 14.dp.toPx() }
            .hardShadow(offset = 4.dp, color = Ink, radius = 12.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(CreamCard)
            .drawBehind {
                if (!Vibe.playful) return@drawBehind   // minimal: plain paper
                val t = flow.value * 6.2832f
                val w = size.width; val h = size.height
                val dyes = listOf(
                    Triple(Butter.fill, 0.55f, 0f),
                    Triple(Candy.fill, 0.38f, 1.7f),
                    Triple(Mint.fill, 0.34f, 3.4f),
                    Triple(Lilac.fill, 0.34f, 5.0f),
                )
                dyes.forEachIndexed { i, (c, a, ph) ->
                    val sp = if (i % 2 == 0) 1f else -1f
                    val ctr = Offset(
                        w * (0.5f + 0.45f * kotlin.math.cos(t * sp + ph)),
                        h * (0.5f + 0.55f * kotlin.math.sin(t * (1f + i * 0.25f) + ph)),
                    )
                    val r = w * 0.55f
                    drawCircle(Brush.radialGradient(listOf(c.copy(alpha = a), c.copy(alpha = 0f)), ctr, r), r, ctr)
                }
                // paper sheen drifting across, so it reads lit, not flat
                val sx = w * (-0.4f + 1.8f * flow.value)
                drawRect(
                    Brush.linearGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.35f), Color.Transparent),
                        Offset(sx - w * 0.2f, 0f), Offset(sx + w * 0.2f, h),
                    ),
                )
            }
            .border(2.5.dp, Ink, RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Text(tr("THE MATHS", "हिसाब"), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, letterSpacing = 1.6.sp, color = InkMid)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text("₹" + "%.2f".format(pro * k), fontSize = 26.sp, fontWeight = FontWeight.Black, color = Ink)
            Text(tr(" /day for Pro", " /दिन Pro"), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = InkMid, modifier = Modifier.padding(bottom = 4.dp))
            Spacer(Modifier.weight(1f))
            Text("₹" + "%.2f".format(plus * k), fontSize = 18.sp, fontWeight = FontWeight.Black, color = Ink)
            Text(tr(" Plus", " Plus"), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkMid, modifier = Modifier.padding(bottom = 2.dp))
        }
        val a = avg ?: 0
        if (a > 0) {
            Spacer(Modifier.height(4.dp))
            Text(
                tr("Your phone takes ${a / 60}h ${a % 60}m a day. Pro costs less than one minute of it.",
                    "आपका फ़ोन रोज़ ${a / 60}घं ${a % 60}मि लेता है। Pro उसके एक मिनट से भी सस्ता है।"),
                style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = 0.75f),
            )
        }
    }
}

/** Brutal perk tile for the Plans header: staggered rise, hard ink shadow. */
@Composable
private fun PerkTile(glyph: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, fill: Color, index: Int, modifier: Modifier = Modifier) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(150L + index * 80L); shown = true }
    val t by animateFloatAsState(if (shown) 1f else 0f, tween(260, easing = FastOutSlowInEasing), label = "perk$index")
    Column(
        modifier
            .graphicsLayer { alpha = t; translationY = (1f - t) * 16.dp.toPx(); rotationZ = (index - 1) * 1.2f * t }
            .hardShadow(offset = 4.dp, color = Ink, radius = 12.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(fill)
            .border(2.5.dp, Ink, RoundedCornerShape(12.dp))
            .padding(10.dp),
    ) {
        Icon(glyph, contentDescription = null, tint = Ink, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(4.dp))
        // Title only: the sub-lines wrapped and clipped on 360dp phones.
        Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black, color = Ink, maxLines = 1, softWrap = false)
    }
}

/** One digit-pair pill in the countdown — the reference's own `.cd-box`. */
@Composable
private fun CdBox(value: String) {
    Box(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color.Black.copy(alpha = 0.25f))
            .padding(horizontal = 7.dp, vertical = 3.dp),
    ) {
        Text(value, color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
    }
}

/**
 * A "Pay Yearly / Pay Monthly" pill, styled after the Leonardo.ai
 * screenshots the user sent — same pill-in-a-pill shape and gold highlight
 * as [SegTabs] so the two sit together comfortably, since this one goes
 * directly above that one.
 *
 * PURELY COSMETIC, confirmed with the user before building it: this app
 * sells Pro and Pro Plus as one-time purchases, not subscriptions, and the
 * ₹199 / ₹399 prices on the cards below do not change no matter which
 * side is selected. This exists because a specific reference asked for
 * this specific pill, not because the pricing model changed — if a real
 * monthly/yearly plan ever gets built, this is UI only and carries none of
 * that logic.
 */
/**
 * The polish pass on both Plans toggles: a soft glow behind whichever
 * segment is active, and a quick spring-back wiggle exactly when a segment
 * *becomes* active — not a continuous idle animation, which would read as
 * something broken jittering rather than a deliberate touch response.
 */
@Composable
private fun WiggleGlow(
    active: Boolean,
    glowColor: Color,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val rotation = remember { Animatable(0f) }
    LaunchedEffect(active) {
        if (active) {
            rotation.snapTo(-7f)
            rotation.animateTo(0f, spring(dampingRatio = 0.35f, stiffness = 260f))
        }
    }
    val glowT by tierLoop(com.momentum.focus.ui.util.DeviceProfile.Tier.HIGH, 
        initialValue = 0.25f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "glow-t",
    )
    Box(
        modifier.graphicsLayer { rotationZ = rotation.value },
        contentAlignment = Alignment.Center,
    ) {
        if (active) {
            Canvas(Modifier.matchParentSize()) {
                drawRect(brush = Brush.radialGradient(listOf(glowColor.copy(alpha = glowT), Color.Transparent)))
            }
        }
        content()
    }
}

/**
 * The Pro Plus / Pro / Free segmented pill — the reference's own `.seg` /
 * `.seg-item.active`: one continuous gold-to-cream gradient bar, the active
 * segment cut out in a solid gold chip regardless of which tier it is (the
 * reference never recolours this per-tier the way the old PlanTabs did).
 *
 * This does NOT switch which card is on screen — every card already sits
 * in the one scrolling column below. Tapping a segment just animates the
 * scroll position to that card's own on-screen offset ([onSelect] gets the
 * index; the caller owns the Y coordinates). That is the whole reason this
 * can come back without bringing the pager's bug back with it: nothing is
 * ever hidden or swapped, so there is nothing for a stale scroll offset to
 * desync from.
 */
@Composable
private fun SegTabs(selected: Int, labels: List<String>, onSelect: (Int) -> Unit) {
    // v4: one gold pill that slides between tabs (springy, 300ms) instead of
    // each tab repainting itself — the eye follows the move.
    val pos by androidx.compose.animation.core.animateFloatAsState(
        selected.toFloat(),
        androidx.compose.animation.core.spring(dampingRatio = 0.72f, stiffness = 420f),
        label = "segPill",
    )
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .hardShadow(offset = 4.dp, radius = 999.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(Brush.linearGradient(listOf(Color(0xFFFFE9A8), Color(0xFFFFFCF4))))
            .border(3.dp, Ink, RoundedCornerShape(999.dp))
            .padding(4.dp),
    ) {
        val tabW = maxWidth / labels.size
        Box(
            Modifier
                .offset(x = tabW * pos)
                .width(tabW)
                .height(40.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(Brush.linearGradient(listOf(Color(0xFFF4CB5A), Color(0xFFC68B1E))))
                .border(2.dp, Ink, RoundedCornerShape(999.dp))
                .drawWithContent {
                    drawContent()
                    drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.35f), Color.Transparent), endY = size.height * 0.55f))
                },
        )
        Row(Modifier.fillMaxWidth().height(40.dp)) {
            labels.forEachIndexed { i, label ->
                val near = (1f - kotlin.math.abs(pos - i)).coerceIn(0f, 1f)
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickableNoRipple(remember { MutableInteractionSource() }) { Sfx.play(Sound.TICK); onSelect(i) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        label,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        color = androidx.compose.ui.graphics.lerp(Ink.copy(alpha = 0.4f), Color(0xFF2B1D06), near),
                        modifier = Modifier.graphicsLayer { val sc = 1f + 0.06f * near; scaleX = sc; scaleY = sc },
                    )
                }
            }
        }
    }
}

/**
 * Plan card entrance (v5): each card drops in on a spring with a small tilt
 * that straightens as it lands (120ms apart), a light sweeps across it ONCE
 * when it settles, and paid tiers keep a slow breathing aura in their colour.
 */
private fun Modifier.cardEntrance(index: Int, aura: Color?): Modifier = composed {
    val land = remember { Animatable(0f) }
    val shine = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(140L + index * 120L)
        land.animateTo(1f, androidx.compose.animation.core.spring(dampingRatio = 0.62f, stiffness = 240f))
        shine.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
    }
    val breath by tierLoop(com.momentum.focus.ui.util.DeviceProfile.Tier.HIGH, 
        0f, 1f, infiniteRepeatable(tween(3200), RepeatMode.Reverse), label = "auraT$index",
    )
    this
        .drawBehind {
            if (aura != null) for (k in 1..5) {
                val g = (k * 4f + breath * 4f).dp.toPx()
                drawRoundRect(
                    aura.copy(alpha = 0.10f * (1f - k / 6f) * land.value),
                    topLeft = Offset(-g, -g),
                    size = androidx.compose.ui.geometry.Size(size.width + 2 * g, size.height + 2 * g),
                    cornerRadius = CornerRadius(28.dp.toPx() + g),
                )
            }
        }
        .graphicsLayer {
            val t = land.value
            alpha = (t * 1.6f).coerceIn(0f, 1f)
            translationY = (1f - t) * 56.dp.toPx()
            rotationZ = (1f - t) * (if (index % 2 == 0) -5f else 5f)
            val sc = 0.92f + 0.08f * t
            scaleX = sc; scaleY = sc
        }
        .drawWithContent {
            drawContent()
            val p = shine.value
            if (p > 0f && p < 1f) {
                val x = size.width * (-0.4f + 1.8f * p)
                drawRect(
                    Brush.linearGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.45f), Color.Transparent),
                        start = Offset(x - size.width * 0.25f, 0f), end = Offset(x + size.width * 0.25f, size.height),
                    ),
                )
            }
        }
}

/** Tilts toward the finger while pressed (up to 6°), springs back on release. */
private fun Modifier.pressTilt(): Modifier = composed {
    var target by remember { mutableStateOf(Offset.Zero) }
    val rx by androidx.compose.animation.core.animateFloatAsState(target.y, androidx.compose.animation.core.spring(0.6f, 300f), label = "rx")
    val ry by androidx.compose.animation.core.animateFloatAsState(target.x, androidx.compose.animation.core.spring(0.6f, 300f), label = "ry")
    this
        .pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                fun aim(p: Offset) {
                    val nx = (p.x / size.width - 0.5f) * 2f
                    val ny = (p.y / size.height - 0.5f) * 2f
                    target = Offset(nx * 6f, -ny * 6f)
                }
                aim(down.position)
                do {
                    val ev = awaitPointerEvent()
                    ev.changes.firstOrNull()?.let { aim(it.position) }
                } while (ev.changes.any { it.pressed })
                target = Offset.Zero
            }
        }
        .graphicsLayer {
            rotationX = rx
            rotationY = ry
            cameraDistance = 14f * density
        }
}

/**
 * A hard, un-blurred offset shadow — `box-shadow: Npx Npx <color>` in the
 * reference's own CSS, always down-and-right, never soft.
 */
private fun Modifier.hardShadow(
    offset: Dp = 6.dp,
    color: Color = Ink,
    radius: Dp = Paper.CardRadius,
): Modifier = drawBehind {
    drawRoundRect(
        color = color,
        topLeft = Offset(offset.toPx() * Vibe.shadow, offset.toPx() * Vibe.shadow),
        size = size,
        cornerRadius = CornerRadius(radius.toPx(), radius.toPx()),
    )
}

/**
 * A gold highlight-beam that scans across the TEXT ITSELF, not the card
 * around it — the specific ask: a beam clipped to the glyphs, the same
 * "sells itself" principle already on the CTA buttons and card beams,
 * applied at text-scale for the number that actually matters on this
 * screen, the price.
 */
@Composable
private fun ShimmerGoldText(text: String, style: androidx.compose.ui.text.TextStyle, fontWeight: FontWeight, baseColor: Color = Ink) {
    val shimmerT by tierLoop(com.momentum.focus.ui.util.DeviceProfile.Tier.MID, 
        0f, 1f,
        infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "price-shimmer-t",
    )
    Text(
        text,
        style = style.copy(
            brush = Brush.linearGradient(
                colorStops = arrayOf(
                    (shimmerT - 0.3f).coerceIn(0f, 1f) to baseColor,
                    shimmerT.coerceIn(0f, 1f) to Color(0xFFF4CB5A),
                    (shimmerT + 0.3f).coerceIn(0f, 1f) to baseColor,
                ),
            ),
        ),
        fontWeight = fontWeight,
        maxLines = 1,
    )
}

/**
 * The reference's own `.featured:before` scan-light — a soft white beam
 * sweeping diagonally on a loop. The one animated flourish on this screen,
 * on the one card (Pro Plus) the reference itself singles out for it.
 */
private fun Modifier.scanSweep(): Modifier = composed {
    val t by tierLoop(com.momentum.focus.ui.util.DeviceProfile.Tier.HIGH, 
        initialValue = -0.3f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing)),
        label = "scan-t",
    )
    this.drawWithContent {
        drawContent()
        rotate(degrees = -18f, pivot = Offset(size.width * t, size.height * 0.45f)) {
            drawRect(
                brush = Brush.linearGradient(
                    listOf(Color.Transparent, Color.White.copy(alpha = 0.22f), Color.Transparent),
                    start = Offset(size.width * t - 80.dp.toPx(), 0f),
                    end = Offset(size.width * t + 80.dp.toPx(), 0f),
                ),
                topLeft = Offset(0f, size.height * 0.40f),
                size = Size(size.width, size.height * 0.12f),
            )
        }
    }
}

@Composable
fun PlansScreen(
    data: AppData,
    onBuy: () -> Unit,
    onRedeem: suspend (String) -> Boolean,
    onRemove: () -> Unit,
    onDone: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    var keyOpen by remember { mutableStateOf(false) }
    // Owning Pro Plus recolours its own card from gold (aspirational) to
    // mint (owned) — the one state-driven colour change on this screen,
    // because it is the one card whose colour is actually telling you
    // something (you have this / you don't), not just tiering it.
    val proPlusAccent = if (data.premium) Mint else Butter

    // SegTabs plumbing. Every card already lives in this one scrolling
    // column — a tab tap just animates to the Y each card reports via
    // onGloballyPositioned, it never hides or swaps content. Default is
    // Free (index 2) because that is genuinely what's on screen at scroll
    // position zero; the reference screenshot's own default of "Pro" was a
    // side effect of its pager starting on page 1, not a claim worth
    // reproducing once there's no pager to make it true.
    val scrollState = rememberScrollState()
    val tabScope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf(1) }
    var proPlusSectionY by remember { mutableStateOf(0) }
    var proSectionY by remember { mutableStateOf(0) }
    var freeSectionY by remember { mutableStateOf(0) }
    fun scrollToTab(index: Int) {
        haptics.tick()
        selectedTab = index
        val target = when (index) { 0 -> proPlusSectionY; 1 -> proSectionY; else -> freeSectionY }
        tabScope.launch { scrollState.animateScrollTo(target) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain(),
    ) {
        PlansAurora(scroll = { scrollState.value })
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(scrollState)
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 24.dp, bottom = 28.dp),
        ) {
            BackPill(onBack = onDone)
            Spacer(Modifier.height(14.dp))
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val density = LocalDensity.current
                val measurer = rememberTextMeasurer()
                val tracking = 0.42.em
                val ghostSize = remember(maxWidth, density) {
                    val probe = 40.sp
                    val measured = measurer.measure(
                        GHOST,
                        TextStyle(fontSize = probe, letterSpacing = tracking, fontWeight = FontWeight.Bold),
                    ).size.width.toFloat()
                    val trailing = with(density) { probe.toPx() } * 0.42f
                    val target = with(density) { maxWidth.toPx() }
                    if (measured <= trailing) probe else probe * (target / (measured - trailing))
                }
                Text(
                    GHOST,
                    fontSize = ghostSize,
                    lineHeight = ghostSize,
                    letterSpacing = tracking,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                    // Was 0.13 and fought the kinetic header; now a whisper.
                    color = Tang.accent.copy(alpha = 0.055f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .fillMaxWidth()
                        .offset(y = (-18).dp),
                )
                // Kinetic header: "Stop scrolling." lands, gets an ink strike,
                // then "Start winning." slams down on top of it.
                var hdr by remember { mutableFloatStateOf(0f) }
                LaunchedEffect(Unit) {
                    val st = withFrameNanos { it }
                    while (hdr < 1200f) withFrameNanos { now -> hdr = (now - st) / 1_000_000f }
                }
                val hFired = remember { mutableSetOf<Int>() }
                SideEffect {
                    if (hdr >= 520f && hFired.add(1)) Sfx.play(Sound.TICK)
                    if (hdr >= 760f && hFired.add(2)) { Sfx.play(Sound.POP); haptics.tick() }
                }
                fun hs(a: Float, d: Float) = ((hdr - a) / d).coerceIn(0f, 1f)
                Column(Modifier.fillMaxWidth()) {
                    Text(
                        str.plans.kicker,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        color = InkMid,
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "Stop scrolling.",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontSize = 48.sp,
                            lineHeight = 48.sp,
                            letterSpacing = (-0.5).sp,
                        ),
                        fontWeight = FontWeight.Black,
                        color = Ink,
                        modifier = Modifier
                            .graphicsLayer {
                                val a = FastOutSlowInEasing.transform(hs(0f, 300f))
                                rotationZ = -2.5f; alpha = a; translationY = (1f - a) * 16.dp.toPx()
                            }
                            .drawWithContent {
                                drawContent()
                                val k = FastOutSlowInEasing.transform(hs(420f, 260f))
                                if (k > 0f) drawLine(
                                    Tang.accent, Offset(0f, size.height * 0.56f),
                                    Offset(size.width * 0.92f * k, size.height * 0.50f),
                                    6.dp.toPx(), StrokeCap.Round,
                                )
                            },
                    )
                    Spacer(Modifier.height((-2).dp))
                    Box(
                        Modifier
                            .graphicsLayer {
                                val k = hs(700f, 240f)
                                val sc = if (k <= 0f) 1.5f else 1.5f - 0.5f * FastOutSlowInEasing.transform(k)
                                rotationZ = 2f + 6f * (1f - k); scaleX = sc; scaleY = sc; alpha = (k * 3f).coerceAtMost(1f)
                                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
                            }
                            .clip(RoundedCornerShape(6.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFFF4CB5A), Color(0xFFC68B1E))))
                            .border(2.5.dp, Ink, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                    ) {
                        Text(
                            "Start winning.",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontSize = 48.sp,
                                lineHeight = 48.sp,
                                letterSpacing = (-0.5).sp,
                            ),
                            fontWeight = FontWeight.Black,
                            color = Ink,
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        str.plans.subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid.copy(alpha = 0.8f),
                    )

                    // Honest strip. The fake countdown (reset to 5:59:42 on every
                    // open), "82/100 claimed" and "500+ students" were invented
                    // numbers — false urgency is a banned dark pattern in India
                    // (CCPA 2023) and students can tell. Real value sells instead.
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PerkTile(Icons.Filled.Lock, tr("Crown lock", "क्राउन लॉक"), tr("Can't uninstall mid-pact", "पैक्ट में अनइंस्टॉल नहीं"), Butter.fill, 0, Modifier.weight(1f))
                        PerkTile(Icons.Filled.AutoAwesome, tr("MyAI", "MyAI"), tr("Doubts, any time", "जब चाहें सवाल"), Lilac.fill, 1, Modifier.weight(1f))
                        PerkTile(Icons.Filled.Palette, tr("All themes", "सब थीम"), tr("No grinding", "बिना लेवलिंग"), Mint.fill, 2, Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(12.dp))
                    TimeMath()
                }
            }

            Spacer(Modifier.height(22.dp))
            // BillingPill removed — it was cosmetic-only (confirmed with the
            // user, since this app sells one-time licences, not
            // subscriptions), and a toggle with no real effect kept reading
            // as broken rather than as a style match. Bring it back once a
            // real monthly/yearly product exists to point it at.
            SegTabs(
                selected = selectedTab,
                labels = listOf("Pro Plus", "Pro", "Free"),
                onSelect = { i -> scrollToTab(i) },
            )

            Spacer(Modifier.height(22.dp))

            // ---- Free — flat, quiet, no glow ---------------------------------------
            Box(
                Modifier
                    .fillMaxWidth()
                    .onGloballyPositioned { freeSectionY = it.positionInParent().y.toInt() },
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .cardEntrance(0, null)
                        .pressTilt()
                        .hardShadow(offset = 6.dp, color = Color(0xFF4A4438))
                        .clip(RoundedCornerShape(Paper.CardRadius))
                        .background(CreamCard)
                        .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                        .padding(18.dp),
                ) {
                    TierBannerStrip("FREE", listOf(Color(0xFF6B6455), Color(0xFF6B6455)))
                    Spacer(Modifier.height(12.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            PlanIcon(sticker = Mint, art = TileArt.Shield, size = 36.dp)
                            Spacer(Modifier.width(10.dp))
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CreamCard)
                                    .border(2.dp, Ink, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 10.dp, vertical = 5.dp),
                            ) {
                                Text("BASIC", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = InkMid)
                            }
                        }
                        if (!data.premium) Tag(str.plans.youreOnThis, Mint)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("\u20b90", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.fillMaxWidth().height(2.dp).background(Ink.copy(alpha = 0.3f)))
                    Spacer(Modifier.height(12.dp))
                    PlanLine(str.plans.freeBlocking)
                    PlanLine(str.plans.freeFeeds)
                    PlanLine(str.plans.freeTimer)
                    PlanLine(str.plans.freePact)
                    if (data.pactLive) {
                        Row(
                            Modifier.padding(start = 32.dp, top = 2.dp, bottom = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(Color(0xFFE8452A)))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "Active — locked until it ends",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF8A5F17),
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                    PlanLine(str.plans.freePanic)
                    PlanLine(str.plans.freeExamAlerts)
                    PlanLine(str.plans.freeStats)
                    PlanLine(str.plans.freeStudyMode, str.plans.freeStudyNote(Doubt.FREE_SESSION))
                    PlanLine(str.plans.freePoster)
                    Spacer(Modifier.height(8.dp))
                    // Real level-gated themes, not a static "unlock as you
                    // level" line — [PlanTheme] entries and their unlock
                    // levels live where themes are actually defined; this
                    // reads data.focusLevel against that real list.
                    val allThemes = remember { Skin.entries }
                    val nextLocked = allThemes.firstOrNull { data.focusLevel < it.unlockLevel }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        allThemes.take(6).forEach { t ->
                            val unlocked = data.focusLevel >= t.unlockLevel
                            Box(
                                Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(7.dp))
                                    .background(if (unlocked) t.accent else t.accent.copy(alpha = 0.3f))
                                    .border(1.5.dp, Ink.copy(alpha = if (unlocked) 1f else 0.4f), RoundedCornerShape(7.dp)),
                                contentAlignment = Alignment.Center,
                            ) {
                                if (!unlocked) Text("\uD83D\uDD12", fontSize = 10.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (nextLocked != null) {
                            "Level ${data.focusLevel} \u00b7 reach Level ${nextLocked.unlockLevel} for ${nextLocked.label}"
                        } else {
                            "Level ${data.focusLevel} \u00b7 every theme unlocked"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                    )
                }
                // Cartoon mascot removed (owner: no kiddish art).
            }

            Spacer(Modifier.height(36.dp))

            // ---- Pro — the middle tier ---------------------------------------------
            // No Aura here: a radial glow centred on a card this tall
            // brightens the middle and fades before it reaches the top or
            // bottom edge, which reads as a soft box floating inside a
            // sharp one rather than a border — confirmed against real
            // screenshots, not just reasoned about. The sticker-coloured
            // outline plus hard shadow already say "this card is different"
            // without a glow shaped wrong for the content.
            Box(
                Modifier
                    .fillMaxWidth()
                    .onGloballyPositioned { proSectionY = it.positionInParent().y.toInt() },
            ) {
                if (!data.premium) {
                    val proBeamAngle by tierLoop(com.momentum.focus.ui.util.DeviceProfile.Tier.HIGH, 
                        initialValue = 0f,
                        targetValue = 360f,
                        animationSpec = infiniteRepeatable(tween(3400, easing = LinearEasing)),
                        label = "pro-beam-angle",
                    )
                    Canvas(
                        Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .matchParentSize()
                            .clip(RoundedCornerShape(24.dp)),
                    ) {
                        rotate(proBeamAngle, pivot = Offset(this.size.width / 2f, this.size.height / 2f)) {
                            drawRect(
                                brush = Brush.verticalGradient(listOf(Mint.accent, Color(0xFFE9FCF3), Mint.accent)),
                                topLeft = Offset(size.width / 2f - size.width * 0.35f, -size.height * 0.2f),
                                size = Size(size.width * 0.7f, size.height * 1.4f),
                            )
                        }
                    }
                }
                val proGlowPulse by tierLoop(com.momentum.focus.ui.util.DeviceProfile.Tier.HIGH, 
                    initialValue = 0f, targetValue = 1f,
                    animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Reverse),
                    label = "pro-glow-pulse-t",
                )
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .cardEntrance(1, Color(0xFF3FE28F))
                        .pressTilt()
                        .hardShadow(offset = 6.dp, color = Color(0xFF1C6B45))
                        .clip(RoundedCornerShape(24.dp))
                        .background(
                            Brush.linearGradient(
                                0.0f to Color(0xFFB8F5D8),
                                0.45f to Color(0xFFE9FCF3),
                                0.85f to Color(0xFFFFFCF4),
                            ),
                        )
                        .border(Paper.Outline, Ink, RoundedCornerShape(24.dp))
                        .drawBehind {
                            val pulse = proGlowPulse
                            val cx = size.width / 2f
                            val cy = size.height
                            val r = size.width * (0.55f + 0.12f * pulse)
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        Color(0xFF4FE8A0).copy(alpha = 0.32f * (0.7f + 0.3f * pulse)),
                                        Color(0xFF4FE8A0).copy(alpha = 0f),
                                    ),
                                    center = Offset(cx, cy),
                                    radius = r,
                                ),
                                radius = r,
                                center = Offset(cx, cy),
                            )
                        }
                        .padding(18.dp),
                ) {
                    Column(Modifier.fillMaxWidth()) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Brush.linearGradient(listOf(Color(0xFF4FE8A0), Color(0xFF1C9E5D))))
                                .then(
                                    Modifier.drawWithContent {
                                        drawContent()
                                        val stripe = 20.dp.toPx()
                                        var x = -size.height
                                        while (x < size.width) {
                                            drawLine(
                                                Color.White.copy(alpha = 0.12f),
                                                Offset(x, size.height), Offset(x + size.height, 0f),
                                                strokeWidth = stripe * 0.35f,
                                            )
                                            x += stripe
                                        }
                                    },
                                )
                                .padding(14.dp),
                        ) {
                            Text(
                                "PRO",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp,
                                color = Color.White,
                            )
                            Spacer(Modifier.height(12.dp))
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                PlanIcon(sticker = Mint, art = TileArt.Medal, size = 40.dp)
                                Column(horizontalAlignment = Alignment.End) {
                                    ShimmerGoldText("\u20b9199\u2009/yr", MaterialTheme.typography.titleLarge, FontWeight.Bold)
                                    Text("\u2248 \u20b917/mo", style = MaterialTheme.typography.labelSmall, color = Ink.copy(alpha = 0.65f))
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Billed yearly \u00b7 study tools without the full unlock",
                            style = MaterialTheme.typography.labelSmall,
                            color = InkMid,
                        )
                        Spacer(Modifier.height(12.dp))
                        Box(Modifier.fillMaxWidth().height(2.dp).background(Ink.copy(alpha = 0.3f)))
                        Spacer(Modifier.height(12.dp))
                        PlanLine(str.plans.allThemes, str.plans.allThemesNote)
                        PlanLine(str.plans.mockTest, str.plans.mockNote(Mock.COUNT))
                        PlanLine(str.plans.posterBackdrop)
                        PlanLine(str.plans.perSessionLabel, str.plans.perSession(Doubt.PER_SESSION, Doubt.FREE_SESSION))
                        Spacer(Modifier.height(14.dp))
                        Box {
                            SquishButton(
                                label = if (data.premium) str.plans.unlocked else "Get Pro",
                                sticker = Mint,
                                enabled = !data.premium,
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { haptics.confirm(); onBuy() },
                            )
                            if (!data.premium) {
                                val sweepT by tierLoop(com.momentum.focus.ui.util.DeviceProfile.Tier.LOW, 
                                    0f, 1f,
                                    infiniteRepeatable(tween(2600, easing = LinearEasing)),
                                    label = "pro-cta-sweep-t",
                                )
                                Box(
                                    Modifier
                                        .matchParentSize()
                                        .clip(RoundedCornerShape(999.dp))
                                        .drawWithContent {
                                            val bandW = size.width * 0.28f
                                            val x = -bandW + sweepT * (size.width + bandW * 2)
                                            drawRect(
                                                brush = Brush.linearGradient(
                                                    listOf(Color.Transparent, Color.White.copy(alpha = 0.45f), Color.Transparent),
                                                    start = Offset(x, 0f), end = Offset(x + bandW, size.height),
                                                ),
                                            )
                                        },
                                )
                            }
                        }
                    }
                }
                // Cartoon mascot removed (owner: no kiddish art).
            }

            Spacer(Modifier.height(36.dp))

            // ---- Pro Plus — the tier the screen is built to sell -------------------
            // Aura removed — this was the exact card the report was about:
            // a radial glow centred on the whole card reads as a rounded
            // box that visibly closes before the bottom edge on something
            // this tall, not a border that runs the full height. The dark
            // background, gold/mint outline, hard shadow and HOT badge
            // already do the "this one's the sell" job on their own.
            Box(
                Modifier
                    .fillMaxWidth()
                    .onGloballyPositioned { proPlusSectionY = it.positionInParent().y.toInt() },
            ) {
                // Edge animation: the exact travelling highlight MyAI's composer
                // wears while an answer is on its way (see glowEdge in
                // Marks.kt — same 1.6s period, same gradient geometry), lit in
                // this card's gold. It replaces a 3-second full-card spinning
                // beam that read as far too fast against the rest of the app.
                Box(Modifier.fillMaxWidth().padding(8.dp)) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(4.dp)
                            .cardEntrance(2, Color(0xFFF4CB5A))
                            .pressTilt()
                            .hardShadow(offset = 7.dp, color = proPlusAccent.fill)
                            .clip(RoundedCornerShape(20.dp))
                            .starfield()
                            .glowEdge(
                                active = true,
                                shape = RoundedCornerShape(20.dp),
                                lit = 3.dp,
                                tint = Color(0xFFF4CB5A),
                            )
                            .scanSweep()
                            .padding(20.dp),
                    ) {
                    Column(Modifier.fillMaxWidth()) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Brush.linearGradient(listOf(Color(0xFFF4CB5A), Color(0xFFC68B1E))))
                                .then(
                                    Modifier.drawWithContent {
                                        drawContent()
                                        val stripe = 20.dp.toPx()
                                        var x = -size.height
                                        while (x < size.width) {
                                            drawLine(
                                                Color.White.copy(alpha = 0.12f),
                                                Offset(x, size.height), Offset(x + size.height, 0f),
                                                strokeWidth = stripe * 0.35f,
                                            )
                                            x += stripe
                                        }
                                    },
                                )
                                .padding(14.dp),
                        ) {
                            Text(
                                "PRO PLUS",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp,
                                color = Color(0xFF2B1D06),
                            )
                            Spacer(Modifier.height(12.dp))
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top,
                            ) {
                                ProPlusIcon(accent = proPlusAccent, size = 48.dp)
                                Column(horizontalAlignment = Alignment.End) {
                                    if (data.premium) {
                                        Text(
                                            str.plans.yours,
                                            style = MaterialTheme.typography.headlineMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF2B1D06),
                                            maxLines = 1,
                                        )
                                    } else {
                                        ShimmerGoldText(
                                            "\u20b9399\u2009/yr",
                                            MaterialTheme.typography.headlineMedium,
                                            FontWeight.Bold,
                                            baseColor = Color(0xFF2B1D06),
                                        )
                                    }
                                    if (!data.premium) {
                                        Text(
                                            "\u2248 \u20b933/mo \u00b7 billed yearly",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF2B1D06).copy(alpha = 0.65f),
                                        )
                                    }
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Text(
                                "${str.plans.productName} PLUS",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2B1D06),
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Everything in Pro, and nothing left locked.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.55f),
                        )

                        Spacer(Modifier.height(16.dp))
                        Box(Modifier.fillMaxWidth().height(2.dp).background(Color.White.copy(alpha = 0.3f)))
                        Spacer(Modifier.height(16.dp))

                        // Pro Plus exclusive: everything Pro has, plus the two
                        // things this codebase can actually gate hardest — full
                        // mode access and a doubt from a photo — plus Crown, which
                        // is a commitment device, not a blocker, so it belongs on
                        // the top tier rather than the free one.
                        PlanLine(str.plans.allModes, str.plans.allModesNote, highlight = true, dark = true)
                        PlanLine(str.plans.photoPdf, dark = true)
                        PlanLine(str.plans.crownMode, str.plans.crownNote, dark = true)
                        PlanLine(str.plans.allThemes, str.plans.allThemesNote, dark = true)
                        PlanLine(str.plans.mockTest, str.plans.mockNote(Mock.COUNT), dark = true)
                        PlanLine(str.plans.posterBackdrop, dark = true)
                        PlanLine(str.plans.perSessionLabel, str.plans.perSession(Doubt.PER_SESSION, Doubt.FREE_SESSION), dark = true)

                        Spacer(Modifier.height(18.dp))
                        // breathing halo under the CTA (the button itself is
                        // disabled once owned, so the glow lives behind it)
                        val ctaHalo by tierLoop(com.momentum.focus.ui.util.DeviceProfile.Tier.HIGH, 
                            0.35f, 1f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "ppHaloT",
                        )
                        Box(
                            Modifier.drawBehind {
                                for (k in 1..6) {
                                    val g = (k * 4f).dp.toPx() * (0.7f + 0.3f * ctaHalo)
                                    drawRoundRect(
                                        proPlusAccent.fill.copy(alpha = 0.13f * ctaHalo * (1f - k / 7f)),
                                        topLeft = Offset(-g, -g),
                                        size = androidx.compose.ui.geometry.Size(size.width + 2 * g, size.height + 2 * g),
                                        cornerRadius = CornerRadius(16.dp.toPx() + g),
                                    )
                                }
                            },
                        ) {
                            SquishButton(
                                label = if (data.premium) str.plans.unlocked else str.plans.unlockLifetime,
                                sticker = proPlusAccent,
                                enabled = !data.premium,
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { haptics.confirm(); onBuy() },
                            )
                            if (!data.premium) {
                                val sweepT2 by tierLoop(com.momentum.focus.ui.util.DeviceProfile.Tier.LOW, 
                                    0f, 1f,
                                    infiniteRepeatable(tween(2600, easing = LinearEasing)),
                                    label = "plus-cta-sweep-t",
                                )
                                Box(
                                    Modifier
                                        .matchParentSize()
                                        .clip(RoundedCornerShape(999.dp))
                                        .drawWithContent {
                                            val bandW = size.width * 0.28f
                                            val x = -bandW + sweepT2 * (size.width + bandW * 2)
                                            drawRect(
                                                brush = Brush.linearGradient(
                                                    listOf(Color.Transparent, Color.White.copy(alpha = 0.5f), Color.Transparent),
                                                    start = Offset(x, 0f), end = Offset(x + bandW, size.height),
                                                ),
                                            )
                                        },
                                )
                            }
                // Cartoon mascot removed (owner: no kiddish art).
                        }

                        Spacer(Modifier.height(10.dp))
                        if (data.premium) {
                            var confirmRemove by remember { mutableStateOf(false) }
                            Text(
                                // Masked: Plans gets screenshotted and shared;
                                // a full key on screen is a key given away.
                                "Key: " + License.pretty(data.licenseKey).let { k ->
                                    val parts = k.split('-')
                                    if (parts.size > 2) (listOf(parts.first()) + parts.drop(1).dropLast(1).map { "•••••" } + parts.last()).joinToString("-") else k
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.55f),
                                modifier = Modifier
                                    .align(Alignment.CenterHorizontally)
                                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                                        haptics.tap(); confirmRemove = true
                                    }
                                    .padding(6.dp),
                            )
                            if (confirmRemove) {
                                Dialog(onDismissRequest = { confirmRemove = false }) {
                                    Column(
                                        Modifier
                                            .fillMaxWidth()
                                            .hardShadow(offset = 6.dp)
                                            .clip(RoundedCornerShape(Paper.CardRadius))
                                            .background(CreamCard)
                                            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                                            .padding(18.dp),
                                    ) {
                                        Text(tr("Remove key?", "की हटाएँ?"), style = MaterialTheme.typography.headlineSmall, color = Ink)
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            tr("Premium will be removed from this phone. You can use the same key on another phone.", "प्रीमियम इस फ़ोन से हट जाएगा। वही की दूसरे फ़ोन पर डाल सकते हैं।"),
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = InkMid,
                                        )
                                        Spacer(Modifier.height(16.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            SquishButton(
                                                label = tr("Keep it", "रहने दें"),
                                                sticker = Mint,
                                                modifier = Modifier.weight(1f),
                                                onClick = { haptics.tap(); confirmRemove = false },
                                            )
                                            SquishButton(
                                                label = tr("Remove", "हटाएँ"),
                                                sticker = Sticker(CreamCard, Ink, Tang.accent),
                                                modifier = Modifier.weight(1f),
                                                onClick = { haptics.press(); confirmRemove = false; onRemove() },
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            Box(
                                Modifier
                                    .align(Alignment.CenterHorizontally)
                                    .clip(RoundedCornerShape(999.dp))
                                    .border(2.dp, Color.White.copy(alpha = 0.55f), RoundedCornerShape(999.dp))
                                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                                        haptics.tap(); keyOpen = true
                                    }
                                    .padding(horizontal = 16.dp, vertical = 9.dp),
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Filled.VpnKey,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Spacer(Modifier.width(7.dp))
                                    Text(
                                        str.plans.haveKey,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.height(20.dp))
                        Column {
                            Text(
                                if (data.premium) str.plans.ownedHeader else str.plans.lockedHeader,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.45f),
                            )
                            Spacer(Modifier.height(10.dp))
                            PremiumPeek(locked = !data.premium, title = str.plans.peekModesTitle, body = str.plans.peekModesBody, art = TileArt.Person, tone = Lilac)
                            Spacer(Modifier.height(8.dp))
                            PremiumPeek(locked = !data.premium, title = str.plans.peekPageTitle, body = str.plans.peekPageBody, art = TileArt.Camera, tone = Sky)
                            Spacer(Modifier.height(8.dp))
                            PremiumPeek(locked = !data.premium, title = str.plans.peekThemesTitle, body = str.plans.peekThemesBody, art = TileArt.Palette, tone = Mint)
                        }

                        Spacer(Modifier.height(14.dp))
                        Text(
                            str.plans.nothingBlocked,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.5f),
                            modifier = Modifier.align(Alignment.CenterHorizontally),
                        )
                    }
                    }
                }

                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = (-13).dp),
                ) {
                    Tag(if (data.premium) str.plans.yours.uppercase() else str.plans.bestValue, proPlusAccent, crown = true)
                }
                if (!data.premium) {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = 6.dp, y = (-12).dp)
                            .graphicsLayer { rotationZ = 4f }
                            .clip(RoundedCornerShape(8.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFFFF6B4A), Color(0xFFE8452A))))
                            .border(2.5.dp, Ink, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                    ) {
                        Text("\uD83D\uDD25 HOT", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                    }
                }
            }

            if (keyOpen) {
                LicenseDialog(
                    onRedeem = onRedeem,
                    onClose = { keyOpen = false },
                )
            }

            Spacer(Modifier.height(22.dp))
            SquishButton(
                label = str.plans.back,
                sticker = Sticker(CreamCard, Ink, Ink),
                modifier = Modifier.fillMaxWidth(),
                onClick = { haptics.tap(); onDone() },
            )
        }
    }
}

/**
 * FlowRow, not Row: the label used to sit in a Modifier.weight(1f,
 * fill = false) slot next to a same-row badge that had no width cap of its
 * own (softWrap = false measures it at full intrinsic width). A short badge
 * left enough room and it never showed; the longest one on this screen,
 * "20 questions per session", ate almost the entire row, leaving the label
 * a sliver of width so narrow Android had to break every word onto its own
 * line, letter by letter. FlowRow keeps the badge inline when it fits and
 * drops it to its own line when it doesn't, so the label always gets the
 * full row to wrap normally either way.
 *
 * [dark] switches the text between ink-on-paper (the Free and Pro cards)
 * and white-on-ink (the Pro Plus card, which stays a dark sticker rather
 * than a paper one — see the comment on [proPlusAccent]).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlanLine(text: String, note: String? = null, highlight: Boolean = false, dark: Boolean = false) {
    Row(
        Modifier.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(18.dp)
                .clip(CircleShape)
                .background(Mint.fill.copy(alpha = 0.92f)),
            contentAlignment = Alignment.Center,
        ) {
            Text("\u2713", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Mint.on)
        }
        Spacer(Modifier.width(10.dp))
        FlowRow(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(
                text,
                style = MaterialTheme.typography.bodyLarge,
                color = if (dark) Color.White.copy(alpha = 0.92f) else Ink,
                fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal,
            )
            if (note != null) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (dark) GoldNeon.copy(alpha = 0.18f) else Butter.fill.copy(alpha = 0.45f))
                        .border(1.dp, if (dark) GoldNeon.copy(alpha = 0.45f) else Ink.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 7.dp, vertical = 2.dp),
                ) {
                    Text(
                        note,
                        maxLines = 1,
                        softWrap = false,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (dark) GoldNeon else InkMid,
                    )
                }
            }
        }
    }
}

/** A tilted comic sticker badge — matches the reference's own `.sticker` class: a flat fill, a thick ink border, a hard shadow, a slight rotation. */
@Composable
private fun Tag(label: String, sticker: Sticker, crown: Boolean = false) {
    Box(
        Modifier
            .graphicsLayer { rotationZ = -2.5f }
            .hardShadow(offset = 3.dp, radius = 999.dp, color = sticker.accent)
            .clip(RoundedCornerShape(999.dp))
            .background(sticker.fill)
            .border(2.dp, Ink, RoundedCornerShape(999.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (crown) {
                CrownMark(size = 13.dp)
                Spacer(Modifier.width(5.dp))
            }
            Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = sticker.on)
        }
    }
}

@Composable
private fun LicenseDialog(
    onRedeem: suspend (String) -> Boolean,
    onClose: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }
    var unlocked by remember { mutableStateOf(false) }
    // Key unlock (from Uiverse install button): the button charges while the
    // key is checked and fills completely on success before the dialog goes.
    val charge = remember { Animatable(0f) }
    LaunchedEffect(checking, unlocked) {
        when {
            unlocked -> charge.animateTo(1f, tween(320, easing = FastOutSlowInEasing))
            checking -> charge.animateTo(0.75f, tween(900, easing = FastOutSlowInEasing))
            else -> charge.animateTo(0f, tween(180))
        }
    }

    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .hardShadow(offset = 6.dp)
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(20.dp),
        ) {
            Text(str.plans.keyTitle, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(4.dp))
            Text(str.plans.keyHint, style = MaterialTheme.typography.headlineSmall, color = Ink)
            Spacer(Modifier.height(14.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(24); error = false },
                placeholder = { Text(str.plans.keyPlaceholder, color = InkLow) },
                singleLine = true,
                isError = error,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Ink,
                    unfocusedTextColor = Ink,
                    focusedBorderColor = Ink,
                    unfocusedBorderColor = Ink.copy(alpha = 0.35f),
                    cursorColor = Ink,
                ),
                modifier = Modifier.fillMaxWidth(),
            )

            if (error) {
                Spacer(Modifier.height(8.dp))
                Text(str.plans.keyWrong, style = MaterialTheme.typography.bodyMedium, color = Tang.accent)
            }

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SquishButton(
                    label = str.plans.cancel,
                    sticker = Sticker(CreamCard, Ink, Ink),
                    modifier = Modifier.weight(1f),
                    onClick = onClose,
                )
                SquishButton(
                    label = when {
                        unlocked -> tr("Unlocked!", "अनलॉक!")
                        checking -> str.plans.checking
                        else -> str.plans.unlock
                    },
                    sticker = Mint,
                    enabled = !checking && !unlocked && text.isNotBlank(),
                    modifier = Modifier
                        .weight(1f)
                        .drawWithContent {
                            drawContent()
                            val k = charge.value
                            if (k <= 0f) return@drawWithContent
                            // Ink hatching sweeps in from the left as it charges.
                            val w = size.width * k
                            clipRect(right = w) {
                                val gap = 9.dp.toPx()
                                var x = -size.height
                                while (x < w + gap) {
                                    drawLine(
                                        Ink.copy(alpha = 0.16f),
                                        Offset(x, size.height), Offset(x + size.height, 0f),
                                        3.dp.toPx(),
                                    )
                                    x += gap
                                }
                            }
                        },
                    onClick = {
                        checking = true
                        scope.launch {
                            val ok = onRedeem(text)
                            checking = false
                            if (ok) {
                                unlocked = true
                                haptics.confirm()
                                kotlinx.coroutines.delay(450)   // let the fill land
                                onClose()
                            } else { haptics.press(); error = true }
                        }
                    },
                )
            }
        }
    }
}

/**
 * One locked/unlocked feature preview row inside the Pro Plus card.
 *
 * BUG FIX: the title used to be capped at `maxLines = 1` with an ellipsis,
 * which is exactly what the recording shows going wrong — "Friend and…",
 * "Send a pa…", "Every the…" — a real word cut mid-sentence next to a
 * button that is asking for money. Two lines is enough room for every
 * title this row is actually given; there is nothing left below the fold
 * of the card that a slightly taller row would push off it.
 */
@Composable
private fun PremiumPeek(
    locked: Boolean,
    title: String,
    body: String,
    art: TileArt,
    tone: Sticker,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Color.White.copy(alpha = if (locked) 0.10f else 0.18f), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .alpha(if (locked) 0.72f else 1f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PlanIcon(sticker = tone, art = art, size = 40.dp, iconSize = 18.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(1.dp))
            Text(
                body,
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.6f),
            )
        }
        if (locked) {
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(GoldNeon)
                    .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            ) {
                Text("PRO", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Ink)
            }
        }
    }
}

/**
 * The Pro Plus night sky, rebuilt literally from the "Pro Plus — starfield
 * idea" reference (rule 1: the HTML is the spec).
 *
 * What the reference has and the old version did not:
 *  - three star layers (45 + 35 + 25 stars per tile) instead of 22 stars in
 *    one, so the sky reads as dense rather than sprinkled;
 *  - a *medium* drift — 300px per 45s / 30s / 60s, i.e. 6.7 / 10 / 5 dp per
 *    second. The old field crossed the whole card in 9 seconds (roughly ten
 *    times faster), which is what read as busy;
 *  - the slowest layer twinkles (0.3 ↔ 0.9 over 2.5s);
 *  - a gold glow pooling at the bottom edge (elliptical, 0.55 → 0.15 → 0),
 *    and the ellipse-at-bottom dark sky behind everything.
 *
 * Drawn *behind* the card content, like the reference, not over it. Tiles
 * wrap on a single wall-clock so no layer ever jumps when it loops. The
 * gyroscope parallax from the reference is still left out on purpose (a
 * live sensor listener on a scrolling pricing card is a real battery cost).
 */
private fun Modifier.starfield(): Modifier = composed {
    // v5: a calm galaxy, not a star storm. Static stars from the reference
    // tile with a slow per-star twinkle, a faint milky band across the card,
    // and a much softer gold horizon (it was washing out the bottom third).
    val tw by tierLoop(com.momentum.focus.ui.util.DeviceProfile.Tier.MID, 
        0f, (2 * Math.PI).toFloat(), infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "galaxyT",
    )
    this.drawBehind {
        val w = size.width
        val h = size.height
        val d = density
        val gold = Color(0xFFF4CB5A)
        drawRect(Brush.verticalGradient(listOf(Color(0xFF0B0A12), Color(0xFF120F14), Color(0xFF17120A))))
        // milky band
        withTransform({ rotate(-24f, Offset(w / 2f, h / 2f)) }) {
            drawRect(
                Brush.verticalGradient(
                    listOf(Color.Transparent, Color(0xFF9C8CFF).copy(alpha = 0.07f), Color(0xFFFFE6C0).copy(alpha = 0.05f), Color.Transparent),
                    startY = h * 0.25f, endY = h * 0.6f,
                ),
                topLeft = Offset(-w * 0.5f, 0f), size = androidx.compose.ui.geometry.Size(w * 2f, h),
            )
        }
        // stars: one pass over the base tile, scaled to the card, slow twinkle
        var i = 0
        var n = 0
        while (i < STARS_BASE.size) {
            val x = (STARS_BASE[i] / 300f) * w
            val y = (STARS_BASE[i + 1] / 300f) * h
            val r = STARS_BASE[i + 2] * 1.05f * d
            val a = 0.45f + 0.5f * (0.5f + 0.5f * kotlin.math.sin(tw + n * 1.37f))
            drawCircle(Color.White.copy(alpha = a), r, Offset(x, y))
            if (n % 7 == 0) drawCircle(Brush.radialGradient(listOf(Color(0xFFCFD8FF).copy(alpha = 0.35f * a), Color.Transparent), Offset(x, y), r * 6f), r * 6f, Offset(x, y))
            i += 3; n++
        }
        // breathing galactic orbs rising from the bottom edge — three half
        // circles (violet, pink, gold) swelling out of phase, with a ring of
        // dust tracing their rim.
        val br = (kotlin.math.sin(tw) + 1f) / 2f
        val orbs = listOf(
            Triple(0.22f, Color(0xFF9D7BFF), 0f),
            Triple(0.55f, Color(0xFFFF4F8B), 2.1f),
            Triple(0.85f, Color(0xFFF4CB5A), 4.2f),
        )
        orbs.forEach { (fx, col, ph) ->
            val b = (kotlin.math.sin(tw + ph) + 1f) / 2f
            val r = w * (0.30f + 0.06f * b)
            val c = Offset(w * fx, h + r * 0.35f)
            drawCircle(
                Brush.radialGradient(listOf(col.copy(alpha = 0.40f + 0.20f * b), col.copy(alpha = 0.10f), Color.Transparent), c, r),
                r, c,
            )
            drawCircle(col.copy(alpha = 0.35f * b), r * 0.82f, c, style = androidx.compose.ui.graphics.drawscope.Stroke(1.2f * d))
            for (k in 0 until 10) {
                val a = Math.toRadians((180.0 + k * 18.0 + tw * 20.0)).toFloat()
                val p = Offset(c.x + kotlin.math.cos(a) * r * 0.82f, c.y + kotlin.math.sin(a) * r * 0.82f)
                if (p.y < h) drawCircle(Color.White.copy(alpha = 0.5f * b), 1.2f * d, p)
            }
        }
        // softer gold horizon
        val glowCx = w / 2f
        val glowCy = h * 1.25f
        val glowRx = w * 0.70711f
        val glowRy = h * 0.5f * 1.41421f
        withTransform({ scale(1f, glowRy / glowRx, Offset(glowCx, glowCy)) }) {
            drawCircle(
                brush = Brush.radialGradient(
                    0f to gold.copy(alpha = 0.22f),
                    0.45f to gold.copy(alpha = 0.06f),
                    0.8f to gold.copy(alpha = 0f),
                    center = Offset(glowCx, glowCy),
                    radius = glowRx,
                ),
                radius = glowRx,
                center = Offset(glowCx, glowCy),
            )
        }
    }
}

// Star tiles copied from the reference HTML: x, y, radius (dp) per star.
// Flat float arrays — 105 stars per tile, no per-star objects.
private val STARS_BASE = floatArrayOf(
        57f, 12f, 1.6f, 125f, 114f, 1.1f, 52f, 279f, 1.1f,
        216f, 16f, 1f, 111f, 119f, 1.4f, 13f, 101f, 1.6f,
        279f, 214f, 1.2f, 142f, 3f, 1.6f, 81f, 216f, 1.3f,
        79f, 110f, 1.8f, 172f, 52f, 1.1f, 49f, 183f, 1.7f,
        135f, 22f, 1.6f, 274f, 63f, 1.8f, 193f, 40f, 1.4f,
        185f, 98f, 1.6f, 23f, 116f, 1.6f, 40f, 119f, 1.7f,
        194f, 142f, 1.4f, 186f, 83f, 1.3f, 107f, 136f, 1.6f,
        36f, 87f, 1.4f, 125f, 83f, 1.4f, 138f, 112f, 1.5f,
        28f, 117f, 1.7f, 161f, 205f, 1.2f, 108f, 161f, 1.2f,
        255f, 202f, 1.7f, 234f, 73f, 1.2f, 126f, 275f, 1.2f,
        219f, 204f, 1.3f, 70f, 260f, 1.4f, 24f, 56f, 1.1f,
        81f, 216f, 1.5f, 197f, 195f, 1.5f, 239f, 270f, 1.2f,
        5f, 58f, 1.5f, 274f, 136f, 1.6f, 174f, 57f, 1.2f,
        80f, 232f, 1f, 134f, 256f, 1.6f, 259f, 54f, 1.7f,
        152f, 259f, 1.5f, 78f, 191f, 1.6f, 276f, 271f, 1.7f,
)

private val STARS_MID = floatArrayOf(
        165f, 250f, 0.8f, 185f, 157f, 1f, 123f, 40f, 0.9f,
        248f, 35f, 1.5f, 272f, 64f, 0.9f, 243f, 84f, 1f,
        216f, 108f, 1.5f, 102f, 159f, 1.1f, 191f, 224f, 1.4f,
        231f, 61f, 1f, 32f, 173f, 0.8f, 117f, 112f, 0.8f,
        30f, 117f, 0.8f, 16f, 169f, 0.8f, 121f, 142f, 1.3f,
        109f, 276f, 0.9f, 242f, 124f, 1.3f, 208f, 97f, 0.9f,
        220f, 181f, 1.1f, 239f, 27f, 1.3f, 50f, 31f, 1.1f,
        173f, 55f, 1f, 97f, 274f, 1.1f, 216f, 93f, 1f,
        127f, 38f, 1.1f, 50f, 25f, 1.3f, 276f, 7f, 1.5f,
        121f, 85f, 1.1f, 246f, 109f, 1.4f, 30f, 84f, 1.1f,
        199f, 135f, 1.4f, 232f, 146f, 1.1f, 249f, 79f, 0.9f,
        111f, 29f, 1.2f, 277f, 31f, 1.3f,
)

private val STARS_TWINKLE = floatArrayOf(
        29f, 25f, 1.9f, 257f, 271f, 1.6f, 260f, 41f, 2.1f,
        35f, 34f, 2f, 120f, 206f, 1.6f, 126f, 20f, 1.9f,
        214f, 267f, 1.7f, 133f, 104f, 2f, 160f, 122f, 1.7f,
        67f, 153f, 1.8f, 37f, 4f, 1.8f, 51f, 37f, 1.9f,
        259f, 135f, 1.6f, 178f, 35f, 2.1f, 189f, 145f, 1.6f,
        278f, 154f, 1.9f, 270f, 4f, 2f, 153f, 53f, 2.2f,
        68f, 135f, 1.6f, 54f, 79f, 1.7f, 107f, 175f, 1.6f,
        135f, 258f, 1.8f, 26f, 47f, 1.9f, 141f, 22f, 1.5f,
        66f, 134f, 1.6f,
)


/**
 * The colored banner strip at the top of each tier card — the uisfx.com
 * / "CREATIVE STUDIO" reference the user sent. Free stays flat (nothing
 * to sell), Pro and Pro Plus get the diagonal-stripe texture and a shine
 * sweep, matching the same "sells itself while unbought" principle as the
 * rotating beams elsewhere on these same cards.
 */
@Composable
private fun TierBannerStrip(name: String, colors: List<Color>, dark: Boolean = false, shine: Boolean = false) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.linearGradient(colors))
            .then(
                if (shine) {
                    Modifier.drawWithContent {
                        drawContent()
                        val stripe = 20.dp.toPx()
                        var x = -size.height
                        while (x < size.width) {
                            drawLine(
                                Color.White.copy(alpha = 0.12f),
                                Offset(x, size.height), Offset(x + size.height, 0f),
                                strokeWidth = stripe * 0.35f,
                            )
                            x += stripe
                        }
                    }
                } else {
                    Modifier
                },
            )
            .padding(horizontal = 14.dp, vertical = 9.dp),
    ) {
        Text(
            name,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            letterSpacing = 0.5.sp,
            color = if (dark) Color(0xFF2B1D06) else Color.White,
        )
    }
}
