package com.momentum.focus.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.ai.Doubt
import com.momentum.focus.ai.Mock
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.R
import com.momentum.focus.ui.components.CrownMark
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileObject
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.components.ScanningBeam
import com.momentum.focus.ui.components.PowerButton
import com.momentum.focus.ui.components.BreathingOrb
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.launch

/**
 * Three tiers: Free, Pro, Pro Plus — one column, top to bottom, instead of
 * three swipeable pages.
 *
 * REBUILD NOTE — why the pager got removed:
 * The previous version of this screen put Free/Pro/Pro Plus on a
 * HorizontalPager inside a fixed-height box, sharing ONE scroll position
 * that belonged to the outer Column, not to whichever page happened to be
 * showing. Pro Plus carries seven feature lines plus three locked-preview
 * rows; Free and Pro are a third of that height. The moment someone
 * scrolled deep into Pro Plus and then swiped to Free or Pro, the shorter
 * page didn't reach as far down as the leftover scroll offset did, so the
 * screen showed a stretch of blank paper-grid where a card should have
 * been — reproduced on video: switching tabs mid-scroll left an empty gap,
 * and the Pro tab could even render fully blank on first landing. A single
 * scrolling column cannot desync from itself this way: every card sits
 * exactly where its own content places it, always. That is the actual
 * "new structure" this pass delivers — not a re-skin of the old one.
 *
 * Two more fixes that came out of the same recording:
 * - The locked-feature preview rows on Pro Plus were truncating their own
 *   titles ("Friend and…", "Send a pa…") because the title Text capped at
 *   one line. [PremiumPeek] now wraps to two.
 * - Pro and Pro Plus used to share the exact same badge (Medal, on a
 *   coloured circle) — the one spot on the screen where two different
 *   tiers looked like the same product. Pro Plus now gets its own mark:
 *   the app's existing hand-drawn [CrownMark] on a dark roundel.
 *
 * Everything below the header (urgency banner, countdown, social proof,
 * spots-left bar) is unchanged — that content was already right, only the
 * cards under it were rebuilt.
 *
 * IMPORTANT — read before wiring a real purchase to the Pro button:
 * the licence system in this codebase (data/License.kt, AppData.premium) has
 * exactly one paid state — a boolean. There is no tier field anywhere. So as
 * shipped here, both the Pro and Pro Plus buttons call the same [onBuy] and
 * both flip the same [AppData.premium] flag — buying "Pro" currently grants
 * everything Pro Plus lists too, because there is nothing downstream able to
 * grant less. The feature split below is real and intentional, but it is a
 * pricing-page split only until License carries a tier and Ai.kt /
 * FocusScreen.kt check it. Wiring that is a real follow-up, not a checkbox
 * on this file.
 *
 * Free stays exactly what it was: nothing that blocks a distraction costs
 * money — the shield, the feed guard, pact and panic are free and stay free.
 */
private const val GHOST = "PLANS"

/**
 * A flat sticker circle with an ink outline and an icon centred inside —
 * every icon badge elsewhere in this app (Settings' action tiles, MyAi's
 * mode picker) is exactly this.
 */
@Composable
private fun DotCluster(color: Color, modifier: Modifier = Modifier, rows: Int = 4, dot: Dp = 5.dp, gap: Dp = 10.dp) {
    Canvas(modifier.size(gap * (rows - 1) + dot, gap * (rows - 1) + dot)) {
        val r = dot.toPx() / 2f
        val step = gap.toPx()
        for (row in 0 until rows) {
            for (col in 0..row) {
                drawCircle(
                    color = color,
                    radius = r,
                    center = Offset(
                        x = col * step + (rows - 1 - row) * step / 2f + r,
                        y = row * step + r,
                    ),
                )
            }
        }
    }
}

@Composable
private fun PlanIcon(
    sticker: Sticker,
    art: TileArt,
    size: Dp = 40.dp,
    iconSize: Dp = size * 0.42f,
) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(sticker.fill)
            .border(Paper.Outline, Ink, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        TileObject(art = art, fill = sticker.on, size = iconSize)
    }
}

/**
 * Pro Plus's own badge, instead of the Medal it used to borrow from the Pro
 * card. [CrownMark] is the app's existing hand-drawn crown — a hard offset
 * shadow, a pale-to-deep gold gradient body, a highlight band and three
 * lit studs — already used for Crown Mode elsewhere in the app, and it is
 * exactly the "real crown with points and a base band" a flat glyph can't
 * be. The roundel behind it is dark ink, not the tier's own gold fill,
 * because a gold crown painted on a gold circle has no edge to read —
 * the one thing this badge has to do is separate Pro Plus from Pro at a
 * glance, and gold-on-gold does the opposite.
 */
@Composable
private fun ProPlusIcon(accent: Sticker, size: Dp = 48.dp) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(0xFF14110B))
            .border(Paper.Outline, accent.fill, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        CrownMark(size = size * 0.52f)
    }
}

/**
 * A hard, un-blurred offset shadow — `box-shadow: Npx Npx <color>` in the
 * reference's own CSS, always down-and-right, never soft.
 */
private fun Modifier.hardShadow(
    offset: Dp = 6.dp,
    color: Color = Ink,
    radius: Dp = Paper.CardRadius,
): Modifier = drawBehind {
    drawRoundRect(
        color = color,
        topLeft = Offset(offset.toPx(), offset.toPx()),
        size = size,
        cornerRadius = CornerRadius(radius.toPx(), radius.toPx()),
    )
}

/**
 * The reference's own `.featured:before` scan-light — a soft white beam
 * sweeping diagonally on a loop. The one animated flourish on this screen,
 * on the one card (Pro Plus) the reference itself singles out for it.
 */
private fun Modifier.scanSweep(): Modifier = composed {
    val infinite = rememberInfiniteTransition(label = "scan-sweep")
    val t by infinite.animateFloat(
        initialValue = -0.3f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing)),
        label = "scan-t",
    )
    this.drawWithContent {
        drawContent()
        rotate(degrees = -18f, pivot = Offset(size.width * t, size.height * 0.45f)) {
            drawRect(
                brush = Brush.linearGradient(
                    listOf(Color.Transparent, Color.White.copy(alpha = 0.22f), Color.Transparent),
                    start = Offset(size.width * t - 80.dp.toPx(), 0f),
                    end = Offset(size.width * t + 80.dp.toPx(), 0f),
                ),
                topLeft = Offset(0f, size.height * 0.40f),
                size = Size(size.width, size.height * 0.12f),
            )
        }
    }
}

@Composable
fun PlansScreen(
    data: AppData,
    onBuy: () -> Unit,
    onRedeem: suspend (String) -> Boolean,
    onRemove: () -> Unit,
    onDone: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    var keyOpen by remember { mutableStateOf(false) }
    // Owning Pro Plus recolours its own card from gold (aspirational) to
    // mint (owned) — the one state-driven colour change on this screen,
    // because it is the one card whose colour is actually telling you
    // something (you have this / you don't), not just tiering it.
    val proPlusAccent = if (data.premium) Mint else Butter

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain(),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 24.dp, bottom = 28.dp),
        ) {
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val density = LocalDensity.current
                val measurer = rememberTextMeasurer()
                val tracking = 0.42.em
                val ghostSize = remember(maxWidth, density) {
                    val probe = 40.sp
                    val measured = measurer.measure(
                        GHOST,
                        TextStyle(fontSize = probe, letterSpacing = tracking, fontWeight = FontWeight.Bold),
                    ).size.width.toFloat()
                    val trailing = with(density) { probe.toPx() } * 0.42f
                    val target = with(density) { maxWidth.toPx() }
                    if (measured <= trailing) probe else probe * (target / (measured - trailing))
                }
                Text(
                    GHOST,
                    fontSize = ghostSize,
                    lineHeight = ghostSize,
                    letterSpacing = tracking,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                    color = Tang.accent.copy(alpha = 0.13f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .fillMaxWidth()
                        .offset(y = (-18).dp),
                )
                Column(Modifier.fillMaxWidth()) {
                    Text(
                        str.plans.kicker,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = InkMid,
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "SIMPLE, TRANSPARENT PRICING",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.02.em,
                        color = Ink,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        str.plans.subtitle,
                        style = MaterialTheme.typography.bodyLarge,
                        color = InkMid,
                    )

                    Spacer(Modifier.height(14.dp))
                    var secondsLeft by remember { mutableStateOf(5 * 3600 + 59 * 60 + 42) }
                    LaunchedEffect(Unit) {
                        while (secondsLeft > 0) {
                            kotlinx.coroutines.delay(1000)
                            secondsLeft--
                        }
                    }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFFFF6B4A), Color(0xFFE8452A))))
                            .border(2.5.dp, Ink, RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("\uD83D\uDD25", fontSize = 14.sp)
                        Spacer(Modifier.width(6.dp))
                        Column {
                            Text(
                                "Price rises to \u20b9499 once the next 100 spots go",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                            )
                            Text(
                                "%02d:%02d:%02d".format(secondsLeft / 3600, (secondsLeft % 3600) / 60, secondsLeft % 60),
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("\uD83D\uDC66\uD83D\uDC67\uD83E\uDDD1", fontSize = 16.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "500+ students unlocked this month",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = InkMid,
                        )
                    }

                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("\uD83D\uDD25 SELLING FAST", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Ink)
                        Text("82 / 100 claimed", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Ink)
                    }
                    Spacer(Modifier.height(4.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color.White)
                            .border(2.dp, Ink, RoundedCornerShape(999.dp)),
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(0.82f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(999.dp))
                                .background(Brush.horizontalGradient(listOf(Color(0xFFFF6B4A), Color(0xFFE8452A)))),
                        )
                    }
                }
            }

            Spacer(Modifier.height(26.dp))

            // ---- Free — flat, quiet, no glow ---------------------------------------
            Box(Modifier.fillMaxWidth()) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .hardShadow(offset = 6.dp)
                        .clip(RoundedCornerShape(Paper.CardRadius))
                        .background(CreamCard)
                        .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                        .padding(18.dp),
                ) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            PlanIcon(sticker = Mint, art = TileArt.Shield, size = 36.dp)
                            Spacer(Modifier.width(10.dp))
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CreamCard)
                                    .border(2.dp, Ink, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 10.dp, vertical = 5.dp),
                            ) {
                                Text("BASIC", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = InkMid)
                            }
                        }
                        if (!data.premium) Tag(str.plans.youreOnThis, Mint)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("\u20b90", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.fillMaxWidth().height(2.dp).background(Ink.copy(alpha = 0.12f)))
                    Spacer(Modifier.height(12.dp))
                    PlanLine(str.plans.freeBlocking)
                    PlanLine(str.plans.freeFeeds)
                    PlanLine(str.plans.freeTimer)
                    PlanLine(str.plans.freePact)
                    PlanLine(str.plans.freePanic)
                    PlanLine(str.plans.freeExamAlerts)
                    PlanLine(str.plans.freeStats)
                    PlanLine(str.plans.freeStudyMode, str.plans.freeStudyNote(Doubt.FREE_SESSION))
                    PlanLine(str.plans.freePoster)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        str.plans.freeThemesNote,
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                    )
                }
                DotCluster(
                    color = Mint.fill,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = (-14).dp, y = (-8).dp),
                )
                Image(
                    painter = painterResource(R.drawable.mascot_free),
                    contentDescription = null,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .offset(x = 4.dp, y = 8.dp)
                        .size(84.dp),
                )
            }

            Spacer(Modifier.height(20.dp))

            // ---- Pro — the middle tier ---------------------------------------------
            Aura(color = Sky.fill, modifier = Modifier.fillMaxWidth(), strength = 0.32f) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .hardShadow(offset = 6.dp)
                        .clip(RoundedCornerShape(Paper.CardRadius))
                        .background(CreamCard)
                        .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                        .padding(18.dp),
                ) {
                    Column(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                PlanIcon(sticker = Sky, art = TileArt.Medal, size = 40.dp)
                                Spacer(Modifier.width(10.dp))
                                Box(
                                    Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Sky.fill)
                                        .border(2.dp, Ink, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 10.dp, vertical = 5.dp),
                                ) {
                                    Text("PRO", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Sky.on)
                                }
                            }
                            Text("\u20b9199", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "One-time \u00b7 study tools without the full unlock",
                            style = MaterialTheme.typography.labelSmall,
                            color = InkMid,
                        )
                        Spacer(Modifier.height(12.dp))
                        Box(Modifier.fillMaxWidth().height(2.dp).background(Ink.copy(alpha = 0.12f)))
                        Spacer(Modifier.height(12.dp))
                        PlanLine(str.plans.allThemes, str.plans.allThemesNote)
                        PlanLine(str.plans.mockTest, str.plans.mockNote(Mock.COUNT))
                        PlanLine(str.plans.posterBackdrop)
                        PlanLine(str.plans.perSessionLabel, str.plans.perSession(Doubt.PER_SESSION, Doubt.FREE_SESSION))
                        Spacer(Modifier.height(14.dp))
                        SquishButton(
                            label = if (data.premium) str.plans.unlocked else "Get Pro",
                            sticker = Sky,
                            enabled = !data.premium,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { haptics.confirm(); onBuy() },
                        )
                    }
                }
                DotCluster(
                    color = Sky.fill,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .offset(x = 10.dp, y = 10.dp),
                )
                Image(
                    painter = painterResource(R.drawable.mascot_pro),
                    contentDescription = null,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .offset(x = 4.dp, y = 8.dp)
                        .size(84.dp),
                )
            }

            Spacer(Modifier.height(20.dp))

            // ---- Pro Plus — the tier the screen is built to sell -------------------
            Aura(color = proPlusAccent.fill, modifier = Modifier.fillMaxWidth(), strength = 0.5f) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .hardShadow(offset = 7.dp, color = proPlusAccent.fill)
                        .clip(RoundedCornerShape(Paper.CardRadius))
                        .background(Brush.radialGradient(listOf(Color(0xFF2A2116), Color(0xFF14110B), Color(0xFF0C0A06))))
                        .border(Paper.Outline, proPlusAccent.fill, RoundedCornerShape(Paper.CardRadius))
                        .scanSweep()
                        .padding(20.dp),
                ) {
                    Column(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top,
                        ) {
                            ProPlusIcon(accent = proPlusAccent, size = 48.dp)
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    if (data.premium) str.plans.yours else "\u20b9399",
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1,
                                )
                                if (!data.premium) {
                                    Text(
                                        "One-time \u00b7 yours forever",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White.copy(alpha = 0.55f),
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.height(14.dp))
                        Text(
                            "${str.plans.productName} PLUS",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "Everything in Pro, and nothing left locked.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.55f),
                        )

                        Spacer(Modifier.height(16.dp))
                        Box(Modifier.fillMaxWidth().height(2.dp).background(Color.White.copy(alpha = 0.14f)))
                        Spacer(Modifier.height(16.dp))

                        // Pro Plus exclusive: everything Pro has, plus the two
                        // things this codebase can actually gate hardest — full
                        // mode access and a doubt from a photo — plus Crown, which
                        // is a commitment device, not a blocker, so it belongs on
                        // the top tier rather than the free one.
                        PlanLine(str.plans.allModes, str.plans.allModesNote, highlight = true, dark = true)
                        PlanLine(str.plans.photoPdf, dark = true)
                        PlanLine(str.plans.crownMode, str.plans.crownNote, dark = true)
                        PlanLine(str.plans.allThemes, str.plans.allThemesNote, dark = true)
                        PlanLine(str.plans.mockTest, str.plans.mockNote(Mock.COUNT), dark = true)
                        PlanLine(str.plans.posterBackdrop, dark = true)
                        PlanLine(str.plans.perSessionLabel, str.plans.perSession(Doubt.PER_SESSION, Doubt.FREE_SESSION), dark = true)

                        Spacer(Modifier.height(18.dp))
                        SquishButton(
                            label = if (data.premium) str.plans.unlocked else str.plans.unlockLifetime,
                            sticker = proPlusAccent,
                            enabled = !data.premium,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { haptics.confirm(); onBuy() },
                        )

                        Spacer(Modifier.height(10.dp))
                        if (data.premium) {
                            var confirmRemove by remember { mutableStateOf(false) }
                            Text(
                                "Key: ${License.pretty(data.licenseKey)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.55f),
                                modifier = Modifier
                                    .align(Alignment.CenterHorizontally)
                                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                                        haptics.tap(); confirmRemove = true
                                    }
                                    .padding(6.dp),
                            )
                            if (confirmRemove) {
                                Dialog(onDismissRequest = { confirmRemove = false }) {
                                    Column(
                                        Modifier
                                            .fillMaxWidth()
                                            .hardShadow(offset = 6.dp)
                                            .clip(RoundedCornerShape(Paper.CardRadius))
                                            .background(CreamCard)
                                            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                                            .padding(18.dp),
                                    ) {
                                        Text("Key hatao?", style = MaterialTheme.typography.headlineSmall, color = Ink)
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            "Premium is phone se hat jayega. Wahi key doosre " +
                                                "phone pe daal sakte ho.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = InkMid,
                                        )
                                        Spacer(Modifier.height(16.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            SquishButton(
                                                label = "Rehne do",
                                                sticker = Mint,
                                                modifier = Modifier.weight(1f),
                                                onClick = { haptics.tap(); confirmRemove = false },
                                            )
                                            SquishButton(
                                                label = "Hatao",
                                                sticker = Sticker(CreamCard, Ink, Tang.accent),
                                                modifier = Modifier.weight(1f),
                                                onClick = { haptics.press(); confirmRemove = false; onRemove() },
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            Box(
                                Modifier
                                    .align(Alignment.CenterHorizontally)
                                    .clip(RoundedCornerShape(999.dp))
                                    .border(2.dp, Color.White.copy(alpha = 0.55f), RoundedCornerShape(999.dp))
                                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                                        haptics.tap(); keyOpen = true
                                    }
                                    .padding(horizontal = 16.dp, vertical = 9.dp),
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Filled.VpnKey,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Spacer(Modifier.width(7.dp))
                                    Text(
                                        str.plans.haveKey,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.height(20.dp))
                        Column {
                            Text(
                                if (data.premium) str.plans.ownedHeader else str.plans.lockedHeader,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.45f),
                            )
                            Spacer(Modifier.height(10.dp))
                            PremiumPeek(locked = !data.premium, title = str.plans.peekModesTitle, body = str.plans.peekModesBody, art = TileArt.Person, tone = Lilac)
                            Spacer(Modifier.height(8.dp))
                            PremiumPeek(locked = !data.premium, title = str.plans.peekPageTitle, body = str.plans.peekPageBody, art = TileArt.Camera, tone = Sky)
                            Spacer(Modifier.height(8.dp))
                            PremiumPeek(locked = !data.premium, title = str.plans.peekThemesTitle, body = str.plans.peekThemesBody, art = TileArt.Palette, tone = Mint)
                        }

                        Spacer(Modifier.height(14.dp))
                        Text(
                            str.plans.nothingBlocked,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.5f),
                            modifier = Modifier.align(Alignment.CenterHorizontally),
                        )
                    }
                }

                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = (-13).dp),
                ) {
                    Tag(if (data.premium) str.plans.yours.uppercase() else str.plans.bestValue, proPlusAccent, crown = true)
                }
                if (!data.premium) {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = (-10).dp, y = 10.dp)
                            .graphicsLayer { rotationZ = 4f }
                            .clip(RoundedCornerShape(8.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFFFF6B4A), Color(0xFFE8452A))))
                            .border(2.5.dp, Ink, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                    ) {
                        Text("\uD83D\uDD25 HOT", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                    }
                }
                DotCluster(
                    color = proPlusAccent.fill,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .offset(x = (-16).dp, y = (-16).dp),
                )
                Image(
                    painter = painterResource(R.drawable.mascot_pro_plus),
                    contentDescription = null,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .offset(x = (-4).dp, y = 8.dp)
                        .size(84.dp),
                )
            }

            if (keyOpen) {
                LicenseDialog(
                    onRedeem = onRedeem,
                    onClose = { keyOpen = false },
                )
            }

            Spacer(Modifier.height(22.dp))
            SquishButton(
                label = str.plans.back,
                sticker = Sticker(CreamCard, Ink, Ink),
                modifier = Modifier.fillMaxWidth(),
                onClick = { haptics.tap(); onDone() },
            )
        }
    }
}

/**
 * FlowRow, not Row: the label used to sit in a Modifier.weight(1f,
 * fill = false) slot next to a same-row badge that had no width cap of its
 * own (softWrap = false measures it at full intrinsic width). A short badge
 * left enough room and it never showed; the longest one on this screen,
 * "20 questions per session", ate almost the entire row, leaving the label
 * a sliver of width so narrow Android had to break every word onto its own
 * line, letter by letter. FlowRow keeps the badge inline when it fits and
 * drops it to its own line when it doesn't, so the label always gets the
 * full row to wrap normally either way.
 *
 * [dark] switches the text between ink-on-paper (the Free and Pro cards)
 * and white-on-ink (the Pro Plus card, which stays a dark sticker rather
 * than a paper one — see the comment on [proPlusAccent]).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlanLine(text: String, note: String? = null, highlight: Boolean = false, dark: Boolean = false) {
    Row(
        Modifier.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(18.dp)
                .clip(CircleShape)
                .background(Mint.fill.copy(alpha = 0.92f)),
            contentAlignment = Alignment.Center,
        ) {
            Text("\u2713", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Mint.on)
        }
        Spacer(Modifier.width(10.dp))
        FlowRow(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(
                text,
                style = MaterialTheme.typography.bodyLarge,
                color = if (dark) Color.White.copy(alpha = 0.92f) else Ink,
                fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal,
            )
            if (note != null) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (dark) GoldNeon.copy(alpha = 0.18f) else Butter.fill.copy(alpha = 0.45f))
                        .border(1.dp, if (dark) GoldNeon.copy(alpha = 0.45f) else Ink.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 7.dp, vertical = 2.dp),
                ) {
                    Text(
                        note,
                        maxLines = 1,
                        softWrap = false,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (dark) GoldNeon else InkMid,
                    )
                }
            }
        }
    }
}

/** A tilted comic sticker badge — matches the reference's own `.sticker` class: a flat fill, a thick ink border, a hard shadow, a slight rotation. */
@Composable
private fun Tag(label: String, sticker: Sticker, crown: Boolean = false) {
    Box(
        Modifier
            .graphicsLayer { rotationZ = -2.5f }
            .hardShadow(offset = 3.dp, radius = 999.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(sticker.fill)
            .border(2.dp, Ink, RoundedCornerShape(999.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (crown) {
                CrownMark(size = 13.dp)
                Spacer(Modifier.width(5.dp))
            }
            Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = sticker.on)
        }
    }
}

@Composable
private fun LicenseDialog(
    onRedeem: suspend (String) -> Boolean,
    onClose: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .hardShadow(offset = 6.dp)
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(20.dp),
        ) {
            Text(str.plans.keyTitle, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(4.dp))
            Text(str.plans.keyHint, style = MaterialTheme.typography.headlineSmall, color = Ink)
            Spacer(Modifier.height(14.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(24); error = false },
                placeholder = { Text(str.plans.keyPlaceholder, color = InkLow) },
                singleLine = true,
                isError = error,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Ink,
                    unfocusedTextColor = Ink,
                    focusedBorderColor = Ink,
                    unfocusedBorderColor = Ink.copy(alpha = 0.35f),
                    cursorColor = Ink,
                ),
                modifier = Modifier.fillMaxWidth(),
            )

            if (error) {
                Spacer(Modifier.height(8.dp))
                Text(str.plans.keyWrong, style = MaterialTheme.typography.bodyMedium, color = Tang.accent)
            }

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SquishButton(
                    label = str.plans.cancel,
                    sticker = Sticker(CreamCard, Ink, Ink),
                    modifier = Modifier.weight(1f),
                    onClick = onClose,
                )
                SquishButton(
                    label = if (checking) str.plans.checking else str.plans.unlock,
                    sticker = Mint,
                    enabled = !checking && text.isNotBlank(),
                    modifier = Modifier.weight(1f),
                    onClick = {
                        checking = true
                        scope.launch {
                            val ok = onRedeem(text)
                            checking = false
                            if (ok) { haptics.confirm(); onClose() }
                            else { haptics.press(); error = true }
                        }
                    },
                )
            }
        }
    }
}

/**
 * One locked/unlocked feature preview row inside the Pro Plus card.
 *
 * BUG FIX: the title used to be capped at `maxLines = 1` with an ellipsis,
 * which is exactly what the recording shows going wrong — "Friend and…",
 * "Send a pa…", "Every the…" — a real word cut mid-sentence next to a
 * button that is asking for money. Two lines is enough room for every
 * title this row is actually given; there is nothing left below the fold
 * of the card that a slightly taller row would push off it.
 */
@Composable
private fun PremiumPeek(
    locked: Boolean,
    title: String,
    body: String,
    art: TileArt,
    tone: Sticker,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Color.White.copy(alpha = if (locked) 0.10f else 0.18f), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .alpha(if (locked) 0.72f else 1f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PlanIcon(sticker = tone, art = art, size = 40.dp, iconSize = 18.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(1.dp))
            Text(
                body,
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.6f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (locked) {
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(GoldNeon)
                    .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            ) {
                Text("PRO", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Ink)
            }
        }
    }
}
