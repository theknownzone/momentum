package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.ReleaseNotes
import com.momentum.focus.data.tr
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * "Update landed" — the ONE thing shown after an update (2026-10-07; owner:
 * the update animation was old and the notes were stale). Replaces the
 * bouncy glass WhatsNewPopup (which also auto-hid after 9s, before anyone
 * could read it) and stands in for the Home "Updated to" strip.
 *
 * Notes come from assets/release_notes.md via ReleaseNotes — the same file
 * CI publishes as the GitHub release — so this card, the full log and the
 * release can never disagree.
 *
 * Motion, paced not bouncy:
 *   0     sheet rises 40dp, dim fades in
 *   250   build number rolls like an odometer from the old build to the new
 *         one, digit by digit (90ms stagger, spring)           TICK per digit
 *   ~800  ink underline draws under it                         CHIME
 *   900+  notes rise one by one (80ms stagger, 380ms ease)
 * Nothing auto-closes. "Let's go" (DONE) or tap outside; "Full log" opens
 * the history.
 */
@Composable
fun UpdateLanded(
    oldVersion: String,
    newVersion: String,
    onFullLog: () -> Unit,
    onDone: () -> Unit,
) {
    val ctx = LocalContext.current
    val haptics = rememberHaptics()
    val sections = remember { ReleaseNotes.sections(ctx) }
    val rise = remember { Animatable(0f) }
    val line = remember { Animatable(0f) }
    var itemsFrom by remember { mutableStateOf(Long.MAX_VALUE) }
    var now by remember { mutableLongStateOf(0L) }
    var closed by remember { mutableStateOf(false) }
    fun close(full: Boolean) {
        if (closed) return
        closed = true
        haptics.confirm()
        Sfx.play(Sound.DONE)
        if (full) onFullLog() else onDone()
    }

    val prefix = newVersion.substringBeforeLast('.', "")
    val newNum = newVersion.substringAfterLast('.')
    val oldNum = oldVersion.substringAfterLast('.').takeIf { it.all(Char::isDigit) && it.isNotEmpty() }
        ?.padStart(newNum.length, '0')?.takeLast(newNum.length) ?: "0".repeat(newNum.length)
    val digits = remember(newNum) { newNum.map { Animatable(0f) } }

    LaunchedEffect(Unit) {
        launch { rise.animateTo(1f, tween(420)) }
        delay(250)
        digits.forEachIndexed { i, a ->
            launch {
                delay(i * 90L)
                Sfx.play(Sound.TICK)
                a.animateTo(1f, spring(dampingRatio = 0.8f, stiffness = 140f))
            }
        }
        delay(250L + digits.size * 90L)
        Sfx.playOnce(Sound.CHIME, 1.12f)
        haptics.tick()
        launch { line.animateTo(1f, tween(420)) }
        itemsFrom = System.currentTimeMillis() + 100
        while (true) { withFrameMillis { now = System.currentTimeMillis() }; if (now - itemsFrom > 3000) break }
    }
    fun itemP(i: Int): Float {
        val t = (now - itemsFrom - i * 80L).toFloat() / 380f
        val x = t.coerceIn(0f, 1f)
        return 1f - (1f - x) * (1f - x) * (1f - x)
    }

    FitDialog(onDismiss = { close(false) }) { usable ->
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = rise.value }
                .background(Ink.copy(alpha = 0.5f))
                .clickableNoRipple(remember { MutableInteractionSource() }) { close(false) },
        )
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
                .heightIn(max = usable * 0.82f)
                .graphicsLayer {
                    alpha = rise.value
                    translationY = (1f - rise.value) * 40.dp.toPx()
                }
                .drawBehind {
                    val d = 6.dp.toPx()
                    drawRoundRect(Ink, Offset(d, d), size, CornerRadius(24.dp.toPx()))
                }
                .clip(RoundedCornerShape(24.dp))
                .background(Cream)
                .border(Paper.Outline, Ink, RoundedCornerShape(24.dp))
                .clickableNoRipple(remember { MutableInteractionSource() }) { },
        ) {
            Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp)) {
                Text(
                    tr("UPDATE LANDED", "अपडेट आ गया"),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.6.sp,
                    color = Mint.accent,
                )
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    if (prefix.isNotEmpty()) {
                        Text("$prefix.", fontSize = 40.sp, lineHeight = 46.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace, color = Ink.copy(alpha = 0.35f))
                    }
                    newNum.forEachIndexed { i, ch ->
                        RollDigit(oldNum.getOrElse(i) { '0' }, ch, digits[i].value)
                    }
                }
                // Ink underline that draws itself once the number lands.
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .drawBehind {
                            val y = size.height / 2f
                            drawLine(Ink, Offset(0f, y), Offset(size.width * line.value, y), 3.dp.toPx(), StrokeCap.Round)
                        },
                )
            }
            Column(
                Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 10.dp),
            ) {
                var k = 0
                sections.forEachIndexed { s, sec ->
                    val fixed = sec.heading.equals("fixed", true) || sec.heading == "ठीक किया"
                    val sticker = if (fixed) Sky else Butter
                    if (sec.heading.isNotBlank()) {
                        val p = itemP(k)
                        Text(
                            sec.heading.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp,
                            color = InkMid,
                            modifier = Modifier
                                .padding(top = if (s == 0) 4.dp else 14.dp, bottom = 6.dp)
                                .graphicsLayer { alpha = p },
                        )
                    }
                    sec.items.forEach { item ->
                        val p = itemP(k++)
                        Row(
                            Modifier
                                .padding(vertical = 5.dp)
                                .graphicsLayer { alpha = p; translationY = (1f - p) * 14.dp.toPx() },
                            verticalAlignment = Alignment.Top,
                        ) {
                            Box(
                                Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(sticker.fill)
                                    .border(2.dp, Ink, RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    if (fixed) Icons.Filled.Build else Icons.Filled.AutoAwesome,
                                    contentDescription = null,
                                    tint = Ink,
                                    modifier = Modifier.size(15.dp),
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(item.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Ink)
                                if (item.sub.isNotBlank()) {
                                    Text(item.sub, style = MaterialTheme.typography.bodySmall, color = InkMid)
                                }
                            }
                        }
                    }
                }
                if (sections.isEmpty()) {
                    Text(tr("Small fixes under the hood.", "अंदर कुछ छोटे सुधार।"), style = MaterialTheme.typography.bodyMedium, color = InkMid)
                }
            }
            Row(
                Modifier.padding(start = 12.dp, end = 20.dp, top = 6.dp, bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    tr("Full log", "पूरा लॉग"),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = Ink,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickableNoRipple(remember { MutableInteractionSource() }) { close(true) }
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                )
                Spacer(Modifier.width(6.dp))
                SquishButton(tr("Let's go", "चलो"), Mint, Modifier.weight(1f)) { close(false) }
            }
        }
    }
}

/** One odometer wheel: rolls from [from] up to [to] as [p] goes 0 → 1. */
@Composable
private fun RollDigit(from: Char, to: Char, p: Float) {
    val a = from.digitToIntOrNull() ?: 0
    val b = to.digitToIntOrNull() ?: 0
    // Always roll forward; a changed number with the same digit here still
    // does a full turn so the eye reads "this moved".
    val steps = ((b - a + 10) % 10).let { if (it == 0 && from != to) 10 else it }
    val h = 46.dp
    Box(Modifier.height(h).clipToBounds()) {
        Column(
            Modifier
                .wrapContentHeight(align = Alignment.Top, unbounded = true)
                .graphicsLayer { translationY = -p * steps * h.toPx() },
        ) {
            for (k in 0..steps) {
                Text(
                    ((a + k) % 10).toString(),
                    fontSize = 40.sp,
                    lineHeight = 46.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = Ink,
                    modifier = Modifier.height(h),
                )
            }
        }
    }
}
