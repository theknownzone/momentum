package com.momentum.focus.ui.screens

import androidx.compose.material.icons.filled.AccountBalanceWallet
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.Sfx
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Umbrella
import com.momentum.focus.ui.components.GlowProgressBar
import com.momentum.focus.data.tr

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.drawscope.Stroke
import com.momentum.focus.ui.components.CrownMark
import com.momentum.focus.ui.components.SyncPulse
import com.momentum.focus.ui.components.BlockedAppsPopup
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import com.momentum.focus.ui.components.BaselineReveal
import com.momentum.focus.ui.components.BrokenNotice
import com.momentum.focus.ui.components.SkinWeather
import com.momentum.focus.ui.components.HeroAtmosphere
import com.momentum.focus.ui.components.isReal
import com.momentum.focus.ui.components.UpdatedStrip
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileObject
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.window.Dialog
import com.momentum.focus.ui.components.FrostCard
import com.momentum.focus.ui.components.clickableNoRipple
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.composed
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.momentum.focus.R
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.derivedStateOf
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.animation.core.Animatable
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.Currency
import com.momentum.focus.data.ExamNews
import com.momentum.focus.data.ExamNewsItem
import com.momentum.focus.data.HolidayCalendar
import com.momentum.focus.data.ScreenTime
import com.momentum.focus.data.Weather
import com.momentum.focus.data.WeatherCondition
import com.momentum.focus.data.WeatherSnapshot
import com.momentum.focus.data.FocusSession
import com.momentum.focus.data.unlockedCount
import androidx.compose.foundation.Canvas
import com.momentum.focus.block.Heartbeat
import com.momentum.focus.ui.components.rakhiMotif
import com.momentum.focus.ui.components.PactBanner
import com.momentum.focus.ui.components.*
import com.momentum.focus.ui.i18n.Strings
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.OemStartup
import com.momentum.focus.ui.util.rememberHaptics
import java.time.LocalDate
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

/**
 * Two-plane dashboard: a dark hero card holding identity and the balance,
 * sitting on a cream body that carries everything else.
 *
 * The split is doing real work. The dark plane is where the number that
 * matters lives, so the eye goes there first every time the app opens; the
 * cream plane is where you act. One surface for status, one for doing.
 */

/**
 * Survives what the Composable state around it does not: switching to
 * another tab and back disposes HomeScreen entirely (the nav `when` in
 * MainActivity only ever composes the current tab), so every `remember`
 * inside it — the weather badge, the exam-news sync, the greeting's
 * one-time typing — was quietly starting over on every single visit, not
 * once per app launch the way each of them was written and commented to
 * behave. Two real network calls and a 20-character animated retype, every
 * time someone tapped back to Home, is the lag that was actually being felt.
 * A plain object outside Compose's lifecycle remembers across that disposal
 * for the life of the process, which is all "once per launch" ever meant.
 */
private object HomeSession {
    var weather: WeatherSnapshot? = null
    var weatherChecked = false
    var news: List<ExamNewsItem>? = null
    var newsFetchedAt: Long = 0L
    var greetingPlayed = false
    var phoneToday = 0
    var billboardSwept = false
}

private const val NEWS_TTL_MS = 60 * 60 * 1000L

/** True when there's no cached news yet, or the cache is over an hour old. */
private fun newsIsStale(): Boolean =
    HomeSession.news == null || System.currentTimeMillis() - HomeSession.newsFetchedAt > NEWS_TTL_MS

/** "Synced just now" / "Synced 12m ago" — visible proof the fetch actually ran, not just presence of a cache. */
private fun syncedAgoLabel(): String? {
    if (HomeSession.newsFetchedAt <= 0L) return null
    val mins = (System.currentTimeMillis() - HomeSession.newsFetchedAt) / 60_000L
    return when {
        mins < 1 -> "Synced just now"
        mins < 60 -> "Synced ${mins}m ago"
        else -> "Synced ${mins / 60}h ago"
    }
}

@Composable
fun HomeScreen(
    data: AppData,
    onStartFocus: () -> Unit,
    onPanic: () -> Unit,
    onJournal: () -> Unit,
    onProfile: () -> Unit,
    onShield: () -> Unit,
    onFeeds: () -> Unit,
    onRewards: () -> Unit,
    onNotify: (Boolean) -> Unit = {},
    onPerms: () -> Unit = {},
    /** Non-null only right after an update, and only until dismissed. */
    updatedVersion: String? = null,
    onOpenChangelog: () -> Unit = {},
    onDismissUpdate: () -> Unit = {},
    hitPremiumWall: Boolean = false,
    onPlans: () -> Unit = {},
    justUpdatedAt: Long? = null,
    currentVersion: String = "",
    onDismissFreeze: () -> Unit = {},
) {
    var bellOpen by remember { mutableStateOf(false) }
    val str = strings()
    val haptics = rememberHaptics()
    val context = androidx.compose.ui.platform.LocalContext.current
    // Was reading a week of UsageStats on the main thread every time Home
    // came back into view — that was the hang on tab switch. Now: last value
    // shows instantly from the session cache, the fresh read runs on IO.
    val phoneToday by produceState(HomeSession.phoneToday, context) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching { ScreenTime.report(context).dailyMinutes.lastOrNull() ?: 0 }.getOrDefault(0)
        }
        HomeSession.phoneToday = value
    }
    var holidays by remember { mutableStateOf(HolidayCalendar.bundled(context)) }
    // Exam notices. Bundled copy renders instantly, the remote copy replaces it
    // when the network allows; a failed fetch simply leaves what is on device.
    var news by remember { mutableStateOf(HomeSession.news ?: ExamNews.bundled(context)) }
    // No region lookup here any more. The catalogue's region field holds "IN"
    // or "World", never a state, so feeding it to the matcher only ever looked
    // like state filtering — the Rajasthan notices actually reach RPSC and REET
    // candidates through the exam name itself.
    var alert by remember { mutableStateOf<ExamNewsItem?>(null) }
    // Bumped whenever anything marks a notice read, because the seen-set lives
    // in SharedPreferences and Compose cannot see it change.
    //
    // The bell count was keyed only on the feed and the exam name, so a write
    // to the seen-set moved neither key and the badge kept whatever number it
    // was last given. Opening the bell left the count sitting there; the
    // launch popup marking one read did nothing to it. It only ever corrected
    // itself by accident, when some unrelated field of data happened to change
    // and force a recompute.
    var seenEpoch by remember { mutableStateOf(0) }
    // Real this time — the wash used to only exist in an HTML preview.
    // True for the actual span of the network call, not a fixed timer, so
    // it never lies about how long the check took.
    var syncingNews by remember { mutableStateOf(newsIsStale()) }
    // Shield used to take a tap on Home straight into the full BlockHub
    // screen just to answer "which apps did I actually turn on" — a whole
    // navigation for a question that is really just a look. This shows
    // that look here instead; "Manage" inside it is what still reaches
    // BlockHub, for the times the answer is actually "let me change one".
    var showBlockedPopup by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        // BUG FIX: this used to skip the fetch whenever HomeSession.news
        // was non-null at all — "already fetched once this process", not
        // "still fresh". A focus app is exactly the kind of thing people
        // leave running for hours without force-closing it, so that read
        // in practice as "exam news updates the first time Home opens
        // after an install or reboot, and never again for as long as the
        // process survives" — notices frozen at whatever they were hours
        // or days ago. Checking staleness instead of mere presence is the
        // actual fix; the hour window matches the cache-busting
        // ExamNews.refresh() already does against GitHub's CDN, so this
        // isn't a new freshness policy, just finally acting on the one
        // that was already there.
        if (!newsIsStale()) {
            alert = ExamNews.nextUnseen(context, news, data.examName)
            return@LaunchedEffect
        }
        // A cache hit (see ExamNews) can resolve in a handful of
        // milliseconds — the AnimatedVisibility fade barely had a frame to
        // paint before it was already fading back out, which is why the
        // sync at the bottom of this card was invisible in practice rather
        // than actually broken. A floor on how long the pulse stays up
        // fixes that without touching how long the real fetch takes.
        val start = System.currentTimeMillis()
        news = ExamNews.refresh(context)
        HomeSession.news = news
        HomeSession.newsFetchedAt = System.currentTimeMillis()
        val elapsed = System.currentTimeMillis() - start
        if (elapsed < 700L) delay(700L - elapsed)
        syncingNews = false
        haptics.tick()
        // Interrupts once per announcement, and only for an announcement that
        // is relevant to this profile.
        alert = ExamNews.nextUnseen(context, news, data.examName)
    }
    alert?.let { item ->
        ExamNewsPopup(item) {
            ExamNews.markSeen(context, item)
            seenEpoch++
            alert = null
        }
    }
    if (showBlockedPopup) {
        BlockedAppsPopup(
            blockedPackages = data.blockedPackages,
            dailyCapMinutes = data.dailyCapMinutes,
            blockedSince = data.blockedSince,
            onManage = onFeeds,
            onClose = { showBlockedPopup = false },
        )
    }
    LaunchedEffect(Unit) {
        holidays = HolidayCalendar.refresh(context)
        if (HolidayCalendar.inSeason(holidays) != null) haptics.festive()
    }
    // One weather check per cache window, same "runs, then leaves it alone"
    // shape as everything else here — see Weather.kt for why this needs no
    // location permission and no continuous polling.
    var weather by remember { mutableStateOf(HomeSession.weather) }
    LaunchedEffect(Unit) {
        if (HomeSession.weatherChecked) return@LaunchedEffect
        weather = Weather.sync(context)
        HomeSession.weather = weather
        HomeSession.weatherChecked = true
    }
    val season = remember(holidays) { HolidayCalendar.inSeason(holidays) }
    val nextHoliday = remember(holidays) { HolidayCalendar.upcoming(holidays) }
    // Used to be `season?.skin ?: skinFor(data.skin)` — on any day that
    // matches an entry in holidays.json (which is most weeks; there is one
    // roughly every 1-3 weeks all year) the hero colour and the weather
    // effect behind it silently switched to that festival's skin, no matter
    // what the person had actually picked in Profile. Today (Ganesh
    // Chaturthi, GOLD) is one of those days — which is exactly the "I pick a
    // theme and something else shows up" bug. The festival still gets its
    // moment: `festSkin` below still carries season?.skin to the Hero, which
    // still lays the Diwali lamp / Rakhi motif / Janmashtami feather art on
    // top and still fires the one-time festive haptic. It just no longer
    // repaints the whole hero over the top of a choice the person actually
    // made — if they want the festival's own colours and weather, that skin
    // is sitting right there in the picker, unlocked, for them to choose.
    val liveSkin = skinFor(data.skin)

    val homeScroll = rememberScrollState()
    Box(Modifier.fillMaxSize()) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .verticalScroll(homeScroll),
    ) {
        val unseen = remember(news, data.examName, seenEpoch) {
            ExamNews.unseenCount(context, news, data.examName)
        }
        // What was unread at the moment the bell was tapped. Held separately
        // because opening the bell marks everything read: without this the
        // sheet would recompute against a seen-set that had just been filled
        // in and show an empty "new" section every single time.
        var freshNotices by remember { mutableStateOf<List<ExamNewsItem>>(emptyList()) }
        Hero(
            data, str, liveSkin, season?.skin, phoneToday, onProfile,
            {
                // Opening the bell is reading them. Leaving the badge up after
                // the sheet has been opened makes it a number that never goes
                // down, and a badge nobody can clear is one people stop
                // looking at.
                freshNotices = ExamNews.unseen(context, news, data.examName)
                ExamNews.markAllSeen(context, news)
                seenEpoch++
                bellOpen = true
            },
            onStartFocus,
            onShield = { showBlockedPopup = true },
            onFeeds = onFeeds,
            unseenNotices = unseen,
            weather = weather,
            hitPremiumWall = hitPremiumWall,
            onPlans = onPlans,
            justUpdatedAt = justUpdatedAt,
            currentVersion = currentVersion,
            scrollPx = { homeScroll.value },
            onDismissFreeze = onDismissFreeze,
        )
        // Room of its own now — this used to sit wedged between the phone-
        // today line and the earned-today prompt, competing with the
        // balance number it was two lines away from. A standalone card
        // right under the hero is the same "room to breathe" every other
        // card on this screen already gets.
        // The FOCUS TODAY goal card is now the bar inside the hero's FOCUS tile.
        if (bellOpen) {
            // Opening the inbox always pulls the latest feed, not the copy
            // from when Home first opened.
            LaunchedEffect(Unit) {
                val fresh = ExamNews.refresh(context)
                news = fresh; HomeSession.news = fresh; HomeSession.newsFetchedAt = System.currentTimeMillis()
            }
            NotifySheet(
                on = data.notifyOn,
                fresh = freshNotices,
                earlier = ExamNews.relevant(news, data.examName)
                    .filter { item -> freshNotices.none { it.id == item.id } },
                onToggle = onNotify,
                onClose = { bellOpen = false },
            )
        }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 18.dp, bottom = 28.dp),
        ) {
            UpdateCard(Modifier.fillMaxWidth())

            if (syncingNews) {
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        // Was CreamCard — SyncPulse's dots are white and its
                        // wash is a low-alpha colour blend, both tuned for a
                        // dark backdrop (the artifact preview it started in).
                        // White dots on cream is why this was never actually
                        // seen: it was rendering the whole time, just at
                        // white-on-white-ish contrast.
                        .background(Color(0xFF15121D)),
                ) {
                    SyncPulse(visible = true, modifier = Modifier.matchParentSize())
                }
            }
            ExamNews.relevant(news, data.examName).let { relevant ->
                if (relevant.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    ExamNewsCard(relevant, Modifier.fillMaxWidth(), syncedLabel = syncedAgoLabel())
                }
            }

            // Says plainly that the first days are thin rather than dressing
            // three data points up as a trend.
            data.daysCollecting?.takeIf { it < 3 }?.let { days ->
                Spacer(Modifier.height(10.dp))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(CreamCard)
                        .border(Paper.Outline, Ink, RoundedCornerShape(16.dp))
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                ) {
                    Text(
                        str.home.notEnoughData,
                        style = MaterialTheme.typography.labelSmall,
                        color = InkMid,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (days <= 0) str.home.countingFromToday
                        else str.home.countingSince(days),
                        style = MaterialTheme.typography.titleMedium,
                        color = Ink,
                    )
                    Text(
                        str.home.afterThreeDays,
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                    )
                }
            }

            // Only on the day itself. A card counting down for a week sat on
            // Home doing nothing — it is not a task, not a warning, and not
            // something anyone acts on, so it was just a festival taking up the
            // slot the actual state of the app should occupy. Rule 5 already
            // says the skin arrives on the day; the card now matches it.
            nextHoliday?.takeIf { it.daysFrom() == 0L }?.let { h ->
                Spacer(Modifier.height(10.dp))
                // Frosted, as the preview of the iOS-style pass. Works here
                // because the page behind is a known flat cream — see FrostCard.
                FrostCard(
                    tint = h.skin.accent,
                    modifier = Modifier.clickableNoRipple(
                        remember { MutableInteractionSource() }
                    ) { haptics.festive() },
                ) {
                    Column {
                        Text(
                            str.home.calendar,
                            style = MaterialTheme.typography.labelSmall,
                            color = h.skin.accent,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            h.headline,
                            style = MaterialTheme.typography.headlineSmall,
                            color = Ink,
                        )
                        Text(
                            if (h.daysFrom() == 0L)
                                // Was "${h.skin.label} theme ...", which read
                                // "Rakhi theme" under a Ganesh Chaturthi
                                // headline, because several festivals share one
                                // skin. The skin name is not the festival name.
                                str.home.themeLiveToday
                            else
                                str.home.themeArrivesOnDay,
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMid,
                        )
                    }
                }
            }

            if (data.examName.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    data.daysToExam?.let { str.home.examWithDaysLeft(data.examName, it) }
                        ?: data.examName,
                    style = MaterialTheme.typography.titleMedium,
                    color = Ink,
                )
            }

            Spacer(Modifier.height(12.dp))

            // The heartbeat was being written by the service and read by
            // nobody, so an OEM kill stayed invisible — which is the entire
            // problem it existed to surface.
            // Recorded at service restart (Heartbeat.recordIfDead), so it
            // survives the app reopening and the service beating again.
            var deadMins by remember(phoneToday) {
                mutableIntStateOf(runCatching { Heartbeat.outageMinutes(context) }.getOrDefault(0))
            }
            var doctorOpen by remember { mutableStateOf(false) }
            // Opens on its own once per outage — the user should not have to
            // find out why blocking stopped.
            LaunchedEffect(deadMins > 0) { if (deadMins > 0) doctorOpen = true }
            if (doctorOpen) {
                com.momentum.focus.ui.components.ShieldDoctor(deadMins) {
                    doctorOpen = false
                    runCatching { Heartbeat.clearOutage(context) }
                    deadMins = 0
                }
            }
            if (deadMins > 0) {
                // Tappable now, not just a diagnosis.
                //
                // The card already told the user exactly what to do —
                // "Turn Autostart ON" — in a sentence with nowhere to tap. It
                // knew the fix and made the person go find Settings, then
                // Permissions, then the right row themselves. Given how easy
                // that hop is to abandon halfway, the kill was likely to
                // recur, and would surface as "this app sometimes just stops
                // working" rather than as the one specific switch it actually
                // is. OemStartup.open() is the same call the Permissions
                // screen's own Autostart row uses, so tapping here does
                // exactly what tapping there would.
                FrostCard(
                    tint = Tang.fill,
                    modifier = Modifier.clickableNoRipple(
                        remember { MutableInteractionSource() }
                    ) {
                        haptics.tap()
                        doctorOpen = true
                    },
                ) {
                  Column {
                    Text(
                        str.home.shieldWasKilled,
                        style = MaterialTheme.typography.labelSmall,
                        color = Tang.on,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (deadMins >= 60)
                            str.home.deadForHoursMinutes(deadMins / 60, deadMins % 60)
                        else str.home.deadForMinutes(deadMins),
                        style = MaterialTheme.typography.headlineSmall,
                        color = Tang.on,
                    )
                    Text(
                        str.home.shieldKilledBody,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Tang.on,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        tr("Tap to see why + fix it →", "वजह देखो + ठीक करो →"),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Tang.on,
                    )
                  }
                }
                Spacer(Modifier.height(12.dp))
            }

            // Anything switched on that cannot actually run, said out loud.
            // Silent failure is the worst thing this app can do: the switch
            // looks on, the screen looks normal, and the blocking never
            // happens — and the person blames the app rather than the missing
            // permission.
            if (updatedVersion != null) {
                UpdatedStrip(
                    version = updatedVersion,
                    onOpen = onOpenChangelog,
                    onDismiss = onDismissUpdate,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(12.dp))
            }

            BrokenNotice(data, onFix = onPerms, modifier = Modifier.fillMaxWidth())

            PactBanner(data.lockUntilEpochMs, Modifier.fillMaxWidth())

            // The answer to the question setup asked. It sat unanswered in the
            // store from the first launch; this is the first thing in the app
            // that reads it back.
            Spacer(Modifier.height(12.dp))
            BaselineReveal(data, Modifier.fillMaxWidth())

            // Momentum Score, one line (Opal-style single number). Full
            // breakdown stays on Profile — tap goes there.
            Spacer(Modifier.height(12.dp))
            com.momentum.focus.ui.components.ScoreStrip(data, onProfile, Modifier.fillMaxWidth())

            // The score and the four readings left this screen. They belong on
            // Profile, where the rest of "how you are doing" lives — Home is
            // the screen you open to start, and it had grown into a report you
            // scroll past on the way to a button.
            Spacer(Modifier.height(20.dp))
            Text(str.home.quickActions, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard(
                    art = TileArt.Bolt,
                    title = str.home.panic,
                    detail = str.home.panicDetail,
                    sticker = Tang,
                    modifier = Modifier.weight(1f),
                ) { haptics.panic(); onPanic() }
                ActionCard(
                    art = TileArt.Journal,
                    title = str.home.journal,
                    detail = str.home.journalDetail,
                    sticker = Lilac,
                    modifier = Modifier.weight(1f),
                ) { haptics.tap(); onJournal() }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard(
                    art = TileArt.Shield,
                    title = tr("Block", "ब्लॉक"),
                    detail = tr(
                        "${data.blockedPackages.size} apps · ${data.blockedSurfaces.size} feeds",
                        "${data.blockedPackages.size} ऐप · ${data.blockedSurfaces.size} फ़ीड",
                    ),
                    sticker = Mint,
                    modifier = Modifier.weight(1f),
                ) { haptics.tap(); onFeeds() }
                ActionCard(
                    art = TileArt.Coin,
                    title = str.home.rewards,
                    detail = str.home.rewardsDetail(data.unlockedCount),
                    sticker = Butter,
                    modifier = Modifier.weight(1f),
                ) { onRewards() }
            }

            Spacer(Modifier.height(24.dp))

            Text(
                str.home.recent,
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(10.dp))

            val feed = remember(data, str) { buildFeed(data, str) }
            if (feed.isEmpty()) EmptyFeed(str) else feed.forEach { ActivityRow(it) }

            // The deck sits last of the reading matter. Everything above it is
            // about this person; the deck is about studying in general, and
            // general advice belongs after the specifics rather than in front
            // of them.
            Spacer(Modifier.height(20.dp))
            InsightDeck(Modifier.fillMaxWidth())

            Spacer(Modifier.height(36.dp))
            Wordmark(skinFor(data.skin), str)
        }
    }

    // Back to Top (from Uiverse): an ink coin with an up-chevron, shown only
    // once the page is a good way down. derivedStateOf so scrolling does not
    // recompose Home every frame — only the show/hide flip does.
    val farDown by remember { derivedStateOf { homeScroll.value > 1400 } }
    val topScope = rememberCoroutineScope()
    androidx.compose.animation.AnimatedVisibility(
        visible = farDown,
        enter = androidx.compose.animation.scaleIn(Motion.bouncy(), initialScale = 0.6f) + androidx.compose.animation.fadeIn(tween(160)),
        exit = androidx.compose.animation.scaleOut(tween(150), targetScale = 0.6f) + androidx.compose.animation.fadeOut(tween(150)),
        modifier = Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = 18.dp),
    ) {
        BackToTop { topScope.launch { homeScroll.animateScrollTo(0, tween(420, easing = FastOutSlowInEasing)) } }
    }

    // The floating Shield-status pill used to render here, Home-only. It
    // now lives globally in MainActivity (see the Box wrapping the whole
    // Scaffold there) so it follows across every tab, not just this one —
    // pacman was explicit that Home-only made it redundant with this
    // screen's own "Shield" button right above.
    }
}

@Composable
private fun BackToTop(onClick: () -> Unit) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 1f else 0f, Motion.press(), label = "topPress")
    // Arrow rises out of the coin and a fresh one rises in on every tap.
    val fly = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    Canvas(
        Modifier
            .size(48.dp)
            .clickableNoRipple(interaction) {
                haptics.tick()
                scope.launch { fly.snapTo(0f); fly.animateTo(1f, tween(360, easing = FastOutSlowInEasing)) }
                onClick()
            },
    ) {
        val d = 3.dp.toPx() * (1f - press)
        val r = size.minDimension / 2 - 3.dp.toPx()
        val c = Offset(size.width / 2 - 1.5.dp.toPx(), size.height / 2 - 1.5.dp.toPx()) +
            Offset(3.dp.toPx() * press, 3.dp.toPx() * press)
        drawCircle(Ink, r, c + Offset(d, d))
        drawCircle(Butter.fill, r, c)
        drawCircle(Ink, r, c, style = Stroke(Paper.Outline.toPx()))
        clipPath(Path().apply { addOval(androidx.compose.ui.geometry.Rect(c, r - 2.dp.toPx())) }) {
            val k = fly.value
            listOf(-k * r * 1.6f, (1f - k) * r * 1.6f).forEach { dy ->
                if (k == 0f && dy > 0f) return@forEach
                val tip = c + Offset(0f, -r * 0.28f + dy)
                val chevron = Path().apply {
                    moveTo(tip.x - r * 0.38f, tip.y + r * 0.34f)
                    lineTo(tip.x, tip.y)
                    lineTo(tip.x + r * 0.38f, tip.y + r * 0.34f)
                }
                drawPath(chevron, Ink, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawLine(Ink, tip + Offset(0f, 2.dp.toPx()), tip + Offset(0f, r * 0.72f), 3.dp.toPx(), StrokeCap.Round)
            }
        }
    }
}

/**
 * The Home hero-banner carousel — the Vi-style promotional strip the user
 * asked for, built from real triggers rather than a fixed rotation:
 *
 * - "new user": [AppData.onboardedAt] within the last 3 days.
 * - "premium wall": a locked Pro-Plus feature redirected here this
 *   session (see MainActivity's `hitPremiumWall`), and still unpurchased.
 *
 * A third slide — "just updated" — was deliberately left out: this app
 * already has a dedicated changelog screen for exactly that moment (see
 * MainActivity's `newsOpen`), and a second "we updated!" card here would
 * just be announcing the same thing twice.
 *
 * Zero, one, or two slides can be true at once. With zero, this renders
 * nothing at all — no empty card, no placeholder.
 */
@Composable
fun HeroBannerCarousel(
    isNewUser: Boolean,
    hitPremiumWall: Boolean,
    justUpdatedAt: Long?,
    onSetupShield: () -> Unit,
    onSeePlans: () -> Unit,
    /**
     * Forces all three slides on, ignoring their real triggers. The real
     * triggers are all transient (first 3 days, 5 minutes after an update, an
     * unpurchased wall hit), so on a long-installed, already-paid phone the
     * carousel correctly renders nothing — which is also indistinguishable from
     * a broken carousel. This is the "Trigger simulator" from the reference
     * HTML, as a Settings long-press (see SettingsScreen).
     */
    previewAll: Boolean = false,
) {
    // Live-ticking, not computed once — a session that started right after
    // an update and stays on Home past the 5-minute mark should actually
    // see the slide disappear, not have it frozen from first composition.
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(justUpdatedAt) {
        if (justUpdatedAt == null) return@LaunchedEffect
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(15_000)
        }
    }
    val justUpdated = previewAll || (justUpdatedAt != null && (nowMs - justUpdatedAt) < 5 * 60 * 1000)

    data class Slide(
        val id: String, val kicker: String, val headline: String, val cta: String,
        val gradient: List<Color>, val mascotRes: Int, val onClick: () -> Unit,
    )
    val slides = buildList {
        if (isNewUser || previewAll) {
            add(
                Slide(
                    "new_user", "WELCOME TO MOMENTUM", "Block your first app\nin 30 seconds",
                    "Set up Shield", listOf(Color(0xFF4FE8A0), Color(0xFF1C9E5D)),
                    R.drawable.mascot_free, onSetupShield,
                ),
            )
        }
        if (justUpdated) {
            add(
                Slide(
                    "just_updated", "JUST UPDATED", "New: MyAI now\nreads photos",
                    "See what's new", listOf(Color(0xFFF4CB5A), Color(0xFFC68B1E)),
                    R.drawable.mascot_pro,
                    // No changelog-navigation callback threaded through yet —
                    // tapping is a safe no-op rather than a broken link.
                    // Thread onOpenChangelog through Hero/HomeScreen when
                    // that's wanted.
                    {},
                ),
            )
        }
        if (hitPremiumWall || previewAll) {
            add(
                Slide(
                    "premium_wall", "THIS NEEDS PRO PLUS", "Crown mode is a\nPro Plus feature",
                    "Unlock it", listOf(Color(0xFF6FC7F5), Color(0xFF2E86D6)),
                    R.drawable.mascot_pro_plus, onSeePlans,
                ),
            )
        }
    }
    if (slides.isEmpty()) return

    var index by remember { mutableStateOf(0) }
    LaunchedEffect(slides.size) {
        if (slides.size < 2) return@LaunchedEffect
        while (true) {
            delay(3500)
            index = (index + 1) % slides.size
        }
    }
    val slide = slides[index.coerceIn(slides.indices)]

    Column {
        Box(
            Modifier
                .fillMaxWidth()
                .height(188.dp)
                .clip(RoundedCornerShape(20.dp))
                .border(3.dp, Ink, RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(slide.gradient))
                .clickableNoRipple(remember { MutableInteractionSource() }, onClick = slide.onClick)
                .drawBehind {
                    val stripe = 26.dp.toPx()
                    var x = -size.height
                    while (x < size.width) {
                        drawLine(
                            Color.White.copy(alpha = 0.10f),
                            Offset(x, size.height), Offset(x + size.height, 0f),
                            strokeWidth = stripe * 0.4f,
                        )
                        x += stripe
                    }
                }
                .padding(18.dp),
        ) {
            Column(Modifier.fillMaxHeight(), verticalArrangement = Arrangement.Center) {
                Text(
                    slide.kicker,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.2.sp,
                    color = Color.White.copy(alpha = 0.85f),
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    slide.headline,
                    style = MaterialTheme.typography.headlineSmall.copy(fontFamily = FontFamily.Cursive),
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.widthIn(max = 165.dp),
                )
                Spacer(Modifier.height(12.dp))
                val glowT by com.momentum.focus.ui.components.ambient(
                    0f, 1f,
                    infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Reverse),
                    label = "cta-glow-t",
                )
                val ctaSweep by com.momentum.focus.ui.components.ambient(
                    0f, 1f,
                    infiniteRepeatable(tween(2400, easing = LinearEasing)),
                    label = "cta-sweep-t",
                )
                val ctaInteraction = remember { MutableInteractionSource() }
                val ctaPressed by ctaInteraction.collectIsPressedAsState()
                val ctaPressOffset by androidx.compose.animation.core.animateFloatAsState(
                    if (ctaPressed) 1f else 0f, Motion.press(), label = "cta-press",
                )
                Box(
                    Modifier
                        .drawBehind {
                            val d = 3.dp.toPx() * (1f - ctaPressOffset)
                            drawRoundRect(
                                color = Ink,
                                topLeft = Offset(d, d),
                                size = size,
                                cornerRadius = CornerRadius(999.dp.toPx()),
                            )
                            // A manually-drawn soft glow behind the pill,
                            // not shadowElevation — colored elevation-
                            // shadows render inconsistently across devices
                            // and were the actual reason this read as "no
                            // glow at all." A drawn radial gradient always
                            // shows, the same technique already reliable
                            // everywhere else in this app (Pro/Pro Plus
                            // beams, the Wallet gem's rings).
                            val glowR = size.minDimension * (0.75f + 0.35f * glowT)
                            drawCircle(
                                brush = Brush.radialGradient(
                                    listOf(
                                        Color(0xFFF4CB5A).copy(alpha = 0.24f + 0.22f * glowT),
                                        Color(0xFFF4CB5A).copy(alpha = 0f),
                                    ),
                                    center = center,
                                    radius = glowR,
                                ),
                                radius = glowR,
                                center = center,
                            )
                        }
                        .offset { IntOffset((3.dp.toPx() * ctaPressOffset).toInt(), (3.dp.toPx() * ctaPressOffset).toInt()) }
                        .clip(RoundedCornerShape(999.dp))
                        .background(Color.White)
                        // Paint blobs (Uiverse Javierrocadev): a Lilac and a
                        // Candy blob park in the corner and smear across the
                        // pill on press — aura, not ripple.
                        .drawBehind {
                            if (!com.momentum.focus.ui.theme.Vibe.playful) return@drawBehind
                            val k = ctaPressOffset
                            val r1 = size.height * (0.55f + 0.35f * k)
                            drawCircle(
                                Brush.radialGradient(listOf(Lilac.fill, Lilac.fill.copy(alpha = 0f)), Offset(size.width - r1 * 0.4f - size.width * 0.55f * k, size.height * 0.2f), r1),
                                r1, Offset(size.width - r1 * 0.4f - size.width * 0.55f * k, size.height * 0.2f),
                            )
                            val r2 = size.height * (0.45f + 0.4f * k)
                            drawCircle(
                                Brush.radialGradient(listOf(Candy.fill, Candy.fill.copy(alpha = 0f)), Offset(size.width - r2 * 1.2f - size.width * 0.3f * k, size.height * 0.95f), r2),
                                r2, Offset(size.width - r2 * 1.2f - size.width * 0.3f * k, size.height * 0.95f),
                            )
                        }
                        .border(2.5.dp, Ink, RoundedCornerShape(999.dp))
                        // Reference `.cta .sweep`: a gold band, 40% of the pill
                        // wide, crossing from -60% to 130% every 2.4s after a
                        // 40% rest. Inside the border, so the ink outline stays
                        // on top; clipped to the pill by the clip above.
                        .drawWithContent {
                            drawContent()
                            val p = ((ctaSweep - 0.4f) / 0.6f).coerceIn(0f, 1f)
                            if (p > 0f && p < 1f) {
                                val e = androidx.compose.animation.core.FastOutSlowInEasing.transform(p)
                                val bandW = size.width * 0.4f
                                val x = size.width * (-0.6f + 1.9f * e)
                                drawRect(
                                    brush = Brush.linearGradient(
                                        0.2f to Color.Transparent,
                                        0.5f to Color(0xFFF4CB5A).copy(alpha = 0.7f),
                                        0.8f to Color.Transparent,
                                        start = Offset(x, 0f),
                                        end = Offset(x + bandW, size.height),
                                    ),
                                    topLeft = Offset(x, 0f),
                                    size = Size(bandW, size.height),
                                )
                            }
                        }
                        .clickableNoRipple(ctaInteraction, onClick = slide.onClick)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                ) {
                    Text(
                        slide.cta,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Black,
                        color = Ink,
                    )
                }
            }
            Image(
                painter = painterResource(slide.mascotRes),
                contentDescription = null,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(96.dp),
            )
        }
        if (slides.size > 1) {
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
            ) {
                slides.forEachIndexed { i, _ ->
                    Box(
                        Modifier
                            .padding(horizontal = 3.dp)
                            .size(if (i == index) 16.dp else 6.dp, 6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (i == index) Ink else Ink.copy(alpha = 0.25f)),
                    )
                }
            }
        }
    }
}

/**
 * The floating Shield-status badge — corrected after the person pointed out
 * the first version was too big and permanently full-width, which collided
 * with the InsightDeck cards scrolling underneath it. Uber's own "Finding…"
 * pill is compact and anchored, not a full-width bar — so this is a small
 * circular badge in the corner that only grows, briefly, in reaction to a
 * tap, then fires the same click it always did.
 */
@Composable
fun FloatingShieldPill(
    count: Int,
    modifier: Modifier = Modifier,
    /** Shield is actually blocking right now. Off = quiet cream pill, no halo. */
    active: Boolean = true,
    /** Being dragged: lifts a little and the shadow drops further. */
    lifted: Boolean = false,
    onClick: () -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    // Press sinks in, drag lifts out. 160ms, no bounce — a control, not a toy.
    val scale by animateFloatAsState(
        when { pressed -> 0.94f; lifted -> 1.08f; else -> 1f },
        tween(160),
        label = "pill-scale",
    )
    val shadow by animateFloatAsState(if (lifted) 7f else if (pressed) 1.5f else 4f, tween(160), label = "pill-shadow")
    // Slow breathing halo only while the shield is really on.
    val halo by com.momentum.focus.ui.components.ambient(
        initialValue = 0.10f,
        targetValue = 0.38f,
        animationSpec = infiniteRepeatable(tween(2400), RepeatMode.Reverse),
        label = "pill-halo",
    )
    val fillTop = if (active) Mint.fill else CreamCard
    val fillBottom = if (active) Mint.accent else CreamCard
    Row(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .drawBehind {
                if (active) {
                    val grow = 6.dp.toPx()
                    drawRoundRect(
                        color = Mint.accent.copy(alpha = halo),
                        topLeft = Offset(-grow, -grow),
                        size = androidx.compose.ui.geometry.Size(size.width + grow * 2, size.height + grow * 2),
                        cornerRadius = CornerRadius(999.dp.toPx()),
                    )
                }
                val d = shadow.dp.toPx()
                drawRoundRect(
                    color = Ink,
                    topLeft = Offset(d, d),
                    size = size,
                    cornerRadius = CornerRadius(999.dp.toPx()),
                )
            }
            .clip(RoundedCornerShape(999.dp))
            .background(Brush.linearGradient(listOf(fillTop, fillBottom)))
            .drawBehind {
                // Glass sheen across the top half.
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.35f), Color.Transparent),
                        endY = size.height * 0.55f,
                    ),
                )
            }
            .border(2.5.dp, Ink, RoundedCornerShape(999.dp))
            .clickableNoRipple(interaction, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            Icons.Filled.Shield,
            contentDescription = tr("Blocked apps", "ब्लॉक किए गए ऐप"),
            tint = Ink,
            modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier
                .clip(CircleShape)
                .background(Ink)
                .defaultMinSize(minWidth = 22.dp, minHeight = 22.dp),
            contentAlignment = Alignment.Center,
        ) {
            // The count rolls rather than snapping when an app is added or removed.
            androidx.compose.animation.AnimatedContent(
                targetState = count,
                transitionSpec = {
                    val up = targetState > initialState
                    (androidx.compose.animation.slideInVertically(tween(220)) { if (up) it else -it } +
                        androidx.compose.animation.fadeIn(tween(220))) togetherWith
                        (androidx.compose.animation.slideOutVertically(tween(160)) { if (up) -it else it } +
                            androidx.compose.animation.fadeOut(tween(160)))
                },
                label = "pill-count",
            ) { n ->
                Text(
                    "$n",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFFF4CB5A),
                )
            }
        }
    }
}

/**
 * The mark at the end of the scroll.
 *
 * Deliberately low contrast and oversized: it is a full stop, not a headline.
 * Reaching it should feel like arriving at the bottom of something made, which
 * is why it carries the version too.
 */
@Composable
private fun Wordmark(skin: Skin, str: Strings) {
    Column(Modifier.fillMaxWidth()) {
        Text(
            str.home.wordmarkTagline,
            style = MaterialTheme.typography.displayMedium.copy(
                fontFamily = FontFamily.Serif,
                letterSpacing = (-1.5).sp,
            ),
            color = InkLow.copy(alpha = 0.55f),
        )
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(InkLow.copy(alpha = 0.4f))
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "momentum",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontFamily = FontFamily.Serif,
            ),
            color = InkLow.copy(alpha = 0.5f),
        )
        Text(
            str.home.skinTheme(skin.label),
            style = MaterialTheme.typography.bodyMedium,
            color = InkLow.copy(alpha = 0.45f),
        )
    }
}

// ---------------------------------------------------------------- hero

@Composable
private fun Hero(
    data: AppData,
    str: Strings,
    skin: Skin,
    festSkin: Skin?,
    phoneToday: Int,
    onProfile: () -> Unit,
    onBell: () -> Unit,
    onStartFocus: () -> Unit,
    onShield: () -> Unit,
    onFeeds: () -> Unit,
    unseenNotices: Int,
    weather: WeatherSnapshot? = null,
    hitPremiumWall: Boolean = false,
    onPlans: () -> Unit = {},
    justUpdatedAt: Long? = null,
    currentVersion: String = "",
    scrollPx: () -> Int = { 0 },
    onDismissFreeze: () -> Unit = {},
) {
    val haptics = rememberHaptics()
    val low = DeviceProfile.isLowEnd(androidx.compose.ui.platform.LocalContext.current)
    val counted by animateFloatAsState(
        targetValue = data.balanceMinutes.toFloat(),
        animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "balance",
    )
    val minutes = counted.roundToInt()
    var heroH by remember { androidx.compose.runtime.mutableIntStateOf(0) }
    val heroOnScreen by remember {
        androidx.compose.runtime.derivedStateOf { heroH == 0 || scrollPx() < heroH }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .onSizeChanged { heroH = it.height }
            .clip(RoundedCornerShape(bottomStart = 26.dp, bottomEnd = 26.dp))
            .background(
                Brush.verticalGradient(listOf(skin.heroTop, skin.heroBottom))
            )
            // (ink edge removed on owner request — the graded theme light
            // reads better meeting the paper directly)
            ,
    ) {
        // Parallax: the theme world moves at 40% of the scroll, so the
        // content slides over it and the hero has depth.
        Box(Modifier.matchParentSize().graphicsLayer { translationY = scrollPx() * 0.4f }) {
        if (skin.isReal()) com.momentum.focus.ui.components.HeroGrade(skin, Modifier.matchParentSize())
        else HeroAtmosphere(skin, Modifier.matchParentSize())
        // Petals live behind the content, clipped to the hero, so the movement
        // is always there without ever competing with the number.
        // Notes drift behind the balance, petals in front of them. Two layers
        // at different opacities give the hero depth without either of them
        // competing with the number.
        if (!low) {
            // The alpha bump exists to let dedicated festival art read through
            // the hero. Rakhi has no art of its own, so bumping it only made
            // money_rain look washed out over the dark band — a skin with no
            // art gets the ordinary treatment.
            val festArt = when (festSkin) {
                Skin.DIWALI -> R.drawable.fest_diwali
                else -> null
            }
            // Rakhi has no artwork file — it is drawn, so there is nothing to
            // source, nothing to watermark and no baked-in English to collide
            // with the balance.
            if (festSkin == Skin.RAKHI) {
                Canvas(Modifier.matchParentSize()) {
                    rakhiMotif(
                        cx = size.width * 0.80f,
                        cy = size.height * 0.30f,
                        radius = size.minDimension * 0.10f,
                        thread = skin.petal.copy(alpha = 0.55f),
                        petal = skin.petal.copy(alpha = 0.40f),
                        centre = skin.heroTop.copy(alpha = 0.85f),
                        outline = skin.petal.copy(alpha = 0.30f),
                    )
                }
            }
            // Janmashtami is drawn too, for the same reason as Rakhi. The
            // feather hangs below its eye, so it is anchored higher than the
            // rakhi to keep the plume off the balance.
            if (festSkin == Skin.JANMASHTAMI) {
                Canvas(Modifier.matchParentSize()) {
                    morPankhMotif(
                        cx = size.width * 0.80f,
                        cy = size.height * 0.30f,
                        radius = size.minDimension * 0.085f,
                        plume = skin.petal.copy(alpha = 0.42f),
                        eyeOuter = skin.petal.copy(alpha = 0.60f),
                        eyeInner = skin.accent.copy(alpha = 0.70f),
                        core = skin.heroTop.copy(alpha = 0.90f),
                    )
                }
            }
            // The generic money-rain PNG is retired: it looked pasted on and
            // fought every theme. Festival art stays — it IS the theme.
            if (festArt != null) {
                Image(
                    painter = painterResource(festArt),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    alpha = 0.42f,
                    modifier = Modifier.matchParentSize(),
                )
            }
            // Weather that matches the skin, replacing the petal fall that ran
            // under every one of them. Monsoon dropped cherry blossom; Ember
            // dropped cherry blossom; Midnight dropped cherry blossom. Each of
            // those names promises something and the app delivered the same
            // pink drift five times, which is worse than no effect at all —
            // the second time you see it the name stops meaning anything.
            // Minimal (free) look: no idle weather at all.
            if (com.momentum.focus.ui.theme.Vibe.playful) {
                if (skin.isReal()) com.momentum.focus.ui.components.RealSkinWeather(skin, Modifier.matchParentSize(), running = heroOnScreen)
                else SkinWeather(skin, Modifier.matchParentSize())
            }
        }
        }

        Column(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = Paper.ScreenPad)
                // v5: taller hero — more air above, between and below
                .padding(top = 22.dp, bottom = 30.dp),
        ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(data) { haptics.tap(); onProfile() }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                TypedGreeting(
                    name = data.userName,
                    nameColor = CreamCard,
                    labelColor = InkLow,
                    alreadyPlayed = HomeSession.greetingPlayed,
                )
                SideEffect { HomeSession.greetingPlayed = true }
                // The plain "X day streak" line upgraded to the comic
                // sticker-badge treatment from the reference — same fact,
                // shown once, just with the weight a streak actually
                // deserves instead of small grey InkLow text easy to miss.
                Box(
                    Modifier
                        .graphicsLayer { rotationZ = -3f }
                        .clip(RoundedCornerShape(9.dp))
                        .background(Tang.fill)
                        .border(2.5.dp, Ink, RoundedCornerShape(9.dp))
                        .padding(horizontal = 9.dp, vertical = 4.dp),
                ) {
                    // Streak 2.0: until someone has held a 7-day run once,
                    // the badge IS the onboarding goal ("Day 3 of 7").
                    val firstWeek = data.bestStreak < 7 && data.streakDays < 7
                    Text(
                        when {
                            !firstWeek -> str.home.dayStreak(data.streakDays)
                            data.streakDays == 0 -> str.streak.firstWeekStart
                            else -> str.streak.firstWeekDay(data.streakDays)
                        },
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Black,
                        color = Tang.on,
                    )
                }
                FreezeSavedNotice(data.freezeSavedStreak, onDismissFreeze)
                // The one-time weather sync: fades and scales in once when a
                // fresh reading lands, then just sits there as a small badge
                // — it does not keep animating, and it never touches
                // skin.heroTop/heroBottom. The actual theme colour is still
                // entirely whatever the person picked; this is a fact about
                // today layered on top of it, the same relationship the
                // festival art already has with the skin underneath it.
                weather?.let { w ->
                    var shown by remember(w) { mutableStateOf(false) }
                    LaunchedEffect(w) { shown = true }
                    val badgeAlpha by animateFloatAsState(
                        if (shown) 1f else 0f, tween(500), label = "weather-fade",
                    )
                    val badgeScale by animateFloatAsState(
                        if (shown) 1f else 0.6f,
                        spring(dampingRatio = 0.6f, stiffness = 300f),
                        label = "weather-scale",
                    )
                    Row(
                        Modifier
                            .padding(top = 2.dp)
                            .graphicsLayer {
                                alpha = badgeAlpha
                                scaleX = badgeScale
                                scaleY = badgeScale
                                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
                            }
                            .billboardSyncSweep(w),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            when (w.condition) {
                                WeatherCondition.RAIN -> Icons.Filled.Umbrella
                                WeatherCondition.SNOW -> Icons.Filled.AcUnit
                                WeatherCondition.SUN -> Icons.Filled.WbSunny
                                WeatherCondition.CLOUD -> Icons.Filled.Cloud
                            },
                            contentDescription = null,
                            tint = if (w.condition == WeatherCondition.SUN) Color(0xFFFFD84D) else InkLow,
                            modifier = (if (w.condition == WeatherCondition.SUN) {
                                // The reference's sun-glow pulse, kept to
                                // just this one condition and just the
                                // emoji itself — the badge stays a small
                                // fact-of-the-day mark either way, this
                                // only adds the one touch that's specific
                                // to it actually being sunny.
                                val glowT by com.momentum.focus.ui.components.ambient(
                                    0.5f, 1f,
                                    infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse),
                                    label = "glow",
                                )
                                Modifier.drawBehind {
                                    drawCircle(
                                        Color(0xFFFFD84D).copy(alpha = 0.35f * glowT),
                                        radius = size.maxDimension * 1.1f * glowT,
                                    )
                                }
                            } else Modifier).size(14.dp),
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            "${w.tempC}\u00b0",
                            style = MaterialTheme.typography.labelSmall,
                            color = InkLow,
                        )
                    }
                }
            }

            // Shield chip — where the floating pill used to hover over every
            // tab. Tap = the blocked-apps sheet, same as the pill did.
            if (data.blockedPackages.isNotEmpty()) {
                com.momentum.focus.ui.components.ShieldChip(
                    count = data.blockedPackages.size,
                    active = data.shieldOn,
                    onClick = { haptics.tap(); onShield() },
                )
                Spacer(Modifier.width(8.dp))
            }
            // The bell, in the hero's corner where every app puts it. It shows
            // the state rather than opening anything: struck through when
            // nudges are off, so the one question it answers — "is this thing
            // going to talk to me" — is answered without a tap. Tapping goes
            // to the switch that changes it.
            Box {
                Box(
                    Modifier
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.10f))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tap(); onBell()
                        }
                        .padding(9.dp),
                ) {
                    Icon(
                        if (data.notifyOn) Icons.Filled.Notifications
                        else Icons.Filled.NotificationsOff,
                        contentDescription = null,
                        tint = if (data.notifyOn) CreamCard else InkLow,
                        modifier = Modifier.size(20.dp),
                    )
                }
                // The count of unread notices, on the bell.
                //
                // The seen-set has been tracked since the feed was built and
                // nothing ever counted it, so a notice could land and sit on
                // Home with no sign it was new. Without the number the bell is
                // decoration and the news only reaches whoever happens to
                // scroll past it.
                if (unseenNotices > 0) {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = 3.dp, y = (-3).dp)
                            .clip(CircleShape)
                            .background(Tang.fill)
                            .border(2.dp, Ink, CircleShape)
                            .padding(horizontal = 5.dp, vertical = 1.dp),
                    ) {
                        Text(
                            // Past nine the exact figure is not the message.
                            if (unseenNotices > 9) "9+" else "$unseenNotices",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Tang.on,
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        // ---- dashboard v3: one number, three tiles, one button. What used to
        // sit here (banked-from-focus line, phone line, first-rupee hint,
        // earned bar, exam bar) was the same facts told twice.
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.AccountBalanceWallet, contentDescription = null, tint = skin.accent, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                tr("WALLET", "वॉलेट"),
                style = MaterialTheme.typography.labelSmall,
                letterSpacing = 1.6.sp,
                fontWeight = FontWeight.Black,
                color = InkLow,
            )
            Spacer(Modifier.weight(1f))
            data.daysToExam?.takeIf { it >= 0 }?.let { days ->
                HeroChip(
                    tr("${data.examName.ifBlank { str.home.boardsFallback }} · ${days}d",
                        "${data.examName.ifBlank { str.home.boardsFallback }} · $days दिन"),
                    fill = if (data.examIsClose) Tang.fill else Butter.fill,
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Odometer(Currency.format(data.balanceMinutes))
                if (data.minutesToday > 0) {
                    HeroChip(
                        "+${Currency.format(data.minutesToday)} " + tr("today", "आज"),
                        fill = Mint.fill,
                    )
                }
            }
            FocusReactor(focus = data.minutesToday, phone = phoneToday, accent = skin.accent)
        }

        Spacer(Modifier.height(18.dp))
        val today = remember { java.time.LocalDate.now().toEpochDay() }
        val sessionsToday = data.sessions.count { it.completed && it.startedAtEpochDay == today }
        // Spotlight (Uiverse hover cards): hold a tile and it steps forward
        // while the other two dim back. Release and all three settle.
        var spot by remember { mutableIntStateOf(-1) }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile(tr("FOCUS", "फ़ोकस"), hm(data.minutesToday), skin.accent, 0, Modifier.weight(1f), progress = data.minutesToday / 180f, spot = spot, onSpot = { spot = it })
            StatTile(
                tr("PHONE", "फ़ोन"), hm(phoneToday),
                if (phoneToday > data.minutesToday && phoneToday > 0) Color(0xFFFF6A2E) else Color(0xFFF7F2E8),
                1, Modifier.weight(1f), spot = spot, onSpot = { spot = it },
            )
            StatTile(tr("SESSIONS", "सेशन"), "$sessionsToday", Color(0xFFFFC531), 2, Modifier.weight(1f), spot = spot, onSpot = { spot = it })
        }

        Spacer(Modifier.height(22.dp))

        HeroStatus(data, phoneToday)
        Spacer(Modifier.height(10.dp))
        val pulse by com.momentum.focus.ui.components.ambient(
            0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "ctaPulseT",
        )
        Box(
            Modifier.drawBehind {
                // A ring of light that leaves the button every 2.2s.
                val g = pulse * 14.dp.toPx()
                drawRoundRect(
                    skin.accent.copy(alpha = 0.5f * (1f - pulse)),
                    topLeft = Offset(-g, -g),
                    size = Size(size.width + g * 2, size.height + g * 2),
                    cornerRadius = CornerRadius(16.dp.toPx() + g),
                    style = Stroke(3.dp.toPx() * (1f - pulse) + 0.5f),
                )
            },
        ) {
            HeroButton(str.home.startFocus, skin.accent, skin.onAccent, Modifier.fillMaxWidth()) {
                onStartFocus()
            }
        }
        }
    }
}

/** Balance as an odometer: each digit rolls into place, gold with a light sweep. */
@Composable
private fun Odometer(text: String) {
    // The repeating light sweep was removed (owner: "irritating"). Digits
    // still roll into place when the balance changes.
    val gold = Brush.linearGradient(listOf(Color(0xFFFFE9A8), GoldNeon, Color(0xFFC68B1E)))
    Row(
    ) {
        text.forEachIndexed { i, ch ->
            androidx.compose.animation.AnimatedContent(
                targetState = ch,
                transitionSpec = {
                    (androidx.compose.animation.slideInVertically(tween(260, delayMillis = i * 40)) { it } + androidx.compose.animation.fadeIn(tween(200, delayMillis = i * 40))) togetherWith
                        (androidx.compose.animation.slideOutVertically(tween(200, delayMillis = i * 40)) { -it } + androidx.compose.animation.fadeOut(tween(160)))
                },
                label = "odo$i",
            ) { c ->
                Text(c.toString(), style = MaterialTheme.typography.displayLarge.copy(brush = gold))
            }
        }
    }
}

/**
 * Focus vs phone, today, as one ring: mint is study, orange is phone. The
 * number in the middle is focus's share of the two — the stat this app exists
 * to move. Sweeps in on open.
 */
@Composable
private fun FocusReactor(focus: Int, phone: Int, accent: Color) {
    val total = (focus + phone).coerceAtLeast(1)
    val share = focus.toFloat() / total
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val k by animateFloatAsState(if (shown) 1f else 0f, tween(1100, easing = FastOutSlowInEasing), label = "reactor")
    val spin by com.momentum.focus.ui.components.ambient(
        0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "reactorSpinT",
    )
    Box(Modifier.size(112.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val st = 9.dp.toPx()
            val tl = Offset(st, st)
            val sz = Size(size.width - st * 2, size.height - st * 2)
            // slow orbit ticks around the ring
            for (i in 0 until 24) {
                val a = (i * 15f + spin) * (Math.PI.toFloat() / 180f)
                val r1 = size.minDimension / 2 - 1.dp.toPx()
                drawCircle(Color.White.copy(alpha = if (i % 6 == 0) 0.35f else 0.12f), 1.dp.toPx(), center + Offset(kotlin.math.cos(a) * r1, kotlin.math.sin(a) * r1))
            }
            drawArc(Color.White.copy(alpha = 0.10f), 0f, 360f, false, tl, sz, style = Stroke(st))
            val fSweep = 360f * share * k
            val pSweep = 360f * (1f - share) * k
            drawArc(Color.White.copy(alpha = 0.28f), -90f + fSweep, pSweep, false, tl, sz, style = Stroke(st))
            for (g in 1..3) drawArc(accent.copy(alpha = 0.16f * (1f - g / 4f)), -90f, fSweep, false, tl, sz, style = Stroke(st + g * 5.dp.toPx(), cap = StrokeCap.Round))
            drawArc(accent, -90f, fSweep.coerceAtLeast(if (focus > 0) 6f else 0f), false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${(share * 100 * k).roundToInt()}%", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = CreamCard)
            Text(tr("FOCUS", "फ़ोकस"), style = MaterialTheme.typography.labelSmall, letterSpacing = 1.2.sp, color = InkLow)
        }
    }
}

/** One short, reactive line about today — the hero talks back. */
@Composable
private fun HeroStatus(data: AppData, phone: Int) {
    val focus = data.minutesToday
    val line = when {
        focus == 0 && phone > 60 -> tr("Phone's winning today. Flip it.", "आज फ़ोन जीत रहा है। पलट दो।")
        focus == 0 -> tr("Clean slate. First minute counts.", "नई शुरुआत। पहला मिनट गिनता है।")
        focus >= phone -> tr("You're beating the feed. Keep stacking.", "आप फ़ीड से आगे हो। जोड़ते रहो।")
        else -> tr("Locked in ${focus}m. Phone's at ${phone}m — close the gap.", "${focus}मि लॉक इन। फ़ोन ${phone}मि पर — फ़ासला घटाओ।")
    }
    androidx.compose.animation.AnimatedContent(
        targetState = line,
        transitionSpec = { androidx.compose.animation.fadeIn(tween(220)) togetherWith androidx.compose.animation.fadeOut(tween(150)) },
        label = "heroStatus",
    ) { l ->
        Text(l, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = CreamCard.copy(alpha = 0.85f))
    }
}

private fun hm(min: Int): String = if (min >= 60) "${min / 60}h ${min % 60}m" else "${min}m"

/** Small tilted sticker on the hero: exam countdown, today's gain. */
@Composable
private fun HeroChip(text: String, fill: Color, modifier: Modifier = Modifier) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val t by animateFloatAsState(if (shown) 1f else 0f, tween(240), label = "heroChip")
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Black,
        color = Ink,
        modifier = modifier
            .graphicsLayer { alpha = t; scaleX = 0.8f + 0.2f * t; scaleY = 0.8f + 0.2f * t; rotationZ = -2f }
            .clip(RoundedCornerShape(8.dp))
            .background(fill)
            .border(2.dp, Ink, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    )
}

/**
 * Glass stat tile on the theme art (v4): frosted pane, bright top edge,
 * warm-white text that reads on every theme, a coloured dot for identity,
 * staggered rise, value rolls when it changes.
 */
@Composable
private fun StatTile(
    label: String, value: String, fill: Color, index: Int, modifier: Modifier = Modifier,
    progress: Float? = null, spot: Int = -1, onSpot: (Int) -> Unit = {},
) {
    val haptics = rememberHaptics()
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(120L + index * 70L); shown = true }
    val t by animateFloatAsState(if (shown) 1f else 0f, tween(240), label = "stat$index")
    val focus by animateFloatAsState(
        when (spot) { -1 -> 1f; index -> 1.08f; else -> 0.94f }, Motion.press(), label = "spot$index",
    )
    val dim by animateFloatAsState(if (spot != -1 && spot != index) 0.5f else 1f, tween(180), label = "dim$index")
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier
            .pointerInput(index) {
                detectTapGestures(
                    onLongPress = { haptics.tick(); onSpot(index) },
                    onPress = { tryAwaitRelease(); onSpot(-1) },
                )
            }
            .graphicsLayer {
                alpha = t * dim
                translationY = (1f - t) * 14.dp.toPx()
                scaleX = focus; scaleY = focus
            }
            .drawBehind {
                // soft drop + faint colour bloom from the tile's own hue
                drawRoundRect(Color.Black.copy(alpha = 0.35f), topLeft = Offset(0f, 4.dp.toPx()), size = size, cornerRadius = CornerRadius(14.dp.toPx()))
                drawRoundRect(fill.copy(alpha = 0.10f), topLeft = Offset(-4.dp.toPx(), -4.dp.toPx()), size = Size(size.width + 8.dp.toPx(), size.height + 8.dp.toPx()), cornerRadius = CornerRadius(18.dp.toPx()))
            }
            .clip(shape)
            .background(Color.White.copy(alpha = 0.08f))
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.Transparent)))
            .border(1.2.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.40f), Color.White.copy(alpha = 0.06f))), shape)
            .padding(horizontal = 12.dp, vertical = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(fill))
            Spacer(Modifier.width(5.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, letterSpacing = 1.2.sp, fontWeight = FontWeight.Black, color = Color(0xFFF7F2E8).copy(alpha = 0.66f))
        }
        androidx.compose.animation.AnimatedContent(
            targetState = value,
            transitionSpec = {
                (androidx.compose.animation.slideInVertically(tween(220)) { it } + androidx.compose.animation.fadeIn(tween(220))) togetherWith
                    (androidx.compose.animation.slideOutVertically(tween(160)) { -it } + androidx.compose.animation.fadeOut(tween(160)))
            },
            label = "statVal$index",
        ) { v ->
            Text(v, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = Color(0xFFF7F2E8), maxLines = 1)
        }
        if (progress != null) {
            val g by animateFloatAsState(if (shown) progress.coerceIn(0f, 1f) else 0f, tween(600, easing = FastOutSlowInEasing), label = "goal")
            Spacer(Modifier.height(5.dp))
            GlowProgressBar(progress = g, height = 6.dp, dark = true)
        }
    }
}

@Composable
private fun HeroButton(
    label: String,
    fill: androidx.compose.ui.graphics.Color,
    on: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    // The orb button's own press feel — a scale-down plus a brighter inner
    // glow on press, rather than a flat rectangle with no feedback beyond
    // the ripple this app already turns off everywhere.
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "hero-btn-scale")
    val glow by animateFloatAsState(if (pressed) 0.35f else 0.16f, tween(150), label = "hero-btn-glow")

    // The shine-sweep from the reference — a diagonal streak that crosses
    // the button once on press, layered on top of the orb glow above
    // rather than replacing it; the glow is the resting/press brightness,
    // this is the one-off motion a press actually earns.
    var sweepT by remember { mutableFloatStateOf(1f) }
    LaunchedEffect(pressed) {
        if (pressed) {
            sweepT = 0f
            val start = withFrameNanos { it }
            while (sweepT < 1f) {
                withFrameNanos { now -> sweepT = ((now - start) / 1_000_000f / 380f).coerceIn(0f, 1f) }
            }
        }
    }

    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(13.dp))
            .background(fill)
            .drawBehind {
                drawRect(
                    brush = Brush.radialGradient(
                        listOf(Color.White.copy(alpha = glow), Color.Transparent),
                        center = Offset(size.width * 0.3f, -size.height * 0.2f),
                        radius = size.width * 0.9f,
                    ),
                )
                if (sweepT < 1f) {
                    val headX = -size.width * 0.3f + sweepT * size.width * 1.6f
                    drawRect(
                        brush = Brush.linearGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.30f * (1f - sweepT)), Color.Transparent),
                            start = Offset(headX - size.width * 0.18f, 0f),
                            end = Offset(headX + size.width * 0.18f, size.height),
                        ),
                    )
                }
            }
            .clickableNoRipple(interaction) {
                haptics.confirm(); onClick()
            }
            .padding(vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium, color = on)
    }
}

@Composable
private fun Avatar(data: AppData, onClick: () -> Unit) {
    Box(
        Modifier
            .size(if (data.premium) 60.dp else 52.dp)
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        // A gold ring for people who paid, and a crown sitting on it.
        //
        // Premium shows up on the Plans page and nowhere else in the app, so
        // after the purchase there is nothing to see — you paid and your own
        // screen looks identical. This is the one mark that is theirs and is
        // visible every single time they open it.
        if (data.premium) {
            Canvas(Modifier.size(60.dp)) {
                val r = size.minDimension / 2f - 2f
                drawCircle(
                    brush = Brush.sweepGradient(
                        listOf(GoldNeon, Butter.fill, Color.White, GoldNeon, Butter.fill, GoldNeon),
                    ),
                    radius = r,
                    style = Stroke(width = 4.dp.toPx()),
                )
                drawCircle(color = Ink, radius = r + 2.dp.toPx(), style = Stroke(1.5.dp.toPx()))
            }
        }
        Avatar3D(
            colorIndex = data.avatarColor,
            shapeIndex = data.avatarShape,
            size = 52.dp,
        )
        if (data.premium) {
            // On the rim at the top, tipped slightly, the way a crown sits
            // rather than the way a badge is pinned.
            CrownMark(
                size = 22.dp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (-8).dp)
                    .rotate(-12f),
            )
        }
    }
}

// ---------------------------------------------------------------- body

@Composable
private fun ActionCard(
    art: TileArt,
    title: String,
    detail: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            // A cast shadow under the card, offset down and right. This is the
            // whole difference between a rectangle drawn on paper and an
            // object resting on it — the reference app builds its entire look
            // out of things that sit above the grid rather than being printed
            // into it.
            .drawBehind {
                val d = 5.dp.toPx() * com.momentum.focus.ui.theme.Vibe.shadow
                drawRoundRect(
                    color = Ink.copy(alpha = 0.20f),
                    topLeft = Offset(d, d),
                    size = size,
                    cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx()),
                )
            }
            .clip(shape)
            // Lighter at the top, so the surface has a direction.
            .background(
                Brush.verticalGradient(
                    listOf(Color.White, CreamCard, Sunk.copy(alpha = 0.55f)),
                ),
            )
            .border(2.dp, Ink, shape)
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                haptics.tap(); onClick()
            }
            .padding(14.dp),
    ) {
        // A drawn solid, not a glyph in a coloured square. A Material icon is
        // flat by construction — one colour, no light on it — and the whole
        // look this is chasing is small objects sitting on grid paper with a
        // lit side, a dark side and a shadow under them.
        TileObject(art = art, fill = sticker.fill, size = 42.dp)
        Spacer(Modifier.height(10.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
        Text(detail, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}

private data class FeedRow(
    val title: String,
    val subtitle: String,
    val amount: String,
    val sticker: Sticker,
    val icon: ImageVector,
)

private fun buildFeed(data: AppData, str: Strings): List<FeedRow> {
    val today = LocalDate.now().toEpochDay()

    fun ago(day: Long) = when (val d = (today - day).toInt()) {
        0 -> str.common.today
        1 -> str.common.yesterday
        else -> str.common.daysAgo(d)
    }

    val sessions = data.sessions.takeLast(6).reversed().map { session: FocusSession ->
        FeedRow(
            title = session.subject,
            subtitle = if (session.completed) ago(session.startedAtEpochDay)
                       else str.home.leftEarly(ago(session.startedAtEpochDay)),
            amount = "+${Currency.format(session.minutes)}",
            sticker = if (session.completed) Mint else Butter,
            icon = Icons.Filled.Timer,
        )
    }

    val urges = data.urges.takeLast(4).reversed().map { u ->
        FeedRow(
            title = if (u.survived) str.home.urgeBeaten else str.home.slipLogged,
            subtitle = str.home.urgeWhen(ago(u.epochDay), u.hour),
            amount = if (u.survived) str.home.held else str.home.reset,
            sticker = if (u.survived) Sky else Candy,
            icon = Icons.Filled.Shield,
        )
    }

    return (sessions + urges).take(8)
}

@Composable
private fun ActivityRow(row: FeedRow) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(row.sticker.fill)
                .border(2.dp, Ink, RoundedCornerShape(9.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                row.icon,
                contentDescription = null,
                tint = row.sticker.on,
                modifier = Modifier.size(18.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(row.title, style = MaterialTheme.typography.titleMedium, color = Ink)
            Text(row.subtitle, style = MaterialTheme.typography.bodyMedium, color = InkMid)
        }
        Text(row.amount, style = MaterialTheme.typography.titleMedium, color = row.sticker.accent)
    }
}

@Composable
private fun EmptyFeed(str: Strings) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        NoteStack3D(noteColor = Mint.fill, coinColor = Butter.fill, size = 118.dp)
        Spacer(Modifier.height(10.dp))
        Text(str.home.nothingBankedYet, style = MaterialTheme.typography.titleMedium, color = Ink)
        Spacer(Modifier.height(4.dp))
        Text(
            str.home.emptyFeedBody,
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
            textAlign = TextAlign.Center,
        )
    }
}

/**
 * The bell.
 *
 * This used to be a switch and three lines describing, in the abstract, what
 * notifications are for — while the actual notices sat in a card halfway down
 * Home. So the badge on the bell counted things the bell did not contain, and
 * the one place in the app shaped like an inbox was the one place with no mail
 * in it. The notices are the content now; the switch is a row at the bottom.
 */
@Composable
private fun NotifySheet(
    on: Boolean,
    fresh: List<ExamNewsItem>,
    earlier: List<ExamNewsItem>,
    onToggle: (Boolean) -> Unit,
    onClose: () -> Unit,
) {
    // v5 inbox: a full-width panel that slides up from the bottom over a dim
    // scrim — handle, title with a live "new" count, All/New filter on a
    // sliding pill, timeline rows that rise in one after another, a real
    // switch for nudges. Back or tapping the scrim closes it.
    val haptics = rememberHaptics()
    val context = LocalContext.current
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val k by animateFloatAsState(if (shown) 1f else 0f, tween(320, easing = FastOutSlowInEasing), label = "inbox")
    var filterNew by remember { mutableStateOf(fresh.isNotEmpty()) }
    val list = if (filterNew) fresh else fresh + earlier.take(20)
    Dialog(
        onDismissRequest = onClose,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.35f * k))
                .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
            contentAlignment = Alignment.BottomCenter,
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.82f)
                    .graphicsLayer { translationY = (1f - k) * size.height }
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(Color(0xFFFFFCF2))
                    .border(Paper.Outline, Ink, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) { }
                    .navigationBarsPadding()
                    .padding(horizontal = 18.dp),
            ) {
                Box(Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp).size(44.dp, 5.dp).clip(RoundedCornerShape(3.dp)).background(Ink.copy(alpha = 0.2f)))
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("INBOX", "इनबॉक्स"), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, letterSpacing = 1.8.sp, color = InkMid)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("Notices", "सूचनाएँ"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = Ink)
                            if (fresh.isNotEmpty()) {
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "${if (fresh.size > 9) "9+" else fresh.size} " + tr("new", "नई"),
                                    style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black, color = Ink,
                                    modifier = Modifier.graphicsLayer { rotationZ = -3f }
                                        .clip(RoundedCornerShape(8.dp)).background(Tang.fill)
                                        .border(2.dp, Ink, RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 2.dp),
                                )
                            }
                        }
                    }
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(Sunk).border(2.dp, Ink, CircleShape)
                            .clickableNoRipple(remember { MutableInteractionSource() }) { haptics.tick(); onClose() },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.Close, contentDescription = tr("Close", "बंद करें"), tint = Ink, modifier = Modifier.size(20.dp)) }
                }
                Spacer(Modifier.height(14.dp))
                // All / New on a sliding pill
                val pos by animateFloatAsState(if (filterNew) 1f else 0f, spring(dampingRatio = 0.75f, stiffness = 420f), label = "inboxPill")
                BoxWithConstraints(
                    Modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(999.dp)).background(Sunk)
                        .border(2.dp, Ink, RoundedCornerShape(999.dp)).padding(3.dp),
                ) {
                    val tw = maxWidth / 2
                    Box(Modifier.offset(x = tw * pos).width(tw).fillMaxHeight().clip(RoundedCornerShape(999.dp)).background(Butter.fill).border(2.dp, Ink, RoundedCornerShape(999.dp)))
                    Row(Modifier.fillMaxSize()) {
                        listOf(tr("All", "सभी") to false, tr("New", "नई") to true).forEach { (label, isNew) ->
                            Box(
                                Modifier.weight(1f).fillMaxHeight().clickableNoRipple(remember { MutableInteractionSource() }) {
                                    Sfx.play(Sound.TICK); filterNew = isNew
                                },
                                contentAlignment = Alignment.Center,
                            ) { Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black, color = Ink) }
                        }
                    }
                }
                // nudges switch — moved up from the bottom, where the system bar hid it
                Row(
                    Modifier.fillMaxWidth().padding(top = 10.dp)
                        .clip(RoundedCornerShape(16.dp)).background(if (on) Mint.fill.copy(alpha = 0.35f) else Sunk)
                        .border(2.dp, Ink, RoundedCornerShape(16.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) { onToggle(!on); haptics.tick(); Sfx.play(if (on) Sound.SHIELD_OFF else Sound.SHIELD_ON) }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("Nudges", "रिमाइंडर"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = Ink)
                        Text(tr("Exam notices · streak saves · weekly read", "परीक्षा सूचना · स्ट्रीक बचाव · हफ़्ते का सार"), style = MaterialTheme.typography.bodySmall, color = InkMid)
                    }
                    val knob by animateFloatAsState(if (on) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "knob")
                    Box(
                        Modifier.size(52.dp, 30.dp).clip(RoundedCornerShape(999.dp))
                            .background(androidx.compose.ui.graphics.lerp(InkLow, Mint.accent, knob))
                            .border(2.dp, Ink, RoundedCornerShape(999.dp)).padding(3.dp),
                    ) {
                        Box(Modifier.offset(x = 22.dp * knob).size(24.dp).clip(CircleShape).background(CreamCard).border(2.dp, Ink, CircleShape))
                    }
                }
                Spacer(Modifier.height(12.dp))

                Box(Modifier.weight(1f)) {
                    if (list.isEmpty()) {
                        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Canvas(Modifier.size(72.dp)) {
                                val w = size.width; val h = size.height
                                val bell = androidx.compose.ui.graphics.Path().apply {
                                    moveTo(w * 0.2f, h * 0.72f)
                                    cubicTo(w * 0.28f, h * 0.6f, w * 0.24f, h * 0.22f, w * 0.5f, h * 0.18f)
                                    cubicTo(w * 0.76f, h * 0.22f, w * 0.72f, h * 0.6f, w * 0.8f, h * 0.72f)
                                    close()
                                }
                                drawPath(bell, Butter.fill)
                                drawPath(bell, Ink, style = Stroke(3.dp.toPx()))
                                drawCircle(Ink, 5.dp.toPx(), Offset(w * 0.5f, h * 0.8f))
                                drawLine(Ink, Offset(w * 0.12f, h * 0.72f), Offset(w * 0.88f, h * 0.72f), 3.dp.toPx(), StrokeCap.Round)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(tr("All clear.", "सब साफ़।"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = Ink)
                            Text(tr("Nothing from the board yet.", "बोर्ड से अभी कुछ नहीं।"), style = MaterialTheme.typography.bodyMedium, color = InkMid)
                        }
                    } else {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                            list.forEachIndexed { i, item ->
                                NoticeRow(item, context, haptics, isNew = item in fresh, index = i)
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun NoticeRow(
    item: ExamNewsItem,
    context: android.content.Context,
    haptics: com.momentum.focus.ui.util.Haptics,
    isNew: Boolean,
    index: Int = 0,
) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(120L + index.coerceAtMost(8) * 55L); shown = true }
    val k by animateFloatAsState(if (shown) 1f else 0f, tween(260, easing = FastOutSlowInEasing), label = "notice$index")
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val p by animateFloatAsState(if (pressed) 1f else 0f, tween(110), label = "noticePress")
    Row(
        Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .padding(bottom = 10.dp, end = 4.dp)
            .graphicsLayer { alpha = k; translationY = (1f - k) * 16.dp.toPx() }
            .drawBehind {
                val d = 4.dp.toPx() * (1f - p)
                drawRoundRect(Ink, Offset(d + 4.dp.toPx() * p, d + 4.dp.toPx() * p), size, CornerRadius(14.dp.toPx()))
            }
            .graphicsLayer { translationX = 4.dp.toPx() * p; translationY = 4.dp.toPx() * p }
            .clip(RoundedCornerShape(14.dp))
            .background(CreamCard)
            .background(if (isNew) Brush.horizontalGradient(listOf(LocalSkin.current.accent.copy(alpha = 0.18f), CreamCard)) else Brush.horizontalGradient(listOf(CreamCard, CreamCard)))
            .border(2.dp, Ink, RoundedCornerShape(14.dp))
            .clickableNoRipple(src) {
                if (item.url.isBlank()) return@clickableNoRipple
                haptics.tap()
                runCatching {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // timeline bar: orange for new, quiet ink for older
        Box(Modifier.width(6.dp).fillMaxHeight().background(if (isNew) LocalSkin.current.accent else Ink.copy(alpha = 0.15f)))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isNew) {
                    val pulse by com.momentum.focus.ui.components.ambient(0.4f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "newDotT")
                    Box(Modifier.size(8.dp).graphicsLayer { alpha = pulse }.clip(CircleShape).background(LocalSkin.current.accent))
                    Spacer(Modifier.width(6.dp))
                }
                if (item.exam.isNotBlank()) {
                    Text(
                        item.exam.uppercase(), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, color = Ink,
                        modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Sky.fill).border(1.5.dp, Ink, RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 1.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text(item.date, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Ink.copy(alpha = 0.55f))
            }
            Spacer(Modifier.height(5.dp))
            Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (item.body.isNotBlank()) {
                Text(item.body, style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = 0.6f), maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        if (item.url.isNotBlank()) {
            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = Ink, modifier = Modifier.padding(end = 12.dp).size(18.dp))
        }
    }
}


/**
 * The ceramic glowing progress bar from the reference clip — a flight
 * tracker there, today's focus minutes against a simple daily target here.
 * The dotted texture on the left, the glowing rounded fill, and the bright
 * marker riding its leading edge are the three things that made the
 * reference read as "physical hardware" rather than a flat percentage bar;
 * all three are kept, the flight-specific labels are not.
 */
@Composable
private fun CeramicProgressBar(minutesToday: Int, targetMinutes: Int, modifier: Modifier = Modifier) {
    val progress = (minutesToday.toFloat() / targetMinutes.toFloat()).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(progress, tween(600), label = "ceramic-progress")

    Box(
        modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(18.dp), clip = false, ambientColor = Color.Black, spotColor = Color.Black)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF1B1D22), Color(0xFF101114))))
            .padding(14.dp),
    ) {
        // The dotted texture, confined to the left third — a hint of surface
        // detail behind the numbers, not competing with them.
        Canvas(Modifier.matchParentSize()) {
            val spacing = 9.dp.toPx()
            var y = spacing / 2f
            while (y < this.size.height) {
                var x = spacing / 2f
                while (x < this.size.width * 0.4f) {
                    drawCircle(Color.White.copy(alpha = 0.05f), 1.2f, Offset(x, y))
                    x += spacing
                }
                y += spacing
            }
        }
        Column {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom,
            ) {
                Column {
                    Text(
                        "FOCUS TODAY",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.45f),
                        letterSpacing = 1.2.sp,
                    )
                    Text(
                        "${minutesToday / 60}h ${minutesToday % 60}m",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                    )
                }
                Text(
                    "Goal ${targetMinutes / 60}h",
                    style = MaterialTheme.typography.bodySmall,
                    color = Mint.accent,
                )
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(14.dp)) {
                Box(
                    Modifier
                        .matchParentSize()
                        .clip(RoundedCornerShape(7.dp))
                        .background(Color.White.copy(alpha = 0.08f)),
                )
                BoxWithConstraints(Modifier.matchParentSize()) {
                    val fillWidth = maxWidth * animatedProgress
                    Box(
                        Modifier
                            .width(fillWidth.coerceAtLeast(14.dp))
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(7.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Mint.fill.copy(alpha = 0.7f), Mint.accent),
                                ),
                            )
                            .drawBehind {
                                drawCircle(
                                    brush = Brush.radialGradient(
                                        listOf(Mint.accent.copy(alpha = 0.9f), Color.Transparent),
                                        center = Offset(size.width, size.height / 2f),
                                        radius = size.height * 2.2f,
                                    ),
                                    radius = size.height * 2.2f,
                                    center = Offset(size.width, size.height / 2f),
                                )
                            },
                    )
                }
            }
        }
    }
}

/**
 * The "Billboard sync" beat from the original artifact preview — a single
 * diagonal light sweep across the hero the one time real weather data
 * actually lands, standing in for the billboard "refreshing". Built as a
 * modifier rather than a child composable so it draws over everything else
 * already layered onto the hero (petals, notes, the balance number)
 * regardless of where in the tree it's attached.
 *
 * Gated on [HomeSession.billboardSwept], the same guard the greeting and
 * the weather badge itself use — without it this would replay every time
 * Home is disposed and recomposed on a tab switch, because [trigger] is
 * already non-null the moment a cached weather reading exists, and a fresh
 * `remember` block has no memory of already having played it once.
 */
private fun Modifier.billboardSyncSweep(trigger: WeatherSnapshot?): Modifier = composed {
    var elapsedMs by remember { mutableFloatStateOf(0f) }
    var playing by remember { mutableStateOf(false) }
    LaunchedEffect(trigger) {
        if (trigger != null && !HomeSession.billboardSwept) {
            HomeSession.billboardSwept = true
            playing = true
            val start = withFrameNanos { it }
            while (elapsedMs < 900f) {
                withFrameNanos { now -> elapsedMs = (now - start) / 1_000_000f }
            }
            playing = false
        }
    }
    val t = (elapsedMs / 800f).coerceIn(0f, 1f)
    this.drawWithContent {
        drawContent()
        if (playing && t < 1f) {
            val sx = -size.width * 0.3f + t * size.width * 1.6f
            drawRect(
                brush = Brush.linearGradient(
                    listOf(
                        Color.Transparent,
                        Color.White.copy(alpha = 0.30f * (1f - t)),
                        Color.Transparent,
                    ),
                    start = Offset(sx - size.width * 0.15f, 0f),
                    end = Offset(sx + size.width * 0.15f, size.height),
                ),
            )
        }
    }
}


/**
 * "Freeze used · streak safe" — shown once after a freeze covers a missed day.
 * Slides in with a 240 ms settle and the SHIELD_ON sound; tap clears it.
 * No loop: it sits still until dismissed.
 */
@Composable
private fun FreezeSavedNotice(saved: Int, onDismiss: () -> Unit) {
    if (saved <= 0) return
    val str = strings().streak
    val enter = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(saved) {
        com.momentum.focus.ui.util.Sfx.play(com.momentum.focus.ui.util.Sound.SHIELD_ON)
        enter.animateTo(1f, tween(240, easing = FastOutSlowInEasing))
    }
    Spacer(Modifier.height(8.dp))
    Row(
        Modifier
            .graphicsLayer {
                alpha = enter.value
                translationY = (1f - enter.value) * 10.dp.toPx()
                rotationZ = 2f
            }
            .clip(RoundedCornerShape(9.dp))
            .background(Sky.fill)
            .border(2.5.dp, Ink, RoundedCornerShape(9.dp))
            .clickableNoRipple(remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { onDismiss() }
            .padding(horizontal = 9.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        com.momentum.focus.ui.components.IceCube(true, Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Column {
            Text(
                str.savedTitle(saved),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Black,
                color = Sky.on,
            )
            Text(str.savedSub, style = MaterialTheme.typography.labelSmall, color = Sky.on.copy(alpha = 0.7f))
        }
    }
}
