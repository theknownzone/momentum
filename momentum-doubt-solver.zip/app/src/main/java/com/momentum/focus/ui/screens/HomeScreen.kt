package com.momentum.focus.ui.screens


import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.drawscope.Stroke
import com.momentum.focus.ui.components.CrownMark
import com.momentum.focus.ui.components.SyncPulse
import com.momentum.focus.ui.components.BlockedAppsPopup
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import com.momentum.focus.ui.components.BaselineReveal
import com.momentum.focus.ui.components.BrokenNotice
import com.momentum.focus.ui.components.SkinWeather
import com.momentum.focus.ui.components.UpdatedStrip
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileObject
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.window.Dialog
import com.momentum.focus.ui.components.FrostCard
import com.momentum.focus.ui.components.clickableNoRipple
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.composed
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.momentum.focus.R
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.Currency
import com.momentum.focus.data.ExamNews
import com.momentum.focus.data.ExamNewsItem
import com.momentum.focus.data.HolidayCalendar
import com.momentum.focus.data.ScreenTime
import com.momentum.focus.data.Weather
import com.momentum.focus.data.WeatherCondition
import com.momentum.focus.data.WeatherSnapshot
import com.momentum.focus.data.FocusSession
import com.momentum.focus.data.unlockedCount
import androidx.compose.foundation.Canvas
import com.momentum.focus.block.Heartbeat
import com.momentum.focus.ui.components.rakhiMotif
import com.momentum.focus.ui.components.PactBanner
import com.momentum.focus.ui.components.*
import com.momentum.focus.ui.i18n.Strings
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.OemStartup
import com.momentum.focus.ui.util.rememberHaptics
import java.time.LocalDate
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

/**
 * Two-plane dashboard: a dark hero card holding identity and the balance,
 * sitting on a cream body that carries everything else.
 *
 * The split is doing real work. The dark plane is where the number that
 * matters lives, so the eye goes there first every time the app opens; the
 * cream plane is where you act. One surface for status, one for doing.
 */

/**
 * Survives what the Composable state around it does not: switching to
 * another tab and back disposes HomeScreen entirely (the nav `when` in
 * MainActivity only ever composes the current tab), so every `remember`
 * inside it — the weather badge, the exam-news sync, the greeting's
 * one-time typing — was quietly starting over on every single visit, not
 * once per app launch the way each of them was written and commented to
 * behave. Two real network calls and a 20-character animated retype, every
 * time someone tapped back to Home, is the lag that was actually being felt.
 * A plain object outside Compose's lifecycle remembers across that disposal
 * for the life of the process, which is all "once per launch" ever meant.
 */
private object HomeSession {
    var weather: WeatherSnapshot? = null
    var weatherChecked = false
    var news: List<ExamNewsItem>? = null
    var greetingPlayed = false
    var billboardSwept = false
}

@Composable
fun HomeScreen(
    data: AppData,
    onStartFocus: () -> Unit,
    onPanic: () -> Unit,
    onJournal: () -> Unit,
    onProfile: () -> Unit,
    onShield: () -> Unit,
    onFeeds: () -> Unit,
    onRewards: () -> Unit,
    onNotify: (Boolean) -> Unit = {},
    onPerms: () -> Unit = {},
    /** Non-null only right after an update, and only until dismissed. */
    updatedVersion: String? = null,
    onOpenChangelog: () -> Unit = {},
    onDismissUpdate: () -> Unit = {},
) {
    var bellOpen by remember { mutableStateOf(false) }
    val str = strings()
    val haptics = rememberHaptics()
    val context = androidx.compose.ui.platform.LocalContext.current
    val phoneToday by produceState(0, context) {
        value = ScreenTime.report(context).dailyMinutes.lastOrNull() ?: 0
    }
    var holidays by remember { mutableStateOf(HolidayCalendar.bundled(context)) }
    // Exam notices. Bundled copy renders instantly, the remote copy replaces it
    // when the network allows; a failed fetch simply leaves what is on device.
    var news by remember { mutableStateOf(HomeSession.news ?: ExamNews.bundled(context)) }
    // No region lookup here any more. The catalogue's region field holds "IN"
    // or "World", never a state, so feeding it to the matcher only ever looked
    // like state filtering — the Rajasthan notices actually reach RPSC and REET
    // candidates through the exam name itself.
    var alert by remember { mutableStateOf<ExamNewsItem?>(null) }
    // Bumped whenever anything marks a notice read, because the seen-set lives
    // in SharedPreferences and Compose cannot see it change.
    //
    // The bell count was keyed only on the feed and the exam name, so a write
    // to the seen-set moved neither key and the badge kept whatever number it
    // was last given. Opening the bell left the count sitting there; the
    // launch popup marking one read did nothing to it. It only ever corrected
    // itself by accident, when some unrelated field of data happened to change
    // and force a recompute.
    var seenEpoch by remember { mutableStateOf(0) }
    // Real this time — the wash used to only exist in an HTML preview.
    // True for the actual span of the network call, not a fixed timer, so
    // it never lies about how long the check took.
    var syncingNews by remember { mutableStateOf(HomeSession.news == null) }
    // Shield used to take a tap on Home straight into the full BlockHub
    // screen just to answer "which apps did I actually turn on" — a whole
    // navigation for a question that is really just a look. This shows
    // that look here instead; "Manage" inside it is what still reaches
    // BlockHub, for the times the answer is actually "let me change one".
    var showBlockedPopup by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        // Already fetched once this session — the "checking for updates"
        // pulse only ever needs to run once, not every time this tab is
        // revisited, so an already-warm cache skips both the fetch and the
        // pulse entirely rather than replaying a sync that already happened.
        if (HomeSession.news != null) {
            alert = ExamNews.nextUnseen(context, news, data.examName)
            return@LaunchedEffect
        }
        // A cache hit (see ExamNews) can resolve in a handful of
        // milliseconds — the AnimatedVisibility fade barely had a frame to
        // paint before it was already fading back out, which is why the
        // sync at the bottom of this card was invisible in practice rather
        // than actually broken. A floor on how long the pulse stays up
        // fixes that without touching how long the real fetch takes.
        val start = System.currentTimeMillis()
        news = ExamNews.refresh(context)
        HomeSession.news = news
        val elapsed = System.currentTimeMillis() - start
        if (elapsed < 700L) delay(700L - elapsed)
        syncingNews = false
        haptics.tick()
        // Interrupts once per announcement, and only for an announcement that
        // is relevant to this profile.
        alert = ExamNews.nextUnseen(context, news, data.examName)
    }
    alert?.let { item ->
        ExamNewsPopup(item) {
            ExamNews.markSeen(context, item.id)
            seenEpoch++
            alert = null
        }
    }
    if (showBlockedPopup) {
        BlockedAppsPopup(
            blockedPackages = data.blockedPackages,
            dailyCapMinutes = data.dailyCapMinutes,
            onManage = onShield,
            onClose = { showBlockedPopup = false },
        )
    }
    LaunchedEffect(Unit) {
        holidays = HolidayCalendar.refresh(context)
        if (HolidayCalendar.inSeason(holidays) != null) haptics.festive()
    }
    // One weather check per cache window, same "runs, then leaves it alone"
    // shape as everything else here — see Weather.kt for why this needs no
    // location permission and no continuous polling.
    var weather by remember { mutableStateOf(HomeSession.weather) }
    LaunchedEffect(Unit) {
        if (HomeSession.weatherChecked) return@LaunchedEffect
        weather = Weather.sync(context)
        HomeSession.weather = weather
        HomeSession.weatherChecked = true
    }
    val season = remember(holidays) { HolidayCalendar.inSeason(holidays) }
    val nextHoliday = remember(holidays) { HolidayCalendar.upcoming(holidays) }
    // Used to be `season?.skin ?: skinFor(data.skin)` — on any day that
    // matches an entry in holidays.json (which is most weeks; there is one
    // roughly every 1-3 weeks all year) the hero colour and the weather
    // effect behind it silently switched to that festival's skin, no matter
    // what the person had actually picked in Profile. Today (Ganesh
    // Chaturthi, GOLD) is one of those days — which is exactly the "I pick a
    // theme and something else shows up" bug. The festival still gets its
    // moment: `festSkin` below still carries season?.skin to the Hero, which
    // still lays the Diwali lamp / Rakhi motif / Janmashtami feather art on
    // top and still fires the one-time festive haptic. It just no longer
    // repaints the whole hero over the top of a choice the person actually
    // made — if they want the festival's own colours and weather, that skin
    // is sitting right there in the picker, unlocked, for them to choose.
    val liveSkin = skinFor(data.skin)

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .verticalScroll(rememberScrollState()),
    ) {
        val unseen = remember(news, data.examName, seenEpoch) {
            ExamNews.unseenCount(context, news, data.examName)
        }
        // What was unread at the moment the bell was tapped. Held separately
        // because opening the bell marks everything read: without this the
        // sheet would recompute against a seen-set that had just been filled
        // in and show an empty "new" section every single time.
        var freshNotices by remember { mutableStateOf<List<ExamNewsItem>>(emptyList()) }
        Hero(
            data, str, liveSkin, season?.skin, phoneToday, onProfile,
            {
                // Opening the bell is reading them. Leaving the badge up after
                // the sheet has been opened makes it a number that never goes
                // down, and a badge nobody can clear is one people stop
                // looking at.
                freshNotices = ExamNews.unseen(context, news, data.examName)
                ExamNews.markAllSeen(context, news)
                seenEpoch++
                bellOpen = true
            },
            onStartFocus, onShield = { showBlockedPopup = true }, unseen,
            weather = weather,
        )
        // Room of its own now — this used to sit wedged between the phone-
        // today line and the earned-today prompt, competing with the
        // balance number it was two lines away from. A standalone card
        // right under the hero is the same "room to breathe" every other
        // card on this screen already gets.
        Spacer(Modifier.height(10.dp))
        CeramicProgressBar(
            minutesToday = data.minutesToday,
            targetMinutes = 180,
            modifier = Modifier.fillMaxWidth().padding(horizontal = Paper.ScreenPad),
        )
        if (bellOpen) {
            NotifySheet(
                on = data.notifyOn,
                fresh = freshNotices,
                earlier = ExamNews.relevant(news, data.examName)
                    .filter { item -> freshNotices.none { it.id == item.id } },
                onToggle = onNotify,
                onClose = { bellOpen = false },
            )
        }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 18.dp, bottom = 28.dp),
        ) {
            UpdateCard(Modifier.fillMaxWidth())

            if (syncingNews) {
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        // Was CreamCard — SyncPulse's dots are white and its
                        // wash is a low-alpha colour blend, both tuned for a
                        // dark backdrop (the artifact preview it started in).
                        // White dots on cream is why this was never actually
                        // seen: it was rendering the whole time, just at
                        // white-on-white-ish contrast.
                        .background(Color(0xFF15121D)),
                ) {
                    SyncPulse(visible = true, modifier = Modifier.matchParentSize())
                }
            }
            ExamNews.relevant(news, data.examName).let { relevant ->
                if (relevant.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    ExamNewsCard(relevant, Modifier.fillMaxWidth())
                }
            }

            // Says plainly that the first days are thin rather than dressing
            // three data points up as a trend.
            data.daysCollecting?.takeIf { it < 3 }?.let { days ->
                Spacer(Modifier.height(10.dp))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(CreamCard)
                        .border(Paper.Outline, Ink, RoundedCornerShape(16.dp))
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                ) {
                    Text(
                        str.home.notEnoughData,
                        style = MaterialTheme.typography.labelSmall,
                        color = InkMid,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (days <= 0) str.home.countingFromToday
                        else str.home.countingSince(days),
                        style = MaterialTheme.typography.titleMedium,
                        color = Ink,
                    )
                    Text(
                        str.home.afterThreeDays,
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                    )
                }
            }

            // Only on the day itself. A card counting down for a week sat on
            // Home doing nothing — it is not a task, not a warning, and not
            // something anyone acts on, so it was just a festival taking up the
            // slot the actual state of the app should occupy. Rule 5 already
            // says the skin arrives on the day; the card now matches it.
            nextHoliday?.takeIf { it.daysFrom() == 0L }?.let { h ->
                Spacer(Modifier.height(10.dp))
                // Frosted, as the preview of the iOS-style pass. Works here
                // because the page behind is a known flat cream — see FrostCard.
                FrostCard(
                    tint = h.skin.accent,
                    modifier = Modifier.clickableNoRipple(
                        remember { MutableInteractionSource() }
                    ) { haptics.festive() },
                ) {
                    Column {
                        Text(
                            str.home.calendar,
                            style = MaterialTheme.typography.labelSmall,
                            color = h.skin.accent,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            h.headline,
                            style = MaterialTheme.typography.headlineSmall,
                            color = Ink,
                        )
                        Text(
                            if (h.daysFrom() == 0L)
                                // Was "${h.skin.label} theme ...", which read
                                // "Rakhi theme" under a Ganesh Chaturthi
                                // headline, because several festivals share one
                                // skin. The skin name is not the festival name.
                                str.home.themeLiveToday
                            else
                                str.home.themeArrivesOnDay,
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMid,
                        )
                    }
                }
            }

            if (data.examName.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    data.daysToExam?.let { str.home.examWithDaysLeft(data.examName, it) }
                        ?: data.examName,
                    style = MaterialTheme.typography.titleMedium,
                    color = Ink,
                )
            }

            Spacer(Modifier.height(12.dp))

            // The heartbeat was being written by the service and read by
            // nobody, so an OEM kill stayed invisible — which is the entire
            // problem it existed to surface.
            val deadMins = remember(phoneToday) {
                runCatching { Heartbeat.deadMinutes(context) }.getOrDefault(0)
            }
            if (deadMins > 0) {
                // Tappable now, not just a diagnosis.
                //
                // The card already told the user exactly what to do —
                // "Turn Autostart ON" — in a sentence with nowhere to tap. It
                // knew the fix and made the person go find Settings, then
                // Permissions, then the right row themselves. Given how easy
                // that hop is to abandon halfway, the kill was likely to
                // recur, and would surface as "this app sometimes just stops
                // working" rather than as the one specific switch it actually
                // is. OemStartup.open() is the same call the Permissions
                // screen's own Autostart row uses, so tapping here does
                // exactly what tapping there would.
                FrostCard(
                    tint = Tang.fill,
                    modifier = Modifier.clickableNoRipple(
                        remember { MutableInteractionSource() }
                    ) {
                        haptics.tap()
                        runCatching { OemStartup.open(context) }
                    },
                ) {
                  Column {
                    Text(
                        str.home.shieldWasKilled,
                        style = MaterialTheme.typography.labelSmall,
                        color = Tang.on,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (deadMins >= 60)
                            str.home.deadForHoursMinutes(deadMins / 60, deadMins % 60)
                        else str.home.deadForMinutes(deadMins),
                        style = MaterialTheme.typography.headlineSmall,
                        color = Tang.on,
                    )
                    Text(
                        str.home.shieldKilledBody,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Tang.on,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Autostart kholne ke liye tap karo →",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Tang.on,
                    )
                  }
                }
                Spacer(Modifier.height(12.dp))
            }

            // Anything switched on that cannot actually run, said out loud.
            // Silent failure is the worst thing this app can do: the switch
            // looks on, the screen looks normal, and the blocking never
            // happens — and the person blames the app rather than the missing
            // permission.
            if (updatedVersion != null) {
                UpdatedStrip(
                    version = updatedVersion,
                    onOpen = onOpenChangelog,
                    onDismiss = onDismissUpdate,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(12.dp))
            }

            BrokenNotice(data, onFix = onPerms, modifier = Modifier.fillMaxWidth())

            PactBanner(data.lockUntilEpochMs, Modifier.fillMaxWidth())

            // The answer to the question setup asked. It sat unanswered in the
            // store from the first launch; this is the first thing in the app
            // that reads it back.
            Spacer(Modifier.height(12.dp))
            BaselineReveal(data, Modifier.fillMaxWidth())

            // The score and the four readings left this screen. They belong on
            // Profile, where the rest of "how you are doing" lives — Home is
            // the screen you open to start, and it had grown into a report you
            // scroll past on the way to a button.
            Spacer(Modifier.height(20.dp))
            Text(str.home.quickActions, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard(
                    art = TileArt.Bolt,
                    title = str.home.panic,
                    detail = str.home.panicDetail,
                    sticker = Tang,
                    modifier = Modifier.weight(1f),
                ) { haptics.panic(); onPanic() }
                ActionCard(
                    art = TileArt.Journal,
                    title = str.home.journal,
                    detail = str.home.journalDetail,
                    sticker = Lilac,
                    modifier = Modifier.weight(1f),
                ) { haptics.tap(); onJournal() }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard(
                    art = TileArt.Shield,
                    title = str.home.shield,
                    detail = str.home.shieldDetail(data.blockedPackages.size),
                    sticker = Mint,
                    modifier = Modifier.weight(1f),
                ) { haptics.shield(!data.shieldOn); showBlockedPopup = true }
                ActionCard(
                    art = TileArt.Coin,
                    title = str.home.rewards,
                    detail = str.home.rewardsDetail(data.unlockedCount),
                    sticker = Butter,
                    modifier = Modifier.weight(1f),
                ) { onRewards() }
            }
            Spacer(Modifier.height(10.dp))
            // Full width rather than half with a hole beside it. Five cards do
            // not divide into pairs, and the odd one left a gap that read as a
            // card that had failed to load. This is also the app's main
            // feature, so the wider slot is the right one for it.
            ActionCard(
                art = TileArt.Wallet,
                title = str.home.feeds,
                detail = if (data.blockedSurfaces.isEmpty()) str.home.feedsAllOn
                else str.home.feedsBlocked(data.blockedSurfaces.size),
                sticker = Tang,
                modifier = Modifier.fillMaxWidth(),
            ) { haptics.tap(); onFeeds() }

            Spacer(Modifier.height(24.dp))

            Text(
                str.home.recent,
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(10.dp))

            val feed = remember(data, str) { buildFeed(data, str) }
            if (feed.isEmpty()) EmptyFeed(str) else feed.forEach { ActivityRow(it) }

            // The deck sits last of the reading matter. Everything above it is
            // about this person; the deck is about studying in general, and
            // general advice belongs after the specifics rather than in front
            // of them.
            Spacer(Modifier.height(20.dp))
            InsightDeck(Modifier.fillMaxWidth())

            Spacer(Modifier.height(36.dp))
            Wordmark(skinFor(data.skin), str)
        }
    }
}

/**
 * The mark at the end of the scroll.
 *
 * Deliberately low contrast and oversized: it is a full stop, not a headline.
 * Reaching it should feel like arriving at the bottom of something made, which
 * is why it carries the version too.
 */
@Composable
private fun Wordmark(skin: Skin, str: Strings) {
    Column(Modifier.fillMaxWidth()) {
        Text(
            str.home.wordmarkTagline,
            style = MaterialTheme.typography.displayMedium.copy(
                fontFamily = FontFamily.Serif,
                letterSpacing = (-1.5).sp,
            ),
            color = InkLow.copy(alpha = 0.55f),
        )
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(InkLow.copy(alpha = 0.4f))
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "momentum",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontFamily = FontFamily.Serif,
            ),
            color = InkLow.copy(alpha = 0.5f),
        )
        Text(
            str.home.skinTheme(skin.label),
            style = MaterialTheme.typography.bodyMedium,
            color = InkLow.copy(alpha = 0.45f),
        )
    }
}

// ---------------------------------------------------------------- hero

@Composable
private fun Hero(
    data: AppData,
    str: Strings,
    skin: Skin,
    festSkin: Skin?,
    phoneToday: Int,
    onProfile: () -> Unit,
    onBell: () -> Unit,
    onStartFocus: () -> Unit,
    onShield: () -> Unit,
    unseenNotices: Int,
    weather: WeatherSnapshot? = null,
) {
    val haptics = rememberHaptics()
    val low = DeviceProfile.isLowEnd(androidx.compose.ui.platform.LocalContext.current)
    val counted by animateFloatAsState(
        targetValue = data.balanceMinutes.toFloat(),
        animationSpec = Motion.settle(),
        label = "balance",
    )
    val minutes = counted.roundToInt()

    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 26.dp, bottomEnd = 26.dp))
            .background(
                Brush.verticalGradient(listOf(skin.heroTop, skin.heroBottom))
            ),
    ) {
        // Petals live behind the content, clipped to the hero, so the movement
        // is always there without ever competing with the number.
        // Notes drift behind the balance, petals in front of them. Two layers
        // at different opacities give the hero depth without either of them
        // competing with the number.
        if (!low) {
            // The alpha bump exists to let dedicated festival art read through
            // the hero. Rakhi has no art of its own, so bumping it only made
            // money_rain look washed out over the dark band — a skin with no
            // art gets the ordinary treatment.
            val festArt = when (festSkin) {
                Skin.DIWALI -> R.drawable.fest_diwali
                else -> null
            }
            // Rakhi has no artwork file — it is drawn, so there is nothing to
            // source, nothing to watermark and no baked-in English to collide
            // with the balance.
            if (festSkin == Skin.RAKHI) {
                Canvas(Modifier.matchParentSize()) {
                    rakhiMotif(
                        cx = size.width * 0.80f,
                        cy = size.height * 0.30f,
                        radius = size.minDimension * 0.10f,
                        thread = skin.petal.copy(alpha = 0.55f),
                        petal = skin.petal.copy(alpha = 0.40f),
                        centre = skin.heroTop.copy(alpha = 0.85f),
                        outline = skin.petal.copy(alpha = 0.30f),
                    )
                }
            }
            // Janmashtami is drawn too, for the same reason as Rakhi. The
            // feather hangs below its eye, so it is anchored higher than the
            // rakhi to keep the plume off the balance.
            if (festSkin == Skin.JANMASHTAMI) {
                Canvas(Modifier.matchParentSize()) {
                    morPankhMotif(
                        cx = size.width * 0.80f,
                        cy = size.height * 0.30f,
                        radius = size.minDimension * 0.085f,
                        plume = skin.petal.copy(alpha = 0.42f),
                        eyeOuter = skin.petal.copy(alpha = 0.60f),
                        eyeInner = skin.accent.copy(alpha = 0.70f),
                        core = skin.heroTop.copy(alpha = 0.90f),
                    )
                }
            }
            Image(
                painter = painterResource(festArt ?: R.drawable.money_rain),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = if (festArt != null) 0.42f else 0.28f,
                modifier = Modifier.matchParentSize(),
            )
            // Weather that matches the skin, replacing the petal fall that ran
            // under every one of them. Monsoon dropped cherry blossom; Ember
            // dropped cherry blossom; Midnight dropped cherry blossom. Each of
            // those names promises something and the app delivered the same
            // pink drift five times, which is worse than no effect at all —
            // the second time you see it the name stops meaning anything.
            SkinWeather(skin, Modifier.matchParentSize())
        }

        Column(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 14.dp, bottom = 22.dp),
        ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(data) { haptics.tap(); onProfile() }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                TypedGreeting(
                    name = data.userName,
                    nameColor = CreamCard,
                    labelColor = InkLow,
                    alreadyPlayed = HomeSession.greetingPlayed,
                )
                SideEffect { HomeSession.greetingPlayed = true }
                // The plain "X day streak" line upgraded to the comic
                // sticker-badge treatment from the reference — same fact,
                // shown once, just with the weight a streak actually
                // deserves instead of small grey InkLow text easy to miss.
                Box(
                    Modifier
                        .graphicsLayer { rotationZ = -3f }
                        .clip(RoundedCornerShape(9.dp))
                        .background(Tang.fill)
                        .border(2.5.dp, Ink, RoundedCornerShape(9.dp))
                        .padding(horizontal = 9.dp, vertical = 4.dp),
                ) {
                    Text(
                        str.home.dayStreak(data.streakDays),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Black,
                        color = Tang.on,
                    )
                }
                // The one-time weather sync: fades and scales in once when a
                // fresh reading lands, then just sits there as a small badge
                // — it does not keep animating, and it never touches
                // skin.heroTop/heroBottom. The actual theme colour is still
                // entirely whatever the person picked; this is a fact about
                // today layered on top of it, the same relationship the
                // festival art already has with the skin underneath it.
                weather?.let { w ->
                    var shown by remember(w) { mutableStateOf(false) }
                    LaunchedEffect(w) { shown = true }
                    val badgeAlpha by animateFloatAsState(
                        if (shown) 1f else 0f, tween(500), label = "weather-fade",
                    )
                    val badgeScale by animateFloatAsState(
                        if (shown) 1f else 0.6f,
                        spring(dampingRatio = 0.6f, stiffness = 300f),
                        label = "weather-scale",
                    )
                    Row(
                        Modifier
                            .padding(top = 2.dp)
                            .graphicsLayer {
                                alpha = badgeAlpha
                                scaleX = badgeScale
                                scaleY = badgeScale
                                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
                            }
                            .billboardSyncSweep(w),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            when (w.condition) {
                                WeatherCondition.RAIN -> "\uD83C\uDF27\uFE0F"
                                WeatherCondition.SNOW -> "\u2744\uFE0F"
                                WeatherCondition.SUN -> "\u2600\uFE0F"
                                WeatherCondition.CLOUD -> "\u2601\uFE0F"
                            },
                            fontSize = 12.sp,
                            modifier = if (w.condition == WeatherCondition.SUN) {
                                // The reference's sun-glow pulse, kept to
                                // just this one condition and just the
                                // emoji itself — the badge stays a small
                                // fact-of-the-day mark either way, this
                                // only adds the one touch that's specific
                                // to it actually being sunny.
                                val sunGlow = rememberInfiniteTransition(label = "sun-glow")
                                val glowT by sunGlow.animateFloat(
                                    0.5f, 1f,
                                    infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse),
                                    label = "glow",
                                )
                                Modifier.drawBehind {
                                    drawCircle(
                                        Color(0xFFFFD84D).copy(alpha = 0.35f * glowT),
                                        radius = size.maxDimension * 1.1f * glowT,
                                    )
                                }
                            } else Modifier,
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            "${w.tempC}\u00b0",
                            style = MaterialTheme.typography.labelSmall,
                            color = InkLow,
                        )
                    }
                }
            }

            // The bell, in the hero's corner where every app puts it. It shows
            // the state rather than opening anything: struck through when
            // nudges are off, so the one question it answers — "is this thing
            // going to talk to me" — is answered without a tap. Tapping goes
            // to the switch that changes it.
            Box {
                Box(
                    Modifier
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.10f))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tap(); onBell()
                        }
                        .padding(9.dp),
                ) {
                    Icon(
                        if (data.notifyOn) Icons.Filled.Notifications
                        else Icons.Filled.NotificationsOff,
                        contentDescription = null,
                        tint = if (data.notifyOn) CreamCard else InkLow,
                        modifier = Modifier.size(20.dp),
                    )
                }
                // The count of unread notices, on the bell.
                //
                // The seen-set has been tracked since the feed was built and
                // nothing ever counted it, so a notice could land and sit on
                // Home with no sign it was new. Without the number the bell is
                // decoration and the news only reaches whoever happens to
                // scroll past it.
                if (unseenNotices > 0) {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = 3.dp, y = (-3).dp)
                            .clip(CircleShape)
                            .background(Tang.fill)
                            .border(2.dp, Ink, CircleShape)
                            .padding(horizontal = 5.dp, vertical = 1.dp),
                    ) {
                        Text(
                            // Past nine the exact figure is not the message.
                            if (unseenNotices > 9) "9+" else "$unseenNotices",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Tang.on,
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Coin3D(color = skin.accent, size = 26.dp)
            Spacer(Modifier.width(8.dp))
            Text(
                str.home.walletBalance,
                style = MaterialTheme.typography.bodyMedium,
                color = InkLow,
            )
        }
        Spacer(Modifier.height(2.dp))

        // Hours large, minutes small — the same trick a bank uses for rupees
        // and paise, so the eye lands on the meaningful digit first.
        // Whole minutes big, the unit small and quiet — the shape a bank uses
        // for rupees and paise, so the number reads as money to spend rather
        // than a duration to endure.
        Text(
            Currency.format(minutes),
            style = MaterialTheme.typography.displayLarge,
            color = GoldNeon,
        )
        Text(
            str.home.bankedFromFocus(minutes / 60, minutes % 60),
            style = MaterialTheme.typography.bodyMedium,
            color = InkLow,
        )
        Text(
            str.home.phoneToday(phoneToday / 60, phoneToday % 60),
            style = MaterialTheme.typography.bodyMedium,
            color = InkLow,
        )
        if (data.earnedMinutes == 0) {
            Spacer(Modifier.height(6.dp))
            Text(
                // Naming a subject only works when the user has named one.
                // The old fallback said "Physics" to everybody, including the
                // banking and law candidates the exam catalogue also serves.
                data.subjects.firstOrNull()
                    ?.let { str.home.firstRupeeHint(it) }
                    ?: str.home.firstRupeeAnySubject,
                style = MaterialTheme.typography.bodyMedium,
                color = Mint.fill,
            )
        }

        Spacer(Modifier.height(12.dp))

        // Glass rather than a solid fill: the money_rain art and the petals
        // run behind this strip, and a flat Mint.on block cut a hole in them.
        GlassBar(Modifier.fillMaxWidth(), tint = skin.accent) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    str.home.earnedToday(Currency.format(data.minutesToday)),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mint.fill,
                )
                Spacer(Modifier.weight(1f))
                Text(
                    str.home.sessionsCount(data.sessions.count { it.completed }),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mint.fill,
                )
            }
        }

        data.daysToExam?.let { days ->
            if (days >= 0) {
                Spacer(Modifier.height(10.dp))
                // Same glass as the earned-today strip above it. This was a
                // flat 18% wash, which let the art through but had none of the
                // lit edge, so two bars sitting on the same artwork a few dp
                // apart were treated two different ways.
                GlassBar(Modifier.fillMaxWidth(), tint = Tang.fill, radius = 10.dp) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        str.home.daysToExam(days, data.examName.ifBlank { str.home.boardsFallback }),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Tang.fill,
                        modifier = Modifier.weight(1f),
                    )
                    if (data.examIsClose) {
                        Text(
                            str.home.crownWindow,
                            style = MaterialTheme.typography.labelSmall,
                            color = Tang.fill,
                        )
                    }
                }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HeroButton(str.home.startFocus, Mint.fill, Mint.on, Modifier.weight(1f)) {
                onStartFocus()
            }
            HeroButton(str.home.shield, CreamCard, Ink, Modifier.weight(1f)) {
                onShield()
            }
        }
        }
    }
}

@Composable
private fun HeroButton(
    label: String,
    fill: androidx.compose.ui.graphics.Color,
    on: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    // The orb button's own press feel — a scale-down plus a brighter inner
    // glow on press, rather than a flat rectangle with no feedback beyond
    // the ripple this app already turns off everywhere.
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "hero-btn-scale")
    val glow by animateFloatAsState(if (pressed) 0.35f else 0.16f, tween(150), label = "hero-btn-glow")

    // The shine-sweep from the reference — a diagonal streak that crosses
    // the button once on press, layered on top of the orb glow above
    // rather than replacing it; the glow is the resting/press brightness,
    // this is the one-off motion a press actually earns.
    var sweepT by remember { mutableFloatStateOf(1f) }
    LaunchedEffect(pressed) {
        if (pressed) {
            sweepT = 0f
            val start = withFrameNanos { it }
            while (sweepT < 1f) {
                withFrameNanos { now -> sweepT = ((now - start) / 1_000_000f / 380f).coerceIn(0f, 1f) }
            }
        }
    }

    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(13.dp))
            .background(fill)
            .drawBehind {
                drawRect(
                    brush = Brush.radialGradient(
                        listOf(Color.White.copy(alpha = glow), Color.Transparent),
                        center = Offset(size.width * 0.3f, -size.height * 0.2f),
                        radius = size.width * 0.9f,
                    ),
                )
                if (sweepT < 1f) {
                    val headX = -size.width * 0.3f + sweepT * size.width * 1.6f
                    drawRect(
                        brush = Brush.linearGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.30f * (1f - sweepT)), Color.Transparent),
                            start = Offset(headX - size.width * 0.18f, 0f),
                            end = Offset(headX + size.width * 0.18f, size.height),
                        ),
                    )
                }
            }
            .clickableNoRipple(interaction) {
                haptics.confirm(); onClick()
            }
            .padding(vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium, color = on)
    }
}

@Composable
private fun Avatar(data: AppData, onClick: () -> Unit) {
    Box(
        Modifier
            .size(if (data.premium) 60.dp else 52.dp)
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        // A gold ring for people who paid, and a crown sitting on it.
        //
        // Premium shows up on the Plans page and nowhere else in the app, so
        // after the purchase there is nothing to see — you paid and your own
        // screen looks identical. This is the one mark that is theirs and is
        // visible every single time they open it.
        if (data.premium) {
            Canvas(Modifier.size(60.dp)) {
                val r = size.minDimension / 2f - 2f
                drawCircle(
                    brush = Brush.sweepGradient(
                        listOf(GoldNeon, Butter.fill, Color.White, GoldNeon, Butter.fill, GoldNeon),
                    ),
                    radius = r,
                    style = Stroke(width = 4.dp.toPx()),
                )
                drawCircle(color = Ink, radius = r + 2.dp.toPx(), style = Stroke(1.5.dp.toPx()))
            }
        }
        Avatar3D(
            colorIndex = data.avatarColor,
            shapeIndex = data.avatarShape,
            size = 52.dp,
        )
        if (data.premium) {
            // On the rim at the top, tipped slightly, the way a crown sits
            // rather than the way a badge is pinned.
            CrownMark(
                size = 22.dp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (-8).dp)
                    .rotate(-12f),
            )
        }
    }
}

// ---------------------------------------------------------------- body

@Composable
private fun ActionCard(
    art: TileArt,
    title: String,
    detail: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            // A cast shadow under the card, offset down and right. This is the
            // whole difference between a rectangle drawn on paper and an
            // object resting on it — the reference app builds its entire look
            // out of things that sit above the grid rather than being printed
            // into it.
            .drawBehind {
                val d = 5.dp.toPx()
                drawRoundRect(
                    color = Ink.copy(alpha = 0.20f),
                    topLeft = Offset(d, d),
                    size = size,
                    cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx()),
                )
            }
            .clip(shape)
            // Lighter at the top, so the surface has a direction.
            .background(
                Brush.verticalGradient(
                    listOf(Color.White, CreamCard, Sunk.copy(alpha = 0.55f)),
                ),
            )
            .border(2.dp, Ink, shape)
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                haptics.tap(); onClick()
            }
            .padding(14.dp),
    ) {
        // A drawn solid, not a glyph in a coloured square. A Material icon is
        // flat by construction — one colour, no light on it — and the whole
        // look this is chasing is small objects sitting on grid paper with a
        // lit side, a dark side and a shadow under them.
        TileObject(art = art, fill = sticker.fill, size = 42.dp)
        Spacer(Modifier.height(10.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
        Text(detail, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}

private data class FeedRow(
    val title: String,
    val subtitle: String,
    val amount: String,
    val sticker: Sticker,
    val icon: ImageVector,
)

private fun buildFeed(data: AppData, str: Strings): List<FeedRow> {
    val today = LocalDate.now().toEpochDay()

    fun ago(day: Long) = when (val d = (today - day).toInt()) {
        0 -> str.common.today
        1 -> str.common.yesterday
        else -> str.common.daysAgo(d)
    }

    val sessions = data.sessions.takeLast(6).reversed().map { session: FocusSession ->
        FeedRow(
            title = session.subject,
            subtitle = if (session.completed) ago(session.startedAtEpochDay)
                       else str.home.leftEarly(ago(session.startedAtEpochDay)),
            amount = "+${Currency.format(session.minutes)}",
            sticker = if (session.completed) Mint else Butter,
            icon = Icons.Filled.Timer,
        )
    }

    val urges = data.urges.takeLast(4).reversed().map { u ->
        FeedRow(
            title = if (u.survived) str.home.urgeBeaten else str.home.slipLogged,
            subtitle = str.home.urgeWhen(ago(u.epochDay), u.hour),
            amount = if (u.survived) str.home.held else str.home.reset,
            sticker = if (u.survived) Sky else Candy,
            icon = Icons.Filled.Shield,
        )
    }

    return (sessions + urges).take(8)
}

@Composable
private fun ActivityRow(row: FeedRow) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(row.sticker.fill)
                .border(2.dp, Ink, RoundedCornerShape(9.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                row.icon,
                contentDescription = null,
                tint = row.sticker.on,
                modifier = Modifier.size(18.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(row.title, style = MaterialTheme.typography.titleMedium, color = Ink)
            Text(row.subtitle, style = MaterialTheme.typography.bodyMedium, color = InkMid)
        }
        Text(row.amount, style = MaterialTheme.typography.titleMedium, color = row.sticker.accent)
    }
}

@Composable
private fun EmptyFeed(str: Strings) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        NoteStack3D(noteColor = Mint.fill, coinColor = Butter.fill, size = 118.dp)
        Spacer(Modifier.height(10.dp))
        Text(str.home.nothingBankedYet, style = MaterialTheme.typography.titleMedium, color = Ink)
        Spacer(Modifier.height(4.dp))
        Text(
            str.home.emptyFeedBody,
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
            textAlign = TextAlign.Center,
        )
    }
}

/**
 * The bell.
 *
 * This used to be a switch and three lines describing, in the abstract, what
 * notifications are for — while the actual notices sat in a card halfway down
 * Home. So the badge on the bell counted things the bell did not contain, and
 * the one place in the app shaped like an inbox was the one place with no mail
 * in it. The notices are the content now; the switch is a row at the bottom.
 */
@Composable
private fun NotifySheet(
    on: Boolean,
    fresh: List<ExamNewsItem>,
    earlier: List<ExamNewsItem>,
    onToggle: (Boolean) -> Unit,
    onClose: () -> Unit,
) {
    val haptics = rememberHaptics()
    val context = LocalContext.current
    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(CreamCard)
                .border(3.dp, Ink, RoundedCornerShape(22.dp))
                .padding(20.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TileObject(
                    art = if (on) TileArt.Feed else TileArt.Shield,
                    fill = if (on) Mint.fill else InkLow,
                    size = 34.dp,
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Notifications",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                )
            }
            Spacer(Modifier.height(14.dp))

            if (fresh.isEmpty() && earlier.isEmpty()) {
                Text(
                    "Abhi koi notice nahi.",
                    style = MaterialTheme.typography.titleMedium,
                    color = Ink,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    "Board kuch daalega to yahin aayega.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                )
            } else {
                // Capped and scrollable. A feed of a few hundred scraped
                // notices inside a dialog would run off the bottom of the
                // screen with no way to reach the switch under it.
                Column(
                    Modifier
                        .heightIn(max = 340.dp)
                        .verticalScroll(rememberScrollState()),
                ) {
                    if (fresh.isNotEmpty()) {
                        Text(
                            "NAYA",
                            style = MaterialTheme.typography.labelSmall,
                            color = Tang.fill,
                        )
                        Spacer(Modifier.height(6.dp))
                        fresh.forEach { NoticeRow(it, context, haptics, isNew = true) }
                    }
                    if (earlier.isNotEmpty()) {
                        if (fresh.isNotEmpty()) Spacer(Modifier.height(12.dp))
                        Text(
                            "PEHLE KE",
                            style = MaterialTheme.typography.labelSmall,
                            color = InkMid,
                        )
                        Spacer(Modifier.height(6.dp))
                        earlier.take(20).forEach {
                            NoticeRow(it, context, haptics, isNew = false)
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().height(Paper.Outline).background(Ink.copy(alpha = 0.25f)))
            Spacer(Modifier.height(12.dp))

            // The switch, now a row rather than the whole dialog.
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (on) Mint.fill.copy(alpha = 0.30f) else Sunk)
                    .border(2.dp, Ink.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        onToggle(!on); haptics.tick()
                    }
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Nudges",
                        style = MaterialTheme.typography.titleMedium,
                        color = Ink,
                    )
                    Text(
                        "Exam notice, streak tootne se pehle, hafte ka read.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                    )
                }
                Spacer(Modifier.width(10.dp))
                Text(
                    if (on) "CHALU" else "BAND",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (on) Mint.on else InkMid,
                )
            }
        }
    }
}

/** One notice inside the bell. Tapping opens the official page, if there is one. */
@Composable
private fun NoticeRow(
    item: ExamNewsItem,
    context: android.content.Context,
    haptics: com.momentum.focus.ui.util.Haptics,
    isNew: Boolean,) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (isNew) Butter.fill.copy(alpha = 0.22f) else Sunk.copy(alpha = 0.5f))
            .border(
                1.5.dp,
                if (isNew) Ink.copy(alpha = 0.55f) else Ink.copy(alpha = 0.22f),
                RoundedCornerShape(12.dp),
            )
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                if (item.url.isBlank()) return@clickableNoRipple
                haptics.tap()
                runCatching {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(item.url))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                }
            }
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (item.exam.isNotBlank()) {
                Text(
                    item.exam.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = Tang.fill,
                )
                Spacer(Modifier.width(8.dp))
            }
            Text(
                item.date,
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
        }
        Spacer(Modifier.height(3.dp))
        Text(
            item.title,
            style = MaterialTheme.typography.titleMedium,
            color = Ink,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        if (item.body.isNotBlank()) {
            Text(
                item.body,
                style = MaterialTheme.typography.bodyMedium,
                color = InkMid,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/**
 * The ceramic glowing progress bar from the reference clip — a flight
 * tracker there, today's focus minutes against a simple daily target here.
 * The dotted texture on the left, the glowing rounded fill, and the bright
 * marker riding its leading edge are the three things that made the
 * reference read as "physical hardware" rather than a flat percentage bar;
 * all three are kept, the flight-specific labels are not.
 */
@Composable
private fun CeramicProgressBar(minutesToday: Int, targetMinutes: Int, modifier: Modifier = Modifier) {
    val progress = (minutesToday.toFloat() / targetMinutes.toFloat()).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(progress, tween(600), label = "ceramic-progress")

    Box(
        modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(18.dp), clip = false, ambientColor = Color.Black, spotColor = Color.Black)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF1B1D22), Color(0xFF101114))))
            .padding(14.dp),
    ) {
        // The dotted texture, confined to the left third — a hint of surface
        // detail behind the numbers, not competing with them.
        Canvas(Modifier.matchParentSize()) {
            val spacing = 9.dp.toPx()
            var y = spacing / 2f
            while (y < this.size.height) {
                var x = spacing / 2f
                while (x < this.size.width * 0.4f) {
                    drawCircle(Color.White.copy(alpha = 0.05f), 1.2f, Offset(x, y))
                    x += spacing
                }
                y += spacing
            }
        }
        Column {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom,
            ) {
                Column {
                    Text(
                        "FOCUS TODAY",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.45f),
                        letterSpacing = 1.2.sp,
                    )
                    Text(
                        "${minutesToday / 60}h ${minutesToday % 60}m",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                    )
                }
                Text(
                    "Goal ${targetMinutes / 60}h",
                    style = MaterialTheme.typography.bodySmall,
                    color = Mint.accent,
                )
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(14.dp)) {
                Box(
                    Modifier
                        .matchParentSize()
                        .clip(RoundedCornerShape(7.dp))
                        .background(Color.White.copy(alpha = 0.08f)),
                )
                BoxWithConstraints(Modifier.matchParentSize()) {
                    val fillWidth = maxWidth * animatedProgress
                    Box(
                        Modifier
                            .width(fillWidth.coerceAtLeast(14.dp))
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(7.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Mint.fill.copy(alpha = 0.7f), Mint.accent),
                                ),
                            )
                            .drawBehind {
                                drawCircle(
                                    brush = Brush.radialGradient(
                                        listOf(Mint.accent.copy(alpha = 0.9f), Color.Transparent),
                                        center = Offset(size.width, size.height / 2f),
                                        radius = size.height * 2.2f,
                                    ),
                                    radius = size.height * 2.2f,
                                    center = Offset(size.width, size.height / 2f),
                                )
                            },
                    )
                }
            }
        }
    }
}

/**
 * The "Billboard sync" beat from the original artifact preview — a single
 * diagonal light sweep across the hero the one time real weather data
 * actually lands, standing in for the billboard "refreshing". Built as a
 * modifier rather than a child composable so it draws over everything else
 * already layered onto the hero (petals, notes, the balance number)
 * regardless of where in the tree it's attached.
 *
 * Gated on [HomeSession.billboardSwept], the same guard the greeting and
 * the weather badge itself use — without it this would replay every time
 * Home is disposed and recomposed on a tab switch, because [trigger] is
 * already non-null the moment a cached weather reading exists, and a fresh
 * `remember` block has no memory of already having played it once.
 */
private fun Modifier.billboardSyncSweep(trigger: WeatherSnapshot?): Modifier = composed {
    var elapsedMs by remember { mutableFloatStateOf(0f) }
    var playing by remember { mutableStateOf(false) }
    LaunchedEffect(trigger) {
        if (trigger != null && !HomeSession.billboardSwept) {
            HomeSession.billboardSwept = true
            playing = true
            val start = withFrameNanos { it }
            while (elapsedMs < 900f) {
                withFrameNanos { now -> elapsedMs = (now - start) / 1_000_000f }
            }
            playing = false
        }
    }
    val t = (elapsedMs / 800f).coerceIn(0f, 1f)
    this.drawWithContent {
        drawContent()
        if (playing && t < 1f) {
            val sx = -size.width * 0.3f + t * size.width * 1.6f
            drawRect(
                brush = Brush.linearGradient(
                    listOf(
                        Color.Transparent,
                        Color.White.copy(alpha = 0.30f * (1f - t)),
                        Color.Transparent,
                    ),
                    start = Offset(sx - size.width * 0.15f, 0f),
                    end = Offset(sx + size.width * 0.15f, size.height),
                ),
            )
        }
    }
}
