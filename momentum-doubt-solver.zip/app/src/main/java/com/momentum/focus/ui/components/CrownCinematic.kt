package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.size
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.GoldNeon
import androidx.compose.ui.platform.LocalContext
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.SystemVoice
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Total run time.
 *
 * Ten seconds. It ran in four, which is a transition rather than a cutscene —
 * the lock had barely finished drawing before it was already breaking, and the
 * title arrived while the shards were still in the air. Everything downstream
 * is a fraction of this number, so the whole thing stretches together and the
 * beats stay in the same places relative to each other.
 *
 * Still skippable on a tap. Ten seconds is a long time to be stuck watching
 * something twice, which is why this only ever plays once.
 */
private const val RUN_MS = 10_000

/** Warm black, not pure black — the app's own paper, with the lights off. */
private val Night = Color(0xFF14110A)
private val Ember = Color(0xFFFFB020)

private const val SHARDS = 44

/**
 * The Crown cutscene. Plays once, ever.
 *
 * Deliberately not made of paper, and that is the one place in this app where
 * breaking the house style is the right call: a cutscene is allowed to look
 * like nowhere else, because it happens once and then never again. It still
 * uses the app's gold and a warm black rather than a stock neon, so it reads as
 * this app with the lights off rather than a screen borrowed from another one.
 *
 * Drawn entirely with gradients and paths. No Modifier.blur anywhere — it is
 * API 31+, and the phones this ships to are mostly older than that, so a blur
 * would mean the one moment built to impress is the one moment that quietly
 * does nothing.
 *
 * Sound: there is none, and it is not an oversight. Shipping an anime voice
 * line would mean either the system text-to-speech, which sounds like a robot
 * reading a menu, or an audio file nobody here has the rights to. The beats are
 * marked with haptics instead, which work in a library at midnight. Drop a
 * MediaPlayer call into the beat block below if you have a clip of your own.
 */
@Composable
fun CrownCinematic(onDone: () -> Unit) {
    val str = strings()
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val progress = remember { Animatable(0f) }

    // Fewer shards on a cheap phone.
    //
    // The scene draws forty-four of them plus a grid plus rays, every frame,
    // for ten seconds — and it runs at exactly the moment someone has just
    // paid, so a stutter here lands on the one screen that is supposed to feel
    // like the money was worth it. The beats and the timing are untouched;
    // there is simply less on screen between them.
    val shards = DeviceProfile.particles(context, SHARDS)

    LaunchedEffect(Unit) {
        // Warmed here rather than at the beat: building the engine is
        // asynchronous, so asking it to speak the moment it is created loses
        // the line entirely.
        SystemVoice.init(context)

        // The beats, on one timeline beside the playhead.
        //
        // The sounds are synthesised, not shipped — the app already builds its
        // tones from raw PCM, so a riser and a low hit cost a few lines of
        // maths instead of an audio file nobody owns the rights to. They go
        // through playOnce, which ignores the UI-sound switch (that switch is
        // there to stop fifty taps a day chirping, not to silence something
        // that happens once ever) but still obeys the physical silent switch.
        //
        // These were six separate LaunchedEffects keyed on `t > 0.03f` and
        // friends. That worked, but every one of those keys was recomputed on
        // every frame of a ten-second animation, and reading `progress.value`
        // up here to compute them recomposed this entire composable — scene,
        // title, close button — sixty times a second. On the older phones this
        // cutscene exists to impress, that is the wrong sixty frames to spend.
        //
        // delay and the tween below run off the same wall clock, so the beats
        // still land where they always did.
        launch {
            fun at(f: Float) = (RUN_MS * f).toLong()
            delay(at(0.03f)); Sfx.playOnce(Sound.RISER)
            delay(at(0.12f - 0.03f)); haptics.tick()
            delay(at(0.38f - 0.12f)); Sfx.playOnce(Sound.CRACK); haptics.press()
            delay(at(0.52f - 0.38f)); Sfx.playOnce(Sound.BOOM); haptics.celebrate()
            delay(at(0.64f - 0.52f)); Sfx.playOnce(Sound.SHIMMER); haptics.festive()
            // Lands over the title, with enough of the run left for the line to
            // finish inside the cutscene rather than trailing onto the next
            // screen.
            delay(at(0.66f - 0.64f)); SystemVoice.say(str.crown.voiceLine)
        }

        progress.animateTo(1f, tween(RUN_MS, easing = LinearEasing))
        // No onDone here. It used to close itself the moment the animation
        // finished, which meant the one thing this exists for — the title
        // holding on screen after the noise stops — was on screen for a
        // fraction of a second before the app took it away. It waits for a tap
        // now, on the close button or anywhere else.
    }

    Box(
        Modifier
            .fillMaxSize()
            // progress is read inside the draw lambda, not in composition, so
            // the scene redraws every frame without recomposing anything.
            .drawBehind { drawScene(progress.value, shards) }
            .clickableNoRipple(remember { MutableInteractionSource() }) { onDone() },
        contentAlignment = Alignment.Center,
    ) {
        // A real close button, not just a tap-anywhere. Ten seconds is long
        // enough that someone will want out before it ends, and "tap to
        // continue" only appears in the last second — until then there was
        // nothing on screen saying this could be skipped at all.
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(16.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.14f))
                .clickableNoRipple(remember { MutableInteractionSource() }) { onDone() }
                .padding(8.dp),
        ) {
            Icon(
                Icons.Filled.Close,
                contentDescription = str.crown.skip,
                tint = Color.White.copy(alpha = 0.75f),
                modifier = Modifier.size(20.dp),
            )
        }

        // The title slams in after the lock breaks. Scale and tracking both
        CrownTitle(progress, str)
    }
}

/**
 * The title, subtitle and skip hint.
 *
 * Split out so that reading the playhead recomposes three Text nodes rather
 * than the whole cutscene. The parent reads `progress` only inside its
 * drawBehind lambda, which runs in the draw phase and recomposes nothing.
 *
 * letterSpacing and color are composition-level parameters, so this subtree
 * genuinely does have to recompose per frame — but three Texts is a different
 * order of cost from the full screen plus a forty-four shard scene.
 */
@Composable
private fun CrownTitle(
    progress: androidx.compose.animation.core.Animatable<Float, *>,
    str: com.momentum.focus.ui.i18n.Strings,
) {
    val t = progress.value
    // The title slams in after the lock breaks. Scale and tracking both
    // collapse inward, which is what makes it land rather than fade.
    val titleIn = ((t - 0.60f) / 0.18f).coerceIn(0f, 1f)
    val settle = 1f - (1f - titleIn) * (1f - titleIn)
    Column(
        Modifier.padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(150.dp))
        Text(
            str.crown.entered,
            fontSize = 34.sp,
            lineHeight = 40.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (0.60f - 0.42f * settle).em,
            textAlign = TextAlign.Center,
            color = GoldNeon.copy(alpha = titleIn),
            modifier = Modifier.graphicsLayer {
                scaleX = 2.2f - 1.2f * settle
                scaleY = 2.2f - 1.2f * settle
            },
        )
        Spacer(Modifier.height(14.dp))
        val subIn = ((t - 0.74f) / 0.16f).coerceIn(0f, 1f)
        Text(
            str.crown.subtitle,
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = Color.White.copy(alpha = 0.72f * subIn),
        )
        Spacer(Modifier.height(26.dp))
        // The hint arrives with the title rather than in the last second,
        // because the screen now sits here until it is dismissed and there
        // has to be something on it saying how.
        val hintIn = ((t - 0.78f) / 0.14f).coerceIn(0f, 1f)
        Text(
            str.crown.skip,
            style = MaterialTheme.typography.labelSmall,
            color = Color.White.copy(alpha = 0.60f * hintIn),
        )
    }
}

/**
 * The whole scene in one pass.
 *
 * Everything is derived from the playhead rather than held in state, so a
 * dropped frame skips ahead instead of falling behind — a cutscene that
 * stutters and then finishes late is worse than one that loses a frame.
 */
private fun DrawScope.drawScene(t: Float, shards: Int) {
    val centre = Offset(size.width / 2f, size.height * 0.42f)
    val unit = size.minDimension

    // 1. Night falls, warm at the middle so the gold has somewhere to sit.
    val dark = (t / 0.12f).coerceIn(0f, 1f)
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFF2A2411), Night),
            center = centre,
            radius = unit * 0.9f,
        ),
        alpha = dark,
    )

    // 2. A grid, the app's own paper lines, sliding in from the dark.
    val gridIn = ((t - 0.04f) / 0.16f).coerceIn(0f, 1f)
    if (gridIn > 0f) {
        val step = unit / 9f
        // In dp. This was 1.5f, and DrawScope units are pixels — on a
        // 2.75-density phone that is a half-dp line at nine percent alpha,
        // which is the grid beat drawing almost nothing. Everything else in
        // this scene is scaled off `unit`, so the grid was the only part that
        // got thinner as the screen got sharper.
        val hair = 1.dp.toPx()
        val ink = Ember.copy(alpha = 0.09f * gridIn)
        var x = 0f
        while (x < size.width) {
            drawLine(
                color = ink,
                start = Offset(x, 0f),
                end = Offset(x, size.height),
                strokeWidth = hair,
            )
            x += step
        }
        var y = 0f
        while (y < size.height) {
            drawLine(
                color = ink,
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = hair,
            )
            y += step
        }
    }

    val burst = ((t - 0.50f) / 0.08f).coerceIn(0f, 1f)

    // 3. The lock: drawn, then shaken, then gone.
    if (t < 0.58f) {
        val draw = ((t - 0.10f) / 0.22f).coerceIn(0f, 1f)
        val shake = ((t - 0.36f) / 0.14f).coerceIn(0f, 1f)
        // Jitter grows as it strains. sin of a fast phase, scaled by how far
        // into the strain we are, so it builds instead of buzzing evenly.
        val jitter = sin(t * 190f) * unit * 0.012f * shake
        val body = unit * 0.16f
        rotate(degrees = jitter * 12f, pivot = centre) {
            run {
                val left = centre.x - body + jitter
                val top = centre.y - body * 0.35f
                // Shackle.
                drawArc(
                    color = GoldNeon.copy(alpha = draw),
                    startAngle = 180f,
                    sweepAngle = 180f * draw,
                    useCenter = false,
                    topLeft = Offset(centre.x - body * 0.62f, top - body * 0.95f),
                    size = Size(body * 1.24f, body * 1.24f),
                    style = Stroke(width = unit * 0.026f),
                )
                // Body.
                drawRoundRect(
                    color = Ember.copy(alpha = 0.16f * draw),
                    topLeft = Offset(left, top),
                    size = Size(body * 2f, body * 1.5f),
                    cornerRadius = CornerRadius(unit * 0.03f, unit * 0.03f),
                )
                drawRoundRect(
                    color = GoldNeon.copy(alpha = draw),
                    topLeft = Offset(left, top),
                    size = Size(body * 2f, body * 1.5f),
                    cornerRadius = CornerRadius(unit * 0.03f, unit * 0.03f),
                    style = Stroke(width = unit * 0.022f),
                )
                // Cracks, spreading from the keyhole as the strain builds.
                if (shake > 0f) {
                    repeat(5) { i ->
                        val a = (i * 72f + 18f) * PI.toFloat() / 180f
                        val reach = body * 1.1f * shake
                        drawLine(
                            color = Color.White.copy(alpha = 0.8f * shake),
                            start = centre,
                            end = Offset(
                                centre.x + cos(a) * reach,
                                centre.y + sin(a) * reach * 0.8f,
                            ),
                            strokeWidth = unit * 0.008f,
                        )
                    }
                }
            }
        }
    }

    // 4. The break: white flash, shockwave, shards.
    if (burst > 0f) {
        val fade = 1f - burst
        drawRect(Color.White.copy(alpha = 0.55f * fade * fade))

        val wave = ((t - 0.50f) / 0.34f).coerceIn(0f, 1f)
        if (wave > 0f && wave < 1f) {
            drawCircle(
                color = GoldNeon.copy(alpha = (1f - wave) * 0.9f),
                radius = unit * 0.12f + unit * 0.85f * wave,
                center = centre,
                style = Stroke(width = unit * 0.02f * (1f - wave)),
            )
            drawCircle(
                color = Color.White.copy(alpha = (1f - wave) * 0.4f),
                radius = unit * 0.06f + unit * 0.62f * wave,
                center = centre,
                style = Stroke(width = unit * 0.01f * (1f - wave)),
            )
        }

        val fly = ((t - 0.50f) / 0.40f).coerceIn(0f, 1f)
        repeat(shards) { i ->
            // Golden angle, so the shards spread evenly without a random
            // source and look the same on every run.
            val a = i * 2.39996f
            val speed = 0.55f + ((i * 37) % 100) / 100f * 0.75f
            val dist = unit * 0.9f * fly * speed
            val px = centre.x + cos(a) * dist
            val py = centre.y + sin(a) * dist + unit * 0.55f * fly * fly
            val len = unit * (0.02f + ((i * 17) % 30) / 1000f)
            rotate(degrees = a * 57f + fly * 320f, pivot = Offset(px, py)) {
                drawRect(
                    color = GoldNeon.copy(alpha = (1f - fly) * 0.95f),
                    topLeft = Offset(px - len / 2f, py - len / 6f),
                    size = Size(len, len / 3f),
                )
            }
        }
    }

    // 5. Rays turning behind the title, and the crown itself.
    val rays = ((t - 0.56f) / 0.24f).coerceIn(0f, 1f)
    if (rays > 0f) {
        rotate(degrees = t * 90f, pivot = centre) {
            repeat(12) { i ->
                val a = i * 30f * PI.toFloat() / 180f
                val inner = unit * 0.18f
                val outer = inner + unit * 0.75f * rays
                drawLine(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            GoldNeon.copy(alpha = 0.30f * rays),
                            Color.Transparent,
                        ),
                        start = Offset(centre.x + cos(a) * inner, centre.y + sin(a) * inner),
                        end = Offset(centre.x + cos(a) * outer, centre.y + sin(a) * outer),
                    ),
                    start = Offset(centre.x + cos(a) * inner, centre.y + sin(a) * inner),
                    end = Offset(centre.x + cos(a) * outer, centre.y + sin(a) * outer),
                    strokeWidth = unit * 0.03f,
                )
            }
        }
        drawCrown(centre, unit * 0.20f, rays)
    }
}

/** Five points, drawn as one path so the outline stays a single stroke. */
private fun DrawScope.drawCrown(centre: Offset, w: Float, alpha: Float) {
    val h = w * 0.72f
    val left = centre.x - w
    val base = centre.y + h * 0.45f
    val top = centre.y - h * 0.55f
    val path = Path().apply {
        moveTo(left, base)
        lineTo(left, top + h * 0.30f)
        lineTo(left + w * 0.5f, top + h * 0.62f)
        lineTo(centre.x, top)
        lineTo(left + w * 1.5f, top + h * 0.62f)
        lineTo(left + w * 2f, top + h * 0.30f)
        lineTo(left + w * 2f, base)
        close()
    }
    drawPath(path, color = Ember.copy(alpha = 0.22f * alpha))
    drawPath(
        path,
        color = GoldNeon.copy(alpha = alpha),
        style = Stroke(width = w * 0.10f),
    )
}
