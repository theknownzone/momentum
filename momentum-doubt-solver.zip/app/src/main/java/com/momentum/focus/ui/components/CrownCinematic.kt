package com.momentum.focus.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.momentum.focus.data.FocusLevels
import com.momentum.focus.data.tr
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

private val Void = Color(0xFF05040A)
private val CGold = Color(0xFFFFC94A)
private val GoldDeep = Color(0xFFB07A12)
private val GoldPale = Color(0xFFFFF3C4)
private val Nebula1 = Color(0xFF3B1466)
private val Nebula2 = Color(0xFF7A1F5C)
private val ChromaR = Color(0xFFFF4D6D)
private val ChromaC = Color(0xFF4DE8FF)

private const val WARP_END = 2300f
private const val END = 7000f

/**
 * Crown Mode — the "you just crossed into another universe" cut.
 * Rebuilt 2026-10-07 (owner: the old one was kiddish — sticker labels,
 * "bro really turned on", AURA +929 — wants hyper-motion, top-level
 * graphics, premium sound). Everything is drawn live (no video asset), so
 * it is sharp at any resolution and costs nothing in APK size.
 *
 *   0.0–2.3s  WARP. Hyperspace: stars in 3D rush at the camera and stretch
 *             into streaks, accelerating; chromatic split at top speed, a
 *             gold core swells, the camera starts to shake. "ENTERING"
 *             whispers in, tracking wider.                      WARP (sound)
 *   2.3s      IMPACT. Gold-white flash, two shockwave rings.   IMPACT + haptic
 *   2.3–4.6s  REVEAL. Deep nebula, slow god-rays, gold dust in orbit. A
 *             metallic crown (gradient gold, moving specular band, three
 *             jewels) settles with a soft overshoot and sways like it is on
 *             a turntable. "CROWN MODE" in gold, tracking tightens from
 *             wide to set.                                       AURA
 *   4.3–5.4s  LOCK. Three status lines decode from noise to text:
 *             SHIELD ARMED · UNINSTALL SEALED · LOCK 3:00:00.    TICK ×3
 *   5.4s+     "Tap to continue". Auto-closes at 7s.
 *
 * Tap during the warp jumps to the impact; tap after it closes. Back
 * closes. LOW tier: 90 stars, no chromatic split, no god-rays, no shake.
 */
@Composable
fun CrownCinematic(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val haptics = rememberHaptics()
    val str = strings().crown
    val rich = remember { DeviceProfile.tier(ctx) != DeviceProfile.Tier.LOW }

    var t by remember { mutableFloatStateOf(0f) }
    var skip by remember { mutableFloatStateOf(0f) }
    var finished by remember { mutableStateOf(false) }
    fun finish() { if (!finished) { finished = true; onDone() } }

    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (!finished) {
            withFrameNanos { now -> t = (now - start) / 1_000_000f + skip }
            if (t >= END) break
        }
        finish()
    }
    BackHandler { finish() }

    // Sound + haptic beats, each fired once.
    val fired = remember { mutableSetOf<Int>() }
    SideEffect {
        fun beat(id: Int, at: Float, fn: () -> Unit) { if (t >= at && fired.add(id) && !finished) fn() }
        beat(0, 0f) { if (t < WARP_END - 200f) Sfx.playOnce(Sound.WARP) }
        // Heartbeat haptics that speed up with the warp.
        val pulses = floatArrayOf(400f, 900f, 1300f, 1600f, 1820f, 1980f, 2100f, 2190f)
        pulses.forEachIndexed { i, at -> beat(10 + i, at) { if (t < WARP_END) haptics.tick() } }
        beat(1, WARP_END) { Sfx.playOnce(Sound.IMPACT); haptics.unlock() }
        beat(2, WARP_END + 160f) { Sfx.playOnce(Sound.AURA) }
        for (k in 0 until 3) beat(20 + k, 4300f + k * 260f) { Sfx.playOnce(Sound.TICK, 1f + k * 0.08f) }
        beat(3, 5100f) { haptics.confirm() }
    }

    fun seg(a: Float, d: Float) = ((t - a) / d).coerceIn(0f, 1f)
    fun easeOut(x: Float) = 1f - (1f - x).pow(3)
    fun backOut(x: Float): Float { val c = 1.6f; val y = x - 1f; return 1f + (c + 1f) * y * y * y + c * y * y }

    val stars = remember(rich) { makeStars(if (rich) 220 else 90) }
    val dust = remember { makeDust(54) }

    Dialog(
        onDismissRequest = { finish() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        val warp = t < WARP_END
        val wp = (t / WARP_END).coerceIn(0f, 1f)
        val shake = if (rich && warp) wp.pow(4) * 6f else 0f
        Box(
            Modifier
                .fillMaxSize()
                .background(Void)
                .clickableNoRipple(remember { MutableInteractionSource() }) {
                    when {
                        t < 900f -> Unit
                        t < WARP_END -> skip += WARP_END - t
                        else -> finish()
                    }
                }
                .graphicsLayer {
                    val k = t / 1000f
                    translationX = sin(k * 61f) * shake.dp.toPx()
                    translationY = cos(k * 47f) * shake.dp.toPx() * 0.6f
                },
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) {
                if (warp) drawWarp(stars, t, wp, rich)
                else drawReveal(t, dust, rich, ::seg, ::easeOut, ::backOut)
                // Impact flash + shockwaves.
                val f = seg(WARP_END, 420f)
                if (t >= WARP_END && f < 1f) {
                    drawRect(GoldPale.copy(alpha = (1f - f).pow(2)))
                }
                for (r in 0 until 2) {
                    val p = seg(WARP_END + r * 140f, 900f)
                    if (t >= WARP_END && p in 0.001f..0.999f) {
                        drawCircle(
                            CGold.copy(alpha = (1f - p) * 0.7f),
                            radius = size.maxDimension * 0.75f * easeOut(p),
                            center = center,
                            style = Stroke(width = (1f - p) * 10.dp.toPx() + 1f),
                        )
                    }
                }
            }

            if (warp) {
                // Warp whisper.
                val a = seg(300f, 400f) * (1f - seg(1700f, 400f))
                Text(
                    tr("ENTERING", "प्रवेश"),
                    color = GoldPale.copy(alpha = a * 0.9f),
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (6f + 10f * wp).sp,
                    modifier = Modifier.offset(y = 120.dp),
                )
            } else {
                // Title block under the crown.
                Column(
                    Modifier.fillMaxWidth().offset(y = 96.dp).padding(horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    val title = easeOut(seg(WARP_END + 250f, 900f))
                    Text(
                        str.entered.uppercase(),
                        style = TextStyle(
                            brush = Brush.linearGradient(listOf(GoldDeep, GoldPale, CGold, GoldDeep)),
                            fontSize = 40.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = (4f + 16f * (1f - title)).sp,
                            textAlign = TextAlign.Center,
                        ),
                        modifier = Modifier.graphicsLayer { alpha = title },
                    )
                    Spacer(Modifier.height(8.dp))
                    // Hairline that draws out from the centre.
                    Box(
                        Modifier
                            .fillMaxWidth(0.55f * easeOut(seg(WARP_END + 700f, 600f)).coerceAtLeast(0.001f))
                            .height(1.dp)
                            .background(Brush.horizontalGradient(listOf(Color.Transparent, CGold, Color.Transparent))),
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        str.subtitle,
                        color = GoldPale.copy(alpha = 0.75f * seg(WARP_END + 900f, 500f)),
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(26.dp))
                    val lines = listOf(
                        tr("SHIELD", "शील्ड") to tr("ARMED", "चालू"),
                        tr("UNINSTALL", "अनइंस्टॉल") to tr("SEALED", "बंद"),
                        tr("LOCK", "लॉक") to "${FocusLevels.PACT_HOURS}:00:00",
                    )
                    lines.forEachIndexed { i, (k, v) ->
                        val p = seg(4300f + i * 260f, 380f)
                        if (p > 0f) {
                            Row(
                                Modifier.fillMaxWidth(0.72f).padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    decode(k, p, i),
                                    color = GoldPale.copy(alpha = 0.55f),
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 2.sp,
                                    modifier = Modifier.weight(1f),
                                )
                                Text(
                                    decode(v, p, i + 7),
                                    color = CGold,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 2.sp,
                                )
                            }
                        }
                    }
                }
            }
        }
        // Tap-to-continue hint, pinned to the bottom edge of the dialog.
        if (!warp) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                Text(
                    str.skip,
                    color = Color.White.copy(alpha = 0.40f * seg(5400f, 500f)),
                    fontSize = 12.sp,
                    letterSpacing = 1.sp,
                    modifier = Modifier.navigationBarsPadding().padding(bottom = 28.dp),
                )
            }
        }
    }
}

/* ───────────────────────── warp ───────────────────────── */

private class WarpStar(val x: Float, val y: Float, val z0: Float, val warm: Boolean)

private fun makeStars(n: Int): List<WarpStar> {
    val r = kotlin.random.Random(7)
    return List(n) {
        // Spread on a disc, a little denser away from dead centre.
        val a = r.nextFloat() * 2f * PI.toFloat()
        val d = 0.08f + r.nextFloat().pow(0.6f)
        WarpStar(cos(a) * d, sin(a) * d, r.nextFloat(), r.nextFloat() < 0.35f)
    }
}

/** Distance travelled by time t: a cruise, then a hard cubic acceleration. */
private fun travel(ms: Float): Float {
    val p = (ms / WARP_END).coerceIn(0f, 1f)
    return 0.12f * ms / 1000f + 2.6f * p.pow(3)
}

private fun DrawScope.drawWarp(stars: List<WarpStar>, t: Float, wp: Float, rich: Boolean) {
    val c = center
    val scale = size.minDimension * 0.5f
    val trav = travel(t)
    val speed = travel(t + 16f) - trav
    val tail = (0.012f + speed * 9f).coerceAtMost(0.35f)
    // Gold core swelling at the vanishing point.
    val coreR = scale * (0.25f + 1.1f * wp.pow(2))
    drawCircle(
        Brush.radialGradient(
            listOf(CGold.copy(alpha = 0.10f + 0.55f * wp.pow(2)), Color.Transparent),
            center = c, radius = coreR,
        ),
        radius = coreR, center = c,
    )
    val chroma = rich && wp > 0.55f
    val split = (wp - 0.55f).coerceAtLeast(0f) * 7.dp.toPx()
    stars.forEach { s ->
        val z = 1f - ((s.z0 + trav) % 1f)           // 1 = far, 0 = at the lens
        val zz = z.coerceAtLeast(0.02f)
        val zt = (z + tail).coerceAtMost(1.2f)
        val head = Offset(c.x + s.x / zz * scale * 0.18f, c.y + s.y / zz * scale * 0.18f)
        val back = Offset(c.x + s.x / zt * scale * 0.18f, c.y + s.y / zt * scale * 0.18f)
        val bright = (1f - z).coerceIn(0f, 1f)
        val col = if (s.warm) CGold else GoldPale
        val w = (0.6f + 2.4f * bright).dp.toPx()
        if (chroma) {
            val d = head - c
            val l = d.getDistance().coerceAtLeast(1f)
            val dir = Offset(d.x / l, d.y / l)
            drawLine(ChromaR.copy(alpha = 0.45f * bright), back + dir * split, head + dir * split, w, StrokeCap.Round)
            drawLine(ChromaC.copy(alpha = 0.45f * bright), back - dir * split, head - dir * split, w, StrokeCap.Round)
        }
        drawLine(col.copy(alpha = 0.25f + 0.75f * bright), back, head, w, StrokeCap.Round)
    }
}

/* ───────────────────────── reveal ───────────────────────── */

private class DustMote(val r: Float, val a: Float, val speed: Float, val size: Float)

private fun makeDust(n: Int): List<DustMote> {
    val r = kotlin.random.Random(19)
    return List(n) { DustMote(0.25f + r.nextFloat() * 0.75f, r.nextFloat() * 6.283f, 0.05f + r.nextFloat() * 0.18f, 0.6f + r.nextFloat() * 1.8f) }
}

private fun DrawScope.drawReveal(
    t: Float,
    dust: List<DustMote>,
    rich: Boolean,
    seg: (Float, Float) -> Float,
    easeOut: (Float) -> Float,
    backOut: (Float) -> Float,
) {
    val k = t / 1000f
    val c = Offset(center.x, center.y - size.height * 0.12f)
    // Nebula: three slow-drifting colour fields.
    drawRect(
        Brush.radialGradient(
            listOf(Nebula1.copy(alpha = 0.9f), Color.Transparent),
            center = Offset(size.width * (0.2f + 0.05f * sin(k * 0.3f)), size.height * 0.25f),
            radius = size.maxDimension * 0.7f,
        ),
    )
    drawRect(
        Brush.radialGradient(
            listOf(Nebula2.copy(alpha = 0.7f), Color.Transparent),
            center = Offset(size.width * (0.85f + 0.04f * cos(k * 0.25f)), size.height * 0.7f),
            radius = size.maxDimension * 0.6f,
        ),
    )
    drawRect(Brush.radialGradient(listOf(CGold.copy(alpha = 0.22f), Color.Transparent), center = c, radius = size.minDimension * 0.7f))

    // God-rays: one sweep gradient, slowly turning. Cheap and soft.
    if (rich) {
        val n = 14
        val stops = Array(n + 1) { i ->
            (i / n.toFloat()) to (if (i % 2 == 0) CGold.copy(alpha = 0.07f) else Color.Transparent)
        }
        rotate(k * 6f, c) {
            drawCircle(Brush.sweepGradient(*stops, center = c), radius = size.maxDimension, center = c)
        }
    }

    // Dust in orbit.
    dust.forEach { m ->
        val a = m.a + k * m.speed
        val rr = m.r * size.minDimension * 0.48f
        val p = Offset(c.x + cos(a) * rr, c.y + sin(a) * rr * 0.55f)
        val tw = 0.4f + 0.6f * (0.5f + 0.5f * sin(k * 3f + m.a * 5f))
        drawCircle(GoldPale.copy(alpha = 0.55f * tw), m.size.dp.toPx(), p)
    }

    // The crown.
    val enter = backOut(seg(WARP_END, 700f))
    val alpha = seg(WARP_END, 260f)
    val turn = 0.86f + 0.14f * cos(k * 1.3f)
    val bob = sin(k * 1.6f) * 5.dp.toPx()
    val w = size.minDimension * 0.46f
    withTransform({
        translate(c.x, c.y + bob)
        scale(enter * turn, enter, Offset.Zero)
    }) {
        drawCrown(w, k, alpha)
    }
}

private fun DrawScope.drawCrown(w: Float, k: Float, alpha: Float) {
    val h = w * 0.62f
    val left = -w / 2f
    val top = -h / 2f
    val band = h * 0.30f
    val body = Path().apply {
        moveTo(left, top + h)
        lineTo(left, top + h * 0.22f)
        lineTo(left + w * 0.22f, top + h * 0.55f)
        lineTo(left + w * 0.5f, top)
        lineTo(left + w * 0.78f, top + h * 0.55f)
        lineTo(left + w, top + h * 0.22f)
        lineTo(left + w, top + h)
        close()
    }
    // Under-glow.
    drawCircle(
        Brush.radialGradient(listOf(CGold.copy(alpha = 0.35f * alpha), Color.Transparent), center = Offset(0f, top + h * 0.6f), radius = w * 0.9f),
        radius = w * 0.9f, center = Offset(0f, top + h * 0.6f),
    )
    // Metal body.
    drawPath(
        body,
        Brush.linearGradient(
            listOf(GoldDeep, CGold, GoldPale, CGold, GoldDeep),
            start = Offset(left, top), end = Offset(left + w, top + h),
        ),
        alpha = alpha,
    )
    // Specular band that slides across the metal.
    val sx = left - w + (w * 3f) * ((k * 0.35f) % 1f)
    clipPath(body) {
        drawRect(
            Brush.linearGradient(
                listOf(Color.Transparent, Color.White.copy(alpha = 0.55f * alpha), Color.Transparent),
                start = Offset(sx, top), end = Offset(sx + w * 0.35f, top + h),
            ),
            topLeft = Offset(left, top), size = Size(w, h),
        )
        // Band across the bottom, a shade deeper.
        drawRect(GoldDeep.copy(alpha = 0.45f * alpha), topLeft = Offset(left, top + h - band), size = Size(w, band))
        drawLine(GoldPale.copy(alpha = 0.7f * alpha), Offset(left, top + h - band), Offset(left + w, top + h - band), 1.5.dp.toPx())
    }
    drawPath(body, GoldDeep.copy(alpha = alpha), style = Stroke(1.5.dp.toPx()))
    // Orbs on the three points.
    listOf(Offset(left, top + h * 0.22f), Offset(0f, top), Offset(left + w, top + h * 0.22f)).forEach { p ->
        val o = p - Offset(w * 0.012f, w * 0.012f)
        drawCircle(
            Brush.radialGradient(listOf(GoldPale, CGold, GoldDeep), center = o, radius = w * 0.06f),
            radius = w * 0.05f, center = p, alpha = alpha,
        )
    }
    // Jewels in the band, each with a glint that blinks in turn.
    val jewels = listOf(Color(0xFFE0245E), Color(0xFF2E7BFF), Color(0xFF1DB954))
    jewels.forEachIndexed { i, col ->
        val p = Offset(left + w * (0.25f + 0.25f * i), top + h - band / 2f)
        val r = band * 0.30f
        val dark = Color(col.red * 0.4f, col.green * 0.4f, col.blue * 0.4f)
        drawCircle(
            Brush.radialGradient(listOf(Color.White, col, dark), center = p - Offset(r * 0.3f, r * 0.3f), radius = r * 1.4f),
            radius = r, center = p, alpha = alpha,
        )
        val g = (0.5f + 0.5f * sin(k * 2.4f - i * 1.4f)).pow(6)
        if (g > 0.05f) {
            val s = r * 1.6f * g
            drawLine(Color.White.copy(alpha = g * alpha), p - Offset(s, 0f), p + Offset(s, 0f), 1.dp.toPx(), StrokeCap.Round)
            drawLine(Color.White.copy(alpha = g * alpha), p - Offset(0f, s), p + Offset(0f, s), 1.dp.toPx(), StrokeCap.Round)
        }
    }
}

/** Text that resolves from scrambled glyphs, left to right, as p goes 0 → 1. */
private fun decode(target: String, p: Float, seed: Int): String {
    if (p >= 1f) return target
    val glyphs = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789#%&*/"
    val done = (target.length * p).toInt()
    val tick = (p * 30f).toInt()
    return buildString {
        target.forEachIndexed { i, ch ->
            append(
                when {
                    i < done || ch == ' ' || ch == ':' -> ch
                    else -> glyphs[(i * 7 + tick * 13 + seed * 5) % glyphs.length]
                },
            )
        }
    }
}
