package com.momentum.focus.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.momentum.focus.data.FocusLevels
import com.momentum.focus.data.tr
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.util.CrownAudio
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.SystemVoice
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/* ─────────────────────────── cue sheet ───────────────────────────
 * Milliseconds on the score's clock. MUST match tools/crown_score.py:
 *   BEATS    heartbeat kicks      T_IMPACT  the hit (preceded by an 85 ms vacuum)
 *   T_VOICE  "Welcome to Crown Mode." starts: "Welcome to" ~0.14–0.8 s into
 *            the clip, "Crown" ~0.9 s, "Mode" ~1.25 s
 *   T_TICKS  one status line each      T_SEAL..T_LOCK  ring closes, then clank
 */
private const val T_IMPACT = 2600f
private const val T_VOICE = 2950f
private val T_TICKS = floatArrayOf(5000f, 5300f, 5600f)
private const val T_SEAL = 6000f
private const val T_LOCK = 6500f
private const val T_END = 9000f
private val BEATS = floatArrayOf(450f, 950f, 1380f, 1740f, 2040f, 2280f, 2440f, 2540f)

/** Visuals run this far behind the player's clock: MediaPlayer output latency. */
private const val AUDIO_LAT = 70f

private val CVoid = Color(0xFF05040A)
private val CGold = Color(0xFFFFC94A)
private val CGoldDeep = Color(0xFFB07A12)
private val CGoldPale = Color(0xFFFFF3C4)
private val CIce = Color(0xFF6FA8FF)
private val CViolet = Color(0xFF7A4DFF)
private val CNeb1 = Color(0xFF3B1466)
private val CNeb2 = Color(0xFF7A1F5C)
private val CCyan = Color(0xFF4DE8FF)
private val CMagenta = Color(0xFFFF4DA6)

private fun seg(t: Float, a: Float, d: Float) = ((t - a) / d).coerceIn(0f, 1f)
private fun ease3(x: Float) = 1f - (1f - x) * (1f - x) * (1f - x)
private fun smooth(x: Float) = x * x * (3f - 2f * x)
private fun backOut(x: Float): Float { val c = 1.5f; val y = x - 1f; return 1f + (c + 1f) * y * y * y + c * y * y }
private fun bump(t: Float, at: Float, d: Float) = sin(seg(t, at, d) * PI.toFloat())

/**
 * Crown Mode, third cut (2026-10-07). The owner: "no good animation, no sound
 * effects, no 'welcome to Crown Mode', looks like kids' animation".
 *
 * What was wrong, and what this does about it:
 *  - SILENCE. The cues were fired from a SideEffect that never re-ran per
 *    frame (the clock was read inside Dialog's own composition), so only the
 *    very first sound ever played; and Sfx is muted by the ringer switch. Now
 *    every cue fires from the frame loop, and the soundtrack is ONE pre-mixed
 *    file on the media stream (CrownAudio) — voice included.
 *  - NO VOICE. The recorded "Welcome to Crown Mode." line was dropped in the
 *    last rewrite. It is back, mixed into the score (reverb, thickened).
 *  - KIDDISH. Flat stickers, primary-colour jewels, comic type. Now: letter-
 *    boxed widescreen, a cold-to-gold hyperspace charge with a heartbeat, an
 *    85 ms vacuum, a hit that shakes and punches the frame, a regal crown
 *    (curved spires, bevel, pearls, ruby) that spins in 3D, serif lettering
 *    that slams in on the spoken words with a travelling shine, a HUD that
 *    decodes, and a gold ring that seals shut on the lock clank.
 *
 * Timeline (see cue sheet above): 0–2.6 charge · 2.6 impact · 2.95 voice ·
 * 5.0–5.6 status lines · 6.0–6.5 seal · 6.5 lock · 9.0 end (tap closes after
 * 4.1 s; Back closes any time). If the score fails to load, the old Sfx
 * sounds and the system voice stand in.
 * LOW tier: 90 stars, no rays/grain, fewer embers, no shake.
 */
@Composable
fun CrownCinematic(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val haptics = rememberHaptics()
    val str = strings().crown
    val rich = remember { DeviceProfile.tier(ctx) != DeviceProfile.Tier.LOW }
    val measurer = rememberTextMeasurer(cacheSize = 96)

    // t is read ONLY in draw / graphicsLayer lambdas below (and the frame
    // loop), so the cinematic redraws every frame with zero recompositions.
    var t by remember { mutableFloatStateOf(-1f) }
    var finished by remember { mutableStateOf(false) }

    fun finish() {
        if (finished) return
        finished = true
        CrownAudio.stopFaded()
        onDone()
    }
    DisposableEffect(Unit) { onDispose { CrownAudio.release() } }
    BackHandler { finish() }

    val subtitle = str.subtitle
    val hint = str.skip
    val voiceLine = str.voiceLine

    LaunchedEffect(Unit) {
        val ok = withContext(Dispatchers.IO) { CrownAudio.prepare(ctx) }
        if (!ok) SystemVoice.init(ctx)
        val fired = HashSet<Int>()
        fun beat(id: Int, at: Float, fn: () -> Unit) { if (t >= at && fired.add(id)) fn() }
        fun beats() {
            BEATS.forEachIndexed { i, at -> beat(10 + i, at) { haptics.tick() } }
            beat(1, T_IMPACT) { haptics.unlock() }
            T_TICKS.forEachIndexed { i, at -> beat(20 + i, at) { haptics.press() } }
            beat(2, T_LOCK) { haptics.celebrate() }
            if (!ok) {
                // Fallback soundtrack: the old synthesized cues + system voice.
                beat(30, 0f) { Sfx.playOnce(Sound.WARP) }
                beat(31, T_IMPACT) { Sfx.playOnce(Sound.IMPACT) }
                beat(32, T_IMPACT + 160f) { Sfx.playOnce(Sound.AURA) }
                beat(33, T_VOICE) { SystemVoice.say(voiceLine) }
            }
        }
        CrownAudio.start()
        val start = withFrameNanos { it }
        while (!finished) {
            withFrameNanos { now ->
                t = (now - start) / 1_000_000f - AUDIO_LAT
                if (t >= 0f) beats()
            }
            if (t >= T_END) break
        }
        finish()
    }

    val stars = remember(rich) { makeStars(if (rich) 260 else 90) }
    val embers = remember(rich) { makeEmbers(if (rich) 70 else 28) }

    Dialog(
        onDismissRequest = { finish() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .background(CVoid)
                .clickableNoRipple(remember { MutableInteractionSource() }) {
                    if (t > T_IMPACT + 1500f) finish()
                },
        ) {
            val crownW = minOf(maxWidth * 0.58f, maxHeight * 0.31f)
            val crownH = crownW * 0.82f
            val crownCyFrac = 0.30f
            // Read maxHeight HERE: inside the nested Box below, BoxScope's
            // layout-scope marker forbids the implicit outer receiver (CI
            // error at the old line 220).
            val crownTop = maxHeight * crownCyFrac - crownH / 2

            // The world: shakes and punches on the hit. Bars/grain stay put.
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val now = t
                        val k = now / 1000f
                        val wp = (now / T_IMPACT).coerceIn(0f, 1f)
                        val e = now - T_IMPACT
                        val punch = if (e in 0f..650f) (1f - e / 650f).pow(2) else 0f
                        val zoom = if (now < T_IMPACT) 1f + 0.035f * wp.pow(3) else 1f + 0.055f * punch
                        scaleX = zoom
                        scaleY = zoom
                        if (rich) {
                            val amp = if (now < T_IMPACT) wp.pow(4) * 5f else 11f * punch
                            translationX = sin(k * 61f) * amp.dp.toPx()
                            translationY = cos(k * 47f) * amp.dp.toPx() * 0.6f
                        }
                    },
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    backdrop(t, stars, embers, rich, size.height * crownCyFrac)
                }
                Canvas(
                    Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = crownTop)
                        .size(crownW, crownH)
                        .graphicsLayer {
                            val now = t
                            val k = now / 1000f
                            alpha = if (now < T_IMPACT) 0f else seg(now, T_IMPACT, 180f)
                            val enter = backOut(seg(now, T_IMPACT, 1000f))
                            val spin = (1f - ease3(seg(now, T_IMPACT, 1500f))) * 540f
                            val sway = 12f * sin(k * 0.9f) * seg(now, T_IMPACT + 1500f, 700f)
                            rotationY = spin + sway
                            rotationX = -5f + 3f * sin(k * 0.7f)
                            cameraDistance = 18f * density
                            val s = (0.5f + 0.5f * enter) * (1f + 0.05f * bump(now, T_LOCK, 380f))
                            scaleX = s
                            scaleY = s
                            translationY = sin(k * 1.6f) * 4.dp.toPx() * seg(now, T_IMPACT + 1000f, 500f)
                        },
                ) {
                    drawCrown(t / 1000f)
                }
                Canvas(Modifier.fillMaxSize()) {
                    drawTexts(t, measurer, size.height * crownCyFrac, crownW.toPx(), subtitle, hint)
                }
            }
            Canvas(Modifier.fillMaxSize()) { drawFilm(t, rich) }
        }
    }
}

/* ───────────────────────── backdrop ───────────────────────── */

private class WarpStar(val x: Float, val y: Float, val z0: Float, val warm: Boolean)

private fun makeStars(n: Int): List<WarpStar> {
    val r = kotlin.random.Random(7)
    return List(n) {
        val a = r.nextFloat() * 2f * PI.toFloat()
        val d = 0.08f + r.nextFloat().pow(0.6f)
        WarpStar(cos(a) * d, sin(a) * d, r.nextFloat(), r.nextFloat() < 0.35f)
    }
}

private class Ember(val x: Float, val speed: Float, val phase: Float, val size: Float, val sway: Float, val warm: Float)

private fun makeEmbers(n: Int): List<Ember> {
    val r = kotlin.random.Random(19)
    return List(n) { Ember(r.nextFloat(), 0.06f + r.nextFloat() * 0.16f, r.nextFloat(), 0.7f + r.nextFloat() * 1.9f, r.nextFloat() * 6.28f, r.nextFloat()) }
}

/** Distance travelled by time t: a cruise, then a hard cubic acceleration. */
private fun travel(ms: Float): Float {
    val p = (ms / T_IMPACT).coerceIn(0f, 1f)
    return 0.12f * ms / 1000f + 2.6f * p.pow(3)
}

private fun chargeTint(wp: Float): Color {
    val a = lerp(CIce, CViolet, smooth(seg(wp, 0f, 0.55f)))
    return lerp(a, CGold, smooth(seg(wp, 0.55f, 0.45f)))
}

private fun DrawScope.backdrop(t: Float, stars: List<WarpStar>, embers: List<Ember>, rich: Boolean, crownCy: Float) {
    if (t < 0f) return
    if (t < T_IMPACT) drawCharge(stars, t, rich) else drawReveal(t, embers, rich, crownCy)
}

private fun DrawScope.drawCharge(stars: List<WarpStar>, t: Float, rich: Boolean) {
    val wp = (t / T_IMPACT).coerceIn(0f, 1f)
    val c = center
    val scale = size.minDimension * 0.5f
    val tint = chargeTint(wp)
    val trav = travel(t)
    val speed = travel(t + 16f) - trav
    val tail = (0.012f + speed * 9f).coerceAtMost(0.35f)

    // Core glow at the vanishing point, cold → violet → gold.
    val coreR = scale * (0.25f + 1.2f * wp.pow(2))
    drawCircle(
        Brush.radialGradient(listOf(tint.copy(alpha = 0.12f + 0.55f * wp.pow(2)), Color.Transparent), center = c, radius = coreR),
        coreR, c,
    )
    // Tunnel rings rushing outward.
    for (i in 0 until 7) {
        val ph = ((i / 7f) + trav * 0.9f) % 1f
        val r = scale * 2.0f * ph.pow(2.2f)
        val a = sin(ph * PI.toFloat()) * (0.10f + 0.40f * wp)
        drawCircle(tint.copy(alpha = a), r, c, style = Stroke((1f + 3f * ph).dp.toPx()))
    }
    // Stars as 3D streaks, chromatic split near top speed.
    val chroma = rich && wp > 0.55f
    val split = (wp - 0.55f).coerceAtLeast(0f) * 7.dp.toPx()
    stars.forEach { s ->
        val z = 1f - ((s.z0 + trav) % 1f)
        val zz = z.coerceAtLeast(0.02f)
        val zt = (z + tail).coerceAtMost(1.2f)
        val head = Offset(c.x + s.x / zz * scale * 0.18f, c.y + s.y / zz * scale * 0.18f)
        val back = Offset(c.x + s.x / zt * scale * 0.18f, c.y + s.y / zt * scale * 0.18f)
        val bright = (1f - z).coerceIn(0f, 1f)
        val col = if (s.warm) lerp(tint, CGold, 0.5f) else lerp(tint, Color.White, 0.65f)
        val w = (0.6f + 2.4f * bright).dp.toPx()
        if (chroma) {
            val d = head - c
            val l = d.getDistance().coerceAtLeast(1f)
            val dir = Offset(d.x / l, d.y / l)
            drawLine(CMagenta.copy(alpha = 0.45f * bright), back + dir * split, head + dir * split, w, StrokeCap.Round)
            drawLine(CCyan.copy(alpha = 0.45f * bright), back - dir * split, head - dir * split, w, StrokeCap.Round)
        }
        drawLine(col.copy(alpha = 0.25f + 0.75f * bright), back, head, w, StrokeCap.Round)
    }
    // Heartbeat rings, one per kick of the score.
    BEATS.forEach { b ->
        val age = t - b
        if (age in 0f..520f) {
            val u = age / 520f
            drawCircle(
                CGold.copy(alpha = (1f - u) * 0.45f),
                scale * (0.12f + 0.95f * ease3(u)), c,
                style = Stroke(((1f - u) * 2.5f + 0.8f).dp.toPx()),
            )
        }
    }
    // Anamorphic streak growing across the frame, and the white-hot core.
    val fl = wp.pow(2.5f)
    if (fl > 0.02f) {
        withTransform({ scale(1f, 0.035f, c) }) {
            drawCircle(
                Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.65f * fl), tint.copy(alpha = 0.25f * fl), Color.Transparent),
                    center = c, radius = size.width * 0.8f,
                ),
                size.width * 0.8f, c,
            )
        }
    }
    drawCircle(Color.White.copy(alpha = 0.3f + 0.7f * wp), scale * 0.02f * (1f + 4f * wp.pow(3)), c)
}

private fun DrawScope.drawReveal(t: Float, embers: List<Ember>, rich: Boolean, cy: Float) {
    val k = t / 1000f
    val a = seg(t, T_IMPACT, 900f)
    val c = Offset(center.x, cy)
    // Nebula + warm core behind the crown.
    drawRect(
        Brush.radialGradient(
            listOf(CNeb1.copy(alpha = 0.9f * a), Color.Transparent),
            center = Offset(size.width * (0.2f + 0.05f * sin(k * 0.3f)), size.height * 0.25f),
            radius = size.maxDimension * 0.7f,
        ),
    )
    drawRect(
        Brush.radialGradient(
            listOf(CNeb2.copy(alpha = 0.7f * a), Color.Transparent),
            center = Offset(size.width * (0.85f + 0.04f * cos(k * 0.25f)), size.height * 0.7f),
            radius = size.maxDimension * 0.6f,
        ),
    )
    drawRect(Brush.radialGradient(listOf(CGold.copy(alpha = 0.30f * a), Color.Transparent), center = c, radius = size.minDimension * 0.8f))

    // God-rays: one soft sweep gradient, turning slowly.
    if (rich) {
        val n = 16
        val stops = Array(n + 1) { i ->
            (i / n.toFloat()) to (if (i % 2 == 0) CGold.copy(alpha = 0.10f) else Color.Transparent)
        }
        rotate(k * 5f, c) {
            drawCircle(
                Brush.sweepGradient(*stops, center = c),
                radius = size.maxDimension, center = c, alpha = seg(t, T_IMPACT + 200f, 1200f),
            )
        }
    }
    // Embers drifting up through the light.
    embers.forEach { m ->
        val ph = (m.phase + k * m.speed) % 1f
        val x = size.width * m.x + sin(k * 1.7f + m.sway) * size.width * 0.03f
        val y = size.height * (1.02f - ph * 1.1f)
        val flick = 0.55f + 0.45f * sin(k * 9f + m.sway * 3f)
        val al = sin(ph * PI.toFloat()) * flick * a
        val col = lerp(CGold, Color(0xFFFF8A3D), m.warm)
        val r = m.size.dp.toPx()
        drawCircle(col.copy(alpha = 0.85f * al), r, Offset(x, y))
        drawLine(col.copy(alpha = 0.35f * al), Offset(x, y), Offset(x - 1.dp.toPx(), y + r * 5f), r * 0.7f, StrokeCap.Round)
    }
    // Lens streak right after the hit.
    val sa = (1f - seg(t, T_IMPACT, 1300f)).pow(1.5f)
    if (t >= T_IMPACT && sa > 0.01f) {
        withTransform({ scale(1f, 0.03f, c) }) {
            drawCircle(
                Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.9f * sa), CGold.copy(alpha = 0.35f * sa), Color.Transparent),
                    center = c, radius = size.width,
                ),
                size.width, c,
            )
        }
    }
    // Two shockwaves, each with a chromatic ghost.
    for (r in 0 until 2) {
        val p = seg(t, T_IMPACT + r * 140f, 1000f)
        if (p in 0.001f..0.999f) {
            val rad = size.maxDimension * 0.8f * ease3(p)
            val w = ((1f - p) * 10f + 1f).dp.toPx()
            val off = (1f - p) * 7.dp.toPx()
            drawCircle(CMagenta.copy(alpha = (1f - p) * 0.35f), rad + off, c, style = Stroke(w))
            drawCircle(CCyan.copy(alpha = (1f - p) * 0.35f), rad - off, c, style = Stroke(w))
            drawCircle(CGold.copy(alpha = (1f - p) * 0.75f), rad, c, style = Stroke(w))
        }
    }
}

/* ───────────────────────── the crown ───────────────────────── */

private val TIPS = arrayOf(0.04f to 0.20f, 0.27f to 0.085f, 0.50f to 0.0f, 0.73f to 0.085f, 0.96f to 0.20f)
private val VALS = arrayOf(0.155f to 0.47f, 0.385f to 0.40f, 0.615f to 0.40f, 0.845f to 0.47f)

private fun crownPath(w: Float): Path = Path().apply {
    fun x(v: Float) = v * w
    moveTo(x(0.02f), x(0.74f))
    cubicTo(x(0.015f), x(0.55f), x(0.03f), x(0.35f), x(TIPS[0].first), x(TIPS[0].second))
    for (i in 0 until 4) {
        val (tx, ty) = TIPS[i]
        val (vx, vy) = VALS[i]
        val (nx, ny) = TIPS[i + 1]
        // down the spire into the valley (concave), then up the next one
        cubicTo(
            x(tx + (vx - tx) * 0.10f), x(ty + (vy - ty) * 0.55f),
            x(vx + (tx - vx) * 0.35f), x(vy),
            x(vx), x(vy),
        )
        cubicTo(
            x(vx + (nx - vx) * 0.35f), x(vy),
            x(nx + (vx - nx) * 0.10f), x(ny + (vy - ny) * 0.55f),
            x(nx), x(ny),
        )
    }
    cubicTo(x(0.97f), x(0.35f), x(0.985f), x(0.55f), x(0.98f), x(0.74f))
    cubicTo(x(0.70f), x(0.80f), x(0.30f), x(0.80f), x(0.02f), x(0.74f))
    close()
}

private fun DrawScope.sphere(c: Offset, r: Float, hi: Color, mid: Color, lo: Color) {
    drawCircle(
        Brush.radialGradient(listOf(hi, mid, lo), center = c + Offset(-0.3f * r, -0.35f * r), radius = r * 1.6f),
        r, c,
    )
}

/** A regal crown: curved spires, bevelled gold, a gem band, pearls, a ruby. */
private fun DrawScope.drawCrown(k: Float) {
    val w = size.width
    fun P(x: Float, y: Float) = Offset(x * w, y * w)
    val sil = crownPath(w)

    // Bevel: dark rim, then the bright body inset a hair.
    drawPath(sil, Color(0xFF6E4608))
    val pivot = P(0.5f, 0.42f)
    val body = Brush.verticalGradient(
        0f to CGoldPale, 0.25f to CGold, 0.55f to Color(0xFFBE8218), 0.80f to Color(0xFFFFD66E), 1f to Color(0xFF784E0A),
        startY = 0f, endY = w * 0.8f,
    )
    withTransform({ translate(0f, 0.006f * w); scale(0.962f, 0.955f, pivot) }) {
        drawPath(sil, body)
    }
    // Ridge down each spire.
    TIPS.forEach { (tx, ty) ->
        drawLine(CGoldPale.copy(alpha = 0.47f), P(tx, ty + 0.02f), P(tx, 0.60f), 0.005f * w)
        drawLine(Color(0xFF6E4608).copy(alpha = 0.43f), P(tx + 0.008f, ty + 0.02f), P(tx + 0.008f, 0.60f), 0.005f * w)
    }
    // A band of light travelling over the metal.
    val sx = -0.5f * w + 2.0f * w * ((k * 0.33f) % 1f)
    clipPath(sil) {
        drawRect(
            Brush.linearGradient(
                listOf(Color.Transparent, Color.White.copy(alpha = 0.50f), Color.Transparent),
                start = Offset(sx, 0f), end = Offset(sx + 0.30f * w, 0.5f * w),
            ),
            size = size,
        )
    }

    // Gem band.
    val band = Path().apply {
        moveTo(0.02f * w, 0.585f * w)
        lineTo(0.98f * w, 0.585f * w)
        lineTo(0.98f * w, 0.74f * w)
        cubicTo(0.70f * w, 0.80f * w, 0.30f * w, 0.80f * w, 0.02f * w, 0.74f * w)
        close()
    }
    drawPath(
        band,
        Brush.verticalGradient(
            0f to Color(0xFFFFE28C), 0.5f to Color(0xFFA87012), 1f to Color(0xFF5A3806),
            startY = 0.585f * w, endY = 0.80f * w,
        ),
    )
    drawLine(CGoldPale.copy(alpha = 0.9f), P(0.02f, 0.585f), P(0.98f, 0.585f), 0.006f * w)

    // Pearls along the band.
    for (i in 0 until 9) {
        val px = 0.10f + 0.80f * i / 8f
        if (abs(px - 0.5f) < 0.07f) continue
        val e = 1f - abs(px - 0.5f) * 2f
        val c = P(px, 0.68f + 0.035f * e * e)
        val r = 0.026f * w
        sphere(c, r, Color(0xFFFFFDF5), Color(0xFFD7D2C8), Color(0xFF8A857B))
        drawCircle(Color(0xFF785008).copy(alpha = 0.8f), r, c, style = Stroke(0.004f * w))
    }

    // The ruby.
    val rc = P(0.5f, 0.675f)
    val rw = 0.05f * w
    val rh = 0.062f * w
    val top = rc + Offset(0f, -rh)
    val right = rc + Offset(rw, 0f)
    val bot = rc + Offset(0f, rh)
    val left = rc + Offset(-rw, 0f)
    fun facet(a: Offset, b: Offset, c: Offset, col: Color) =
        drawPath(Path().apply { moveTo(a.x, a.y); lineTo(b.x, b.y); lineTo(c.x, c.y); close() }, col)
    drawCircle(Color(0xFFE0245E).copy(alpha = 0.22f), rw * 2.6f, rc)
    facet(top, right, rc, Color(0xFFEB3250))
    facet(top, rc, left, Color(0xFFC81838))
    facet(left, rc, bot, Color(0xFF6E061C))
    facet(rc, right, bot, Color(0xFF5A0416))
    drawPath(
        Path().apply { moveTo(top.x, top.y); lineTo(right.x, right.y); lineTo(bot.x, bot.y); lineTo(left.x, left.y); close() },
        CGoldPale, style = Stroke(0.006f * w),
    )
    val g = (0.5f + 0.5f * sin(k * 2.2f)).pow(8)
    if (g > 0.05f) {
        val s = rh * 1.1f * g
        drawLine(Color.White.copy(alpha = g), rc + Offset(-s, -rh * 0.3f), rc + Offset(s, -rh * 0.3f), 1.2.dp.toPx(), StrokeCap.Round)
        drawLine(Color.White.copy(alpha = g), rc + Offset(0f, -rh * 0.3f - s), rc + Offset(0f, -rh * 0.3f + s), 1.2.dp.toPx(), StrokeCap.Round)
    }

    // Orbs on the spire tips.
    TIPS.forEachIndexed { i, (tx, ty) ->
        val c = P(tx, ty - 0.012f)
        val r = 0.034f * w
        sphere(c, r, Color(0xFFFFF0B4), Color(0xFFD9A33A), Color(0xFF8A5A0A))
        drawCircle(Color(0xFF6E4608).copy(alpha = 0.85f), r, c, style = Stroke(0.004f * w))
        val gl = (0.5f + 0.5f * sin(k * 2.6f - i * 1.3f)).pow(10)
        if (gl > 0.06f) {
            val s = r * 1.6f * gl
            drawLine(Color.White.copy(alpha = gl), c - Offset(s, 0f), c + Offset(s, 0f), 1.dp.toPx(), StrokeCap.Round)
            drawLine(Color.White.copy(alpha = gl), c - Offset(0f, s), c + Offset(0f, s), 1.dp.toPx(), StrokeCap.Round)
        }
    }
}

/* ───────────────────────── type, HUD, seal ───────────────────────── */

private fun DrawScope.label(
    m: TextMeasurer, text: String, center: Offset, style: TextStyle, alpha: Float = 1f,
    maxWidth: Float = Float.NaN,
): TextLayoutResult {
    val lr = if (maxWidth.isNaN()) m.measure(text, style)
    else m.measure(text, style, constraints = Constraints(maxWidth = maxWidth.toInt()))
    if (alpha > 0.003f) {
        drawText(lr, topLeft = Offset(center.x - lr.size.width / 2f, center.y - lr.size.height / 2f), alpha = alpha)
    }
    return lr
}

/** Letters of [word] slam in one after another; a bright band sweeps along. */
private fun DrawScope.slamWord(
    m: TextMeasurer, word: String, cy: Float, style: TextStyle, spacing: Float,
    startAt: Float, stagger: Float, t: Float, shine: Float,
) {
    val lrs = word.map { m.measure(it.toString(), style) }
    val total = lrs.sumOf { it.size.width.toDouble() }.toFloat() + spacing * (word.length - 1)
    var x = center.x - total / 2f
    lrs.forEachIndexed { i, lr ->
        val p = seg(t, startAt + i * stagger, 240f)
        if (p > 0f) {
            val e = ease3(p)
            val tl = Offset(x, cy - lr.size.height / 2f - (1f - e) * size.height * 0.03f)
            val pv = Offset(x + lr.size.width / 2f, cy)
            val sc = 1f + 0.8f * (1f - e)
            withTransform({ scale(sc, sc, pv) }) {
                drawText(
                    lr,
                    brush = Brush.verticalGradient(listOf(CGoldPale, CGold, CGoldDeep), startY = 0f, endY = lr.size.height.toFloat()),
                    topLeft = tl, alpha = p,
                    shadow = Shadow(CGold.copy(alpha = 0.55f), Offset.Zero, 26f),
                )
                if (p >= 1f) {
                    drawText(
                        lr,
                        brush = Brush.linearGradient(
                            0f to Color.Transparent, 0.5f to Color.White.copy(alpha = 0.9f), 1f to Color.Transparent,
                            start = Offset(shine - x - size.width * 0.09f, 0f),
                            end = Offset(shine - x + size.width * 0.09f, lr.size.height * 0.4f),
                        ),
                        topLeft = tl,
                    )
                }
            }
        }
        x += lr.size.width + spacing
    }
}

private const val GLYPHS = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789#%&*/"

/** Text that resolves from scrambled glyphs, left to right, as p goes 0 → 1. */
private fun decode(target: String, p: Float, seed: Int): String {
    if (p >= 1f) return target
    val done = (target.length * p).toInt()
    val tick = (p * 30f).toInt()
    return buildString {
        target.forEachIndexed { i, ch ->
            append(if (i < done || ch == ' ' || ch == ':') ch else GLYPHS[(i * 7 + tick * 13 + seed * 5) % GLYPHS.length])
        }
    }
}

private fun DrawScope.drawTexts(
    t: Float, m: TextMeasurer, crownCy: Float, crownW: Float, subtitle: String, hint: String,
) {
    if (t < 0f) return
    val W = size.width
    val H = size.height
    val cx = W / 2f
    val k = t / 1000f

    // ── charge HUD ──
    if (t < T_IMPACT) {
        val a = seg(t, 500f, 500f) * (1f - seg(t, T_IMPACT - 160f, 120f))
        val pct = ((t / T_IMPACT).coerceIn(0f, 1f).pow(1.6f) * 100f).toInt()
        val st = TextStyle(
            color = CGoldPale, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
            fontSize = (W * 0.031f).toSp(), letterSpacing = (W * 0.008f).toSp(),
        )
        label(m, tr("SEALING THE PHONE", "फ़ोन सील हो रहा है") + "  " + pct.toString().padStart(3, '0') + "%", Offset(cx, H * 0.855f), st, a)
        val bw = W * 0.5f
        val by = H * 0.885f
        drawLine(CGoldPale.copy(alpha = 0.18f * a), Offset(cx - bw / 2f, by), Offset(cx + bw / 2f, by), 1.dp.toPx())
        drawLine(CGold.copy(alpha = 0.9f * a), Offset(cx - bw / 2f, by), Offset(cx - bw / 2f + bw * pct / 100f, by), 1.5.dp.toPx())
        return
    }

    // ── title ──
    val a1 = seg(t, T_VOICE + 100f, 450f)
    label(
        m, tr("WELCOME TO", "स्वागत है"), Offset(cx, H * 0.468f - (1f - a1) * H * 0.012f),
        TextStyle(
            color = CGoldPale.copy(alpha = 0.85f), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
            fontSize = (W * 0.034f).toSp(), letterSpacing = (W * 0.014f).toSp(),
        ),
        a1,
    )
    val shine = (((t - 4700f) / 2400f) % 1f) * W * 1.7f - W * 0.35f
    val big = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = (W * 0.158f).toSp())
    slamWord(m, "CROWN", H * 0.535f, big, W * 0.022f, T_VOICE + 900f, 45f, t, shine)
    val small = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Medium, fontSize = (W * 0.064f).toSp())
    slamWord(m, "MODE", H * 0.610f, small, W * 0.05f, T_VOICE + 1250f, 55f, t, shine)
    val hl = ease3(seg(t, T_VOICE + 1500f, 600f))
    drawLine(
        Brush.horizontalGradient(listOf(Color.Transparent, CGold, Color.Transparent), startX = cx - W * 0.3f, endX = cx + W * 0.3f),
        Offset(cx - W * 0.3f * hl, H * 0.652f), Offset(cx + W * 0.3f * hl, H * 0.652f), 1.dp.toPx(),
    )

    // ── status rows, decoding on each tick of the score ──
    val rows = listOf(
        tr("SHIELD", "शील्ड") to tr("ARMED", "चालू"),
        tr("UNINSTALL", "अनइंस्टॉल") to tr("SEALED", "बंद"),
        tr("LOCK", "लॉक") to "${FocusLevels.PACT_HOURS}:00:00",
    )
    val rs = TextStyle(color = CGoldPale.copy(alpha = 0.6f), fontFamily = FontFamily.Monospace, fontSize = (W * 0.032f).toSp(), letterSpacing = (W * 0.006f).toSp())
    val vs = TextStyle(color = CGold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = (W * 0.032f).toSp(), letterSpacing = (W * 0.006f).toSp())
    rows.forEachIndexed { i, (lab, value) ->
        val p = seg(t, T_TICKS[i], 380f)
        val a = seg(t, T_TICKS[i] - 60f, 160f)
        if (a <= 0f) return@forEachIndexed
        val y = H * 0.700f + i * W * 0.078f
        val l = m.measure(decode(lab, p, i), rs)
        val v = m.measure(decode(value, p, i + 7), vs)
        val x0 = W * 0.15f
        val x1 = W * 0.85f
        drawRect(CGold.copy(alpha = a), Offset(x0 - W * 0.04f, y - W * 0.008f), Size(W * 0.016f, W * 0.016f))
        drawText(l, topLeft = Offset(x0, y - l.size.height / 2f), alpha = a)
        drawText(v, topLeft = Offset(x1 - v.size.width, y - v.size.height / 2f), alpha = a)
        val ly = y + l.size.height * 0.62f
        drawLine(CGoldPale.copy(alpha = 0.20f * a), Offset(x0, ly), Offset(x0 + (x1 - x0) * p, ly), 0.8.dp.toPx())
    }

    // ── seal ring: sweeps shut, then the lock lands ──
    val c = Offset(cx, crownCy)
    val ringR = crownW * 0.74f
    val sweep = 360f * smooth(seg(t, T_SEAL, 520f))
    if (sweep > 0.5f) {
        val tl = c - Offset(ringR, ringR)
        val sz = Size(ringR * 2f, ringR * 2f)
        for (g in 3 downTo 1) {
            drawArc(CGold.copy(alpha = 0.10f), -90f, sweep, false, tl, sz, style = Stroke((g * 3f + 2f).dp.toPx(), cap = StrokeCap.Round))
        }
        drawArc(CGoldPale, -90f, sweep, false, tl, sz, style = Stroke(1.6.dp.toPx(), cap = StrokeCap.Round))
        if (t < T_LOCK) {
            val ang = ((-90f + sweep) * PI / 180.0).toFloat()
            val tip = c + Offset(cos(ang), sin(ang)) * ringR
            drawCircle(
                Brush.radialGradient(listOf(Color.White, CGold.copy(alpha = 0.4f), Color.Transparent), center = tip, radius = 14.dp.toPx()),
                14.dp.toPx(), tip,
            )
        }
    }
    if (t >= T_LOCK) {
        val la = seg(t, T_LOCK, 160f)
        for (q in 0 until 4) {
            val ang = (q * 90f - 90f) * PI.toFloat() / 180f
            val d = Offset(cos(ang), sin(ang))
            drawLine(CGoldPale.copy(alpha = la), c + d * (ringR * 0.92f), c + d * (ringR * 1.10f), 2.dp.toPx(), StrokeCap.Round)
        }
        val ra = seg(t, T_LOCK + 100f, 600f)
        rotate(k * 14f, c) {
            drawCircle(
                CGold.copy(alpha = 0.40f * ra), ringR * 1.10f, c,
                style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 10.dp.toPx()))),
            )
        }
        // Sparks bursting off the ring.
        val age = (t - T_LOCK) / 950f
        if (age in 0f..1f) {
            for (i in 0 until 28) {
                val ang = (i * 2f * PI / 28.0).toFloat() + (i % 3) * 0.07f
                val sp = 0.55f + (i * 37 % 10) / 22f
                val d = Offset(cos(ang), sin(ang))
                val p0 = c + d * (ringR + age * ringR * 0.95f * sp)
                drawLine(CGold.copy(alpha = 1f - age), p0, p0 - d * (7.dp.toPx() * (1f - age)), 1.6.dp.toPx(), StrokeCap.Round)
            }
        }
        // The line that lands once it is locked.
        val sa = seg(t, T_LOCK + 450f, 500f)
        label(
            m, subtitle, Offset(cx, H * 0.820f),
            TextStyle(color = CGoldPale.copy(alpha = 0.85f), fontSize = (W * 0.036f).toSp()), sa, maxWidth = W * 0.84f,
        )
        val ha = seg(t, T_LOCK + 1200f, 400f) * (0.45f + 0.35f * sin(k * 3f))
        label(
            m, hint, Offset(cx, H * 0.885f),
            TextStyle(color = Color.White.copy(alpha = 0.6f), fontSize = (W * 0.030f).toSp(), letterSpacing = (W * 0.004f).toSp()), ha,
        )
    }
}

/* ───────────────────────── film layer ───────────────────────── */

private fun DrawScope.drawFilm(t: Float, rich: Boolean) {
    if (t < 0f) {
        drawRect(CVoid)
        return
    }
    // The 85 ms vacuum before the hit — the score drops out at the same time.
    if (t >= T_IMPACT - 85f && t < T_IMPACT) drawRect(Color.Black.copy(alpha = 0.9f))
    // The flash.
    val f = seg(t, T_IMPACT, 480f)
    if (t >= T_IMPACT && f < 1f) drawRect(CGoldPale.copy(alpha = (1f - f).pow(2) * 0.95f))
    val lf = seg(t, T_LOCK, 260f)
    if (t >= T_LOCK && lf < 1f) drawRect(Color.White.copy(alpha = (1f - lf) * 0.30f))
    // Heartbeat: the vignette breathes with each kick.
    var beat = 0f
    BEATS.forEach { b -> val age = t - b; if (age in 0f..260f) beat = maxOf(beat, 1f - age / 260f) }
    drawRect(
        Brush.radialGradient(
            listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f + 0.18f * beat)),
            center = center, radius = size.maxDimension * 0.75f,
        ),
    )
    // Film grain.
    if (rich) {
        val r = kotlin.random.Random((t / 42f).toInt())
        val s = 1.4.dp.toPx()
        for (i in 0 until 36) {
            drawRect(Color.White.copy(alpha = 0.05f), Offset(r.nextFloat() * size.width, r.nextFloat() * size.height), Size(s, s))
        }
    }
    // Letterbox.
    val bar = size.height * 0.07f * ease3(seg(t, 0f, 800f))
    drawRect(Color.Black, Offset.Zero, Size(size.width, bar))
    drawRect(Color.Black, Offset(0f, size.height - bar), Size(size.width, bar))
}
