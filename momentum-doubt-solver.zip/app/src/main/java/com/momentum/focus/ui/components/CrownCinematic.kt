package com.momentum.focus.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.momentum.focus.data.FocusLevels
import com.momentum.focus.data.tr
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Crown Mode — v3 "THE HYPE EDIT".
 *
 * Owner: v2 (vault door) was boring; wants dopamine + brainrot, nothing like
 * the old styles, and the "Welcome to Crown Mode" voice back.
 *
 * So it's cut like a 4-second TikTok edit — hard cuts, zoom punches, flash
 * frames, RGB-split type, meme captions — but in ink/gold, not cartoon:
 *
 *  SHOT 1  0.00–0.55  black, tiny typewriter: "bro really turned on"   TICK per word
 *  SHOT 2  0.55–1.55  WHITE FLASH → "CROWN MODE" zoom-punch, RGB split,
 *                     speed lines, crown slams; AURA counter rolls to
 *                     +1000                                            BOOM, TICK roll
 *  SHOT 3  1.55–2.45  hard cut to halftone gold; three stamps slam in
 *                     L/R/L: PHONE SEALED · UNINSTALL LOCKED · EXCUSES
 *                     DELETED                                          CRACK ×3 + shake
 *  SHOT 4  2.45–3.55  "LOCKED IN" squeezes in, glow, "for 3 hours";
 *                     voice: "Welcome to Crown Mode."                  RISER→LEVEL + TTS
 *  OUT     2.45–4.35 (holds for the voice)  slice-glitch to black                             WHOOSH
 *
 * One clock drives picture, sound, haptics and the voice. Tap after 1.2 s or
 * Back to skip. Tier: LOW drops RGB split, slice glitch and half the lines.
 */
private val Gold = Color(0xFFFFC94A)
private val GoldPale = Color(0xFFFFF0B8)
private val Hot = Color(0xFFFF3B6B)
private val Cyan = Color(0xFF39E6FF)
private val InkBlack = Color(0xFF0B0B0D)

/** Owner: v3 was "bahut fast". Everything runs 1.6× slower (one knob). */
private const val SLOW = 1.6f
private const val END = 4750f

@Composable
fun CrownCinematic(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val haptics = rememberHaptics()
    val str = strings().crown
    val tier = remember { DeviceProfile.tier(ctx) }
    val rich = tier != DeviceProfile.Tier.LOW

    var t by remember { mutableFloatStateOf(0f) }
    var finished by remember { mutableStateOf(false) }
    fun finish() { if (!finished) { finished = true; onDone() } }

    // Voice: the original recorded clip ("Welcome to Crown Mode", res/raw),
    // pre-loaded — not robot TTS. Plays unless the phone is on silent.
    LaunchedEffect(Unit) { com.momentum.focus.ui.util.SystemVoice.init(ctx) }

    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (t < END && !finished) withFrameNanos { now -> t = (now - start) / 1_000_000f / SLOW }
        finish()
    }
    BackHandler { finish() }

    val fired = remember { mutableSetOf<Int>() }
    SideEffect {
        fun beat(id: Int, at: Float, fn: () -> Unit) { if (t >= at && fired.add(id) && !finished) fn() }
        for (k in 0 until 4) beat(100 + k, 60f + k * 110f) { Sfx.play(Sound.TICK) }
        beat(1, 550f) { Sfx.play(Sound.BOOM); haptics.unlock() }
        for (k in 0 until 8) beat(200 + k, 900f + k * 60f) { Sfx.play(Sound.TICK); if (k % 2 == 0) haptics.tick() }
        beat(2, 1450f) { Sfx.play(Sound.SHIMMER) }
        for (k in 0 until 3) beat(300 + k, 1600f + k * 260f) { Sfx.play(Sound.CRACK); haptics.confirm() }
        beat(3, 2350f) { Sfx.play(Sound.RISER) }
        beat(4, 2480f) { Sfx.play(Sound.LEVEL); haptics.celebrate() }
        beat(5, 2560f) { com.momentum.focus.ui.util.SystemVoice.say(str.voiceLine) }
        beat(6, 4350f) { Sfx.play(Sound.WHOOSH) }
    }

    fun seg(a: Float, d: Float) = ((t - a) / d).coerceIn(0f, 1f)
    fun out3(x: Float) = 1f - (1f - x) * (1f - x) * (1f - x)
    /** Zoom punch: overshoots big then snaps back. */
    fun punch(x: Float) = if (x <= 0f) 0f else 1f + 0.9f * (1f - x) * (1f - x) * cos(x * 9f)
    fun jitter(x: Float, amp: Float) = if (x in 0.001f..0.999f) sin(x * PI.toFloat() * 8f) * (1f - x) * amp else 0f

    val shot = when {
        t < 550f -> 1
        t < 1550f -> 2
        t < 2450f -> 3
        else -> 4
    }
    val flash = (1f - seg(550f, 160f)).let { if (t >= 550f) it else 0f } +
                (1f - seg(1550f, 90f)).let { if (t >= 1550f) it * 0.7f else 0f } +
                (1f - seg(2450f, 120f)).let { if (t >= 2450f) it * 0.8f else 0f }
    val outGlitch = seg(4350f, 400f)
    val stampAt = floatArrayOf(1600f, 1860f, 2120f)
    val shake = jitter(seg(550f, 380f), 18f) + stampAt.fold(0f) { acc, a -> acc + jitter(seg(a, 220f), 10f) } + jitter(seg(2480f, 300f), 8f)
    val sh = if (rich) shake else shake * 0.4f

    Dialog(
        onDismissRequest = { finish() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(InkBlack)
                .clickableNoRipple(remember { MutableInteractionSource() }) { if (t > 1200f) finish() }
                .graphicsLayer { translationX = sh.dp.toPx(); translationY = (sh * 0.5f).dp.toPx() },
            contentAlignment = Alignment.Center,
        ) {
            // ── backgrounds per shot
            Canvas(Modifier.fillMaxSize()) {
                val c = Offset(size.width / 2f, size.height * 0.45f)
                when (shot) {
                    2 -> {
                        // speed lines rushing out from the centre
                        val n = if (rich) 36 else 18
                        val p = seg(550f, 1000f)
                        for (i in 0 until n) {
                            val a = (i * 360f / n + (i % 3) * 4f) * PI.toFloat() / 180f
                            val r0 = size.minDimension * (0.18f + ((p * 1.7f + i * 0.13f) % 1f) * 0.6f)
                            val r1 = r0 + size.minDimension * 0.22f
                            drawLine(
                                Gold.copy(alpha = 0.35f),
                                c + Offset(cos(a) * r0, sin(a) * r0), c + Offset(cos(a) * r1, sin(a) * r1),
                                strokeWidth = (if (i % 4 == 0) 4f else 2f).dp.toPx(),
                            )
                        }
                    }
                    3 -> {
                        // halftone gold field, drifting
                        drawRect(Brush.verticalGradient(listOf(Color(0xFF2A1B00), Color(0xFF120C00))))
                        val step = 22.dp.toPx()
                        val drift = seg(1550f, 900f) * step
                        var y = -step
                        var row = 0
                        while (y < size.height + step) {
                            var x = if (row % 2 == 0) 0f else step / 2f
                            while (x < size.width + step) {
                                val k = (y / size.height).coerceIn(0f, 1f)
                                drawCircle(Gold.copy(alpha = 0.10f + 0.12f * k), (2.5f + 3.5f * k).dp.toPx(), Offset(x - drift, y + drift * 0.5f))
                                x += step
                            }
                            y += step; row++
                        }
                    }
                    4 -> {
                        val g = seg(2450f, 900f)
                        drawCircle(
                            Brush.radialGradient(listOf(Gold.copy(alpha = 0.45f * (0.6f + 0.4f * g)), Color.Transparent), center = c, radius = size.minDimension * 0.75f),
                            radius = size.minDimension * 0.75f, center = c,
                        )
                        // rotating sunburst rays, slow
                        val rays = if (rich) 16 else 8
                        for (i in 0 until rays) {
                            val a = (i * 360f / rays + g * 40f) * PI.toFloat() / 180f
                            drawLine(Gold.copy(alpha = 0.10f), c, c + Offset(cos(a), sin(a)) * size.maxDimension, strokeWidth = 26.dp.toPx())
                        }
                    }
                }
            }

            // ── foreground per shot
            when (shot) {
                1 -> {
                    val words = tr("bro really turned on", "भाई ने सच में चालू किया").split(" ")
                    val shown = (t / 110f).toInt().coerceIn(0, words.size)
                    Text(
                        words.take(shown).joinToString(" "),
                        fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.8f),
                    )
                }
                2 -> {
                    val p = seg(550f, 520f)
                    val z = punch(p)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Canvas(Modifier.size(width = 120.dp, height = 90.dp).graphicsLayer {
                            val s = punch(seg(700f, 500f)); scaleX = s; scaleY = s; rotationZ = (1f - seg(700f, 400f)) * -25f
                            alpha = if (t < 700f) 0f else 1f
                        }) { crownGlyph(1f, 3.dp.toPx()) }
                        Spacer(Modifier.height(10.dp))
                        RgbText(str.entered.uppercase(), 46.sp, Gold, rich, Modifier.graphicsLayer { scaleX = z; scaleY = z })
                        Spacer(Modifier.height(12.dp))
                        val aura = (out3(seg(900f, 500f)) * 1000).toInt()
                        Box(
                            Modifier
                                .graphicsLayer { alpha = if (t >= 900f) 1f else 0f; rotationZ = -3f }
                                .clip(RoundedCornerShape(8.dp))
                                .background(Hot)
                                .padding(horizontal = 14.dp, vertical = 4.dp)
                        ) {
                            Text("AURA +$aura", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                        }
                    }
                }
                3 -> {
                    val lines = listOf(
                        tr("PHONE: SEALED", "फ़ोन: सील"),
                        tr("UNINSTALL: LOCKED", "अनइंस्टॉल: लॉक"),
                        tr("EXCUSES: DELETED", "बहाने: डिलीट"),
                    )
                    val fills = listOf(Gold, Color.White, Hot)
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
                        lines.forEachIndexed { i, l ->
                            val q = seg(stampAt[i], 160f)
                            val fromLeft = i % 2 == 0
                            Box(
                                Modifier
                                    .graphicsLayer {
                                        alpha = if (q > 0f) 1f else 0f
                                        val s = punch(q).coerceAtLeast(0.01f); scaleX = s; scaleY = s
                                        translationX = (1f - out3(q)) * (if (fromLeft) -300f else 300f)
                                        rotationZ = if (fromLeft) -4f else 3f
                                    }
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(InkBlack)
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                Text(l, fontSize = 28.sp, fontWeight = FontWeight.Black, color = fills[i])
                            }
                        }
                    }
                }
                else -> {
                    val q = out3(seg(2450f, 420f))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        RgbText(
                            tr("LOCKED IN", "लॉक्ड इन"), 54.sp, GoldPale, rich,
                            Modifier.graphicsLayer { val s = 1.6f - 0.6f * q; scaleX = s; scaleY = s; alpha = q },
                            letterSpacing = (18f - 16f * q).sp,
                        )
                        Spacer(Modifier.height(10.dp))
                        val sub = out3(seg(2750f, 380f))
                        Text(
                            tr("for ${FocusLevels.PACT_HOURS} hours. no cap.", "${FocusLevels.PACT_HOURS} घंटे। पक्का।"),
                            fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.graphicsLayer { alpha = sub; translationY = (1f - sub) * 14.dp.toPx() },
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            str.subtitle, fontSize = 14.sp, color = Gold.copy(alpha = 0.7f * sub), textAlign = TextAlign.Center,
                        )
                    }
                }
            }

            // ── flash frames
            if (flash > 0.01f) Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = flash.coerceIn(0f, 1f))))

            // ── slice-glitch out
            if (outGlitch > 0f) {
                Canvas(Modifier.fillMaxSize()) {
                    val slices = if (rich) 14 else 6
                    val h = size.height / slices
                    for (i in 0 until slices) {
                        val dir = if (i % 2 == 0) 1f else -1f
                        val off = dir * size.width * out3((outGlitch * 1.4f - (i % 5) * 0.08f).coerceIn(0f, 1f))
                        drawRect(InkBlack, Offset(off, i * h), Size(size.width, h + 1f))
                        if (rich && i % 3 == 0) drawRect(Hot.copy(alpha = 0.25f * (1f - outGlitch)), Offset(off + 8f, i * h), Size(size.width, 3f))
                    }
                }
            }

            if (t > 1200f && outGlitch == 0f) {
                Text(
                    str.skip, fontSize = 12.sp, color = Color.White.copy(alpha = 0.35f),
                    modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 28.dp),
                )
            }
        }
    }
}

/** Big type with an RGB split (two offset ghosts) — the edit's signature. */
@Composable
private fun RgbText(
    text: String,
    size: TextUnit,
    color: Color,
    rich: Boolean,
    modifier: Modifier = Modifier,
    letterSpacing: TextUnit = 0.sp,
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        if (rich) {
            Text(text, fontSize = size, fontWeight = FontWeight.Black, color = Hot.copy(alpha = 0.7f), letterSpacing = letterSpacing, softWrap = false, maxLines = 1,
                modifier = Modifier.graphicsLayer { translationX = -4.dp.toPx(); translationY = 1.dp.toPx() })
            Text(text, fontSize = size, fontWeight = FontWeight.Black, color = Cyan.copy(alpha = 0.7f), letterSpacing = letterSpacing, softWrap = false, maxLines = 1,
                modifier = Modifier.graphicsLayer { translationX = 4.dp.toPx(); translationY = -1.dp.toPx() })
        }
        Text(text, fontSize = size, fontWeight = FontWeight.Black, color = color, letterSpacing = letterSpacing, softWrap = false, maxLines = 1)
    }
}
