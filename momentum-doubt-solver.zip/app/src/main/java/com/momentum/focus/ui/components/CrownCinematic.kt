package com.momentum.focus.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.FocusLevels
import com.momentum.focus.data.tr
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Crown Mode — "THE VAULT SEALS" (v2, rebuilt from scratch; the old
 * lock-opening intro read childish to the owner).
 *
 * The idea: Crown isn't unlocking anything — it's sealing YOU in with your
 * work. So the phone becomes a bank vault door closing:
 *
 *   0.00 s  cut to black, a gold scan line sweeps down          WHOOSH
 *   0.35 s  a round vault door swings in, rim light traces       RISER
 *   1.10 s  the door LANDS — screen shake, shockwave, dust       BOOM + heavy haptic
 *   1.30 s  twelve bolts shoot inward, in pairs, 70 ms apart     TICK ×6 + tick haptics
 *   1.85 s  the crown emblem on the door flashes gold            SHIMMER
 *   2.15 s  "CROWN ON" — letters drop in one by one              CRACK on the last letter
 *   3.60 s  iris closes to a point and the app is back           (done)
 *
 * One clock drives picture, sound and haptics together, so they can't drift.
 * Tap to skip after 1.2 s; Back skips. Device tier scales the expensive
 * bits: LOW = no shake, 6 dust specks; HIGH = full dust and a second ring.
 */
private val Gold = Color(0xFFE8C26B)
private val GoldPale = Color(0xFFFFE9B0)
private val GoldDeep = Color(0xFF9C6F22)
private val Steel = Color(0xFF2B2D31)
private val SteelHi = Color(0xFF4A4E55)

private const val END = 3950f

@Composable
fun CrownCinematic(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val haptics = rememberHaptics()
    val tier = remember { DeviceProfile.tier(ctx) }
    var t by remember { mutableFloatStateOf(0f) }
    var finished by remember { mutableStateOf(false) }
    fun finish() { if (!finished) { finished = true; onDone() } }

    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (t < END && !finished) withFrameNanos { now -> t = (now - start) / 1_000_000f }
        finish()
    }
    BackHandler { finish() }

    // ── beats: sound + haptic on the picture's clock
    val fired = remember { mutableSetOf<Int>() }
    SideEffect {
        fun beat(id: Int, at: Float, fn: () -> Unit) { if (t >= at && fired.add(id) && !finished) fn() }
        beat(0, 0f) { Sfx.play(Sound.WHOOSH) }
        beat(1, 350f) { Sfx.play(Sound.RISER) }
        beat(2, 1100f) { Sfx.play(Sound.BOOM); haptics.unlock() }
        for (k in 0 until 6) beat(10 + k, 1300f + k * 70f) { Sfx.play(Sound.TICK); haptics.tick() }
        beat(3, 1850f) { Sfx.play(Sound.SHIMMER) }
        beat(4, 2150f + 7 * 45f) { Sfx.play(Sound.CRACK); haptics.confirm() }
    }

    fun seg(a: Float, d: Float) = ((t - a) / d).coerceIn(0f, 1f)
    fun easeOut(x: Float) = 1f - (1f - x) * (1f - x) * (1f - x)
    fun back(x: Float) = 1f + 2.4f * (x - 1f).let { it * it * it } + 1.4f * (x - 1f).let { it * it }

    val scan = seg(0f, 420f)
    val swing = seg(350f, 750f)                 // door swings in
    val land = seg(1100f, 380f)                 // impact
    val bolts = FloatArray(6) { k -> easeOut(seg(1300f + k * 70f, 160f)) }
    val flash = seg(1850f, 520f)
    val iris = seg(3600f, 350f)
    val shake = if (tier == DeviceProfile.Tier.LOW) 0f
                else if (land in 0.001f..0.999f) sin(land * PI.toFloat() * 7f) * (1f - land) * 14f else 0f
    val dustN = when (tier) { DeviceProfile.Tier.HIGH -> 26; DeviceProfile.Tier.MID -> 14; else -> 6 }
    val dustA = remember(dustN) { FloatArray(dustN) { (it * 360f / dustN) + (it % 4) * 9f } }

    // Own full-screen window: covers the app tab bar and system bars too.
    androidx.compose.ui.window.Dialog(
        onDismissRequest = { finish() },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickableNoRipple(remember { MutableInteractionSource() }) { if (t > 1200f) finish() },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize().graphicsLayer { translationX = shake.dp.toPx(); translationY = (shake * 0.4f).dp.toPx() }) {
            val c = Offset(size.width / 2f, size.height * 0.42f)
            val R = size.minDimension * 0.34f

            // Gold scan line.
            if (scan in 0.001f..0.999f) {
                val y = size.height * scan
                drawRect(
                    Brush.verticalGradient(listOf(Color.Transparent, Gold.copy(alpha = 0.55f), Color.Transparent), startY = y - 60f, endY = y + 60f),
                    topLeft = Offset(0f, y - 60f), size = Size(size.width, 120f),
                )
            }

            // Iris-out mask region is handled by drawing a shrinking clear circle last.
            val doorScale = if (swing <= 0f) 0f else (0.55f + 0.45f * back(swing)).coerceAtMost(1.06f) - 0.04f * land * (1f - land) * 4f
            if (doorScale > 0f) {
                val angle = (1f - easeOut(swing)) * -38f
                rotate(angle, c) {
                    val r = R * doorScale
                    // Door body: brushed steel disc with concentric rings.
                    drawCircle(Brush.radialGradient(listOf(SteelHi, Steel, Color(0xFF16171A)), center = c, radius = r), r, c)
                    for (k in 1..3) drawCircle(Color.White.copy(alpha = 0.06f), r * (1f - k * 0.18f), c, style = Stroke(2.dp.toPx()))
                    // Rim light traces around while swinging in.
                    val sweep = 360f * easeOut(swing)
                    drawArc(
                        Brush.sweepGradient(listOf(Gold.copy(alpha = 0f), GoldPale, Gold.copy(alpha = 0f)), center = c),
                        startAngle = -90f, sweepAngle = sweep, useCenter = false,
                        topLeft = Offset(c.x - r, c.y - r), size = Size(r * 2, r * 2), style = Stroke(5.dp.toPx()),
                    )
                    drawCircle(GoldDeep, r, c, style = Stroke(2.dp.toPx()))
                    // Bolts: 12 around the rim, shooting INWARD in 6 pairs.
                    for (i in 0 until 12) {
                        val a = Math.toRadians(i * 30.0 - 90.0)
                        val p = bolts[i % 6]
                        val outR = r * 1.18f - p * r * 0.22f
                        val dir = Offset(cos(a).toFloat(), sin(a).toFloat())
                        val tip = c + dir * outR
                        val tail = c + dir * (outR + r * 0.16f)
                        drawLine(if (p >= 1f) Gold else SteelHi, tip, tail, 9.dp.toPx() * doorScale, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                        if (p in 0.85f..1f) drawCircle(GoldPale.copy(alpha = (1f - p) * 6f), 8.dp.toPx(), tip)
                    }
                    // Crown emblem in the middle, flashing gold.
                    val em = r * 0.62f
                    translate(c.x - em / 2f, c.y - em * 0.42f) {
                        val w = em; val h = em * 0.76f
                        val path = Path().apply {
                            moveTo(w * 0.08f, h * 0.78f); lineTo(w * 0.04f, h * 0.30f); lineTo(w * 0.28f, h * 0.52f)
                            lineTo(w * 0.50f, h * 0.14f); lineTo(w * 0.72f, h * 0.52f); lineTo(w * 0.96f, h * 0.30f)
                            lineTo(w * 0.92f, h * 0.78f); close()
                        }
                        val lit = 0.35f + 0.65f * flash
                        drawPath(path, Brush.verticalGradient(listOf(GoldPale, Gold, GoldDeep), endY = h), alpha = lit)
                        drawRect(Gold.copy(alpha = lit), Offset(w * 0.08f, h * 0.82f), Size(w * 0.84f, h * 0.12f))
                        if (flash in 0.001f..0.999f) {
                            val x = w * (flash * 1.6f - 0.3f)
                            drawRect(
                                Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.8f), Color.Transparent), start = Offset(x - 40f, 0f), end = Offset(x + 40f, h)),
                                size = Size(w, h),
                            )
                        }
                    }
                }
            }

            // Impact: shockwave(s) + dust.
            if (land > 0f) {
                val rings = if (tier == DeviceProfile.Tier.HIGH) listOf(0f, 0.2f) else listOf(0f)
                rings.forEach { lag ->
                    val q = ((land - lag) / (1f - lag)).coerceIn(0f, 1f)
                    if (q > 0f && q < 1f) drawCircle(Gold.copy(alpha = (1f - q) * 0.7f), R * (1.05f + q * 0.9f), c, style = Stroke((1f - q) * 8.dp.toPx() + 1f))
                }
                val d = seg(1100f, 900f)
                dustA.forEach { a ->
                    val rad = Math.toRadians(a.toDouble())
                    val dist = R * (1.1f + d * 0.8f)
                    val p = c + Offset(cos(rad).toFloat(), sin(rad).toFloat()) * dist
                    drawCircle(GoldPale.copy(alpha = (1f - d) * 0.8f), (1f - d) * 3.dp.toPx() + 0.5f, p)
                }
            }

            // Iris-out: black closes in from the edges to a point.
            if (iris > 0f) {
                val maxR = size.maxDimension
                drawCircle(Color.Black, maxR, c, style = Stroke(maxR * 2f * easeOut(iris)))
            }
        }

        // Title: letters drop in one by one.
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 140.dp).graphicsLayer { alpha = 1f - iris },
        ) {
            val word = tr("CROWN ON", "क्राउन ऑन")
            Row {
                word.forEachIndexed { i, ch ->
                    val q = easeOut(seg(2150f + i * 45f, 260f))
                    Text(
                        ch.toString(),
                        fontSize = 40.sp, fontWeight = FontWeight.Black, color = Gold,
                        modifier = Modifier.graphicsLayer { alpha = q; translationY = (1f - q) * -40.dp.toPx(); scaleX = 1.4f - 0.4f * q; scaleY = scaleX },
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            val sub = easeOut(seg(2700f, 400f))
            Text(
                tr("Sealed for ${FocusLevels.PACT_HOURS} hours. Uninstall is locked.", "${FocusLevels.PACT_HOURS} घंटे के लिए सील। अनइंस्टॉल लॉक।"),
                fontSize = 15.sp, color = GoldPale.copy(alpha = 0.85f),
                modifier = Modifier.graphicsLayer { alpha = sub; translationY = (1f - sub) * 10.dp.toPx() },
            )
        }
    }
}
}
