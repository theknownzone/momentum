package com.momentum.focus.ui.util

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import androidx.core.content.getSystemService

/**
 * Cheap phones keep the same features. They drop petals, festival bitmaps
 * and long splash so 4 GB / Helio devices stay usable.
 */
object DeviceProfile {

    /**
     * Worked out once. This was being called straight from composables and
     * from the petal renderer, so a system service lookup and a MemoryInfo
     * allocation ran on every recomposition and every frame — on precisely
     * the cheap phones the check exists to protect. The answer cannot change
     * while the process is alive, so it is settled once and kept.
     */
    @Volatile private var cached: Boolean? = null

    fun isLowEnd(context: Context): Boolean =
        cached ?: compute(context).also { cached = it }

    /**
     * Whether continuous background animation is worth its cost here.
     *
     * The flag existed and was honoured in exactly two places — the hero
     * weather and the splash — so a 3 GB phone was still running an infinite
     * gradient in the tab bar, a halftone field redrawn per frame, and a
     * ten-second cutscene of forty-four shards. The check was there; almost
     * nothing asked it.
     *
     * Named for what it decides rather than for the hardware, so call sites
     * read as a decision about the effect instead of a guess about the phone.
     */
    fun wantsAmbientMotion(context: Context): Boolean = !isLowEnd(context)

    /**
     * How many particles an effect should draw, from the count it would like.
     *
     * A third on a cheap phone. Halving was tried and is not enough: the cost
     * is the per-particle draw call, and these effects run every frame for as
     * long as the screen is up.
     */
    fun particles(context: Context, wanted: Int): Int =
        if (isLowEnd(context)) (wanted / 3).coerceAtLeast(6) else wanted

    private fun compute(context: Context): Boolean {
        val am = context.getSystemService<ActivityManager>() ?: return Build.VERSION.SDK_INT < 29
        if (am.isLowRamDevice) return true
        val mem = runCatching { ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) } }.getOrNull()
        val totalBytes = mem?.totalMem ?: 0L
        // A "4 GB" phone reports about 3.7 GB, so the cut is made in bytes
        // rather than on a truncated integer count of gigabytes.
        val fourGb = 4L * 1024L * 1024L * 1024L
        if (totalBytes in 1 until fourGb) return true
        return Build.VERSION.SDK_INT < 29
    }

    // ── Tiers (owner idea): HIGH = everything, MID = signature motion only,
    // LOW = 2–4 key animations. Hardware decides the starting tier; the jank
    // watcher (JankWatch) can demote it at runtime if frames actually drop,
    // so a "good on paper" phone that stutters still gets the lighter set.

    enum class Tier { LOW, MID, HIGH }

    @Volatile private var tierCached: Tier? = null
    @Volatile var demoted: Tier? = null

    fun tier(context: Context): Tier {
        demoted?.let { return it }
        return tierCached ?: computeTier(context).also { tierCached = it }
    }

    private fun computeTier(context: Context): Tier {
        if (isLowEnd(context)) return Tier.LOW
        val am = context.getSystemService<ActivityManager>() ?: return Tier.MID
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val gb = mi.totalMem / (1024f * 1024f * 1024f)
        val cores = Runtime.getRuntime().availableProcessors()
        val hz = runCatching {
            @Suppress("DEPRECATION")
            (context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay.refreshRate
        }.getOrDefault(60f)
        return when {
            gb >= 7.5f && cores >= 8 && Build.VERSION.SDK_INT >= 31 -> Tier.HIGH
            gb >= 5.5f && hz >= 89f && Build.VERSION.SDK_INT >= 30 -> Tier.HIGH
            else -> Tier.MID
        }
    }
}

/**
 * Runtime demotion: counts slow frames for the first ~20 s of a screen; if
 * more than 12% miss (> 25 ms), the tier drops one step for this process.
 * Choreographer callbacks only while measuring, then it stops — no ongoing cost.
 */
object JankWatch {
    @Volatile private var started = false
    fun start(context: Context) {
        if (started) return
        started = true
        val ch = android.view.Choreographer.getInstance()
        var last = 0L; var frames = 0; var slow = 0
        val begin = System.nanoTime()
        val cb = object : android.view.Choreographer.FrameCallback {
            override fun doFrame(now: Long) {
                if (last != 0L) {
                    frames++
                    if (now - last > 25_000_000L) slow++
                }
                last = now
                if (now - begin < 20_000_000_000L) ch.postFrameCallback(this)
                else if (frames > 120 && slow * 100 / frames > 12) {
                    val t = DeviceProfile.tier(context)
                    DeviceProfile.demoted = if (t == DeviceProfile.Tier.HIGH) DeviceProfile.Tier.MID else DeviceProfile.Tier.LOW
                }
            }
        }
        ch.postFrameCallback(cb)
    }
}
