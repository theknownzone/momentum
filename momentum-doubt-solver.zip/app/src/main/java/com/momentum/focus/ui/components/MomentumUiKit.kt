package com.momentum.focus.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.util.rememberHaptics

private val Cyan = Color(0xFF00F3FF)
private val Violet = Color(0xFF8B5CF6)
private val Pink = Color(0xFFFF2E93)
private val Mint = Color(0xFF00FFAA)
private val Panel = Color(0xFF10121B)
private val Panel2 = Color(0xFF171A26)

@Composable
fun MomentumGlowCard(
    modifier: Modifier = Modifier,
    accent: Color = Cyan,
    title: String,
    subtitle: String? = null,
    icon: @Composable (() -> Unit)? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit = {},
) {
    val haptics = rememberHaptics()
    val transition = rememberInfiniteTransition(label = "glow")
    val pulse by transition.animateFloat(
        0.55f, 1f,
        infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val pressScale by animateFloatAsState(if (pressed && onClick != null) 0.985f else 1f, spring(stiffness = Spring.StiffnessMediumLow), label = "cardPress")
    val pressY by animateDpAsState(if (pressed && onClick != null) 2.dp else 0.dp, spring(stiffness = Spring.StiffnessMediumLow), label = "cardLift")
    val interaction = if (onClick != null) Modifier.clickable(
        interactionSource = source, indication = null
    ) { haptics.tap(); onClick() } else Modifier
    Column(
        interaction
            .fillMaxWidth()
            .graphicsLayer { scaleX = pressScale; scaleY = pressScale; translationY = pressY.toPx() }
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(Panel, Panel2)))
            .border(1.dp, accent.copy(alpha = 0.28f * pulse), RoundedCornerShape(22.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Box(Modifier.size(38.dp).clip(CircleShape).background(accent.copy(alpha = .10f)), Alignment.Center) { icon() }
                Spacer(Modifier.width(10.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                if (subtitle != null) Text(subtitle, color = Color.White.copy(.58f), fontSize = 12.sp)
            }
        }
        content()
    }
}

@Composable
fun MomentumPixelToggle(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val haptics = rememberHaptics()
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val pressScale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(stiffness = Spring.StiffnessMediumLow), label = "togglePress")
    val x by animateDpAsState(if (checked) 44.dp else 2.dp, spring(stiffness = Spring.StiffnessMediumLow), label = "thumb")
    val color by animateColorAsState(if (checked) Mint else Pink, tween(260), label = "toggleColor")
    Row(
        modifier.size(width = 82.dp, height = 42.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF0B0D12))
            .border(1.5.dp, color.copy(alpha = .55f), RoundedCornerShape(24.dp))
            .clickable(interactionSource = source, indication = null) { haptics.tap(); onCheckedChange(!checked) }
            .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
            .padding(2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.offset(x).size(34.dp).clip(CircleShape).background(color).border(2.dp, Color(0xFF151821), CircleShape)) {
            Icon(if (checked) Icons.Default.Check else Icons.Default.Lock, null, tint = Color(0xFF11131A), modifier = Modifier.padding(8.dp))
        }
    }
}

@Composable
fun MomentumCyberInfo(
    title: String,
    body: String,
    modifier: Modifier = Modifier,
) {
    var open by remember { mutableStateOf(false) }
    val haptics = rememberHaptics()
    Column(modifier) {
        Row(
            Modifier.clip(RoundedCornerShape(12.dp))
                .background(Color.Transparent)
                .border(1.dp, Cyan.copy(.45f), RoundedCornerShape(12.dp))
                .clickable { haptics.tap(); open = !open }
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Default.Info, null, tint = Cyan, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(7.dp))
            Text(title, color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        if (open) {
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Color(0xFF141A2B), Color(0xFF171225)))).border(1.dp, Violet.copy(.35f), RoundedCornerShape(14.dp)).padding(12.dp)) {
                Text(body, color = Color.White.copy(.72f), fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
    }
}

@Composable
fun MomentumOrb(modifier: Modifier = Modifier, accent: Color = Cyan, size: androidx.compose.ui.unit.Dp = 72.dp) {
    val transition = rememberInfiniteTransition(label = "orb")
    val rotation by transition.animateFloat(0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "rotation")
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f
            drawCircle(Brush.radialGradient(listOf(Color.White.copy(.9f), accent.copy(.7f), Violet.copy(.28f), Color.Transparent)), r * .72f)
            drawArc(accent.copy(.75f), rotation, 120f, false, style = Stroke(width = 2.dp.toPx()))
            drawArc(Pink.copy(.45f), rotation + 180f, 90f, false, style = Stroke(width = 1.5.dp.toPx()))
        }
        Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(size * .30f))
    }
}

@Composable
fun MomentumGradientButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed && enabled) 0.97f else 1f, spring(stiffness = Spring.StiffnessMediumLow), label = "buttonPress")
    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(15.dp))
            .background(if (enabled) Brush.horizontalGradient(listOf(Cyan, Violet, Pink)) else Brush.horizontalGradient(listOf(Color.Gray, Color.DarkGray)))
            .clickable(enabled = enabled, interactionSource = source, indication = null) { haptics.tap(); onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (enabled) Color(0xFF07080D) else Color.White.copy(.55f), fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = 0.6.sp)
    }
}

@Composable
fun MomentumUiStrip(
    mode: MomentumUiMode,
    modifier: Modifier = Modifier,
    checked: Boolean = false,
    onToggle: ((Boolean) -> Unit)? = null,
    onAction: (() -> Unit)? = null,
) {
    var localToggle by remember { mutableStateOf(checked) }
    val toggle = checked
    fun setToggle(value: Boolean) {
        localToggle = value
        onToggle?.invoke(value)
    }
    when (mode) {
        MomentumUiMode.PREMIUM -> {
            Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                NeonPlanCard(onAction)
                BrutalPricingCard(onAction)
                MomentumCyberInfo("Premium details", "Premium benefits, activation and pricing live here. Existing purchase action is preserved.")
                IndigoTooltip()
            }
        }
        MomentumUiMode.FOCUS -> {
            var monsterOn by remember { mutableStateOf(toggle) }
            var verticalOn by remember { mutableStateOf(toggle) }
            Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    MonsterToggle(monsterOn) { monsterOn = !monsterOn; setToggle(monsterOn) }
                    VerticalModeToggle(verticalOn) { verticalOn = !verticalOn; setToggle(verticalOn) }
                    Column(Modifier.weight(1f)) { Text("FOCUS SHIELD", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp); Text("Mechanical + vertical controls", color = Color.White.copy(.55f), fontSize = 10.sp) }
                }
                MomentumPixelToggle(toggle, ::setToggle)
            }
        }
        MomentumUiMode.AI -> {
            Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                BlobGlassCard()
                CyberInput("Ask a doubt…")
                AnimatedInput("Type your question")
                CyberTooltip()
                BranchTooltip()
                IndigoTooltip()
                if (onAction != null) MomentumGradientButton("OPEN AI", Modifier.fillMaxWidth(), onClick = onAction)
            }
        }
        MomentumUiMode.SETTINGS -> {
            Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MomentumGlowCard(Modifier, Violet, "CONTROL CENTER", "Haptics + sound + interaction feel", { MomentumOrb(accent = Violet, size = 38.dp) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Sound effects", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("UI sounds for focus and completion", color = Color.White.copy(.5f), fontSize = 10.sp)
                        }
                        MomentumPixelToggle(toggle, ::setToggle)
                    }
                }
                CyberSettingsInfo()
            }
        }
        MomentumUiMode.STATS -> {
            Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MomentumGlowCard(Modifier, Mint, "MOMENTUM DATA", "Depth + progress", { MomentumOrb(accent = Mint, size = 38.dp) }) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("FOCUS" to "84%", "TIME" to "12h", "STREAK" to "7d").forEach { (a,b) ->
                            Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(.045f)).padding(10.dp)) {
                                Text(a, color = Color.White.copy(.45f), fontSize = 9.sp, fontWeight = FontWeight.Bold); Text(b, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                ComicAchievementCard()
            }
        }
        MomentumUiMode.HOME -> {
            Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MomentumGlowCard(Modifier, Cyan, "TODAY", "One-tap momentum surface", { MomentumOrb(accent = Cyan, size = 38.dp) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Start a focused session", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        if (onAction != null) MomentumGradientButton("GO", onClick = onAction)
                    }
                }
                LayeredWeatherCard()
                PixelSunnyCard()
            }
        }
    }
}

enum class MomentumUiMode { HOME, FOCUS, PREMIUM, AI, STATS, SETTINGS }

@Composable
private fun UiPressable(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val haptics = rememberHaptics()
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed && onClick != null) .97f else 1f, spring(stiffness = Spring.StiffnessMediumLow), label = "uiPress")
    Box(
        modifier.graphicsLayer { scaleX = scale; scaleY = scale; translationY = if (pressed && onClick != null) 2.dp.toPx() else 0f }
            .then(if (onClick != null) Modifier.clickable(source, null) { haptics.tap(); onClick() } else Modifier),
        content = content
    )
}

@Composable
private fun NeonPlanCard(onClick: (() -> Unit)? = null) {
    val transition = rememberInfiniteTransition(label = "plan-edge")
    val sweep by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "plan-sweep")
    UiPressable(Modifier.fillMaxWidth(), onClick) {
        Column(Modifier.clip(RoundedCornerShape(22.dp)).background(Brush.radialGradient(listOf(Color(0xFF173B43), Panel, Color(0xFF080A11)))).border(1.5.dp, Cyan.copy(.32f + .25f * sweep), RoundedCornerShape(22.dp)).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("PREMIUM STACK", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
                    Text("Unlock your focus stack", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                }
                MomentumOrb(accent = Cyan, size = 48.dp)
            }
            Spacer(Modifier.height(5.dp))
            Text("Neon depth • push feedback • premium controls", color = Color.White.copy(.58f), fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            if (onClick != null) MomentumGradientButton("UPGRADE  →", Modifier.fillMaxWidth(), onClick = onClick)
        }
    }
}

@Composable
private fun BrutalPricingCard(onClick: (() -> Unit)? = null) {
    UiPressable(Modifier.fillMaxWidth(), onClick) {
        Column(Modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF00FFA0)).border(2.dp, Color(0xFF05060F), RoundedCornerShape(16.dp)).padding(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("MOMENTUM PRO+", color = Color(0xFF05060F), fontSize = 13.sp, fontWeight = FontWeight.Black)
                    Text("ALL-IN FOCUS", color = Color(0xFF05060F), fontSize = 22.sp, fontWeight = FontWeight.Black)
                }
                Text("↗", color = Color(0xFF05060F), fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Text("AI • Shield • Advanced stats • Premium themes", color = Color(0xFF05060F).copy(.78f), fontSize = 11.sp)
        }
    }
}

@Composable
private fun LayeredWeatherCard() {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xFFF4F5F7)).padding(14.dp)) {
        Text("TODAY", color = Color.Black.copy(.5f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("72°", color = Color.Black, fontSize = 34.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.width(12.dp))
            Column { Text("FOCUS WEATHER", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text("Clear mind • low distraction", color = Color.Black.copy(.55f), fontSize = 10.sp) }
        }
    }
}

@Composable
private fun BlobGlassCard() {
    Box(Modifier.fillMaxWidth().height(118.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF0C1020)).border(1.dp, Cyan.copy(.25f), RoundedCornerShape(20.dp))) {
        val t = rememberInfiniteTransition(label = "blob")
        val x by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "blobX")
        Canvas(Modifier.fillMaxSize()) { drawCircle(Brush.radialGradient(listOf(Cyan.copy(.42f), Violet.copy(.18f), Color.Transparent)), size.minDimension * .62f, Offset(size.width * (.2f + .55f * x), size.height * .45f)) }
        Column(Modifier.padding(15.dp)) { Text("AI STATE", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Black); Text("Thinking surface", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Glass + moving blob depth", color = Color.White.copy(.55f), fontSize = 11.sp) }
    }
}

@Composable
private fun PixelSunnyCard() {
    Box(Modifier.fillMaxWidth().height(125.dp).clip(RoundedCornerShape(22.dp)).background(Brush.verticalGradient(listOf(Color(0xFFFFB347), Color(0xFFFF8C42))))) {
        Canvas(Modifier.fillMaxSize()) { drawCircle(Color.White.copy(.9f), 25.dp.toPx(), Offset(size.width - 45.dp.toPx(), 36.dp.toPx())); drawCircle(Color.White.copy(.15f), 52.dp.toPx(), Offset(size.width - 45.dp.toPx(), 36.dp.toPx())) }
        Column(Modifier.padding(15.dp)) { Text("MOMENTUM WEATHER", color = Color.White.copy(.8f), fontSize = 9.sp, fontWeight = FontWeight.Black); Text("HIGH FOCUS", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black); Text("Best window: now", color = Color.White.copy(.82f), fontSize = 11.sp) }
    }
}

@Composable
private fun ComicAchievementCard() {
    val haptics = rememberHaptics()
    UiPressable(Modifier.fillMaxWidth(), onClick = { haptics.confirm() }) {
        Column(Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFFFEFAE8)).border(2.dp, Color(0xFF212121), RoundedCornerShape(10.dp)).padding(13.dp)) {
            Text("ACHIEVEMENT UNLOCKED", color = Color(0xFF212121), fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Spacer(Modifier.height(4.dp)); Text("7 DAY STREAK!", color = Color(0xFF212121), fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text("Momentum is becoming a habit.", color = Color(0xFF212121).copy(.7f), fontSize = 11.sp)
        }
    }
}

@Composable
private fun MonsterToggle(checked: Boolean, onChange: (Boolean) -> Unit) {
    UiPressable(Modifier.width(145.dp).height(70.dp), onChange.let { { onChange(!checked) } }) {
        Row(Modifier.fillMaxSize().clip(RoundedCornerShape(16.dp)).background(if (checked) Mint.copy(.18f) else Color(0xFF2C3E50)).border(1.dp, if (checked) Mint else Color.White.copy(.15f), RoundedCornerShape(16.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(if (checked) Mint else Color(0xFF34495E)), Alignment.Center) { Text(if (checked) "◉" else "•", color = Color.Black, fontSize = 20.sp, fontWeight = FontWeight.Black) }
            Spacer(Modifier.width(9.dp)); Column { Text(if (checked) "SHIELD ON" else "SHIELD", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp); Text("pushable", color = Color.White.copy(.55f), fontSize = 9.sp) }
        }
    }
}

@Composable
private fun VerticalModeToggle(checked: Boolean, onChange: (Boolean) -> Unit) {
    UiPressable(Modifier.width(50.dp).height(104.dp), onChange.let { { onChange(!checked) } }) {
        Box(Modifier.fillMaxSize().clip(RoundedCornerShape(17.dp)).background(if (checked) Mint.copy(.2f) else Pink.copy(.16f)).border(1.dp, if (checked) Mint else Pink.copy(.6f), RoundedCornerShape(17.dp)), Alignment.Center) {
            Box(Modifier.size(25.dp).offset(y = if (checked) 29.dp else (-29).dp).clip(CircleShape).background(if (checked) Mint else Pink))
        }
    }
}

@Composable
private fun CyberInput(label: String) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF0F1520)).border(1.dp, Cyan.copy(.5f), RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Text("⌕", color = Cyan, fontSize = 18.sp)
    }
}

@Composable
private fun AnimatedInput(label: String) {
    val t = rememberInfiniteTransition(label = "input")
    val alpha by t.animateFloat(.35f, .9f, infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "inputGlow")
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(7.dp)).background(Color(0xFF212121)).border(2.dp, Cyan.copy(alpha), RoundedCornerShape(7.dp)).padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White.copy(.75f), fontSize = 12.sp, modifier = Modifier.weight(1f)); Text("ENTER", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun IndigoTooltip() {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Color(0xFF1B1932), Color(0xFF11111A)))).border(1.dp, Violet.copy(.45f), RoundedCornerShape(14.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(Violet.copy(.15f)), Alignment.Center) { Text("i", color = Violet, fontWeight = FontWeight.Black) }
        Spacer(Modifier.width(10.dp)); Column { Text("Important information", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp); Text("Premium feature • tap for details", color = Color.White.copy(.55f), fontSize = 10.sp) }
    }
}

@Composable
private fun CyberTooltip() {
    val t = rememberInfiniteTransition(label = "scan-tooltip")
    val scan by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "scan")
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xF70F0F23)).border(1.dp, Cyan.copy(.45f + .25f * scan), RoundedCornerShape(8.dp)).padding(12.dp)) {
        Column {
            Text("SYSTEM INFO", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Text("Live explanation surface • scanline ${if (scan > .5f) "ACTIVE" else "READY"}", color = Cyan.copy(.75f), fontSize = 10.sp)
        }
    }
}

@Composable
private fun CyberSettingsInfo() {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF0E111A)).border(1.dp, Violet.copy(.35f), RoundedCornerShape(14.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(Violet.copy(.14f)), Alignment.Center) { Text("⌁", color = Violet, fontWeight = FontWeight.Black) }
        Spacer(Modifier.width(10.dp))
        Column {
            Text("MOMENTUM FEEL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            Text("Push, glow and haptic feedback stay subtle so the app doesn't become noisy.", color = Color.White.copy(.52f), fontSize = 10.sp)
        }
    }
}

@Composable
private fun BranchTooltip() {
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("AI", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
            Box(Modifier.weight(1f).height(1.dp).background(Violet.copy(.65f)))
            Text("EXPLAIN", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
            Box(Modifier.weight(1f).height(1.dp).background(Mint.copy(.65f)))
            Text("RETRY", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
        }
    }
}
