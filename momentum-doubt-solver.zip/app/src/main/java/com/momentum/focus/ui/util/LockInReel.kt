package com.momentum.focus.ui.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import androidx.core.content.FileProvider
import com.momentum.focus.data.Currency
import com.momentum.focus.data.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import kotlin.coroutines.coroutineContext
import kotlin.math.min

/**
 * Lock-in Reel (V1, no camera): a 15 s 9:16 "study with me" clip made on the
 * phone after a session — timer counting up, ring filling, ₹ earned, streak,
 * a SESSION SECURED stamp, Momentum watermark.
 *
 * Built for cheap phones:
 *  - Only runs when the user taps for it. Nothing renders in the background
 *    on its own.
 *  - Its own single, minimum-priority thread, so the UI thread and the
 *    ceremony never compete with it.
 *  - 720x1280 @ 24 fps, H.264 via the phone's own MediaCodec (no FFmpeg, no
 *    APK growth). Frames drawn on one reused Bitmap; the paper background is
 *    drawn once and blitted. ~6 MB file.
 *  - Byte-buffer input with our own timestamps (not a Canvas Surface, whose
 *    timestamps follow wall-clock and would squash the clip on fast phones).
 *  - Silent on purpose: people add trending audio inside Instagram/Shorts,
 *    and no music means no copyright problem.
 *
 * Cancels cleanly (ensureActive per frame) and always releases the codec.
 * NOT verified on a real device yet — encoders vary by chipset.
 */
object LockInReel {

    data class Info(
        val minutes: Int,
        val subject: String?,
        val earned: Int,
        val streak: Int,
    )

    private const val W = 720
    private const val H = 1280
    private const val FPS = 24
    private const val SECONDS = 15
    private const val FRAMES = FPS * SECONDS
    private const val BITRATE = 3_500_000
    private const val MIME = "video/avc"

    /** Renders the reel; returns the file or null if the phone's encoder refused. */
    suspend fun make(context: Context, info: Info, onProgress: (Float) -> Unit): File? {
        val exec = Executors.newSingleThreadExecutor { r ->
            Thread(r, "lockin-reel").apply { priority = Thread.MIN_PRIORITY }
        }
        val dispatcher = exec.asCoroutineDispatcher()
        return try {
            withContext(dispatcher) {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                val out = File(context.cacheDir, "momentum-lockin.mp4")
                runCatching { encode(out, info, onProgress); out }
                    .onFailure { out.delete(); if (it is kotlinx.coroutines.CancellationException) throw it }
                    .getOrNull()
            }
        } finally {
            dispatcher.close()
        }
    }

    suspend fun share(context: Context, file: File) {
        withContext(Dispatchers.Main) {
            runCatching {
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_TEXT, tr("Locked in. Study with me — Momentum", "लॉक इन। साथ पढ़ो — Momentum"))
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, tr("Share your reel", "रील शेयर करें")))
            }
        }
    }

    // ───────────────────────── encoder ─────────────────────────

    private suspend fun encode(file: File, info: Info, onProgress: (Float) -> Unit) {
        val format = MediaFormat.createVideoFormat(MIME, W, H).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, BITRATE)
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val codec = MediaCodec.createEncoderByType(MIME)
        var muxer: MediaMuxer? = null
        var muxStarted = false
        val painter = Painter(info)
        val argb = IntArray(W * H)
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            val mx = MediaMuxer(file.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4).also { muxer = it }
            val bi = MediaCodec.BufferInfo()
            var track = -1
            var frame = 0
            var inputDone = false
            var outputDone = false
            var lastReported = -1

            while (!outputDone) {
                coroutineContext.ensureActive()
                if (!inputDone) {
                    val idx = codec.dequeueInputBuffer(10_000)
                    if (idx >= 0) {
                        val pts = frame * 1_000_000L / FPS
                        if (frame >= FRAMES) {
                            codec.queueInputBuffer(idx, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val bmp = painter.draw(frame / FPS.toFloat())
                            bmp.getPixels(argb, 0, W, 0, 0, W, H)
                            val img = codec.getInputImage(idx)
                            if (img != null) fillImage(img, argb)
                            else codec.getInputBuffer(idx)?.let { fillI420(it, argb) }
                            codec.queueInputBuffer(idx, 0, W * H * 3 / 2, pts, 0)
                            frame++
                            val pct = frame * 100 / FRAMES
                            if (pct != lastReported) { lastReported = pct; onProgress(pct / 100f) }
                        }
                    }
                }
                // Drain whatever is ready.
                while (true) {
                    val o = codec.dequeueOutputBuffer(bi, if (inputDone) 10_000 else 0)
                    if (o == MediaCodec.INFO_TRY_AGAIN_LATER) break
                    if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = mx.addTrack(codec.outputFormat)
                        mx.start(); muxStarted = true
                        continue
                    }
                    if (o < 0) continue
                    val buf = codec.getOutputBuffer(o)
                    if (bi.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) bi.size = 0
                    if (bi.size > 0 && muxStarted && buf != null) {
                        buf.position(bi.offset); buf.limit(bi.offset + bi.size)
                        mx.writeSampleData(track, buf, bi)
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (bi.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) { outputDone = true; break }
                }
            }
        } finally {
            runCatching { codec.stop() }
            runCatching { codec.release() }
            if (muxStarted) runCatching { muxer?.stop() }
            runCatching { muxer?.release() }
            painter.recycle()
        }
        if (!muxStarted) error("encoder produced nothing")
    }

    /** ARGB → YUV420 (BT.601 limited) into whatever plane layout the encoder gave us. */
    private fun fillImage(img: Image, argb: IntArray) {
        val planes = img.planes
        val y = planes[0]; val u = planes[1]; val v = planes[2]
        val yBuf = y.buffer; val uBuf = u.buffer; val vBuf = v.buffer
        val yRow = y.rowStride; val yPix = y.pixelStride
        val row = ByteArray(W)
        for (j in 0 until H) {
            val base = j * W
            for (i in 0 until W) {
                val c = argb[base + i]
                val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
                row[i] = (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).toByte()
            }
            if (yPix == 1) { yBuf.position(j * yRow); yBuf.put(row) }
            else for (i in 0 until W) yBuf.put(j * yRow + i * yPix, row[i])
        }
        val uRow = u.rowStride; val uPix = u.pixelStride
        val vRow = v.rowStride; val vPix = v.pixelStride
        for (j in 0 until H / 2) {
            for (i in 0 until W / 2) {
                val c = argb[(j * 2) * W + i * 2]
                val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
                uBuf.put(j * uRow + i * uPix, (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).toByte())
                vBuf.put(j * vRow + i * vPix, (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).toByte())
            }
        }
    }

    /** Fallback when the encoder offers no Image: plain I420. */
    private fun fillI420(buf: ByteBuffer, argb: IntArray) {
        buf.clear()
        val ySize = W * H; val q = ySize / 4
        for (k in 0 until ySize) {
            val c = argb[k]
            val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
            buf.put(k, (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).toByte())
        }
        for (j in 0 until H / 2) for (i in 0 until W / 2) {
            val c = argb[(j * 2) * W + i * 2]
            val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
            val k = j * (W / 2) + i
            buf.put(ySize + k, (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).toByte())
            buf.put(ySize + q + k, (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).toByte())
        }
    }

    // ───────────────────────── frames ─────────────────────────

    /**
     * Paper/comic, paced (no frantic motion): every element eases in once and
     * then holds. Timeline (s): 0–1.2 header + subject card · 1–8 ring fills,
     * timer counts up · 8–10.5 ₹ + streak tiles rise · 10.5–11.2 stamp lands ·
     * 11.2–15 hold.
     */
    private class Painter(val info: Info) {
        private val INK = Color.parseColor("#1A1A1A")
        private val INK_MID = Color.parseColor("#8A7A3E")
        private val CREAM = Color.parseColor("#FBF3D5")
        private val CARD = Color.parseColor("#FFFDF2")
        private val GRID = Color.parseColor("#E8D98E")
        private val SUNK = Color.parseColor("#F2E7BE")
        private val MINT = Color.parseColor("#3FE28F")
        private val BUTTER = Color.parseColor("#FFD84D")
        private val TANG = Color.parseColor("#FF8A5C")

        private val bg: Bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888).also { b ->
            val c = Canvas(b)
            c.drawColor(CREAM)
            val p = Paint().apply { color = GRID; strokeWidth = 1.5f }
            var g = 0f
            while (g < W) { c.drawLine(g, 0f, g, H.toFloat(), p); g += 60f }
            g = 0f
            while (g < H) { c.drawLine(0f, g, W.toFloat(), g, p); g += 60f }
        }
        private val frame: Bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        private val c = Canvas(frame)
        private val black = Typeface.create("sans-serif-black", Typeface.NORMAL)
        private val bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; color = INK; strokeWidth = 6f; strokeJoin = Paint.Join.ROUND
        }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()

        private fun seg(t: Float, start: Float, dur: Float) = ((t - start) / dur).coerceIn(0f, 1f)
        private fun out(x: Float) = 1f - (1f - x) * (1f - x) * (1f - x)
        private fun inOut(x: Float) = if (x < 0.5f) 4f * x * x * x else 1f - (-2f * x + 2f).let { it * it * it } / 2f

        private fun block(l: Float, t: Float, r: Float, b: Float, color: Int, radius: Float = 26f, shadow: Float = 10f) {
            fill.color = INK
            rect.set(l + shadow, t + shadow, r + shadow, b + shadow); c.drawRoundRect(rect, radius, radius, fill)
            fill.color = color
            rect.set(l, t, r, b); c.drawRoundRect(rect, radius, radius, fill)
            c.drawRoundRect(rect, radius, radius, stroke)
        }

        private fun fit(str: String, x: Float, y: Float, size: Float, maxW: Float, face: Typeface, color: Int, center: Boolean = false) {
            text.typeface = face; text.color = color; text.textSize = size
            while (text.measureText(str) > maxW && text.textSize > 14f) text.textSize -= 2f
            val dx = if (center) text.measureText(str) / 2f else 0f
            c.drawText(str, x - dx, y, text)
        }

        fun draw(t: Float): Bitmap {
            c.drawBitmap(bg, 0f, 0f, null)
            val left = 56f; val right = W - 56f

            // Header (fades in 0–0.5s)
            val head = out(seg(t, 0f, 0.5f))
            c.save(); c.translate(0f, (1f - head) * -20f)
            fit("MOMENTUM", left, 92f, 38f, 300f, black, INK)
            text.typeface = bold; text.textSize = 22f
            val pill = tr("LOCK-IN REEL", "लॉक-इन रील")
            val pw = text.measureText(pill) + 40f
            block(right - pw, 56f, right, 104f, INK, 24f, 0f)
            fit(pill, right - pw + 20f, 88f, 22f, pw, bold, BUTTER)
            c.restore()

            // Subject card slides down (0.2–1.2s)
            val sub = out(seg(t, 0.2f, 1.0f))
            c.save(); c.translate(0f, (1f - sub) * -60f)
            block(left, 150f, right, 300f, CARD)
            fit(tr("STUDY WITH ME", "साथ पढ़ो"), left + 32f, 200f, 24f, 400f, bold, INK_MID)
            fit(info.subject ?: tr("Deep focus", "गहरा फ़ोकस"), left + 30f, 266f, 56f, right - left - 60f, black, INK)
            c.restore()

            // Ring + timer (1–8s)
            val p = inOut(seg(t, 1f, 7f))
            val cx = W / 2f; val cy = 610f; val r = 210f
            fill.color = INK; c.drawCircle(cx + 10f, cy + 10f, r + 22f, fill)
            fill.color = CARD; c.drawCircle(cx, cy, r + 22f, fill)
            stroke.strokeWidth = 6f; c.drawCircle(cx, cy, r + 22f, stroke)
            val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 30f; strokeCap = Paint.Cap.ROUND }
            arc.color = SUNK; c.drawCircle(cx, cy, r - 12f, arc)
            if (p > 0.003f) {
                arc.color = MINT
                rect.set(cx - r + 12f, cy - r + 12f, cx + r - 12f, cy + r - 12f)
                c.drawArc(rect, -90f, 360f * p, false, arc)
            }
            val shown = (info.minutes * 60 * p).toInt()
            val clock = if (info.minutes >= 60) "%d:%02d:%02d".format(shown / 3600, (shown / 60) % 60, shown % 60)
            else "%02d:%02d".format(shown / 60, shown % 60)
            fit(clock, cx, cy + 30f, 104f, r * 1.5f, black, INK, center = true)
            fit(if (p >= 1f) tr("LOCKED IN", "लॉक्ड इन") else tr("FOCUSING…", "फ़ोकस…"), cx, cy + 92f, 26f, 300f, bold, INK_MID, center = true)

            // Tiles rise (8–10.5s)
            val tw = (right - left - 24f) / 2f
            val tileTop = 900f
            val ta = out(seg(t, 8f, 0.9f))
            val tb = out(seg(t, 8.6f, 0.9f))
            val count = out(seg(t, 8.3f, 1.6f))
            if (ta > 0f) {
                c.save(); c.translate(0f, (1f - ta) * 80f)
                block(left, tileTop, left + tw, tileTop + 170f, BUTTER, 22f, 8f)
                fit(tr("EARNED", "कमाए"), left + 24f, tileTop + 46f, 24f, tw - 48f, bold, INK)
                fit("+" + Currency.format((info.earned * count).toInt()), left + 22f, tileTop + 132f, 64f, tw - 44f, black, INK)
                c.restore()
            }
            if (tb > 0f) {
                c.save(); c.translate(0f, (1f - tb) * 80f)
                val x = left + tw + 24f
                block(x, tileTop, x + tw, tileTop + 170f, TANG, 22f, 8f)
                fit(tr("STREAK", "स्ट्रीक"), x + 24f, tileTop + 46f, 24f, tw - 48f, bold, INK)
                fit(tr("Day ${info.streak.coerceAtLeast(1)}", "दिन ${info.streak.coerceAtLeast(1)}"), x + 22f, tileTop + 132f, 64f, tw - 44f, black, INK)
                c.restore()
            }

            // Stamp lands (10.5–11.2s), settles, holds
            val s = out(seg(t, 10.5f, 0.7f))
            if (s > 0f) {
                c.save()
                val scale = 1.35f - 0.35f * s
                c.rotate(-5f * s, cx, 1150f)
                c.scale(scale, scale, cx, 1150f)
                val half = 260f
                block(cx - half, 1105f, cx + half, 1195f, MINT, 20f, 8f * s)
                fit(tr("SESSION SECURED", "सेशन पक्का"), cx, 1166f, 40f, half * 2 - 40f, black, INK, center = true)
                c.restore()
            }

            // Footer watermark, always on
            fill.color = INK; c.drawRect(0f, H - 64f, W.toFloat(), H.toFloat(), fill)
            fit(tr("Lock in with Momentum", "Momentum के साथ लॉक इन"), cx, H - 22f, 26f, W - 80f, black, BUTTER, center = true)
            return frame
        }

        fun recycle() { bg.recycle(); frame.recycle() }
    }
}
