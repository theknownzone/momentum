package com.momentum.focus.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.tr
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.util.PremiumClip
import com.momentum.focus.ui.util.PremiumSfx
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/*
 * Vault ceremony — Compose port of the approved "Vault № 0499 v2" HTML
 * (premium-welcome.html, 2026-10-03).
 *
 * One clock drives everything (ms since start), so every visual beat and its
 * sound land together and "tap to skip" is just jumping the clock to the end:
 *   0.5/1.0/1.5s ratchet ×3 · 1.95s bolt clunk + puff · 2.3s door swings
 *   3.8s glow + embers · 4.3s slip prints out of the vault and falls to its
 *   dock · 6.5s ACTIVE stamp · 8.0s wax seal · 8.3s perks · 8.8s CTA.
 *
 * Kept honest: the slip states only what the app knows — holder, key, status.
 * Perks are only features that exist.
 */

private val Cavity = Color(0xFF120E0A)
private val GoldHi = Color(0xFFFFE89E)
private val Gold = Color(0xFFF2C34D)
private val GoldLo = Color(0xFFD9A537)
private val Ivory = Color(0xFFFFFDF6)
private val CremCard = Color(0xFFFFFDF2)
private val VMint = Color(0xFF3FE28F)
private val VMintAcc = Color(0xFF1D9E55)
private val VInkMid = Color(0xFF8A7A3E)
private val VInkLow = Color(0xFFB0A26A)
private val VSky = Color(0xFF7FD4FF)

private const val END_MS = 9400f
private val Settle = CubicBezierEasing(0.35f, 0.65f, 0.3f, 1f)

private fun clamp01(x: Float) = x.coerceIn(0f, 1f)
private fun seg(t: Float, start: Float, dur: Float) = clamp01((t - start) / dur)

/** Piecewise-linear keyframes: list of (time 0..1, value). */
private fun kf(p: Float, vararg pts: Pair<Float, Float>): Float {
    if (p <= pts.first().first) return pts.first().second
    for (i in 1 until pts.size) {
        val (t1, v1) = pts[i]
        val (t0, v0) = pts[i - 1]
        if (p <= t1) {
            val f = FastOutSlowInEasing.transform((p - t0) / (t1 - t0))
            return v0 + (v1 - v0) * f
        }
    }
    return pts.last().second
}

@Composable
internal fun VaultCeremony(
    data: AppData,
    onStart: () -> Unit,
    onShareReceipt: () -> Unit,
    onDismiss: () -> Unit,
) {
    val haptics = rememberHaptics()
    var t by remember { mutableFloatStateOf(0f) }
    var skipped by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (t < END_MS && !skipped) {
            withFrameNanos { now -> if (!skipped) t = (now - start) / 1_000_000f }
        }
    }
    BackHandler { onDismiss() }

    // ---- sound + haptic beats, each fires once as the clock passes it
    val fired = remember { mutableSetOf<Int>() }
    fun beat(id: Int, at: Float, fn: () -> Unit) {
        if (t >= at && id !in fired) { fired += id; if (!skipped) fn() }
    }
    SideEffect {
    beat(1, 500f) { Sfx.play(Sound.TICK); haptics.tick() }
    beat(2, 1000f) { Sfx.play(Sound.TICK); haptics.tick() }
    beat(3, 1500f) { Sfx.play(Sound.TICK); haptics.tick() }
    beat(4, 1950f) { Sfx.playOnce(Sound.CRACK); haptics.unlock() }
    beat(5, 2300f) { Sfx.play(Sound.WHOOSH) }
    beat(6, 3800f) { Sfx.playOnce(Sound.SHIMMER); PremiumSfx.play(PremiumClip.CELEBRATE) }
    beat(7, 4300f) { Sfx.play(Sound.SEND) }
    beat(8, 6500f) { Sfx.play(Sound.POP); haptics.confirm() }
    beat(9, 8000f) { Sfx.play(Sound.SUCCESS); haptics.confirm() }
    beat(10, 8800f) { Sfx.play(Sound.UNLOCK) }
    }

    // ---- ambient loops (after the door is open)
    val amb = rememberInfiniteTransition(label = "vaultAmb")
    val edge by amb.animateFloat(0.30f, 0.62f, infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Reverse), label = "edge")
    val ember by amb.animateFloat(0f, 1f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "ember")
    val floatY by amb.animateFloat(0f, 1f, infiniteRepeatable(tween(7000), RepeatMode.Reverse), label = "float")
    val glint by amb.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "glint")
    val gain by amb.animateFloat(0f, 1f, infiniteRepeatable(tween(6000), RepeatMode.Reverse), label = "gain")

    // ---- derived timeline
    val stageIn = seg(t, 0f, 350f)
    val handleTurn = when {
        t < 500f -> 0f
        t < 1000f -> 40f * FastOutSlowInEasing.transform(seg(t, 500f, 220f))
        t < 1500f -> 40f + 40f * FastOutSlowInEasing.transform(seg(t, 1000f, 220f))
        else -> 80f + 40f * FastOutSlowInEasing.transform(seg(t, 1500f, 220f))
    }
    val lit = when { t >= 1500f -> 3; t >= 1000f -> 2; t >= 500f -> 1; else -> 0 }
    val clunk = seg(t, 1950f, 220f).let { if (it in 0.001f..0.999f) kf(it, 0f to 1f, 0.35f to 1.035f, 0.72f to 0.995f, 1f to 1f) else 1f }
    val puff = seg(t, 1950f, 550f)
    val swing = seg(t, 2300f, 1500f)
    val doorAngle = kf(Settle.transform(swing), 0f to 0f, 0.72f to -112f, 0.88f to -95f, 1f to -97f)
    val open = seg(t, 2300f + 550f, 550f)
    val glow = seg(t, 3800f, 800f)
    val print = seg(t, 4300f, 1550f)
    val inked = seg(t, 6000f, 400f)
    val rows = seg(t, 6250f, 400f)
    val stamp = seg(t, 6500f, 420f)
    val seal = seg(t, 8000f, 450f)
    val chips = seg(t, 8300f, 500f)
    val cta = seg(t, 8800f, 400f)
    val docked = print >= 1f

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(listOf(Color(0xFF17130E), Color(0xFF241C12), Color(0xFF17130E))))
            .drawBehind {
                // fine dot grain
                val step = 5.dp.toPx()
                var y = 0f
                while (y < size.height) {
                    var x = 0f
                    while (x < size.width) { drawCircle(Color.White.copy(alpha = 0.024f), 1f, Offset(x, y)); x += step }
                    y += step
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { if (t < END_MS) { skipped = true; t = END_MS } }
            },
    ) {
        // gold edge pulse + inner vignette
        Canvas(Modifier.matchParentSize()) {
            drawRect(Brush.radialGradient(listOf(Color.Transparent, Color(0x9E140A00)), center, size.maxDimension * 0.75f))
            drawRoundRect(Gold.copy(alpha = edge), size = size, cornerRadius = CornerRadius(28.dp.toPx()), style = Stroke((2f + edge * 1.6f).dp.toPx()))
        }

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
                .padding(top = 20.dp, bottom = 34.dp)
                .graphicsLayer { alpha = stageIn },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                tr("MOMENTUM · VAULT", "MOMENTUM · तिजोरी"),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                letterSpacing = 2.5.sp,
                color = Color(0xB8FFD54A),
            )
            Spacer(Modifier.height(8.dp))

            // ---------------- the vault zone ----------------
            Box(Modifier.fillMaxWidth().height(236.dp), contentAlignment = Alignment.Center) {
                // room glow
                Canvas(Modifier.size(400.dp)) {
                    drawCircle(Brush.radialGradient(listOf(Color(0x21FFCA66), Color.Transparent), center, size.minDimension / 2 * 0.62f / 0.5f))
                }
                // interior (behind the door)
                Box(Modifier.size(206.dp)) {
                    Canvas(Modifier.fillMaxSize()) {
                        val r = size.minDimension / 2
                        drawCircle(Cavity, r)
                        drawCircle(Brush.radialGradient(listOf(Color(0x73000000), Color(0xCC000000)), center, r), r, alpha = 1f - open)
                        drawCircle(
                            Brush.radialGradient(
                                listOf(Color(0x6BFFCE6E), Color(0x24D99A37), Color.Transparent),
                                Offset(center.x, size.height * 0.62f), r,
                            ),
                            r, alpha = glow,
                        )
                        // coin stack at the bottom of the vault
                        if (glow > 0f) {
                            for (i in 0 until 5) {
                                val cx = center.x + (i - 2) * 16.dp.toPx()
                                val cy = size.height * 0.74f - (if (i % 2 == 0) 0f else 5.dp.toPx())
                                val s = glow
                                drawOval(GoldLo, Offset(cx - 11.dp.toPx() * s, cy - 4.dp.toPx() * s), Size(22.dp.toPx() * s, 9.dp.toPx() * s))
                                drawOval(GoldHi, Offset(cx - 11.dp.toPx() * s, cy - 6.dp.toPx() * s), Size(22.dp.toPx() * s, 8.dp.toPx() * s))
                                drawOval(Ink, Offset(cx - 11.dp.toPx() * s, cy - 6.dp.toPx() * s), Size(22.dp.toPx() * s, 8.dp.toPx() * s), style = Stroke(1.5.dp.toPx()))
                            }
                        }
                        // embers drifting up
                        if (glow > 0f) {
                            listOf(0.42f to 0.034f, 0.58f to 0.367f, 0.50f to 0.683f).forEach { (x, off) ->
                                val ph = (ember + off) % 1f
                                val a = when { ph < 0.18f -> ph / 0.18f * 0.8f; ph < 0.7f -> 0.8f - (ph - 0.18f) / 0.52f * 0.45f; else -> 0.35f * (1f - (ph - 0.7f) / 0.3f) }
                                drawCircle(Color(0xFFFFD678).copy(alpha = a * glow), 1.6.dp.toPx(), Offset(size.width * x, size.height * 0.72f - ph * 64.dp.toPx()))
                            }
                        }
                        // print slot
                        drawRoundRect(Color(0xA6000000), Offset(center.x - 33.dp.toPx(), size.height - 26.dp.toPx()), Size(66.dp.toPx(), 5.dp.toPx()), CornerRadius(3.dp.toPx()))
                    }
                }
                // puff on the bolt clunk
                if (puff in 0.001f..0.999f) {
                    Canvas(Modifier.size(340.dp)) {
                        listOf(20f, 75f, 155f, 205f, 290f, 335f).forEach { a ->
                            val rad = (a - 90f) * PI.toFloat() / 180f
                            val d = (118f + 36f * puff).dp.toPx()
                            drawCircle(Color(0xFFFBF3D5).copy(alpha = 0.8f * (1f - puff)), 1.6.dp.toPx() * (1f - 0.7f * puff), center + Offset(cos(rad) * d, sin(rad) * d))
                        }
                    }
                }
                // the door
                VaultDoor(
                    angle = doorAngle,
                    scale = clunk,
                    handleTurn = handleTurn,
                    lit = lit,
                    serial = "№ M-" + (data.licenseKey.takeLast(4).uppercase().ifBlank { "0499" }),
                )
            }

            // ---------------- the slip ----------------
            val slipTy = if (docked) -2f * floatY else kf(print, 0f to -190f, 0.24f to -252f, 0.5f to -168f, 0.74f to 8f, 0.88f to -3f, 1f to 0f)
            val slipSc = if (docked) 1f else kf(print, 0f to 0.58f, 0.24f to 0.84f, 0.5f to 0.93f, 0.74f to 1f, 1f to 1f)
            val slipRot = if (docked) -1.5f + 0.4f * floatY else kf(print, 0f to -7f, 0.24f to -6f, 0.5f to -5f, 0.74f to -2.3f, 0.88f to -1.1f, 1f to -1.5f)
            val slipA = if (print <= 0f) 0f else clamp01(print / 0.24f)
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                // dock shadow
                Canvas(Modifier.padding(top = 214.dp).width(270.dp).height(16.dp)) {
                    drawOval(Brush.radialGradient(listOf(Color(0x7A000000), Color.Transparent), center, size.width / 2), alpha = if (docked) 1f else 0f)
                }
                Slip(
                    data = data,
                    modifier = Modifier
                        .padding(top = 6.dp)
                        .graphicsLayer {
                            translationY = slipTy.dp.toPx()
                            scaleX = slipSc; scaleY = slipSc
                            rotationZ = slipRot
                            alpha = slipA
                        },
                    inked = inked,
                    rows = rows,
                    stamp = stamp,
                    seal = seal,
                    glint = glint,
                )
            }

            // ---------------- perks ----------------
            Spacer(Modifier.height(18.dp))
            Row(
                Modifier.fillMaxWidth().graphicsLayer { alpha = chips },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Canvas(Modifier.weight(1f).height(2.dp)) { dottedLine() }
                Text(
                    "  ★ " + tr("EVERYTHING UNLOCKED", "सब कुछ अनलॉक") + " ★  ",
                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp,
                    letterSpacing = 2.sp, color = VInkLow,
                )
                Canvas(Modifier.weight(1f).height(2.dp)) { dottedLine() }
            }
            Spacer(Modifier.height(10.dp))
            val perks = listOf(
                Triple(Icons.Filled.AutoAwesome, tr("Unlimited MyAI", "असीमित MyAI"), Color(0xFF5A3FC0)),
                Triple(Icons.Filled.Lock, tr("Crown lock", "क्राउन लॉक"), Color(0xFFB24A1E)),
                Triple(Icons.Filled.Palette, tr("Every theme", "हर थीम"), Color(0xFF1D9E55)),
                Triple(Icons.Filled.Quiz, tr("Mock tests", "मॉक टेस्ट"), Color(0xFF1A6E96)),
            )
            perks.chunked(2).forEachIndexed { r, pair ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEachIndexed { c, (icon, label, acc) ->
                        val i = r * 2 + c
                        PerkChip(icon, label, acc, seg(t, 8300f + i * 120f, 340f), gain, Modifier.weight(1f))
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // ---------------- CTA ----------------
            Column(Modifier.graphicsLayer { alpha = cta; translationY = (1f - cta) * 26.dp.toPx() }) {
                PowerButton(tr("Start Premium →", "प्रीमियम शुरू करें →")) {
                    if (cta > 0.5f) { haptics.confirm(); Sfx.play(Sound.BEGIN); onStart() }
                }
                Text(
                    tr("Save receipt", "रसीद सेव करें"),
                    fontSize = 13.sp,
                    color = VInkLow.copy(alpha = 0.75f),
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .clickableNoRipple(remember { MutableInteractionSource() }) { if (cta > 0.5f) { haptics.tick(); onShareReceipt() } }
                        .padding(10.dp),
                )
            }
        }

        if (t < END_MS) {
            Text(
                tr("tap to skip", "छोड़ने के लिए टैप करें"),
                fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.sp,
                color = Color.White.copy(alpha = 0.3f),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
            )
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.dottedLine() {
    var x = 0f
    while (x < size.width) { drawCircle(Color(0x73B0A26A), 1.dp.toPx(), Offset(x, size.height / 2)); x += 5.dp.toPx() }
}

@Composable
private fun VaultDoor(angle: Float, scale: Float, handleTurn: Float, lit: Int, serial: String) {
    Box(
        Modifier
            .size(236.dp)
            .graphicsLayer {
                rotationY = angle
                scaleX = scale; scaleY = scale
                transformOrigin = TransformOrigin(0.05f, 0.5f)
                cameraDistance = 12f * density
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2
            // hard drop shadow
            drawCircle(Color(0x80000000), r, center + Offset(6.dp.toPx(), 6.dp.toPx()))
            // door face
            drawCircle(
                Brush.radialGradient(listOf(Color(0xFFFFFAEC), Color(0xFFF3E7C6), Color(0xFFE8D9B2)), Offset(size.width * 0.4f, size.height * 0.33f), r * 1.2f),
                r,
            )
            // dot texture inside the face
            clipPath(Path().apply { addOval(androidx.compose.ui.geometry.Rect(center, r)) }) {
                val st = 6.dp.toPx()
                var y = 0f
                while (y < size.height) { var x = 0f; while (x < size.width) { drawCircle(Color(0x0D000000), 1f, Offset(x, y)); x += st }; y += st }
            }
            // thickness edge, visible while the door turns away
            val edgeA = clamp01((-angle - 20f) / 30f)
            if (edgeA > 0f) {
                drawRoundRect(
                    Brush.horizontalGradient(listOf(Color(0xFF101010), Color(0xFF3A3A3A)), startX = size.width - 11.dp.toPx(), endX = size.width),
                    Offset(size.width - 11.dp.toPx(), size.height * 0.09f), Size(11.dp.toPx(), size.height * 0.82f),
                    CornerRadius(5.dp.toPx()), alpha = edgeA,
                )
            }
            drawCircle(Ink, r - 1.75.dp.toPx(), style = Stroke(3.5.dp.toPx()))
            drawCircle(GoldHi, r - 12.dp.toPx(), style = Stroke(2.5.dp.toPx()))
            // hinges
            drawRoundRect(Ink, Offset(-5.dp.toPx(), 52.dp.toPx()), Size(12.dp.toPx(), 28.dp.toPx()), CornerRadius(4.dp.toPx()))
            drawRoundRect(Ink, Offset(-5.dp.toPx(), size.height - 80.dp.toPx()), Size(12.dp.toPx(), 28.dp.toPx()), CornerRadius(4.dp.toPx()))
            // 12 ratchet ticks; 0, 4, 8 light mint as the handle turns
            for (i in 0 until 12) {
                val on = (i == 0 && lit >= 1) || (i == 4 && lit >= 2) || (i == 8 && lit >= 3)
                rotate(i * 30f, center) {
                    val top = center.y - r + 22.dp.toPx()
                    if (on) drawRoundRect(VMint.copy(alpha = 0.35f), Offset(center.x - 4.dp.toPx(), top - 3.dp.toPx()), Size(8.dp.toPx(), 16.dp.toPx()), CornerRadius(4.dp.toPx()))
                    drawRoundRect(if (on) VMint else Ink, Offset(center.x - 1.75.dp.toPx(), top), Size(3.5.dp.toPx(), 10.dp.toPx()), CornerRadius(2.dp.toPx()))
                }
            }
        }
        // plate
        Text(
            "VAULT · MOMENTUM",
            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 8.sp, letterSpacing = 2.sp, color = Ink,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 38.dp)
                .graphicsLayer { rotationZ = -2f }
                .drawBehind { drawRoundRect(Color(0x73000000), Offset(3.dp.toPx(), 3.dp.toPx()), size, CornerRadius(8.dp.toPx())) }
                .clip(RoundedCornerShape(8.dp))
                .background(Brush.linearGradient(listOf(GoldHi, Gold)))
                .border(2.5.dp, Ink, RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 5.dp),
        )
        // handle: three spokes with knobs, hub in the middle
        Canvas(Modifier.size(132.dp).graphicsLayer { rotationZ = handleTurn }) {
            for (k in 0 until 3) {
                rotate(k * 120f, center) {
                    drawRoundRect(Ink, Offset(0f, center.y - 5.5.dp.toPx()), Size(size.width, 11.dp.toPx()), CornerRadius(6.dp.toPx()))
                    listOf(4.dp.toPx(), size.width - 4.dp.toPx()).forEach { x ->
                        drawCircle(CremCard, 8.dp.toPx(), Offset(x, center.y))
                        drawCircle(Ink, 8.dp.toPx(), Offset(x, center.y), style = Stroke(2.5.dp.toPx()))
                    }
                }
            }
            drawCircle(Ink, 17.dp.toPx())
            drawCircle(CremCard, 7.5.dp.toPx())
            drawCircle(Ink, 7.5.dp.toPx(), style = Stroke(2.5.dp.toPx()))
        }
        Text(
            serial,
            fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = 2.sp, color = Ink.copy(alpha = 0.42f),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 34.dp),
        )
    }
}

@Composable
private fun Slip(
    data: AppData,
    modifier: Modifier,
    inked: Float,
    rows: Float,
    stamp: Float,
    seal: Float,
    glint: Float,
) {
    Box(modifier.width(300.dp)) {
        Column(
            Modifier
                .fillMaxWidth()
                .drawBehind { drawRoundRect(Color(0x8C000000), Offset(5.dp.toPx(), 5.dp.toPx()), size, CornerRadius(16.dp.toPx())) }
                .clip(RoundedCornerShape(16.dp))
                .background(Ivory)
                .drawBehind {
                    val st = 6.dp.toPx(); var y = 0f
                    while (y < size.height) { var x = 0f; while (x < size.width) { drawCircle(Color(0x09000000), 1f, Offset(x, y)); x += st }; y += st }
                }
                .border(3.dp, Ink, RoundedCornerShape(16.dp))
                .padding(horizontal = 18.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                tr("MOMENTUM", "MOMENTUM"),
                fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 3.sp, color = VInkMid,
                modifier = Modifier.graphicsLayer { alpha = inked; translationY = (1f - inked) * 6.dp.toPx() },
            )
            Text(
                "Premium",
                fontFamily = FontFamily.Cursive, fontWeight = FontWeight.Bold, fontSize = 40.sp, color = Ink,
                modifier = Modifier.graphicsLayer { alpha = inked; translationY = (1f - inked) * 6.dp.toPx() },
            )
            // hand-drawn underline that draws itself in
            Canvas(Modifier.width(160.dp).height(10.dp)) {
                val p = Path().apply {
                    moveTo(0f, size.height * 0.6f)
                    quadraticTo(size.width * 0.5f, size.height * 0.1f, size.width, size.height * 0.5f)
                }
                val m = androidx.compose.ui.graphics.PathMeasure().apply { setPath(p, false) }
                val part = Path()
                m.getSegment(0f, m.length * clamp01((inked - 0.3f) / 0.7f), part, true)
                drawPath(part, Gold, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
            }
            Text(
                tr("MEMBER · FOCUS, BANKED.", "सदस्य · फ़ोकस, जमा।"),
                fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 2.5.sp, color = VInkMid,
                modifier = Modifier.graphicsLayer { alpha = inked },
            )
            Canvas(Modifier.fillMaxWidth().padding(vertical = 10.dp).height(1.dp)) {
                var x = 0f
                while (x < size.width) { drawLine(Ink.copy(alpha = 0.4f), Offset(x, 0f), Offset(x + 3.dp.toPx(), 0f), 1.dp.toPx()); x += 7.dp.toPx() }
            }
            SlipRow(tr("Holder", "धारक"), data.userName.ifBlank { tr("friend", "दोस्त") }, seg(rows, 0f, 0.7f))
            if (data.licenseKey.isNotBlank()) SlipRow(tr("Key", "की"), "•••• " + data.licenseKey.takeLast(4).uppercase(), seg(rows, 0.15f, 0.7f))
            Row(
                Modifier.fillMaxWidth().padding(vertical = 3.dp).graphicsLayer { alpha = seg(rows, 0.3f, 0.7f) },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(tr("Status", "स्थिति"), fontFamily = FontFamily.Monospace, fontSize = 11.5.sp, color = VInkMid, modifier = Modifier.weight(1f))
                val sc = if (stamp <= 0f) 1.7f else kf(stamp, 0f to 1.7f, 0.62f to 0.94f, 1f to 1f)
                Text(
                    tr("ACTIVE", "सक्रिय"),
                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold, fontSize = 11.5.sp, letterSpacing = 2.sp, color = VMintAcc,
                    modifier = Modifier
                        .graphicsLayer { rotationZ = -12f; scaleX = sc; scaleY = sc; alpha = clamp01(stamp / 0.62f) }
                        .border(2.5.dp, VMintAcc, RoundedCornerShape(4.dp))
                        .padding(horizontal = 9.dp, vertical = 2.dp),
                )
            }
            Spacer(Modifier.height(4.dp))
            Text("focus, banked.", fontFamily = FontFamily.Cursive, fontSize = 15.sp, color = VInkMid)
        }
        // washi tape
        Canvas(Modifier.padding(start = 16.dp).offset(y = (-10).dp).width(92.dp).height(22.dp).graphicsLayer { rotationZ = -7f }) {
            drawRect(VMint.copy(alpha = 0.34f))
            var x = -size.height
            while (x < size.width) {
                drawLine(Color.White.copy(alpha = 0.28f), Offset(x, size.height), Offset(x + size.height, 0f), 6.dp.toPx())
                x += 12.dp.toPx()
            }
        }
        // wax seal
        val ss = if (seal <= 0f) 1.6f else kf(seal, 0f to 1.6f, 0.62f to 0.93f, 1f to 1f)
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .offset(x = (-12).dp, y = 15.dp)
                .size(46.dp)
                .graphicsLayer { rotationZ = -8f; scaleX = ss; scaleY = ss; alpha = clamp01(seal / 0.62f) }
                .drawBehind { drawCircle(Color(0x73000000), size.minDimension / 2, center + Offset(3.dp.toPx(), 3.dp.toPx())) }
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(GoldHi, Gold, GoldLo)))
                .border(2.5.dp, Ink, CircleShape)
                .drawWithContent {
                    drawContent()
                    drawCircle(Ink.copy(alpha = 0.55f), size.minDimension / 2 - 7.dp.toPx(), style = Stroke(2.dp.toPx(), pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(2f, 5f))))
                    // glint sweeps across now and then
                    val g = if (glint < 0.72f) -0.6f else -0.6f + (glint - 0.72f) / 0.16f * 1.9f
                    if (g in -0.6f..1.3f) {
                        drawRect(
                            Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.5f), Color.Transparent), startX = size.width * g, endX = size.width * (g + 0.45f)),
                        )
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            Text("★", fontSize = 20.sp, color = Ink)
        }
    }
}

@Composable
private fun SlipRow(label: String, value: String, a: Float) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.5.dp).graphicsLayer { alpha = a; translationY = (1f - a) * 5.dp.toPx() },
    ) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp, color = VInkMid, modifier = Modifier.weight(1f))
        Text(value, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = Ink, maxLines = 1)
    }
}

@Composable
private fun PerkChip(icon: ImageVector, label: String, acc: Color, a: Float, gain: Float, modifier: Modifier) {
    val sc = if (a <= 0f) 0.92f else 0.92f + 0.08f * FastOutSlowInEasing.transform(a)
    val shine = clamp01((a - 0.5f) / 0.5f)
    Row(
        modifier
            .graphicsLayer { alpha = a; translationY = (1f - a) * 10.dp.toPx(); scaleX = sc; scaleY = sc }
            .drawBehind {
                // soft accent glow that breathes, under a hard ink shadow
                for (k in 1..4) {
                    val g = (k * (3f + 2f * gain)).dp.toPx()
                    drawRoundRect(acc.copy(alpha = 0.07f * (1f - k / 5f)), Offset(-g, -g), Size(size.width + 2 * g, size.height + 2 * g), CornerRadius(12.dp.toPx() + g))
                }
                drawRoundRect(Color(0x80000000), Offset(4.dp.toPx(), 4.dp.toPx()), size, CornerRadius(12.dp.toPx()))
            }
            .clip(RoundedCornerShape(12.dp))
            .background(CremCard)
            .background(Brush.linearGradient(listOf(acc.copy(alpha = 0.26f), Color.Transparent)))
            .drawWithContent {
                drawContent()
                val x = -0.6f + shine * 1.95f
                if (shine in 0.001f..0.999f) drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent), startX = size.width * x, endX = size.width * (x + 0.4f)))
            }
            .border(2.5.dp, Ink, RoundedCornerShape(12.dp))
            .padding(horizontal = 11.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = acc, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Ink, maxLines = 1)
    }
}

@Composable
private fun PowerButton(label: String, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val p by androidx.compose.animation.core.animateFloatAsState(if (pressed) 1f else 0f, tween(120), label = "power")
    Box(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .drawBehind {
                val d = 5.dp.toPx() * (1f - p)
                drawRoundRect(Color(0x80000000), Offset(d + 5.dp.toPx() * p, d + 5.dp.toPx() * p), size, CornerRadius(14.dp.toPx()))
            }
            .graphicsLayer { translationX = 5.dp.toPx() * p; translationY = 5.dp.toPx() * p }
            .clip(RoundedCornerShape(14.dp))
            .background(VSky)
            .border(2.5.dp, Ink, RoundedCornerShape(14.dp))
            .clickableNoRipple(src, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink)
    }
}
