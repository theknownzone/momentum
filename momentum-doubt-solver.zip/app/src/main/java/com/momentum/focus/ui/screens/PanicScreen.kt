package com.momentum.focus.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay

private enum class Phase(val label: String, val seconds: Int) {
    IN("Breathe in", 4), HOLD("Hold", 7), OUT("Breathe out", 8)
}

/**
 * 4-7-8 breathing. The circle scale and the haptics run off the same phase
 * state, so the buzz always lands exactly on the turn — that sync is what
 * makes it usable with eyes closed.
 */
@Composable
fun PanicScreen(
    onSurvived: () -> Unit,
    onRelapsed: () -> Unit,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()
    var phase by remember { mutableStateOf(Phase.IN) }
    var cycles by remember { mutableIntStateOf(0) }
    var secondsLeft by remember { mutableIntStateOf(Phase.IN.seconds) }

    LaunchedEffect(Unit) {
        while (true) {
            haptics.press()
            secondsLeft = phase.seconds
            repeat(phase.seconds) {
                delay(1000)
                secondsLeft -= 1
                if (phase == Phase.IN || phase == Phase.OUT) haptics.tick()
            }
            phase = when (phase) {
                Phase.IN -> Phase.HOLD
                Phase.HOLD -> Phase.OUT
                Phase.OUT -> { cycles += 1; Phase.IN }
            }
        }
    }

    val target = when (phase) {
        Phase.IN -> 1f
        Phase.HOLD -> 1f
        Phase.OUT -> 0.55f
    }
    val scale by animateFloatAsState(
        targetValue = target,
        animationSpec = tween(
            durationMillis = phase.seconds * 1000,
            easing = LinearEasing,
        ),
        label = "breath",
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .paperGrain()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 32.dp, bottom = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "THIS PASSES",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            "An urge peaks in about 10 minutes. You only have to outlast it.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp),
        )

        Spacer(Modifier.weight(1f))

        Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(220.dp)
                    .scale(scale)
                    .clip(CircleShape)
                    .background(Mint.fill)
                    .border(Paper.Outline, MaterialTheme.colorScheme.onSurface, CircleShape)
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(phase.label, style = MaterialTheme.typography.headlineSmall, color = Mint.on)
                Text("$secondsLeft", style = MaterialTheme.typography.displayMedium, color = Mint.on)
            }
        }

        Spacer(Modifier.height(12.dp))
        Text(
            "$cycles cycles done",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.weight(1f))

        SquishButton(
            label = "I got through it",
            sticker = Jade,
            modifier = Modifier.fillMaxWidth(),
        ) { haptics.celebrate(); onSurvived(); onDone() }

        Spacer(Modifier.height(10.dp))

        // Relapse is logged without shame language. An app that punishes gets
        // uninstalled on the exact day it was most needed.
        SquishButton(
            label = "I slipped — log it honestly",
            sticker = Blush,
            modifier = Modifier.fillMaxWidth(),
        ) { onRelapsed(); onDone() }
    }
}
