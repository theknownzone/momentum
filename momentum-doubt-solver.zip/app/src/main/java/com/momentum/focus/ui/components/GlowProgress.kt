package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Sunk

/*
 * One progress language for the whole app (2026-10-03).
 *
 * Every bar fills with a colour that tells you where you are — ember orange
 * when you have barely started, gold through the middle, mint once you are
 * nearly there — with a white-hot head and a soft bloom around the fill, like
 * light coming off it. The ink outline stays, so it still reads as print.
 */

private val RampLow = Color(0xFFFF7A4D)   // just started
private val RampMid = Color(0xFFFFD23F)   // halfway
private val RampHigh = Color(0xFF3FE28F)  // nearly done / done

/** Colour for a progress value 0..1: orange → gold → mint. */
fun progressColor(p: Float): Color {
    val t = p.coerceIn(0f, 1f)
    return if (t < 0.5f) lerp(RampLow, RampMid, t / 0.5f) else lerp(RampMid, RampHigh, (t - 0.5f) / 0.5f)
}

/**
 * Glowing progress bar.
 *
 * @param dark  true on a dark surface (hero, cards on ink): translucent track,
 *              no outline. false on paper: sunk track with the 2dp ink outline.
 * @param color fixed fill colour; null = follow [progressColor].
 */
@Composable
fun GlowProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    height: Dp = 12.dp,
    dark: Boolean = false,
    color: Color? = null,
) {
    // Fills in from zero the first time it appears, then eases to new values.
    val anim = remember { Animatable(0f) }
    LaunchedEffect(progress) {
        anim.animateTo(progress.coerceIn(0f, 1f), tween(700, easing = FastOutSlowInEasing))
    }
    val sweep by rememberInfiniteTransition(label = "glowSweep").animateFloat(
        initialValue = -0.3f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing)),
        label = "sweep",
    )

    Canvas(modifier.fillMaxWidth().height(height)) {
        val p = anim.value
        val h = size.height
        val r = h / 2f
        val fillW = (size.width * p).coerceAtLeast(if (p > 0f) h else 0f)
        val c = color ?: progressColor(p)

        // Bloom: stacked rounded rects fading outward. No blur API needed,
        // so it looks the same on every Android version.
        if (fillW > 0f) {
            for (k in 1..6) {
                val g = k * 2.2.dp.toPx()
                drawRoundRect(
                    c.copy(alpha = (if (dark) 0.16f else 0.10f) * (1f - k / 7f)),
                    topLeft = Offset(-g, -g),
                    size = Size(fillW + g * 2, h + g * 2),
                    cornerRadius = CornerRadius(r + g),
                )
            }
        }

        // Track
        drawRoundRect(
            if (dark) Color.White.copy(alpha = 0.10f) else Sunk,
            size = size,
            cornerRadius = CornerRadius(r),
        )

        if (fillW > 0f) {
            val fill = Path().apply { addRoundRect(RoundRect(0f, 0f, fillW, h, CornerRadius(r))) }
            clipPath(fill) {
                // Body: deeper at the start, the live colour, white-hot head.
                drawRect(
                    Brush.horizontalGradient(
                        0f to lerp(c, Color.Black, 0.18f),
                        0.75f to c,
                        1f to lerp(c, Color.White, 0.75f),
                        startX = 0f,
                        endX = fillW,
                    ),
                )
                // Glass highlight on the top half.
                drawRect(
                    Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.45f), Color.Transparent), endY = h * 0.6f),
                )
                // Light travelling along the fill.
                val sx = sweep * fillW
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.45f), Color.Transparent),
                        startX = sx - h * 2,
                        endX = sx + h * 2,
                    ),
                )
            }
        }

        if (!dark) {
            drawRoundRect(Ink, size = size, cornerRadius = CornerRadius(r), style = Stroke(2.dp.toPx()))
        }
    }
}
