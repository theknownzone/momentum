package com.momentum.focus.ui.screens

import androidx.compose.ui.graphics.drawscope.rotate
import kotlinx.coroutines.flow.first
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.focus.data.AppStore
import com.momentum.focus.data.ScreenTime
import com.momentum.focus.data.tr
import com.momentum.focus.ui.components.AppIcon
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.progressColor
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/*
 * All Set — "Damage → Shield → Value → Light" (2026-10-03).
 *
 * Not a celebration of nothing. It shows the person their own numbers, then
 * shows the app taking them:
 *
 *  Act 1  DAMAGE  (0.3–1.4s)  dark page; your real 7-day average phone time
 *                             counts up in red, the screen flinches.
 *  Act 2  SHIELD  (1.5–2.9s)  your real blocked apps (their actual icons)
 *                             orbit; a shield slams down; each icon is pulled
 *                             in and padlocked, one tick each.
 *  Act 3  VALUE   (3.0–3.9s)  the red number is struck through and re-priced
 *                             in your own earn rate: what that time is worth
 *                             once it is study.
 *  Act 4  LIGHT   (4.0–5.0s)  a ring charges round the shield through the app's
 *                             progress ramp; at full it flashes and the dark
 *                             page is wiped away to paper from the shield out.
 *  Then   name stamp, headline, one button.
 *
 * Every beat has its sound and haptic on the same clock. Tap anywhere skips
 * to the end. Without usage access the damage act is replaced by one honest
 * line — no invented numbers.
 */

private const val END = 5600f
private val Night = Color(0xFF14110D)
private val Blood = Color(0xFFFF5A3C)

private fun c01(x: Float) = x.coerceIn(0f, 1f)
private fun seg(t: Float, a: Float, d: Float) = c01((t - a) / d)
private fun ease(x: Float) = FastOutSlowInEasing.transform(c01(x))

@Composable
internal fun AllSetCeremony(
    kicker: String,
    headline: String,
    subtitle: String,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()
    val context = LocalContext.current
    val store = remember { AppStore(context) }
    val data by store.data.collectAsStateWithLifecycle(initialValue = null)
    val avgMin by produceState<Int?>(null) {
        value = withContext(Dispatchers.IO) {
            runCatching { ScreenTime.report(context).let { if (it.hasData) it.averageMinutes else 0 } }.getOrDefault(0)
        }
    }
    val apps = remember(data?.blockedPackages) { data?.blockedPackages?.take(6).orEmpty() }
    val ratio = (data?.effectiveRatio ?: 3).coerceAtLeast(1)
    val name = data?.userName?.trim().orEmpty()
    val hasDamage = (avgMin ?: 0) > 0

    var t by remember { mutableFloatStateOf(0f) }
    var skipped by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }
    fun finish() { if (!done) { done = true; onDone() } }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (t < END && !skipped) withFrameNanos { now -> if (!skipped) t = (now - start) / 1_000_000f }
    }
    BackHandler { finish() }

    // ---- beats: sound + haptic on the same clock as the picture
    val fired = remember { mutableSetOf<Int>() }
    SideEffect {
        fun beat(id: Int, at: Float, fn: () -> Unit) { if (t >= at && fired.add(id) && !skipped) fn() }
        if (hasDamage) {
            for (k in 0 until 6) beat(100 + k, 350f + k * 150f) { Sfx.play(Sound.TICK) }
            beat(1, 1350f) { Sfx.play(Sound.SLIP); haptics.reject() }
        }
        beat(2, 1550f) { Sfx.play(Sound.WHOOSH) }
        beat(3, 2050f) { Sfx.play(Sound.SHIELD_ON); haptics.unlock() }
        for (k in apps.indices) beat(200 + k, 2250f + k * 110f) { Sfx.play(Sound.TICK); haptics.tick() }
        if (hasDamage) beat(4, 3050f) { Sfx.play(Sound.SPEND) }
        beat(5, 4000f) { Sfx.play(Sound.LEVEL) }
        beat(6, 4800f) { Sfx.play(Sound.SESSION); haptics.confirm() }
        beat(7, 5200f) { Sfx.play(Sound.POP); haptics.tick() }
    }

    val amb = rememberInfiniteTransition(label = "allsetAmb")
    val orbit by amb.animateFloat(0f, 360f, infiniteRepeatable(tween(24000, easing = LinearEasing)), label = "orbit")
    val breathe by amb.animateFloat(0f, 1f, infiniteRepeatable(tween(2600), RepeatMode.Reverse), label = "breathe")

    // ---- timeline
    val intro = seg(t, 0f, 300f)
    val count = if (hasDamage) ease(seg(t, 350f, 950f)) else 0f
    val flinch = seg(t, 1350f, 260f).let { if (it in 0.001f..0.999f) sin(it * PI.toFloat() * 5f) * (1f - it) * 9f else 0f }
    val appsIn = seg(t, 1500f, 500f)
    val slam = seg(t, 2000f, 260f)
    val slamShake = seg(t, 2050f, 240f).let { if (it in 0.001f..0.999f) sin(it * PI.toFloat() * 6f) * (1f - it) * 10f else 0f }
    val strike = if (hasDamage) ease(seg(t, 3000f, 300f)) else 0f
    val value = if (hasDamage) ease(seg(t, 3150f, 700f)) else 0f
    val charge = seg(t, 4000f, 800f)
    val flash = seg(t, 4800f, 500f)
    val reveal = ease(seg(t, 4800f, 650f))
    val stamp = seg(t, 5200f, 260f)
    val cta = ease(seg(t, 5350f, 300f))
    val shake = flinch + slamShake

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Night)
            .pointerInput(Unit) { detectTapGestures { if (t < END) { skipped = true; t = END } } }
            .graphicsLayer { translationX = shake.dp.toPx(); alpha = intro },
    ) {
        val w = maxWidth
        val h = maxHeight
        val shieldY = h * 0.43f
        val onPaper = reveal > 0.5f

        // ---- the light: paper wipes out from the shield
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2, shieldY.toPx())
            val maxR = kotlin.math.hypot(size.width.toDouble(), size.height.toDouble()).toFloat()
            if (reveal > 0f) drawCircle(Cream, maxR * reveal, c)
            if (flash in 0.001f..0.999f) {
                drawCircle(Color.White.copy(alpha = 0.55f * (1f - flash)), maxR)
                drawCircle(progressColor(1f).copy(alpha = 0.8f * (1f - flash)), 70.dp.toPx() + 260.dp.toPx() * flash, c, style = Stroke((10f * (1f - flash) + 1f).dp.toPx()))
            }
        }
        if (reveal > 0.98f) Box(Modifier.fillMaxSize().paperGrain())

        // ---- Act 1 + 3: the damage, then its price
        Column(
            Modifier.fillMaxWidth().statusBarsPadding().padding(top = 28.dp, start = 24.dp, end = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            val inkCol = if (onPaper) Ink else Color(0xFFF2EBDD)
            Text(
                if (hasDamage) tr("YOUR PHONE · DAILY AVERAGE", "आपका फ़ोन · रोज़ का औसत") else kicker,
                fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 2.4.sp,
                color = inkCol.copy(alpha = 0.6f),
            )
            Spacer(Modifier.height(6.dp))
            if (hasDamage) {
                val shown = ((avgMin ?: 0) * count).roundToInt()
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        "${shown / 60}h ${shown % 60}m",
                        fontSize = 52.sp, fontWeight = FontWeight.Black, letterSpacing = (-1).sp,
                        color = lerp(Blood, Blood.copy(alpha = 0.45f), strike),
                    )
                    // strike-through drawn left to right
                    Canvas(Modifier.matchParentSize()) {
                        if (strike > 0f) drawLine(
                            inkCol, Offset(-6.dp.toPx(), size.height * 0.55f),
                            Offset(-6.dp.toPx() + (size.width + 12.dp.toPx()) * strike, size.height * 0.48f),
                            5.dp.toPx(), StrokeCap.Round,
                        )
                    }
                }
                Text(
                    tr("a day on the feed.", "रोज़ फ़ीड पर।"),
                    fontSize = 14.sp, color = inkCol.copy(alpha = 0.55f * c01(count * 2f) * (1f - strike * 0.5f)),
                )
                Spacer(Modifier.height(8.dp))
                // Act 3: re-priced at the person's own earn rate
                val rupees = (((avgMin ?: 0) / ratio) * value).roundToInt()
                Row(
                    Modifier.graphicsLayer { alpha = value; translationY = (1f - value) * 12.dp.toPx(); rotationZ = -2f * value }
                        .drawBehind { drawRoundRect(Ink, Offset(4.dp.toPx(), 4.dp.toPx()), size, CornerRadius(10.dp.toPx())) }
                        .clip(RoundedCornerShape(10.dp))
                        .background(Mint.fill)
                        .border(2.5.dp, Ink, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("= ₹$rupees", fontSize = 26.sp, fontWeight = FontWeight.Black, color = Ink)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        tr("/day if it were study", "/दिन, अगर यह पढ़ाई होती"),
                        fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Ink.copy(alpha = 0.7f),
                    )
                }
            } else {
                Text(
                    tr("From now, every scroll has a price.", "अब से हर स्क्रॉल की क़ीमत है।"),
                    fontSize = 22.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center,
                    color = inkCol.copy(alpha = seg(t, 400f, 500f)),
                )
            }
        }

        // ---- Act 2: real app icons orbit, get pulled in and padlocked
        val orbitR = 118.dp
        apps.forEachIndexed { i, pkg ->
            val base = i * (360f / apps.size.coerceAtLeast(1)) - 90f
            val pull = ease(seg(t, 2250f + i * 110f, 260f))
            val ang = (base + orbit * (1f - 0.6f * pull)) * PI.toFloat() / 180f
            val rad = orbitR * (1.25f - 0.25f * ease(appsIn)) * (1f - 0.42f * pull)
            val x = w / 2 + rad * cos(ang)
            val y = shieldY + rad * sin(ang)
            val sz = 44.dp * (1f - 0.25f * pull)
            Box(
                Modifier
                    .offset { IntOffset((x - sz / 2).roundToPx(), (y - sz / 2).roundToPx()) }
                    .size(sz)
                    .graphicsLayer {
                        alpha = ease(appsIn)
                        scaleX = 0.6f + 0.4f * ease(appsIn); scaleY = scaleX
                        rotationZ = (1f - pull) * (if (i % 2 == 0) -8f else 8f)
                    },
            ) {
                Box(Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)).border(2.dp, if (onPaper) Ink else Color(0x66FFFFFF), RoundedCornerShape(12.dp))) {
                    AppIcon(pkg, sz, Modifier.graphicsLayer { alpha = 1f - 0.45f * pull })
                }
                if (pull > 0.6f) {
                    val pop = ease((pull - 0.6f) / 0.4f)
                    Box(
                        Modifier.align(Alignment.BottomEnd).offset(4.dp, 4.dp).size(20.dp)
                            .graphicsLayer { scaleX = 0.4f + 0.6f * pop; scaleY = scaleX }
                            .clip(CircleShape).background(Ink).border(1.5.dp, Mint.fill, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.Lock, null, tint = Mint.fill, modifier = Modifier.size(11.dp)) }
                }
            }
        }

        // ---- the shield + charge ring
        val sSize = 132.dp
        Box(
            Modifier
                .offset { IntOffset((w / 2 - sSize / 2).roundToPx(), (shieldY - sSize / 2).roundToPx()) }
                .size(sSize),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(sSize + 70.dp).graphicsLayer { alpha = c01(charge * 4f) }) {
                val st = 8.dp.toPx()
                val tl = Offset(st, st)
                val sz = Size(size.width - st * 2, size.height - st * 2)
                drawArc(if (onPaper) Ink.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.10f), 0f, 360f, false, tl, sz, style = Stroke(st))
                val pc = progressColor(charge)
                for (k in 1..4) drawArc(pc.copy(alpha = 0.12f * (1f - k / 5f)), -90f, 360f * charge, false, tl, sz, style = Stroke(st + k * 6.dp.toPx(), cap = StrokeCap.Round))
                drawArc(pc, -90f, 360f * charge, false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
            }
            val drop = ease(slam)
            Canvas(
                Modifier.fillMaxSize().graphicsLayer {
                    val sc = if (slam <= 0f) 1.9f else 1.9f - 0.9f * drop + (if (slam in 0.7f..1f) 0.04f * sin((slam - 0.7f) / 0.3f * PI.toFloat()) else 0f)
                    scaleX = sc; scaleY = sc
                    alpha = c01(slam * 3f)
                    translationY = -(1f - drop) * 90.dp.toPx()
                    val b = if (t > END - 1f || skipped) breathe else 0f
                    scaleX *= 1f + 0.02f * b; scaleY *= 1f + 0.02f * b
                },
            ) { drawShield(appsLocked = apps.size, fill = lerp(Mint.fill, progressColor(1f), charge)) }
        }

        // ---- ink confetti on the stamp (one-shot, runs on its own clock so
        // it keeps falling after the ceremony timeline stops at END)
        val confetti = remember { androidx.compose.animation.core.Animatable(0f) }
        LaunchedEffect(Unit) {
            androidx.compose.runtime.snapshotFlow { t >= 5200f || skipped }.first { it }
            confetti.animateTo(1f, androidx.compose.animation.core.tween(1900, easing = androidx.compose.animation.core.LinearEasing))
        }
        Canvas(Modifier.fillMaxSize()) {
            val k = confetti.value
            if (k <= 0f || k >= 1f) return@Canvas
            val cols = listOf(Mint.fill, Butter.fill, Tang.fill, Sky.fill, Lilac.fill, Candy.fill)
            for (i in 0 until 34) {
                val seed = (i * 7919) % 1000 / 1000f
                val x0 = size.width * ((i * 37 % 100) / 100f)
                val fall = (k * (1.1f + seed * 0.6f)).coerceAtMost(1.4f)
                val y = -40f + size.height * 0.9f * fall
                val x = x0 + sin((k * 6f + i) * 1.7f) * 22.dp.toPx() * (0.5f + seed)
                val a = (1f - k).coerceIn(0f, 1f)
                val w = (6f + seed * 5f).dp.toPx(); val h = w * 0.55f
                rotate(degrees = k * 540f * (if (i % 2 == 0) 1f else -1f) + i * 20f, pivot = Offset(x, y)) {
                    drawRect(cols[i % cols.size].copy(alpha = a), Offset(x - w / 2, y - h / 2), Size(w, h))
                    drawRect(Ink.copy(alpha = a), Offset(x - w / 2, y - h / 2), Size(w, h), style = Stroke(1.2.dp.toPx()))
                }
            }
        }

        // ---- name stamp + headline + CTA (on paper)
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding()
                .padding(horizontal = 22.dp).padding(bottom = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Buddy from onboarding, grinning, lands with the stamp.
            FocusBuddy(
                BuddyMood.SECURED,
                Modifier
                    .padding(bottom = 8.dp)
                    .graphicsLayer {
                        val p = c01(stamp * 2f)
                        alpha = p; translationY = (1f - p) * 18.dp.toPx()
                    },
            )
            val label = if (name.isNotEmpty()) "${name.uppercase()} · " + tr("LOCKED IN", "लॉक इन") else tr("LOCKED IN", "लॉक इन")
            val ss = if (stamp <= 0f) 1.8f else 1.8f - 0.8f * ease(stamp)
            Text(
                label,
                fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp, color = Ink, maxLines = 1,
                modifier = Modifier
                    .graphicsLayer { scaleX = ss; scaleY = ss; alpha = c01(stamp * 2f); rotationZ = -3f }
                    .drawBehind { drawRoundRect(Ink, Offset(4.dp.toPx(), 4.dp.toPx()), size, CornerRadius(6.dp.toPx())) }
                    .clip(RoundedCornerShape(6.dp))
                    .background(Butter.fill)
                    .border(2.5.dp, Ink, RoundedCornerShape(6.dp))
                    .padding(horizontal = 12.dp, vertical = 4.dp),
            )
            Spacer(Modifier.height(14.dp))
            Text(
                headline, fontSize = 30.sp, fontWeight = FontWeight.Black, color = Ink, textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = seg(t, 5100f, 300f); translationY = (1f - ease(seg(t, 5100f, 300f))) * 12.dp.toPx() },
            )
            Text(
                apps.size.let { n ->
                    if (n > 0) tr("$n apps locked · ₹1 every $ratio min studied", "$n ऐप लॉक · हर $ratio मिनट पढ़ाई = ₹1")
                    else subtitle
                },
                fontSize = 13.sp, color = InkMid, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp).graphicsLayer { alpha = seg(t, 5250f, 300f) },
            )
            Spacer(Modifier.height(16.dp))
            Box(Modifier.graphicsLayer { alpha = cta; translationY = (1f - cta) * 22.dp.toPx() }) {
                PrimaryButton(tr("Lock in →", "शुरू करें →")) {
                    if (cta > 0.5f) { haptics.confirm(); Sfx.play(Sound.BEGIN); finish() }
                }
            }
        }

        if (t < END) {
            Text(
                tr("tap to skip", "छोड़ने के लिए टैप करें"),
                fontFamily = FontFamily.Monospace, fontSize = 9.sp,
                color = (if (onPaper) Ink else Color.White).copy(alpha = 0.3f),
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 2.dp),
            )
        }
    }
}

/** Heater shield in the app's print style: ink outline, bevel, gloss, padlock. */
private fun DrawScope.drawShield(appsLocked: Int, fill: Color) {
    val w = size.width
    val h = size.height
    fun shieldPath(inset: Float) = Path().apply {
        moveTo(w * 0.5f, h * 0.04f + inset)
        cubicTo(w * 0.70f, h * 0.14f, w * 0.86f, h * 0.15f, w * 0.94f - inset, h * 0.14f + inset)
        cubicTo(w * 0.95f - inset, h * 0.55f, w * 0.80f, h * 0.82f, w * 0.5f, h * 0.97f - inset)
        cubicTo(w * 0.20f, h * 0.82f, w * 0.05f + inset, h * 0.55f, w * 0.06f + inset, h * 0.14f + inset)
        cubicTo(w * 0.14f, h * 0.15f, w * 0.30f, h * 0.14f, w * 0.5f, h * 0.04f + inset)
        close()
    }
    val outer = shieldPath(0f)
    // hard ink shadow
    translateBy(6.dp.toPx()) { drawPath(outer, Ink) }
    drawPath(outer, Brush.verticalGradient(listOf(lerp(fill, Color.White, 0.35f), fill, lerp(fill, Color.Black, 0.18f))))
    drawPath(shieldPath(10.dp.toPx()), Color.White.copy(alpha = 0.55f), style = Stroke(2.dp.toPx()))
    // gloss on the upper-left
    drawPath(
        Path().apply {
            moveTo(w * 0.5f, h * 0.10f)
            cubicTo(w * 0.32f, h * 0.18f, w * 0.18f, h * 0.20f, w * 0.14f, h * 0.20f)
            cubicTo(w * 0.15f, h * 0.40f, w * 0.22f, h * 0.52f, w * 0.30f, h * 0.60f)
            cubicTo(w * 0.40f, h * 0.40f, w * 0.45f, h * 0.25f, w * 0.5f, h * 0.10f)
            close()
        },
        Color.White.copy(alpha = 0.28f),
    )
    drawPath(outer, Ink, style = Stroke(3.5.dp.toPx()))
    // padlock
    val cx = w / 2
    val cy = h * 0.52f
    val bw = w * 0.30f
    val bh = h * 0.22f
    drawArc(Ink, 180f, 180f, false, Offset(cx - bw * 0.32f, cy - bh * 0.95f), Size(bw * 0.64f, bh * 0.9f), style = Stroke(5.dp.toPx(), cap = StrokeCap.Round))
    drawRoundRect(Ink, Offset(cx - bw / 2, cy - bh * 0.5f), Size(bw, bh), CornerRadius(5.dp.toPx()))
    drawCircle(lerp(fill, Color.White, 0.4f), 3.5.dp.toPx(), Offset(cx, cy - bh * 0.08f))
    drawLine(lerp(fill, Color.White, 0.4f), Offset(cx, cy - bh * 0.08f), Offset(cx, cy + bh * 0.25f), 2.5.dp.toPx(), StrokeCap.Round)
}

private inline fun DrawScope.translateBy(d: Float, block: DrawScope.() -> Unit) {
    drawContext.transform.translate(d, d)
    block()
    drawContext.transform.translate(-d, -d)
}
