package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink

/**
 * Money icons drawn in code rather than imported.
 *
 * Stock 3D icon packs are almost always licensed per-seat and cannot be
 * redistributed inside an app, so shipping them would be a problem the moment
 * this leaves the phone. These are the same isometric trick used everywhere
 * else in the app: one hue at three brightnesses, hard black outline.
 */

private fun Color.lit(f: Float) = Color(
    (red * f).coerceIn(0f, 1f),
    (green * f).coerceIn(0f, 1f),
    (blue * f).coerceIn(0f, 1f),
    alpha,
)

/** A single coin lying at an angle, with a rupee cut into the face. */
@Composable
fun Coin3D(
    color: Color,
    size: Dp = 40.dp,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val cw = w * 0.82f
        val ch = cw * 0.40f
        val left = (w - cw) / 2
        val top = w * 0.24f
        val thick = ch * 0.62f
        val o = 2.5f.dp.toPx()

        val body = Path().apply {
            moveTo(left, top + ch / 2)
            lineTo(left, top + ch / 2 + thick)
            arcTo(Rect(Offset(left, top + thick), Size(cw, ch)), 180f, -180f, false)
            lineTo(left + cw, top + ch / 2)
            close()
        }
        drawPath(body, color.lit(0.62f))
        drawPath(body, Ink, style = Stroke(o))

        drawOval(color.lit(1.12f), Offset(left, top), Size(cw, ch))
        drawOval(Ink, Offset(left, top), Size(cw, ch), style = Stroke(o))

        rupee(
            center = Offset(w / 2, top + ch / 2),
            height = ch * 0.62f,
            stroke = o * 0.9f,
        )
    }
}

/**
 * The rupee mark, squashed vertically to sit on the coin's ellipse.
 *
 * Drawn rather than typed because a glyph at this size renders as a smudge and
 * refuses to follow the coin's perspective.
 */
private fun DrawScope.rupee(center: Offset, height: Float, stroke: Float) {
    val h = height
    val w = h * 0.95f
    val x = center.x - w / 2
    val y = center.y - h / 2

    val path = Path().apply {
        moveTo(x, y)
        lineTo(x + w, y)
        moveTo(x, y + h * 0.34f)
        lineTo(x + w, y + h * 0.34f)
        moveTo(x + w * 0.15f, y)
        lineTo(x + w * 0.15f, y + h * 0.34f)
        moveTo(x + w * 0.15f, y + h * 0.34f)
        lineTo(x + w, y + h)
    }
    drawPath(path, Ink, style = Stroke(stroke))
}

/** A wallet, slightly open, with a note poking out. */
@Composable
fun Wallet3D(
    color: Color,
    accent: Color,
    size: Dp = 56.dp,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val o = 3.dp.toPx()

        // Note first so the wallet body overlaps its lower edge.
        val note = Path().apply {
            moveTo(w * 0.30f, w * 0.30f)
            lineTo(w * 0.72f, w * 0.22f)
            lineTo(w * 0.72f, w * 0.52f)
            lineTo(w * 0.30f, w * 0.60f)
            close()
        }
        drawPath(note, accent.lit(1.1f))
        drawPath(note, Ink, style = Stroke(o * 0.8f))

        val front = Path().apply {
            moveTo(w * 0.18f, w * 0.42f)
            lineTo(w * 0.82f, w * 0.34f)
            lineTo(w * 0.82f, w * 0.72f)
            lineTo(w * 0.18f, w * 0.80f)
            close()
        }
        drawPath(front, color.lit(1.0f))
        drawPath(front, Ink, style = Stroke(o))

        val side = Path().apply {
            moveTo(w * 0.18f, w * 0.42f)
            lineTo(w * 0.18f, w * 0.80f)
            lineTo(w * 0.10f, w * 0.74f)
            lineTo(w * 0.10f, w * 0.36f)
            close()
        }
        drawPath(side, color.lit(0.66f))
        drawPath(side, Ink, style = Stroke(o))

        val clasp = Path().apply {
            moveTo(w * 0.60f, w * 0.52f)
            lineTo(w * 0.78f, w * 0.50f)
            lineTo(w * 0.78f, w * 0.62f)
            lineTo(w * 0.60f, w * 0.64f)
            close()
        }
        drawPath(clasp, accent.lit(0.9f))
        drawPath(clasp, Ink, style = Stroke(o * 0.8f))
    }
}


/**
 * A fanned stack of notes with coins resting against it.
 *
 * The fan is the whole illusion: five slabs offset by a few degrees each, drawn
 * back to front, with every layer a shade darker than the one on top. Draw them
 * flat and stacked and it reads as a single green rectangle.
 */
@Composable
fun NoteStack3D(
    noteColor: Color,
    coinColor: Color,
    size: Dp = 96.dp,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val o = 2.5f.dp.toPx()
        val cx = w * 0.48f
        val cy = w * 0.50f
        val nw = w * 0.56f
        val nh = w * 0.34f

        // Back to front, each sheet lifted and lightened slightly.
        for (i in 4 downTo 0) {
            val lift = i * w * 0.028f
            val skew = i * w * 0.012f
            val shade = 0.68f + (4 - i) * 0.09f

            val note = Path().apply {
                moveTo(cx - nw / 2 - skew, cy - nh / 2 + lift)
                lineTo(cx + nw / 2 - skew, cy - nh / 2 - lift * 0.5f + lift)
                lineTo(cx + nw / 2 + skew, cy + nh / 2 + lift)
                lineTo(cx - nw / 2 + skew, cy + nh / 2 + lift * 0.5f + lift)
                close()
            }
            drawPath(note, noteColor.lit(shade))
            drawPath(note, Ink, style = Stroke(o))

            // Only the top sheet gets the printed detail; on the ones below it
            // would just be noise at this size.
            if (i == 0) {
                drawCircle(
                    color = noteColor.lit(0.72f),
                    radius = nh * 0.20f,
                    center = Offset(cx, cy + lift),
                )
                drawCircle(
                    color = Ink,
                    radius = nh * 0.20f,
                    center = Offset(cx, cy + lift),
                    style = Stroke(o * 0.8f),
                )
                rupee(
                    center = Offset(cx, cy + lift),
                    height = nh * 0.24f,
                    stroke = o * 0.9f,
                )
            }
        }

        // Coins tucked against the lower edges, largest in front.
        listOf(
            Triple(w * 0.16f, w * 0.74f, 0.30f),
            Triple(w * 0.78f, w * 0.68f, 0.26f),
            Triple(w * 0.52f, w * 0.84f, 0.34f),
        ).forEach { (x, y, scale) ->
            val cw = w * scale
            val ch = cw * 0.42f
            val left = x - cw / 2
            val top = y - ch / 2
            val thick = ch * 0.55f

            val body = Path().apply {
                moveTo(left, top + ch / 2)
                lineTo(left, top + ch / 2 + thick)
                arcTo(Rect(Offset(left, top + thick), Size(cw, ch)), 180f, -180f, false)
                lineTo(left + cw, top + ch / 2)
                close()
            }
            drawPath(body, coinColor.lit(0.60f))
            drawPath(body, Ink, style = Stroke(o))
            drawOval(coinColor.lit(1.14f), Offset(left, top), Size(cw, ch))
            drawOval(Ink, Offset(left, top), Size(cw, ch), style = Stroke(o))
        }
    }
}

/**
 * A lock, front-on rather than isometric like the coins — a shackle reads
 * as a shackle from directly ahead in a way it stops doing at the coins'
 * angle, and the thing being communicated here is specifically "locked",
 * not "an object in space". Same house rule otherwise: one hue at three
 * brightnesses, hard Ink outline.
 */
@Composable
fun Lock3D(
    color: Color,
    size: Dp = 40.dp,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val o = 2.2f.dp.toPx()

        val bodyW = w * 0.62f
        val bodyH = w * 0.48f
        val bodyLeft = (w - bodyW) / 2f
        val bodyTop = w * 0.44f

        // The shackle: a thick U, stroked rather than filled so the gap it
        // arches over stays open.
        val shackleR = w * 0.20f
        val shackleCx = w / 2f
        val shackleCy = bodyTop
        drawArc(
            color = Ink,
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(shackleCx - shackleR, shackleCy - shackleR * 1.3f),
            size = Size(shackleR * 2f, shackleR * 2.1f),
            style = Stroke(w * 0.13f + o),
        )
        drawArc(
            color = color.lit(1.15f),
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(shackleCx - shackleR, shackleCy - shackleR * 1.3f),
            size = Size(shackleR * 2f, shackleR * 2.1f),
            style = Stroke(w * 0.13f),
        )

        // The body: two-tone so it reads as lit from the upper-left, same
        // trick the coin's face/rim split uses.
        val bodyRect = Rect(Offset(bodyLeft, bodyTop), Size(bodyW, bodyH))
        drawRoundRect(
            color = color.lit(0.62f),
            topLeft = bodyRect.bottomLeft.let { Offset(bodyLeft, bodyTop + bodyH * 0.42f) },
            size = Size(bodyW, bodyH * 0.58f),
            cornerRadius = CornerRadius(w * 0.07f, w * 0.07f),
        )
        drawRoundRect(
            color = color.lit(1.05f),
            topLeft = Offset(bodyLeft, bodyTop),
            size = Size(bodyW, bodyH * 0.62f),
            cornerRadius = CornerRadius(w * 0.07f, w * 0.07f),
        )
        drawRoundRect(
            color = Ink,
            topLeft = Offset(bodyLeft, bodyTop),
            size = Size(bodyW, bodyH),
            cornerRadius = CornerRadius(w * 0.07f, w * 0.07f),
            style = Stroke(o),
        )

        // The keyhole: a small circle over a short wedge.
        val khCx = w / 2f
        val khCy = bodyTop + bodyH * 0.44f
        val khR = w * 0.055f
        drawCircle(Ink, khR, Offset(khCx, khCy))
        drawRect(
            color = Ink,
            topLeft = Offset(khCx - khR * 0.55f, khCy),
            size = Size(khR * 1.1f, khR * 1.6f),
        )
    }
}
