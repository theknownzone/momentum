package com.momentum.focus.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.components.Avatar3D
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

/**
 * The payoff moment.
 *
 * Everything fires at once on purpose — haptic, sound, confetti, a shape
 * punching in with overshoot. Reward has to be loud and immediate or it does
 * not register as reward at all. This is the only screen in the app allowed to
 * shout, which is exactly why it works.
 */
@Composable
fun CelebrationScreen(
    kicker: String,
    title: String,
    body: String,
    colorIndex: Int,
    shapeIndex: Int,
    // Optional content between the body text and the button — the streak
    // celebration uses it for the week's tick row. Nothing else passes it,
    // so every existing call site is unaffected.
    //
    // Placed before onDone, not after. A trailing lambda always fills
    // whichever parameter is *last* in the signature, regardless of name —
    // with extra last, a call site that names extra explicitly and still
    // uses a trailing lambda for onDone (the streak screen does exactly
    // this) has the trailing lambda try to fill extra a second time, and
    // onDone is left with nothing. Keeping onDone last is what every other
    // call site's `{ ... }` is actually relying on.
    extra: (@Composable () -> Unit)? = null,
    // True only for the setup-complete moment (see MainActivity's setupWon).
    // Delegates immediately to AllSetIntro rather than branching deep inside
    // this function's body — the two share nothing but the outer signature;
    // forcing one function to draw both would have meant threading a flag
    // through every layout decision below instead of just not entering it.
    useWordmarkIntro: Boolean = false,
    onDone: () -> Unit,
) {
    if (useWordmarkIntro) {
        AllSetIntro(kicker = kicker, headline = title, subtitle = body, onDone = onDone)
        return
    }
    val haptics = rememberHaptics()
    val str = strings()
    val pop = remember { Animatable(0.2f) }
    val confetti = remember { Animatable(0f) }
    val sticker = stickerFor(colorIndex)

    LaunchedEffect(Unit) {
        haptics.celebrate()
        pop.animateTo(
            1f,
            spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        )
    }
    LaunchedEffect(Unit) {
        confetti.animateTo(1f, tween(2600, easing = LinearEasing))
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Cream)
            .paperGrain(),
        contentAlignment = Alignment.Center,
    ) {
        Confetti(confetti.value)

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 40.dp, bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(1f))

            Box(Modifier.scale(pop.value), contentAlignment = Alignment.Center) {
                // A flat, thick-bordered sticker block behind the shape
                // instead of a soft glow — a glow is a glass trick; every
                // other burst of colour in this app (and the reference this
                // whole redesign is chasing) is a flat sticker with an ink
                // outline and a hard offset shadow, never a blur. This is
                // that same block, sized to read as impact rather than as a
                // rounded card, so it still feels like a bang, not a badge.
                Box(
                    Modifier
                        .size(190.dp)
                        .celebrationShadow(color = Ink)
                        .clip(RoundedCornerShape(38.dp))
                        .graphicsLayer { rotationZ = -3f }
                        .background(sticker.fill)
                        .border(4.dp, Ink, RoundedCornerShape(38.dp)),
                )
                Avatar3D(colorIndex = colorIndex, shapeIndex = shapeIndex, size = 150.dp)
            }

            Spacer(Modifier.height(28.dp))

            Text(
                kicker,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = InkMid,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                title,
                style = MaterialTheme.typography.displayMedium,
                color = Ink,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                body,
                style = MaterialTheme.typography.bodyLarge,
                color = InkMid,
                textAlign = TextAlign.Center,
            )

            if (extra != null) {
                Spacer(Modifier.height(20.dp))
                extra()
            }

            Spacer(Modifier.weight(1f))

            SquishButton(
                label = str.focus.keepGoing,
                sticker = sticker,
                modifier = Modifier.fillMaxWidth(),
                onClick = onDone,
            )
        }
    }
}

/** Same hard, un-blurred offset shadow trick as Plans' cards — see the longer version of this comment in PlansScreen.kt. */
private fun Modifier.celebrationShadow(offset: androidx.compose.ui.unit.Dp = 6.dp, color: Color = Ink): Modifier =
    androidx.compose.ui.draw.drawBehind {
        drawRoundRect(
            color = color,
            topLeft = Offset(offset.toPx(), offset.toPx()),
            size = size,
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(38.dp.toPx(), 38.dp.toPx()),
        )
    }

/**
 * Confetti as plain rectangles falling on sine paths.
 *
 * A particle system would be overkill: at this size the eye reads colour and
 * motion, not shape, so fifty rectangles with different phases is enough and
 * costs nothing.
 */
/**
 * Confetti with actual depth — near pieces bigger and faster, far pieces
 * smaller and slower, each one spinning rather than falling flat-faced, on
 * a colour palette pulled wider than one sticker cycle. Was fifty 6–14px
 * rectangles with no rotation and one size class; at that size and that
 * uniformity it read as scattered debris rather than confetti, which is
 * exactly what it looked like on screen.
 */
@Composable
private fun Confetti(progress: Float) {
    val palette = remember {
        listOf(
            Mint.fill, Sky.fill, Lilac.fill, GoldNeon, Tang.fill, Candy.fill, Butter.fill,
        )
    }
    val pieces = remember {
        val rng = Random(9)
        List(90) { index ->
            val near = index % 2 == 0
            ConfettiPiece(
                x = rng.nextFloat(),
                delay = rng.nextFloat() * 0.30f,
                speed = if (near) 0.85f + rng.nextFloat() * 0.55f else 0.55f + rng.nextFloat() * 0.40f,
                drift = (rng.nextFloat() - 0.5f) * (if (near) 0.26f else 0.14f),
                width = if (near) 10f + rng.nextFloat() * 10f else 5f + rng.nextFloat() * 6f,
                height = if (near) 16f + rng.nextFloat() * 14f else 8f + rng.nextFloat() * 10f,
                color = palette[rng.nextInt(palette.size)],
                phase = rng.nextFloat() * 6.28f,
                spin = (if (index % 2 == 0) 1f else -1f) * (0.5f + rng.nextFloat() * 0.9f),
                alpha = if (near) 0.95f else 0.55f,
            )
        }
    }

    Canvas(Modifier.fillMaxSize()) {
        pieces.forEach { p ->
            val t = ((progress - p.delay) * p.speed).coerceIn(0f, 1f)
            if (t <= 0f) return@forEach
            val y = t * (size.height + 140f) - 70f
            val x = p.x * size.width + sin(t * 6f + p.phase) * size.width * p.drift
            rotate(degrees = t * 360f * p.spin, pivot = Offset(x, y)) {
                drawRect(
                    color = p.color.copy(alpha = (p.alpha * (1f - t * 0.6f)).coerceIn(0f, 1f)),
                    topLeft = Offset(x - p.width / 2f, y - p.height / 2f),
                    size = Size(p.width, p.height),
                )
            }
        }
    }
}

private data class ConfettiPiece(
    val x: Float,
    val delay: Float,
    val speed: Float,
    val drift: Float,
    val width: Float,
    val height: Float,
    val color: Color,
    val phase: Float,
    val spin: Float,
    val alpha: Float,
)

/**
 * The one-time "setup is actually done" moment — a hanami rather than
 * confetti, and the real ring animation (the cleaned Veo clip, watermark
 * removed, in res/raw/celebration_ring) standing in for the "o" in
 * Momentum as it types itself out, instead of a generic avatar shape.
 *
 * The video plays through Android's built-in [VideoView] rather than
 * pulling in ExoPlayer for one three-second silent clip — muted at the
 * MediaPlayer level (its own audio track was stripped when it was trimmed
 * for this anyway; the beats here are this app's own [Sound.FESTIVE] and
 * [rememberHaptics]'s `unlock()`, not whatever the source clip carried).
 *
 * Timing mirrors the HTML preview this was built and approved from:
 * kicker first, then "M", then the ring drops into the "o" slot with a
 * rising chime, then "mentum" types across the same span the clip runs,
 * finishing as the ring seals — which is also when the brighter
 * `haptics.unlock()` beat lands.
 */
@Composable
private fun AllSetIntro(
    kicker: String,
    headline: String,
    subtitle: String,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()
    val context = LocalContext.current
    var elapsedMs by remember { mutableFloatStateOf(0f) }
    var fallFired by remember { mutableStateOf(false) }
    var sealFired by remember { mutableStateOf(false) }
    var playVideo by remember { mutableStateOf(false) }
    // Guards onDone against firing twice — once from whichever finishes
    // first, the auto-advance below or a manual tap on Continue while it's
    // still waiting to fire on its own.
    var advanced by remember { mutableStateOf(false) }
    fun advance() {
        if (!advanced) {
            advanced = true
            onDone()
        }
    }

    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        // Was capped at 6500ms — settle (wordSpanStart + 5380 = 6580ms here)
        // plus the button's own +600ms delay meant the loop stopped
        // incrementing elapsedMs before "elapsedMs > settle + 600f" could
        // ever be true. The screen would sit fully formed minus its own
        // Continue button, permanently — not a hang, but the same practical
        // dead end one would have been. Capped past the last threshold any
        // element in this composable actually waits on, with headroom.
        while (elapsedMs < 7500f) {
            withFrameNanos { now -> elapsedMs = (now - start) / 1_000_000f }
        }
    }

    // Auto-advances into Home on its own, the beat after everything has
    // finished settling — this was a screen someone had to personally
    // dismiss before, the one place in the app's whole reveal chain that
    // still asked for a tap instead of just finishing and moving on.
    // Continue stays on screen the whole time as the one manual way out
    // for anyone who doesn't want to wait for it.
    LaunchedEffect(Unit) {
        delay(8600)
        advance()
    }

    val kickerShown = elapsedMs > 120f
    val mShown = elapsedMs > 900f
    val videoShown = elapsedMs > 1200f
    val letters = "mentum"
    val wordSpanStart = 1200f
    val wordSpanEnd = 4980f
    val step = (wordSpanEnd - wordSpanStart) / letters.length
    val settle = wordSpanStart + 5380f

    if (videoShown && !fallFired) {
        fallFired = true
        playVideo = true
        Sfx.playOnce(Sound.FESTIVE)
        haptics.tick()
    }
    // Realigned to when the ring's own animation actually seals (1500ms
    // trace + 400ms fall after wordSpanStart) rather than the old fixed
    // 3100ms offset, which was timed against the video clip's own internal
    // pacing — a timeline this Canvas animation doesn't share. Left as the
    // old number, the buzz would have landed a second and a half after the
    // dot had already visibly closed the ring.
    if (elapsedMs > wordSpanStart + 1850f && !sealFired) {
        sealFired = true
        haptics.unlock()
    }

    val petal = Color(0xFFFFB7C5)
    // Was elapsedMs / 1000f — tied to the exact same timer that caps at
    // 7500ms for the letter-reveal sequence, so the petals froze in place
    // the instant that loop stopped incrementing, on a screen someone can
    // now sit on for several extra seconds before auto-advancing. Its own
    // infinite transition, decoupled from the one-shot reveal clock, so
    // the drift keeps going for as long as this screen is actually shown.
    val petalInfinite = rememberInfiniteTransition(label = "petal-drift")
    val drift by petalInfinite.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(tween(1_000_000, easing = LinearEasing)),
        label = "drift",
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF120B1E), Color(0xFF2A1220), Color(0xFF120A12)),
                ),
            ),
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            repeat(220) { i ->
                val speed = 0.10f + rndF(i, 500) * 0.16f
                val born = rndF(i, 501)
                val y = h * 0.05f + ((drift * speed + rndF(i, 502)) % 1f) * (h * 1.05f)
                val sway = sin((drift * speed * 2.4f + rndF(i, 503)) * 6.283f) * w * 0.05f
                val x = born * w + sway
                val r = 3f + rndF(i, 504) * 5f
                val a = 0.30f + rndF(i, 505) * 0.4f
                drawOval(
                    color = petal.copy(alpha = a),
                    topLeft = Offset(x - r, y - r * 0.55f),
                    size = Size(r * 2f, r * 1.1f),
                )
            }
        }

        Column(
            Modifier.fillMaxSize().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                kicker,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black,
                color = Color(0xFFF2F2F5),
                modifier = Modifier
                    // Reads elapsedMs directly inside graphicsLayer's own
                    // lambda rather than via the kickerShown val — a value
                    // read at the top of the composable's body still counts
                    // as a composition-time read of elapsedMs, so the fix
                    // wasn't complete until the read itself moved here,
                    // where graphicsLayer only triggers a redraw, not a
                    // recomposition of everything downstream of it.
                    .graphicsLayer {
                        alpha = if (elapsedMs > 120f) 1f else 0f
                        translationY = if (elapsedMs > 120f) 0f else 8f
                    },
            )
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                WordChar("M", mShown)
                Box(
                    Modifier
                        .size(52.dp)
                        .graphicsLayer {
                            alpha = if (playVideo) 1f else 0f
                            translationY = if (playVideo) 0f else -120f
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    // The ring, drawn rather than played — a VideoView here
                    // caused a real hang once already this session (stuck
                    // mid-typeout, no petals, no sound), and a video file
                    // is real risk for what is otherwise the safest kind of
                    // effect in this codebase: this project now has four
                    // working Canvas animations (ChromaticRing, laserEdge,
                    // CeramicProgressBar, the billboard sweep),
                    // all built exactly this way, none of them ever hanging.
                    // Same shape as the source clip: ring traces in, a dot
                    // drops into the gap, a warm flash on contact.
                    val ringT = ((elapsedMs - wordSpanStart) / 1500f).coerceIn(0f, 1f)
                    val fallT = (((elapsedMs - wordSpanStart) - 1500f) / 400f).coerceIn(0f, 1f)
                    val flashT = (((elapsedMs - wordSpanStart) - 1850f) / 500f).coerceIn(0f, 1f)
                    Canvas(Modifier.fillMaxSize()) {
                        val cx = size.width / 2f
                        val cy = size.height / 2f
                        val r = size.minDimension * 0.38f
                        val gapDeg = 40f
                        val sweep = (360f - gapDeg) * ringT
                        drawArc(
                            color = Color(0xFF2BE39B),
                            startAngle = -90f + gapDeg / 2f,
                            sweepAngle = sweep,
                            useCenter = false,
                            topLeft = Offset(cx - r, cy - r),
                            size = Size(r * 2f, r * 2f),
                            style = Stroke(width = size.width * 0.11f, cap = StrokeCap.Round),
                        )
                        if (fallT > 0f) {
                            val dotY = cy - r + (1f - fallT) * -r * 0.9f
                            drawCircle(
                                color = Color(0xFFF2F2F5),
                                radius = size.width * 0.075f,
                                center = Offset(cx, dotY),
                            )
                        }
                        if (flashT in 0f..1f) {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    listOf(
                                        Color(0xFFFFD84D).copy(alpha = 0.8f * (1f - flashT)),
                                        Color.Transparent,
                                    ),
                                    center = Offset(cx, cy - r),
                                    radius = r * (0.6f + flashT * 0.8f),
                                ),
                                radius = r * (0.6f + flashT * 0.8f),
                                center = Offset(cx, cy - r),
                            )
                        }
                    }
                }
                letters.forEachIndexed { i, ch ->
                    WordChar(ch.toString(), elapsedMs > wordSpanStart + step * (i + 1))
                }
            }
            Spacer(Modifier.height(20.dp))
            Text(
                headline,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = if (elapsedMs > settle) 1f else 0f },
            )
            Spacer(Modifier.height(8.dp))
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.65f),
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = if (elapsedMs > settle + 300f) 1f else 0f },
            )
            Spacer(Modifier.height(26.dp))
            val ctaInteraction = remember { MutableInteractionSource() }
            val ctaPressed by ctaInteraction.collectIsPressedAsState()
            val ctaBurst by animateFloatAsState(
                if (ctaPressed) 0.96f else 1f,
                spring(dampingRatio = 0.35f, stiffness = 700f),
                label = "cta-burst",
            )
            Box(
                Modifier
                    .fillMaxWidth()
                    .graphicsLayer { alpha = if (elapsedMs > settle + 600f) 1f else 0f }
                    .height(64.dp)
                    // The reference's own layered comic-brutal button,
                    // simplified for touch (no hover state to carry the
                    // halftone/ink-splatter/dashed-focus layers, which only
                    // ever showed on a cursor hovering, never on a finger) —
                    // kept the three things that do translate: the offset
                    // hard-shadow panel, the accent frame peeking out behind
                    // it, and a burst on press. One-off for this specific
                    // "you're in" button rather than something reused
                    // app-wide, which SquishButton's own plainer 3D-press
                    // already covers everywhere else.
                    .graphicsLayer { rotationZ = -2f },
            ) {
                Box(
                    Modifier
                        .matchParentSize()
                        .padding(top = 6.dp, start = 6.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1A0E14)),
                )
                Box(
                    Modifier
                        .matchParentSize()
                        .padding(top = 3.dp, start = 3.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFFFEF00)),
                )
                Box(
                    Modifier
                        .matchParentSize()
                        .graphicsLayer {
                            scaleX = ctaBurst; scaleY = ctaBurst
                        }
                        .clip(RoundedCornerShape(16.dp))
                        .background(Brush.horizontalGradient(listOf(Mint.fill, Color(0xFF6EE6B8))))
                        .border(2.dp, Ink, RoundedCornerShape(16.dp))
                        .clickableNoRipple(ctaInteraction, onClick = { advance() }),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "Continue",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = Ink,
                    )
                }
            }
        }
    }
}

/** One letter of the wordmark, blurring in the same way TypedGreeting's do. */
@Composable
private fun WordChar(char: String, visible: Boolean) {
    val t by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(190, easing = LinearOutSlowInEasing),
        label = "wordchar",
    )
    if (t <= 0f) return
    Text(
        char,
        style = MaterialTheme.typography.displaySmall,
        fontWeight = FontWeight.ExtraBold,
        color = Color(0xFFF2F2F5),
        modifier = Modifier
            .alpha(t)
            .graphicsLayer {
                translationX = (1f - t) * -6f
                if (android.os.Build.VERSION.SDK_INT >= 31) {
                    val radius = ((1f - t) * 7f).coerceAtLeast(0.01f)
                    renderEffect = android.graphics.RenderEffect
                        .createBlurEffect(radius, radius, android.graphics.Shader.TileMode.CLAMP)
                        .asComposeRenderEffect()
                }
            },
    )
}

// Deterministic pseudo-random in 0..1, same trick used throughout
// SkinWeather — named distinctly from that file's rnd() since this one
// lives here instead of importing across screens for a single helper.
private fun rndF(i: Int, salt: Int): Float {
    val x = sin((i * 12.9898 + salt * 78.233)) * 43758.5453
    return (x - kotlin.math.floor(x)).toFloat()
}
