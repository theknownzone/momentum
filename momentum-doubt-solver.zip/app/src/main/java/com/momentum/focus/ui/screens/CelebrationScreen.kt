package com.momentum.focus.ui.screens

import kotlin.math.PI
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.components.Avatar3D
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

/**
 * The payoff moment.
 *
 * Everything fires at once on purpose — haptic, sound, confetti, a shape
 * punching in with overshoot. Reward has to be loud and immediate or it does
 * not register as reward at all. This is the only screen in the app allowed to
 * shout, which is exactly why it works.
 */
@Composable
fun CelebrationScreen(
    kicker: String,
    title: String,
    body: String,
    colorIndex: Int,
    shapeIndex: Int,
    // Optional content between the body text and the button — the streak
    // celebration uses it for the week's tick row. Nothing else passes it,
    // so every existing call site is unaffected.
    //
    // Placed before onDone, not after. A trailing lambda always fills
    // whichever parameter is *last* in the signature, regardless of name —
    // with extra last, a call site that names extra explicitly and still
    // uses a trailing lambda for onDone (the streak screen does exactly
    // this) has the trailing lambda try to fill extra a second time, and
    // onDone is left with nothing. Keeping onDone last is what every other
    // call site's `{ ... }` is actually relying on.
    extra: (@Composable () -> Unit)? = null,
    // True only for the setup-complete moment (see MainActivity's setupWon).
    // Delegates immediately to AllSetIntro rather than branching deep inside
    // this function's body — the two share nothing but the outer signature;
    // forcing one function to draw both would have meant threading a flag
    // through every layout decision below instead of just not entering it.
    useWordmarkIntro: Boolean = false,
    onDone: () -> Unit,
) {
    if (useWordmarkIntro) {
        AllSetIntro(kicker = kicker, headline = title, subtitle = body, onDone = onDone)
        return
    }
    val haptics = rememberHaptics()
    val str = strings()
    val pop = remember { Animatable(0.2f) }
    val confetti = remember { Animatable(0f) }
    val sticker = stickerFor(colorIndex)

    LaunchedEffect(Unit) {
        haptics.celebrate()
        pop.animateTo(
            1f,
            spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        )
    }
    LaunchedEffect(Unit) {
        confetti.animateTo(1f, tween(2600, easing = LinearEasing))
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Cream)
            .paperGrain(),
        contentAlignment = Alignment.Center,
    ) {
        Confetti(confetti.value)

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 40.dp, bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(1f))

            Box(Modifier.scale(pop.value), contentAlignment = Alignment.Center) {
                // A flat, thick-bordered sticker block behind the shape
                // instead of a soft glow — a glow is a glass trick; every
                // other burst of colour in this app (and the reference this
                // whole redesign is chasing) is a flat sticker with an ink
                // outline and a hard offset shadow, never a blur. This is
                // that same block, sized to read as impact rather than as a
                // rounded card, so it still feels like a bang, not a badge.
                Box(
                    Modifier
                        .size(190.dp)
                        .celebrationShadow(color = Ink)
                        .clip(RoundedCornerShape(38.dp))
                        .graphicsLayer { rotationZ = -3f }
                        .background(sticker.fill)
                        .border(4.dp, Ink, RoundedCornerShape(38.dp)),
                )
                Avatar3D(colorIndex = colorIndex, shapeIndex = shapeIndex, size = 150.dp)
            }

            Spacer(Modifier.height(28.dp))

            Text(
                kicker,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = InkMid,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                title,
                style = MaterialTheme.typography.displayMedium,
                color = Ink,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                body,
                style = MaterialTheme.typography.bodyLarge,
                color = InkMid,
                textAlign = TextAlign.Center,
            )

            if (extra != null) {
                Spacer(Modifier.height(20.dp))
                extra()
            }

            Spacer(Modifier.weight(1f))

            SquishButton(
                label = str.focus.keepGoing,
                sticker = sticker,
                modifier = Modifier.fillMaxWidth(),
                onClick = onDone,
            )
        }
    }
}

/** Same hard, un-blurred offset shadow trick as Plans' cards — see the longer version of this comment in PlansScreen.kt. */
private fun Modifier.celebrationShadow(offset: Dp = 6.dp, color: Color = Ink): Modifier =
    drawBehind {
        drawRoundRect(
            color = color,
            topLeft = Offset(offset.toPx(), offset.toPx()),
            size = size,
            cornerRadius = CornerRadius(38.dp.toPx(), 38.dp.toPx()),
        )
    }

/**
 * Confetti as plain rectangles falling on sine paths.
 *
 * A particle system would be overkill: at this size the eye reads colour and
 * motion, not shape, so fifty rectangles with different phases is enough and
 * costs nothing.
 */
/**
 * Confetti with actual depth — near pieces bigger and faster, far pieces
 * smaller and slower, each one spinning rather than falling flat-faced, on
 * a colour palette pulled wider than one sticker cycle. Was fifty 6–14px
 * rectangles with no rotation and one size class; at that size and that
 * uniformity it read as scattered debris rather than confetti, which is
 * exactly what it looked like on screen.
 */
@Composable
private fun Confetti(progress: Float) {
    val palette = remember {
        listOf(
            Mint.fill, Sky.fill, Lilac.fill, GoldNeon, Tang.fill, Candy.fill, Butter.fill,
        )
    }
    val pieces = remember {
        val rng = Random(9)
        List(90) { index ->
            val near = index % 2 == 0
            ConfettiPiece(
                x = rng.nextFloat(),
                delay = rng.nextFloat() * 0.30f,
                speed = if (near) 0.85f + rng.nextFloat() * 0.55f else 0.55f + rng.nextFloat() * 0.40f,
                drift = (rng.nextFloat() - 0.5f) * (if (near) 0.26f else 0.14f),
                width = if (near) 10f + rng.nextFloat() * 10f else 5f + rng.nextFloat() * 6f,
                height = if (near) 16f + rng.nextFloat() * 14f else 8f + rng.nextFloat() * 10f,
                color = palette[rng.nextInt(palette.size)],
                phase = rng.nextFloat() * 6.28f,
                spin = (if (index % 2 == 0) 1f else -1f) * (0.5f + rng.nextFloat() * 0.9f),
                alpha = if (near) 0.95f else 0.55f,
            )
        }
    }

    Canvas(Modifier.fillMaxSize()) {
        pieces.forEach { p ->
            val t = ((progress - p.delay) * p.speed).coerceIn(0f, 1f)
            if (t <= 0f) return@forEach
            val y = t * (size.height + 140f) - 70f
            val x = p.x * size.width + sin(t * 6f + p.phase) * size.width * p.drift
            rotate(degrees = t * 360f * p.spin, pivot = Offset(x, y)) {
                drawRect(
                    color = p.color.copy(alpha = (p.alpha * (1f - t * 0.6f)).coerceIn(0f, 1f)),
                    topLeft = Offset(x - p.width / 2f, y - p.height / 2f),
                    size = Size(p.width, p.height),
                )
            }
        }
    }
}

private data class ConfettiPiece(
    val x: Float,
    val delay: Float,
    val speed: Float,
    val drift: Float,
    val width: Float,
    val height: Float,
    val color: Color,
    val phase: Float,
    val spin: Float,
    val alpha: Float,
)

/**
 * The one-time "setup is actually done" moment — a hanami rather than
 * confetti, and the real ring animation (the cleaned Veo clip, watermark
 * removed, in res/raw/celebration_ring) standing in for the "o" in
 * Momentum as it types itself out, instead of a generic avatar shape.
 *
 * The video plays through Android's built-in [VideoView] rather than
 * pulling in ExoPlayer for one three-second silent clip — muted at the
 * MediaPlayer level (its own audio track was stripped when it was trimmed
 * for this anyway; the beats here are this app's own [Sound.FESTIVE] and
 * [rememberHaptics]'s `unlock()`, not whatever the source clip carried).
 *
 * Timing mirrors the HTML preview this was built and approved from:
 * kicker first, then "M", then the ring drops into the "o" slot with a
 * rising chime, then "mentum" types across the same span the clip runs,
 * finishing as the ring seals — which is also when the brighter
 * `haptics.unlock()` beat lands.
 */
@Composable
private fun AllSetIntro(
    kicker: String,
    headline: String,
    subtitle: String,
    onDone: () -> Unit,
) {
    // v3 (2026-10-03): rebuilt from scratch in the app's neo-brutalist print
    // language — paper page, ink stamp, sticker checklist, flat confetti.
    // ~1.4s to the button; no video, no starfield.
    val haptics = rememberHaptics()
    var step by remember { mutableIntStateOf(0) }
    var advanced by remember { mutableStateOf(false) }
    fun advance() { if (!advanced) { advanced = true; onDone() } }

    val shake = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(120)
        step = 1                                   // stamp slams
        Sfx.play(Sound.LEVEL); haptics.unlock()
        listOf(9f, -7f, 4f, -2f, 0f).forEach { shake.animateTo(it, tween(40)) }
        repeat(3) { i -> delay(110); step = 2 + i; Sfx.play(Sound.TICK); haptics.tick() }  // 2,3,4 checklist
        delay(120); step = 5                       // headline + confetti
        delay(380); step = 6                       // CTA
        delay(7000); advance()
    }
    BackHandler { advance() }

    val stampIn by animateFloatAsState(if (step >= 1) 1f else 0f, tween(220, easing = FastOutSlowInEasing), label = "stamp")
    val confetti = remember { Animatable(0f) }
    LaunchedEffect(step >= 5) { if (step >= 5) confetti.animateTo(1f, tween(1600, easing = LinearEasing)) }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .graphicsLayer { translationX = shake.value },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 36.dp, bottom = 20.dp),
        ) {
            Text(
                kicker,
                style = MaterialTheme.typography.labelSmall,
                letterSpacing = 1.8.sp,
                fontWeight = FontWeight.Black,
                color = InkMid,
                modifier = Modifier.graphicsLayer { alpha = stampIn },
            )
            Spacer(Modifier.height(14.dp))
            // The stamp: oversized, slams down to size and settles at a tilt.
            Box(
                Modifier
                    .graphicsLayer {
                        val sc = 1.7f - 0.7f * stampIn
                        scaleX = sc; scaleY = sc
                        alpha = stampIn
                        rotationZ = -9f + 5f * stampIn
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
                    }
                    .celebrationShadow(offset = 7.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Mint.fill)
                    .border(Paper.Outline, Ink, RoundedCornerShape(12.dp))
                    .padding(horizontal = 18.dp, vertical = 6.dp),
            ) {
                Text(
                    com.momentum.focus.data.tr("ALL SET", "सब तैयार"),
                    fontSize = 54.sp,
                    lineHeight = 56.sp,
                    fontWeight = FontWeight.Black,
                    color = Ink,
                )
            }

            Spacer(Modifier.height(26.dp))
            val checks = listOf(
                Triple(com.momentum.focus.data.tr("Feeds blocked", "फ़ीड बंद"), Butter.fill, 2),
                Triple(com.momentum.focus.data.tr("Timer armed", "टाइमर तैयार"), Sky.fill, 3),
                Triple(com.momentum.focus.data.tr("Wallet open", "वॉलेट खुला"), Candy.fill, 4),
            )
            checks.forEachIndexed { i, (label, fill, at) ->
                val t by animateFloatAsState(if (step >= at) 1f else 0f, tween(220, easing = FastOutSlowInEasing), label = "chk$i")
                Row(
                    Modifier
                        .padding(bottom = 10.dp, start = (i * 14).dp)
                        .graphicsLayer {
                            alpha = t
                            translationX = (1f - t) * 80.dp.toPx()
                            rotationZ = (if (i % 2 == 0) -1.5f else 1.5f) * t
                        }
                        .celebrationShadow(offset = 4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(fill)
                        .border(2.5.dp, Ink, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.size(22.dp).clip(CircleShape).background(Ink),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("✓", color = Mint.fill, fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = Ink)
                }
            }

            Spacer(Modifier.height(18.dp))
            if (step >= 5) {
                WordReveal(headline)
                Spacer(Modifier.height(8.dp))
                FadeUp(delayMs = 220) {
                    Text(subtitle, style = MaterialTheme.typography.bodyLarge, color = InkMid)
                }
            }

            Spacer(Modifier.weight(1f))
            val ctaIn by animateFloatAsState(if (step >= 6) 1f else 0f, tween(260, easing = FastOutSlowInEasing), label = "cta")
            Box(Modifier.graphicsLayer { alpha = ctaIn; translationY = (1f - ctaIn) * 24.dp.toPx() }) {
                PrimaryButton(com.momentum.focus.data.tr("Lock in →", "शुरू करें →"), enabled = true) {
                    if (ctaIn > 0.5f) { haptics.confirm(); Sfx.play(Sound.BEGIN); advance() }
                }
            }
        }

        // Flat print confetti: ink-outlined squares, triangles, dots, bursting
        // from the stamp and falling under gravity. Drawn over everything.
        if (confetti.value in 0.001f..0.999f) {
            Canvas(Modifier.fillMaxSize()) {
                val p = confetti.value
                val ox = size.width * 0.32f
                val oy = size.height * 0.20f
                val cols = listOf(Mint.fill, Butter.fill, Tang.fill, Sky.fill, Candy.fill, Lilac.fill)
                repeat(34) { i ->
                    val ang = (rndF(i, 1) * 300f - 240f) * (PI.toFloat() / 180f)
                    val v = 0.9f + rndF(i, 2) * 1.3f
                    val x = ox + kotlin.math.cos(ang) * v * size.width * 0.55f * p
                    val y = oy + kotlin.math.sin(ang) * v * size.width * 0.55f * p + size.height * 0.9f * p * p
                    val s = (7f + rndF(i, 3) * 9f) * density / 2.6f
                    val c = cols[i % cols.size].copy(alpha = 1f - p * p)
                    val ink = Ink.copy(alpha = 1f - p * p)
                    rotate(rndF(i, 4) * 360f + p * 540f * (if (i % 2 == 0) 1 else -1), Offset(x, y)) {
                        when (i % 3) {
                            0 -> {
                                drawRect(c, Offset(x - s, y - s), Size(s * 2, s * 2))
                                drawRect(ink, Offset(x - s, y - s), Size(s * 2, s * 2), style = Stroke(2f))
                            }
                            1 -> {
                                val path = androidx.compose.ui.graphics.Path().apply {
                                    moveTo(x, y - s * 1.2f); lineTo(x + s, y + s); lineTo(x - s, y + s); close()
                                }
                                drawPath(path, c); drawPath(path, ink, style = Stroke(2f))
                            }
                            else -> {
                                drawCircle(c, s, Offset(x, y)); drawCircle(ink, s, Offset(x, y), style = Stroke(2f))
                            }
                        }
                    }
                }
            }
        }
    }
}

/** One letter of the wordmark, blurring in the same way TypedGreeting's do. */
@Composable
private fun WordChar(char: String, visible: Boolean) {
    val t by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(190, easing = LinearOutSlowInEasing),
        label = "wordchar",
    )
    if (t <= 0f) return
    Text(
        char,
        style = MaterialTheme.typography.displaySmall,
        fontWeight = FontWeight.ExtraBold,
        color = Color(0xFFF2F2F5),
        modifier = Modifier
            .alpha(t)
            .graphicsLayer {
                translationX = (1f - t) * -6f
                if (android.os.Build.VERSION.SDK_INT >= 31) {
                    val radius = ((1f - t) * 7f).coerceAtLeast(0.01f)
                    renderEffect = android.graphics.RenderEffect
                        .createBlurEffect(radius, radius, android.graphics.Shader.TileMode.CLAMP)
                        .asComposeRenderEffect()
                }
            },
    )
}

// Deterministic pseudo-random in 0..1, same trick used throughout
// SkinWeather — named distinctly from that file's rnd() since this one
// lives here instead of importing across screens for a single helper.
private fun rndF(i: Int, salt: Int): Float {
    val x = sin((i * 12.9898 + salt * 78.233)) * 43758.5453
    return (x - kotlin.math.floor(x)).toFloat()
}
