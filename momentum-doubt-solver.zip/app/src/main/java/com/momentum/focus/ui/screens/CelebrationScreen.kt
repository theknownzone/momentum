package com.momentum.focus.ui.screens

import android.net.Uri
import android.widget.VideoView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.momentum.focus.R
import com.momentum.focus.ui.components.Avatar3D
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.sin
import kotlin.random.Random

/**
 * The payoff moment.
 *
 * Everything fires at once on purpose — haptic, sound, confetti, a shape
 * punching in with overshoot. Reward has to be loud and immediate or it does
 * not register as reward at all. This is the only screen in the app allowed to
 * shout, which is exactly why it works.
 */
@Composable
fun CelebrationScreen(
    kicker: String,
    title: String,
    body: String,
    colorIndex: Int,
    shapeIndex: Int,
    // Optional content between the body text and the button — the streak
    // celebration uses it for the week's tick row. Nothing else passes it,
    // so every existing call site is unaffected.
    //
    // Placed before onDone, not after. A trailing lambda always fills
    // whichever parameter is *last* in the signature, regardless of name —
    // with extra last, a call site that names extra explicitly and still
    // uses a trailing lambda for onDone (the streak screen does exactly
    // this) has the trailing lambda try to fill extra a second time, and
    // onDone is left with nothing. Keeping onDone last is what every other
    // call site's `{ ... }` is actually relying on.
    extra: (@Composable () -> Unit)? = null,
    // True only for the setup-complete moment (see MainActivity's setupWon).
    // Delegates immediately to AllSetIntro rather than branching deep inside
    // this function's body — the two share nothing but the outer signature;
    // forcing one function to draw both would have meant threading a flag
    // through every layout decision below instead of just not entering it.
    useWordmarkIntro: Boolean = false,
    onDone: () -> Unit,
) {
    if (useWordmarkIntro) {
        AllSetIntro(kicker = kicker, headline = title, subtitle = body, onDone = onDone)
        return
    }
    val haptics = rememberHaptics()
    val str = strings()
    val pop = remember { Animatable(0.2f) }
    val confetti = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        haptics.celebrate()
        pop.animateTo(
            1f,
            spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        )
    }
    LaunchedEffect(Unit) {
        confetti.animateTo(1f, tween(2600, easing = LinearEasing))
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Ink),
        contentAlignment = Alignment.Center,
    ) {
        Confetti(confetti.value)

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 40.dp, bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(1f))

            Box(Modifier.scale(pop.value), contentAlignment = Alignment.Center) {
                // A burst of light behind the shape rather than the shape
                // sitting alone on flat Ink — the one thing missing that
                // made "tagda" (a real impact) instead of just a bigger
                // icon popping in.
                Canvas(Modifier.size(260.dp)) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(
                                stickerFor(colorIndex).fill.copy(alpha = 0.35f * pop.value),
                                stickerFor(colorIndex).fill.copy(alpha = 0.12f * pop.value),
                                Color.Transparent,
                            ),
                        ),
                        radius = size.minDimension / 2f,
                    )
                }
                Avatar3D(colorIndex = colorIndex, shapeIndex = shapeIndex, size = 150.dp)
            }

            Spacer(Modifier.height(28.dp))

            Text(
                kicker,
                style = MaterialTheme.typography.labelSmall,
                color = stickerFor(colorIndex).fill,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                title,
                style = MaterialTheme.typography.displayMedium,
                color = CreamCard,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                body,
                style = MaterialTheme.typography.bodyLarge,
                color = InkLow,
                textAlign = TextAlign.Center,
            )

            if (extra != null) {
                Spacer(Modifier.height(20.dp))
                extra()
            }

            Spacer(Modifier.weight(1f))

            SquishButton(
                label = str.focus.keepGoing,
                sticker = stickerFor(colorIndex),
                modifier = Modifier.fillMaxWidth(),
                onClick = onDone,
            )
        }
    }
}

/**
 * Confetti as plain rectangles falling on sine paths.
 *
 * A particle system would be overkill: at this size the eye reads colour and
 * motion, not shape, so fifty rectangles with different phases is enough and
 * costs nothing.
 */
/**
 * Confetti with actual depth — near pieces bigger and faster, far pieces
 * smaller and slower, each one spinning rather than falling flat-faced, on
 * a colour palette pulled wider than one sticker cycle. Was fifty 6–14px
 * rectangles with no rotation and one size class; at that size and that
 * uniformity it read as scattered debris rather than confetti, which is
 * exactly what it looked like on screen.
 */
@Composable
private fun Confetti(progress: Float) {
    val palette = remember {
        listOf(
            Mint.fill, Sky.fill, Lilac.fill, GoldNeon, Tang.fill, Candy.fill, Butter.fill,
        )
    }
    val pieces = remember {
        val rng = Random(9)
        List(90) { index ->
            val near = index % 2 == 0
            ConfettiPiece(
                x = rng.nextFloat(),
                delay = rng.nextFloat() * 0.30f,
                speed = if (near) 0.85f + rng.nextFloat() * 0.55f else 0.55f + rng.nextFloat() * 0.40f,
                drift = (rng.nextFloat() - 0.5f) * (if (near) 0.26f else 0.14f),
                width = if (near) 10f + rng.nextFloat() * 10f else 5f + rng.nextFloat() * 6f,
                height = if (near) 16f + rng.nextFloat() * 14f else 8f + rng.nextFloat() * 10f,
                color = palette[rng.nextInt(palette.size)],
                phase = rng.nextFloat() * 6.28f,
                spin = (if (index % 2 == 0) 1f else -1f) * (0.5f + rng.nextFloat() * 0.9f),
                alpha = if (near) 0.95f else 0.55f,
            )
        }
    }

    Canvas(Modifier.fillMaxSize()) {
        pieces.forEach { p ->
            val t = ((progress - p.delay) * p.speed).coerceIn(0f, 1f)
            if (t <= 0f) return@forEach
            val y = t * (size.height + 140f) - 70f
            val x = p.x * size.width + sin(t * 6f + p.phase) * size.width * p.drift
            rotate(degrees = t * 360f * p.spin, pivot = Offset(x, y)) {
                drawRect(
                    color = p.color.copy(alpha = (p.alpha * (1f - t * 0.6f)).coerceIn(0f, 1f)),
                    topLeft = Offset(x - p.width / 2f, y - p.height / 2f),
                    size = Size(p.width, p.height),
                )
            }
        }
    }
}

private data class ConfettiPiece(
    val x: Float,
    val delay: Float,
    val speed: Float,
    val drift: Float,
    val width: Float,
    val height: Float,
    val color: Color,
    val phase: Float,
    val spin: Float,
    val alpha: Float,
)

/**
 * The one-time "setup is actually done" moment — a hanami rather than
 * confetti, and the real ring animation (the cleaned Veo clip, watermark
 * removed, in res/raw/celebration_ring) standing in for the "o" in
 * Momentum as it types itself out, instead of a generic avatar shape.
 *
 * The video plays through Android's built-in [VideoView] rather than
 * pulling in ExoPlayer for one three-second silent clip — muted at the
 * MediaPlayer level (its own audio track was stripped when it was trimmed
 * for this anyway; the beats here are this app's own [Sound.FESTIVE] and
 * [rememberHaptics]'s `unlock()`, not whatever the source clip carried).
 *
 * Timing mirrors the HTML preview this was built and approved from:
 * kicker first, then "M", then the ring drops into the "o" slot with a
 * rising chime, then "mentum" types across the same span the clip runs,
 * finishing as the ring seals — which is also when the brighter
 * `haptics.unlock()` beat lands.
 */
@Composable
private fun AllSetIntro(
    kicker: String,
    headline: String,
    subtitle: String,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()
    val context = LocalContext.current
    var elapsedMs by remember { mutableFloatStateOf(0f) }
    var fallFired by remember { mutableStateOf(false) }
    var sealFired by remember { mutableStateOf(false) }
    var playVideo by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (elapsedMs < 6500f) {
            withFrameNanos { now -> elapsedMs = (now - start) / 1_000_000f }
        }
    }

    val kickerShown = elapsedMs > 120f
    val mShown = elapsedMs > 900f
    val videoShown = elapsedMs > 1200f
    val letters = "mentum"
    val wordSpanStart = 1200f
    val wordSpanEnd = 4980f
    val step = (wordSpanEnd - wordSpanStart) / letters.length
    val settle = wordSpanStart + 5380f

    if (videoShown && !fallFired) {
        fallFired = true
        playVideo = true
        Sfx.playOnce(Sound.FESTIVE)
        haptics.tick()
    }
    if (elapsedMs > wordSpanStart + 3100f && !sealFired) {
        sealFired = true
        haptics.unlock()
    }

    val petal = Color(0xFFFFB7C5)
    val drift = elapsedMs / 1000f

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF120B1E), Color(0xFF2A1220), Color(0xFF120A12)),
                ),
            ),
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            repeat(220) { i ->
                val speed = 0.10f + rndF(i, 500) * 0.16f
                val born = rndF(i, 501)
                val y = h * 0.05f + ((drift * speed + rndF(i, 502)) % 1f) * (h * 1.05f)
                val sway = sin((drift * speed * 2.4f + rndF(i, 503)) * 6.283f) * w * 0.05f
                val x = born * w + sway
                val r = 3f + rndF(i, 504) * 5f
                val a = 0.30f + rndF(i, 505) * 0.4f
                drawOval(
                    color = petal.copy(alpha = a),
                    topLeft = Offset(x - r, y - r * 0.55f),
                    size = Size(r * 2f, r * 1.1f),
                )
            }
        }

        Column(
            Modifier.fillMaxSize().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                kicker,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black,
                color = Color(0xFFF2F2F5),
                modifier = Modifier
                    .alpha(if (kickerShown) 1f else 0f)
                    .graphicsLayer { translationY = if (kickerShown) 0f else 8f },
            )
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                WordChar("M", mShown)
                Box(
                    Modifier
                        .size(52.dp)
                        .graphicsLayer {
                            alpha = if (playVideo) 1f else 0f
                            translationY = if (playVideo) 0f else -120f
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    AndroidView(
                        modifier = Modifier.matchParentSize(),
                        factory = { ctx ->
                            VideoView(ctx).apply {
                                setVideoURI(
                                    Uri.parse(
                                        "android.resource://${ctx.packageName}/${R.raw.celebration_ring}",
                                    ),
                                )
                                setOnPreparedListener { mp ->
                                    mp.setVolume(0f, 0f)
                                    mp.isLooping = false
                                }
                            }
                        },
                        update = { view ->
                            if (playVideo) {
                                view.seekTo(0)
                                view.start()
                            }
                        },
                    )
                }
                letters.forEachIndexed { i, ch ->
                    WordChar(ch.toString(), elapsedMs > wordSpanStart + step * (i + 1))
                }
            }
            Spacer(Modifier.height(20.dp))
            Text(
                headline,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.alpha(if (elapsedMs > settle) 1f else 0f),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.65f),
                textAlign = TextAlign.Center,
                modifier = Modifier.alpha(if (elapsedMs > settle + 300f) 1f else 0f),
            )
            Spacer(Modifier.height(26.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .alpha(if (elapsedMs > settle + 600f) 1f else 0f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFFFFB7C5), Color(0xFFFF8FB1))))
                    .border(1.dp, Color.White.copy(alpha = 0.30f), RoundedCornerShape(16.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onDone)
                    .padding(vertical = 15.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "Continue",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1A0E14),
                )
            }
        }
    }
}

/** One letter of the wordmark, blurring in the same way TypedGreeting's do. */
@Composable
private fun WordChar(char: String, visible: Boolean) {
    val t by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(190, easing = LinearOutSlowInEasing),
        label = "wordchar",
    )
    if (t <= 0f) return
    Text(
        char,
        style = MaterialTheme.typography.displaySmall,
        fontWeight = FontWeight.ExtraBold,
        color = Color(0xFFF2F2F5),
        modifier = Modifier
            .alpha(t)
            .graphicsLayer {
                translationX = (1f - t) * -6f
                if (android.os.Build.VERSION.SDK_INT >= 31) {
                    val radius = ((1f - t) * 7f).coerceAtLeast(0.01f)
                    renderEffect = android.graphics.RenderEffect
                        .createBlurEffect(radius, radius, android.graphics.Shader.TileMode.CLAMP)
                        .asComposeRenderEffect()
                }
            },
    )
}

// Deterministic pseudo-random in 0..1, same trick used throughout
// SkinWeather — named distinctly from that file's rnd() since this one
// lives here instead of importing across screens for a single helper.
private fun rndF(i: Int, salt: Int): Float {
    val x = sin((i * 12.9898 + salt * 78.233)) * 43758.5453
    return (x - kotlin.math.floor(x)).toFloat()
}
