package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.Candy
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.PremiumClip
import com.momentum.focus.ui.util.PremiumSfx
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * The Pro upgrade moment (owner-approved HTML preview, ported as-is):
 * plasma dots flood up from the bottom, the bass drops as a scan line starts
 * down, the new playful look is revealed above the line, and it lands with a
 * flash, confetti and the cha-ching in sfx_pro_unlock.
 *
 * 0–600ms flood (veil rises over the old look) · 600 [onFlip] + scan starts ·
 * 600–1300 scan reveals · 1300 flash + confetti · 1900 [onDone].
 *
 * A Popup, so it sits above every screen and dialog that might be open at the
 * moment Pro switches on. Everything animates in the draw phase off one clock.
 */
@Composable
fun ProUpgradeOverlay(onFlip: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val haptics = rememberHaptics()
    val low = remember { DeviceProfile.isLowEnd(ctx) }
    val flip by rememberUpdatedState(onFlip)
    val done by rememberUpdatedState(onDone)
    var t by remember { mutableFloatStateOf(0f) }
    // confetti: fixed seeds so it never reallocates per frame
    val sparks = remember {
        val r = java.util.Random(42)
        List(26) { floatArrayOf((r.nextFloat() * 6.283f), 1.6f + r.nextFloat() * 3.4f, 2f + r.nextFloat() * 3f) }
    }
    LaunchedEffect(Unit) {
        PremiumSfx.playMoment(PremiumClip.PRO_UNLOCK)
        haptics.tap()
        val start = withFrameNanos { it }
        var flipped = false
        var landed = false
        while (t < 1900f) {
            withFrameNanos { now -> t = (now - start) / 1_000_000f }
            if (!flipped && t >= 600f) { flipped = true; haptics.confirm(); flip() }
            if (!landed && t >= 1300f) { landed = true; haptics.confirm() }
        }
        done()
    }
    val cols = listOf(Lilac.fill, Sky.fill, Mint.fill, Candy.fill, Butter.fill)
    val paper = Color(0xFFFBF6EA)
    Popup(properties = PopupProperties(focusable = false, clippingEnabled = false)) {
        Canvas(Modifier.fillMaxSize()) {
            val now = t
            val w = size.width; val h = size.height
            val origin = Offset(w / 2, h - 60.dp.toPx())
            val maxR = hypot(w, h)
            val step = (if (low) 22.dp else 15.dp).toPx()
            var sk = if (now < 600f) 0f else ((now - 600f) / 700f).coerceIn(0f, 1f)
            sk = 1f - (1f - sk) * (1f - sk)
            val yLine = sk * h
            val fade = if (now > 1300f) (1f - (now - 1300f) / 600f).coerceIn(0f, 1f) else 1f
            // veil hides the swap: rises with the flood, then only covers what
            // the scan has not reached yet
            val veilA = when {
                now < 350f -> 0f
                now < 600f -> 0.94f * (now - 350f) / 250f
                now < 1300f -> 0.94f
                else -> 0f
            }
            if (veilA > 0f) drawRect(paper.copy(alpha = veilA), topLeft = Offset(0f, yLine), size = Size(w, h - yLine))
            // plasma dots
            val front = (now / 600f).coerceAtMost(1f) * maxR
            var y = step / 2
            while (y < h) {
                var x = step / 2
                while (x < w) {
                    val d = hypot(x - origin.x, y - origin.y)
                    if (d <= front) {
                        val above = y < yLine
                        val wave = sin((d / density) * 0.05f - now * 0.014f) * 0.5f + 0.5f
                        val edge = (1f - (front - d) / 40.dp.toPx()).coerceIn(0f, 1f)
                        val rad = (1.1f + 3.2f * wave + 2.4f * edge).dp.toPx() * 0.6f * (if (above) 0.5f else 1f) * fade
                        if (rad > 0.4f) {
                            val ci = (((d / density) * 0.022f + now * 0.005f).toInt() % 5 + 5) % 5
                            drawCircle(cols[ci].copy(alpha = (if (above) 0.3f else 0.9f) * fade), rad, Offset(x, y))
                        }
                    }
                    x += step
                }
                y += step
            }
            // scan line: light band + ink line with a pink/cyan split
            if (now in 600f..1420f) {
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0f), Color.White.copy(alpha = 0.8f), Color.White.copy(alpha = 0f)),
                        startY = yLine - 70.dp.toPx(), endY = yLine + 8.dp.toPx(),
                    ),
                    topLeft = Offset(0f, yLine - 70.dp.toPx()), size = Size(w, 78.dp.toPx()),
                )
                drawRect(Candy.fill, Offset(0f, yLine - 4.dp.toPx()), Size(w, 2.dp.toPx()))
                drawRect(Ink, Offset(0f, yLine - 1.5.dp.toPx()), Size(w, 3.dp.toPx()))
                drawRect(Sky.fill, Offset(0f, yLine + 2.dp.toPx()), Size(w, 2.dp.toPx()))
            }
            // landing flash + confetti
            if (now >= 1300f) {
                val lt = now - 1300f
                if (lt < 260f) {
                    drawRect(
                        Brush.radialGradient(
                            listOf(Color.White.copy(alpha = 0.55f * (1f - lt / 260f)), Color.White.copy(alpha = 0f)),
                            center = Offset(w / 2, h * 0.44f), radius = w * 0.9f,
                        ),
                    )
                }
                if (!low) {
                    val f = lt / 16.67f  // frames at 60fps, same physics as the preview
                    sparks.forEachIndexed { i, sp ->
                        val vx = cos(sp[0]) * sp[1]; val vy0 = sin(sp[0]) * sp[1] - 1.2f
                        // drag 0.985/frame and gravity 0.12/frame², summed in closed form
                        val drag = (1f - Math.pow(0.985, f.toDouble()).toFloat()) / 0.015f
                        val px = w / 2 + vx * drag * density
                        val py = h * 0.44f + (vy0 * f + 0.06f * f * (f + 1f)) * density
                        val r = sp[2] * density
                        rotate(degrees = f * 6f + i * 20f, pivot = Offset(px, py)) {
                            drawRect(cols[i % 5].copy(alpha = fade), Offset(px - r, py - r * 0.6f), Size(r * 2, r * 1.2f))
                        }
                    }
                }
            }
        }
    }
}
