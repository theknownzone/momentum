package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound

/**
 * A real shop's roll-down shutter — the reference photo the user sent
 * (a corrugated blue panel, a roller housing above it, side rails, a
 * bottom bar) redrawn in this app's own flat-fill-plus-Ink-outline
 * language rather than pasted in as a photo, the same way the Focus
 * Machine's Lid is a drawn object and not a stock image.
 *
 * This replaces the plain 🔒 emoji the MyAI-locked screen used before —
 * that told you *that* something was locked without committing to any
 * particular image of what. A shutter is a specific, recognisable object,
 * and "the shop is shut" reads instantly in a way a padlock glyph alone
 * doesn't.
 */
@Composable
fun ShopShutter(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val frame = Color(0xFF0E3A63)
        val panel = Color(0xFF2E86D6)
        val ridgeShadow = Color(0xFF1E6BAE)
        val ridgeLight = Color(0xFF6BB4EE)
        val wallRadius = CornerRadius(18.dp.toPx())

        // The wall the shutter is set into.
        drawRoundRect(color = Color(0xFFBFE3F5), size = Size(w, h), cornerRadius = wallRadius)

        // Roller housing along the top.
        val housingH = h * 0.11f
        val housingTop = Offset(w * 0.06f, h * 0.035f)
        val housingSize = Size(w * 0.88f, housingH)
        drawRoundRect(color = frame, topLeft = housingTop, size = housingSize, cornerRadius = CornerRadius(10.dp.toPx()))
        drawRoundRect(color = Ink, topLeft = housingTop, size = housingSize, cornerRadius = CornerRadius(10.dp.toPx()), style = Stroke(3.dp.toPx()))

        // The shutter panel itself.
        val panelTop = housingTop.y + housingH + 5.dp.toPx()
        val panelBottom = h * 0.86f
        val panelLeft = w * 0.09f
        val panelRight = w * 0.91f
        val panelW = panelRight - panelLeft
        val panelH = panelBottom - panelTop

        drawRoundRect(color = panel, topLeft = Offset(panelLeft, panelTop), size = Size(panelW, panelH), cornerRadius = CornerRadius(6.dp.toPx()))

        // Corrugation — repeating horizontal ridges, each a shadow band
        // under a highlight line, the same two-tone trick the coins and
        // the lock body use for "lit from above" everywhere else in the
        // app's icon set.
        val ridges = 13
        val ridgeH = panelH / ridges
        repeat(ridges) { i ->
            val y = panelTop + i * ridgeH
            drawRect(color = ridgeShadow, topLeft = Offset(panelLeft, y + ridgeH * 0.55f), size = Size(panelW, ridgeH * 0.45f))
            drawRect(color = ridgeLight.copy(alpha = 0.6f), topLeft = Offset(panelLeft, y), size = Size(panelW, ridgeH * 0.16f))
        }

        // Side rails the panel rolls inside.
        drawRect(color = frame, topLeft = Offset(panelLeft - 7.dp.toPx(), panelTop), size = Size(7.dp.toPx(), panelH))
        drawRect(color = frame, topLeft = Offset(panelRight, panelTop), size = Size(7.dp.toPx(), panelH))

        drawRoundRect(color = Ink, topLeft = Offset(panelLeft, panelTop), size = Size(panelW, panelH), cornerRadius = CornerRadius(6.dp.toPx()), style = Stroke(3.dp.toPx()))

        // Bottom end-bar, where a real shutter's hasp lives.
        val barH = h * 0.05f
        val barTop = Offset(panelLeft, panelBottom - barH)
        drawRoundRect(color = frame, topLeft = barTop, size = Size(panelW, barH), cornerRadius = CornerRadius(4.dp.toPx()))
        drawRoundRect(color = Ink, topLeft = barTop, size = Size(panelW, barH), cornerRadius = CornerRadius(4.dp.toPx()), style = Stroke(2.5.dp.toPx()))

        // The step below.
        val ledgeTop = panelBottom + 5.dp.toPx()
        drawRect(color = Color(0xFFE8D9A8), topLeft = Offset(0f, ledgeTop), size = Size(w, h - ledgeTop))
        drawLine(Ink, Offset(0f, ledgeTop), Offset(w, ledgeTop), strokeWidth = 3.dp.toPx())

        drawRoundRect(color = Ink, size = Size(w, h), cornerRadius = wallRadius, style = Stroke(3.dp.toPx()))
    }
}

/**
 * The full MyAI-locked screen: [ShopShutter] closing into view with a real
 * animation, a hanging [Lock3D] at the hasp, "LOCKED IN" in a bold rotated
 * outline treatment, then the same key-entry flow as before.
 *
 * The shutter used to render already-shut, at a fixed 210dp — a photo of
 * a closed shutter, not a shutter closing. It now animates its own height
 * from nothing up to the space available on first composition, the same
 * "this is happening, not just true" distinction the rest of this app's
 * motion design cares about, with a sound cue timed to the same close.
 */
@Composable
fun MyAiLockedScreen(
    keyInput: String,
    onKeyChange: (String) -> Unit,
    onUnlock: () -> Unit,
) {
    val closeFraction = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        Sfx.play(Sound.WHOOSH)
        closeFraction.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
        Sfx.play(Sound.SHIELD_ON)
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 28.dp, vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
            // Full available height once closed — a shutter that only
            // covers the top third and stops was the exact complaint.
            ShopShutter(
                Modifier
                    .fillMaxWidth()
                    .height(320.dp * closeFraction.value.coerceAtLeast(0.02f)),
            )
            Lock3D(color = Butter.fill, size = 42.dp, modifier = Modifier.offset(y = 16.dp))
            // A taped instruction note, the way a real shuttered shop has
            // a handwritten sign stuck to the metal rather than nothing.
            if (closeFraction.value > 0.85f) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .offset(y = (-54).dp)
                        .rotate(-2f)
                        .background(Color(0xFFFFFCF4), RoundedCornerShape(4.dp))
                        .border(2.dp, Ink, RoundedCornerShape(4.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                ) {
                    Text(
                        "\uD83D\uDD27 Back while MyAI cooks",
                        color = Ink,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        Spacer(Modifier.height(30.dp))
        // "LOCKED IN" — a marker-style outline (several Ink copies offset
        // a couple of px behind a mint fill) and a slight rotation stands
        // in for the spray-paint reference; a literal spray/noise texture
        // has no cheap Compose equivalent, but the bold rotated outline is
        // the same "this was written, not printed" read at a glance.
        Box(
            Modifier
                .rotate(-3f)
                .graphicsLayer { alpha = closeFraction.value },
            contentAlignment = Alignment.Center,
        ) {
            listOf(
                Offset(-2f, -2f), Offset(2f, -2f), Offset(-2f, 2f), Offset(2f, 2f),
                Offset(0f, -3f), Offset(0f, 3f), Offset(-3f, 0f), Offset(3f, 0f),
            ).forEach { off ->
                Text(
                    "LOCKED IN",
                    color = Ink,
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.offset(x = off.x.dp, y = off.y.dp),
                )
            }
            Text(
                "LOCKED IN",
                color = Mint.fill,
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "MyAI is being worked on",
            color = Color.White.copy(alpha = 0.75f),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Back shortly. Got a key? Use it below to peek inside.",
            color = Color.White.copy(alpha = 0.55f),
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(
            value = keyInput,
            onValueChange = onKeyChange,
            placeholder = { Text("Key") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(12.dp))
        SquishButton(
            label = "Unlock",
            sticker = Mint,
            modifier = Modifier.fillMaxWidth(),
            onClick = onUnlock,
        )
    }
}
