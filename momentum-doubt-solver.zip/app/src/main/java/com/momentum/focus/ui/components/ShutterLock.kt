package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate as rotateDraw
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound

/**
 * A real shop's roll-down shutter — the reference photo the user sent
 * (a corrugated blue panel, a roller housing above it, side rails, a
 * bottom bar) redrawn in this app's own flat-fill-plus-Ink-outline
 * language rather than pasted in as a photo, the same way the Focus
 * Machine's Lid is a drawn object and not a stock image.
 *
 * This replaces the plain 🔒 emoji the MyAI-locked screen used before —
 * that told you *that* something was locked without committing to any
 * particular image of what. A shutter is a specific, recognisable object,
 * and "the shop is shut" reads instantly in a way a padlock glyph alone
 * doesn't.
 */
@Composable
fun ShopShutter(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val frame = Color(0xFF0E3A63)
        val panel = Color(0xFF2E86D6)
        val ridgeShadow = Color(0xFF1E6BAE)
        val ridgeLight = Color(0xFF6BB4EE)
        val wallRadius = CornerRadius(18.dp.toPx())

        // The wall the shutter is set into.
        drawRoundRect(color = Color(0xFFBFE3F5), size = Size(w, h), cornerRadius = wallRadius)

        // Roller housing along the top.
        val housingH = h * 0.11f
        val housingTop = Offset(w * 0.06f, h * 0.035f)
        val housingSize = Size(w * 0.88f, housingH)
        drawRoundRect(color = frame, topLeft = housingTop, size = housingSize, cornerRadius = CornerRadius(10.dp.toPx()))
        drawRoundRect(color = Ink, topLeft = housingTop, size = housingSize, cornerRadius = CornerRadius(10.dp.toPx()), style = Stroke(3.dp.toPx()))

        // The shutter panel itself.
        val panelTop = housingTop.y + housingH + 5.dp.toPx()
        val panelBottom = h * 0.86f
        val panelLeft = w * 0.09f
        val panelRight = w * 0.91f
        val panelW = panelRight - panelLeft
        val panelH = panelBottom - panelTop

        drawRoundRect(color = panel, topLeft = Offset(panelLeft, panelTop), size = Size(panelW, panelH), cornerRadius = CornerRadius(6.dp.toPx()))

        // Corrugation — repeating horizontal ridges, each a shadow band
        // under a highlight line, the same two-tone trick the coins and
        // the lock body use for "lit from above" everywhere else in the
        // app's icon set.
        val ridges = 13
        val ridgeH = panelH / ridges
        repeat(ridges) { i ->
            val y = panelTop + i * ridgeH
            drawRect(color = ridgeShadow, topLeft = Offset(panelLeft, y + ridgeH * 0.55f), size = Size(panelW, ridgeH * 0.45f))
            drawRect(color = ridgeLight.copy(alpha = 0.6f), topLeft = Offset(panelLeft, y), size = Size(panelW, ridgeH * 0.16f))
        }

        // Side rails the panel rolls inside.
        drawRect(color = frame, topLeft = Offset(panelLeft - 7.dp.toPx(), panelTop), size = Size(7.dp.toPx(), panelH))
        drawRect(color = frame, topLeft = Offset(panelRight, panelTop), size = Size(7.dp.toPx(), panelH))

        drawRoundRect(color = Ink, topLeft = Offset(panelLeft, panelTop), size = Size(panelW, panelH), cornerRadius = CornerRadius(6.dp.toPx()), style = Stroke(3.dp.toPx()))

        // Bottom end-bar, where a real shutter's hasp lives.
        val barH = h * 0.05f
        val barTop = Offset(panelLeft, panelBottom - barH)
        drawRoundRect(color = frame, topLeft = barTop, size = Size(panelW, barH), cornerRadius = CornerRadius(4.dp.toPx()))
        drawRoundRect(color = Ink, topLeft = barTop, size = Size(panelW, barH), cornerRadius = CornerRadius(4.dp.toPx()), style = Stroke(2.5.dp.toPx()))

        // The step below.
        val ledgeTop = panelBottom + 5.dp.toPx()
        drawRect(color = Color(0xFFE8D9A8), topLeft = Offset(0f, ledgeTop), size = Size(w, h - ledgeTop))
        drawLine(Ink, Offset(0f, ledgeTop), Offset(w, ledgeTop), strokeWidth = 3.dp.toPx())

        drawRoundRect(color = Ink, size = Size(w, h), cornerRadius = wallRadius, style = Stroke(3.dp.toPx()))
    }
}

/**
 * The full MyAI-locked screen, following the "MyAI shutter — full close +
 * graffiti" reference:
 *
 *  1. the shutter rolls down over the whole screen (700ms, with the whoosh);
 *  2. the roller housing at the top lights its status plate —
 *     "SERVER ON HIGH LOAD" beside a slow amber LED — in engraved chrome;
 *  3. LOCKED IN is sprayed on: a 900ms left-to-right reveal in 24 discrete
 *     strokes, a can travelling with the wipe, specks popping off the nozzle,
 *     and a couple of drips settling once the paint is down;
 *  4. the copy underneath and the key entry arrive as before.
 *
 * Paced on purpose (CLAUDE_PROJECT_RULES.md, rule 6): the shutter and the
 * spray each get one deliberate pass, then everything holds still except the
 * LED and the drips finishing their run.
 */
@Composable
fun MyAiLockedScreen(
    keyInput: String,
    onKeyChange: (String) -> Unit,
    onUnlock: () -> Unit,
) {
    val closeFraction = remember { Animatable(0f) }
    val reveal = remember { Animatable(0f) }
    val drips = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        Sfx.play(Sound.WHOOSH)
        closeFraction.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
        Sfx.play(Sound.SHIELD_ON)
        reveal.animateTo(1f, tween(900, easing = LinearEasing))
        drips.animateTo(1f, tween(1400, easing = FastOutSlowInEasing))
    }
    Box(Modifier.fillMaxSize().background(Ink)) {
        // The shutter fills the WHOLE screen, top-anchored; everything else
        // overlays it (the reference's own model: position:absolute; inset:0).
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            ShopShutter(
                Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(closeFraction.value.coerceAtLeast(0.02f)),
            )
        }

        // The roller housing was an empty navy slab. It now carries the plate.
        HousingPlate(closeFraction.value)

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 28.dp)
                .padding(top = 40.dp, bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(1f))

            SprayGraffiti(
                reveal = reveal.value,
                drips = drips.value,
                modifier = Modifier.fillMaxWidth().height(156.dp),
            )
            Spacer(Modifier.height(6.dp))

            Lock3D(color = Butter.fill, size = 42.dp)
            Spacer(Modifier.height(12.dp))

            // Always composed so nothing below it shifts when it fades in.
            Box(
                Modifier
                    .graphicsLayer { alpha = ((closeFraction.value - 0.85f) / 0.15f).coerceIn(0f, 1f) }
                    .rotate(-2f)
                    .background(Color(0xFFFFFCF4), RoundedCornerShape(4.dp))
                    .border(2.dp, Ink, RoundedCornerShape(4.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
            ) {
                Text(
                    "\uD83D\uDD27 Back while MyAI cooks",
                    color = Ink,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                )
            }
            Spacer(Modifier.height(18.dp))

            MetalText(
                "MyAI is being worked on",
                fontSize = 20.sp,
                weight = FontWeight.ExtraBold,
                letterSpacing = 0.3.sp,
            )
            Spacer(Modifier.height(8.dp))
            MetalText(
                "Back shortly. Got a key? Use it below to peek inside.",
                fontSize = 14.sp,
                weight = FontWeight.SemiBold,
                letterSpacing = 0.2.sp,
                muted = true,
            )
            Spacer(Modifier.height(28.dp))
            OutlinedTextField(
                value = keyInput,
                onValueChange = onKeyChange,
                placeholder = { Text("Key") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            SquishButton(
                label = "Unlock",
                sticker = Mint,
                modifier = Modifier.fillMaxWidth(),
                onClick = onUnlock,
            )
        }
    }
}

/**
 * The status plate on the roller housing. It sits exactly where
 * [ShopShutter] draws the housing (3.5% down, 11% tall, inset 6%), scaled by
 * the same closing fraction so it rides the shutter down instead of floating
 * over an empty rectangle.
 */
@Composable
private fun HousingPlate(close: Float) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val shutterH = maxHeight * close.coerceAtLeast(0.02f)
        val visible = ((close - 0.6f) / 0.4f).coerceIn(0f, 1f)
        val led by rememberInfiniteTransition(label = "housing-led").animateFloat(
            initialValue = 0.35f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "housing-led-alpha",
        )
        Row(
            Modifier
                .offset(x = maxWidth * 0.06f, y = shutterH * 0.035f)
                .width(maxWidth * 0.88f)
                .height(shutterH * 0.11f)
                .graphicsLayer { alpha = visible },
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(8.dp)
                    .graphicsLayer { alpha = led }
                    .background(Color(0xFFFFB020), CircleShape),
            )
            Spacer(Modifier.width(10.dp))
            MetalText(
                "SERVER ON HIGH LOAD",
                fontSize = 13.sp,
                weight = FontWeight.ExtraBold,
                letterSpacing = 2.4.sp,
            )
        }
    }
}

/**
 * Chrome lettering. There is no metallic typeface on the device and none can
 * be fetched at build time, so the metal is done the way it is done in print:
 * a bold face filled with a steel gradient that has a hard horizon at the
 * middle (bright sky over dark ground, the signature of polished chrome),
 * over a dark bevel copy one pixel lower so the letters read as raised off
 * the surface. The bevel also carries contrast against the blue corrugation,
 * which the old flat translucent white never had.
 */
@Composable
private fun MetalText(
    text: String,
    modifier: Modifier = Modifier,
    fontSize: TextUnit,
    weight: FontWeight,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    muted: Boolean = false,
) {
    val sky = if (muted) Color(0xFFDCE6F0) else Color(0xFFFFFFFF)
    val upper = if (muted) Color(0xFFA9BACB) else Color(0xFFC3D2E2)
    val horizon = if (muted) Color(0xFF6C8299) else Color(0xFF52687F)
    val lower = if (muted) Color(0xFFC4D2E0) else Color(0xFFE4ECF4)
    Box(modifier) {
        Text(
            text,
            modifier = Modifier.offset(y = 1.5.dp),
            color = Color(0xFF06121F).copy(alpha = 0.8f),
            fontSize = fontSize,
            fontWeight = weight,
            letterSpacing = letterSpacing,
            textAlign = TextAlign.Center,
        )
        Text(
            text,
            modifier = Modifier
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .drawWithContent {
                    drawContent()
                    drawRect(
                        brush = Brush.verticalGradient(
                            0f to sky,
                            0.46f to upper,
                            0.5f to horizon,
                            1f to lower,
                        ),
                        blendMode = BlendMode.SrcIn,
                    )
                },
            color = Color.White,
            fontSize = fontSize,
            fontWeight = weight,
            letterSpacing = letterSpacing,
            textAlign = TextAlign.Center,
        )
    }
}

private val SprayPink = Color(0xFFFF3D6E)

/**
 * LOCKED IN, sprayed onto the shutter — the reference's graffiti block.
 *
 * Reference values kept: 56 size, pink #FF3D6E fill, ink outline, a hard 4dp
 * ink shadow plus a soft 7dp one, a pink glow, -4° tilt, a 900ms left-to-right
 * reveal in 24 steps (not a smooth wipe — a smooth wipe reads as a UI
 * transition, stepped strokes read as an arm moving), a can riding the wipe
 * from 20% to 78% of the width, and ten specks popping off it.
 *
 * Two honest substitutions: the reference's Permanent Marker face and its
 * turbulence displacement filter have no equivalent that works on every
 * supported API level with no font file to bundle, so the letters are a black
 * italic system face with a stroked outline and a seeded overspray scatter
 * standing in for the filter; and the reference's 🥫 is a drawn can in the
 * app's flat-fill-plus-Ink style (rule 9: no emoji art next to our own).
 */
@Composable
private fun SprayGraffiti(reveal: Float, drips: Float, modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        if (reveal <= 0f) return@Box
        val steps = 24
        val wipe = kotlin.math.floor(reveal * steps) / steps
        Box(Modifier.matchParentSize().graphicsLayer { rotationZ = -4f }, contentAlignment = Alignment.Center) {
            // The paint, uncovered one stroke at a time.
            Box(
                Modifier
                    .matchParentSize()
                    .drawWithContent {
                        clipRect(right = size.width * wipe) {
                            this@drawWithContent.drawContent()
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                GraffitiWord(Color.Black.copy(alpha = 0.25f), 7.dp, 7.dp)
                GraffitiWord(Ink, 4.dp, 4.dp)
                GraffitiWord(Ink, 0.dp, 0.dp, outline = true)
                GraffitiWord(SprayPink, 0.dp, 0.dp, glow = true)
                Canvas(Modifier.matchParentSize()) {
                    // Overspray: a seeded scatter, denser toward the ends of the
                    // word where a real can leaves and arrives.
                    val rnd = kotlin.random.Random(7)
                    repeat(90) {
                        val x = rnd.nextFloat() * size.width
                        val y = size.height * (0.12f + rnd.nextFloat() * 0.76f)
                        val edge = kotlin.math.abs(x - size.width / 2f) / (size.width / 2f)
                        if (rnd.nextFloat() < 0.25f + edge * 0.5f) {
                            drawCircle(
                                SprayPink.copy(alpha = rnd.nextFloat() * 0.5f),
                                radius = (rnd.nextFloat() * 2f + 0.5f) * density,
                                center = Offset(x, y),
                            )
                        }
                    }
                }
            }
            // Can, specks and drips ride on top, unclipped.
            Canvas(Modifier.matchParentSize()) {
                val w = size.width
                val h = size.height
                val ms = reveal * 900f

                // Specks: (28 + i*4.5)% across, 34–46% down in the reference.
                val rnd = kotlin.random.Random(11)
                for (i in 0 until 10) {
                    val t = ((ms - i * 35f) / 400f)
                    if (t <= 0f || t >= 1f) continue
                    val cx = w * (0.14f + i * 0.07f)
                    val cy = h * (0.22f + rnd.nextFloat() * 0.3f) + t * 6.dp.toPx()
                    drawCircle(
                        SprayPink.copy(alpha = 0.9f * (1f - t)),
                        radius = 2.5.dp.toPx() * (1f + 1.2f * t),
                        center = Offset(cx, cy),
                    )
                }

                // The can, 20% → 78% of the width in the same 24 steps.
                if (reveal in 0.001f..0.95f) {
                    val cx = w * (0.20f + 0.58f * wipe)
                    val cy = h * 0.10f
                    rotateDraw(-24f, Offset(cx, cy)) {
                        val bw = 18.dp.toPx()
                        val bh = 30.dp.toPx()
                        val left = cx - bw / 2f
                        val top = cy - bh / 2f
                        drawRoundRect(Color(0xFFDCE4EC), Offset(left, top), Size(bw, bh), CornerRadius(4.dp.toPx()))
                        drawRect(SprayPink, Offset(left, top + bh * 0.36f), Size(bw, bh * 0.30f))
                        drawRoundRect(
                            Ink, Offset(left, top), Size(bw, bh), CornerRadius(4.dp.toPx()),
                            style = Stroke(2.dp.toPx()),
                        )
                        drawRoundRect(Ink, Offset(cx - 6.dp.toPx(), top - 7.dp.toPx()), Size(12.dp.toPx(), 8.dp.toPx()), CornerRadius(2.dp.toPx()))
                        drawRect(Ink, Offset(cx - 1.5.dp.toPx(), top - 12.dp.toPx()), Size(3.dp.toPx(), 5.dp.toPx()))
                    }
                }

                // Drips finishing their run below the second line.
                if (drips > 0f) {
                    val dripX = listOf(0.445f to 20f, 0.575f to 30f)
                    dripX.forEach { (fx, maxLen) ->
                        val len = maxLen.dp.toPx() * drips
                        val x = w * fx
                        val y0 = h * 0.82f
                        drawRoundRect(
                            SprayPink.copy(alpha = 0.9f),
                            Offset(x - 2.dp.toPx(), y0),
                            Size(4.dp.toPx(), len),
                            CornerRadius(2.dp.toPx()),
                        )
                        drawCircle(SprayPink.copy(alpha = 0.9f), 3.dp.toPx(), Offset(x, y0 + len))
                    }
                }
            }
        }
    }
}

@Composable
private fun GraffitiWord(
    color: Color,
    dx: Dp,
    dy: Dp,
    outline: Boolean = false,
    glow: Boolean = false,
) {
    Text(
        "LOCKED\nIN",
        modifier = Modifier.offset(dx, dy),
        style = TextStyle(
            color = color,
            fontSize = 56.sp,
            lineHeight = 54.sp,
            fontWeight = FontWeight.Black,
            fontStyle = FontStyle.Italic,
            letterSpacing = (-1).sp,
            textAlign = TextAlign.Center,
            drawStyle = if (outline) Stroke(width = 9f, join = StrokeJoin.Round) else null,
            shadow = if (glow) Shadow(SprayPink.copy(alpha = 0.6f), Offset.Zero, 36f) else null,
        ),
    )
}
