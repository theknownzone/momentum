package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.ScreenTimeReport
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.RoastCard
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.launch

/**
 * The one button that draws and shares the Screen Time Roast.
 *
 * Shows "Cooking your roast…" while the poster renders on IO, then opens the
 * share sheet with a WHOOSH. Guards double taps — two 8 MB renders at once is
 * exactly what a 2 GB phone can't afford. Hidden entirely when the week has no
 * data: an empty roast would be a fake number, and this screen never fakes.
 */
@Composable
fun RoastShareButton(
    report: ScreenTimeReport,
    modifier: Modifier = Modifier,
    sticker: Sticker = Butter,
) {
    if (!report.hasData) return
    val context = LocalContext.current
    val str = strings().roast
    val haptics = rememberHaptics()
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    SquishButton(
        label = if (busy) str.cooking else str.shareCta,
        sticker = sticker,
        enabled = !busy,
        modifier = modifier,
    ) {
        if (busy) return@SquishButton
        busy = true
        haptics.confirm()
        scope.launch {
            val ok = RoastCard.share(context, report, str)
            if (ok) Sfx.play(Sound.SEND) else haptics.reject()
            busy = false
        }
    }
}

/**
 * Stats entry point: a small comic card with the tier stamp preview, so the
 * roast is easy to find after onboarding too.
 *
 * The stamp settles in once (220 ms, draw-phase only) when the card first
 * appears — no idle loop, nothing for a cheap phone to keep paying for.
 */
@Composable
fun RoastEntryCard(report: ScreenTimeReport, modifier: Modifier = Modifier) {
    if (!report.hasData) return
    val str = strings().roast
    val tier = RoastCard.tier(report.averageMinutes)
    val tierFill = listOf(Mint, Sky, Butter, Tang, Candy)[tier]
    val days = RoastCard.daysPerYear(report.averageMinutes)

    val settle = remember { Animatable(0f) }
    LaunchedEffect(Unit) { settle.animateTo(1f, tween(220, easing = FastOutSlowInEasing)) }

    val shape = RoundedCornerShape(Paper.CardRadius)
    val shadow = 4.dp * Vibe.shadow
    Column(
        modifier
            .fillMaxWidth()
            .drawBehind {
                val d = shadow.toPx()
                drawRoundRect(
                    color = Ink,
                    topLeft = Offset(d, d),
                    size = size,
                    cornerRadius = CornerRadius(Paper.CardRadius.toPx()),
                )
            }
            .clip(shape)
            .background(CreamCard)
            .border(Paper.Outline, Ink, shape)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(str.statsTitle, style = MaterialTheme.typography.labelSmall, color = Tang.accent)
                    Spacer(Modifier.width(6.dp))
                    NewBadge()
                }
                Spacer(Modifier.height(4.dp))
                Text(str.days(days), style = MaterialTheme.typography.headlineMedium, color = Ink)
                Text(str.daysSub, style = MaterialTheme.typography.bodyMedium, color = InkMid)
            }
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier
                    .graphicsLayer {
                        val v = settle.value
                        rotationZ = -6f * v
                        scaleX = 1.12f - 0.12f * v
                        scaleY = 1.12f - 0.12f * v
                        alpha = v
                    }
                    .clip(RoundedCornerShape(10.dp))
                    .background(tierFill.fill)
                    .border(2.5.dp, Ink, RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(str.tiers[tier], style = MaterialTheme.typography.labelSmall, color = tierFill.on)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(str.statsSub, style = MaterialTheme.typography.bodySmall, color = InkMid)
        Spacer(Modifier.height(12.dp))
        RoastShareButton(report, Modifier.fillMaxWidth())
    }
}
