package com.momentum.focus.ui.components

import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.momentum.focus.R
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Sticker
import com.momentum.focus.ui.theme.stickerFor

/**
 * Isometric avatars drawn in code.
 *
 * The whole illusion of solidity comes from one rule: the same colour at three
 * brightnesses, one per visible face. Top face lightest, left face mid, right
 * face darkest. Get that ordering right and a flat shape reads as an object
 * lit from above, with no image files involved.
 */
/**
 * Six pickable avatars in total: three faces and three shapes.
 *
 * There were nine, which ran the picker onto a third ragged row under a colour
 * row of six. Three of the shapes — a tower, a coin and a prism — were only
 * distinguishable from the others by looking for the difference, so removing
 * them costs nothing and the grid lands as two clean rows.
 */
enum class AvatarShape { CUBE, GEM, ORB }

/**
 * Rendered avatars supplied as artwork. They sit first in the picker because a
 * face is what most people want, and the drawn shapes remain for anyone who
 * would rather not be represented by a person at all.
 */
private val PHOTOS = listOf(
    R.drawable.avatar_1,
    R.drawable.avatar_2,
    R.drawable.avatar_3,
)

/** Total pickable avatars: the rendered faces followed by the drawn shapes. */
val AVATAR_COUNT = PHOTOS.size + AvatarShape.entries.size

/**
 * Index of a drawn shape, never a face.
 *
 * Badges were landing in the photo range and awarding the user their own
 * portrait, which made no sense as a trophy.
 */
fun shapeOnly(index: Int): Int = PHOTOS.size + Math.floorMod(index, AvatarShape.entries.size)

@Composable
fun Avatar3D(
    colorIndex: Int,
    shapeIndex: Int,
    size: Dp = 64.dp,
    modifier: Modifier = Modifier,
) {
    // v6 "aura" avatars (owner: no letters, no cartoons, Gen-Z): a living
    // mesh-gradient orb — three colour blobs slowly orbiting inside the disc,
    // film grain, a holographic rim — with one clean glyph in the middle.
    // Six identities, one per colour slot: Aurora, Solar, Ember, Nebula,
    // Tide, Bloom. All code-drawn, so they're sharp at any size.
    val style = Math.floorMod(colorIndex, AURAS.size)
    val a = AURAS[style]
    val t by androidx.compose.animation.core.rememberInfiniteTransition(label = "aura").animateFloat(
        0f, 360f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(14000, easing = androidx.compose.animation.core.LinearEasing)),
        label = "auraT",
    )
    Canvas(modifier.size(size)) {
        val r = this.size.minDimension / 2
        val c = center
        val disc = Path().apply { addOval(androidx.compose.ui.geometry.Rect(c, r)) }
        androidx.compose.ui.graphics.drawscope.clipPath(disc) {
            drawRect(a.base)
            // three blobs orbiting = mesh gradient that never sits still
            a.blobs.forEachIndexed { k, col ->
                val ang = Math.toRadians((t * (if (k % 2 == 0) 1.0 else -0.7) + k * 120.0))
                val bc = c + Offset((kotlin.math.cos(ang) * r * 0.45f).toFloat(), (kotlin.math.sin(ang) * r * 0.45f).toFloat())
                drawCircle(Brush.radialGradient(listOf(col, col.copy(alpha = 0f)), bc, r * 1.05f), r * 1.05f, bc)
            }
            // grain
            val rnd = java.util.Random(style.toLong())
            repeat(90) {
                drawCircle(Color.White.copy(alpha = 0.06f + rnd.nextFloat() * 0.06f), r * 0.012f + 0.4f, Offset(c.x - r + rnd.nextFloat() * 2 * r, c.y - r + rnd.nextFloat() * 2 * r))
            }
            // top gloss
            drawOval(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.40f), Color.Transparent), startY = c.y - r, endY = c.y), Offset(c.x - r * 0.62f, c.y - r * 0.92f), androidx.compose.ui.geometry.Size(r * 1.24f, r * 0.8f))
        }
        // holographic rim
        drawCircle(Brush.sweepGradient(listOf(Color(0xFFFF9EC4), Color(0xFF7FD4FF), Color(0xFF3FE28F), Color(0xFFFFD84D), Color(0xFFFF9EC4)), c), r - r * 0.04f, c, style = Stroke(r * 0.08f))
        drawCircle(Ink, r - 0.5f, c, style = Stroke((r * 0.06f).coerceAtLeast(1.5f)))
        // glyph with a soft glow
        val g = r * 0.42f
        drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.35f), Color.Transparent), c, g * 1.8f), g * 1.8f, c)
        val w = Color.White
        val st = Stroke(r * 0.11f, cap = androidx.compose.ui.graphics.StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
        when (style) {
            0 -> { // Aurora: four-point spark
                val p = Path().apply {
                    moveTo(c.x, c.y - g); quadraticTo(c.x, c.y, c.x + g, c.y); quadraticTo(c.x, c.y, c.x, c.y + g)
                    quadraticTo(c.x, c.y, c.x - g, c.y); quadraticTo(c.x, c.y, c.x, c.y - g); close()
                }
                drawPath(p, w)
            }
            1 -> { // Solar: disc + rays
                drawCircle(w, g * 0.45f, c)
                for (k in 0 until 8) {
                    val an = Math.toRadians(k * 45.0)
                    val d1 = g * 0.7f; val d2 = g
                    drawLine(w, c + Offset((kotlin.math.cos(an) * d1).toFloat(), (kotlin.math.sin(an) * d1).toFloat()), c + Offset((kotlin.math.cos(an) * d2).toFloat(), (kotlin.math.sin(an) * d2).toFloat()), r * 0.09f, androidx.compose.ui.graphics.StrokeCap.Round)
                }
            }
            2 -> { // Ember: flame drop
                val p = Path().apply {
                    moveTo(c.x, c.y - g)
                    cubicTo(c.x + g * 0.9f, c.y - g * 0.1f, c.x + g * 0.7f, c.y + g, c.x, c.y + g)
                    cubicTo(c.x - g * 0.7f, c.y + g, c.x - g * 0.9f, c.y - g * 0.1f, c.x, c.y - g); close()
                }
                drawPath(p, w)
                drawCircle(a.base, g * 0.28f, c + Offset(0f, g * 0.35f))
            }
            3 -> { // Nebula: planet + ring
                drawCircle(w, g * 0.5f, c)
                rotate(-20f, c) {
                    drawOval(w, Offset(c.x - g, c.y - g * 0.32f), androidx.compose.ui.geometry.Size(g * 2, g * 0.64f), style = st)
                }
            }
            4 -> { // Tide: double wave
                for (k in 0..1) {
                    val y = c.y - g * 0.25f + k * g * 0.55f
                    val p = Path().apply {
                        moveTo(c.x - g, y)
                        cubicTo(c.x - g * 0.5f, y - g * 0.45f, c.x - g * 0.1f, y + g * 0.45f, c.x + g * 0.3f, y)
                        quadraticTo(c.x + g * 0.65f, y - g * 0.3f, c.x + g, y)
                    }
                    drawPath(p, w, style = st)
                }
            }
            else -> { // Bloom: five petals
                for (k in 0 until 5) {
                    rotate(k * 72f, c) {
                        drawOval(w, Offset(c.x - g * 0.22f, c.y - g), androidx.compose.ui.geometry.Size(g * 0.44f, g * 0.75f))
                    }
                }
                drawCircle(a.base, g * 0.22f, c)
            }
        }
    }
}

private class Aura(val base: Color, val blobs: List<Color>)

private val AURAS = listOf(
    Aura(Color(0xFF0B3D33), listOf(Color(0xFF3FE28F), Color(0xFF22C7FF), Color(0xFFB9FFDF))),   // Aurora
    Aura(Color(0xFF4A2A05), listOf(Color(0xFFFFC531), Color(0xFFFF8A1E), Color(0xFFFFF1C2))),   // Solar
    Aura(Color(0xFF3D0E06), listOf(Color(0xFFFF6A2E), Color(0xFFFF3550), Color(0xFFFFB347))),   // Ember
    Aura(Color(0xFF1A1040), listOf(Color(0xFF9D7BFF), Color(0xFFFF4F8B), Color(0xFF22C7FF))),   // Nebula
    Aura(Color(0xFF062A44), listOf(Color(0xFF22C7FF), Color(0xFF3B6CFF), Color(0xFF9DF3FF))),   // Tide
    Aura(Color(0xFF3F0A24), listOf(Color(0xFFFF4F8B), Color(0xFFFF9EC4), Color(0xFFB9A7FF))),   // Bloom
)

/** The signed-in name's initial, set once from AppData by MainActivity. */
object AvatarInitial { @Volatile var value: String = "" }

private fun Color.shade(factor: Float): Color = Color(
    red = (red * factor).coerceIn(0f, 1f),
    green = (green * factor).coerceIn(0f, 1f),
    blue = (blue * factor).coerceIn(0f, 1f),
    alpha = alpha,
)

private fun DrawScope.face(points: List<Offset>, fill: Color, outline: Float) {
    val path = Path().apply {
        moveTo(points[0].x, points[0].y)
        points.drop(1).forEach { lineTo(it.x, it.y) }
        close()
    }
    drawPath(path, fill)
    drawPath(path, Ink, style = Stroke(outline))
}

private fun DrawScope.cube(s: Sticker) {
    val w = size.width
    val o = 3.dp.toPx()
    val cx = w / 2
    val top = w * 0.16f
    val mid = w * 0.40f
    val low = w * 0.62f
    val bot = w * 0.86f
    val half = w * 0.32f

    face(listOf(Offset(cx, top), Offset(cx + half, mid), Offset(cx, low), Offset(cx - half, mid)),
        s.fill.shade(1.15f), o)
    face(listOf(Offset(cx - half, mid), Offset(cx, low), Offset(cx, bot), Offset(cx - half, bot - (low - mid))),
        s.fill.shade(0.82f), o)
    face(listOf(Offset(cx + half, mid), Offset(cx, low), Offset(cx, bot), Offset(cx + half, bot - (low - mid))),
        s.fill.shade(0.62f), o)
}

private fun DrawScope.gem(s: Sticker) {
    val w = size.width
    val o = 3.dp.toPx()
    val cx = w / 2
    val half = w * 0.30f

    face(listOf(Offset(cx, w * 0.12f), Offset(cx + half, w * 0.40f), Offset(cx, w * 0.52f)),
        s.fill.shade(1.15f), o)
    face(listOf(Offset(cx, w * 0.12f), Offset(cx - half, w * 0.40f), Offset(cx, w * 0.52f)),
        s.fill.shade(0.95f), o)
    face(listOf(Offset(cx - half, w * 0.40f), Offset(cx, w * 0.52f), Offset(cx, w * 0.90f)),
        s.fill.shade(0.78f), o)
    face(listOf(Offset(cx + half, w * 0.40f), Offset(cx, w * 0.52f), Offset(cx, w * 0.90f)),
        s.fill.shade(0.58f), o)
}




private fun DrawScope.orb(s: Sticker) {
    val w = size.width
    val o = 3.dp.toPx()
    val r = w * 0.30f
    val c = Offset(w / 2, w * 0.52f)

    drawCircle(s.fill.shade(0.7f), r, c)
    // A highlight offset up-left is the cheapest possible sphere: the eye
    // reads the gradient as a curved surface immediately.
    drawCircle(s.fill.shade(1.2f), r * 0.62f, Offset(c.x - r * 0.24f, c.y - r * 0.26f))
    drawCircle(s.fill.shade(1.45f), r * 0.22f, Offset(c.x - r * 0.36f, c.y - r * 0.38f))
    drawCircle(Ink, r, c, style = Stroke(o))
}
