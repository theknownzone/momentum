package com.momentum.focus.ui.components

import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.momentum.focus.R
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Sticker
import com.momentum.focus.ui.theme.stickerFor

/**
 * Isometric avatars drawn in code.
 *
 * The whole illusion of solidity comes from one rule: the same colour at three
 * brightnesses, one per visible face. Top face lightest, left face mid, right
 * face darkest. Get that ordering right and a flat shape reads as an object
 * lit from above, with no image files involved.
 */
/**
 * Six pickable avatars in total: three faces and three shapes.
 *
 * There were nine, which ran the picker onto a third ragged row under a colour
 * row of six. Three of the shapes — a tower, a coin and a prism — were only
 * distinguishable from the others by looking for the difference, so removing
 * them costs nothing and the grid lands as two clean rows.
 */
enum class AvatarShape { CUBE, GEM, ORB }

/**
 * Rendered avatars supplied as artwork. They sit first in the picker because a
 * face is what most people want, and the drawn shapes remain for anyone who
 * would rather not be represented by a person at all.
 */
private val PHOTOS = listOf(
    R.drawable.avatar_1,
    R.drawable.avatar_2,
    R.drawable.avatar_3,
)

/** Total pickable avatars: the rendered faces followed by the drawn shapes. */
val AVATAR_COUNT = PHOTOS.size + AvatarShape.entries.size

/**
 * Index of a drawn shape, never a face.
 *
 * Badges were landing in the photo range and awarding the user their own
 * portrait, which made no sense as a trophy.
 */
fun shapeOnly(index: Int): Int = PHOTOS.size + Math.floorMod(index, AvatarShape.entries.size)

@Composable
fun Avatar3D(
    colorIndex: Int,
    shapeIndex: Int,
    size: Dp = 64.dp,
    modifier: Modifier = Modifier,
) {
    // v5 (owner: "cartoon DPs are childish"): every avatar is now a
    // monogram — the user's initial set in a glossy gradient disc of their
    // chosen colour, ink ring, soft top highlight. shapeIndex is kept in the
    // signature (stored data, other call sites) but no longer changes the art.
    val sticker = stickerFor(colorIndex)
    val initial = AvatarInitial.value.ifBlank { "M" }
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(sticker.fill, sticker.accent)))
            .drawWithContent {
                drawContent()
                val r = this.size.minDimension / 2
                drawCircle(Color.White.copy(alpha = 0.35f), r - r * 0.12f, style = androidx.compose.ui.graphics.drawscope.Stroke(r * 0.04f))
                drawArc(
                    Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.45f), Color.Transparent), endY = this.size.height * 0.5f),
                    200f, 140f, false,
                    topLeft = Offset(r * 0.25f, r * 0.12f), size = androidx.compose.ui.geometry.Size(r * 1.5f, r * 0.9f),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(r * 0.1f, cap = androidx.compose.ui.graphics.StrokeCap.Round),
                )
            }
            .border((size.value / 32f).coerceIn(1.5f, 3f).dp, Ink, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            initial.take(1).uppercase(),
            fontSize = (size.value * 0.46f).sp,
            fontWeight = FontWeight.Black,
            color = sticker.on,
        )
    }
}

/** The signed-in name's initial, set once from AppData by MainActivity. */
object AvatarInitial { @Volatile var value: String = "" }

private fun Color.shade(factor: Float): Color = Color(
    red = (red * factor).coerceIn(0f, 1f),
    green = (green * factor).coerceIn(0f, 1f),
    blue = (blue * factor).coerceIn(0f, 1f),
    alpha = alpha,
)

private fun DrawScope.face(points: List<Offset>, fill: Color, outline: Float) {
    val path = Path().apply {
        moveTo(points[0].x, points[0].y)
        points.drop(1).forEach { lineTo(it.x, it.y) }
        close()
    }
    drawPath(path, fill)
    drawPath(path, Ink, style = Stroke(outline))
}

private fun DrawScope.cube(s: Sticker) {
    val w = size.width
    val o = 3.dp.toPx()
    val cx = w / 2
    val top = w * 0.16f
    val mid = w * 0.40f
    val low = w * 0.62f
    val bot = w * 0.86f
    val half = w * 0.32f

    face(listOf(Offset(cx, top), Offset(cx + half, mid), Offset(cx, low), Offset(cx - half, mid)),
        s.fill.shade(1.15f), o)
    face(listOf(Offset(cx - half, mid), Offset(cx, low), Offset(cx, bot), Offset(cx - half, bot - (low - mid))),
        s.fill.shade(0.82f), o)
    face(listOf(Offset(cx + half, mid), Offset(cx, low), Offset(cx, bot), Offset(cx + half, bot - (low - mid))),
        s.fill.shade(0.62f), o)
}

private fun DrawScope.gem(s: Sticker) {
    val w = size.width
    val o = 3.dp.toPx()
    val cx = w / 2
    val half = w * 0.30f

    face(listOf(Offset(cx, w * 0.12f), Offset(cx + half, w * 0.40f), Offset(cx, w * 0.52f)),
        s.fill.shade(1.15f), o)
    face(listOf(Offset(cx, w * 0.12f), Offset(cx - half, w * 0.40f), Offset(cx, w * 0.52f)),
        s.fill.shade(0.95f), o)
    face(listOf(Offset(cx - half, w * 0.40f), Offset(cx, w * 0.52f), Offset(cx, w * 0.90f)),
        s.fill.shade(0.78f), o)
    face(listOf(Offset(cx + half, w * 0.40f), Offset(cx, w * 0.52f), Offset(cx, w * 0.90f)),
        s.fill.shade(0.58f), o)
}




private fun DrawScope.orb(s: Sticker) {
    val w = size.width
    val o = 3.dp.toPx()
    val r = w * 0.30f
    val c = Offset(w / 2, w * 0.52f)

    drawCircle(s.fill.shade(0.7f), r, c)
    // A highlight offset up-left is the cheapest possible sphere: the eye
    // reads the gradient as a curved surface immediately.
    drawCircle(s.fill.shade(1.2f), r * 0.62f, Offset(c.x - r * 0.24f, c.y - r * 0.26f))
    drawCircle(s.fill.shade(1.45f), r * 0.22f, Offset(c.x - r * 0.36f, c.y - r * 0.38f))
    drawCircle(Ink, r, c, style = Stroke(o))
}
