package com.momentum.focus.ui.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import com.momentum.focus.MainActivity
import com.momentum.focus.R

/**
 * Tells the user their weekly Coach report is ready, using the report's own
 * headline as the notification body — the same AI analysis already built
 * for the in-app card, just also said out loud once a week instead of only
 * waiting to be found on Stats.
 *
 * This is a real, deliberate change of the app's own stated position:
 * Coach's own doc comment says a report "cannot become the thing you scroll
 * instead of studying", which is why it never had a notification before.
 * What this still respects is the *rate* — [ai.Coach.canRun] still gates it
 * to once a week minimum, so what changed is that the one report a week
 * produces now says so once, not that reports got any more frequent.
 *
 * A real limit worth being upfront about: this fires from inside the app,
 * when [ai.Coach.run] actually completes — not from a server, and not while
 * the app has been closed for days the way a delivery app's push does. That
 * needs a backend (push infrastructure this client-only app doesn't have)
 * to build for real; this is the honest version of the same idea that
 * works without one.
 */
object CoachNotice {

    private const val CHANNEL = "momentum_coach"
    private const val ID = 76

    fun show(context: Context, headline: String) {
        if (headline.isBlank()) return
        if (!canPost(context)) return

        val manager = context.getSystemService<NotificationManager>() ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL,
                "Weekly report",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Your weekly Coach read, once it's ready"
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                    null,
                )
                enableVibration(true)
            }
            manager.createNotificationChannel(channel)
        }

        val open = PendingIntent.getActivity(
            context,
            2,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Your week, read")
            .setContentText(headline)
            .setStyle(NotificationCompat.BigTextStyle().bigText(headline))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setDefaults(NotificationCompat.DEFAULT_SOUND or NotificationCompat.DEFAULT_VIBRATE)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(ID, notification)
        }
        Sfx.play(Sound.REPLY)
    }

    private fun canPost(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
}
