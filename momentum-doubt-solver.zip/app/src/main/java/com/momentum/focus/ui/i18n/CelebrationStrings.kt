package com.momentum.focus.ui.i18n

/**
 * The four celebration moments MainActivity fires directly — session
 * banked, streak, level up, shield up at the end of onboarding. All four
 * were literals at the call site, in English only, regardless of what the
 * rest of the app was set to. The badge-unlock celebration is not here: its
 * kicker/title/body come from the achievement's own data, not from a
 * literal in MainActivity.
 */
interface CelebrationStrings {
    val sessionKicker: String
    fun sessionBody(minutes: Int): String

    val streakKicker: String
    val streakBodyFirst: String
    val streakBodyLater: String

    val levelKicker: String
    fun levelTitle(level: Int): String
    val levelBody: String

    val shieldKicker: String
    val shieldTitle: String
    val shieldBody: String
}

object CelebrationHi : CelebrationStrings {
    override val sessionKicker = "SESSION BANKED"
    override fun sessionBody(minutes: Int) = "$minutes min padhai hui. Wallet mein aa gaya."

    override val streakKicker = "STREAK"
    override val streakBodyFirst = "Din streak. Pehla din yahin se shuru."
    override val streakBodyLater = "Din streak. Compound effect asli hai."

    override val levelKicker = "LEVEL UP"
    override fun levelTitle(level: Int) = "Level $level"
    override val levelBody = "Iska har minute kamaya hai. Kisi ne diya nahi."

    override val shieldKicker = "ALL SET"
    override val shieldTitle = "Set to focus."
    override val shieldBody = "Distractions band hain, timer taiyar hai. Jab chaho, pehla session shuru karo."
}

object CelebrationEn : CelebrationStrings {
    override val sessionKicker = "SESSION BANKED"
    override fun sessionBody(minutes: Int) = "$minutes min studied. In the wallet now."

    override val streakKicker = "STREAK"
    override val streakBodyFirst = "Day streak. Day one starts here."
    override val streakBodyLater = "Days streak. The compound effect is real."

    override val levelKicker = "LEVEL UP"
    override fun levelTitle(level: Int) = "Level $level"
    override val levelBody = "Every minute of this was earned. Nobody handed it to you."

    override val shieldKicker = "ALL SET"
    override val shieldTitle = "Set to focus."
    override val shieldBody = "Distractions are blocked, the timer's ready. First session whenever you are."
}
