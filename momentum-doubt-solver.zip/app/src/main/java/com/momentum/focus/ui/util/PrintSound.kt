package com.momentum.focus.ui.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import com.momentum.focus.R

/**
 * The shipped-clip sounds used across the unlock receipt: the printer
 * running, a riser as it wakes up, a chime when premium actually unlocks,
 * and a soft click for taps during the sequence.
 *
 * A shipped clip rather than one of Sfx's synthesised tones. Sfx builds its
 * cues from raw PCM maths, which is right for short abstract beeps -- a
 * riser, a low hit -- but a dot-matrix head dragging across paper, or a
 * chime with real harmonic body, is texture nobody writes by hand. These are
 * the sounds in the app that have to be recordings.
 *
 * One [MediaPlayer] per cue rather than one shared player. The four fire at
 * different points in the same sequence and are not guaranteed to stay
 * non-overlapping forever -- a tap during the print stage should not have to
 * wait for the gears to finish, or cut them off, to play its own click. A
 * small pool costs a handful of MediaPlayer instances, which is cheap; a
 * single shared player racing itself across four call sites is the kind of
 * bug that only shows up once someone taps at the wrong moment.
 *
 * Follows SystemVoice's pattern: prepared ahead of the beat so decoding
 * never lands a cue late, and every play() is gated on the physical silent
 * switch.
 */
enum class PrintCue(val res: Int) {
    /** The sustained mechanical run, trimmed to ~17s to match the feed stage. */
    GEARS(R.raw.printer_gears),
    /** A short rising whoosh for the boot/calibrate moment before printing starts. */
    RISER(R.raw.print_riser),
    /** The payoff chime, timed to "Welcome to Premium!". */
    CHIME(R.raw.premium_chime),
    /** A soft tap sound for buttons inside the sequence (Cancel/Unlock etc). */
    CLICK(R.raw.soft_click),
}

object PrintSound {

    private val players = mutableMapOf<PrintCue, MediaPlayer>()
    private var audioManager: AudioManager? = null

    fun init(context: Context) {
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val app = context.applicationContext
        PrintCue.entries.forEach { cue ->
            if (players.containsKey(cue)) return@forEach
            runCatching {
                MediaPlayer.create(
                    app,
                    cue.res,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                    0,
                )
            }.getOrNull()?.let { players[cue] = it }
        }
    }

    fun play(cue: PrintCue) {
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val p = players[cue] ?: return
        runCatching {
            if (p.isPlaying) {
                p.pause()
                p.seekTo(0)
            }
            p.start()
        }
    }

    /** Stops every cue mid-clip, for when the receipt is dismissed early. */
    fun stopAll() {
        players.values.forEach { p ->
            runCatching {
                if (p.isPlaying) {
                    p.pause()
                    p.seekTo(0)
                }
            }
        }
    }

    fun release() {
        players.values.forEach { p -> runCatching { p.release() } }
        players.clear()
        audioManager = null
    }
}
