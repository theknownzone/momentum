package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.sin

private val PI_F = PI.toFloat()

private fun rnd(i: Int, salt: Int): Float {
    val x = sin((i * 12.9898 + salt * 78.233)) * 43758.5453
    return (x - floor(x)).toFloat()
}

/**
 * The payoff screen after an actual purchase — a hanami at night, not a
 * generic confetti screen. Hundreds of sakura petals rather than fifty
 * pieces of confetti, a single scanning light sweep standing in for the
 * moment a receipt actually prints, and the result typed out in a pixel
 * face rather than the app's normal one.
 */
@Composable
fun PremiumCelebration(
    title: String,
    subtitle: String,
    onDone: () -> Unit
) {
    val haptics = rememberHaptics()
    var elapsedMs by remember { mutableFloatStateOf(0f) }
    var sweepFired by remember { mutableStateOf(false) }
    var climaxFired by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { now -> elapsedMs = (now - start) / 1_000_000f }
        }
    }
    LaunchedEffect(elapsedMs > 500f) {
        if (elapsedMs > 500f && !sweepFired) {
            sweepFired = true
            Sfx.playOnce(Sound.FESTIVE)
            haptics.tick()
        }
    }
    LaunchedEffect(elapsedMs > 1300f) {
        if (elapsedMs > 1300f && !climaxFired) {
            climaxFired = true
            haptics.unlock()
        }
    }

    val infinite = rememberInfiniteTransition(label = "hanami")
    val drift by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "drift",
    )

    val petal = Color(0xFFFFB7C5)
    val sweepX = ((elapsedMs - 200f) / 900f).coerceIn(0f, 1f)
    val checkAssemble = ((elapsedMs - 600f) / 500f).coerceIn(0f, 1f)
    val line1 = "PAYMENT DONE"
    val line1Chars = ((elapsedMs - 900f) / 40f).toInt().coerceIn(0, line1.length)

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF120B1E), Color(0xFF2A1220), Color(0xFF120A12)),
                ),
            ),
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            repeat(260) { i ->
                val speed = 0.35f + rnd(i, 300) * 0.55f
                val born = rnd(i, 301)
                val y = h * 0.05f + ((drift * speed + rnd(i, 302)) % 1f) * (h * 1.05f)
                val sway = sin((drift * speed * 2.4f + rnd(i, 303)) * 2f * PI_F) * w * 0.05f
                val x = born * w + sway
                val r = 3f + rnd(i, 304) * 5f
                val spin = drift * 300f * speed + i * 23f
                val a = 0.35f + rnd(i, 305) * 0.45f
                rotate(degrees = spin, pivot = Offset(x, y)) {
                    drawOval(
                        color = petal.copy(alpha = a),
                        topLeft = Offset(x - r, y - r * 0.55f),
                        size = Size(r * 2f, r * 1.1f),
                    )
                }
            }
            repeat(40) { i ->
                val x = rnd(i, 320) * w
                val y = h - 2f - rnd(i, 321) * 10f
                val r = 3f + rnd(i, 322) * 4f
                rotate(degrees = rnd(i, 323) * 180f, pivot = Offset(x, y)) {
                    drawOval(
                        color = petal.copy(alpha = 0.28f),
                        topLeft = Offset(x - r, y - r * 0.5f),
                        size = Size(r * 2f, r),
                    )
                }
            }

            if (sweepX in 0f..1f) {
                val sx = -w * 0.3f + sweepX * w * 1.6f
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.22f),
                            petal.copy(alpha = 0.30f),
                            Color.Transparent,
                        ),
                        start = Offset(sx - w * 0.18f, 0f),
                        end = Offset(sx + w * 0.18f, h),
                    ),
                )
            }
        }

        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier.weight(1f).size(280.dp),
                contentAlignment = Alignment.Center,
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(
                                Color.White.copy(alpha = 0.85f),
                                petal.copy(alpha = 0.55f),
                                Color(0xFF7A3B52).copy(alpha = 0.25f),
                                Color.Transparent
                            ),
                            center = center,
                            radius = 140f,
                        ),
                        center = center,
                        radius = 140f,
                    )
                }
                Canvas(Modifier.size(56.dp)) {
                    val unit = this.size.minDimension / 8f
                    val dots = listOf(1 to 4, 2 to 5, 3 to 6, 4 to 5, 5 to 4, 6 to 3, 7 to 2)
                    dots.forEach { (col, row) ->
                        val reveal = (col + row - 5) / 4f
                        if (checkAssemble >= reveal) {
                            drawRect(
                                color = Color(0xFF6CE59A),
                                topLeft = Offset(col * unit, row * unit),
                                size = Size(unit * 0.85f, unit * 0.85f),
                            )
                        }
                    }
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    line1.take(line1Chars),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    letterSpacing = 2.sp,
                    color = Color(0xFF6CE59A),
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White.copy(alpha = 0.68f),
                    textAlign = TextAlign.Center,
                )
            }

            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 26.dp)
                    .shadow(10.dp, RoundedCornerShape(16.dp), clip = false)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFFFFB7C5), Color(0xFFFF8FB1))))
                    .border(1.dp, Color.White.copy(alpha = 0.30f), RoundedCornerShape(16.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onDone)
                    .padding(vertical = 15.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "Continue",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Ink,
                )
            }
        }
    }
}
