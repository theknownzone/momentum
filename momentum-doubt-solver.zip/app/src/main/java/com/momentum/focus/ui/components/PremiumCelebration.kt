package com.momentum.focus.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val PI_F = PI.toFloat()

@Composable
fun PremiumCelebration(
    title: String,
    subtitle: String,
    onDone: () -> Unit
) {
    val transition = rememberInfiniteTransition(label = "premiumCelebration")
    val pulse by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            tween(1900),
            RepeatMode.Reverse
        ),
        label = "orbPulse"
    )
    val orbit by transition.animateFloat(
        initialValue = 0f,
        targetValue = PI_F * 2f,
        animationSpec = infiniteRepeatable(
            tween(5200, easing = LinearEasing),
            RepeatMode.Restart
        ),
        label = "orbOrbit"
    )
    val fallClock by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(4300, easing = LinearEasing),
            RepeatMode.Restart
        ),
        label = "confettiFall"
    )

    val pieces = remember {
        List(52) { i ->
            ConfettiPiece(
                x = (i * 73 % 100) / 100f,
                phase = (i * 41 % 100) / 100f,
                size = if (i % 3 == 0) 6f else 3.5f,
                drift = if (i % 2 == 0) 28f else 14f,
                spin = if (i % 2 == 0) 1f else -1f,
            )
        }
    }

    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height * 0.42f)
            val orbRadius = size.minDimension * 0.23f * pulse

            // Atmospheric bloom behind the orb.
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(
                        Color.White.copy(alpha = 0.26f),
                        Color(0xFF65C7FF).copy(alpha = 0.20f),
                        Color(0xFF6F62FF).copy(alpha = 0.08f),
                        Color.Transparent,
                    ),
                    center = center,
                    radius = orbRadius * 2.35f,
                ),
                center = center,
                radius = orbRadius * 2.35f,
            )

            // Spherical dot lattice. The z/depth factor makes side dots smaller
            // and dimmer, producing a sphere instead of a flat dot circle.
            val rows = 13
            val cols = 24
            for (row in 0 until rows) {
                val v = row.toFloat() / (rows - 1).toFloat()
                val latitude = (v - 0.5f) * PI_F
                val cosLat = cos(latitude)
                val sinLat = sin(latitude)
                for (col in 0 until cols) {
                    val u = col.toFloat() / cols.toFloat()
                    val longitude = u * PI_F * 2f + orbit * 0.32f
                    val x3 = cosLat * cos(longitude)
                    val y3 = sinLat
                    val z3 = cosLat * sin(longitude)
                    if (z3 < -0.08f) continue

                    val perspective = 0.72f + 0.28f * z3
                    val x = center.x + x3 * orbRadius * perspective
                    val y = center.y + y3 * orbRadius * perspective
                    val radius = (1.35f + 2.2f * ((z3 + 1f) / 2f)) * perspective
                    drawCircle(
                        color = Color(0xFFBFEAFF).copy(
                            alpha = 0.18f + 0.72f * ((z3 + 1f) / 2f)
                        ),
                        radius = radius,
                        center = Offset(x, y),
                    )
                }
            }

            // A few orbital dots sell motion without turning the orb into a
            // spinner.
            for (ring in 0 until 3) {
                val angle = orbit + ring * (PI_F * 2f / 3f)
                val x = center.x + cos(angle) * orbRadius * 1.30f
                val y = center.y + sin(angle * 0.72f) * orbRadius * 0.55f
                drawCircle(
                    color = Color.White.copy(alpha = 0.72f),
                    radius = 2.5f + ring,
                    center = Offset(x, y),
                )
            }

            pieces.forEach { piece ->
                val t = (fallClock + piece.phase) % 1f
                val y = -30f + t * (size.height + 60f)
                val driftAngle = t * PI_F * 2f + piece.phase * PI_F * 2f
                val x = piece.x * size.width + sin(driftAngle) * piece.drift
                rotate(
                    degrees = t * 360f * piece.spin,
                    pivot = Offset(x, y)
                ) {
                    drawRect(
                        color = piece.color.copy(alpha = if (piece.size > 5f) 0.85f else 0.52f),
                        topLeft = Offset(x - piece.size / 2f, y - piece.size / 2f),
                        size = androidx.compose.ui.geometry.Size(
                            piece.size,
                            piece.size * 1.7f
                        ),
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            AnimatedVisibility(
                visible = true,
                enter = fadeIn(tween(650)) + scaleIn(tween(650)),
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(title, color = Color.White, fontSize = 28.sp)
                    Text(
                        subtitle,
                        color = Color.White.copy(alpha = 0.68f),
                        fontSize = 14.sp,
                    )
                }
            }
            Button(onClick = onDone) {
                Text("Continue")
            }
        }
    }
}

private data class ConfettiPiece(
    val x: Float,
    val phase: Float,
    val size: Float,
    val drift: Float,
    val spin: Float,
    val color: Color = Color.White,
)
