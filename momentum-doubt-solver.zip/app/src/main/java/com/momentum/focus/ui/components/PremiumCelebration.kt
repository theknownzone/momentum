package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

private const val TAU = (PI * 2.0).toFloat()

private fun unit(i: Int, salt: Int): Float {
    val x = sin(i * 12.9898 + salt * 78.233) * 43758.5453
    return (x - floor(x)).toFloat()
}

/** Universe-style payoff shown after a successful premium unlock. */
@Composable
fun PremiumCelebration(
    title: String,
    subtitle: String,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()
    var elapsedMs by remember { mutableFloatStateOf(0f) }
    var fired by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (elapsedMs < 5000f) {
            withFrameNanos { now -> elapsedMs = (now - start) / 1_000_000f }
        }
    }
    LaunchedEffect(elapsedMs > 850f) {
        if (elapsedMs > 850f && !fired) {
            fired = true
            Sfx.playOnce(Sound.FESTIVE)
            haptics.unlock()
        }
    }

    val infinite = rememberInfiniteTransition(label = "premium-universe")
    val orbit by infinite.animateFloat(0f, 360f, infiniteRepeatable(tween(12000, easing = LinearEasing)), label = "orbit")
    val pulse by infinite.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(1800), repeatMode = androidx.compose.animation.core.RepeatMode.Reverse), label = "pulse")
    val reveal = ((elapsedMs - 650f) / 650f).coerceIn(0f, 1f)
    val featuresReveal = ((elapsedMs - 1450f) / 800f).coerceIn(0f, 1f)
    val buttonReveal = ((elapsedMs - 2200f) / 450f).coerceIn(0f, 1f)

    val gold = Color(0xFFFFC857)
    val goldBright = Color(0xFFFFE7A3)
    val violet = Color(0xFF8E6CFF)
    val bg = Color(0xFF05040B)
    val panel = Color(0xFF0D0A16).copy(alpha = 0.94f)

    Box(Modifier.fillMaxSize().background(bg)) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val center = androidx.compose.ui.geometry.Offset(w / 2f, h * 0.38f)

            drawCircle(
                Brush.radialGradient(listOf(gold.copy(alpha = 0.14f), Color.Transparent)),
                radius = w * 0.58f,
                center = center,
            )
            drawCircle(
                Brush.radialGradient(listOf(violet.copy(alpha = 0.08f), Color.Transparent)),
                radius = w * 0.82f,
                center = androidx.compose.ui.geometry.Offset(w * 0.18f, h * 0.7f),
            )

            // Deep-space star field: deterministic, so it does not jump every recomposition.
            repeat(110) { i ->
                val x = unit(i, 1) * w
                val travel = ((elapsedMs * (0.000012f + unit(i, 2) * 0.000018f)) + unit(i, 3)) % 1f
                val y = h * (1.02f - travel * 1.18f)
                val r = 0.7f + unit(i, 4) * 1.7f
                val alpha = (0.08f + unit(i, 5) * 0.45f) * (0.25f + travel * 0.75f)
                drawCircle(if (i % 7 == 0) goldBright.copy(alpha = alpha) else Color.White.copy(alpha = alpha), r, androidx.compose.ui.geometry.Offset(x, y))
            }

            // Rising gold particles around the unlock core.
            repeat(28) { i ->
                val angle = unit(i, 6) * TAU
                val radius = w * (0.08f + unit(i, 7) * 0.38f)
                val lift = ((elapsedMs * (0.00003f + unit(i, 8) * 0.000035f)) + unit(i, 9)) % 1f
                val x = center.x + cos(angle) * radius * (0.75f + lift * 0.5f)
                val y = center.y + sin(angle) * radius - lift * h * 0.18f
                drawCircle(gold.copy(alpha = 0.15f + lift * 0.45f), 1.2f + unit(i, 10) * 2.2f, androidx.compose.ui.geometry.Offset(x, y))
            }

            // Orbit rings.
            rotate(orbit, center) {
                drawOval(gold.copy(alpha = 0.20f), topLeft = androidx.compose.ui.geometry.Offset(center.x - w * 0.31f, center.y - w * 0.09f), size = androidx.compose.ui.geometry.Size(w * 0.62f, w * 0.18f), style = Stroke(width = 1.5f))
            }
            rotate(-orbit * 0.65f, center) {
                drawOval(Color.White.copy(alpha = 0.09f), topLeft = androidx.compose.ui.geometry.Offset(center.x - w * 0.39f, center.y - w * 0.13f), size = androidx.compose.ui.geometry.Size(w * 0.78f, w * 0.26f), style = Stroke(width = 1f))
            }
            rotate(orbit * 0.45f, center) {
                drawOval(gold.copy(alpha = 0.10f), topLeft = androidx.compose.ui.geometry.Offset(center.x - w * 0.48f, center.y - w * 0.17f), size = androidx.compose.ui.geometry.Size(w * 0.96f, w * 0.34f), style = Stroke(width = 1f))
            }
        }

        Column(
            Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                "✦  PREMIUM UNLOCKED  ✦",
                color = gold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.6.sp,
                modifier = Modifier.alpha((reveal * 1.3f).coerceIn(0f, 1f)),
            )
            Spacer(Modifier.height(20.dp))

            Box(Modifier.size(148.dp), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size((118f * pulse).dp)
                        .shadow(32.dp, CircleShape, ambientColor = gold, spotColor = gold)
                        .clip(CircleShape)
                        .background(Brush.radialGradient(listOf(goldBright, gold, Color(0xFF9D6410))))
                        .border(1.dp, goldBright.copy(alpha = 0.8f), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("✦", color = Color(0xFF1A1002), fontSize = 46.sp, fontWeight = FontWeight.Black)
                }
                Text("✦", color = goldBright.copy(alpha = 0.75f), fontSize = 16.sp, modifier = Modifier.graphicsLayer { rotationZ = orbit; translationX = 48.dp.toPx(); translationY = (-42).dp.toPx() })
            }

            Spacer(Modifier.height(18.dp))
            Text(
                "WELCOME TO PREMIUM",
                color = Color.White,
                fontSize = 25.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.alpha((reveal * 1.2f).coerceIn(0f, 1f)),
            )
            Spacer(Modifier.height(7.dp))
            Text(
                "Your Momentum just leveled up.",
                color = Color.White.copy(alpha = 0.62f),
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.alpha(reveal),
            )
            Spacer(Modifier.height(20.dp))

            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(panel).border(1.dp, gold.copy(alpha = 0.18f), RoundedCornerShape(22.dp)).padding(17.dp).alpha(featuresReveal),
            ) {
                val items = subtitle.split("\u00b7").map { it.trim() }.filter { it.isNotBlank() }
                items.forEachIndexed { index, item ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 5.dp)) {
                        Box(Modifier.size(22.dp).clip(CircleShape).background(gold.copy(alpha = 0.14f)).border(1.dp, gold.copy(alpha = 0.55f), CircleShape), contentAlignment = Alignment.Center) {
                            Text("✓", color = goldBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(item, color = Color.White.copy(alpha = 0.86f), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    }
                    if (index != items.lastIndex) Spacer(Modifier.height(2.dp))
                }
            }

            Spacer(Modifier.height(22.dp))
            val interaction = remember { MutableInteractionSource() }
            val pressed by interaction.collectIsPressedAsState()
            val scale by animateFloatAsState(if (pressed) 0.965f else 1f, tween(110), label = "continue-scale")
            Box(
                Modifier.fillMaxWidth().alpha(buttonReveal).graphicsLayer { scaleX = scale; scaleY = scale }
                    .shadow(if (pressed) 4.dp else 16.dp, RoundedCornerShape(17.dp), spotColor = gold)
                    .clip(RoundedCornerShape(17.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFFFFB52E), Color(0xFFFFD86B), Color(0xFFFFA915))))
                    .border(1.dp, goldBright.copy(alpha = 0.9f), RoundedCornerShape(17.dp))
                    .clickableNoRipple(interaction, onClick = onDone)
                    .padding(vertical = 15.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("ENTER MOMENTUM  →", color = Color(0xFF1B1000), fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
            }
        }
    }
}
