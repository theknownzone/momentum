package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkLow
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.sin

private val PI_F = PI.toFloat()

private fun rnd(i: Int, salt: Int): Float {
    val x = sin((i * 12.9898 + salt * 78.233)) * 43758.5453
    return (x - floor(x)).toFloat()
}

/**
 * The payoff screen after an actual purchase.
 *
 * Rebuilt to match the receipt-style mock this was actually approved from —
 * a light, paper-toned screen with one bordered card carrying the pixel
 * checkmark and the "PAYMENT DONE" line, not the dark hanami take that
 * replaced it at some point in between. [title]/[subtitle] are the caller's
 * own copy — MainActivity passes "PRO PLUS UNLOCKED" and the
 * "FRIEND + GURU · ALL THEMES · CROWN MODE" line specifically, but neither
 * string is hardcoded here, so the layout, not the words, is what's fixed.
 */
@Composable
fun PremiumCelebration(
    title: String,
    subtitle: String,
    onDone: () -> Unit
) {
    val haptics = rememberHaptics()
    var elapsedMs by remember { mutableFloatStateOf(0f) }
    var sealFired by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { now -> elapsedMs = (now - start) / 1_000_000f }
        }
    }
    LaunchedEffect(elapsedMs > 700f) {
        if (elapsedMs > 700f && !sealFired) {
            sealFired = true
            Sfx.playOnce(Sound.FESTIVE)
            haptics.unlock()
        }
    }

    val infinite = rememberInfiniteTransition(label = "confetti-drift")
    val drift by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(11000, easing = LinearEasing)),
        label = "drift",
    )

    val line1 = "PAYMENT DONE"
    val line1Chars = ((elapsedMs - 550f) / 35f).toInt().coerceIn(0, line1.length)

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF120B1E), Color(0xFF2A1220), Color(0xFF120A12)),
                ),
            ),
    ) {
        // Sakura petals again, not generic confetti rectangles — teardrop
        // shapes in petal-pink, the cinematic dark-hanami stage the receipt
        // card floats on. The card itself stays the light paper it was
        // approved as; only the screen behind it went back to being night.
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val petal = Color(0xFFFFB7C5)
            repeat(90) { i ->
                val speed = 0.12f + rnd(i, 300) * 0.16f
                val y = h * 0.05f + ((drift * speed + rnd(i, 302)) % 1f) * (h * 1.05f)
                val sway = sin((drift * speed * 2.4f + rnd(i, 303)) * 2f * PI_F) * w * 0.06f
                val x = rnd(i, 301) * w + sway
                val r = 3f + rnd(i, 304) * 5f
                val spin = drift * 300f * speed + i * 23f
                rotate(degrees = spin, pivot = Offset(x, y)) {
                    drawOval(
                        color = petal.copy(alpha = 0.30f + rnd(i, 305) * 0.35f),
                        topLeft = Offset(x - r, y - r * 0.55f),
                        size = Size(r * 2f, r * 1.1f),
                    )
                }
            }
        }

        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .shadow(14.dp, RoundedCornerShape(20.dp), clip = false)
                    .clip(RoundedCornerShape(20.dp))
                    .background(CreamCard)
                    .border(2.dp, Mint.accent, RoundedCornerShape(20.dp))
                    .padding(vertical = 32.dp, horizontal = 20.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    // The PhonePe-style morph from the reference: a spinning
                    // loader arc that fills into a solid badge, then a
                    // checkmark draws inside it stroke by stroke — payment
                    // verifying, then confirmed, rather than dots quietly
                    // assembling into a shape with no verifying step shown.
                    Canvas(Modifier.size(56.dp)) {
                        val cx = this.size.width / 2f
                        val cy = this.size.height / 2f
                        val r = this.size.minDimension * 0.42f
                        val morphT = ((elapsedMs - 400f) / 350f).coerceIn(0f, 1f)
                        val checkT = ((elapsedMs - 650f) / 350f).coerceIn(0f, 1f)

                        if (morphT < 1f) {
                            rotate(degrees = elapsedMs * 0.8f) {
                                drawArc(
                                    color = Color(0xFFFF8A5C).copy(alpha = 1f - morphT),
                                    startAngle = 0f,
                                    sweepAngle = 270f,
                                    useCenter = false,
                                    topLeft = Offset(cx - r, cy - r),
                                    size = Size(r * 2f, r * 2f),
                                    style = Stroke(width = this.size.width * 0.09f, cap = StrokeCap.Round),
                                )
                            }
                        }
                        if (morphT > 0f) {
                            drawCircle(
                                color = Mint.accent.copy(alpha = morphT),
                                radius = r * morphT,
                                center = Offset(cx, cy),
                            )
                        }
                        if (checkT > 0f) {
                            val p1 = Offset(cx - r * 0.35f, cy)
                            val p2 = Offset(cx - r * 0.05f, cy + r * 0.30f)
                            val p3 = Offset(cx + r * 0.40f, cy - r * 0.30f)
                            val strokeW = this.size.width * 0.09f
                            if (checkT <= 0.5f) {
                                val segT = checkT / 0.5f
                                drawLine(
                                    Color.White, p1,
                                    Offset(p1.x + (p2.x - p1.x) * segT, p1.y + (p2.y - p1.y) * segT),
                                    strokeWidth = strokeW, cap = StrokeCap.Round,
                                )
                            } else {
                                drawLine(Color.White, p1, p2, strokeWidth = strokeW, cap = StrokeCap.Round)
                                val segT = (checkT - 0.5f) / 0.5f
                                drawLine(
                                    Color.White, p2,
                                    Offset(p2.x + (p3.x - p2.x) * segT, p2.y + (p3.y - p2.y) * segT),
                                    strokeWidth = strokeW, cap = StrokeCap.Round,
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(
                        line1.take(line1Chars),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        letterSpacing = 2.sp,
                        color = Mint.accent,
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Ink,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.alpha(if (elapsedMs > 1300f) 1f else 0f),
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkLow,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.alpha(if (elapsedMs > 1600f) 1f else 0f),
                    )
                }
            }

            Spacer(Modifier.height(28.dp))

            // The tagline — motion-blur per letter, same technique as the
            // wordmark reveal and Home's greeting, starting about a second
            // after the card has actually settled rather than racing it.
            // Split at its own sentence break into two Rows rather than one
            // long non-wrapping Row of 49 characters, which a phone-width
            // screen at readable size would have clipped or overflowed.
            val tagline1 = "Every distraction, blocked."
            val tagline2 = "Every minute, yours."
            val taglineStart = 2600f
            val taglineStep = 22f
            Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                tagline1.forEachIndexed { i, ch ->
                    TaglineChar(ch, elapsedMs > taglineStart + i * taglineStep)
                }
            }
            Spacer(Modifier.height(2.dp))
            Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                val offset = tagline1.length
                tagline2.forEachIndexed { i, ch ->
                    TaglineChar(ch, elapsedMs > taglineStart + (offset + i) * taglineStep)
                }
            }

            Spacer(Modifier.height(28.dp))

            Box(
                Modifier
                    .fillMaxWidth()
                    .alpha(if (elapsedMs > 3900f) 1f else 0f)
                    .shadow(8.dp, RoundedCornerShape(16.dp), clip = false)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Mint.fill)
                    .border(1.dp, Ink, RoundedCornerShape(16.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onDone)
                    .padding(vertical = 15.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "Continue",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Mint.on,
                )
            }
        }
    }
}

/** One letter of the tagline, blurring in the same way the wordmark's do. */
@Composable
private fun TaglineChar(char: Char, visible: Boolean) {
    val t by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(160, easing = LinearOutSlowInEasing),
        label = "tagline-char",
    )
    if (t <= 0f) return
    Text(
        char.toString(),
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = Color(0xFFFFB7C5),
        modifier = Modifier
            .alpha(t)
            .graphicsLayer {
                translationY = (1f - t) * -4f
                if (android.os.Build.VERSION.SDK_INT >= 31) {
                    val radius = ((1f - t) * 6f).coerceAtLeast(0.01f)
                    renderEffect = android.graphics.RenderEffect
                        .createBlurEffect(radius, radius, android.graphics.Shader.TileMode.CLAMP)
                        .asComposeRenderEffect()
                }
            },
    )
}
