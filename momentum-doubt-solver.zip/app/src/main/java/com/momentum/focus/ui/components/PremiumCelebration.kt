package com.momentum.focus.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin

// PI is a Double in kotlin.math. Every particle field below stays Float by
// converting once, here, rather than trusting an implicit conversion Kotlin
// doesn't actually perform.
private val PI_F = PI.toFloat()

@Composable
fun PremiumCelebration(
    title: String,
    subtitle: String,
    onDone: () -> Unit
) {
    val transition = rememberInfiniteTransition(label = "celebration")
    val pulse by transition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            tween(1800),
            RepeatMode.Reverse
        ),
        label = "orbPulse"
    )

    // A single looping clock (0..1 over 4.2s) drives every piece of
    // confetti. Each piece reads it at its own phase offset instead of
    // getting its own animateFloat, so 52 pieces cost one animation, not 52.
    val fallClock by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(4200, easing = LinearEasing),
            RepeatMode.Restart
        ),
        label = "confettiFall"
    )

    val palette = remember {
        listOf(
            Color(0xFF79C7FF), Color(0xFFB9E8FF), Color(0xFF9D8CFF),
            Color(0xFFFFD54A), Color(0xFFFFFFFF),
        )
    }

    // Two size classes, not fifty-two individual sizes -- near pieces are
    // bigger, fall faster and drift more; far pieces are smaller, fall
    // slower and drift less. That gap is what reads as depth rather than
    // "confetti of slightly different sizes".
    val pieces = remember {
        List(48) { index ->
            val near = index % 2 == 0
            ConfettiPiece(
                baseX = (index * 137 % 100) / 100f,
                phase = (index * 71 % 100) / 100f,
                near = near,
                fallSpeed = if (near) 1.15f else 0.75f,
                driftAmp = if (near) 26f else 12f,
                driftFreq = 1.4f + (index % 5) * 0.3f,
                spin = (if (index % 2 == 0) 1f else -1f) * (0.6f + (index % 4) * 0.25f),
                size = if (near) 7f else 4f,
                color = palette[index % palette.size],
            )
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            // The one thing missing that made this screen look blank: no
            // background at all. It rendered over whatever was behind it —
            // reached via the same early-return-before-Scaffold path
            // sessionWon/streakWon use, so there was no cream Scaffold
            // behind it either, just the raw window background, which
            // defaults light. White title and subtitle text on that is
            // invisible; only the orb (its own gradient) and the Continue
            // button (its own Material theming) ever showed.
            .background(Color(0xFF0D0E14)),
    ) {
        // Confetti spans the whole screen -- it was confined to the same
        // 300dp box as the orb before, which reads as a sparkle ring around
        // the orb rather than confetti filling the air over a celebration.
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            pieces.forEach { piece ->
                val t = ((fallClock * piece.fallSpeed + piece.phase) % 1f + 1f) % 1f
                // Falls from just above the top edge to just below the
                // bottom edge, so it enters and exits off-screen rather than
                // popping in or cutting off mid-fall.
                val y = -40f + t * (h + 80f)
                val driftAngle = t * PI_F * piece.driftFreq * 2f + piece.phase * PI_F * 2f
                val x = piece.baseX * w + sin(driftAngle) * piece.driftAmp
                val rotationDeg = t * 360f * piece.spin

                rotate(degrees = rotationDeg, pivot = Offset(x, y)) {
                    drawRect(
                        color = piece.color.copy(alpha = if (piece.near) 0.85f else 0.5f),
                        topLeft = Offset(x - piece.size / 2f, y - piece.size / 2f),
                        size = androidx.compose.ui.geometry.Size(piece.size, piece.size * 1.6f),
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Canvas(
                modifier = Modifier
                    .weight(1f)
                    .size(300.dp)
            ) {
                val center = Offset(size.width / 2f, size.height / 2f)
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(
                            Color.White.copy(alpha = 0.95f),
                            Color(0xFF79C7FF).copy(alpha = 0.7f),
                            Color(0xFF367BFF).copy(alpha = 0.25f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = 150f * pulse
                    ),
                    center = center,
                    radius = 150f * pulse
                )
            }

            AnimatedVisibility(
                visible = true,
                enter = fadeIn(tween(650)) + scaleIn(tween(650))
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(title, color = Color.White)
                    Text(subtitle, color = Color.White.copy(alpha = 0.65f))
                }
            }

            Button(onClick = onDone) {
                Text("Continue")
            }
        }
    }
}

private data class ConfettiPiece(
    val baseX: Float,
    val phase: Float,
    val near: Boolean,
    val fallSpeed: Float,
    val driftAmp: Float,
    val driftFreq: Float,
    val spin: Float,
    val size: Float,
    val color: Color,
)
