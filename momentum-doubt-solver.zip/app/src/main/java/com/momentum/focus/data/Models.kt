package com.momentum.focus.data

import kotlinx.serialization.Serializable
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * What one drill actually tested, and what was got wrong.
 *
 * None of this used to be kept. A mock was built, answered, scored and thrown
 * away when the sheet closed — MockState is an in-memory flow and clearMock
 * empties it. So the app could not tell you what you were weak at, and neither
 * could the model: asking it to choose the next drill meant asking it to guess,
 * because there was nothing to look at.
 *
 * [missed] holds the questions that were answered wrong, trimmed short. They
 * are the useful part. A score says a drill went badly; the missed questions
 * say what to set next.
 */
@Serializable
data class MockResult(
    val epochDay: Long,
    val subject: String,
    val topic: String,
    val score: Int,
    val total: Int,
    val missed: List<String> = emptyList(),
)

@Serializable
data class FocusSession(
    val startedAtEpochDay: Long,
    val minutes: Int,
    val subject: String,
    val completed: Boolean,
    /**
     * The earn ratio in force when this session was banked.
     *
     * Rupees used to be worked out from lifetime minutes divided by whatever
     * ratio happened to be current, which meant the whole wallet was repriced
     * every time the user changed focus level or the weekend arrived. Dropping
     * from Hard to Soft tripled a balance that had already been earned. A
     * session is priced once, when it is banked, and never again.
     */
    val ratio: Int = 8,
)

@Serializable
data class UrgeEvent(
    val epochDay: Long,
    val hour: Int,
    val survived: Boolean,
    val note: String = "",
)

@Serializable
data class JournalEntry(
    val epochDay: Long,
    val mood: Int,          // 1..5
    val text: String,
    val trigger: String = "",
)

@Serializable
data class Slip(
    val epochDay: Long,
    val reason: String,
    val regretted: Boolean,
)


/**
 * A named set of rules the user can switch between.
 *
 * One blocklist could not describe a real week. WhatsApp has to go at
 * midnight and come back at eight; a Sunday needs less than a Monday. Without
 * this the only way to get either was to edit the list by hand twice a day,
 * which nobody does, so people set one harsh list and turned the app off
 * instead.
 *
 * A profile is a snapshot, not a live link. Activating one copies its values
 * into the live settings; editing the live settings afterwards does not write
 * back. That keeps "what is switched on right now" a single answer rather than
 * something assembled from a profile plus overrides.
 */
@Serializable
data class BlockProfile(
    val id: String,
    val name: String,
    val blockedPackages: Set<String> = emptySet(),
    val dailyCapMinutes: Map<String, Int> = emptyMap(),
    val blockedSurfaces: Set<String> = emptySet(),
    val classHoursOn: Boolean = true,
    val classDays: Set<Int> = setOf(1, 2, 3, 4, 5, 6),
    val profiles: List<BlockProfile> = emptyList(),
    /** Which profile's rules are loaded, for display only. Empty means custom. */
    val activeProfileId: String = "",
    val classStartHour: Int = 6,
    val classEndHour: Int = 22,
)

/**
 * How much XP one level costs. See [AppData.level].
 *
 * Top level rather than inside AppData so the screens that draw the progress
 * ring and the "N xp to level" caption can read the same number the maths
 * uses, without an AppData instance in hand.
 */
const val XP_PER_LEVEL = 600

@Serializable
data class AppData(
    val userName: String = "friend",
    val streakStartEpochDay: Long = LocalDate.now().toEpochDay(),
    val bestStreak: Int = 0,
    val streakGoal: Int = 90,
    val sessions: List<FocusSession> = emptyList(),
    val urges: List<UrgeEvent> = emptyList(),
    val journal: List<JournalEntry> = emptyList(),
    /**
     * Empty until the user names them.
     *
     * Defaulting to Physics/Maths/Chemistry quietly decided the app was for
     * science students. A commerce student saw three subjects they do not
     * study, a UPSC aspirant saw school subjects, and both got told their
     * Physics was "untouched in 30 days" — a reproach for not studying
     * something they never signed up for. Blank asks instead of assuming.
     */
    val subjects: List<String> = emptyList(),

    /**
     * Recent drill results, newest last. Capped — see recordMock.
     *
     * Kept so the app can say what you are weak at instead of asking you every
     * time, and so the model setting the next drill has something real to aim
     * at.
     */
    val mockResults: List<MockResult> = emptyList(),
    val onboarded: Boolean = false,
    val spentMinutes: Int = 0,
    val blockedPackages: Set<String> = emptySet(),
    val shieldOn: Boolean = false,
    val avatarColor: Int = 3,
    val avatarShape: Int = 0,
    val skin: Int = 0,
    /**
     * Language code, "hi" (Hinglish) or "en". Defaults to English now.
     *
     * This used to default to Hinglish, on the reasoning that it's what the
     * app was written in and what most existing users read fastest. That
     * reasoning was sound for people already using the app — it said nothing
     * about the install screen a brand new person sees before they've told
     * the app anything about themselves. Onboarding, and the app's starting
     * state generally, now begins in English by explicit product decision;
     * Hinglish is still one tap away in Settings for anyone who wants it.
     */
    val lang: String = "en",
    /**
     * The last weekly coach report, as JSON, and when it was produced.
     *
     * Kept here so it survives a restart and so the weekly gap is enforced
     * against a real timestamp rather than an in-memory guess. Blank on any
     * build without an API key, because the feature never runs there.
     */
    val coachJson: String = "",
    val coachAtMs: Long = 0L,
    val lastSeenVersion: String = "",
    val lastSeenChangelog: Int = 0,
    /** Minutes of study needed to earn one minute of distraction. */
    val earnRatio: Int = 8,
    val focusLevel: Int = 2,
    val crownMode: Boolean = false,
    val studyPackages: Set<String> = emptySet(),
    val studyXp: Int = 0,
    val guessHours: Int = 0,
    val guessPickups: Int = 0,
    val baselineMinutes: Int = 0,
    val examName: String = "",
    val examEpochDay: Long = 0L,
    /** Crown mode switches itself on inside this many days of the exam. */
    val examCrownDays: Int = 30,
    /**
     * Channels allowed to play when [studyOnlyYouTube] is on.
     *
     * Stored lowercase and trimmed so a name typed with different capitals
     * still matches — people add these from memory, not from a copy-paste.
     */
    val allowedChannels: Set<String> = emptySet(),
    val studyOnlyYouTube: Boolean = false,
    val weekendRelaxed: Boolean = true,
    val classHoursOn: Boolean = true,
    /**
     * Weekdays the class-hours window applies to, 1 = Monday through 7 =
     * Sunday. A single window with no day filter meant Sunday was policed like
     * a school day, which is the fastest way to get the whole feature switched
     * off. Default is Mon-Sat, matching an Indian school week.
     */
    val classDays: Set<Int> = setOf(1, 2, 3, 4, 5, 6),
    val profiles: List<BlockProfile> = emptyList(),
    /** Which profile's rules are loaded, for display only. Empty means custom. */
    val activeProfileId: String = "",
    val classStartHour: Int = 6,
    val classEndHour: Int = 22,
    val lockUntilEpochMs: Long = 0L,
    /**
     * Which in-app feeds the guard shields, by FeedSurface key. Defaults are
     * applied at first run rather than here, so a user who turns everything
     * off does not have it all switch back on next launch.
     */
    val blockedSurfaces: Set<String> = emptySet(),
    val surfacesSeeded: Boolean = false,
    /**
     * package -> minutes allowed per day. Optional and empty by default; a cap
     * only ever tightens. Once a package is over its cap the shield fires for
     * the rest of the day regardless of the wallet, so paying cannot buy past
     * a limit the user set for themselves.
     */
    val dailyCapMinutes: Map<String, Int> = emptyMap(),
    val slips: List<Slip> = emptyList(),
    val lastCelebratedLevel: Int = 1,
    /**
     * Whether the Crown cutscene has played.
     *
     * Once, ever. The first time is the moment worth marking; the fortieth is
     * four seconds standing between someone and their book.
     */
    val crownIntroSeen: Boolean = false,
    /**
     * UI sounds.
     *
     * Stored, because the switch on Profile only ever set an in-memory flag on
     * Sfx: turning sound on lasted until the app was next killed, and there was
     * no way to tell the difference between "off" and "forgotten".
     */
    /**
     * On from the first launch.
     *
     * It defaulted to off, which meant every sound in the app existed and
     * nobody heard one unless they went looking through Settings for a switch
     * they had no reason to think was there. A feature nobody discovers is the
     * same as a feature nobody built. Off is a choice people make after
     * hearing it, not before.
     */
    val soundOn: Boolean = true,

    /**
     * Nudges outside a session: exam alerts, the weekly read, streak warnings.
     *
     * Separate from the running-session notification, which is a foreground
     * service and cannot be turned off without killing the timer. This one
     * only governs the things the app chooses to say.
     */
    val notifyOn: Boolean = true,
    /**
     * Kept only so an install from before [celebratedBadgeIds] existed can be
     * told apart from a genuinely new one. A count cannot say *which* badge
     * was earned, which is why it stopped being enough.
     */
    val lastCelebratedBadges: Int = 0,
    /**
     * Ids of badges whose celebration screen has already been shown.
     *
     * This is not a second source of truth for whether a badge is earned —
     * that stays computed in [achievements]. It only records what the user has
     * already been shown, which nothing else can derive.
     */
    val celebratedBadgeIds: Set<String> = emptySet(),
    /** Day of the first launch. 0 until it has been stamped. */
    val firstOpenEpochDay: Long = 0L,
    /** The five-step walkthrough has been shown. */
    val tourSeen: Boolean = false,
    /**
     * Lifetime unlock. Deliberately not consulted by anything that blocks a
     * distraction — the shield, the feed guard, the pact and panic all work the
     * same whether this is true or false. Paywalling the thing that stops a
     * relapse would make the app fail at the one job it has.
     */
    val premium: Boolean = false,
    /** The key that unlocked it, kept so it can be shown and re-checked. */
    val licenseKey: String = "",
    /**
     * A session that is currently running, kept across process death.
     *
     * The timer used to live only in the ViewModel, so swiping the app away
     * killed it — someone would study for forty minutes, come back, and find
     * the clock reset to zero with nothing banked. Storing when it ends means
     * the remaining time can be recomputed from the wall clock on relaunch
     * instead of being trusted to a coroutine that no longer exists.
     */
    val liveSessionEndsAtMs: Long = 0L,
    val liveSessionTotalSec: Int = 0,
    val liveSessionStartedAtMs: Long = 0L,
    val liveSessionSubject: String = "",
    /**
     * Doubts asked since the current session began, zeroed when the next one
     * starts.
     *
     * Stored rather than held in the ViewModel for the same reason the session
     * itself is: an in-memory count is cleared by force-stopping the app, and
     * a limit you can lift by force-stopping the app is not a limit. It sits
     * here beside the live session because that is what it is scoped to.
     */
    val doubtsUsed: Int = 0,
    val pendingReflectionMinutes: Int = 0,
) {
    val pactLive: Boolean
        get() = lockUntilEpochMs > System.currentTimeMillis()

    /**
     * Whole days since the first launch, or null before it was stamped.
     *
     * Three days of one person's usage is not a trend, and presenting it as
     * one would be the same failure as a streak that climbs while nobody
     * studies — a number that looks earned and is not.
     */
    val daysCollecting: Int?
        get() = if (firstOpenEpochDay <= 0L) null
        else (java.time.LocalDate.now().toEpochDay() - firstOpenEpochDay).toInt()

    /**
     * Consecutive days ending today or yesterday with real completed minutes.
     *
     * This used to be plain calendar arithmetic from a start date, which meant
     * it kept climbing for someone who had not opened a book in a month. A
     * streak that rises while you do nothing is the same lie as a fake usage
     * number, and it is worse here because the whole app is built on it.
     *
     * Today not being studied yet does not break the streak — it is only
     * broken once a full day has been missed.
     */
    /**
     * Computed once per snapshot, not once per read.
     *
     * This was `get()`, which walks every session in the store every single
     * time it is read — and it is read in sixteen places, several of them
     * inside scrolling screens, so on a long history it ran on every frame of
     * every scroll. AppData is immutable and a new instance is built on each
     * store write, so `by lazy` gives exactly one walk per snapshot and the
     * scroll gets its frames back.
     *
     * The same reasoning applies to every derived value below it.
     */
    val streakDays: Int by lazy {
        val today = LocalDate.now().toEpochDay()
        val studied = sessions.filter { it.completed && it.minutes > 0 }
            .map { it.startedAtEpochDay }
            .toSet()
        // Labelled returns, because this is a lambda now and a bare `return`
        // would try to leave the enclosing function.
        if (studied.isEmpty()) return@lazy 0
        // Start from today if it counts, otherwise from yesterday.
        var cursor = if (today in studied) today else today - 1
        if (cursor !in studied) return@lazy 0
        var count = 0
        // A logged relapse moves this floor to today, so the walk stops
        // there. Without it resetStreak had nothing left to reset and the
        // "I slipped" button silently did nothing.
        while (cursor in studied && cursor >= streakStartEpochDay) {
            count++
            cursor--
        }
        count
    }

    fun minutesOn(day: Long): Int =
        sessions.filter { it.startedAtEpochDay == day && it.completed }.sumOf { it.minutes }

    val minutesToday: Int get() = minutesOn(LocalDate.now().toEpochDay())

    /**
     * Completed minutes in a seven-day window, counting back from today.
     *
     * [weeksAgo] 0 is the last seven days including today, 1 is the seven
     * before that. Rolling windows rather than calendar weeks on purpose: a
     * calendar week resets on Monday, so someone comparing on a Tuesday would
     * be holding one day up against seven and concluding they had collapsed.
     *
     * Derived from sessions, which are already stored — no new field, nothing
     * to migrate, and nothing a second counter could drift away from.
     */
    fun weekMinutes(weeksAgo: Int = 0): Int {
        val today = LocalDate.now().toEpochDay()
        val newest = today - weeksAgo * 7L
        val oldest = newest - 6L
        return sessions
            .filter { it.completed && it.startedAtEpochDay in oldest..newest }
            .sumOf { it.minutes }
    }

    val sessionsToday: Int
        get() = sessions.count {
            it.startedAtEpochDay == LocalDate.now().toEpochDay() && it.completed
        }

    /** Minutes per day for the last [days] days, oldest first. */
    fun recentMinutes(days: Int): List<Int> {
        val today = LocalDate.now().toEpochDay()
        return (days - 1 downTo 0).map { minutesOn(today - it) }
    }

    val urgesSurvived: Int by lazy { urges.count { it.survived } }

    /**
     * Minutes per subject over the last 30 days, biggest first.
     *
     * The subject you have been avoiding is invisible in a single total, and
     * it is almost always the one that decides the result.
     */
    fun subjectSplit(): List<Pair<String, Int>> {
        val cutoff = LocalDate.now().toEpochDay() - 30
        val byName = sessions
            .filter { it.completed && it.startedAtEpochDay >= cutoff }
            // A "Bas focus" session is filed with no subject. The Focus screen
            // promises it lands under General, so it has to have a name here or
            // the minutes vanish from the breakdown entirely.
            .groupBy { it.subject.ifBlank { "General" } }
            .mapValues { (_, list) -> list.sumOf { it.minutes } }
        // Subjects with no time still appear, at zero. A missing row reads as
        // "not tracked"; a zero row reads as "you have not touched this".
        val all = (subjects + byName.keys).distinct()
        return all.map { it to (byName[it] ?: 0) }.sortedByDescending { it.second }
    }

    /** Every completed minute of focus, for display. Not the wallet. */
    val earnedMinutes: Int by lazy { sessions.filter { it.completed }.sumOf { it.minutes } }

    /**
     * What is left to spend on distraction.
     *
     * Each session is converted at the ratio it was banked at, so eight
     * minutes of study buys one minute of scrolling and stays bought. The
     * accumulation runs in hundredths so a run of short sessions is not
     * rounded away one at a time.
     *
     * Filtered on minutes, not on [FocusSession.completed]. Those are two
     * different questions and this is the one about money: a session that was
     * abandoned but still cleared the seventy percent bar is paid, and it is
     * recorded as not completed on purpose, because the streak and the success
     * score both measure finishing. Filtering the wallet on completed as well
     * meant those minutes were audited, priced, written into history — and then
     * silently never paid. Forty honest minutes could vanish between the
     * session log and the balance.
     */
    val earnedRupees: Int by lazy {
        sessions.filter { it.minutes > 0 }
            .sumOf { (it.minutes * 100L) / it.ratio.coerceAtLeast(1) }
            .let { (it / 100L).toInt() }
    }

    val balanceMinutes: Int by lazy { (earnedRupees - spentMinutes).coerceAtLeast(0) }

    /**
     * XP in one level.
     *
     * A constant because six places used the literal 600 and none of them got
     * it from each other: the two lines below, the progress ring and the
     * "xp to level N" caption on Profile, and the "$xp/600 xp" string in both
     * language tables. Retuning the curve meant finding all six, and missing
     * one means a bar that fills at the wrong place or a caption that counts
     * down to a level it does not reach.
     *
     * This project has already shipped that exact bug once — the plans page
     * advertised a five-question mock after the drill was doubled to ten,
     * because the number was typed rather than read.
     */
    val level: Int get() = 1 + (studyXp / XP_PER_LEVEL)
    val xpIntoLevel: Int get() = studyXp % XP_PER_LEVEL

    /**
     * The topic worth drilling next, from the last few results.
     *
     * Weakest first, ties broken by recency. Null when there is nothing to go
     * on — which is the honest answer on a fresh install and is why this
     * returns a nullable rather than picking a subject at random. The app
     * guessing what you should revise, with no evidence, is the bug this whole
     * record exists to fix.
     *
     * A drill scored 8/10 or better is not a weakness, so it is not offered
     * back. Repeating what someone has already shown they know is how a
     * revision tool starts wasting their time.
     */
    val weakestDrill: MockResult?
        get() = mockResults
            .takeLast(8)
            .filter { it.total > 0 && it.score * 10 < it.total * 8 }
            .minByOrNull { it.score.toFloat() / it.total }

    val daysToExam: Int?
        get() = if (examEpochDay == 0L) null
                else (examEpochDay - LocalDate.now().toEpochDay()).toInt()

    val examIsClose: Boolean
        get() = daysToExam?.let { it in 0..examCrownDays } == true

    /** Saturday or Sunday, used to loosen the rules if the user allows it. */
    val isWeekend: Boolean
        get() = LocalDate.now().dayOfWeek.value >= 6

    /**
     * Minutes of study that buy one minute of scroll, after everything that
     * moves it.
     *
     * The focus level is in here now, and it was not before. Light, Lock and
     * Crown all earned at exactly the same rate — so the picker said "4 min =
     * ₹1" under all three, and choosing Crown bought a three hour pact that
     * cannot be shortened, a device admin lock and a locked Settings screen in
     * return for nothing at all. A commitment device that costs more and pays
     * the same is one nobody has a reason to pick.
     *
     * Rounded up, so a better level never quietly becomes a worse one through
     * integer division, and floored at one.
     */
    val effectiveRatio: Int
        get() {
            val byLevel = when {
                focusLevel >= 3 -> (earnRatio * 6 + 9) / 10
                focusLevel == 2 -> (earnRatio * 8 + 9) / 10
                else -> earnRatio
            }
            val weekend = if (weekendRelaxed && isWeekend) byLevel / 2 else byLevel
            return weekend.coerceAtLeast(1)
        }

    /**
     * The share of slips the user later called a mistake, per reason. This is
     * the one number no other app has, because it needs a question asked after
     * the craving has passed rather than during it.
     */
    fun regretRate(reason: String): Pair<Int, Int> {
        val all = slips.filter { it.reason == reason }
        return all.count { it.regretted } to all.size
    }

    val todayJournal: JournalEntry?
        get() = journal.firstOrNull { it.epochDay == LocalDate.now().toEpochDay() }
}

fun nowHour(): Int = LocalDateTime.now().hour

/**
 * Minutes of real study a session must reach before it pays anything.
 *
 * Seventy percent of what was planned, so a fifty minute session cannot be
 * cashed in after two. It lives here rather than in the view model because the
 * Focus screen has to show the bar before someone sits down and the view model
 * has to enforce it afterwards — and when the two computed it separately, a
 * change to one would have silently disagreed with the other.
 */
fun bankBar(plannedMinutes: Int): Int = maxOf(1, (plannedMinutes * 7) / 10)
