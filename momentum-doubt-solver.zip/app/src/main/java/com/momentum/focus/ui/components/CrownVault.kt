package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.tr
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Crown Vault — the confirmation for the one tap in the app that arms a lock
 * it refuses to undo (owner: old popup "baccho wala lag raha").
 *
 * Look: a black-and-gold vault card on a dark scrim. No emoji: a drawn gold
 * crown, Roman-numeral terms, the lock length set like a safe's dial.
 * Consent is HOLD-TO-ARM (1.4 s): a deliberate press that can't happen by
 * accident, replacing the checkbox + button pair. Releasing early springs it
 * back. Haptic ticks at each quarter, a heavy thump on arm.
 *
 * Motion: card rises + settles (spring), crown strokes in, one gold sheen
 * sweeps the header. No loops.
 */
private val Gold = Color(0xFFE8C26B)
private val GoldDeep = Color(0xFFB8862F)
private val GoldPale = Color(0xFFFFE9B0)
private val Vault = Color(0xFF121110)
private val VaultEdge = Color(0xFF2A2621)
private val Cream = Color(0xFFF4ECD8)

/** A crown, drawn — five points, band, three jewels. [p] 0..1 draws it in. */
fun DrawScope.crownGlyph(p: Float = 1f, stroke: Float = 3f, fill: Boolean = true) {
    val w = size.width; val h = size.height
    val path = Path().apply {
        moveTo(w * 0.08f, h * 0.78f)
        lineTo(w * 0.04f, h * 0.30f)
        lineTo(w * 0.28f, h * 0.52f)
        lineTo(w * 0.50f, h * 0.14f)
        lineTo(w * 0.72f, h * 0.52f)
        lineTo(w * 0.96f, h * 0.30f)
        lineTo(w * 0.92f, h * 0.78f)
        close()
    }
    if (fill) drawPath(path, Brush.verticalGradient(listOf(GoldPale, Gold, GoldDeep)), alpha = p)
    drawPath(path, Color(0xFF3A2A0A), style = Stroke(stroke), alpha = p)
    drawRect(Brush.horizontalGradient(listOf(GoldDeep, Gold, GoldDeep)), Offset(w * 0.08f, h * 0.80f), Size(w * 0.84f * p, h * 0.12f))
    listOf(0.04f to 0.30f, 0.50f to 0.14f, 0.96f to 0.30f).forEach { (x, y) ->
        drawCircle(Color.White.copy(alpha = 0.9f * p), w * 0.045f, Offset(w * x, h * y))
    }
}

@Composable
fun CrownVaultBrief(
    hours: Int,
    onClose: () -> Unit,
    onArm: () -> Unit,
) {
    val haptics = rememberHaptics()
    val scope = rememberCoroutineScope()
    val canBlur = rememberCanBlur()
    val rise = remember { Animatable(0f) }
    val draw = remember { Animatable(0f) }
    val sheen = remember { Animatable(-0.3f) }
    val vctx = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) {
        CrownVoice.warm(vctx)   // ready long before the cinematic's voice beat
        launch { rise.animateTo(1f, spring(Spring.DampingRatioLowBouncy, Spring.StiffnessMediumLow)) }
        delay(120)
        launch { draw.animateTo(1f, tween(520, easing = FastOutSlowInEasing)) }
        delay(260)
        sheen.animateTo(1.3f, tween(800, easing = FastOutSlowInEasing))
    }

    val hold = remember { Animatable(0f) }
    var armed by remember { mutableStateOf(false) }

    // FitDialog: above the app tab bar, sized to THIS phone; the hold button
    // is pinned below the scroll so it can never be cut off (owner shot).
    FitDialog(onClose) { maxH ->
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.72f * rise.value.coerceIn(0f, 1f)))
            .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .graphicsLayer {
                    val v = rise.value
                    alpha = v.coerceIn(0f, 1f)
                    translationY = (1f - v) * 60.dp.toPx()
                    scaleX = 0.94f + 0.06f * v; scaleY = 0.94f + 0.06f * v
                }
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.verticalGradient(listOf(VaultEdge, Vault, Vault)))
                .border(1.dp, Gold.copy(alpha = 0.55f), RoundedCornerShape(28.dp))
                .clickableNoRipple(remember { MutableInteractionSource() }) { /* swallow */ }
                .heightIn(max = maxH),
        ) {
          Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
            // Header: crown on a soft gold halo, sheen sweeps once.
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .drawBehind {
                        drawCircle(
                            Brush.radialGradient(listOf(Gold.copy(alpha = 0.28f), Color.Transparent), radius = size.minDimension * 0.75f),
                            radius = size.minDimension * 0.75f, center = Offset(size.width / 2, size.height * 0.55f),
                        )
                        val x = size.width * sheen.value
                        drawRect(
                            Brush.linearGradient(
                                listOf(Color.Transparent, GoldPale.copy(alpha = 0.18f), Color.Transparent),
                                start = Offset(x - 140f, 0f), end = Offset(x + 140f, size.height),
                            )
                        )
                    },
                contentAlignment = Alignment.Center,
            ) {
                Canvas(Modifier.size(width = 84.dp, height = 64.dp).graphicsLayer {
                    scaleX = 0.8f + 0.2f * draw.value; scaleY = 0.8f + 0.2f * draw.value
                }) { crownGlyph(draw.value, 2.5.dp.toPx()) }
                IconClose(Modifier.align(Alignment.TopEnd).padding(12.dp)) { haptics.tick(); onClose() }
            }

            Column(Modifier.padding(horizontal = 22.dp)) {
                Text(
                    tr("CROWN MODE", "क्राउन मोड"),
                    fontSize = 11.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Black, color = Gold,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    tr("The strongest lock in Momentum.", "Momentum का सबसे मज़बूत लॉक।"),
                    fontSize = 24.sp, lineHeight = 28.sp, fontWeight = FontWeight.Black, color = Cream,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    tr("No undo button. Read it once, properly.", "कोई अनडू नहीं। एक बार ठीक से पढ़ लो।"),
                    fontSize = 14.sp, color = Cream.copy(alpha = 0.6f), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(18.dp))

                // The dial: lock length, the one fact that changes the decision.
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White.copy(alpha = 0.04f))
                        .border(1.dp, Gold.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "%d:00:00".format(hours),
                        fontFamily = FontFamily.Monospace, fontSize = 30.sp, fontWeight = FontWeight.Black, color = Gold,
                    )
                    Spacer(Modifier.width(14.dp))
                    Text(
                        tr("starts the moment you arm. Extend it any time — never shorten it.", "आर्म करते ही शुरू। बढ़ा सकते हो — घटा नहीं सकते।"),
                        fontSize = 13.sp, lineHeight = 18.sp, color = Cream.copy(alpha = 0.85f),
                    )
                }
                Spacer(Modifier.height(16.dp))

                listOf(
                    tr("Blocked apps stay shut for the whole session.", "पूरे सेशन ब्लॉक ऐप्स बंद रहेंगे।"),
                    tr("Uninstalling is locked — device admin turns on.", "अनइंस्टॉल लॉक — डिवाइस एडमिन चालू होगा।"),
                    tr("Settings stay sealed while a session runs.", "सेशन के दौरान Settings बंद रहेगी।"),
                    tr("After the lock you can step down — that session's earnings go with it.", "लॉक के बाद नीचे आ सकते हो — उस सेशन की कमाई जाएगी।"),
                ).forEachIndexed { i, line ->
                    val a = remember { Animatable(0f) }
                    LaunchedEffect(Unit) { delay(300L + i * 60L); a.animateTo(1f, tween(240, easing = FastOutSlowInEasing)) }
                    Row(
                        Modifier.padding(vertical = 6.dp).graphicsLayer { alpha = a.value; translationX = (1f - a.value) * 16.dp.toPx() },
                        verticalAlignment = Alignment.Top,
                    ) {
                        Text(
                            listOf("I", "II", "III", "IV")[i],
                            fontFamily = FontFamily.Serif, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Gold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.width(30.dp).padding(top = 1.dp),
                        )
                        Text(line, fontSize = 15.sp, lineHeight = 21.sp, color = Cream)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
          }
          // Pinned footer: a gold hairline, then the hold.
          Box(Modifier.fillMaxWidth().height(1.dp).background(Gold.copy(alpha = 0.25f)))
          Column(Modifier.padding(start = 22.dp, end = 22.dp, top = 14.dp)) {
                // Hold-to-arm.
                val shape = RoundedCornerShape(18.dp)
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .graphicsLayer { val s = 1f - 0.03f * (hold.value.coerceIn(0f, 1f)); scaleX = s; scaleY = s }
                        .clip(shape)
                        .background(Brush.verticalGradient(listOf(Color(0xFF2E2718), Color(0xFF1E1A12))))
                        .border(1.5.dp, Gold, shape)
                        .drawBehind {
                            val w = size.width * hold.value
                            drawRect(Brush.horizontalGradient(listOf(GoldDeep, Gold, GoldPale)), size = Size(w, size.height))
                        }
                        .pointerInput(armed) {
                            if (armed) return@pointerInput
                            awaitEachGesture {
                                awaitFirstDown()
                                haptics.tick()
                                val job = scope.launch {
                                    var last = 0
                                    hold.animateTo(1f, tween(((1f - hold.value) * 1400).toInt().coerceAtLeast(1), easing = LinearEasing)) {
                                        val q = (value * 4).toInt()
                                        if (q > last) { last = q; haptics.tick() }
                                    }
                                    armed = true
                                    haptics.celebrate()
                                    Sfx.play(Sound.SUCCESS)
                                    onArm()
                                }
                                waitForUpOrCancellation()
                                if (!armed) {
                                    job.cancel()
                                    scope.launch { hold.animateTo(0f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)) }
                                }
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (hold.value > 0.02f) tr("Keep holding…", "दबाए रखो…") else tr("Hold to arm Crown", "क्राउन आर्म करने को दबाए रखो"),
                        fontSize = 17.sp, fontWeight = FontWeight.Black,
                        color = if (hold.value > 0.5f) Vault else Gold,
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    tr("Not now", "अभी नहीं"),
                    fontSize = 14.sp, color = Cream.copy(alpha = 0.55f),
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .clip(RoundedCornerShape(10.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) { haptics.tick(); onClose() }
                        .padding(10.dp),
                )
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}
}

@Composable
private fun IconClose(modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Gold.copy(alpha = 0.4f), CircleShape)
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(12.dp)) {
            drawLine(Gold, Offset.Zero, Offset(size.width, size.height), 2.dp.toPx())
            drawLine(Gold, Offset(size.width, 0f), Offset(0f, size.height), 2.dp.toPx())
        }
    }
}
