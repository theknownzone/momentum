Momentum UI/animation patch

- Removed Streak from bottom navigation (streak data remains available in existing surfaces).
- Replaced onboarding foreground artwork with supplied full-fit illustrations.
- Made onboarding ghost artwork visible behind the content with controlled blur/fade.
- Replaced first-install hero with supplied phone/lock artwork, full-fit with motion/blur entry.
- Reworked setup completion hero to use the orb avatar and larger typography.
- Reworked AI reveal orb: larger glass sphere, connected aura ribbons, lower horizon bloom and rim light.
- Reworked AI thinking indicator with breathing fluid rings around the dot field.
- Reworked Premium receipt scene to use a sanitized supplied-receipt-inspired artwork and dynamic licence key overlay.
- Tightened premium printer timing and synchronized motor sound to the same visual playhead.
- Made WELCOME TO MOMENTUM PREMIUM appear as a dedicated, visible beat before completion.
- Removed instructional permission interstitials; native/system permission surfaces remain.
