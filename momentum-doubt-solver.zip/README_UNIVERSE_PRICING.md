# Universe Pricing UI pass

Implemented on top of the previous Momentum source without changing the purchase callbacks or plan data flow.

## PlansScreen changes
- Added a cinematic universe/starfield layer with upward-moving particles.
- Added soft orbital curves and the existing concentric-ring atmosphere.
- Reworked the pricing header toward the supplied reference: **SIMPLE, TRANSPARENT PRICING**.
- The pricing pager now opens on the middle Premium/Pro tier so the primary conversion card is centered.
- Added horizontal peek spacing so adjacent plans remain visible behind the centered card.
- Reworked the middle Pro card to the gold/amber premium treatment: glow, animated living border, glass/dark surface, premium badge and CTA.
- Existing `onBuy`, license redemption, remove-license and back navigation are preserved.
- Existing haptic calls remain wired to interactions.

## Preview
Open `design/plans-universe-pricing-preview.html` for a browser preview of the visual direction.
