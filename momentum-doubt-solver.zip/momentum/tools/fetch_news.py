#!/usr/bin/env python3
"""
Pulls fresh notices from the boards and merges them into exam-news.json.

Design rule, and the only one that matters: **this never deletes anything.**

A scraper that rewrites the file wholesale is one bad afternoon away from
emptying the app's news feed for everyone — a site changes its markup, every
parser returns nothing, the file is written as `[]`, and the feature is gone
until someone notices. So this only ever adds. Hand-written entries survive
forever, and a board that goes quiet or changes its HTML simply contributes
nothing that run.

Each board is its own function returning a list of entries. When one breaks,
it breaks alone: the exception is caught, logged, and the other boards still
publish. Fixing a board means fixing one function.
"""

import json
import os
import re
import sys
from datetime import date
from html import unescape
from urllib.request import Request, urlopen

HERE = os.path.dirname(os.path.abspath(__file__))
FEED = os.path.join(HERE, "..", "exam-news.json")

# Boards block obvious bots. A real UA is not a trick, it is the minimum
# needed to be served the same page a browser gets.
UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile"

# Nothing older than this is worth pushing to a student as "news".
MAX_ITEMS_PER_BOARD = 6


def fetch(url, timeout=20):
    req = Request(url, headers={"User-Agent": UA})
    with urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "ignore")


def clean(text):
    """Tags out, entities decoded, whitespace collapsed."""
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", unescape(text)).strip()


def trim(text, limit=96):
    """
    Cuts at a word, not mid-word, and marks that it was cut.

    Board titles run long — "Notice for Post Result Declaration Facilities to
    the Students, Class XII Supplementary Examination 2026 (2.72 MB)" — and a
    hard slice landed in the middle of a number, so the card read "...2026
    (2.72" and looked like the data was broken rather than long. Cutting at a
    space and adding an ellipsis says "there is more", which is true and is
    what the tap is for.

    The trailing file size every board appends is dropped first: nobody
    choosing what to read cares that the PDF is 638 KB.
    """
    text = re.sub(r"\s*\((?:\d+(?:\.\d+)?)\s*[KMkm]B\)\s*$", "", text).strip()
    if len(text) <= limit:
        return text
    cut = text[:limit].rsplit(" ", 1)[0].rstrip(" ,;:-—(")
    return cut + "…"


def slug(text):
    s = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return s[:60]


def absolute(base, href):
    if href.startswith("http"):
        return href
    if href.startswith("/"):
        return base.rstrip("/") + href
    return base.rstrip("/") + "/" + href


# ---------------------------------------------------------------- boards
#
# Each returns a list of dicts in the app's own shape. The selectors here are
# the fragile part and they are meant to be: when a board redesigns, this is
# the function to open. Keep them short so that is a five minute job.


def cbse():
    base = "https://www.cbse.gov.in"
    html = fetch(base + "/cbsenew/cbse.html")
    out = []
    # The notice board is a list of anchors inside the marquee/latest block.
    for href, label in re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', html, re.S):
        title = clean(label)
        if len(title) < 25:
            continue
        if not re.search(r"date ?sheet|result|circular|notice|exam", title, re.I):
            continue
        out.append(
            {
                "id": "cbse-" + slug(title),
                "title": trim(title),
                "body": "From the CBSE notice board.",
                "exam": "CBSE",
                "region": "All India",
                "date": date.today().isoformat(),
                "url": absolute(base, href),
            }
        )
        if len(out) >= MAX_ITEMS_PER_BOARD:
            break
    return out


def rbse():
    base = "https://rajeduboard.rajasthan.gov.in"
    html = fetch(base + "/")
    out = []
    for href, label in re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', html, re.S):
        title = clean(label)
        if len(title) < 25:
            continue
        if not re.search(r"date ?sheet|result|notice|exam|समय|परिणाम", title, re.I):
            continue
        out.append(
            {
                "id": "rbse-" + slug(title),
                "title": trim(title),
                "body": "Rajasthan board notice.",
                "exam": "RBSE",
                "region": "Rajasthan",
                "date": date.today().isoformat(),
                "url": absolute(base, href),
            }
        )
        if len(out) >= MAX_ITEMS_PER_BOARD:
            break
    return out


def ibps():
    base = "https://www.ibps.in"
    html = fetch(base + "/")
    out = []
    for href, label in re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', html, re.S):
        title = clean(label)
        if len(title) < 25:
            continue
        if not re.search(r"recruit|notification|admit|result|exam|calendar", title, re.I):
            continue
        out.append(
            {
                "id": "ibps-" + slug(title),
                "title": trim(title),
                "body": "IBPS notification.",
                "exam": "IBPS",
                "region": "All India",
                "date": date.today().isoformat(),
                "url": absolute(base, href),
            }
        )
        if len(out) >= MAX_ITEMS_PER_BOARD:
            break
    return out


def from_rss(url, exam, region, body, prefix, want=None):
    """
    Reads an RSS feed and turns its items into entries.

    RSS first, everywhere it exists, because it is the one part of a site that
    is *meant* to be read by a program. Scraping a homepage means guessing at
    markup written for a browser, and it breaks the week someone redesigns the
    header. A feed has a fixed shape, carries a real publish date, and keeps
    working through a redesign.
    """
    xml = fetch(url)
    out = []
    for block in re.findall(r"<item>(.*?)</item>", xml, re.S):
        title = clean(re.search(r"<title>(.*?)</title>", block, re.S).group(1)) \
            if re.search(r"<title>", block) else ""
        link_m = re.search(r"<link>(.*?)</link>", block, re.S)
        link = clean(link_m.group(1)) if link_m else ""
        if len(title) < 15 or not link:
            continue
        # Some aggregators post everything under the sun. When a filter is
        # given, keep only what a student preparing would care about.
        if want and not re.search(want, title, re.I):
            continue
        # RSS dates are RFC-822: "Sat, 06 Sep 2026 04:30:00 +0000". Only the
        # day is wanted and a formatter for that would be three imports.
        pub = re.search(r"<pubDate>(.*?)</pubDate>", block)
        when = date.today().isoformat()
        if pub:
            m = re.search(r"(\d{1,2}) (\w{3}) (\d{4})", pub.group(1))
            if m:
                months = "JanFebMarAprMayJunJulAugSepOctNovDec"
                mi = months.find(m.group(2)) // 3 + 1
                when = f"{m.group(3)}-{mi:02d}-{int(m.group(1)):02d}"
        out.append(
            {
                "id": f"{prefix}-" + slug(title),
                "title": trim(title),
                "body": body,
                "exam": exam,
                "region": region,
                "date": when,
                "url": link,
            }
        )
        if len(out) >= MAX_ITEMS_PER_BOARD:
            break
    return out


def sarkari_result():
    return from_rss(
        "https://www.sarkariresult.com/feed/",
        exam="Sarkari",
        region="All India",
        body="Government job and exam notice.",
        prefix="sr",
    )


def free_job_alert():
    return from_rss(
        "https://www.freejobalert.com/feed/",
        exam="Sarkari",
        region="All India",
        body="Recruitment, admit card or result.",
        prefix="fja",
    )


def sarkari_exam():
    return from_rss(
        "https://www.sarkariexam.com/feed/",
        exam="Sarkari",
        region="All India",
        body="Exam notification.",
        prefix="se",
    )


BOARDS = [
    # Aggregators first: one feed each and they already cover most boards, so
    # a board scraper failing matters less.
    ("SarkariResult", sarkari_result),
    ("FreeJobAlert", free_job_alert),
    ("SarkariExam", sarkari_exam),
    # The boards themselves, for the things aggregators are slow on —
    # date sheets and practical schedules.
    ("CBSE", cbse),
    ("RBSE", rbse),
    ("IBPS", ibps),
]


def main():
    with open(FEED, encoding="utf-8") as f:
        existing = json.load(f)

    # Keyed by id, so re-running is harmless and a notice that appears on a
    # board for weeks does not appear in the feed a dozen times.
    seen = {e["id"] for e in existing}
    added = []

    for name, fn in BOARDS:
        try:
            for entry in fn():
                if entry["id"] in seen:
                    continue
                seen.add(entry["id"])
                added.append(entry)
            print(f"{name}: ok")
        except Exception as exc:
            # Logged, not raised. One broken board must not stop the others,
            # and it must not fail the workflow — a red build every morning
            # trains everyone to ignore the builds.
            print(f"{name}: skipped ({exc})", file=sys.stderr)

    if not added:
        print("nothing new")
        return

    # Newest first, and the hand-written entries keep their place underneath.
    merged = added + existing
    with open(FEED, "w", encoding="utf-8") as f:
        json.dump(merged, f, indent=2, ensure_ascii=False)
        f.write("\n")
    print(f"added {len(added)}")


if __name__ == "__main__":
    main()
