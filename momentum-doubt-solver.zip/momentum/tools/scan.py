#!/usr/bin/env python3
"""Pre-push checks for the Momentum Kotlin sources.

This is not a type checker. It catches a handful of specific mistakes that
have actually happened in this project, so a CI run isn't spent discovering
them one at a time:

  1. brackets   — unbalanced {} or () (string- and comment-aware)
  2. parity     — a string-table interface member missing from Hi or En
  3. resolve    — str.section.member that no interface declares
  4. scope      — a function using `str` without binding it
  5. imports    — the same import twice
  6. shadow     — a lambda parameter with the same name as the strings binding

Run from the repo root:

    python3 tools/scan.py

Exit code is 1 if anything is found, so it can gate a push.
"""

from __future__ import annotations

import os
import re
import sys

ROOT = "app/src/main/java/com/momentum/focus"


# ------------------------------------------------------------------ helpers

def blank_noncode(src: str) -> str:
    """Replace strings and comments with spaces, keeping newlines and length.

    Bracket counting is meaningless otherwise: this codebase is full of
    literals containing braces, and of `${...}` templates whose braces do
    count. Template braces are kept for that reason.
    """
    out, i, n = [], 0, len(src)
    while i < n:
        c = src[i]
        if c == "\n":
            out.append("\n")
            i += 1
        elif c == "/" and i + 1 < n and src[i + 1] == "/":
            while i < n and src[i] != "\n":
                out.append(" ")
                i += 1
        elif c == "/" and i + 1 < n and src[i + 1] == "*":
            while i + 1 < n and not (src[i] == "*" and src[i + 1] == "/"):
                out.append("\n" if src[i] == "\n" else " ")
                i += 1
            out.append("  ")
            i += 2
        elif src.startswith('"""', i):
            out.append("   ")
            i += 3
            while i < n and not src.startswith('"""', i):
                out.append("\n" if src[i] == "\n" else " ")
                i += 1
            out.append("   ")
            i += 3
        elif c == '"':
            out.append(" ")
            i += 1
            depth = 0
            while i < n:
                if src[i] == "\\":
                    out.append("  ")
                    i += 2
                    continue
                if src[i] == "{":
                    depth += 1
                    out.append("{")
                elif src[i] == "}":
                    depth -= 1
                    out.append("}")
                elif src[i] == '"' and depth <= 0:
                    break
                else:
                    out.append("\n" if src[i] == "\n" else " ")
                i += 1
            out.append(" ")
            i += 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


def kt_files(root: str):
    for dirpath, _, files in os.walk(root):
        for f in sorted(files):
            if f.endswith(".kt"):
                yield os.path.join(dirpath, f)


def body_after(code: str, start: int) -> str:
    """Return the braced block that opens at or after `start`."""
    i = code.find("{", start)
    if i < 0:
        return ""
    depth, j = 0, i
    while j < len(code):
        if code[j] == "{":
            depth += 1
        elif code[j] == "}":
            depth -= 1
            if depth == 0:
                return code[i:j + 1]
        j += 1
    return code[i:]


# ------------------------------------------------------------------- checks

def check_brackets(files, report):
    for path in files:
        code = blank_noncode(open(path, encoding="utf-8").read())
        for op, cl, name in (("{", "}", "brace"), ("(", ")", "paren")):
            d = code.count(op) - code.count(cl)
            if d:
                report("brackets", path, 0, f"{name} off by {d:+d}")


def collect_tables(root: str):
    """interface name -> members, and object name -> (interface, overrides)."""
    interfaces, objects = {}, {}
    i18n = os.path.join(root, "ui/i18n")
    if not os.path.isdir(i18n):
        return interfaces, objects
    for path in kt_files(i18n):
        src = open(path, encoding="utf-8").read()
        code = blank_noncode(src)
        for m in re.finditer(r"\binterface\s+(\w+)\s*\{", code):
            body = body_after(code, m.end() - 1)
            members = set(re.findall(r"^\s*(?:val|fun)\s+(\w+)", body, re.M))
            interfaces[m.group(1)] = (members, path)
        for m in re.finditer(r"\bobject\s+(\w+)\s*:\s*(\w+)\s*\{", code):
            body = body_after(code, m.end() - 1)
            overrides = set(re.findall(r"^\s*override\s+(?:val|fun)\s+(\w+)", body, re.M))
            objects[m.group(1)] = (m.group(2), overrides, path)
    return interfaces, objects


def check_parity(interfaces, objects, report):
    for obj, (iface, overrides, path) in sorted(objects.items()):
        if iface not in interfaces:
            continue
        members, _ = interfaces[iface]
        missing = members - overrides
        extra = overrides - members
        for name in sorted(missing):
            report("parity", path, 0, f"{obj} does not implement {iface}.{name}")
        for name in sorted(extra):
            report("parity", path, 0, f"{obj} overrides {name}, absent from {iface}")


def check_resolve(files, interfaces, root, report):
    """Every str.section.member must exist on the section's interface."""
    strings_kt = os.path.join(root, "ui/i18n/Strings.kt")
    if not os.path.exists(strings_kt):
        return
    code = blank_noncode(open(strings_kt, encoding="utf-8").read())
    m = re.search(r"\binterface\s+Strings\s*\{", code)
    if not m:
        return
    # section property name -> interface type
    sections = dict(re.findall(r"^\s*val\s+(\w+)\s*:\s*(\w+)", body_after(code, m.end() - 1), re.M))
    for path in files:
        if "/ui/i18n/" in path:
            continue
        code = blank_noncode(open(path, encoding="utf-8").read())
        for hit in re.finditer(r"\b(?:s|str)\.(\w+)\.(\w+)", code):
            sec, member = hit.group(1), hit.group(2)
            iface = sections.get(sec)
            if not iface or iface not in interfaces:
                continue          # `s` is something else here — not our table
            if member not in interfaces[iface][0]:
                line = code[:hit.start()].count("\n") + 1
                report("resolve", path, line, f"no {iface}.{member}")


FUN_RE = re.compile(r"^(?:@\w+\s*(?:\([^)]*\))?\s*)*(?:private\s+|internal\s+)?fun\s+"
                    r"(?:<[^>]*>\s*)?(?:\w+\.)?(\w+)\s*\(", re.M)


def check_scope(files, report):
    """A function that says `str.` must bind `str` somewhere it can see."""
    for path in files:
        if "/ui/i18n/" in path:
            continue
        code = blank_noncode(open(path, encoding="utf-8").read())
        for m in FUN_RE.finditer(code):
            # signature runs to the brace that opens the body
            body = body_after(code, m.end())
            if not body or "str." not in body:
                continue
            sig = code[m.start():code.find("{", m.end())]
            bound = ("val str" in body or "str:" in sig
                     or "str =" in body)
            if not bound:
                line = code[:m.start()].count("\n") + 1
                report("scope", path, line, f"fun {m.group(1)}() uses str, never binds it")


def check_imports(files, report):
    for path in files:
        seen = set()
        for n, line in enumerate(open(path, encoding="utf-8"), 1):
            if line.startswith("import "):
                key = line.strip()
                if key in seen:
                    report("imports", path, n, f"duplicate {key}")
                seen.add(key)


def check_shadow(files, report):
    """A lambda param named like the strings binding hides it."""
    for path in files:
        code = blank_noncode(open(path, encoding="utf-8").read())
        # A Strings binding must never be called `s`, whether it comes from
        # strings() or arrives as a parameter. `s` is the reflex name for a
        # session, a subject, a sticker — and any lambda using it hides the
        # table. This bit WalletScreen and FocusScreen before it was a rule.
        for m in re.finditer(r"\bval\s+s\s*=\s*strings\(\)|\bs\s*:\s*Strings\b", code):
            line = code[:m.start()].count("\n") + 1
            report("shadow", path, line, "Strings bound as `s` — call it `str`")

        if "val str = strings()" in code or "str: Strings" in code:
            for m in re.finditer(r"\{\s*str\s*(?::|->)", code):
                line = code[:m.start()].count("\n") + 1
                report("shadow", path, line, "lambda param `str` shadows the strings binding")


# --------------------------------------------------------------------- main

def main() -> int:
    root = ROOT
    if not os.path.isdir(root):
        print(f"run me from the repo root ({root} not found)", file=sys.stderr)
        return 2

    findings = []

    def report(kind, path, line, msg):
        findings.append((kind, os.path.relpath(path, root), line, msg))

    files = list(kt_files(root))
    interfaces, objects = collect_tables(root)

    check_brackets(files, report)
    check_parity(interfaces, objects, report)
    check_resolve(files, interfaces, root, report)
    check_scope(files, report)
    check_imports(files, report)
    check_shadow(files, report)

    print(f"scanned {len(files)} Kotlin files, "
          f"{len(interfaces)} string interfaces, {len(objects)} tables\n")

    if not findings:
        print("nothing found")
        return 0

    by_kind: dict[str, list] = {}
    for kind, path, line, msg in findings:
        by_kind.setdefault(kind, []).append((path, line, msg))
    for kind in sorted(by_kind):
        print(f"{kind} ({len(by_kind[kind])})")
        for path, line, msg in sorted(by_kind[kind]):
            where = f"{path}:{line}" if line else path
            print(f"    {where}  {msg}")
        print()
    return 1


if __name__ == "__main__":
    sys.exit(main())
