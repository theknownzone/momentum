package com.momentum.focus.block

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppStore
import com.momentum.focus.data.Currency
import androidx.compose.material3.Divider
import com.momentum.focus.ui.components.Coin3D
import com.momentum.focus.ui.components.FrostScrim
import com.momentum.focus.ui.components.FrostSheet
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * The shield. Deliberately hard to leave and easy to obey.
 *
 * The "spend minutes" button is locked for a few seconds after the screen
 * appears. That pause is the whole mechanism: a craving fades in seconds, and
 * a button you cannot press yet is the difference between a decision and a
 * reflex.
 */
class ShieldActivity : ComponentActivity() {

    companion object {
        const val EXTRA_PACKAGE = "pkg"
        const val COST_MINUTES = 10
        const val LOCK_SECONDS = 7
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Shows over the lock screen and keeps the screen on: a shield that
        // vanishes when the display sleeps is not a shield.
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val pkg = intent.getStringExtra(EXTRA_PACKAGE) ?: ""
        val store = AppStore(applicationContext)

        setContent {
            MomentumTheme {
                val scope = rememberCoroutineScope()
                val haptics = rememberHaptics()

                var balance by remember { mutableIntStateOf(0) }
                var streak by remember { mutableIntStateOf(0) }
                var crown by remember { mutableStateOf(false) }
                var countdown by remember { mutableIntStateOf(LOCK_SECONDS) }
                var confirmPay by remember { mutableStateOf(false) }
                val label = remember(pkg) { appLabel(pkg) }
                val isSettings = remember(pkg) {
                    pkg == "com.android.settings" ||
                        pkg.startsWith("com.android.settings.")
                }

                LaunchedEffect(Unit) {
                    val data = store.data.first()
                    balance = data.balanceMinutes
                    streak = data.streakDays
                    crown = data.crownMode
                    while (countdown > 0) {
                        delay(1000)
                        countdown--
                    }
                    haptics.tick()
                }

                Column(
                    Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .paperGrain()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(horizontal = Paper.ScreenPad)
                        .padding(top = 40.dp, bottom = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        "BLOCKED",
                        style = MaterialTheme.typography.labelSmall,
                        color = Tang.accent,
                    )
                    Text(
                        label,
                        style = MaterialTheme.typography.displayMedium,
                        color = Ink,
                        textAlign = TextAlign.Center,
                    )

                    Spacer(Modifier.height(28.dp))

                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(Paper.CardRadius))
                            .background(Mint.fill)
                            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                            .padding(20.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Coin3D(color = Butter.fill, size = 26.dp)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "WALLET BALANCE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Mint.on.copy(alpha = 0.75f),
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                Currency.format(balance),
                                style = MaterialTheme.typography.displayMedium,
                                color = Mint.on,
                            )

                            Spacer(Modifier.height(14.dp))
                            Divider(color = Mint.on.copy(alpha = 0.25f))
                            Spacer(Modifier.height(12.dp))

                            // A receipt, not a warning. Seeing the balance
                            // after the purchase is what makes the cost land.
                            ReceiptRow("Entry price", "−${Currency.format(COST_MINUTES)}", Mint.on)
                            ReceiptRow(
                                "Left after this",
                                Currency.format((balance - COST_MINUTES).coerceAtLeast(0)),
                                Mint.on,
                            )
                            ReceiptRow("Streak", "$streak days", Mint.on.copy(alpha = 0.8f))
                        }
                    }

                    Spacer(Modifier.weight(1f))

                    SquishButton(
                        label = "Close it",
                        sticker = Mint,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        haptics.confirm()
                        goHome()
                    }

                    Spacer(Modifier.height(12.dp))

                    val affordable = balance >= COST_MINUTES
                    val unlocked = countdown == 0

                    // Settings is only ever blocked while a Crown session is
                    // running, and it is the one place you go to switch this
                    // app off — so the way out has to be spelled out rather
                    // than left to be discovered. Ending the session unblocks
                    // it at once, and partial time is still banked, so this
                    // costs the session and nothing else.
                    if (isSettings) {
                        Text(
                            "Settings is locked while a Crown session runs.\n\n" +
                                "Need it now? Open Momentum and press " +
                                "\"Give up — log partial time\". Settings comes " +
                                "straight back and your minutes so far are kept.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = Tang.accent,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(12.dp))
                        SquishButton(
                            label = "Open Momentum",
                            sticker = Tang,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            haptics.tick()
                            runCatching {
                                packageManager.getLaunchIntentForPackage(packageName)
                                    ?.let { startActivity(it) }
                            }
                            finish()
                        }
                    } else if (crown) {
                        Text(
                            "Crown mode is on. No buying your way in.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = Tang.accent,
                            textAlign = TextAlign.Center,
                        )
                    } else if (!unlocked) {
                        Text(
                            "Unlocking in $countdown",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    } else if (!affordable) {
                        Text(
                            "Not enough in the wallet. Go earn ${Currency.format(COST_MINUTES)}.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                    } else {
                        SquishButton(
                            label = "Pay ${Currency.format(COST_MINUTES)}",
                            sticker = Tang,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            haptics.tick()
                            confirmPay = true
                        }
                    }
                }

                if (confirmPay) {
                    FrostScrim {
                        Box(
                            Modifier
                                .fillMaxSize()
                                .padding(horizontal = Paper.ScreenPad),
                            contentAlignment = Alignment.BottomCenter,
                        ) {
                            FrostSheet(Modifier.padding(bottom = 28.dp)) {
                                Column(Modifier.padding(20.dp)) {
                                    Text(
                                        "Spend ${Currency.format(COST_MINUTES)}?",
                                        style = MaterialTheme.typography.headlineSmall,
                                        color = Ink,
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        "Wallet will drop to ${Currency.format((balance - COST_MINUTES).coerceAtLeast(0))}.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Ink.copy(alpha = 0.7f),
                                    )
                                    Spacer(Modifier.height(16.dp))
                                    SquishButton(
                                        label = "Pay and open",
                                        sticker = Tang,
                                        modifier = Modifier.fillMaxWidth(),
                                    ) {
                                        haptics.reject()
                                        scope.launch {
                                            store.update {
                                                it.copy(
                                                    spentMinutes = it.spentMinutes + COST_MINUTES,
                                                    pendingReflectionMinutes = COST_MINUTES,
                                                )
                                            }
                                            BlockerService.allow(pkg, COST_MINUTES)
                                            finish()
                                        }
                                    }
                                    Spacer(Modifier.height(10.dp))
                                    SquishButton(
                                        label = "Keep blocked",
                                        sticker = Mint,
                                        modifier = Modifier.fillMaxWidth(),
                                    ) { confirmPay = false }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun ReceiptRow(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                label,
                style = MaterialTheme.typography.bodyLarge,
                color = color.copy(alpha = 0.75f),
                modifier = Modifier.weight(1f),
            )
            Text(value, style = MaterialTheme.typography.titleMedium, color = color)
        }
    }

    private fun appLabel(pkg: String): String = runCatching {
        val info = packageManager.getApplicationInfo(pkg, 0)
        packageManager.getApplicationLabel(info).toString()
    }.getOrDefault(pkg)

    /** Send the user to the launcher rather than back into the blocked app. */
    private fun goHome() {
        val home = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(home)
        finish()
    }

    @Deprecated("Back must not dismiss the shield")
    override fun onBackPressed() {
        goHome()
    }
}
