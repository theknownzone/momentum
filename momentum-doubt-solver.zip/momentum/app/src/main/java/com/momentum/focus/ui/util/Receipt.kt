package com.momentum.focus.ui.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * The unlock receipt -- a thermal-printer slip, rendered and saved to the
 * device's Downloads folder.
 *
 * Drawn rather than composed because the output is a file, not a screen. A
 * Compose surface would have to be captured to a bitmap anyway, and capture
 * pulls in view-tree plumbing that only exists while something is on screen;
 * a plain Canvas has neither problem and produces the same pixels whether the
 * app is foregrounded or not.
 *
 * The look is deliberately a till receipt: monospace, centred header, dotted
 * rules, a torn zigzag bottom edge. A licence is a purchase, and a purchase
 * that hands back something shaped like a receipt reads as settled in a way
 * that a "Thank you!" card does not.
 */
object Receipt {

    private const val W = 720
    private const val PAD = 56f

    /**
     * Renders the slip and writes it to Downloads.
     *
     * Returns the display name on success, null on any failure. Null rather
     * than an exception because the caller is an animation: a receipt that
     * could not be saved should cost the user nothing more than a missing
     * file, never a crash on the screen that just took their money.
     */
    suspend fun saveToDownloads(context: Context, data: AppData): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = render(data)
                val name = "momentum-receipt-${System.currentTimeMillis()}.png"
                if (Build.VERSION.SDK_INT >= 29) {
                    // MediaStore on API 29+, because scoped storage means a
                    // direct write to the public Downloads path is denied.
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, "image/png")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val uri = resolver.insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, values,
                    ) ?: return@runCatching null
                    resolver.openOutputStream(uri)?.use {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                } else {
                    // Pre-29 the public directory is writable directly, and
                    // MediaStore.Downloads does not exist yet.
                    @Suppress("DEPRECATION")
                    val dir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS,
                    )
                    dir.mkdirs()
                    File(dir, name).outputStream().use {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                }
                name
            }.getOrNull()
        }

    private fun render(data: AppData): Bitmap {
        // Final saved receipt mirrors the on-screen success moment: black stage,
        // neon-green confirmation, torn notebook paper and a clean payment
        // hierarchy. It uses Momentum data only; no third-party payment details.
        val w = 1080
        val h = 1600
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap)
        c.drawColor(Color.BLACK)

        val green = Color.rgb(0x65, 0xFF, 0x65)
        val greenSoft = Color.rgb(0x29, 0xA8, 0x3B)
        val paper = Color.rgb(0xF6, 0xF2, 0xE8)
        val ink = Color.rgb(0x1A, 0x1A, 0x1A)
        val muted = Color.rgb(0x55, 0x55, 0x55)
        val mono = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        val bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

        // Sparse green confetti/glow: decorative only, no animation in the
        // saved image and no random data that could make exports inconsistent.
        val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = greenSoft; alpha = 55 }
        c.drawCircle(w / 2f, 210f, 190f, glow)
        val confetti = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = green; alpha = 180 }
        val pieces = listOf(
            110f to 190f, 180f to 360f, 900f to 190f, 950f to 420f,
            80f to 760f, 1000f to 740f, 130f to 1180f, 920f to 1160f,
            220f to 1320f, 850f to 1350f
        )
        pieces.forEachIndexed { i, (x, y) ->
            c.save()
            c.rotate((i * 17 % 35) - 17f, x, y)
            c.drawRect(x - 10f, y - 18f, x + 10f, y + 18f, confetti)
            c.restore()
        }

        // Success seal above the paper.
        val sealPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = green }
        c.drawCircle(w / 2f, 190f, 88f, sealPaint)
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 7f
        }
        c.drawCircle(w / 2f, 190f, 80f, ring)
        val check = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 14f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val cp = Path().apply {
            moveTo(w / 2f - 38f, 190f)
            lineTo(w / 2f - 8f, 220f)
            lineTo(w / 2f + 52f, 154f)
        }
        c.drawPath(cp, check)

        val left = 135f
        val right = w - 135f
        val top = 305f
        val bottom = 1290f

        // Slightly tilted paper, matching the reference composition.
        c.save()
        c.rotate(-3.5f, w / 2f, (top + bottom) / 2f)
        val paperPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = paper }
        c.drawRect(left, top, right, bottom, paperPaint)

        // Punched top edge.
        val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
        var hx = left + 42f
        while (hx < right - 25f) {
            c.drawCircle(hx, top + 4f, 15f, hole)
            hx += 62f
        }

        val centre = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = bold; color = ink }
        centre.textSize = 74f
        c.drawText("₹399", w / 2f, top + 285f, centre)

        centre.textSize = 31f
        c.drawText("Momentum Premium Paid", w / 2f, top + 350f, centre)
        centre.textSize = 29f
        c.drawText("Lifetime Access", w / 2f, top + 400f, centre)

        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = mono; color = ink; textSize = 26f }
        val name = data.userName.ifBlank { "Momentum user" }
        c.drawText(name, w / 2f, top + 465f, body)
        body.textSize = 22f
        c.drawText("Premium access unlocked", w / 2f, top + 505f, body)

        dotted(c, top + 555f)
        body.textSize = 21f
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, h:mma"))
        c.drawText(stamp + "  •  MOMENTUM", w / 2f, top + 620f, body)
        c.drawText("License  " + License.pretty(data.licenseKey), w / 2f, top + 660f, body)

        centre.textSize = 29f
        c.drawText("PAID WITH MOMENTUM", w / 2f, top + 760f, centre)
        body.textSize = 19f
        c.drawText("PREMIUM  •  LIFETIME", w / 2f, top + 805f, body)
        c.drawText("POWERED BY MOMENTUM", w / 2f, top + 845f, body)

        // Torn lower edge.
        val tear = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
        val tp = Path().apply {
            moveTo(left, bottom - 2f)
            var x = left
            var up = true
            while (x <= right + 30f) {
                x += 28f
                lineTo(x, if (up) bottom + 18f else bottom - 18f)
                up = !up
            }
            lineTo(right + 30f, bottom + 45f)
            lineTo(left, bottom + 45f)
            close()
        }
        c.drawPath(tp, tear)
        c.restore()

        val footer = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = bold; color = Color.WHITE; textSize = 34f }
        c.drawText("Done  →", w / 2f, 1450f, footer)
        val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = mono; color = green; textSize = 18f }
        c.drawText("PAYMENT SUCCESSFUL  •  ONE STEP CLOSER", w / 2f, 1490f, sub)
        return bitmap
    }

    private fun dotted(c: Canvas, y: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            strokeWidth = 2f
        }
        var x = PAD
        while (x < W - PAD) {
            c.drawLine(x, y, x + 6f, y, p)
            x += 14f
        }
    }

    private fun dashedBox(c: Canvas, top: Float, bottom: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2f
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f, 8f), 0f)
        }
        c.drawRect(PAD - 8f, top, W - PAD + 8f, bottom, p)
    }

    /** The zigzag tear at the bottom, the way a slip leaves the printer. */
    private fun tornEdge(c: Canvas, h: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.TRANSPARENT }
        p.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR)
        val path = Path().apply {
            moveTo(0f, h)
            var x = 0f
            var up = true
            moveTo(0f, h - 22f)
            while (x < W) {
                x += 24f
                lineTo(x, if (up) h else h - 22f)
                up = !up
            }
            lineTo(W.toFloat(), h)
            lineTo(0f, h)
            close()
        }
        c.drawPath(path, p)
    }
}
