package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.*

/**
 * A tiny illustrated walkthrough shown before handing someone off to a system
 * settings screen, instead of dropping them there cold.
 *
 * Regain-style apps do this with an actual screenshot of the destination
 * screen, numbered circles overlaid on top of it. This app draws its own
 * illustration instead of a real screenshot for two reasons: a captured
 * screenshot is one specific OEM's settings UI and looks wrong on every other
 * phone (Xiaomi's toggle screen looks nothing like Samsung's), and every
 * other surface in this app is hand-drawn rather than photographed — a real
 * screenshot here would be the one photographic thing in an illustrated app.
 * A drawn phone with a drawn toggle makes the same point — "this is what you
 * are about to see, and this is what to do with it" — without either
 * problem.
 */
@Composable
fun PermGuideSheet(
    title: String,
    art: TileArt,
    tone: Sticker,
    steps: List<String>,
    onContinue: () -> Unit,
    onDismiss: () -> Unit,
) {
    FrostScrim {
        Box(
            Modifier.fillMaxSize().padding(horizontal = Paper.ScreenPad),
            contentAlignment = Alignment.BottomCenter,
        ) {
            FrostSheet {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TileObject(art = art, fill = tone.fill, size = 40.dp)
                        Spacer(Modifier.width(12.dp))
                        Text(
                            title,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = Ink,
                            modifier = Modifier.weight(1f),
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    // The illustration: a small drawn phone with a single
                    // toggle row, coloured to the permission's own sticker so
                    // the five guides in this flow don't all look identical.
                    PermMockup(tone = tone)

                    Spacer(Modifier.height(18.dp))

                    steps.forEachIndexed { i, step ->
                        Row(
                            Modifier.padding(vertical = 5.dp),
                            verticalAlignment = Alignment.Top,
                        ) {
                            Box(
                                Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(tone.fill)
                                    .border(2.dp, Ink, CircleShape),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    (i + 1).toString(),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = tone.on,
                                )
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(
                                step,
                                style = MaterialTheme.typography.bodyLarge,
                                color = Ink,
                                modifier = Modifier.weight(1f).padding(top = 1.dp),
                            )
                        }
                    }

                    Spacer(Modifier.height(18.dp))

                    SquishButton(
                        label = "Got it",
                        sticker = tone,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onContinue,
                    )

                    Spacer(Modifier.height(10.dp))

                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clickableNoRipple(remember { MutableInteractionSource() }) { onDismiss() }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("Not now", style = MaterialTheme.typography.bodyMedium, color = InkMid)
                    }
                }
            }
        }
    }
}

/**
 * A drawn phone frame with one toggle row inside it, mid-flip. The finger
 * icon sitting on the toggle is the whole point — it is the thing a real
 * screenshot would need an overlaid circle-and-arrow to fake, and here it is
 * just part of the drawing.
 */
@Composable
private fun PermMockup(tone: Sticker) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(120.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(CreamCard)
            .border(Paper.Outline, Ink, RoundedCornerShape(18.dp)),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            Modifier
                .fillMaxWidth(0.8f)
                .clip(RoundedCornerShape(12.dp))
                .background(tone.fill.copy(alpha = 0.22f))
                .border(2.dp, tone.edge, RoundedCornerShape(12.dp))
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .weight(1f)
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Ink.copy(alpha = 0.12f)),
            )
            Spacer(Modifier.width(12.dp))
            // The toggle, drawn on rather than switched by anything — it is
            // always shown already flipped on, since this illustration's job
            // is "this is what on looks like", not to animate the flip.
            Box(
                Modifier
                    .size(width = 40.dp, height = 22.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(Mint.fill)
                    .border(2.dp, Ink, RoundedCornerShape(11.dp)),
                contentAlignment = Alignment.CenterEnd,
            ) {
                Box(
                    Modifier
                        .padding(2.dp)
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(CreamCard)
                        .border(1.5.dp, Ink, CircleShape),
                )
            }
        }
    }
}
