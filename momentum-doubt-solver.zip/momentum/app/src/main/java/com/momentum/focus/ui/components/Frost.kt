package com.momentum.focus.ui.components

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.LocalSkin
import com.momentum.focus.ui.theme.Paper

/**
 * Frost only as a veil behind a solid paper card.
 * Never used as the whole screen (Shield stays cream).
 */
@Composable
fun FrostScrim(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(modifier.fillMaxSize()) {
        Box(
            Modifier
                .matchParentSize()
                // Guarded, the same way Locked.kt already guards its frost.
                // Modifier.blur is API 31 and up; below that it is a silent
                // no-op, so every phone older than Android 12 — most of the
                // ones this ships to — got the gradient with none of the
                // softening and the scrim read as a flat grey sheet. The
                // deepened tint below stands in for it there.
                .then(
                    if (Build.VERSION.SDK_INT >= 31) Modifier.blur(22.dp) else Modifier,
                )
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0x66FFFFFF),
                            Color(0x44140E08),
                        )
                    )
                )
        )
        Box(
            Modifier
                .matchParentSize()
                .background(
                    // Heavier without the blur. The blur is half of what
                    // separates the sheet from what is behind it; with it gone
                    // the tint has to do the whole job on its own.
                    if (Build.VERSION.SDK_INT >= 31) Color(0x33000000)
                    else Color(0x59000000),
                )
        )
        content()
    }
}

@Composable
fun FrostSheet(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(Color(0xE6FBF3D5))
            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
    ) {
        content()
    }
}

@Composable
fun FrostPill(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    // A wash of the current skin under the white. Faint on purpose: the bar
    // sits under every screen, so it has to carry the theme without competing
    // with the tab that is selected. The tabs keep their own colours — those
    // identify the destination, which is not what a skin is for.
    val tint = LocalSkin.current.petal
    Box(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .background(tint.copy(alpha = 0.35f))
            // Glass, not a white rectangle.
            //
            // This was one flat Color(0xCCFFFFFF) over the tint, which is a
            // sheet of paint at 80% — it hides what is behind it and reflects
            // nothing. Real frosted glass is brightest along its top edge,
            // where light catches the bevel, and thins towards the bottom
            // where you are seeing more of what is underneath. Three stops and
            // a highlight hairline is the whole trick; there is no blur here
            // and there does not need to be, because what reads as glass is
            // the falloff and the lit edge, not the blur.
            //
            // No RenderEffect either. Real background blur is API 31+ and
            // costs a full-screen pass every frame, on a bar that is on screen
            // in every single state of the app.
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xF2FFFFFF),
                        Color(0xC4FFFFFF),
                        Color(0xDBFFFFFF),
                    ),
                ),
            )
            .border(2.dp, Ink.copy(alpha = 0.35f), RoundedCornerShape(22.dp))
            .drawWithContent {
                drawContent()
                // The lit bevel, inside the border and following its curve.
                val inset = 3.dp.toPx()
                val r = 22.dp.toPx() - inset
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colorStops = arrayOf(
                            0f to Color.White.copy(alpha = 0.95f),
                            0.35f to Color.White.copy(alpha = 0.10f),
                            1f to Color.Transparent,
                        ),
                        startY = 0f,
                        endY = size.height * 0.55f,
                    ),
                    topLeft = Offset(inset, inset),
                    size = Size(size.width - inset * 2, size.height - inset * 2),
                    cornerRadius = CornerRadius(r, r),
                    style = Stroke(width = 1.5.dp.toPx()),
                )
            },
        contentAlignment = Alignment.Center,
        content = content,
    )
}
