package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.mutableIntStateOf
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import com.momentum.focus.ai.DoubtState
import com.momentum.focus.ui.components.DoubtSheet
import com.momentum.focus.ui.components.FrostScrim
import com.momentum.focus.ui.components.FrostSheet
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.block.Admin
import com.momentum.focus.data.AppData
import com.momentum.focus.data.FocusLevels
import com.momentum.focus.data.bankBar
import com.momentum.focus.data.Currency
import com.momentum.focus.ui.TimerState
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.Locked
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.PactBanner
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import androidx.compose.ui.platform.LocalContext
import com.momentum.focus.data.AppCatalog
import com.momentum.focus.data.CataloguedApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay

/**
 * Extensions long enough to need confirming, longest last.
 *
 * Three, not seven: the row has to fit a narrow phone, and the gap between
 * half a day and a week is not one anybody fine-tunes.
 */
private val LONG_EXTENDS = listOf("+12h" to 12, "+1d" to 24, "+7d" to 168)

@Composable
fun FocusScreen(
    data: AppData,
    timer: TimerState,
    onToggle: () -> Unit,
    onAbandon: () -> Unit,
    onDuration: (Int) -> Unit,
    onSubject: (String) -> Unit,
    onFocusLevel: (Int) -> Unit = {},
    onCrown: (Boolean) -> Unit = {},
    premium: Boolean = false,
    onPlans: () -> Unit = {},
    onToggleStudy: (String) -> Unit = {},
    onExtendPact: (Int) -> Unit = {},
    onSubjects: (List<String>) -> Unit = {},
    /** Non-null when Begin will not do anything, and says why. */
    startBlocked: String? = null,
    /**
     * Null on any build without an API key, which removes the doubt solver
     * from the screen entirely rather than showing a button that explains it
     * cannot work.
     */
    doubt: DoubtState? = null,
    onAskDoubt: (String, String?) -> Unit = { _, _ -> },
    onRetryDoubt: () -> Unit = {},
    onStopDoubt: () -> Unit = {},
) {
    val haptics = rememberHaptics()
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var adminRefresh by remember { mutableIntStateOf(0) }
    var pendingCrown by rememberSaveable { mutableStateOf(false) }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) adminRefresh++
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    val adminOnNow = remember(adminRefresh) { Admin.isActive(context) }
    LaunchedEffect(adminOnNow, premium) {
        if (pendingCrown && adminOnNow && premium) {
            onCrown(true)
            pendingCrown = false
        }
        if (!adminOnNow && data.crownMode && !data.pactLive) onCrown(false)
    }
    val str = strings()
    var confirmStop by remember { mutableStateOf(false) }
    // Which long extension is waiting on a yes. Null when nothing is asked.
    var pactAsk by remember { mutableStateOf<Int?>(null) }
    // Crown waiting on a yes. Crown is the one level that arms a pact, and a
    // pact cannot be shortened, so it is the one level a stray tap can cost
    // you a day over.
    var crownAsk by remember { mutableStateOf(false) }
    var addSubject by remember { mutableStateOf(false) }
    var levelRefused by remember { mutableStateOf(false) }
    LaunchedEffect(levelRefused) {
        if (levelRefused) { kotlinx.coroutines.delay(2600); levelRefused = false }
    }
    var customOpen by rememberSaveable { mutableStateOf(false) }
    var customMins by rememberSaveable { mutableIntStateOf(40) }
    // Defaults to subject mode when a subject is already set, so returning to
    // the screen does not silently drop the label off the next session.
    var justFocus by rememberSaveable { mutableStateOf(false) }
    val split = remember(data.sessions, data.subjects) { data.subjectSplit() }
    val minsNow = (timer.totalSeconds / 60).coerceAtLeast(1)
    val earn = (minsNow / data.effectiveRatio.coerceAtLeast(1))
    val presets = listOf(25, 50, 90)
    val isCustom = timer.totalSeconds / 60 !in presets

    // A tick on every whole minute boundary. Frequent enough to feel present,
    // rare enough that it never becomes noise.
    LaunchedEffect(timer.remaining) {
        if (timer.running && timer.remaining > 0 && timer.remaining % 60 == 0) {
            haptics.tick()
        }
    }

    Box(Modifier.fillMaxSize()) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 28.dp, bottom = 88.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            str.focus.header.uppercase(),
            style = MaterialTheme.typography.displaySmall,
            color = Tang.accent,
        )
        Text(
            timer.subject,
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // The old L3 is gone from the picker. It armed the pact and Crown armed
            // the pact plus the uninstall lock, so the two read as the same
            // choice with one extra switch — and a level nobody can tell apart
            // from the next one is just a decision the user has to make twice.
            //
            // The stored value is left alone. Anyone already sitting on 3 keeps
            // working exactly as before and shows as Crown here, which is what
            // their level already does; migrating the number would risk more
            // than it fixes.
            // The lock count is the honest part of this row: one, two or
            // three, rising with how much the level takes away from you.
            // The label can be renamed without touching it.
            listOf(
                Triple(1, FocusLevels.NO_BLOCK, 1),
                Triple(2, FocusLevels.SHIELD, 2),
                Triple(4, FocusLevels.SHIELD_AND_UNINSTALL, 3),
            ).forEach { (lv, label, locks) ->
                // Dropping below the level you started on is refused while the
                // clock runs, so the chip has to look refused too. Tapping a
                // dead chip that stays silent is how a rule reads as a bug.
                val locked = timer.running && lv < data.focusLevel
                Chip(
                    text = label,
                    selected = if (lv == 4) data.focusLevel >= 3 else data.focusLevel == lv,
                    sticker = if (lv == 4) Tang else Cobalt,
                    locks = locks,
                    dimmed = locked,
                ) {
                    when {
                        locked -> { haptics.press(); levelRefused = true }
                        // Climbing to Crown only. Tapping Crown while already
                        // there is a no-op and should not interrogate anyone.
                        lv == 4 && !premium -> {
                            haptics.tick(); onPlans()
                        }
                        lv == 4 && !Admin.isActive(context) -> {
                            haptics.press()
                            pendingCrown = true
                            runCatching { context.startActivity(Admin.requestIntent(context)) }
                        }
                        lv == 4 && data.focusLevel < 3 -> {
                            haptics.press(); crownAsk = true; levelRefused = false
                        }
                        lv < 3 -> { haptics.tick(); onCrown(false); onFocusLevel(lv) }
                        else -> { haptics.tick(); onFocusLevel(lv) }
                    }
                }
            }
        }
        if (levelRefused) {
            Spacer(Modifier.height(6.dp))
            Text(
                str.focus.levelRefused,
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.accent,
            )
        }
        if (crownAsk) {
            Spacer(Modifier.height(6.dp))
            // Spelled out rather than named. "Crown" says nothing about what
            // it takes away, and this is the only tap in the app that arms a
            // lock the app itself then refuses to undo.
            Text(
                str.focus.crownWarning,
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.accent,
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(text = str.focus.crownConfirm, selected = true, sticker = Tang) {
                    haptics.press(); crownAsk = false; onCrown(true); onFocusLevel(4)
                }
                Chip(text = str.focus.crownDecline, selected = false, sticker = Cobalt) {
                    haptics.tick(); crownAsk = false
                }
            }
        }
        Text(
            // The rate here used to be written into the label by hand, so it
            // could disagree with the line right below it and with Profile.
            // One source now: effectiveRatio.
            when (data.focusLevel) {
                1 -> str.focus.lineNoBlock(FocusLevels.NO_BLOCK)
                2 -> str.focus.lineShield(FocusLevels.SHIELD)
                else -> str.focus.lineCrown(FocusLevels.SHIELD_AND_UNINSTALL)
            } + str.focus.ratePerRupee(data.effectiveRatio),
        )
        // pactLive is derived from the wall clock, so nothing in the store
        // changes when it runs out. Without this tick the countdown froze at
        // whatever it read on the last recomposition and the screen went on
        // claiming to be locked long after the pact had ended.
        var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
        LaunchedEffect(Unit) {
            while (true) {
                delay(1_000)
                nowMs = System.currentTimeMillis()
            }
        }
        val pactLive = data.lockUntilEpochMs > nowMs

        if (pactLive) {
            // The same banner Home and Profile show, instead of a second
            // hand-rolled version of it here. Extending now lives inside that
            // card: loose under the level chips and built from the same Chip,
            // "+6h lock" read as a fourth level rather than as something that
            // acts on the pact.
            PactBanner(data.lockUntilEpochMs, Modifier.fillMaxWidth()) {
                Spacer(Modifier.height(10.dp))
                // Short extensions stay one tap. An hour is a small enough
                // mistake to live with.
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 3, 6).forEach { hrs ->
                        Chip(text = "+${hrs}h", selected = false, sticker = Tang) {
                            haptics.tick(); onExtendPact(hrs)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                val asked = pactAsk
                if (asked == null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LONG_EXTENDS.forEach { (label, hrs) ->
                            Chip(text = label, selected = false, sticker = Tang) {
                                haptics.tick(); pactAsk = hrs
                            }
                        }
                    }
                } else {
                    // Nothing shortens a pact, so a week has to be asked for
                    // twice. The old comment on extendPact records what one
                    // stray tap already cost when it was only six hours.
                    Text(
                        str.focus.pactConfirm(
                            LONG_EXTENDS.first { it.second == asked }.first
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Tang.on,
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip(text = str.common.yes, selected = true, sticker = Cobalt) {
                            haptics.press(); onExtendPact(asked); pactAsk = null
                        }
                        Chip(text = str.common.no, selected = false, sticker = Tang) {
                            haptics.tick(); pactAsk = null
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(28.dp))

        TimerRing(progress = timer.progress, label = timer.label, running = timer.running)

        Spacer(Modifier.height(28.dp))

        if (!timer.running) {
            Text(
                str.focus.willEarn(minsNow, Currency.format(earn)),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            // The bar was enforced and never shown. Someone would sit for ten
            // minutes of a fifty minute session, watch the timer count, and get
            // nothing — with no way to know a threshold existed at all.
            Text(
                str.focus.minimumToEarn(bankBar(minsNow)),
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.accent,
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { mins ->
                    Chip(
                        text = "${mins}m",
                        selected = !isCustom && timer.totalSeconds == mins * 60,
                        sticker = Cobalt,
                    ) {
                        haptics.tick()
                        customOpen = false
                        onDuration(mins)
                    }
                }
                Chip(
                    text = if (isCustom) "${minsNow}m" else str.focus.setCustom,
                    selected = isCustom || customOpen,
                    sticker = Lilac,
                ) {
                    haptics.tick()
                    customOpen = !customOpen
                }
            }
            if (customOpen) {
                Spacer(Modifier.height(8.dp))
                Text(
                    str.focus.customMinutes(customMins),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Slider(
                    value = customMins.toFloat(),
                    onValueChange = {
                        val next = it.toInt().coerceIn(15, 180)
                        if (next != customMins) haptics.tick()
                        customMins = next
                    },
                    onValueChangeFinished = { haptics.confirm() },
                    valueRange = 15f..180f,
                    steps = 32,
                    colors = SliderDefaults.colors(
                        thumbColor = Lilac.fill,
                        activeTrackColor = Lilac.fill,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
                SquishButton(
                    label = str.focus.useCustom(customMins),
                    sticker = Lilac,
                    modifier = Modifier.fillMaxWidth(0.6f),
                ) {
                    haptics.confirm()
                    onDuration(customMins)
                    customOpen = false
                }
            }
            Spacer(Modifier.height(16.dp))

            // Two ways in, asked before anything else, because they want
            // different things from this screen. Someone revising Physics
            // wants the subject on the record so the breakdown means
            // something. Someone who just needs the phone to leave them alone
            // for an hour was previously forced to label it Physics anyway,
            // which quietly poisoned the by-subject stats with sessions that
            // had nothing to do with Physics.
            Text(
                str.focus.howLabel,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(
                    text = str.focus.withSubject,
                    selected = !justFocus,
                    sticker = Marigold,
                ) { haptics.tick(); justFocus = false }
                Chip(
                    text = str.focus.justFocus,
                    selected = justFocus,
                    sticker = Cobalt,
                ) {
                    haptics.tick()
                    justFocus = true
                    // Nothing gets filed under a subject the user did not pick.
                    onSubject("")
                }
            }

            Spacer(Modifier.height(12.dp))
            if (justFocus) {
                Text(
                    str.focus.justFocusNote,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
            } else if (data.examName.isNotBlank()) {
                Text(
                    data.daysToExam?.let { str.focus.examDaysLeft(data.examName, it) }
                        ?: data.examName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
                Spacer(Modifier.height(8.dp))
            }
            if (!justFocus) {
                if (data.subjects.isEmpty()) {
                    // Nothing named yet. Saying so beats showing three chips
                    // the user never chose.
                    Text(
                        str.focus.noSubjectsYet,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    // Scrollable, because three subjects plus "+ Naya" is
                    // wider than a narrow phone. The add chip was being cut in
                    // half at the right edge and read as an empty pill.
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        data.subjects.take(3).forEach { subject ->
                            Chip(
                                text = subject,
                                selected = timer.subject == subject,
                                sticker = Marigold,
                            ) { haptics.tick(); onSubject(subject) }
                        }
                        // Adding a subject used to mean leaving the screen,
                        // finding Profile, opening a collapsed section and
                        // typing into one of three boxes — for something people
                        // realise they need at the moment they sit down.
                        Chip(text = str.focus.addSubject, selected = false, sticker = Cobalt) {
                            haptics.tick(); addSubject = true
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            Text(
                str.focus.studyAppLabel,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            // These used to be the first six entries of a hardcoded list, shown
            // whether or not the phone had them. Tapping one added a package
            // that was not installed, so the timer waited for an app that could
            // never come to the foreground and no rupees were ever paid.
            val context = LocalContext.current
            val studyFound by produceState(initialValue = emptyList<CataloguedApp>()) {
                value = withContext(Dispatchers.IO) {
                    runCatching { AppCatalog.installedStudyApps(context) }.getOrDefault(emptyList())
                }
            }
            if (studyFound.isEmpty()) {
                Text(
                    str.focus.noStudyApp,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                // Chunked rows rather than FlowRow: that one is still behind
                // ExperimentalLayoutApi, so using it is a compile error without
                // an opt-in, and the opt-in is not worth taking on for a list
                // that is almost always two or three chips long.
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    studyFound.chunked(2).forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            row.forEach { app ->
                                Box(Modifier.weight(1f)) {
                                    Chip(
                                        text = app.label,
                                        selected = app.pkg in data.studyPackages,
                                        sticker = Mint,
                                    ) { haptics.tick(); onToggleStudy(app.pkg) }
                                }
                            }
                            // Keeps a lone chip on the last row at half width
                            // instead of stretching it across the screen.
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
            if (data.studyPackages.isEmpty()) {
                Text(
                    str.focus.noStudyAppWarning,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }
            val subMins = split.firstOrNull { it.first == timer.subject }?.second ?: 0
            val untouched = split.filter { it.second == 0 }.map { it.first }
            // With no subject chosen there is nothing to report on, and
            // "untouched in 30 days" about a blank name is just a reproach for
            // not doing something nobody asked for.
            if (!justFocus && timer.subject.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(
                if (subMins == 0) str.focus.subjectUntouched(timer.subject)
                else str.focus.subjectMinutes(timer.subject, subMins),
                style = MaterialTheme.typography.bodyMedium,
                color = if (subMins == 0) Tang.accent else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (untouched.isNotEmpty() && timer.subject !in untouched) {
                Text(
                    str.focus.stillZero(untouched.take(3).joinToString()),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            }
                    }

        Spacer(Modifier.height(24.dp))

        SquishButton(
            label = if (timer.running) str.focus.pause else str.focus.begin,
            sticker = if (timer.running) Marigold else Jade,
            modifier = Modifier.fillMaxWidth(0.7f),
            onClick = onToggle,
        )

        // Begin used to be a live-looking button that quietly did nothing when
        // the session could not start. Saying why, right under it, is the whole
        // fix — the condition was always knowable, it was just never shown.
        if (!timer.running && startBlocked != null) {
            Spacer(Modifier.height(8.dp))
            Text(
                startBlocked,
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.accent,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(0.85f),
            )
        }

        if (timer.running) {
            val doneMin = (timer.totalSeconds - timer.remaining) / 60
            val bar = bankBar(timer.totalSeconds / 60)
            Spacer(Modifier.height(10.dp))
            Text(
                if (doneMin >= bar) str.focus.earnSecured
                else str.focus.minutesUntilSecured(bar - doneMin),
                style = MaterialTheme.typography.bodyMedium,
                color = if (doneMin >= bar) Jade.accent else Tang.accent,
                textAlign = TextAlign.Center,
            )
        }


        if (timer.remaining < timer.totalSeconds) {
            Spacer(Modifier.height(10.dp))
            Text(
                str.focus.giveUp,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.reject(); confirmStop = true
                    }
                    .padding(10.dp),
            )
        }
    }

    if (addSubject) {
        NewSubjectDialog(
            existing = data.subjects,
            onSave = { name ->
                // Three is the cap the store already enforces. Dropping the
                // oldest keeps the newest choice working instead of silently
                // ignoring it once the list is full.
                val next = (data.subjects + name).takeLast(3)
                onSubjects(next)
                onSubject(name)
                addSubject = false
            },
            onClose = { addSubject = false },
        )
    }


    if (confirmStop) {
        FrostScrim {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = Paper.ScreenPad),
                contentAlignment = Alignment.Center,
            ) {
                FrostSheet {
                    Column(
                        Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            str.focus.stopTitle,
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            str.focus.stopBody,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(16.dp))
                        SquishButton(
                            label = str.focus.stopConfirm,
                            sticker = Tang,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            confirmStop = false
                            onAbandon()
                        }
                        Spacer(Modifier.height(10.dp))
                        SquishButton(
                            label = str.focus.keepGoing,
                            sticker = Mint,
                            modifier = Modifier.fillMaxWidth(),
                        ) { confirmStop = false }
                    }
                }
            }
        }
    }
}
}

@Composable
private fun TimerRing(progress: Float, label: String, running: Boolean) {
    val str = strings()
    val animated by animateFloatAsState(progress, Motion.settle(), label = "p")
    val track = MaterialTheme.colorScheme.surfaceVariant
    // The filled arc is the single element most looked at in the app, so it is
    // where a skin earns its keep. The track, the outline and the cream behind
    // it are untouched — a theme changes the accent, not the paper.
    val arcColor = LocalSkin.current.accent

    Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 22.dp.toPx()
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(stroke / 2, stroke / 2)
            drawArc(track, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(Ink, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke + 6f, cap = StrokeCap.Round))
            drawArc(track, -90f, 360f, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(Ink, -90f, 360f * animated, false, topLeft, arcSize,
                style = Stroke(stroke + 6f, cap = StrokeCap.Round))
            drawArc(arcColor, -90f, 360f * animated, false, topLeft, arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                label,
                style = MaterialTheme.typography.displayMedium,
                color = Ink,
            )
            Text(
                if (running) str.focus.inSession else str.focus.ready,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun Chip(
    text: String,
    selected: Boolean,
    sticker: Sticker,
    /** Small locks under the label — one per step of strictness. 0 hides them. */
    locks: Int = 0,
    /** Still tappable, so the tap can explain itself instead of doing nothing. */
    dimmed: Boolean = false,
    onClick: () -> Unit,
) {
    val bg = if (selected) sticker.fill else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (selected) sticker.on else MaterialTheme.colorScheme.onSurfaceVariant
    Column(
        Modifier
            .alpha(if (dimmed) 0.42f else 1f)
            .clip(RoundedCornerShape(Paper.ChipRadius))
            .background(bg)
            .border(2.dp, Ink, RoundedCornerShape(Paper.ChipRadius))
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(text, style = MaterialTheme.typography.titleMedium, color = fg)
        if (locks > 0) {
            Spacer(Modifier.height(3.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                repeat(locks) {
                    Icon(
                        Icons.Filled.Lock,
                        // Decorative: the label names the level and the line
                        // under the row already says what it does, so a
                        // screen reader announcing "lock" three times would
                        // only add noise.
                        contentDescription = null,
                        tint = fg,
                        modifier = Modifier.size(10.dp),
                    )
                }
            }
        }
    }
}


/** Names a subject without leaving the screen someone is about to start on. */
@Composable
private fun NewSubjectDialog(
    existing: List<String>,
    onSave: (String) -> Unit,
    onClose: () -> Unit,
) {
    var text by remember { mutableStateOf("") }
    val clean = text.trim()
    val dupe = existing.any { it.equals(clean, ignoreCase = true) }

    val str = strings()
    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(18.dp),
        ) {
            Text(
                str.focus.newSubjectTitle,
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(18) },
                placeholder = { Text(str.focus.newSubjectHint) },
                singleLine = true,
                isError = dupe,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )
            if (existing.size >= 3) {
                Spacer(Modifier.height(8.dp))
                Text(
                    str.focus.threeMax(existing.first()),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }
            if (dupe) {
                Spacer(Modifier.height(8.dp))
                Text(
                    str.focus.duplicateName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClose)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        str.common.cancel,
                        style = MaterialTheme.typography.titleMedium,
                        color = Ink,
                    )
                }
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Jade.fill)
                        .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(
                            remember { MutableInteractionSource() },
                            enabled = clean.isNotBlank() && !dupe,
                        ) { onSave(clean) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        str.common.save,
                        style = MaterialTheme.typography.titleMedium,
                        color = Jade.on,
                    )
                }
            }
        }
    }
}
