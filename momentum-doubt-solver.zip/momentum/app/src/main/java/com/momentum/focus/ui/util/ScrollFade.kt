package com.momentum.focus.ui.util

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Lightweight iOS-style edge fade for scrollable content.
 *
 * The fade is a mask, not a translucent rectangle painted over the content,
 * so text/cards don't get washed out. It is active only on an edge that can
 * actually scroll. Offscreen compositing is used once for the mask; there is
 * no blur, shadow, or per-frame animation involved.
 */
fun Modifier.scrollEdgeFade(
    canScrollTop: Boolean,
    canScrollBottom: Boolean,
    edge: Dp = 18.dp,
): Modifier = graphicsLayer {
    compositingStrategy = CompositingStrategy.Offscreen
}.drawWithCache {
    val edgePx = edge.toPx().coerceAtMost(size.height / 3f)
    val topBrush = if (canScrollTop && edgePx > 0f) {
        Brush.verticalGradient(
            colors = listOf(Color.Transparent, Color.White),
            startY = 0f,
            endY = edgePx,
        )
    } else null
    val bottomBrush = if (canScrollBottom && edgePx > 0f) {
        Brush.verticalGradient(
            colors = listOf(Color.White, Color.Transparent),
            startY = (size.height - edgePx).coerceAtLeast(0f),
            endY = size.height,
        )
    } else null

    onDrawWithContent {
        drawContent()
        topBrush?.let { drawRect(it, blendMode = BlendMode.DstIn) }
        bottomBrush?.let { drawRect(it, blendMode = BlendMode.DstIn) }
    }
}

fun Modifier.verticalScrollWithFade(
    state: ScrollState,
    edge: Dp = 18.dp,
): Modifier = verticalScroll(state).scrollEdgeFade(
    canScrollTop = state.canScrollBackward,
    canScrollBottom = state.canScrollForward,
    edge = edge,
)

fun Modifier.horizontalScrollWithFade(
    state: ScrollState,
    edge: Dp = 18.dp,
): Modifier = horizontalScroll(state).then(
    graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithCache {
            val edgePx = edge.toPx().coerceAtMost(size.width / 3f)
            val startBrush = if (state.canScrollBackward && edgePx > 0f) {
                Brush.horizontalGradient(listOf(Color.Transparent, Color.White), 0f, edgePx)
            } else null
            val endBrush = if (state.canScrollForward && edgePx > 0f) {
                Brush.horizontalGradient(listOf(Color.White, Color.Transparent), size.width - edgePx, size.width)
            } else null
            onDrawWithContent {
                drawContent()
                startBrush?.let { drawRect(it, blendMode = BlendMode.DstIn) }
                endBrush?.let { drawRect(it, blendMode = BlendMode.DstIn) }
            }
        }
)
}

fun Modifier.lazyListEdgeFade(
    state: LazyListState,
    edge: Dp = 18.dp,
): Modifier = scrollEdgeFade(
    canScrollTop = state.canScrollBackward,
    canScrollBottom = state.canScrollForward,
    edge = edge,
)
