package com.momentum.focus.ui.i18n

interface CoachStrings {
    val label: String
    val title: String
    val intro: String
    val readMyWeek: String
    val thinking: String
    val refresh: String
    fun notEnoughYet(sessions: Int): String
    val whatIFound: String
    val whatToDo: String
    val disclaimer: String
    fun lastRead(days: Int): String
    val lastReadToday: String
    val tryAgain: String
}

object CoachHi : CoachStrings {
    override val label = "COACH"
    override val title = "Padhai ka hisaab"
    override val intro =
        "Tumhare hi numbers padh ke — kaunsa subject chhoot raha hai, urges kis " +
            "waqt aate hain, kitne session beech mein chhode."
    override val readMyWeek = "Mera hafta padho"
    override val thinking = "Padh raha hoon"
    override val refresh = "Dobara padho"
    override fun notEnoughYet(sessions: Int) =
        "Abhi $sessions session aur chahiye. Usse pehle jo bhi kahunga wo andaza hoga."
    override val whatIFound = "JO DIKHA"
    override val whatToDo = "AB KYA KARO"
    override val disclaimer = "AI ne likha hai. Apne hisaab se dekh lena."
    override fun lastRead(days: Int) = "$days din pehle padha tha"
    override val lastReadToday = "Aaj hi padha hai"
    override val tryAgain = "Phir se koshish karo"
}

object CoachEn : CoachStrings {
    override val label = "YOUR WEEK"
    override val title = "A read of your week"
    override val intro =
        "From your own numbers — which subject is slipping, when the urges land, " +
            "how many sessions you walked out of."
    override val readMyWeek = "Read my week"
    override val thinking = "Reading"
    override val refresh = "Read it again"
    override fun notEnoughYet(sessions: Int) =
        if (sessions == 1) "One more session first. Before that, anything I said would be a guess."
        else "$sessions more sessions first. Before that, anything I said would be a guess."
    override val whatIFound = "WHAT I FOUND"
    override val whatToDo = "WHAT TO DO"
    override val disclaimer = "Written by AI. Check it against what you know."
    override fun lastRead(days: Int) =
        if (days == 1) "Read yesterday" else "Read $days days ago"
    override val lastReadToday = "Read today"
    override val tryAgain = "Try again"
}
