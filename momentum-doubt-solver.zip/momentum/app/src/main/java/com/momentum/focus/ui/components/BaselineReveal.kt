package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Tang
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * What they guessed, against what the phone says.
 *
 * The setup quiz has always asked for this guess and always stored it, and
 * until now nothing in the app ever read it back — the two numbers went into
 * the store and stayed there. That made the quiz two questions with no answer,
 * which is worse than not asking: it takes something from the person and gives
 * nothing back.
 *
 * The gap is the whole point. Nobody changes a habit because a number is high;
 * people change when the number is higher than the one in their head. So the
 * guess is shown first, at the same size, and the real figure lands beside it.
 *
 * Shown only while the gap is worth showing. Once someone's guess is close,
 * they already know, and the card becomes a thing they scroll past.
 */
@Composable
fun BaselineReveal(data: AppData, modifier: Modifier = Modifier) {
    val guessMin = data.guessHours * 60
    if (guessMin <= 0 || data.baselineMinutes <= 0) return
    val real = data.baselineMinutes
    val gap = real - guessMin
    // Under half an hour out is a good guess, and telling someone they were
    // right is not news.
    if (abs(gap) < 30) return

    val str = strings()
    val shape = RoundedCornerShape(Paper.CardRadius)

    // The real figure counts up from the guess rather than appearing. Watching
    // it climb past your own number is the moment; printing both at once is a
    // table.
    val climb = remember { Animatable(guessMin.toFloat()) }
    LaunchedEffect(real) {
        climb.animateTo(real.toFloat(), tween(1400))
    }
    val shown = climb.value.roundToInt()

    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(CreamCard)
            .border(Paper.Outline, Ink, shape)
            .padding(16.dp),
    ) {
        Text(str.home.baselineLabel, style = MaterialTheme.typography.labelSmall, color = InkMid)
        Spacer(Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text(
                    str.home.baselineGuess,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                )
                Text(
                    hm(guessMin),
                    style = MaterialTheme.typography.headlineSmall,
                    color = InkMid,
                )
            }
            Column(Modifier.weight(1f)) {
                Text(
                    str.home.baselineReal,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (gap > 0) Tang.accent else Mint.accent,
                )
                Text(
                    hm(shown),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Ink,
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        // One bar, split. The guess is the pale part and the truth is the
        // whole of it, so the overshoot is a length rather than a subtraction
        // someone has to do in their head.
        Box(
            Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(if (gap > 0) Tang.fill else Mint.fill)
                .border(2.dp, Ink, RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.CenterStart,
        ) {
            val share = (guessMin.toFloat() / maxOf(real, guessMin)).coerceIn(0f, 1f)
            Box(
                Modifier
                    .fillMaxWidth(share)
                    .height(12.dp)
                    .background(Color.White.copy(alpha = 0.55f)),
            )
        }

        Spacer(Modifier.height(10.dp))
        Text(
            if (gap > 0) str.home.baselineOver(hm(gap)) else str.home.baselineUnder(hm(-gap)),
            style = MaterialTheme.typography.bodyMedium,
            color = Ink,
        )
    }
}

/** Minutes as "10h 03m". Kept local — this is the only place that needs it. */
private fun hm(minutes: Int): String {
    val m = abs(minutes)
    return "${m / 60}h ${(m % 60).toString().padStart(2, '0')}m"
}
