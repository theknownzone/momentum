package com.momentum.focus.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.data.ExamNewsItem
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

/**
 * Exam notifications, on the home page and in front of you once.
 *
 * Two surfaces, one source. [ExamNewsPopup] interrupts exactly once per
 * announcement and never again — an alert that reappears every launch is an
 * alert people learn to dismiss without reading. [ExamNewsCard] is the quiet
 * version that stays on Home so a dismissed item is still findable.
 *
 * Relevance is decided before either one is shown: an item is either marked
 * All India or it has to match the exam or the state on the profile. Someone
 * preparing for NEET should never be interrupted by an RPSC date.
 */
@Composable
fun ExamNewsPopup(item: ExamNewsItem, onClose: () -> Unit) {
    val context = LocalContext.current
    val haptics = rememberHaptics()

    LaunchedEffect(item.id) { haptics.tap() }

    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius)),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Tang.fill)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "EXAM ALERT",
                    style = MaterialTheme.typography.labelSmall,
                    color = Tang.on,
                )
                Text(
                    item.region.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = Tang.on,
                )
            }
            Box(Modifier.fillMaxWidth().height(Paper.Outline).background(Ink))

            Column(Modifier.padding(18.dp)) {
                // Two lines, then an ellipsis. Board notices run to twenty
                // words and the full text is on the other side of the tap
                // anyway — a card that gives four lines to one notice pushes
                // the next three off the screen, which is the opposite of what
                // a list of notices is for.
                Text(
                    item.title,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(6.dp))
                Text(item.body, style = MaterialTheme.typography.bodyLarge, color = InkMid)
                Spacer(Modifier.height(10.dp))
                Text(
                    // The date is only shown for an actual announcement. Every
                    // standing portal link carries the day it was added to the
                    // file, and printing that made "CBSE · 2026-09-04" look
                    // like a circular had landed this morning when nothing had
                    // happened at all.
                    if (item.alert) "${item.exam} · ${item.date}" else item.exam,
                    style = MaterialTheme.typography.labelSmall,
                    color = InkLow,
                )

                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tap(); onClose()
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("Got it", style = MaterialTheme.typography.titleMedium, color = Ink)
                    }
                    if (item.url.isNotBlank()) {
                        Box(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Mint.fill)
                                .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    haptics.confirm()
                                    runCatching {
                                        context.startActivity(
                                            Intent(Intent.ACTION_VIEW, Uri.parse(item.url))
                                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                                        )
                                    }
                                    onClose()
                                }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                "Open notice",
                                style = MaterialTheme.typography.titleMedium,
                                color = Mint.on,
                            )
                        }
                    }
                }
            }
        }
    }
}

/** The persistent version on Home: the newest few relevant announcements. */
@Composable
fun ExamNewsCard(
    items: List<ExamNewsItem>,
    modifier: Modifier = Modifier,
) {
    if (items.isEmpty()) return
    val context = LocalContext.current
    val haptics = rememberHaptics()
    var expanded by remember { mutableStateOf(false) }
    val shown = if (expanded) items.take(6) else items.take(2)

    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CreamCard)
            .border(Paper.Outline, Ink, RoundedCornerShape(16.dp))
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("EXAM NOTICES", style = MaterialTheme.typography.labelSmall, color = InkMid)
            Text(
                if (expanded) "Less" else "All",
                style = MaterialTheme.typography.labelSmall,
                color = Mint.accent,
                modifier = Modifier
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.tap(); expanded = !expanded
                    }
                    .padding(4.dp),
            )
        }
        shown.forEachIndexed { i, item ->
            if (i > 0) {
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(InkLow.copy(alpha = 0.4f)))
                Spacer(Modifier.height(10.dp))
            } else {
                Spacer(Modifier.height(8.dp))
            }
            Column(
                Modifier
                    .fillMaxWidth()
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        if (item.url.isBlank()) return@clickableNoRipple
                        haptics.tap()
                        runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(item.url))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        }
                    },
            ) {
                Text(
                    item.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = Ink,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    if (item.alert) "${item.exam} · ${item.region} · ${item.date}"
                    else "${item.exam} · ${item.region}",
                    style = MaterialTheme.typography.labelSmall,
                    color = InkLow,
                )
            }
        }
    }
}
