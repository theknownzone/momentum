package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberInfiniteTransition
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * The Siri activation glow — copied beat for beat, not adapted.
 *
 * Three things happen at once in the reference, and any one of them alone
 * reads as a generic effect rather than as "Siri":
 * - The light sits at the screen's *edges*, leaving the middle clear.
 * - It arrives with one fast outward sweep, as if the colour were flicked
 *   onto the glass — not a fade-in.
 * - Once arrived, it breathes on a slow cycle rather than holding steady.
 *
 * [trigger] is the replay key. Change its value (a mode enum, an incrementing
 * counter — anything with `equals`) and the whole sequence — snap to zero,
 * sweep in, breathe, fade — plays again from the start. A plain boolean
 * cannot express "play again", only "on or off": if the halo were already
 * showing when a second event asked for it, a boolean would see no change and
 * nothing would replay.
 *
 * Two colour modes:
 * - [rainbow] true: Apple's own blue -> pink -> purple -> orange, for moments
 *   that are meant to read as "this is that effect".
 * - [rainbow] false with a [tint]: the same three motions in one colour, for
 *   moments that should say *which* thing is active rather than "look, Siri".
 */
@Composable
fun Modifier.siriEdgeHalo(
    trigger: Any?,
    rainbow: Boolean = true,
    tint: Color = Color(0xFF7FD4FF),
    /** How far the colour reaches in from the true edge. */
    reach: Dp = 46.dp,
    /** How long the halo holds at full breathing brightness before it fades. */
    holdMs: Long = 1800L,
): Modifier {
    if (trigger == null) return this

    // The arrival-hold-fade envelope. One Animatable rather than three
    // separate booleans, because the three stages are one continuous value --
    // 0 at rest, 1 while showing, back to 0 to leave -- and driving that with
    // a single number is what makes the fade-out a mirror of the sweep-in
    // instead of a separate effect bolted on.
    val level = remember { Animatable(0f) }
    LaunchedEffect(trigger) {
        level.snapTo(0f)
        // The sweep. Fast and eased out, which is what a flick looks like --
        // a linear ramp arrives at a constant speed and reads as mechanical.
        level.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
        delay(holdMs)
        level.animateTo(0f, tween(520, easing = FastOutSlowInEasing))
    }

    // The breathing pulse, continuous for as long as this modifier exists.
    // Cheap to leave running even while level is 0 -- it is one float, and
    // the draw pass below is skipped entirely when level*breathe rounds to
    // nothing worth painting.
    val transition = rememberInfiniteTransition(label = "siriHaloBreathe")
    val breathe by transition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(2600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "breathe",
    )

    return this.drawWithContent {
        drawContent()
        val alpha = level.value * breathe
        if (alpha < 0.01f) return@drawWithContent

        val w = reach.toPx()
        val colours = if (rainbow) {
            // Apple's own order: blue leads, pink and purple carry the
            // middle, orange trails, and it closes back on blue so the sweep
            // gradient has no seam.
            listOf(
                Color(0xFF5AC8FA), Color(0xFFFF6FB5), Color(0xFFB57BFF),
                Color(0xFFFF9F5A), Color(0xFF5AC8FA),
            )
        } else {
            listOf(tint.copy(alpha = 0.9f), tint.copy(alpha = 0.45f), tint.copy(alpha = 0.9f))
        }
        val brush = Brush.sweepGradient(colours)
        val corner = CornerRadius(28.dp.toPx(), 28.dp.toPx())

        // Ordinary compositing, not BlendMode.Plus.
        //
        // The reference sits on black, where an additive blend is what makes
        // the glow look like it is emitting light rather than sitting on top
        // of the screen. This app's background is light cream paper, not
        // black — adding saturated colour to something already near-white
        // pushes it further towards white and the whole halo would wash out
        // to almost nothing, however high alpha went. Plain alpha blending is
        // what actually shows the colour as colour on a light surface.
        drawRoundRect(
            brush = brush,
            topLeft = Offset(w / 2, w / 2),
            size = Size(size.width - w, size.height - w),
            cornerRadius = corner,
            style = Stroke(width = w),
            alpha = alpha,
        )
        // A tighter, dimmer inner pass -- the soft core that keeps the edge
        // from reading as one flat coloured ring.
        drawRoundRect(
            brush = brush,
            topLeft = Offset(w * 0.8f, w * 0.8f),
            size = Size(size.width - w * 1.6f, size.height - w * 1.6f),
            cornerRadius = CornerRadius(22.dp.toPx(), 22.dp.toPx()),
            style = Stroke(width = w * 0.4f),
            alpha = alpha * 0.6f,
        )
    }
}
