package com.momentum.focus.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.R
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.LiquidGlass
import com.momentum.focus.ui.components.LiquidGlassButton
import com.momentum.focus.ui.i18n.Strings
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

private data class Page(
    val kicker: String,
    val title: String,
    val body: String,
    val sticker: Sticker,
    val art: Int,
)

/**
 * Built per call rather than held in a top-level val, because the copy now
 * comes from the string table and a static list is fixed at class-init — long
 * before anyone has chosen a language.
 */
private fun pages(str: Strings): List<Page> = listOf(
    Page(
        str.welcome.howItWorksLabel,
        str.welcome.howItWorksTitle,
        str.welcome.howItWorksBody,
        Emerald,
        R.drawable.welcome_earn,
    ),
    Page(
        str.welcome.catchLabel,
        str.welcome.catchTitle,
        str.welcome.catchBody,
        Gold,
        R.drawable.welcome_block,
    ),
    Page(
        str.welcome.dataLabel,
        str.welcome.dataTitle,
        str.welcome.dataBody,
        Ice,
        R.drawable.welcome_data,
    ),
    Page(
        str.welcome.hardLabel,
        str.welcome.hardTitle,
        str.welcome.hardBody,
        Ember,
        R.drawable.welcome_crown,
    ),
    Page(
        str.welcome.setupLabel,
        str.welcome.setupTitle,
        str.welcome.setupBody,
        Ice,
        R.drawable.perm_overlay,
    ),
)

@Composable
fun WelcomeScreen(
    onDone: (String) -> Unit,
) {
    val haptics = rememberHaptics()
    var index by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }

    val str = strings()
    val pages = pages(str)
    val onNamePage = index == pages.size

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 32.dp, bottom = 24.dp),
    ) {
        // Progress dots. Four steps is short enough that people finish it.
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(pages.size + 1) { i ->
                Box(
                    Modifier
                        .height(4.dp)
                        .weight(1f)
                        .clip(RoundedCornerShape(50))
                        .background(
                            if (i <= index) Mint.fill
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                )
            }
        }

        Spacer(Modifier.weight(1f))

        if (onNamePage) {
            Text(
                str.welcome.lastThing,
                style = MaterialTheme.typography.labelSmall,
                color = Lilac.on,
            )
            Text(
                str.welcome.nameQuestion,
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(18) },
                placeholder = { Text(str.welcome.namePlaceholder) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            )

            // Typing into an empty box gives no sense of what the name is for.
            // Showing the greeting as it is typed makes the field feel like it
            // is wiring something up rather than collecting a field.
            Spacer(Modifier.height(16.dp))
            LiquidGlass(
                modifier = Modifier.fillMaxWidth(),
                tint = Lilac.fill,
                radius = Paper.CardRadius,
            ) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(
                        str.welcome.youllSee,
                        style = MaterialTheme.typography.labelSmall,
                        color = InkMid,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (name.isBlank()) str.welcome.welcomeBackAnon
                        else str.welcome.welcomeBack(name.trim()),
                        style = MaterialTheme.typography.headlineSmall,
                        color = Ink,
                    )
                }
            }
        } else {
            val page = pages[index]
            Image(
                painter = painterResource(page.art),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(22.dp)),
            )
            Spacer(Modifier.height(16.dp))
            LiquidGlass(
                modifier = Modifier.size(64.dp),
                tint = page.sticker.fill,
                radius = 20.dp,
            ) {
                Text(
                    "${index + 1}",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                )
            }
            Spacer(Modifier.height(22.dp))
            LiquidGlass(
                modifier = Modifier.fillMaxWidth(),
                tint = page.sticker.fill,
                radius = Paper.CardRadius,
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text(
                        page.kicker,
                        style = MaterialTheme.typography.labelSmall,
                        color = InkMid,
                    )
                    Text(
                        page.title,
                        style = MaterialTheme.typography.displayMedium,
                        color = Ink,
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        page.body,
                        style = MaterialTheme.typography.bodyLarge,
                        color = InkMid,
                    )
                }
            }
        }

        Spacer(Modifier.weight(1f))

        LiquidGlassButton(
            tint = if (onNamePage) Emerald.fill else Ice.fill,
            onClick = {
                haptics.confirm()
                if (onNamePage) onDone(name.trim()) else index++
            },
        ) {
            Text(
                if (onNamePage) str.welcome.start else str.welcome.next,
                style = MaterialTheme.typography.titleMedium,
                color = Ink,
            )
        }

        if (!onNamePage) {
            Spacer(Modifier.height(10.dp))
            Text(
                str.welcome.skip,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .padding(10.dp),
            )
        }
    }
}
