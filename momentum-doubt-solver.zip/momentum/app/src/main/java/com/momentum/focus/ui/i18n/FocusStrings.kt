package com.momentum.focus.ui.i18n

/**
 * The level names themselves are not here. Light, Lock and Crown live in
 * [com.momentum.focus.data.FocusLevels] because they read identically in both
 * languages — that was part of why those names were chosen over L1 and L2.
 */
interface FocusStrings {
    val header: String
    val ready: String
    val inSession: String

    // level row
    val levelRefused: String
    val crownWarning: String
    val crownConfirm: String

    /** Shown when the confirm button is tapped before the terms are ticked. */
    val crownTickFirst: String
    val crownDecline: String
    fun lineNoBlock(name: String): String
    fun lineShield(name: String): String
    fun lineCrown(name: String): String
    fun ratePerRupee(minutes: Int): String

    // pact
    fun pactConfirm(amount: String): String

    // duration
    fun willEarn(minutes: Int, amount: String): String
    fun minimumToEarn(minutes: Int): String
    val setCustom: String
    fun customMinutes(minutes: Int): String
    fun useCustom(minutes: Int): String

    // how to study
    val howLabel: String
    val withSubject: String
    val justFocus: String
    val justFocusNote: String
    fun examDaysLeft(exam: String, days: Int): String
    val noSubjectsYet: String
    val addSubject: String

    // study app
    val studyAppLabel: String
    val noStudyApp: String
    val noStudyAppWarning: String

    // subject history
    fun subjectUntouched(subject: String): String
    fun subjectMinutes(subject: String, minutes: Int): String
    fun stillZero(subjects: String): String

    // run controls
    val begin: String
    val pause: String
    val earnSecured: String
    fun minutesUntilSecured(minutes: Int): String
    val giveUp: String
    val stopTitle: String
    val stopBody: String
    val stopConfirm: String
    val keepGoing: String

    // new subject sheet
    val newSubjectTitle: String
    val newSubjectHint: String
    fun threeMax(dropped: String): String
    val duplicateName: String
}

object FocusHi : FocusStrings {
    override val header = "FOCUS"
    override val ready = "TAIYAAR"
    override val inSession = "CHAL RAHA HAI"

    override val levelRefused =
        "Session ke beech level neeche nahi ja sakta. Upar ja sakte ho."
    override val crownWarning =
        "Crown Shield chalu karega, uninstall band kar dega, aur pact " +
            "arm ho jaayega. Neeche wali baatein padh lo — ye tap wapas " +
            "nahi hota."
    override val crownConfirm = "Samajh gaya"
    override val crownTickFirst = "Pehle upar wala tick lagao."
    override val crownDecline = "Rehne do"
    override fun lineNoBlock(name: String) = "$name — block off"
    override fun lineShield(name: String) = "$name — Shield on"
    override fun lineCrown(name: String) = "$name — Shield + uninstall lock"
    override fun ratePerRupee(minutes: Int) = " · $minutes min = ₹1"

    override fun pactConfirm(amount: String) =
        "$amount aur — pakka? Pact kabhi chhota nahi hota."

    override fun willEarn(minutes: Int, amount: String) =
        "$minutes min → $amount in the wallet"
    override fun minimumToEarn(minutes: Int) =
        "Kam se kam $minutes min padhna hoga, tabhi ₹ milega"
    override val setCustom = "Set"
    override fun customMinutes(minutes: Int) = "$minutes minutes"
    override fun useCustom(minutes: Int) = "Use ${minutes}m"

    override val howLabel = "KAISE PADHNA HAI"
    override val withSubject = "Subject ke saath"
    override val justFocus = "Bas focus"
    override val justFocusNote =
        "Koi subject nahi. Time chalega, ₹ milega, stats mein " +
            "\"General\" ke neeche jaayega."
    override fun examDaysLeft(exam: String, days: Int) = "$exam · ${days}d left"
    override val noSubjectsYet =
        "Abhi koi subject nahi. Profile mein apne subject likh do — " +
            "ya \"Bas focus\" chuno."
    override val addSubject = "+ Naya"

    override val studyAppLabel = "STUDY APP — ₹ tabhi jab yeh open ho"
    override val noStudyApp = "Koi study app nahi mili. Focus ke andar se apni app choose karo."
    override val noStudyAppWarning = "Bina study app timer ₹ nahi dega."

    override fun subjectUntouched(subject: String) = "$subject untouched in 30 days"
    override fun subjectMinutes(subject: String, minutes: Int) =
        "$subject · ${minutes}m in 30 days"
    override fun stillZero(subjects: String) = "Still 0: $subjects"

    override val begin = "Shuru karo"
    override val pause = "Rok do"
    override val earnSecured = "₹ pakka ho gaya. Ab jitna aur, utna zyada."
    override fun minutesUntilSecured(minutes: Int) = "$minutes min aur, phir ₹ pakka"
    override val giveUp = "Chhod do — jitna hua utna jama"
    override val stopTitle = "Session rok dein?"
    override val stopBody = "Jitna waqt hua, wo phir bhi jama hoga."
    override val stopConfirm = "Roko aur jama karo"
    override val keepGoing = "Chalte raho"

    override val newSubjectTitle = "NAYA SUBJECT"
    override val newSubjectHint = "Chemistry, Paper 3, Revision..."
    override fun threeMax(dropped: String) =
        "Teen subject rakh sakte ho. Naya jodoge to \"$dropped\" hat jayega."
    override val duplicateName = "Ye naam pehle se hai."
}

object FocusEn : FocusStrings {
    override val header = "FOCUS"
    override val ready = "READY"
    override val inSession = "IN SESSION"

    override val levelRefused =
        "You can't drop a level mid-session. Going up is fine."
    override val crownWarning =
        "Crown turns Shield on, blocks uninstalling, and arms a pact. " +
            "Read every line below — this tap does not undo."
    override val crownConfirm = "I understand"
    override val crownTickFirst = "Tick the box above first."
    override val crownDecline = "Not now"
    override fun lineNoBlock(name: String) = "$name — nothing blocked"
    override fun lineShield(name: String) = "$name — Shield on"
    override fun lineCrown(name: String) = "$name — Shield + uninstall lock"
    override fun ratePerRupee(minutes: Int) = " · $minutes min = ₹1"

    override fun pactConfirm(amount: String) =
        "$amount more — sure? A pact never gets shorter."

    override fun willEarn(minutes: Int, amount: String) =
        "$minutes min → $amount in the wallet"
    override fun minimumToEarn(minutes: Int) =
        "You need at least $minutes min before anything is paid"
    override val setCustom = "Set"
    override fun customMinutes(minutes: Int) =
        if (minutes == 1) "1 minute" else "$minutes minutes"
    override fun useCustom(minutes: Int) = "Use ${minutes}m"

    override val howLabel = "HOW YOU'RE STUDYING"
    override val withSubject = "With a subject"
    override val justFocus = "Just focus"
    override val justFocusNote =
        "No subject. The clock still runs and you still earn — " +
            "it lands under \"General\" in stats."
    override fun examDaysLeft(exam: String, days: Int) = "$exam · ${days}d left"
    override val noSubjectsYet =
        "No subjects yet. Add yours in Profile — or pick \"Just focus\"."
    override val addSubject = "+ New"

    override val studyAppLabel = "STUDY APP — ₹ only while this is open"
    override val noStudyApp = "No study app set. Pick one from inside Focus."
    override val noStudyAppWarning = "Without a study app the timer pays nothing."

    override fun subjectUntouched(subject: String) = "$subject untouched in 30 days"
    override fun subjectMinutes(subject: String, minutes: Int) =
        "$subject · ${minutes}m in 30 days"
    override fun stillZero(subjects: String) = "Still 0: $subjects"

    override val begin = "Begin"
    override val pause = "Pause"
    override val earnSecured = "Your ₹ is secured. Everything past this adds more."
    override fun minutesUntilSecured(minutes: Int) = "$minutes min more, then the ₹ is safe"
    override val giveUp = "Give up — log partial time"
    override val stopTitle = "Stop this session?"
    override val stopBody = "Partial time still gets banked."
    override val stopConfirm = "Stop and bank"
    override val keepGoing = "Keep going"

    override val newSubjectTitle = "NEW SUBJECT"
    override val newSubjectHint = "Chemistry, Paper 3, Revision..."
    override fun threeMax(dropped: String) =
        "Three subjects maximum. Adding one drops \"$dropped\"."
    override val duplicateName = "That name is already there."
}
