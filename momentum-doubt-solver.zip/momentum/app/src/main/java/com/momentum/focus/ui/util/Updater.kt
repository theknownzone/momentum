package com.momentum.focus.ui.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Release(
    val version: String,
    val apkUrl: String,
    val notes: String,
)

/**
 * Checks GitHub Releases for a newer build and installs it.
 *
 * Releases are used rather than Actions artifacts because artifacts require an
 * authenticated API token to download, while release assets are public. The CI
 * workflow publishes one release per successful build.
 */
object Updater {

    @Volatile
    var cached: Release? = null
        private set

    // Change this if the repo ever moves.
    private const val REPO = "theknownzone/momentum"
    private const val API = "https://api.github.com/repos/$REPO/releases/latest"

    fun currentVersion(context: Context): String = runCatching {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0"
    }.getOrDefault("0")

    /**
     * Download progress, held here rather than in the card.
     *
     * It used to live in the composable's own state, so switching tabs threw
     * the card away mid-download and it came back offering to start over — the
     * bytes were still arriving, the UI had just forgotten. Process-wide state
     * survives navigation because the download does.
     */
    var progress by mutableFloatStateOf(-1f)

    /**
     * Recent commit subjects, used when the release body is empty.
     *
     * Nothing writes those bodies — the workflow publishes and GitHub appends
     * only a compare link — so the app fell back to a list baked into the APK,
     * which is exactly the stale list this was meant to replace. The commits
     * exist either way and describe the same build, so they are a truer answer
     * than a hardcoded one and need nothing added to the release process.
     */
    private suspend fun recentCommits(): String? = withContext(Dispatchers.IO) {
        runCatching {
            val conn = (URL("https://api.github.com/repos/$REPO/commits?per_page=15")
                .openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("Accept", "application/vnd.github+json")
            }
            if (conn.responseCode != 200) return@withContext null
            val arr = JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
            val lines = (0 until arr.length()).mapNotNull { i ->
                val msg = arr.optJSONObject(i)?.optJSONObject("commit")
                    ?.optString("message").orEmpty()
                // First line only; commit bodies are for the repo, not a phone.
                val subject = msg.lineSequence().firstOrNull()?.trim().orEmpty()
                subject.takeIf {
                    it.isNotBlank() &&
                        !it.startsWith("Merge", true) &&
                        !it.startsWith("Bump", true) &&
                        !it.startsWith("chore", true)
                }
            }.distinct().take(10)
            if (lines.isEmpty()) null
            else "## Is build mein\n\n" + lines.joinToString("\n") { "- $it" }
        }.getOrNull()
    }

    /**
     * The notes attached to the newest release, whether or not it is newer
     * than what is installed.
     *
     * What's New used to read from a list hardcoded in the app, which meant it
     * only changed when someone remembered to edit it — and it went several
     * builds without being touched, so every update proudly announced the same
     * old fixes. The release body is written once, at release time, and cannot
     * fall out of step with the build it describes.
     */
    /** One published release: its version, when it landed, and its notes. */
    data class Entry(val version: String, val date: String, val notes: String)

    /**
     * The last several releases, newest first.
     *
     * The what's-new screen only ever asked for the latest one, which makes it
     * a notice rather than a log — someone who skipped two versions saw only
     * the third and had no way to find out what they had missed. Ten is enough
     * to cover a few months of a project this size and still fit one request.
     */
    suspend fun history(): List<Entry> = withContext(Dispatchers.IO) {
        runCatching {
            val conn = (URL("https://api.github.com/repos/$REPO/releases?per_page=10")
                .openConnection() as HttpURLConnection).apply {
                connectTimeout = 6_000
                readTimeout = 10_000
                setRequestProperty("Accept", "application/vnd.github+json")
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(text)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                if (o.optBoolean("draft")) return@mapNotNull null
                val body = o.optString("body").trim()
                if (body.isBlank()) return@mapNotNull null
                Entry(
                    version = o.optString("tag_name").ifBlank { o.optString("name") },
                    // "2026-09-06T18:04:11Z" -> "6 Sep". Substring rather than
                    // a parser: the shape is fixed by the API and a formatter
                    // here would be three imports for ten characters.
                    date = o.optString("published_at").take(10),
                    notes = body,
                )
            }
        }.getOrDefault(emptyList())
    }

    suspend fun latestNotes(): String? = withContext(Dispatchers.IO) {
        runCatching {
            val conn = (URL(API).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("Accept", "application/vnd.github+json")
            }
            if (conn.responseCode != 200) return@withContext null
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            json.optString("body").takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    /** Release body if someone wrote one, otherwise the commits themselves. */
    suspend fun notesOrCommits(): String? = latestNotes()?.let { body ->
        val meaningful = body.lines().map { it.trim() }.any {
            it.isNotBlank() &&
                !it.startsWith("**Full Changelog", true) &&
                !it.startsWith("Full Changelog", true) &&
                !it.startsWith("https://")
        }
        if (meaningful) body else null
    } ?: recentCommits()

    suspend fun check(context: Context): Release? = withContext(Dispatchers.IO) {
        runCatching {
            val conn = (URL(API).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("Accept", "application/vnd.github+json")
            }
            if (conn.responseCode != 200) return@withContext null
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })

            val tag = json.optString("tag_name").removePrefix("v")
            val assets = json.optJSONArray("assets") ?: return@withContext null
            var apk: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) {
                    apk = a.optString("browser_download_url"); break
                }
            }
            if (apk == null) return@withContext null

            if (!isNewer(tag, currentVersion(context))) {
                cached = null
                return@withContext null
            }
            Release(tag, apk, json.optString("body")).also { cached = it }
        }.getOrNull()
    }

    /** Compares dotted versions numerically, so 1.0.10 beats 1.0.9. */
    private fun isNewer(remote: String, local: String): Boolean {
        val r = remote.split(".").mapNotNull { it.toIntOrNull() }
        val l = local.split(".").mapNotNull { it.toIntOrNull() }
        for (i in 0 until maxOf(r.size, l.size)) {
            val a = r.getOrElse(i) { 0 }
            val b = l.getOrElse(i) { 0 }
            if (a != b) return a > b
        }
        return false
    }

    /**
     * Opens the release's APK in the browser instead of installing it here.
     *
     * The in-app installer needed REQUEST_INSTALL_PACKAGES, which is the
     * permission a malware dropper needs and the one Play Protect reacts to
     * hardest. Holding it alongside an accessibility service and a device
     * admin receiver produced the exact profile of a banking trojan, and the
     * install was blocked outright rather than merely warned about.
     *
     * Handing the URL to the browser costs one extra tap — the download lands
     * in Downloads and the user opens it — and the browser carries the install
     * permission on its own behalf, where it belongs.
     */
    fun openDownload(context: Context, release: Release): Boolean = runCatching {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(release.apkUrl))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        true
    }.getOrDefault(false)
}
