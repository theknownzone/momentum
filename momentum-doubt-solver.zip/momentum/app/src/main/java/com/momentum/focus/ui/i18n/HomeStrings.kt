package com.momentum.focus.ui.i18n

/**
 * The Hinglish side is the app's current wording copied verbatim, including
 * the parts that were already in English. Hinglish is a mix by nature, and
 * "Start focus" is what a Hinglish-reading user of this app has always seen —
 * translating it into something more Hindi would be a change to the existing
 * product, not a translation of it.
 */
interface HomeStrings {
    // thin-data notice
    val notEnoughData: String
    val countingFromToday: String
    fun countingSince(days: Int): String
    val afterThreeDays: String

    // festival card
    val calendar: String
    val themeLiveToday: String
    val themeArrivesOnDay: String

    // exam chip
    fun examWithDaysLeft(exam: String, days: Int): String

    // shield-was-killed card
    val shieldWasKilled: String
    fun deadForHoursMinutes(hours: Int, minutes: Int): String
    fun deadForMinutes(minutes: Int): String
    val shieldKilledBody: String

    // quick actions
    val quickActions: String
    val panic: String
    val panicDetail: String
    val journal: String
    val journalDetail: String
    val shield: String
    fun shieldDetail(apps: Int): String
    val rewards: String
    fun rewardsDetail(unlocked: Int): String
    val feeds: String
    val feedsAllOn: String
    fun feedsBlocked(count: Int): String

    // hero
    fun dayStreak(days: Int): String
    val walletBalance: String
    fun bankedFromFocus(hours: Int, minutes: Int): String
    fun phoneToday(hours: Int, minutes: Int): String
    fun firstRupeeHint(subject: String): String
    val firstRupeeAnySubject: String
    fun earnedToday(amount: String): String

    /** Labels under the four readings at the top of the scroll. */
    val statStreak: String
    val statLevel: String
    val statToday: String
    val statWallet: String

    /** The setup guess against the phone's own figure. */
    val baselineLabel: String
    val baselineGuess: String
    val baselineReal: String
    fun baselineOver(gap: String): String
    fun baselineUnder(gap: String): String
    fun sessionsCount(count: Int): String
    fun daysToExam(days: Int, exam: String): String
    val boardsFallback: String
    val crownWindow: String
    val startFocus: String

    // recent feed
    val recent: String
    fun leftEarly(ago: String): String
    val urgeBeaten: String
    val slipLogged: String
    fun urgeWhen(ago: String, hour: Int): String
    val held: String
    val reset: String
    val nothingBankedYet: String
    val emptyFeedBody: String

    // wordmark
    val wordmarkTagline: String
    fun skinTheme(skin: String): String
}

object HomeHi : HomeStrings {
    override val notEnoughData = "ABHI PURA DATA NAHI"
    override val countingFromToday = "Momentum aaj se ginna shuru kar raha hai."
    override fun countingSince(days: Int) = "Momentum $days din se gin raha hai."
    override val afterThreeDays = "3 din ke baad ye numbers sach mein kuch matlab rakhenge."

    override val calendar = "CALENDAR"
    override val themeLiveToday = "Aaj ka theme Home pe live hai."
    override val themeArrivesOnDay = "Theme us din khud aa jaayegi."

    override fun examWithDaysLeft(exam: String, days: Int) = "$exam · ${days}d left"

    override val shieldWasKilled = "SHIELD BAND HO GAYI THI"
    override fun deadForHoursMinutes(hours: Int, minutes: Int) = "${hours}h ${minutes}m tak"
    override fun deadForMinutes(minutes: Int) = "$minutes min tak"
    override val shieldKilledBody =
        "Phone ne Shield ko background mein maar diya tha. Autostart ON " +
            "karo, warna ye roz hoga."

    override val quickActions = "JALDI SE"
    override val panic = "Panic"
    override val panicDetail = "ya phone hilao"
    override val journal = "Journal"
    override val journalDetail = "aaj ka likho"
    override val shield = "Shield"
    override fun shieldDetail(apps: Int) = "$apps apps blocked"
    override val rewards = "Inaam"
    override fun rewardsDetail(unlocked: Int) = "$unlocked unlocked"
    override val feeds = "Feeds"
    override val feedsAllOn = "Shorts aur Reels chalu hain"
    override fun feedsBlocked(count: Int) = "$count feeds band · app khuli rehti hai"

    override fun dayStreak(days: Int) = "$days day streak"
    override val walletBalance = "Wallet mein"
    override fun bankedFromFocus(hours: Int, minutes: Int) =
        "%dh %02dm banked from focus".format(hours, minutes)
    override fun phoneToday(hours: Int, minutes: Int) =
        "%dh %02dm phone today".format(hours, minutes)
    override fun firstRupeeHint(subject: String) = "25 min $subject = first ₹"
    override val firstRupeeAnySubject = "25 min padhai = first ₹"
    override fun earnedToday(amount: String) = "▲ +$amount earned today"
    override val statStreak = "Streak"
    override val statLevel = "Level"
    override val statToday = "Aaj"
    override val statWallet = "Wallet"
    override val baselineLabel = "SETUP KE WAQT"
    override val baselineGuess = "Tumne socha tha"
    override val baselineReal = "Asli"
    override fun baselineOver(gap: String) = "$gap zyada. Ye andaze ka farak hai, tumhari galti nahi — koi bhi apna screen time kam hi aankta hai."
    override fun baselineUnder(gap: String) = "$gap kam. Tumne apne aap ko zyada bura samjha tha."
    override fun sessionsCount(count: Int) = "$count sessions"
    override fun daysToExam(days: Int, exam: String) = "${days}d to $exam"
    override val boardsFallback = "Boards"
    override val crownWindow = "CROWN KA WAQT"
    override val startFocus = "Padhai shuru"

    override val recent = "HAAL HI MEIN"
    override fun leftEarly(ago: String) = "$ago · left early"
    override val urgeBeaten = "Urge haari"
    override val slipLogged = "Slip likhi"
    override fun urgeWhen(ago: String, hour: Int) = "$ago · around $hour:00"
    override val held = "ruke"
    override val reset = "reset"
    override val nothingBankedYet = "Abhi kuch jama nahi"
    override val emptyFeedBody = "Ek session poora karo, pehle minute yahan aa jayenge."

    override val wordmarkTagline = "Kamaya hai, maanga nahi"
    override fun skinTheme(skin: String) = "$skin theme"
}

object HomeEn : HomeStrings {
    override val notEnoughData = "NOT ENOUGH DATA YET"
    override val countingFromToday = "Momentum starts counting from today."
    override fun countingSince(days: Int) =
        if (days == 1) "Momentum has been counting for 1 day."
        else "Momentum has been counting for $days days."
    override val afterThreeDays = "After three days these numbers will actually mean something."

    override val calendar = "CALENDAR"
    override val themeLiveToday = "Today's theme is live on Home."
    override val themeArrivesOnDay = "The theme arrives on the day itself."

    override fun examWithDaysLeft(exam: String, days: Int) = "$exam · ${days}d left"

    override val shieldWasKilled = "SHIELD WAS SHUT DOWN"
    override fun deadForHoursMinutes(hours: Int, minutes: Int) = "for ${hours}h ${minutes}m"
    override fun deadForMinutes(minutes: Int) = "for $minutes min"
    override val shieldKilledBody =
        "Your phone killed Shield in the background. Turn Autostart ON, " +
            "or this will happen every day."

    override val quickActions = "QUICK ACTIONS"
    override val panic = "Panic"
    override val panicDetail = "or shake the phone"
    override val journal = "Journal"
    override val journalDetail = "log today"
    override val shield = "Shield"
    override fun shieldDetail(apps: Int) =
        if (apps == 1) "1 app blocked" else "$apps apps blocked"
    override val rewards = "Rewards"
    override fun rewardsDetail(unlocked: Int) = "$unlocked unlocked"
    override val feeds = "Feeds"
    override val feedsAllOn = "Shorts and Reels are running"
    override fun feedsBlocked(count: Int) =
        if (count == 1) "1 feed blocked · the app still opens"
        else "$count feeds blocked · the apps still open"

    override fun dayStreak(days: Int) = if (days == 1) "1 day streak" else "$days day streak"
    override val walletBalance = "Wallet balance"
    override fun bankedFromFocus(hours: Int, minutes: Int) =
        "%dh %02dm banked from focus".format(hours, minutes)
    override fun phoneToday(hours: Int, minutes: Int) =
        "%dh %02dm phone today".format(hours, minutes)
    override fun firstRupeeHint(subject: String) = "25 min of $subject = your first ₹"
    override val firstRupeeAnySubject = "25 min of study = your first ₹"
    override fun earnedToday(amount: String) = "▲ +$amount earned today"
    override val statStreak = "Streak"
    override val statLevel = "Level"
    override val statToday = "Today"
    override val statWallet = "Wallet"
    override val baselineLabel = "AT SETUP"
    override val baselineGuess = "You guessed"
    override val baselineReal = "Actually"
    override fun baselineOver(gap: String) = "$gap more. That gap is normal — almost nobody guesses their own screen time high."
    override fun baselineUnder(gap: String) = "$gap less. You were harder on yourself than the phone was."
    override fun sessionsCount(count: Int) =
        if (count == 1) "1 session" else "$count sessions"
    override fun daysToExam(days: Int, exam: String) = "${days}d to $exam"
    override val boardsFallback = "Boards"
    override val crownWindow = "CROWN WINDOW"
    override val startFocus = "Start focus"

    override val recent = "RECENT"
    override fun leftEarly(ago: String) = "$ago · left early"
    override val urgeBeaten = "Urge beaten"
    override val slipLogged = "Slip logged"
    override fun urgeWhen(ago: String, hour: Int) = "$ago · around $hour:00"
    override val held = "held"
    override val reset = "reset"
    override val nothingBankedYet = "Nothing banked yet"
    override val emptyFeedBody =
        "Finish one focus session and your first minutes land here."

    override val wordmarkTagline = "Earned, not claimed"
    override fun skinTheme(skin: String) = "$skin theme"
}
