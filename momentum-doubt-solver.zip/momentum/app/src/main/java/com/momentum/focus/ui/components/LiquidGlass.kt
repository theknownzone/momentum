package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink

/**
 * A pane of glass sitting on the page, with a lit top edge and a faint
 * iridescent fringe.
 *
 * Three things make glass read as glass, and none of them is blur. There is a
 * bright specular band along the top where the light catches the bevel; the
 * body is pale and slightly translucent with the fill lifting again near the
 * bottom as light bounces back up; and the very edge splits colour into a
 * faint rainbow, which is what a real bevel does and what a flat translucent
 * rectangle never does.
 *
 * Deliberately not [Modifier.blur]. Blur is API 31+, and this app ships to 26 —
 * a blurred pane would look like glass on a new phone and like a plain grey box
 * on an old one, which is worse than never trying. Everything here is
 * gradients, so it renders identically everywhere.
 */
@Composable
fun LiquidGlass(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    radius: Dp = 22.dp,
    outlined: Boolean = true,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(radius)

    // Where the finger is, and whether it is down.
    //
    // Everything below this used to be drawn once and never move again: the
    // lit edge, the fringe, the shadow — all static gradients. It looked like
    // glass in a screenshot and like a picture of glass in the hand, because
    // real glass only reads as glass when the highlight travels as you move
    // against it.
    val press = remember { MutableInteractionSource() }
    val down by press.collectIsPressedAsState()
    // The touch point, in fraction-of-width. Half means centred, which is where
    // the highlight sits when nothing is being touched.
    var touchX by remember { mutableFloatStateOf(0.5f) }
    val slide by animateFloatAsState(
        targetValue = if (down) touchX else 0.5f,
        // Springs, not tweens, everywhere in here. A linear highlight slide
        // looks mechanical; the whole point is that the light has weight and
        // settles.
        animationSpec = spring(dampingRatio = 0.75f, stiffness = 400f),
        label = "specular",
    )
    // Squish on press, overshoot back on release.
    //
    // 0.985 rather than the 0.95 a button usually takes. This is a pane of
    // glass, not a rubber button — it should compress barely enough to feel
    // the touch land, then spring back past its own size and settle. Damping
    // 0.75 gives exactly one overshoot; lower bounces, higher is dead.
    val squish by animateFloatAsState(
        targetValue = if (down) 0.985f else 1f,
        animationSpec = spring(dampingRatio = 0.75f, stiffness = 400f),
        label = "squish",
    )

    Box(
        modifier
            .graphicsLayer {
                scaleX = squish
                scaleY = squish
            }
            .clip(shape)
            .background(CreamCard)
            .background(tint.copy(alpha = 0.18f))
            .background(
                // Body: bright at the top, thinnest through the middle, lifting
                // again at the base. A single flat wash reads as paint; this
                // reads as something with depth behind it.
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.72f),
                        Color.White.copy(alpha = 0.10f),
                        Color.White.copy(alpha = 0.34f),
                    )
                )
            )
            .drawWithContent {
                drawContent()
                val lip = size.height * 0.22f
                // The lit bevel along the top edge.
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.85f), Color.Transparent),
                        endY = lip,
                    ),
                    size = Size(size.width, lip),
                )
                // The specular hot-spot, which is the part that moves.
                //
                // A soft radial of white centred on the finger, riding along
                // the lit edge. This is the single thing that separates Apple's
                // glass from a translucent rectangle: the bevel highlight is
                // brightest where you are touching it and fades away from
                // there, so the surface reports where your hand is. Drawn over
                // the static bevel rather than replacing it, so an untouched
                // pane still has its lit top.
                val hotX = size.width * slide
                val hot = size.width * 0.42f
                drawCircle(
                    brush = Brush.radialGradient(
                        colorStops = arrayOf(
                            0f to Color.White.copy(alpha = 0.55f),
                            0.45f to Color.White.copy(alpha = 0.16f),
                            1f to Color.Transparent,
                        ),
                        center = Offset(hotX, lip * 0.35f),
                        radius = hot,
                    ),
                    radius = hot,
                    center = Offset(hotX, lip * 0.35f),
                )
                // Colour splitting at the rim. Kept very low alpha on purpose —
                // at full strength it stops looking like glass and starts
                // looking like a bug.
                drawRect(
                    brush = Brush.horizontalGradient(
                        0.00f to Color(0xFF7FD4FF).copy(alpha = 0.22f),
                        0.28f to Color.Transparent,
                        0.72f to Color.Transparent,
                        1.00f to Color(0xFFFFA9C9).copy(alpha = 0.22f),
                    ),
                )
                // A shadow catching under the bottom lip.
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.Transparent, Ink.copy(alpha = 0.07f)),
                        startY = size.height - lip * 0.7f,
                    ),
                    topLeft = Offset(0f, size.height - lip * 0.7f),
                    size = Size(size.width, lip * 0.7f),
                )
            }
            .then(if (outlined) Modifier.border(2.dp, Ink.copy(alpha = 0.55f), shape) else Modifier)
            .then(
                if (onClick != null) {
                    Modifier
                        // The touch point has to be captured before the click
                        // fires, which is why this is a separate pointer pass
                        // rather than something clickable could report.
                        .pointerInput(Unit) {
                            awaitPointerEventScope {
                                while (true) {
                                    val e = awaitPointerEvent()
                                    e.changes.firstOrNull()?.let { c ->
                                        if (size.width > 0) {
                                            touchX = (c.position.x / size.width).coerceIn(0f, 1f)
                                        }
                                    }
                                }
                            }
                        }
                        .clickableNoRipple(press, onClick = onClick)
                } else Modifier
            ),
        contentAlignment = Alignment.Center,
        content = content,
    )
}

/**
 * The dark cousin of [LiquidGlass], for a bar sitting on the hero.
 *
 * [LiquidGlass] starts from an opaque [CreamCard] base, which is right on a
 * cream page and wrong here — the hero has artwork and falling petals behind
 * it, and an opaque strip hides them, reading as a sticker pasted over the
 * picture. This dims what is behind just enough for the text to stay legible
 * and lets the rest through.
 *
 * Same decision as [LiquidGlass] on blur: none. An API 26 phone and an API 34
 * phone render this identically.
 */
@Composable
fun GlassBar(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    radius: Dp = 12.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(radius)
    Box(
        modifier
            .clip(shape)
            // Dim first, so whatever is behind can never fight the text, then
            // lay the glass over that.
            .background(Color.Black.copy(alpha = 0.34f))
            .background(tint.copy(alpha = 0.06f))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.16f),
                        Color.White.copy(alpha = 0.03f),
                        Color.White.copy(alpha = 0.08f),
                    )
                )
            )
            .drawWithContent {
                drawContent()
                val lip = size.height * 0.30f
                // The lit top edge. On a dark pane this is the one cue that
                // sells glass rather than a translucent rectangle.
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.30f), Color.Transparent),
                        endY = lip,
                    ),
                    size = Size(size.width, lip),
                )
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.18f)),
                        startY = size.height - lip,
                    ),
                    topLeft = Offset(0f, size.height - lip),
                    size = Size(size.width, lip),
                )
            }
            .border(1.dp, Color.White.copy(alpha = 0.18f), shape),
        content = content,
    )
}

/** The same glass shaped as a full-width pill, for primary actions. */
@Composable
fun LiquidGlassButton(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    LiquidGlass(
        modifier = modifier.fillMaxWidth(),
        tint = tint,
        radius = 26.dp,
        onClick = onClick,
    ) {
        Box(Modifier.padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
            content()
        }
    }
}
