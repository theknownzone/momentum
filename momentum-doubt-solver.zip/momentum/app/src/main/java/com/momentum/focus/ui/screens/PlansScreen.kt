package com.momentum.focus.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.ai.Doubt
import com.momentum.focus.ai.Mock
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.ui.components.CrownMark
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileObject
import com.momentum.focus.ui.components.glowEdge
import com.momentum.focus.ui.components.GlassPanel
import com.momentum.focus.ui.components.Locked
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.launch

/**
 * The two plans, and an explicit promise about where the line sits.
 *
 * Every line on this screen was checked against the code before it was written
 * here, because both columns had drifted into fiction. Free claimed crown mode,
 * which FocusScreen refuses without premium. Free claimed unlimited profiles
 * and full history while the paid pitch sold the same two things back. And the
 * paid column advertised backup, restore and website blocking, none of which
 * exist anywhere in this app — a pricing page is the one screen where naming a
 * feature that was never built is taking money for it.
 *
 * The line that actually holds: nothing that blocks a distraction costs money.
 * The shield, the feed guard, the pact and panic are free and stay free, since
 * someone relapsing because they did not pay would be the app failing at its
 * only job. What is paid is the assistant, the whole theme set at once, and
 * crown mode — which is not a blocker but a commitment device.
 *
 * LOCKED IS A PITCH, UNLOCKED IS A RECEIPT.
 *
 * Everything on this card that is styled to persuade — the gold band, the halo,
 * the price, the neon on the product name, the frosted tiles — is for someone
 * deciding. Once it is bought, all of it has to calm down: mint instead of
 * gold, a quieter halo, the price replaced by the word Yours, the key on show.
 *
 * The rule exists because the card kept half-switching. A paying user was
 * being told "LOCKED UNTIL YOU UNLOCK" under a header reading Yours, and the
 * loudest glow on the screen sat behind the one person with nothing left to
 * buy. Selling something to the person who already paid for it does not read
 * as enthusiasm; it reads as the app not knowing who it is talking to.
 *
 * So: any new conditional here answers "is this persuading, or is this
 * confirming?" — and if it persuades, it is gated on !data.premium.
 */
/** The watermark behind the heading. Same word as the heading itself. */
// Not str.plans.kicker: this is a top-level const, evaluated at compile time,
// where there is no composition and therefore no strings(). A bulk rename of
// "PLANS" walked straight into it. The watermark is the same word in both
// languages anyway.
private const val GHOST = "PLANS"

@Composable
fun PlansScreen(
    data: AppData,
    onBuy: () -> Unit,
    onRedeem: suspend (String) -> Boolean,
    onRemove: () -> Unit,
    onDone: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val skin = LocalSkin.current
    var keyOpen by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        // Header. The oversized ghost word that used to sit behind this was
        // scaled 1.7x from its left edge, so it ran off the right margin and
        // sat on top of the real heading — the whole block read crooked. A
        // plain left-aligned stack is straight at every text size.
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            // Measured, not guessed. Both earlier attempts picked the size by
            // hand: one scaled the heading 1.7x from its left edge and ran off
            // the right margin, the next played safe at 34sp and never reached
            // it. Measuring the word and solving for the width that actually
            // exists lands on the edge on every screen and at every system
            // text size, which is the only version of this that stays right.
            val density = LocalDensity.current
            val measurer = rememberTextMeasurer()
            // Tracking in em rather than sp so it grows with the font size —
            // in sp it would stay put while the letters grew, and the spread
            // would tighten as the word got bigger.
            val tracking = 0.42.em
            val ghostSize = remember(maxWidth, density) {
                val probe = 40.sp
                val measured = measurer.measure(
                    GHOST,
                    TextStyle(
                        fontSize = probe,
                        letterSpacing = tracking,
                        fontWeight = FontWeight.Bold,
                    ),
                ).size.width.toFloat()
                // Tracking is added after the final letter too, so the measured
                // box is one gap wider than the glyphs. Without taking it off,
                // the word stops short of the edge by exactly that much.
                val trailing = with(density) { probe.toPx() } * 0.42f
                val target = with(density) { maxWidth.toPx() }
                if (measured <= trailing) probe else probe * (target / (measured - trailing))
            }
            Text(
                GHOST,
                fontSize = ghostSize,
                lineHeight = ghostSize,
                letterSpacing = tracking,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                // Clipped rather than allowed to push the layout. If the
                // measurement is ever a pixel out, the word loses a sliver of
                // its last letter instead of shoving the heading sideways —
                // which is how this block read crooked the first time.
                overflow = TextOverflow.Clip,
                color = Tang.accent.copy(alpha = 0.13f),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .offset(y = (-18).dp),
            )
        Column(Modifier.fillMaxWidth()) {
            Text(str.plans.kicker, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(2.dp))
            Text(
                str.plans.title,
                // displaySmall overran the width and the full stop fell off
                // the right edge. One step down fits at every text size.
                style = MaterialTheme.typography.headlineMedium,
                color = Ink,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                str.plans.subtitle,
                style = MaterialTheme.typography.bodyLarge,
                color = InkMid,
            )
        }
        }

        Spacer(Modifier.height(22.dp))

        // ---- lifetime -------------------------------------------------------
        // Ordered first now. The paid card is the one thing this screen exists
        // to show, and it was sitting below a longer free card where you had to
        // scroll to reach it. Gold plate, crown, and the only glow in the app —
        // three signals stacked on one card so nothing else can compete.
        Box(Modifier.fillMaxWidth()) {
            Aura(
                color = Tang.accent,
                // Brighter while it is still an offer. It used to be the other
                // way round — the loudest halo on the screen sat behind the
                // card of the person who had nothing left to buy.
                strength = if (data.premium) 0.30f else 0.55f,
                modifier = Modifier.fillMaxWidth(),
            ) {
                // Inset on purpose. The aura draws behind its content, and the
                // card was filling the full width — so the halo was always
                // underneath opaque paint and nothing showed. The margin is
                // where the glow actually lives.
                // The halo goes round the whole card, not just the wordmark.
                // The margin on the panel below is what gives it somewhere to
                // live — a glow drawn under an opaque card edge is a glow
                // nobody sees.
                Aura(color = GoldNeon, strength = 0.62f) {
                GlassPanel(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        // A light running the edge of the paid card, and only
                        // the paid one. On a pricing page the job of the
                        // highlighted plan is to be the thing the eye lands on
                        // first; an aura says "this one glows" and a travelling
                        // edge says "this one is alive". The free card below
                        // stays flat paper, which is what makes the difference
                        // read at a glance instead of on reading.
                        .glowEdge(
                            active = true,
                            shape = RoundedCornerShape(Paper.CardRadius),
                            lit = 2.dp,
                        )
                        // Comic print: a hard offset frame behind the card.
                        //
                        // The Ben-Day field used to be in here too and could
                        // never be seen. GlassPanel applies the caller's
                        // modifier first and then paints .background(CreamCard)
                        // over it — an opaque fill — so everything this
                        // drawBehind drew inside the card bounds was covered
                        // immediately. Only the offset frame survived, because
                        // it sticks out past the edge. The dots have moved down
                        // onto the inner Column, which is inside the panel's
                        // fills and above them.
                        .drawBehind {
                            val d = 6.dp.toPx()
                            drawRoundRect(
                                color = Ink,
                                topLeft = Offset(d, d),
                                size = size,
                                cornerRadius = CornerRadius(
                                    Paper.CardRadius.toPx(),
                                    Paper.CardRadius.toPx(),
                                ),
                            )
                        },
                    tint = Butter.fill,
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            // Gold while it is being sold, mint once it is
                            // owned. See the note on this screen: locked is a
                            // pitch, unlocked is a receipt. This band stayed
                            // gold either way, so the top of the card kept
                            // advertising to the person who had already paid —
                            // while four other things on the same card (the
                            // header, the button, the key, the tag) had already
                            // switched over.
                            .background(
                                if (data.premium) Mint.fill.lit() else Butter.fill.lit(),
                            )
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CrownMark(size = 30.dp)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    str.plans.lifetime,
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = Butter.on,
                                )
                            }
                            Text(
                                if (data.premium) str.plans.yours else "₹399",
                                style = MaterialTheme.typography.headlineSmall,
                                color = Butter.on,
                            )
                        }
                        Spacer(Modifier.height(2.dp))
                        // Set in gold on its own glow rather than as grey
                        // subtext. It is the product name on the card someone
                        // is deciding about, so it should read as the thing
                        // being bought, not as a caption under the price.
                        Aura(
                            color = if (data.premium) Mint.accent else GoldNeon,
                            strength = if (data.premium) 0.25f else 0.5f,
                        ) {
                            Text(
                                str.plans.productName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                // Dark on the gold fill. In GoldNeon it was
                                // yellow on yellow and vanished; the glow
                                // behind is what supplies the gold.
                                color = Butter.on,
                            )
                        }
                    }
                    Box(Modifier.fillMaxWidth().height(Paper.Outline).background(Ink))

                    // Gold runs through the whole card, not just the strip at
                    // the top. Under the header this body was plain cream —
                    // exactly the cream of the free card below it — so the two
                    // plans differed by one band of colour and nothing else.
                    // The reference for this page fills its highlighted plan
                    // edge to edge, and that is why the eye lands on it.
                    Column(
                        Modifier
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Butter.fill.copy(alpha = 0.30f),
                                        Butter.fill.copy(alpha = 0.12f),
                                        Butter.fill.copy(alpha = 0.22f),
                                    ),
                                ),
                            )
                            // Ben-Day dots, after the gradient so they land on
                            // top of it and under the text. This is the one
                            // page in the app that is selling something and the
                            // free card beside it is deliberately flat, so the
                            // difference has to land before a word is read.
                            //
                            // Radius in dp, not raw pixels. It was 1.7f, and
                            // DrawScope units are pixels — a 0.6dp dot at five
                            // percent alpha is not a faint texture, it is
                            // nothing at all. Same mistake as the stars in
                            // SkinWeather.
                            .drawBehind {
                                // Sparse and faint on purpose.
                                //
                                // The first pass at making these visible went
                                // straight past "texture" into "rash": 1.3dp
                                // dots on an 11dp grid at ten percent alpha
                                // covered the whole card, including behind the
                                // feature list, so the eye read spots rather
                                // than paper. A halftone is meant to be the
                                // thing you notice second. Wider grid, smaller
                                // dot, and under half the alpha.
                                val step = 16.dp.toPx()
                                val r = 0.85.dp.toPx()
                                val ink = Ink.copy(alpha = 0.055f)
                                var y = step / 2f
                                var row = 0
                                while (y < size.height) {
                                    var x = if (row % 2 == 0) step / 2f else step
                                    while (x < size.width) {
                                        drawCircle(ink, r, Offset(x, y))
                                        x += step
                                    }
                                    y += step
                                    row++
                                }
                            }
                            .padding(16.dp),
                    ) {
                        PlanLine(str.plans.allModes, str.plans.allModesNote, highlight = true)
                        PlanLine(
                            str.plans.perSessionLabel,
                            str.plans.perSession(Doubt.PER_SESSION, Doubt.FREE_SESSION),
                        )
                        PlanLine(str.plans.photoPdf)
                        // Read off Mock.COUNT, which is 10. This said 5 — it
                        // was written when the drill was five questions and
                        // was not touched when the drill was doubled. A number
                        // on a pricing page has to be fetched from the constant
                        // that decides it, or it is only ever right on the day
                        // it is typed.
                        PlanLine(str.plans.mockTest, str.plans.mockNote(Mock.COUNT))
                        PlanLine(str.plans.crownMode, str.plans.crownNote)
                        PlanLine(str.plans.allThemes, str.plans.allThemesNote)
                        PlanLine(str.plans.posterBackdrop)

                        Spacer(Modifier.height(14.dp))
                        // The header depends on whether it is true.
                        //
                        // "LOCKED UNTIL YOU UNLOCK" was unconditional, so
                        // somebody holding Lifetime — with str.plans.yours in the
                        // header, "Unlocked" on the button and their key
                        // printed underneath — was still being told these
                        // three things were locked. Four places on one card
                        // saying they own it and one saying they do not.
                        Text(
                            if (data.premium) str.plans.ownedHeader else str.plans.lockedHeader,
                            style = MaterialTheme.typography.labelSmall,
                            color = InkMid,
                        )
                        Spacer(Modifier.height(8.dp))
                        // The same frosting the app puts over a blocked video,
                        // pointed at the paid features. You can see the thing
                        // is there and you can see you cannot reach it yet —
                        // which is a far better argument than a bullet list.
                        // Both of these are real and both are locked right
                        // now, which is the whole point of the frosted peek.
                        // It used to be pointed at backup, restore and website
                        // blocking — three things that have never existed in
                        // this codebase.
                        PremiumPeek(
                            locked = !data.premium,
                            title = str.plans.peekModesTitle,
                            body = str.plans.peekModesBody,
                            art = TileArt.Medal,
                        )
                        Spacer(Modifier.height(8.dp))
                        PremiumPeek(
                            locked = !data.premium,
                            title = str.plans.peekPageTitle,
                            body = str.plans.peekPageBody,
                            art = TileArt.Camera,
                        )
                        Spacer(Modifier.height(8.dp))
                        PremiumPeek(
                            locked = !data.premium,
                            title = str.plans.peekThemesTitle,
                            // Was "All six skins — Sakura, Frost, Ember and the
                            // rest". There is no Frost skin. Frost.kt is a card
                            // surface, not a theme, and it got read as one. The
                            // levelled set is five: Sakura at 1, Monsoon at 3,
                            // Ember at 6, Midnight at 10, Gold at 15 — the
                            // seasonal five are all unlockLevel 1 and free to
                            // everybody, so they are not what the money buys.
                            body = str.plans.peekThemesBody,
                            art = TileArt.Coin,
                        )
                        // "Aur gehra focus, premium ke saath / Ye abhi bane
                        // nahi hain" used to sit here, between the tiles and
                        // the button.
                        //
                        // It was a paragraph about features that do not exist,
                        // placed directly under three that do — so the last
                        // thing read before the buy button was a promise about
                        // nothing. On a card already carrying seven checks and
                        // three tiles it was the one block with no content in
                        // it at all.
                        Spacer(Modifier.height(16.dp))
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (data.premium) Sunk else Mint.fill)
                                .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                                .clickableNoRipple(
                                    remember { MutableInteractionSource() },
                                    enabled = !data.premium,
                                ) { haptics.confirm(); onBuy() }
                                .padding(vertical = 14.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                if (data.premium) str.plans.unlocked else str.plans.unlockLifetime,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (data.premium) InkMid else Mint.on,
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            if (data.premium) "Key: ${License.pretty(data.licenseKey)}"
                            else str.plans.haveKey,
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMid,
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    haptics.tap()
                                    if (data.premium) onRemove() else keyOpen = true
                                }
                                .padding(6.dp),
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            str.plans.nothingBlocked,
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMid,
                            modifier = Modifier.align(Alignment.CenterHorizontally),
                        )
                    }
                }
                }
            }

            // The badge straddles the top edge of the card rather than sitting
            // inside it, so the card reads as the one that has been picked out.
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (-11).dp),
            ) {
                Tag(if (data.premium) str.plans.yours.uppercase() else str.plans.bestValue, Butter, crown = true)
            }
        }

        Spacer(Modifier.height(Paper.Gap))

        // ---- free ----
        // Flat paper, and that is the whole point. The paid card is glass on a
        // gold halo; this one is a plain sheet with an outline and nothing
        // else. Both cards used to be the same panel on nearly the same cream,
        // so the two tiers read as one long list instead of as a choice — and
        // no wording fixes that, only the surface does.
        // Recessed rather than raised: a flat sunk panel with a thinner, softer
        // outline. The paid card sits forward, this one sits back, and the
        // difference has to be visible before a single word is read.
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(Sunk.copy(alpha = 0.55f))
                .border(1.5.dp, Ink.copy(alpha = 0.32f), RoundedCornerShape(Paper.CardRadius))
                .padding(16.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(str.plans.freeTitle, style = MaterialTheme.typography.headlineSmall, color = Ink)
                if (!data.premium) Tag(str.plans.youreOnThis, Mint)
            }
            Rule()
            // Crown left this list because the code refuses it without
            // premium, and profiles and history left it because the paid
            // column was selling the same two things two cards up.
            PlanLine(str.plans.freeBlocking)
            PlanLine(str.plans.freeFeeds)
            PlanLine(str.plans.freeTimer)
            PlanLine(str.plans.freePact)
            PlanLine(str.plans.freePanic)
            PlanLine(str.plans.freeExamAlerts)
            PlanLine(str.plans.freeStats)
            PlanLine(str.plans.freeStudyMode, str.plans.freeStudyNote(Doubt.FREE_SESSION))
            PlanLine(str.plans.freePoster)
            Spacer(Modifier.height(6.dp))
            Text(
                str.plans.freeThemesNote,
                style = MaterialTheme.typography.bodyMedium,
                color = InkMid,
            )
        }


        if (keyOpen) {
            LicenseDialog(
                onRedeem = onRedeem,
                onClose = { keyOpen = false },
            )
        }

        Spacer(Modifier.height(20.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                .clickableNoRipple(remember { MutableInteractionSource() }) {
                    haptics.tap(); onDone()
                }
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(str.plans.back, style = MaterialTheme.typography.titleMedium, color = Ink)
        }
    }
}

@Composable
private fun Rule() {
    Spacer(Modifier.height(10.dp))
    Box(Modifier.fillMaxWidth().height(Paper.Outline).background(Ink))
    Spacer(Modifier.height(10.dp))
}

/**
 * One feature, with the number that makes it a feature.
 *
 * "Sawaal per session" says nothing on its own; "1000 · free mein 20" is the
 * whole argument. The note is set apart in gold on its own chip so the eye
 * lands on the figure rather than reading the sentence and moving on.
 */
@Composable
private fun PlanLine(text: String, note: String? = null, highlight: Boolean = false) {
    Row(
        Modifier.padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("✓", style = MaterialTheme.typography.bodyLarge, color = Mint.accent)
        Spacer(Modifier.width(10.dp))
        // The headline line gets a marker swipe under it. One line on the
        // card, not several — a page where four things are highlighted has
        // nothing highlighted, and the eye needs one place to land first.
        Text(
            text,
            style = MaterialTheme.typography.bodyLarge,
            color = Ink,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal,
            // weight(fill = false) so the label takes what it needs and gives
            // the rest back. Without it the label and the chip both asked for
            // their full width on a row that had less, and the chip lost —
            // "Friend + Guru" broke across two lines inside a pill sized for
            // one, which is the split chip on the premium card.
            modifier = (
                if (!highlight) Modifier else Modifier.drawBehind {
                val h = size.height
                val path = Path().apply {
                    moveTo(-3f, h * 0.62f)
                    quadraticBezierTo(size.width * 0.5f, h * 0.50f, size.width + 6f, h * 0.60f)
                    lineTo(size.width + 6f, h * 0.98f)
                    quadraticBezierTo(size.width * 0.5f, h * 1.06f, -3f, h * 0.92f)
                    close()
                }
                    drawPath(path, color = GoldNeon.copy(alpha = 0.55f))
                }
                ).weight(1f, fill = false),
        )
        if (note != null) {
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(GoldNeon.copy(alpha = 0.30f))
                    .border(1.5.dp, Ink, RoundedCornerShape(8.dp))
                    .padding(horizontal = 7.dp, vertical = 1.dp),
            ) {
                Text(
                    note,
                    // The chip is a label, not a paragraph. Left to wrap it
                    // will, and a two-line pill next to a one-line row is the
                    // thing that made this card look broken.
                    maxLines = 1,
                    softWrap = false,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Ink,
                )
            }
        }
    }
}

@Composable
private fun Tag(label: String, sticker: Sticker, crown: Boolean = false) {
    Box(
        Modifier
            .clip(RoundedCornerShape(9.dp))
            .background(sticker.fill)
            .border(2.dp, Ink, RoundedCornerShape(9.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        // The emoji is gone from here too. A system emoji renders as a
        // different picture on every phone and none of them match a cut-paper
        // app; the drawn one is the same crown everywhere.
        if (crown) {
            CrownMark(size = 13.dp)
            Spacer(Modifier.width(5.dp))
        }
        Text(label, style = MaterialTheme.typography.labelSmall, color = sticker.on)
      }
    }
}

/**
 * Key entry.
 *
 * Deliberately forgiving about formatting: it accepts lowercase, missing dashes
 * and stray spaces, because these get retyped from an email on a phone keyboard
 * and rejecting a correct key over a lowercase letter is a support ticket that
 * should never exist. Only a genuinely wrong key is refused, and it says so
 * rather than silently doing nothing.
 */
@Composable
private fun LicenseDialog(
    onRedeem: suspend (String) -> Boolean,
    onClose: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(18.dp),
        ) {
            Text(str.plans.keyTitle, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(4.dp))
            Text(
                str.plans.keyHint,
                style = MaterialTheme.typography.headlineSmall,
                color = Ink,
            )
            Spacer(Modifier.height(14.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(24); error = false },
                placeholder = { Text(str.plans.keyPlaceholder) },
                singleLine = true,
                isError = error,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )

            if (error) {
                Spacer(Modifier.height(8.dp))
                Text(
                    str.plans.keyWrong,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClose)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(str.plans.cancel, style = MaterialTheme.typography.titleMedium, color = Ink)
                }
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Mint.fill)
                        .border(Paper.Outline, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(
                            remember { MutableInteractionSource() },
                            enabled = !checking && text.isNotBlank(),
                        ) {
                            checking = true
                            scope.launch {
                                val ok = onRedeem(text)
                                checking = false
                                if (ok) { haptics.confirm(); onClose() }
                                else { haptics.press(); error = true }
                            }
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (checking) str.plans.checking else str.plans.unlock,
                        style = MaterialTheme.typography.titleMedium,
                        color = Mint.on,
                    )
                }
            }
        }
    }
}


/**
 * A paid feature shown through frosted glass.
 *
 * Same treatment the shield puts over a blocked video: the row is rendered in
 * full and then frosted, so the feature is visibly present and visibly out of
 * reach. Once [locked] is false the frost disappears and the row is simply the
 * feature, with no layout shift between the two states.
 */
@Composable
private fun PremiumPeek(locked: Boolean, title: String, body: String, art: TileArt) {
    Locked(locked = locked, modifier = Modifier.fillMaxWidth(), label = "PREMIUM") {
        // A comic panel with a drawn object on it. These three cards are the
        // whole pitch — they are what someone reads before deciding to pay —
        // and they were three identical cream rectangles with text in them.
        // A frame, a halftone field and a glyph give each one a face.
        Row(
            Modifier
                .fillMaxWidth()
                // The hard offset frame only. It sits outside the card, so it
                // has to be drawn before the clip or it gets cut off at its
                // own edge.
                .drawBehind {
                    val d = 5.dp.toPx()
                    drawRoundRect(
                        color = Ink,
                        topLeft = Offset(d, d),
                        size = size,
                        cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx()),
                    )
                }
                .clip(RoundedCornerShape(12.dp))
                .background(CreamCard)
                // Ben-Day dots, and now they are where the old comment claimed
                // they already were. Modifiers run in order: the field used to
                // be drawn in the block above, before .clip and before
                // .background(CreamCard), so it was painted and then buried
                // under an opaque fill on the very next line. It was neither
                // clipped nor visible. After the background it is both.
                //
                // Radius in dp too — 1.5f was raw pixels, roughly half a dp.
                .drawBehind {
                    // Same restraint as the card behind these — see the note
                    // there. Slightly tighter grid because these panels are
                    // small, but the same faint dot.
                    val step = 13.dp.toPx()
                    val r = 0.85.dp.toPx()
                    val ink = Ink.copy(alpha = 0.055f)
                    var y = step / 2f
                    var row = 0
                    while (y < size.height) {
                        var x = if (row % 2 == 0) step / 2f else step
                        while (x < size.width) {
                            drawCircle(ink, r, Offset(x, y))
                            x += step
                        }
                        y += step
                        row++
                    }
                }
                .border(3.dp, Ink, RoundedCornerShape(12.dp))
                .padding(horizontal = 13.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // A stage, not a plate.
            //
            // At 58dp beside two lines of text this was still a list row with
            // a bigger bullet on it. The art has to be tall enough to be the
            // thing you look at first, which on a row this shape means taking
            // the full height rather than sitting centred in the middle of it.
            Box(
                Modifier
                    .size(width = 78.dp, height = 86.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Butter.fill.copy(alpha = if (locked) 0.50f else 0.78f),
                                GoldNeon.copy(alpha = if (locked) 0.10f else 0.20f),
                                Butter.fill.copy(alpha = if (locked) 0.20f else 0.36f),
                            ),
                        ),
                    )
                    .border(
                        2.5.dp,
                        Ink.copy(alpha = if (locked) 0.45f else 0.9f),
                        RoundedCornerShape(16.dp),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                // The pool of light, from the brand wheel on the spin screen.
                // Drawn behind the object rather than as a background on it,
                // so it spills past the edges instead of ending at a box —
                // which is the whole difference between a glow and a coloured
                // square.
                Canvas(Modifier.fillMaxSize()) {
                    val r = size.minDimension * 0.62f
                    drawCircle(
                        brush = Brush.radialGradient(
                            colorStops = arrayOf(
                                0f to GoldNeon.copy(alpha = if (locked) 0.38f else 0.58f),
                                0.5f to GoldNeon.copy(alpha = if (locked) 0.16f else 0.26f),
                                1f to Color.Transparent,
                            ),
                            center = center,
                            radius = r,
                        ),
                        radius = r,
                    )
                    // The halogen ring: a bright rim where the light ends.
                    //
                    // This is what makes the brand circles on the spin screen
                    // read as lit rather than as tinted. A radial fade alone
                    // has no edge, so it looks like a coloured smudge; the ring
                    // gives the glow a boundary and the boundary is the thing
                    // the eye picks up as light.
                    drawCircle(
                        color = GoldNeon.copy(alpha = if (locked) 0.30f else 0.55f),
                        radius = size.minDimension * 0.36f,
                        center = center,
                        style = Stroke(width = 2.dp.toPx()),
                    )
                    drawCircle(
                        color = GoldNeon.copy(alpha = if (locked) 0.12f else 0.22f),
                        radius = size.minDimension * 0.44f,
                        center = center,
                        style = Stroke(width = 1.5.dp.toPx()),
                    )
                    // Comic marks in the corners — the hatch this app draws
                    // everywhere else and had left off the one place it was
                    // selling something.
                    val ink = Ink.copy(alpha = if (locked) 0.16f else 0.28f)
                    val w = 1.5.dp.toPx()
                    listOf(
                        Offset(size.width * 0.16f, size.height * 0.18f),
                        Offset(size.width * 0.84f, size.height * 0.22f),
                        Offset(size.width * 0.80f, size.height * 0.82f),
                    ).forEachIndexed { i, c ->
                        val len = size.minDimension * (0.07f + 0.02f * i)
                        drawLine(ink, Offset(c.x - len, c.y), Offset(c.x + len, c.y), w)
                        drawLine(ink, Offset(c.x, c.y - len), Offset(c.x, c.y + len), w)
                    }
                    // No ground oval here.
                    //
                    // There was one, and TileObject already draws its own cast
                    // shadow as its first pass — so every object on this page
                    // stood on two shadows at once, one hard and offset and one
                    // soft and centred. That is the doubled shadow under the
                    // coin.
                }
                TileObject(art = art, fill = GoldNeon, size = 54.dp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Ink,
                )
                Spacer(Modifier.height(2.dp))
                Text(body, style = MaterialTheme.typography.bodyMedium, color = InkMid)
            }
        }
    }
}
