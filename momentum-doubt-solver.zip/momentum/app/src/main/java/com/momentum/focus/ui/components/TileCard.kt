package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Paper
import kotlin.math.cos
import kotlin.math.sin

/**
 * A tile: raised, tinted, with punched marks at two corners.
 *
 * The marks are the point. Cards in this app are plain rounded rectangles and
 * twenty of them down a screen read as a list of boxes; a row of small punched
 * dots in one corner turns each one into an object that was cut out and placed
 * — the same trick a paper tag or a pressed metal plate uses.
 *
 * Two corners, not four. On all four the dots become a border and stop being a
 * detail; on the top-left and bottom-right they read as the two points where
 * something was fixed down, and the diagonal keeps the eye moving across the
 * tile rather than around its edge.
 */
@Composable
fun TileCard(
    modifier: Modifier = Modifier,
    fill: Color = CreamCard,
    /** Dots take this colour at low alpha. Ink on pale tiles, white on dark. */
    dots: Color = Ink,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(Paper.CardRadius)
    val clickable = if (onClick != null) {
        Modifier.clickableNoRipple(remember { MutableInteractionSource() }) { onClick() }
    } else {
        Modifier
    }
    Column(
        modifier
            // The tile sits on the page rather than being printed into it, so
            // it casts something.
            .drawBehind {
                val d = 4.dp.toPx()
                drawRoundRect(
                    color = Ink.copy(alpha = 0.18f),
                    topLeft = Offset(d, d),
                    size = size,
                    cornerRadius = CornerRadius(Paper.CardRadius.toPx(), Paper.CardRadius.toPx()),
                )
            }
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(lerp(fill, Color.White, 0.22f), fill, lerp(fill, Color.Black, 0.05f)),
                ),
            )
            .border(Paper.Outline, Ink, shape)
            .then(clickable)
            .drawBehind {
                comicPrint(dots)
                tilePunches(dots)
            }
            .padding(14.dp),
        content = content,
    )
}

/**
 * Three dots stepping in from each of two corners.
 *
 * Sized off the tile rather than fixed, so a small tile gets small marks
 * instead of the same dots crowding a smaller card.
 */
/** Three dots stepping in from each of two corners. Shared so streak and hub tiles match. */
/** Quiet comic print inside a tile: three rays and a handful of dots. */
fun DrawScope.comicPrint(colour: Color) {
    val origin = Offset(size.width * 0.88f, size.height * 0.08f)
    val len = size.maxDimension * 0.55f
    listOf(-0.55f, -0.18f, 0.22f).forEach { a ->
        drawLine(
            color = colour.copy(alpha = 0.07f),
            start = origin,
            end = Offset(origin.x + cos(a) * len, origin.y + sin(a) * len),
            strokeWidth = size.minDimension * 0.12f,
        )
    }
    val gap = size.minDimension * 0.09f
    val r = size.minDimension * 0.012f
    var y = size.height * 0.62f
    var row = 0
    while (y < size.height - gap) {
        var x = if (row % 2 == 0) gap else gap * 1.5f
        while (x < size.width * 0.45f) {
            drawCircle(colour.copy(alpha = 0.10f), r, Offset(x, y))
            x += gap
        }
        y += gap
        row++
    }
}

fun DrawScope.tilePunches(colour: Color) {
    val r = size.minDimension * 0.017f
    val gap = r * 3.4f
    val inset = size.minDimension * 0.075f
    repeat(3) { i ->
        val step = i * gap
        val fade = 0.34f - i * 0.09f
        // Top-left, running down and right along the diagonal.
        drawCircle(
            color = colour.copy(alpha = fade),
            radius = r,
            center = Offset(inset + step, inset + step * 0.35f),
        )
        // Bottom-right, mirrored.
        drawCircle(
            color = colour.copy(alpha = fade),
            radius = r,
            center = Offset(size.width - inset - step, size.height - inset - step * 0.35f),
        )
    }
}

/** A label above a number, the shape every tile in the grid repeats. */
@Composable
fun TileStat(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    fill: Color = CreamCard,
    art: TileArt? = null,
    artFill: Color = Ink,
    onClick: (() -> Unit)? = null,
) {
    TileCard(modifier.fillMaxWidth(), fill = fill, onClick = onClick) {
        if (art != null) {
            TileObject(art = art, fill = artFill, size = 30.dp)
            Box(Modifier.padding(top = 8.dp))
        }
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = InkMid,
        )
        Text(
            value,
            style = MaterialTheme.typography.headlineSmall,
            color = Ink,
            maxLines = 1,
        )
    }
}
