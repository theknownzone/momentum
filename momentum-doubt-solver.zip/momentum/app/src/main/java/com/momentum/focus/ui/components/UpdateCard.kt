package com.momentum.focus.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.geometry.Size
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.UpdateNotice
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.roundToInt

/**
 * Update card with a real install button and a real progress bar.
 *
 * The previous version was one big tappable strip with no button and no
 * feedback, so a tap anywhere started a silent download that looked like
 * nothing had happened. Here the button is the only tap target, the bar fills
 * with measured bytes, and the sound fires when the installer opens.
 */
@Composable
fun UpdateCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val haptics = rememberHaptics()

    var release by remember { mutableStateOf(Updater.cached) }
    // Read from the Updater, not from local state — see the note there. A tab
    // switch used to lose the download that was still running.
    val progress = Updater.progress

    LaunchedEffect(Unit) {
        val found = Updater.check(context) ?: Updater.cached
        release = found
        if (found != null) UpdateNotice.show(context, found.version)
    }

    val found = release
    AnimatedVisibility(
        visible = found != null,
        enter = fadeIn() + slideInVertically { -it },
        modifier = modifier,
    ) {
        if (found == null) return@AnimatedVisibility
        val downloading = progress >= 0f
        val animated by animateFloatAsState(
            targetValue = progress.coerceAtLeast(0f),
            animationSpec = Motion.settle(),
            label = "dl",
        )

        // A comic panel: hard black frame, a thick offset shadow with no
        // softness in it, and a burst of rays behind the whole thing. This is
        // the one card in the app that appears uninvited and asks for a tap,
        // and everything else here is quiet paper — so it gets the loudest
        // treatment the house style has, and no other card is allowed it.
        Box(
            Modifier
                .fillMaxWidth()
                .drawBehind {
                    // Speed rays from the top-left corner, the way a comic
                    // panel points at the thing that just happened.
                    val origin = Offset(size.width * 0.12f, size.height * 0.16f)
                    repeat(14) { i ->
                        val a = (i / 14f) * 2f * PI.toFloat()
                        val len = size.maxDimension
                        rotate(degrees = 0f) {
                            drawLine(
                                color = Butter.fill.copy(alpha = 0.16f),
                                start = origin,
                                end = Offset(
                                    origin.x + cos(a) * len,
                                    origin.y + sin(a) * len,
                                ),
                                strokeWidth = size.height * 0.055f,
                            )
                        }
                    }
                    // The panel's cast shadow: offset, flat, black. A comic
                    // frame never has a soft edge.
                    val d = 7.dp.toPx()
                    drawRoundRect(
                        color = Ink,
                        topLeft = Offset(d, d),
                        size = size,
                        cornerRadius = CornerRadius(
                            Paper.CardRadius.toPx(),
                            Paper.CardRadius.toPx(),
                        ),
                    )
                },
        ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(
                    Brush.verticalGradient(
                        listOf(
                            lerp(Butter.fill, Color.White, 0.30f),
                            Butter.fill,
                            lerp(Butter.fill, Color.Black, 0.06f),
                        ),
                    ),
                )
                .border(3.5.dp, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(16.dp)
        ) {
            Text(
                "UPDATE READY",
                style = MaterialTheme.typography.labelSmall,
                color = Butter.on.copy(alpha = 0.75f),
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Version ${found.version}",
                style = MaterialTheme.typography.headlineSmall,
                color = Butter.on,
            )
            Text(
                "Install ke baad list khulegi.",
                style = MaterialTheme.typography.bodyMedium,
                color = Butter.on.copy(alpha = 0.75f),
            )

            if (downloading) {
                Spacer(Modifier.height(12.dp))
                // A web spun across the bar as it fills. The strands are
                // drawn from the leading edge back into the filled part, so
                // the thing making progress looks like it is building the bar
                // rather than a rectangle getting wider.
                val web = rememberInfiniteTransition(label = "web")
                val crawl = web.animateFloat(
                    initialValue = 0f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing)),
                    label = "crawl",
                )
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(18.dp)
                        .clip(RoundedCornerShape(50))
                        .background(CreamCard)
                        .border(2.5.dp, Ink, RoundedCornerShape(50))
                        .drawBehind {
                            val w = size.width * animated
                            if (w <= 1f) return@drawBehind
                            drawRoundRect(
                                brush = Brush.horizontalGradient(
                                    listOf(
                                        Tang.fill,
                                        Mint.fill,
                                        lerp(Mint.fill, Color.White, 0.30f),
                                    ),
                                    startX = 0f,
                                    endX = w,
                                ),
                                size = Size(w, size.height),
                                cornerRadius = CornerRadius(size.height, size.height),
                            )
                            // Strands. Each one leans back from the head at its
                            // own angle and slides as the crawl advances, which
                            // is what gives the fill a direction.
                            val head = w
                            repeat(9) { i ->
                                val off = ((i / 9f) + crawl.value) % 1f
                                val x = head - off * size.height * 3.2f
                                if (x < 0f) return@repeat
                                val lean = size.height * 0.55f
                                drawLine(
                                    color = Ink.copy(alpha = 0.22f),
                                    start = Offset(x, 0f),
                                    end = Offset(x - lean, size.height),
                                    strokeWidth = 1.6f,
                                )
                            }
                            // A bright leading edge, like the thread being
                            // pulled.
                            drawLine(
                                color = Color.White.copy(alpha = 0.85f),
                                start = Offset(head - 1.5f, 0f),
                                end = Offset(head - 1.5f, size.height),
                                strokeWidth = 3f,
                            )
                        },
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    if (animated >= 1f) "Opening installer…"
                    else "${(animated * 100).roundToInt()}%",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Butter.on,
                )
            } else {
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier
                        .clip(RoundedCornerShape(Paper.ChipRadius))
                        .background(Mint.fill)
                        .border(Paper.Outline, Ink, RoundedCornerShape(Paper.ChipRadius))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.confirm()
                            // Hands off to the browser. There is no progress to
                            // show any more because the download is no longer
                            // ours — the browser owns it, and it reports its own.
                            Updater.openDownload(context, found)
                            UpdateNotice.clear(context)
                            Sfx.play(Sound.SUCCESS)
                        }
                        .padding(horizontal = 22.dp, vertical = 11.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "Download update",
                        style = MaterialTheme.typography.titleMedium,
                        color = Mint.on,
                    )
                }
            }
        }
        }
    }
}
