package com.momentum.focus.ui.i18n

/**
 * "General" is deliberately absent. It is the bucket a subject-less session is
 * stored under, not a label — translating the displayed copy while the saved
 * sessions still say "General" would split one bucket into two that never
 * match.
 */
interface StatsStrings {
    val dashboard: String
    val whereItsGoing: String
    val level: String
    fun xpProgress(xp: Int): String
    val focused: String
    fun sessions(count: Int): String

    val whereItGoes: String
    val blocked: String

    val bySubject: String
    val last30Days: String
    val untouched: String

    val yourPattern: String
    fun regretLine(reason: String, percent: Int): String
    fun basedOnAnswers(count: Int): String
    val pattern: String
    fun urgeHour(hour: Int): String

    val todaysOrder: String
    val whatOpenedWhen: String
    val saved: String

    val todaysScreenTime: String
    val todaySoFar: String
    val overYourPace: String
    val reclaimedSoFar: String
    val grantUsageAccess: String
    fun dayJustStarted(hours: Int, minutes: Int): String
    fun normallyByNow(normHours: Int, normMins: Int, todayHours: Int, todayMins: Int): String

    val last7Days: String
    fun averageLine(hours: Int, minutes: Int): String
    fun underBaseline(hours: Int, minutes: Int): String
    fun overBaseline(hours: Int, minutes: Int): String
    val readingYourWeek: String

    val banked: String
    val bestDay: String
    val thisWeek: String
    val today: String
    val focusTime: String
    val firstSessionHint: String

    val goal: String
    val streak: String
    val goalCaps: String
    val daily: String
    val emptyYet: String
    val goalDone: String
    val studyTodayStart: String
    fun daysMore(days: Int): String
}

object StatsHi : StatsStrings {
    override val dashboard = "DASHBOARD"
    override val whereItsGoing = "Waqt ja kahan raha hai"
    override val level = "LEVEL"
    override fun xpProgress(xp: Int) = "$xp/600 xp"
    override val focused = "PADHA"
    override fun sessions(count: Int) = "$count sessions"

    override val whereItGoes = "KAHAN JATA HAI"
    override val blocked = "band"

    override val bySubject = "SUBJECT KE HISAAB SE"
    override val last30Days = "Pichhle 30 din"
    override val untouched = "chhua hi nahi"

    override val yourPattern = "TUMHARA PATTERN"
    override fun regretLine(reason: String, percent: Int) =
        "When you spend out of \"$reason\", you regret it $percent% of the time."
    override fun basedOnAnswers(count: Int) =
        "Based on $count answers you gave after the fact."
    override val pattern = "PATTERN"
    override fun urgeHour(hour: Int) =
        "Most urges hit around $hour:00. Put something there."

    override val todaysOrder = "AAJ KA ORDER"
    override val whatOpenedWhen = "Kab kya khola"
    override val saved = "bachaya"

    override val todaysScreenTime = "AAJ KA SCREEN TIME"
    override val todaySoFar = "AAJ AB TAK"
    override val overYourPace = "APNI RAFTAAR SE ZYADA"
    override val reclaimedSoFar = "AB TAK WAPAS LIYA"
    override val grantUsageAccess = "Baseline banane ke liye usage access do."
    override fun dayJustStarted(hours: Int, minutes: Int) =
        "Din abhi shuru hua hai. Baseline %dh %02dm roz ka.".format(hours, minutes)
    override fun normallyByNow(
        normHours: Int,
        normMins: Int,
        todayHours: Int,
        todayMins: Int,
    ) = "Is waqt tak normally %dh %02dm. Aaj: %dh %02dm."
        .format(normHours, normMins, todayHours, todayMins)

    override val last7Days = "PICHHLE 7 DIN"
    override fun averageLine(hours: Int, minutes: Int) =
        "Average %dh %02dm · red line is your baseline".format(hours, minutes)
    override fun underBaseline(hours: Int, minutes: Int) =
        " · %dh %02dm under baseline".format(hours, minutes)
    override fun overBaseline(hours: Int, minutes: Int) =
        " · %dh %02dm over baseline".format(hours, minutes)
    override val readingYourWeek = "Tumhara hafta padh raha hoon…"

    override val banked = "JAMA"
    override val thisWeek = "IS HAFTE"
    override val today = "AAJ"
    override val focusTime = "Padhai ka waqt"
    override val firstSessionHint = "Pehla session karo,\nyahan line dikhegi."

    override val goal = "target"
    override val streak = "STREAK"
    override val goalCaps = "TARGET"
    override val daily = "ROZ"
    override val emptyYet = "Abhi khaali"
    override val goalDone = "Ho gaya. Ab bada rakho."
    override val studyTodayStart = "Aaj padho, streak shuru."
    override fun daysMore(days: Int) = "$days din aur."
    override val bestDay = "SABSE ACHHA DIN"
}

object StatsEn : StatsStrings {
    override val dashboard = "DASHBOARD"
    override val whereItsGoing = "Where it's going"
    override val level = "LEVEL"
    override fun xpProgress(xp: Int) = "$xp/600 xp"
    override val focused = "FOCUSED"
    override fun sessions(count: Int) = if (count == 1) "1 session" else "$count sessions"

    override val whereItGoes = "WHERE IT GOES"
    override val blocked = "blocked"

    override val bySubject = "BY SUBJECT"
    override val last30Days = "Last 30 days"
    override val untouched = "untouched"

    override val yourPattern = "YOUR PATTERN"
    override fun regretLine(reason: String, percent: Int) =
        "When you spend out of \"$reason\", you regret it $percent% of the time."
    override fun basedOnAnswers(count: Int) =
        if (count == 1) "Based on 1 answer you gave after the fact."
        else "Based on $count answers you gave after the fact."
    override val pattern = "PATTERN"
    override fun urgeHour(hour: Int) =
        "Most urges hit around $hour:00. Put something there."

    override val todaysOrder = "TODAY'S ORDER"
    override val whatOpenedWhen = "What you opened, and when"
    override val saved = "saved"

    override val todaysScreenTime = "TODAY'S SCREEN TIME"
    override val todaySoFar = "TODAY SO FAR"
    override val overYourPace = "OVER YOUR PACE"
    override val reclaimedSoFar = "RECLAIMED SO FAR"
    override val grantUsageAccess = "Grant usage access to set a baseline."
    override fun dayJustStarted(hours: Int, minutes: Int) =
        "The day has only just started. Your baseline is %dh %02dm a day."
            .format(hours, minutes)
    override fun normallyByNow(
        normHours: Int,
        normMins: Int,
        todayHours: Int,
        todayMins: Int,
    ) = "By now you're normally at %dh %02dm. Today: %dh %02dm."
        .format(normHours, normMins, todayHours, todayMins)

    override val last7Days = "LAST 7 DAYS"
    override fun averageLine(hours: Int, minutes: Int) =
        "Average %dh %02dm · red line is your baseline".format(hours, minutes)
    override fun underBaseline(hours: Int, minutes: Int) =
        " · %dh %02dm under baseline".format(hours, minutes)
    override fun overBaseline(hours: Int, minutes: Int) =
        " · %dh %02dm over baseline".format(hours, minutes)
    override val readingYourWeek = "Reading your week…"

    override val banked = "BANKED"
    override val thisWeek = "THIS WEEK"
    override val today = "TODAY"
    override val focusTime = "Focus time"
    override val firstSessionHint = "Finish one session\nand the line starts here."

    override val goal = "goal"
    override val streak = "STREAK"
    override val goalCaps = "GOAL"
    override val daily = "DAILY"
    override val emptyYet = "Nothing yet"
    override val goalDone = "Done. Set a longer one."
    override val studyTodayStart = "Study today and the streak starts."
    override fun daysMore(days: Int) = if (days == 1) "1 day to go." else "$days days to go."
    override val bestDay = "BEST DAY"
}
