package com.momentum.focus.ui.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.momentum.focus.ai.Ai
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * Hands the current MyAi thread to the share sheet as a text file.
 *
 * A file rather than EXTRA_TEXT alone: a long thread pasted into an intent
 * extra gets silently truncated by some apps, and a chat that arrives missing
 * its last half is worse than one that did not send.
 *
 * "History" is the current thread and nothing older, because there is nothing
 * older to have. The thread lives in memory and is cleared when the next focus
 * session starts — deliberately, so MyAi never becomes a log to scroll. Export
 * is the way to keep a conversation that was worth keeping; it does not turn
 * the app into something that remembers every one of them.
 */
object ExportChat {

    private val STAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

    fun share(context: Context, thread: List<Ai.Turn>, mode: String, you: String, ai: String) {
        if (thread.isEmpty()) return
        val text = buildString {
            appendLine("Momentum · MyAi · $mode")
            appendLine(LocalDateTime.now().format(STAMP))
            appendLine()
            thread.forEach { turn ->
                appendLine(if (turn.fromUser) "$you:" else "$ai:")
                appendLine(turn.text)
                // Named, not embedded. The page itself is not in the file; the
                // line is there so a transcript that reads oddly on its own
                // says why.
                if (turn.imageB64 != null) appendLine("[page attached]")
                appendLine()
            }
        }

        runCatching {
            val file = File(context.cacheDir, "momentum-myai.txt")
            file.writeText(text)
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file,
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, text.take(2000))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, null))
        }
    }
}
