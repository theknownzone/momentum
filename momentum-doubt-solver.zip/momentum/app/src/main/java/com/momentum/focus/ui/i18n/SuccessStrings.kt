package com.momentum.focus.ui.i18n

/**
 * The success card's text.
 *
 * No congratulation strings in here, on purpose. The card reports four
 * measurements and names the weakest one; a line telling someone they are doing
 * great is the app talking about itself rather than about them.
 */
interface SuccessStrings {
    val label: String
    val outOf: String

    /**
     * One word for where the number falls.
     *
     * A score on its own is a number; a number with a word beside it is a
     * reading. Four bands, none of them praise — "Chal raha hai" is a
     * description, "Shaandaar!" would be the app talking about itself.
     */
    fun verdict(score: Int): String
    val consistency: String
    val finishing: String
    val volume: String
    val balance: String

    /** What to do about whichever part came out lowest. */
    val nextConsistency: String
    val nextFinishing: String
    val nextVolume: String
    val nextBalance: String

    /** The streak ladder. */
    val streakLabel: String
    val streakDays: String
    val rungDays: String
    fun toNextRung(left: Int, rung: Int): String

    val emptyTitle: String
    val emptyBody: String

    /** Share poster. */
    val share: String
    val sharing: String
    val newArt: String
}

object SuccessHi : SuccessStrings {
    override val label = "SCORE · 30 DIN"
    override val outOf = "/ 100"
    override fun verdict(score: Int) = when {
        score >= 80 -> "Sab line pe"
        score >= 55 -> "Chal raha hai"
        score >= 30 -> "Aadha raasta"
        else -> "Patla"
    }
    override val consistency = "Lagataar"
    override val finishing = "Poora kiya"
    override val volume = "Kitna padha"
    override val balance = "Subject cover"
    override val nextConsistency = "Streak toot rahi hai. Kal 25 min, chhota rakho, par karo."
    override val nextFinishing = "Session beech mein chhod dete ho. 90 nahi, 25 min chuno."
    override val nextVolume = "Minute kam hain. Roz ek 50 min ka block rakho."
    override val nextBalance = "Ek subject bilkul nahi chhua. Kal usi se shuru karo."
    override val streakLabel = "STREAK"
    override val streakDays = "din"
    override val rungDays = "din"
    override fun toNextRung(left: Int, rung: Int) =
        if (left == 1) "1 din aur, phir $rung ka nishaan" else "$left din aur, phir $rung ka nishaan"
    override val emptyTitle = "Abhi koi number nahi"
    override val emptyBody =
        "Ek session poora karo, phir yahan asli score dikhega. Andaaza nahi lagayenge."
    override val share = "Poster share karo"
    override val sharing = "Poster ban raha hai"
    override val newArt = "Naya background"
}

object SuccessEn : SuccessStrings {
    override val label = "SCORE · 30 DAYS"
    override val outOf = "/ 100"
    override fun verdict(score: Int) = when {
        score >= 80 -> "All on track"
        score >= 55 -> "Holding"
        score >= 30 -> "Halfway"
        else -> "Thin"
    }
    override val consistency = "Consistency"
    override val finishing = "Finishing"
    override val volume = "Volume"
    override val balance = "Coverage"
    override val nextConsistency = "The streak keeps breaking. Tomorrow, 25 minutes. Small, but done."
    override val nextFinishing = "Sessions get abandoned. Pick 25 minutes, not 90."
    override val nextVolume = "The minutes are thin. One 50 minute block a day."
    override val nextBalance = "A subject has gone untouched. Start with it tomorrow."
    override val streakLabel = "STREAK"
    override val streakDays = "days"
    override val rungDays = "days"
    override fun toNextRung(left: Int, rung: Int) =
        if (left == 1) "One more day to the $rung mark" else "$left more days to the $rung mark"
    override val emptyTitle = "No numbers yet"
    override val emptyBody =
        "Finish one session and the real score appears here. Nothing gets estimated."
    override val share = "Share poster"
    override val sharing = "Making the poster"
    override val newArt = "New background"
}
