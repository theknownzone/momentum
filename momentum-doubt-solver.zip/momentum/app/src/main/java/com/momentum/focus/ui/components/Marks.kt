package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.LocalSkin
import com.momentum.focus.ui.theme.Motion
import com.momentum.focus.ui.theme.Paper

/**
 * The border glow, as a modifier anyone can wear.
 *
 * Lifted out of the composer so the same effect can mark anything that is
 * working or worth looking at, instead of living in one file. It is a bright
 * line travelling along the outline — not a halo bloomed outside the shape,
 * which is a different effect and the one that kept getting built here by
 * mistake. Outside the shape it overlapped whatever sat next to it; on the
 * outline it belongs to the thing it is describing.
 *
 * [active] false leaves a plain Ink outline, so a caller can hand this the same
 * modifier chain in both states and let it settle between them.
 */
fun Modifier.glowEdge(
    active: Boolean,
    shape: Shape,
    resting: Dp = Paper.Outline,
    lit: Dp = 2.5.dp,
): Modifier = composed {
    val accent = LocalSkin.current.accent
    val transition = rememberInfiniteTransition(label = "edge")
    val travel by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing)),
        label = "travel",
    )
    val heat by animateFloatAsState(
        targetValue = if (active) 1f else 0f,
        animationSpec = Motion.settle(),
        label = "heat",
    )
    val brush: Brush = if (heat <= 0.01f) {
        SolidColor(Ink)
    } else {
        val span = 900f
        val head = travel * span * 2f - span * 0.5f
        Brush.linearGradient(
            colors = listOf(
                Ink,
                accent.copy(alpha = heat),
                Color.White.copy(alpha = 0.85f * heat),
                accent.copy(alpha = heat),
                Ink,
            ),
            start = Offset(head, 0f),
            end = Offset(head + span * 0.55f, span * 0.30f),
        )
    }
    this.border(if (heat > 0.01f) lit else resting, brush, shape)
}

/**
 * A heading with a marker swipe struck through it.
 *
 * The stroke is drawn, not a rectangle: it thickens through the middle, thins
 * at both ends and overshoots the last letter, which is what a real highlighter
 * does and what a flat bar never looks like. It sits *behind* the word at low
 * alpha rather than under it, so the word stays the loudest thing.
 *
 * It sweeps in from the left on first composition. Once, on arrival — a mark
 * that keeps redrawing itself stops being a mark and becomes a loading bar.
 */
@Composable
fun MarkerTitle(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Ink,
    marker: Color = LocalSkin.current.accent,
    style: TextStyle = MaterialTheme.typography.displaySmall,
) {
    // An Animatable driven from an effect, not animateFloatAsState. That helper
    // starts *at* its target on first composition, so a target of 1f meant the
    // stroke was simply already there — it compiled, it looked fine, and the
    // sweep it exists for never happened once.
    val swipe = remember { Animatable(0f) }
    LaunchedEffect(text) {
        swipe.snapTo(0f)
        swipe.animateTo(1f, tween(620, easing = LinearEasing))
    }
    Box(
        modifier
            .wrapContentSize()
            .drawBehind {
                if (swipe.value <= 0.01f) return@drawBehind
                val h = size.height
                val w = size.width * swipe.value
                // Centre of the stroke sits low, across the lower third of the
                // letters, the way a marker lands when someone is going fast.
                val midY = h * 0.68f
                val thick = h * 0.34f
                val path = Path().apply {
                    moveTo(0f, midY - thick * 0.30f)
                    // Bulges downward in the middle: one pass of a wide nib,
                    // pressed harder halfway across.
                    quadraticBezierTo(
                        w * 0.5f, midY - thick * 0.62f,
                        w, midY - thick * 0.18f,
                    )
                    lineTo(w, midY + thick * 0.44f)
                    quadraticBezierTo(
                        w * 0.5f, midY + thick * 0.70f,
                        0f, midY + thick * 0.36f,
                    )
                    close()
                }
                drawPath(path, color = marker.copy(alpha = 0.42f))
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = style.copy(fontWeight = FontWeight.Bold), color = color)
    }
}

/**
 * A small hand-drawn mark, for the corners of things.
 *
 * Four shapes, chosen by [seed] so a caller can scatter them without picking
 * each one. Cheap enough to sit on a scrolling screen: two or three strokes.
 */
@Composable
fun Doodle(
    seed: Int,
    modifier: Modifier = Modifier,
    color: Color = LocalSkin.current.accent,
) {
    Box(
        modifier.drawBehind {
            val w = size.width
            val h = size.height
            val stroke = androidx.compose.ui.graphics.drawscope.Stroke(width = w * 0.10f)
            when (seed % 4) {
                // A pair of speed lines.
                0 -> {
                    drawLine(color, Offset(0f, h * 0.35f), Offset(w * 0.8f, h * 0.15f), w * 0.10f)
                    drawLine(color, Offset(0f, h * 0.70f), Offset(w * 0.6f, h * 0.55f), w * 0.10f)
                }
                // A curl.
                1 -> drawPath(
                    Path().apply {
                        moveTo(0f, h)
                        cubicTo(w * 0.1f, h * 0.2f, w * 0.9f, h * 0.9f, w, 0f)
                    },
                    color, style = stroke,
                )
                // A spark.
                2 -> {
                    drawLine(color, Offset(w * 0.5f, 0f), Offset(w * 0.5f, h * 0.35f), w * 0.10f)
                    drawLine(color, Offset(0f, h * 0.5f), Offset(w * 0.32f, h * 0.5f), w * 0.10f)
                    drawLine(color, Offset(w * 0.68f, h * 0.5f), Offset(w, h * 0.5f), w * 0.10f)
                }
                // A tick.
                else -> drawPath(
                    Path().apply {
                        moveTo(0f, h * 0.55f)
                        lineTo(w * 0.38f, h)
                        lineTo(w, 0f)
                    },
                    color, style = stroke,
                )
            }
        },
    )
}
