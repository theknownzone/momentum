package com.momentum.focus.ai

import com.momentum.focus.data.AppData
import java.time.LocalDate

/** Study is free; Friend and Guru are what the paid tier buys. */
enum class MyAiMode { Study, Friend, Guru }

data class StudyPulse(
    val headline: String,
    val lines: List<String>,
    val next: String,
)

/**
 * MyAi: the one place in this app where a person types at a model.
 *
 * The thing this feature can go wrong as is not a wrong answer. It is becoming
 * what you open when the page in front of you got difficult — the exact move
 * the rest of the app exists to interrupt. What stands against that:
 *
 *  - A cap per focus session, refilled only when the next one starts. Free is
 *    [FREE_SESSION], which is a real limit; paid is [PER_SESSION], which is
 *    not one and is not pretending to be.
 *  - The clock does not stop while MyAi is open, and the countdown sits at the
 *    top of the screen so that is visible rather than merely true.
 *  - The prompt forbids the model from offering to continue. A model that ends
 *    on "want me to explain more?" spends the next question for them.
 */
object Doubt {

    /** Paid ceiling. High enough not to be felt, present so nothing runs away. */
    const val PER_SESSION = 1000

    /** The free cap, and the one that actually bites. */
    const val FREE_SESSION = 20

    fun cap(premium: Boolean) = if (premium) PER_SESSION else FREE_SESSION

    /**
     * A doubt is one question. Past this it is an essay prompt, and the answer
     * to an essay prompt is not something you read and go back to work.
     */
    const val MAX_CHARS = 300

    /**
     * How many past turns travel with a follow-up. Three exchanges is as far
     * back as a line of questioning about one step ever reaches, and every turn
     * beyond that is paid for on every request after it.
     */
    private const val MEMORY = 6

    /**
     * Defaults to the free cap, not the paid one.
     *
     * It defaulted to premium, so any call that forgot to pass the flag handed
     * out a thousand questions. A gate whose default is "unlocked" is not a
     * gate; if a caller is ever added that does not know, the safe answer is
     * the small number.
     */
    fun left(used: Int, premium: Boolean = false): Int =
        (cap(premium) - used).coerceAtLeast(0)

    /**
     * The shortest time an answer of this length could honestly have been read.
     *
     * Eighteen characters a second is fast — around 200 words a minute — so
     * anything under this is not "read quickly", it is not read. Floored at
     * three seconds because a one-line reply really can be taken in at a
     * glance, and capped at forty because nobody sits through a whole minute
     * before their next thought.
     */
    fun readingSeconds(chars: Int): Int = (chars / 18).coerceIn(3, 40)

    /**
     * The turns worth sending.
     *
     * A question that was stopped or that failed stays in the thread on screen
     * — it is still something the student asked — but it has no answer under
     * it, so sending it would put two user messages in a row and invite the
     * model to answer the older one. Only completed exchanges travel, plus the
     * question being asked now.
     */
    fun context(thread: List<Ai.Turn>): List<Ai.Turn> {
        val kept = thread.filterIndexed { i, turn ->
            val answered = !turn.fromUser || thread.getOrNull(i + 1)?.fromUser == false
            answered || i == thread.lastIndex
        }.takeLast(MEMORY)
        // The picture rides along with the question it belongs to and is
        // dropped from everything older. Kept on history turns, a single
        // attached page was re-uploaded in full on every follow-up for the rest
        // of the session, and — because any image in the request routes the
        // whole thing to the vision model — every later text-only question was
        // answered by the vision model too.
        return kept.mapIndexed { i, turn ->
            val last = i == kept.lastIndex
            if (last) turn else turn.copy(imageB64 = null, more = emptyList())
        }
    }

    /**
     * Hinglish or English, from the language the app is already running in.
     *
     * Read as a raw code rather than through `Lang`, so this package keeps
     * pointing at `data` only and never up into the UI.
     */
    private fun replyLanguage(data: AppData): String =
        if (data.lang == "en") {
            "Reply in plain English."
        } else {
            "Reply in Hinglish — Hindi in Latin script, with the English words " +
                "students actually use for technical terms. Not Devanagari."
        }

    fun pulse(data: AppData, phoneAvgMin: Int?): StudyPulse {
        val today = LocalDate.now().toEpochDay()
        val recent = data.sessions.filter { today - it.startedAtEpochDay <= 30 }
        val done = recent.filter { it.completed }
        val abandoned = recent.size - done.size
        val minutes = done.sumOf { it.minutes }
        val perSubject = data.subjects.associateWith { s ->
            done.filter { it.subject == s }.sumOf { it.minutes }
        }
        val weak = perSubject.minByOrNull { it.value }?.takeIf { data.subjects.isNotEmpty() }
        val lines = buildList {
            add("${data.streakDays} day streak · ${done.size} sessions in 30d · ${abandoned} left early")
            add("$minutes min studied in 30 days")
            if (phoneAvgMin != null) add("Phone wellbeing: ${phoneAvgMin} min/day average")
            weak?.let { add("Least touched: ${it.key} (${it.value} min)") }
            data.daysToExam?.let { add("${data.examName.ifBlank { "Exam" }} in $it days") }
        }
        val next = when {
            minutes == 0 -> "Start a 25 min session today. The card stays empty until you sit."
            phoneAvgMin != null && phoneAvgMin > minutes / 4 && minutes < 600 ->
                "Phone time is beating study time. One blocked hour tonight beats another doubt."
            weak != null && weak.value == 0 ->
                "Open ${weak.key} tomorrow for 25 min before anything else."
            abandoned > done.size && done.isNotEmpty() ->
                "You leave sessions more than you finish. Pick 25m, not 90m."
            else -> "Keep the same subject two days in a row before switching."
        }
        val headline = when {
            minutes == 0 -> "No study minutes on record yet"
            else -> "$minutes min in 30 days — here is the honest read"
        }
        return StudyPulse(headline, lines, next)
    }

    fun systemPrompt(data: AppData, mode: MyAiMode, facts: String): String {
        val exam = data.examName.ifBlank { "a competitive exam" }
        val subjects = data.subjects.joinToString().ifBlank { "school and exam subjects" }
        val voice = when (mode) {
            MyAiMode.Study -> """
                MODE: Study.
                You handle anything to do with preparing for this exam: doubts,
                concepts, formulas, what a topic covers, what the paper asks,
                what to revise first, how to attempt a section, what kind of
                questions come. All of that is your job. Practice questions are
                your job too — give two or three inline, and say the MOCK button
                sets a proper drill.
                Only pure chat is off-topic: films, gossip, someone's day.
                Hi / kaise ho → one line "Study mode. Sawal poochho." then stop.
                Steps then answer. Under 130 words. No jokes, no gali, no emoji.
            """.trimIndent()
            MyAiMode.Friend -> """
                MODE: Friend.
                You are their yaar and you are blunt with them the way a close
                friend is. Hinglish. Gali-galoch allowed, teasing allowed,
                non-study baat allowed — mood, din, bakchodi — AND study if they
                ask. Say the awkward thing a friend would say instead of the
                polite thing a bot would. Do not refuse a hello. Never say
                "this is only for study".
                Under 180 words. A 22-year-old roommate, not a bot.
            """.trimIndent()
            MyAiMode.Guru -> """
                MODE: Guru.
                Kadak teacher. Rules pehle, pyar baad mein kabhi nahi.
                Late / phone / 0 sessions → seedha daant, numbers se.
                Method, then one drill they must do on paper.
                No slang softness, no "bro", no "it's okay". Under 200 words.
            """.trimIndent()
        }
        val gate = when (mode) {
            MyAiMode.Study ->
                "- Only films, gossip and someone's day are off-topic. Anything " +
                    "about the exam or preparing for it is not — including asking " +
                    "for practice or guess questions, which you answer."
            MyAiMode.Friend ->
                "- Off-topic is allowed. Talk. If they pivot to a sum, solve it."
            MyAiMode.Guru ->
                "- Off-topic: one kadak line, push them back to the book or a drill."
        }
        return """
            You are MyAi inside Momentum. Exam: $exam. Subjects: $subjects.

            ${AppGuide.text(data)}

            $voice

            ${replyLanguage(data)}

            IMAGE RULE: if the user message includes a photo, that photo IS
            the problem. Read it. Solve the marked step. Never ask them to
            type the question you can already see. Follow-ups like
            "I don't get this step" refer to the same page until they attach
            a new one.

            THEIR REAL DATA (do not invent extra numbers):
            $facts

            If they ask how they are doing, use only those numbers.
            Every number is labelled. Quote it with its label — a longest-day
            figure is not a daily average.

            Rules:
            $gate
            - Never invent a formula, date, figure or citation.
            - Text only. You cannot draw, make images or open anything — never
              offer to. Point at the tab or the button instead.
            - Do not end with "want more?"
            - Never reuse a line from earlier in this conversation.
            - Plain text. No markdown headers, no tables.
        """.trimIndent()
    }

    /**
     * One answer. [thread] ends with the question being asked.
     *
     * Tokens are capped low on purpose. The length limit in the prompt is a
     * request; this is the part that holds when the model ignores it.
     */
    suspend fun answer(
        data: AppData,
        thread: List<Ai.Turn>,
        mode: MyAiMode = MyAiMode.Study,
        facts: String = "",
        onDelta: ((String) -> Unit)? = null,
    ): String = Ai.chat(
        system = systemPrompt(data, mode, facts),
        turns = context(thread),
        // These were held down because nothing streamed: every token in the
        // ceiling was a second of someone staring at dots, so the cap was
        // doing double duty as a length limit and as a wait limit. It streams
        // now, and reading starts on the first line — so the ceiling can go
        // back to being what it should be, a guard against a model that
        // ignores the word limit in the prompt. Raised, not removed.
        maxTokens = when (mode) { MyAiMode.Friend -> 420; MyAiMode.Guru -> 480; else -> 340 },
        temperature = when (mode) { MyAiMode.Friend -> 0.7; MyAiMode.Guru -> 0.25; else -> 0.3 },
        onDelta = onDelta,
    )
}

/**
 * Everything the sheet draws, in one object so the screen takes one parameter
 * rather than five loose ones.
 *
 * [left] is derived from the stored count rather than kept here as the truth,
 * because the count has to survive the process dying mid-session — otherwise
 * force-stopping the app would be a way to buy five more questions.
 */
data class DoubtState(
    val thread: List<Ai.Turn> = emptyList(),
    val busy: Boolean = false,
    /**
     * The answer so far, while it is still arriving.
     *
     * Empty when nothing is in flight. Held apart from [thread] because it is
     * not a turn yet: it has no final text, it must not be sent back as
     * context if the next question goes out, and it disappears the moment the
     * finished turn is appended.
     */
    val streaming: String = "",
    /** Last failure, shown under the question it belongs to. */
    val error: String? = null,
    val left: Int = Doubt.FREE_SESSION,
) {
    /**
     * True when the last thing in the thread is a question with nothing under
     * it — stopped, or failed. The sheet offers to re-ask rather than making
     * anyone type it again.
     */
    val awaitingRetry: Boolean
        get() = !busy && thread.lastOrNull()?.fromUser == true
}
