package com.momentum.focus.ai

import com.momentum.focus.data.AppData

/**
 * A doubt solver that is deliberately hard to hide in.
 *
 * The risk this feature carries is not a wrong answer. It is that a box you
 * can type into becomes the thing you open when the page in front of you got
 * difficult — the exact move the rest of the app exists to interrupt. Three
 * things are set against that, and none of them are decoration:
 *
 *  - [PER_SESSION] questions, counted against the running focus session and
 *    refilled only when the next one starts. Five is enough for the doubts a
 *    sitting actually produces and far too few to hold a conversation with.
 *  - The clock does not stop while the sheet is open. Time spent asking is
 *    time spent out of the session, and the sheet shows the countdown so that
 *    is visible rather than merely true.
 *  - The prompt forbids the model from offering to continue. A model that ends
 *    on "want me to explain more?" spends a student's remaining questions for
 *    them.
 *
 * What is left after that is the useful case: you are stuck on one step, the
 * answer takes twenty seconds, and the alternative was unlocking the phone.
 */
object Doubt {

    /** Questions per focus session. Refilled when a new session begins. */
    const val PER_SESSION = 5

    /**
     * A doubt is one question. Past this it is an essay prompt, and the answer
     * to an essay prompt is not something you read and go back to work.
     */
    const val MAX_CHARS = 300

    /**
     * How many past turns travel with a follow-up. Three exchanges is more
     * than [PER_SESSION] can produce in a single line of questioning, so this
     * never truncates anything a student would notice.
     */
    private const val MEMORY = 6

    fun left(used: Int): Int = (PER_SESSION - used).coerceAtLeast(0)

    /**
     * The turns worth sending.
     *
     * A question that was stopped or that failed stays in the thread on screen
     * — it is still something the student asked — but it has no answer under
     * it, so sending it would put two user messages in a row and invite the
     * model to answer the older one. Only completed exchanges travel, plus the
     * question being asked now.
     */
    fun context(thread: List<Ai.Turn>): List<Ai.Turn> {
        val kept = thread.filterIndexed { i, turn ->
            val answered = !turn.fromUser || thread.getOrNull(i + 1)?.fromUser == false
            answered || i == thread.lastIndex
        }
        return kept.takeLast(MEMORY)
    }

    /**
     * Hinglish or English, from the language the app is already running in.
     *
     * Read as a raw code rather than through `Lang`, so this package keeps
     * pointing at `data` only and never up into the UI.
     */
    private fun replyLanguage(data: AppData): String =
        if (data.lang == "en") {
            "Reply in plain English."
        } else {
            "Reply in Hinglish — Hindi in Latin script, with the English words " +
                "students actually use for technical terms. Not Devanagari."
        }

    fun systemPrompt(data: AppData): String {
        val exam = data.examName.ifBlank { "a competitive exam" }
        val subjects = data.subjects.joinToString().ifBlank { "school and exam subjects" }
        return """
            You are answering one doubt for a student who is in the middle of a
            timed study session in Momentum, an app that pays them screen time
            for focused study. They are preparing for $exam. Their subjects are
            $subjects. Their timer is running while they read your answer, and
            they get only ${PER_SESSION} questions per session.

            ${replyLanguage(data)}

            Rules:
            - Answer the question and stop. Under 120 words. No preamble, no
              restating the question, no summary at the end.
            - For anything with a method — a sum, a derivation, a grammar rule
              — give the steps in the shortest form that can be followed, then
              the result. Not a worked essay.
            - If the question is outside $subjects or unrelated to studying,
              say in one line that this is only for study doubts, and stop.
            - If you are not sure, say so in one line. Never invent a formula,
              a date, a figure or a citation. A wrong answer costs them more
              than no answer.
            - No praise, no encouragement, no motivational lines. This app does
              not cheer.
            - Never offer to continue. Do not end with a question, do not ask
              if they want more detail, do not suggest a follow-up. They have a
              fixed number of questions and a clock running, and an offer to
              keep talking spends both.
            - Plain text. No markdown headers, no bold, no tables.
        """.trimIndent()
    }

    /**
     * One answer. [thread] ends with the question being asked.
     *
     * Tokens are capped low on purpose. The length limit in the prompt is a
     * request; this is the part that holds when the model ignores it.
     */
    suspend fun answer(data: AppData, thread: List<Ai.Turn>): String = Ai.chat(
        system = systemPrompt(data),
        turns = context(thread),
        maxTokens = 420,
        temperature = 0.3,
    )
}

/**
 * Everything the sheet draws, in one object so the screen takes one parameter
 * rather than five loose ones.
 *
 * [left] is derived from the stored count rather than kept here as the truth,
 * because the count has to survive the process dying mid-session — otherwise
 * force-stopping the app would be a way to buy five more questions.
 */
data class DoubtState(
    val thread: List<Ai.Turn> = emptyList(),
    val busy: Boolean = false,
    /** Last failure, shown under the question it belongs to. */
    val error: String? = null,
    val left: Int = Doubt.PER_SESSION,
) {
    /**
     * True when the last thing in the thread is a question with nothing under
     * it — stopped, or failed. The sheet offers to re-ask rather than making
     * anyone type it again.
     */
    val awaitingRetry: Boolean
        get() = !busy && thread.lastOrNull()?.fromUser == true
}
