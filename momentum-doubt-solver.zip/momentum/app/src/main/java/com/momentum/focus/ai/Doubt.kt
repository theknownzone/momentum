package com.momentum.focus.ai

import com.momentum.focus.data.AppData
import java.time.LocalDate

/**
 * A doubt solver that is deliberately hard to hide in.
 *
 * The risk this feature carries is not a wrong answer. It is that a box you
 * can type into becomes the thing you open when the page in front of you got
 * difficult — the exact move the rest of the app exists to interrupt. Three
 * things are set against that, and none of them are decoration:
 *
 *  - [PER_SESSION] questions, counted against the running focus session and
 *    refilled only when the next one starts. Five is enough for the doubts a
 *    sitting actually produces and far too few to hold a conversation with.
 *  - The clock does not stop while the sheet is open. Time spent asking is
 *    time spent out of the session, and the sheet shows the countdown so that
 *    is visible rather than merely true.
 *  - The prompt forbids the model from offering to continue. A model that ends
 *    on "want me to explain more?" spends a student's remaining questions for
 *    them.
 *
 * What is left after that is the useful case: you are stuck on one step, the
 * answer takes twenty seconds, and the alternative was unlocking the phone.
 */
enum class MyAiMode { Study, Friend, Guru }

data class StudyPulse(
    val headline: String,
    val lines: List<String>,
    val next: String,
)

object Doubt {

    /** Questions per focus session. Refilled when a new session begins. */
    const val PER_SESSION = 1000

    /**
     * A doubt is one question. Past this it is an essay prompt, and the answer
     * to an essay prompt is not something you read and go back to work.
     */
    const val MAX_CHARS = 300

    /**
     * How many past turns travel with a follow-up. Three exchanges is more
     * than [PER_SESSION] can produce in a single line of questioning, so this
     * never truncates anything a student would notice.
     */
    private const val MEMORY = 6

    fun left(used: Int): Int = (PER_SESSION - used).coerceAtLeast(0)

    /**
     * The turns worth sending.
     *
     * A question that was stopped or that failed stays in the thread on screen
     * — it is still something the student asked — but it has no answer under
     * it, so sending it would put two user messages in a row and invite the
     * model to answer the older one. Only completed exchanges travel, plus the
     * question being asked now.
     */
    fun context(thread: List<Ai.Turn>): List<Ai.Turn> {
        val kept = thread.filterIndexed { i, turn ->
            val answered = !turn.fromUser || thread.getOrNull(i + 1)?.fromUser == false
            answered || i == thread.lastIndex
        }
        return kept.takeLast(MEMORY)
    }

    /**
     * Hinglish or English, from the language the app is already running in.
     *
     * Read as a raw code rather than through `Lang`, so this package keeps
     * pointing at `data` only and never up into the UI.
     */
    private fun replyLanguage(data: AppData): String =
        if (data.lang == "en") {
            "Reply in plain English."
        } else {
            "Reply in Hinglish — Hindi in Latin script, with the English words " +
                "students actually use for technical terms. Not Devanagari."
        }

    fun pulse(data: AppData, phoneAvgMin: Int?): StudyPulse {
        val today = LocalDate.now().toEpochDay()
        val recent = data.sessions.filter { today - it.startedAtEpochDay <= 30 }
        val done = recent.filter { it.completed }
        val abandoned = recent.size - done.size
        val minutes = done.sumOf { it.minutes }
        val perSubject = data.subjects.associateWith { s ->
            done.filter { it.subject == s }.sumOf { it.minutes }
        }
        val weak = perSubject.minByOrNull { it.value }?.takeIf { data.subjects.isNotEmpty() }
        val lines = buildList {
            add("${data.streakDays} day streak · ${done.size} sessions in 30d · ${abandoned} left early")
            add("$minutes min studied in 30 days")
            if (phoneAvgMin != null) add("Phone wellbeing: ${phoneAvgMin} min/day average")
            weak?.let { add("Least touched: ${it.key} (${it.value} min)") }
            data.daysToExam?.let { add("${data.examName.ifBlank { "Exam" }} in $it days") }
        }
        val next = when {
            minutes == 0 -> "Start a 25 min session today. The card stays empty until you sit."
            phoneAvgMin != null && phoneAvgMin > minutes / 4 && minutes < 600 ->
                "Phone time is beating study time. One blocked hour tonight beats another doubt."
            weak != null && weak.value == 0 ->
                "Open ${weak.key} tomorrow for 25 min before anything else."
            abandoned > done.size && done.isNotEmpty() ->
                "You leave sessions more than you finish. Pick 25m, not 90m."
            else -> "Keep the same subject two days in a row before switching."
        }
        val headline = when {
            minutes == 0 -> "No study minutes on record yet"
            else -> "$minutes min in 30 days — here is the honest read"
        }
        return StudyPulse(headline, lines, next)
    }

    fun systemPrompt(data: AppData, mode: MyAiMode, facts: String): String {
        val exam = data.examName.ifBlank { "a competitive exam" }
        val subjects = data.subjects.joinToString().ifBlank { "school and exam subjects" }
        val voice = when (mode) {
            MyAiMode.Study -> """
                MODE: Study. You are a strict tutor. Short steps, then the answer.
                Under 120 words. No jokes, no pep talk, no emoji.
            """.trimIndent()
            MyAiMode.Friend -> """
                MODE: Friend. You are a study-batch friend speaking Hinglish/English
                the way they already use. Warm, plain, still useful. Under 160 words.
                You can say "haan" or "dekho" — you cannot ramble.
            """.trimIndent()
            MyAiMode.Guru -> """
                MODE: Guru. You teach the idea, then the method, then one check
                they can do on paper. Under 220 words. Patient, not holy, not long.
            """.trimIndent()
        }
        return """
            You are MyAi inside Momentum. The student is preparing for $exam.
            Subjects: $subjects. Questions left this session: capped at $PER_SESSION.

            $voice

            ${replyLanguage(data)}

            THEIR REAL DATA (do not invent extra numbers):
            $facts

            When they ask how they are doing, or how to improve, use only those
            numbers. Point at the weakest subject or the phone-vs-study gap if
            it is in the data. If the data is thin, say it is thin.

            Rules:
            - Stay on study. If the question is not a study doubt and not about
              their progress, one line: this is only for study, then stop.
            - Never invent a formula, date, figure or citation.
            - Never offer to continue. Do not end with "want more?"
            - Plain text. No markdown headers, no bold, no tables.
        """.trimIndent()
    }

    /**
     * One answer. [thread] ends with the question being asked.
     *
     * Tokens are capped low on purpose. The length limit in the prompt is a
     * request; this is the part that holds when the model ignores it.
     */
    suspend fun answer(
        data: AppData,
        thread: List<Ai.Turn>,
        mode: MyAiMode = MyAiMode.Study,
        facts: String = "",
    ): String = Ai.chat(
        system = systemPrompt(data, mode, facts),
        turns = context(thread),
        maxTokens = if (mode == MyAiMode.Guru) 560 else 420,
        temperature = if (mode == MyAiMode.Friend) 0.5 else 0.3,
    )
}

/**
 * Everything the sheet draws, in one object so the screen takes one parameter
 * rather than five loose ones.
 *
 * [left] is derived from the stored count rather than kept here as the truth,
 * because the count has to survive the process dying mid-session — otherwise
 * force-stopping the app would be a way to buy five more questions.
 */
data class DoubtState(
    val thread: List<Ai.Turn> = emptyList(),
    val busy: Boolean = false,
    /** Last failure, shown under the question it belongs to. */
    val error: String? = null,
    val left: Int = Doubt.PER_SESSION,
) {
    /**
     * True when the last thing in the thread is a question with nothing under
     * it — stopped, or failed. The sheet offers to re-ask rather than making
     * anyone type it again.
     */
    val awaitingRetry: Boolean
        get() = !busy && thread.lastOrNull()?.fromUser == true
}
