package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Paper

/**
 * A section of settings that stays shut until it is asked for.
 *
 * The Profile screen's real problem was never which control sat in which
 * group — it was that every control was open at once, so a screen with four
 * concerns read as one undifferentiated scroll. Closing three of the four is
 * the only change that actually shortens it.
 *
 * The glass is faked the same way [FrostCard] fakes it: layered translucent
 * washes plus a bright sweep, never `Modifier.blur`. Blur is API 31+ and this
 * app ships to API 26, where it silently does nothing — a real blur here would
 * look like glass on a new phone and like flat grey on an old one.
 */
/**
 * The same frosted surface as [GlassSection] without the header or the drawer.
 *
 * Light glass, not dark: the references for this are panels sitting on a pale
 * background with a bright top edge and a faint colour bleed, which is what
 * cream paper can actually carry. A dark glass panel on cream would just be a
 * hole in the page.
 */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(Paper.CardRadius)
    Column(
        modifier
            .clip(shape)
            .background(CreamCard)
            .background(tint.copy(alpha = 0.22f))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.55f),
                        Color.White.copy(alpha = 0.04f),
                        Color.White.copy(alpha = 0.16f),
                    )
                )
            )
            // The bright top edge is what makes a flat panel read as glass —
            // it is the highlight where a real pane would catch the light.
            .drawWithContent {
                drawContent()
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.65f), Color.Transparent),
                        endY = 6.dp.toPx(),
                    ),
                    size = androidx.compose.ui.geometry.Size(size.width, 6.dp.toPx()),
                )
            }
            .border(Paper.Outline, Ink, shape),
        content = content,
    )
}

@Composable
fun GlassSection(
    title: String,
    note: String,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    initiallyOpen: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    var open by rememberSaveable(title) { mutableStateOf(initiallyOpen) }
    val turn by animateFloatAsState(
        targetValue = if (open) 90f else 0f,
        label = "chevron",
    )

    Column(
        modifier
            .fillMaxWidth()
            .padding(top = 14.dp)
            .clip(RoundedCornerShape(Paper.CardRadius))
            // Order matters and the first version had it backwards: the tint
            // went down at 14% and then three white washes at 70, 32 and 50
            // percent were painted on top of it, which wiped the colour out
            // almost completely. Every section looked identical no matter which
            // skin was chosen. Now the card starts opaque, takes the skin
            // colour at a strength you can actually see, and gets one soft
            // sheen on top instead of three.
            .background(CreamCard)
            .background(tint.copy(alpha = 0.30f))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.42f),
                        Color.White.copy(alpha = 0.06f),
                        Color.White.copy(alpha = 0.20f),
                    )
                )
            )
            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius)),
            // animateContentSize is gone on purpose.
            //
            // It tweens from whatever height the node had last time it was
            // measured. Changing the theme changes this section's own tint,
            // which remeasures the whole subtree — so the card animated open
            // and shut again every time someone picked a skin, with nothing
            // having opened. The expand still works; it just snaps, which is
            // what a disclosure row does everywhere else in the app.
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickableNoRipple(remember { MutableInteractionSource() }) { open = !open }
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                )
                Text(
                    note,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                )
            }
            // A caret rather than an icon font: one glyph, no asset, and it
            // reads as "there is more here" at any size.
            Text(
                "\u203A",
                style = MaterialTheme.typography.headlineSmall,
                color = InkMid,
                modifier = Modifier.rotate(turn),
            )
        }

        if (open) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 18.dp),
                content = content,
            )
        }
    }
}
