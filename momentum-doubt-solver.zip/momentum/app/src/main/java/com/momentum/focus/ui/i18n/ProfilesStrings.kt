package com.momentum.focus.ui.i18n

/**
 * The profiles screen.
 *
 * Every word on it was a literal, so with English selected the whole screen —
 * title, body, empty state, buttons — stayed in Hinglish. It is one of the
 * three screens the language switch most visibly failed on.
 */
interface ProfilesStrings {
    val kicker: String
    val title: String
    val blurb: String
    val pactLocked: String
    val saveHeader: String
    val namePlaceholder: String
    val save: String
    val emptyState: String
    val classHoursOff: String
    val active: String
    val apply: String
    val remove: String
    val done: String
}

object ProfilesHi : ProfilesStrings {
    override val kicker = "PROFILES"
    override val title = "Alag din, alag rules"
    override val blurb =
        "Abhi jo bhi on hai — blocked apps, caps, feeds, class hours — sab ek " +
            "naam ke neeche save ho jaata hai. Baad mein ek tap mein wapas."
    override val pactLocked =
        "Pact chal raha hai — profile switch nahi kar sakte. Naya save kar sakte ho."
    override val saveHeader = "ABHI KA SETUP SAVE KARO"
    override val namePlaceholder = "Raat, Weekend, Exam week…"
    override val save = "Save"
    override val emptyState =
        "Abhi koi profile nahi. Apps aur feeds set karke yahan naam de do — " +
            "jaise \"Raat\" jisme WhatsApp bhi band ho."
    override val classHoursOff = "Class hours off"
    override val active = "CHALU"
    override val apply = "Lagao"
    override val remove = "Hatao"
    override val done = "Done"
}

object ProfilesEn : ProfilesStrings {
    override val kicker = "PROFILES"
    override val title = "Different days, different rules"
    override val blurb =
        "Whatever is on right now — blocked apps, caps, feeds, class hours — " +
            "saves under one name. One tap brings it back later."
    override val pactLocked =
        "A pact is running — you cannot switch profiles. You can still save a new one."
    override val saveHeader = "SAVE THE CURRENT SETUP"
    override val namePlaceholder = "Night, Weekend, Exam week…"
    override val save = "Save"
    override val emptyState =
        "No profiles yet. Set your apps and feeds, then name it here — " +
            "like \"Night\", with WhatsApp blocked too."
    override val classHoursOff = "Class hours off"
    override val active = "ACTIVE"
    override val apply = "Apply"
    override val remove = "Remove"
    override val done = "Done"
}
