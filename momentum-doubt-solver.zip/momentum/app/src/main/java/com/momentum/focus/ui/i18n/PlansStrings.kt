package com.momentum.focus.ui.i18n

/**
 * The plans screen.
 *
 * Every line here used to be a literal inside PlansScreen.kt, which is why
 * someone with English selected in Settings — under a label that promises
 * "The whole app switches to this language" — still read a page of Hinglish.
 * Seventeen strings on the one screen that asks for money.
 *
 * Numbers are parameters, never text. The drill length and the session cap are
 * read from Mock.COUNT and Doubt.PER_SESSION at the call site, because this
 * project has already shipped a plans page advertising a five-question mock
 * after the drill was doubled to ten.
 */
interface PlansStrings {
    val kicker: String
    val title: String
    val subtitle: String

    val lifetime: String
    val yours: String
    val productName: String
    val bestValue: String

    /** The checklist on the paid card. */
    val allModes: String
    val allModesNote: String
    fun perSession(cap: Int, free: Int): String
    val perSessionLabel: String
    val photoPdf: String
    val mockTest: String
    fun mockNote(count: Int): String
    val crownMode: String
    val crownNote: String
    val allThemes: String
    val allThemesNote: String
    val posterBackdrop: String

    /** Header above the three tiles — depends on whether they are owned. */
    val ownedHeader: String
    val lockedHeader: String

    val peekModesTitle: String
    val peekModesBody: String
    val peekPageTitle: String
    val peekPageBody: String
    val peekThemesTitle: String
    val peekThemesBody: String

    val unlocked: String
    val unlockLifetime: String
    val haveKey: String
    val nothingBlocked: String

    val freeTitle: String
    val youreOnThis: String
    val freeBlocking: String
    val freeFeeds: String
    val freeTimer: String
    val freePact: String
    val freePanic: String
    val freeExamAlerts: String
    val freeStats: String
    val freeStudyMode: String
    fun freeStudyNote(free: Int): String
    val freePoster: String
    val freeThemesNote: String

    val back: String

    /** The key dialog. */
    val keyTitle: String
    val keyHint: String
    val keyPlaceholder: String
    val keyWrong: String
    val cancel: String
    val checking: String
    val unlock: String
}

object PlansHi : PlansStrings {
    override val kicker = "PLANS"
    override val title = "Blocking free hi rahegi."
    override val subtitle = "Paise sirf tab do jab aur jagah chahiye kaam karne ko."

    override val lifetime = "Lifetime"
    override val yours = "Tumhara"
    override val productName = "MOMENTUM PREMIUM"
    override val bestValue = "SABSE SAHI"

    override val allModes = "MyAi ke saare modes"
    override val allModesNote = "Friend + Guru"
    override fun perSession(cap: Int, free: Int) = "$cap · free $free"
    override val perSessionLabel = "Sawaal per session"
    override val photoPdf = "Photo aur PDF se doubt"
    override val mockTest = "Mock test"
    override fun mockNote(count: Int) = "$count sawaal ka drill"
    override val crownMode = "Crown mode"
    override val crownNote = "uninstall lock"
    override val allThemes = "Saare themes, abhi"
    override val allThemesNote = "levelling nahi"
    override val posterBackdrop = "Poster ka AI background"

    override val ownedHeader = "AB TUMHARA HAI"
    override val lockedHeader = "KHULEGA JAB UNLOCK KAROGE"

    override val peekModesTitle = "Friend aur Guru"
    override val peekModesBody = "Ek dost jaisa, ya ek ustaad jaisa. Free mein sirf Study."
    override val peekPageTitle = "Page bhejo, jawab lo"
    override val peekPageBody = "Kitaab ka photo ya PDF — usi page se doubt aur mock test."
    override val peekThemesTitle = "Saare theme, abhi"
    override val peekThemesBody =
        "Sakura, Monsoon, Ember, Midnight, Gold — level ka intezaar nahi."

    override val unlocked = "Unlocked"
    override val unlockLifetime = "Lifetime unlock karo"
    override val haveKey = "Pehle se khareeda hai? Key daalo"
    override val nothingBlocked = "Jo cheez distraction rokti hai, wo iske peeche nahi hai."

    override val freeTitle = "Free"
    override val youreOnThis = "TUM ISI PE HO"
    override val freeBlocking = "App blocking + shield"
    override val freeFeeds = "Shorts / Reels / Stories guard"
    override val freeTimer = "Focus timer + wallet"
    override val freePact = "Pact"
    override val freePanic = "Panic button"
    override val freeExamAlerts = "Exam alerts"
    override val freeStats = "Stats aur poori history"
    override val freeStudyMode = "MyAi Study mode"
    override fun freeStudyNote(free: Int) = "$free sawaal per session"
    override val freePoster = "Success card aur poster"
    override val freeThemesNote = "Themes level ke saath khulte hain."

    override val back = "Wapas"

    override val keyTitle = "LICENCE KEY"
    override val keyHint = "Jo key kharidne pe mili thi"
    override val keyPlaceholder = "MOM-XXXXX-XXXXX-XXXXX"
    override val keyWrong =
        "Ye key sahi nahi hai. Dobara dekh lo — dash aur capital letters ki " +
            "fikar mat karo, wo apne aap sambhal jaate hain."
    override val cancel = "Rehne do"
    override val checking = "Dekh rahe hain…"
    override val unlock = "Unlock"
}

object PlansEn : PlansStrings {
    override val kicker = "PLANS"
    override val title = "Blocking stays free."
    override val subtitle = "Pay only if you want more room to work in."

    override val lifetime = "Lifetime"
    override val yours = "Yours"
    override val productName = "MOMENTUM PREMIUM"
    override val bestValue = "BEST VALUE"

    override val allModes = "Every MyAi mode"
    override val allModesNote = "Friend + Guru"
    override fun perSession(cap: Int, free: Int) = "$cap · free $free"
    override val perSessionLabel = "Questions per session"
    override val photoPdf = "Doubts from a photo or PDF"
    override val mockTest = "Mock test"
    override fun mockNote(count: Int) = "$count-question drill"
    override val crownMode = "Crown mode"
    override val crownNote = "uninstall lock"
    override val allThemes = "Every theme, now"
    override val allThemesNote = "no levelling"
    override val posterBackdrop = "AI backdrop on the poster"

    override val ownedHeader = "YOURS NOW"
    override val lockedHeader = "LOCKED UNTIL YOU UNLOCK"

    override val peekModesTitle = "Friend and Guru"
    override val peekModesBody = "Like a mate, or like a teacher. Free gets Study only."
    override val peekPageTitle = "Send a page, get an answer"
    override val peekPageBody = "A photo of the book or a PDF — doubts and drills from that page."
    override val peekThemesTitle = "Every theme, now"
    override val peekThemesBody =
        "Sakura, Monsoon, Ember, Midnight, Gold — no waiting for a level."

    override val unlocked = "Unlocked"
    override val unlockLifetime = "Unlock lifetime"
    override val haveKey = "Already bought? Enter your key"
    override val nothingBlocked = "Nothing that blocks a distraction is behind this."

    override val freeTitle = "Free"
    override val youreOnThis = "YOU'RE ON THIS"
    override val freeBlocking = "App blocking + shield"
    override val freeFeeds = "Shorts / Reels / Stories guard"
    override val freeTimer = "Focus timer + wallet"
    override val freePact = "Pact"
    override val freePanic = "Panic button"
    override val freeExamAlerts = "Exam alerts"
    override val freeStats = "Stats and full history"
    override val freeStudyMode = "MyAi Study mode"
    override fun freeStudyNote(free: Int) = "$free questions per session"
    override val freePoster = "Success card and poster"
    override val freeThemesNote = "Themes unlock as you level."

    override val back = "Back"

    override val keyTitle = "LICENCE KEY"
    override val keyHint = "The key you got when you bought it"
    override val keyPlaceholder = "MOM-XXXXX-XXXXX-XXXXX"
    override val keyWrong =
        "That key is not right. Check it again — dashes and capitals do not " +
            "matter, they are handled."
    override val cancel = "Cancel"
    override val checking = "Checking…"
    override val unlock = "Unlock"
}
