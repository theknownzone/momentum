package com.momentum.focus.ui.theme

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.i18n.Lang
import com.momentum.focus.ui.i18n.LocalStrings
import com.momentum.focus.ui.i18n.stringsFor

/**
 * Rebuilt on every read, not held.
 *
 * As a plain val this was constructed once when the class loaded and kept the
 * cream-and-ink values for the life of the process — so switching to neon
 * darkened every surface drawn with the raw colours and left every surface
 * drawn through MaterialTheme.colorScheme exactly as it was. Half a themed
 * app is worse than an unthemed one.
 *
 * A getter is read inside the composable below, which puts the read inside
 * composition, which is what makes the switch recompose rather than require a
 * restart.
 */
private val Scheme: ColorScheme get() = lightColorScheme(
    background       = Cream,
    onBackground     = Ink,
    surface          = CreamCard,
    onSurface        = Ink,
    surfaceVariant   = Sunk,
    onSurfaceVariant = InkMid,
    primary          = Mint.fill,
    onPrimary        = Mint.on,
    secondary        = Butter.fill,
    onSecondary      = Butter.on,
    tertiary         = Lilac.fill,
    onTertiary       = Lilac.on,
    outline          = Ink,
)

/**
 * The skin currently in use, readable from anywhere in the tree.
 *
 * The skin used to be read straight out of AppData by the one screen that
 * cared, so picking Monsoon changed a single gradient on Home and nothing
 * else. Every other screen kept its fixed colours, which made a reward that
 * unlocks at level 3 look broken rather than subtle.
 *
 * Passed through a CompositionLocal rather than a parameter because the places
 * that should react — a nav bar, a section header — sit several composables
 * below whoever holds the data, and threading a colour through all of them
 * would be worse than the problem.
 */
val LocalSkin = staticCompositionLocalOf { Skin.SAKURA }

/**
 * Also the app's environment root, which is why the language lives here next
 * to the skin. Both are one-per-app choices read from deep in the tree, and
 * providing them together means there is a single place that wraps everything
 * rather than two nested providers around the same content.
 */
@Composable
fun MomentumTheme(
    skin: Skin = Skin.SAKURA,
    lang: Lang = Lang.HI,
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(
        LocalSkin provides skin,
        LocalStrings provides stringsFor(lang),
    ) {
        MaterialTheme(
            // primary is what the accent-coloured controls resolve to, so
            // pointing it at the skin is what makes the choice visible beyond
            // the one card that already read it directly.
            colorScheme = Scheme.copy(primary = skin.accent),
            typography = AppTypography,
            content = content,
        )
    }
}

object Motion {
    fun <T> press() = spring<T>(dampingRatio = 0.55f, stiffness = Spring.StiffnessHigh)
    fun <T> bouncy() = spring<T>(dampingRatio = 0.42f, stiffness = Spring.StiffnessMediumLow)
    fun <T> settle() = spring<T>(dampingRatio = 1f, stiffness = Spring.StiffnessLow)
}

object Paper {
    val CardRadius = 16.dp
    val ChipRadius = 13.dp
    val StickerOffset = 0.dp
    /** Every outline in the app is this thick. Vary it and the print look dies. */
    val Outline = 3.dp
    val ScreenPad = 18.dp
    val Gap = 12.dp
}
