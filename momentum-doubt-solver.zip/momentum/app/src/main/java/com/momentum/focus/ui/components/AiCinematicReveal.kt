package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Cream
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Tang
import kotlinx.coroutines.delay
import kotlin.math.sin

/**
 * MyAI's opening sequence is deliberately inspired by modern food/commerce AI
 * surfaces: skeleton -> reveal -> living input -> ambient light. It is an
 * overlay, not a modal, so the screen remains usable while the animation plays.
 * The first 3.6s are the story; the remaining ~8s are a low-alpha ambient pass.
 */
@Composable
fun Modifier.aiCinematicReveal(): Modifier {
    val phase = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        phase.animateTo(0.30f, tween(1500, easing = FastOutSlowInEasing))
        phase.animateTo(0.58f, tween(1300, easing = FastOutSlowInEasing))
        phase.animateTo(0.76f, tween(800, easing = FastOutSlowInEasing))
        phase.animateTo(1f, tween(8400, easing = LinearEasing))
    }

    return drawWithContent {
        drawContent()
        val p = phase.value
        if (p >= 1f) return@drawWithContent

        val w = size.width
        val h = size.height
        val intro = (1f - p / 0.76f).coerceIn(0f, 1f)
        val skeleton = (1f - ((p - 0.10f) / 0.40f)).coerceIn(0f, 1f)
        val scan = ((p - 0.30f) / 0.28f).coerceIn(0f, 1f)
        val ambient = ((p - 0.76f) / 0.24f).coerceIn(0f, 1f)

        // A soft veil prevents the underlying paper from competing with the
        // opening choreography, but never blocks interaction.
        if (intro > 0f) {
            drawRect(Color(0xFF080A12).copy(alpha = 0.11f * intro))
        }

        // Zomato-style loading geometry: two quiet content blocks first, then
        // the real screen is allowed to take over. No fake content is readable.
        if (skeleton > 0f) {
            val left = w * 0.10f
            val width = w * 0.80f
            val top = h * 0.22f
            val gap = h * 0.12f
            val shimmerX = ((p * 3.2f) % 1.35f) * width * 1.7f - width * 0.85f
            listOf(top, top + gap).forEachIndexed { i, y ->
                val cardH = if (i == 0) h * 0.13f else h * 0.10f
                drawRoundRect(
                    color = Color(0xFF10131C).copy(alpha = 0.52f * skeleton),
                    topLeft = Offset(left, y),
                    size = Size(width, cardH),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(22.dp.toPx(), 22.dp.toPx()),
                )
                drawRect(
                    brush = Brush.horizontalGradient(
                        listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.10f * skeleton),
                            Color.Transparent,
                        ),
                        startX = left + shimmerX - width * 0.20f,
                        endX = left + shimmerX + width * 0.20f,
                    ),
                    topLeft = Offset(left, y),
                    size = Size(width, cardH),
                )
            }
        }

        // Scanner head: thin core + broad chromatic halo + a small landing orb.
        if (scan > 0f) {
            val y = h * (0.12f + 0.70f * scan)
            val beamH = 28.dp.toPx()
            drawRect(
                brush = Brush.verticalGradient(
                    listOf(
                        Color.Transparent,
                        Lilac.fill.copy(alpha = 0.10f * (1f - scan * 0.35f)),
                        Sky.fill.copy(alpha = 0.18f * (1f - scan * 0.35f)),
                        Mint.fill.copy(alpha = 0.08f),
                        Color.Transparent,
                    ),
                    startY = y - beamH,
                    endY = y + beamH,
                ),
                topLeft = Offset(0f, y - beamH),
                size = Size(w, beamH * 2f),
            )
            drawRect(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, Lilac.fill.copy(alpha = 0.70f), Color.White.copy(alpha = 0.92f), Sky.fill.copy(alpha = 0.70f), Color.Transparent)
                ),
                topLeft = Offset(w * 0.08f, y - 1.dp.toPx()),
                size = Size(w * 0.84f, 2.dp.toPx()),
            )
            val r = (14.dp.toPx() + 24.dp.toPx() * scan)
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Tang.fill.copy(alpha = 0.18f), Lilac.fill.copy(alpha = 0.10f), Color.Transparent),
                    radius = r * 2.4f,
                ),
                radius = r * 2.4f,
                center = Offset(w * 0.50f, y),
            )
            drawCircle(Color.White.copy(alpha = 0.75f), 2.5.dp.toPx(), Offset(w * 0.50f, y))
        }

        // The composer gets one soft chromatic breathing pass. This is the
        // "AI is ready" moment; it is deliberately subtle so it can coexist
        // with typing instead of behaving like a full-screen ad.
        val breathe = 0.5f + 0.5f * sin(p * 18f)
        if (p > 0.52f) {
            val a = ((p - 0.52f) / 0.48f).coerceIn(0f, 1f)
            val y = h * 0.84f
            val x = w * (0.12f + 0.76f * ((p * 1.35f) % 1f))
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Mint.fill.copy(alpha = 0.13f * a), Sky.fill.copy(alpha = 0.08f * a), Color.Transparent),
                    radius = h * (0.07f + 0.03f * breathe),
                ),
                radius = h * (0.07f + 0.03f * breathe),
                center = Offset(x, y),
            )
        }

        // Final ambient chromatic sweep keeps the visual alive for the full
        // sequence without repeating the loud scan/judder every few seconds.
        if (ambient > 0f) {
            val x = w * ((p * 1.6f) % 1.35f) - w * 0.15f
            drawRect(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, Sky.fill.copy(alpha = 0.035f), Lilac.fill.copy(alpha = 0.045f), Tang.fill.copy(alpha = 0.025f), Color.Transparent),
                    startX = x - w * 0.28f,
                    endX = x + w * 0.28f,
                ),
                topLeft = Offset(0f, 0f),
                size = Size(w, h),
            )
        }
    }
}
