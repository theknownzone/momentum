package com.momentum.focus.ui.util

import android.os.Build
import android.os.Vibrator
import android.os.VibrationEffect
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.content.getSystemService

/**
 * Haptics done properly.
 *
 * Two channels are used deliberately:
 *  - View.performHapticFeedback() for standard taps. The OEM tunes these, so
 *    they feel correct on that specific phone and respect system settings.
 *  - Vibrator + VibrationEffect for custom celebration patterns that no
 *    stock constant covers.
 *
 * Everything degrades quietly on old devices. Never crash for a buzz.
 */
class Haptics(
    private val view: View,
    private val vibrator: Vibrator?,
) {
    // Chat typing needs tactile feedback, but one vibration per character is
    // objectively too much. Throttle it so fast typing feels like a soft
    // texture rather than a motor running continuously.
    private var lastTypingAt = 0L
    /**
     * A tap, with a fallback for phones that swallow it.
     *
     * performHapticFeedback returns false when the ROM's own touch-feedback
     * setting is off, and on several Chinese ROMs that is the default — so on
     * exactly the phones this app is aimed at, every tick in the app did
     * nothing at all and the return value was being thrown away. When the view
     * channel refuses, the vibrator is driven directly, which answers to the
     * VIBRATE permission rather than to a touch-feedback checkbox.
     */
    private fun perform(constant: Int, ms: Long = 12, amp: Int = 55) = runCatching {
        if (view.performHapticFeedback(constant)) return@runCatching
        val v = vibrator ?: return@runCatching
        if (!v.hasVibrator()) return@runCatching
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(ms, amp))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(ms)
        }
    }

    /** Every ordinary tap. The baseline tick under a finger. */
    fun tap() {
        perform(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    /**
     * Passing a threshold: slider notch, chip selecting, card snapping in.
     *
     * Deliberately silent. This is the most-called feedback in the app — a
     * chip row, a weekday picker and the card pager all fire it, and the pager
     * fires on every swipe — so a sound here meant the app chirped at almost
     * every touch. A threshold is something you feel, not something that needs
     * announcing. Sound is kept for events that actually completed: confirm,
     * success, error.
     */
    fun tick() {
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CLOCK_TICK
            else HapticFeedbackConstants.KEYBOARD_TAP
        )
    }

    /** Long press opened something. Heavier, deliberate. */
    fun press() {
        perform(HapticFeedbackConstants.LONG_PRESS, ms = 18, amp = 85)
    }

    /** Action succeeded: session logged, habit checked. */
    /**
     * A button that did what it said. Vibration only.
     *
     * This fires in twenty-five places — every Done, every Save, every chip
     * that applied — and every one of them was playing the same SUCCESS tone.
     * Twenty-five different actions saying "ding" in the same voice is not
     * feedback, it is a noise the app makes when touched, and after ten
     * minutes it is the reason people turn sound off entirely.
     *
     * Sound now belongs to events, not to acknowledgements. Finishing a
     * session, levelling up, unlocking premium, getting a question right —
     * things that happened. Pressing Save is not one of them.
     */
    fun confirm() {
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
            else HapticFeedbackConstants.VIRTUAL_KEY,
            ms = 16,
            amp = 75,
        )
    }

    /** Action refused: blocked app, invalid input. Sharp double bump. */
    /** A button that refused. Vibration only, same reasoning as confirm. */
    fun reject() {
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.REJECT
            else HapticFeedbackConstants.LONG_PRESS
        )
    }

    /** Drag finished, gesture completed. */
    fun gestureEnd() = perform(
        if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.GESTURE_END
        else HapticFeedbackConstants.CLOCK_TICK
    )

    /**
     * One keystroke. No sound at all and the lightest tap in the file.
     *
     * It fires per character, so anything with weight or a tone attached to it
     * turns a sentence into a rattle.
     */
    fun typing() {
        val now = SystemClock.uptimeMillis()
        if (now - lastTypingAt < 140L) return
        lastTypingAt = now
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.KEYBOARD_TAP
            else HapticFeedbackConstants.VIRTUAL_KEY,
            ms = 7,
            amp = 24,
        )
    }

    /** A question leaving for the model. */
    fun send() {
        Sfx.play(Sound.SEND)
        perform(HapticFeedbackConstants.KEYBOARD_TAP, ms = 10, amp = 45)
    }

    /** An answer landing. Lighter than send — you did not do anything. */
    fun receive() {
        Sfx.play(Sound.REPLY)
        // One light landing pulse. No repeating vibration while streaming.
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.KEYBOARD_TAP
            else HapticFeedbackConstants.VIRTUAL_KEY,
            ms = 9,
            amp = 32,
        )
    }

    /**
     * The pulse while an answer is on its way.
     *
     * The lightest thing in this file, and no sound at all. It repeats for as
     * long as the wait lasts, so anything with weight to it becomes a phone
     * buzzing in someone's hand rather than a sign that work is happening.
     */
    fun waiting() {
        // Deliberately silent. Network latency is not a user action and should
        // never produce a repeating vibration while the model is thinking.
    }

    /** A right answer on the mock test. */
    fun correct() {
        Sfx.play(Sound.RIGHT)
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
            else HapticFeedbackConstants.VIRTUAL_KEY,
            ms = 14,
            amp = 70,
        )
    }

    /** A wrong one. Not the refusal buzz — nothing was refused. */
    fun wrong() {
        Sfx.play(Sound.WRONG)
        perform(HapticFeedbackConstants.LONG_PRESS, ms = 18, amp = 65)
    }

    /** A focus session starting. */
    fun begin() {
        Sfx.play(Sound.BEGIN)
        perform(HapticFeedbackConstants.LONG_PRESS, ms = 20, amp = 95)
    }

    /** The panic button. */
    fun panic() {
        Sfx.play(Sound.PANIC)
        perform(HapticFeedbackConstants.LONG_PRESS, ms = 26, amp = 120)
    }

    /** The shield going on or coming off. */
    fun shield(on: Boolean) {
        Sfx.play(if (on) Sound.SHIELD_ON else Sound.SHIELD_OFF)
        perform(HapticFeedbackConstants.VIRTUAL_KEY, ms = 15, amp = if (on) 85 else 55)
    }

    /** Wallet minutes being spent. */
    fun spend() {
        Sfx.play(Sound.SPEND)
        perform(HapticFeedbackConstants.KEYBOARD_TAP, ms = 12, amp = 60)
    }

    /** A slip being logged. Flat on purpose. */
    fun slip() {
        Sfx.play(Sound.SLIP)
        perform(HapticFeedbackConstants.LONG_PRESS, ms = 16, amp = 55)
    }

    /** Premium unlocked. Once, usually. */
    fun unlock() {
        Sfx.play(Sound.UNLOCK)
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        runCatching {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0, 30, 40, 40, 40, 180),
                        intArrayOf(0, 70, 0, 130, 0, 255),
                        -1,
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(longArrayOf(0, 30, 40, 40, 40, 180), -1)
            }
        }
    }

    /**
     * Streak milestone. A rising three-beat that ramps in amplitude — this is
     * the one moment in the app allowed to be loud. Fire it with confetti.
     */
    fun celebrate() {
        Sfx.play(Sound.LEVEL)
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        runCatching {
            if (Build.VERSION.SDK_INT >= 26) {
                val timings = longArrayOf(0, 45, 70, 55, 70, 110)
                val amps    = intArrayOf(0, 90, 0, 150, 0, 255)
                v.vibrate(VibrationEffect.createWaveform(timings, amps, -1))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(longArrayOf(0, 45, 70, 55, 70, 110), -1)
            }
        }
    }

    /** Soft two-beat for a festival banner. */
    fun festive() {
        Sfx.play(Sound.FESTIVE)
        val v = vibrator ?: run { tap(); return }
        runCatching {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0, 35, 50, 70),
                        intArrayOf(0, 80, 0, 160),
                        -1,
                    )
                )
            } else tap()
        }
    }

    fun sessionComplete() {
        Sfx.play(Sound.SESSION)
        val v = vibrator ?: return
        if (Build.VERSION.SDK_INT >= 26 && v.hasAmplitudeControl()) {
            runCatching {
                v.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0, 250), intArrayOf(0, 140), -1
                    )
                )
            }
        } else confirm()
    }
}

val LocalHaptics = staticCompositionLocalOf<Haptics> {
    error("Haptics not provided. Wrap your content in ProvideHaptics { }.")
}

@Composable
fun rememberHaptics(): Haptics {
    val view = LocalView.current
    val context = LocalContext.current
    return remember(view) {
        Sfx.init(context.applicationContext)
        Haptics(view, context.getSystemService<Vibrator>())
    }
}
