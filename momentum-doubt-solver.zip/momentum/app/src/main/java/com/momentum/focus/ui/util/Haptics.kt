package com.momentum.focus.ui.util

import android.os.Build
import android.os.Vibrator
import android.os.VibrationEffect
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.content.getSystemService

/**
 * Haptics done properly.
 *
 * Two channels are used deliberately:
 *  - View.performHapticFeedback() for standard taps. The OEM tunes these, so
 *    they feel correct on that specific phone and respect system settings.
 *  - Vibrator + VibrationEffect for custom celebration patterns that no
 *    stock constant covers.
 *
 * Everything degrades quietly on old devices. Never crash for a buzz.
 */
class Haptics(
    private val view: View,
    private val vibrator: Vibrator?,
) {
    /**
     * A tap, with a fallback for phones that swallow it.
     *
     * performHapticFeedback returns false when the ROM's own touch-feedback
     * setting is off, and on several Chinese ROMs that is the default — so on
     * exactly the phones this app is aimed at, every tick in the app did
     * nothing at all and the return value was being thrown away. When the view
     * channel refuses, the vibrator is driven directly, which answers to the
     * VIBRATE permission rather than to a touch-feedback checkbox.
     */
    private fun perform(constant: Int, ms: Long = 16, amp: Int = 95) = runCatching {
        if (view.performHapticFeedback(constant)) return@runCatching
        val v = vibrator ?: return@runCatching
        if (!v.hasVibrator()) return@runCatching
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(ms, amp))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(ms)
        }
    }

    /** Every ordinary tap. The baseline tick under a finger. */
    fun tap() {
        Sfx.play(Sound.POP)
        perform(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    /**
     * Passing a threshold: slider notch, chip selecting, card snapping in.
     *
     * Deliberately silent. This is the most-called feedback in the app — a
     * chip row, a weekday picker and the card pager all fire it, and the pager
     * fires on every swipe — so a sound here meant the app chirped at almost
     * every touch. A threshold is something you feel, not something that needs
     * announcing. Sound is kept for events that actually completed: confirm,
     * success, error.
     */
    fun tick() {
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CLOCK_TICK
            else HapticFeedbackConstants.KEYBOARD_TAP
        )
    }

    /** Long press opened something. Heavier, deliberate. */
    fun press() {
        Sfx.play(Sound.WHOOSH)
        perform(HapticFeedbackConstants.LONG_PRESS, ms = 28, amp = 150)
    }

    /** Action succeeded: session logged, habit checked. */
    fun confirm() {
        Sfx.play(Sound.SUCCESS)
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
            else HapticFeedbackConstants.VIRTUAL_KEY,
            ms = 22,
            amp = 130,
        )
    }

    /** Action refused: blocked app, invalid input. Sharp double bump. */
    fun reject() {
        Sfx.play(Sound.ERROR)
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.REJECT
            else HapticFeedbackConstants.LONG_PRESS
        )
    }

    /** Drag finished, gesture completed. */
    fun gestureEnd() = perform(
        if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.GESTURE_END
        else HapticFeedbackConstants.CLOCK_TICK
    )

    /** A question leaving for the model. */
    fun send() {
        Sfx.play(Sound.SEND)
        perform(HapticFeedbackConstants.KEYBOARD_TAP, ms = 14, amp = 80)
    }

    /** An answer landing. Lighter than send — you did not do anything. */
    fun receive() {
        Sfx.play(Sound.REPLY)
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CLOCK_TICK
            else HapticFeedbackConstants.KEYBOARD_TAP,
            ms = 12,
            amp = 70,
        )
    }

    /** A right answer on the mock test. */
    fun correct() {
        Sfx.play(Sound.RIGHT)
        perform(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
            else HapticFeedbackConstants.VIRTUAL_KEY,
            ms = 18,
            amp = 120,
        )
    }

    /** A wrong one. Not the refusal buzz — nothing was refused. */
    fun wrong() {
        Sfx.play(Sound.WRONG)
        perform(HapticFeedbackConstants.LONG_PRESS, ms = 26, amp = 110)
    }

    /** Premium unlocked. Once, usually. */
    fun unlock() {
        Sfx.play(Sound.UNLOCK)
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        runCatching {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0, 30, 40, 40, 40, 180),
                        intArrayOf(0, 70, 0, 130, 0, 255),
                        -1,
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(longArrayOf(0, 30, 40, 40, 40, 180), -1)
            }
        }
    }

    /**
     * Streak milestone. A rising three-beat that ramps in amplitude — this is
     * the one moment in the app allowed to be loud. Fire it with confetti.
     */
    fun celebrate() {
        Sfx.play(Sound.LEVEL)
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        runCatching {
            if (Build.VERSION.SDK_INT >= 26) {
                val timings = longArrayOf(0, 45, 70, 55, 70, 110)
                val amps    = intArrayOf(0, 90, 0, 150, 0, 255)
                v.vibrate(VibrationEffect.createWaveform(timings, amps, -1))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(longArrayOf(0, 45, 70, 55, 70, 110), -1)
            }
        }
    }

    /** Soft two-beat for a festival banner. */
    fun festive() {
        Sfx.play(Sound.FESTIVE)
        val v = vibrator ?: run { tap(); return }
        runCatching {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0, 35, 50, 70),
                        intArrayOf(0, 80, 0, 160),
                        -1,
                    )
                )
            } else tap()
        }
    }

    fun sessionComplete() {
        Sfx.play(Sound.SESSION)
        val v = vibrator ?: return
        if (Build.VERSION.SDK_INT >= 26 && v.hasAmplitudeControl()) {
            runCatching {
                v.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0, 250), intArrayOf(0, 140), -1
                    )
                )
            }
        } else confirm()
    }
}

val LocalHaptics = staticCompositionLocalOf<Haptics> {
    error("Haptics not provided. Wrap your content in ProvideHaptics { }.")
}

@Composable
fun rememberHaptics(): Haptics {
    val view = LocalView.current
    val context = LocalContext.current
    return remember(view) {
        Sfx.init(context.applicationContext)
        Haptics(view, context.getSystemService<Vibrator>())
    }
}
