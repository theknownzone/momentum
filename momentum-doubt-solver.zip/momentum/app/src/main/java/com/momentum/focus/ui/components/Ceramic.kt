package com.momentum.focus.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.LocalSkin

/**
 * A ceramic slab: translucent, soft-edged, sitting on more of itself.
 *
 * The other surfaces in this app are printed — hard Ink outline, flat fill,
 * offset shadow. This one is the opposite and deliberately so: no outline at
 * all, a milky fill that lets the grid show through, and two paler copies of
 * itself stacked behind at an offset. The stack is what does the work. A single
 * translucent rectangle reads as a faded card; three of them reads as a solid
 * object with thickness.
 *
 * No blur anywhere. Ceramic is about softness and layering rather than
 * defocus, so the look survives on API 26 where Modifier.blur does nothing —
 * and on a phone that *can* blur it would not look any different.
 */
@Composable
fun CeramicPanel(
    modifier: Modifier = Modifier,
    radius: Dp = 20.dp,
    /** Colour bled into the milk. Skin accent by default. */
    tint: Color = LocalSkin.current.accent,
    /** How many slabs sit behind the front one. */
    layers: Int = 2,
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(radius)
    Box(
        modifier
            .drawBehind { slabs(radius.toPx(), tint, layers) }
            .clip(shape)
            .drawBehind { face(radius.toPx(), tint) },
        content = content,
    )
}

/**
 * The stack behind the front slab.
 *
 * Each one steps down and right and loses opacity, so the pile reads as thick
 * rather than as a shadow. Drawn outside the clip, which is why this is a
 * separate pass from [face].
 */
private fun DrawScope.slabs(r: Float, tint: Color, layers: Int) {
    for (i in layers downTo 1) {
        val step = size.minDimension * 0.028f * i
        val fade = 0.16f / i
        drawRoundRect(
            color = lerp(Color.White, tint, 0.22f).copy(alpha = fade),
            topLeft = Offset(step, step),
            size = Size(size.width - step * 0.4f, size.height - step * 0.4f),
            cornerRadius = CornerRadius(r, r),
        )
        // A hairline on each, or the pile is a smudge rather than edges.
        drawRoundRect(
            color = Color.White.copy(alpha = 0.20f / i),
            topLeft = Offset(step, step),
            size = Size(size.width - step * 0.4f, size.height - step * 0.4f),
            cornerRadius = CornerRadius(r, r),
            style = Stroke(width = 1.5f),
        )
    }
}

/**
 * The front slab: milk, a lit top edge, and a shaded bottom.
 *
 * The rim is drawn as two strokes rather than one border, because a ceramic
 * edge is bright where it faces up and dark where it turns under — a single
 * even outline is what makes translucent panels look like flat rectangles.
 */
private fun DrawScope.face(r: Float, tint: Color) {
    drawRoundRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.72f),
                lerp(Color.White, tint, 0.14f).copy(alpha = 0.52f),
                lerp(Color.White, tint, 0.30f).copy(alpha = 0.60f),
            ),
        ),
        cornerRadius = CornerRadius(r, r),
    )
    // Sheen across the top third, where the curve of the surface would catch.
    drawRoundRect(
        brush = Brush.verticalGradient(
            colors = listOf(Color.White.copy(alpha = 0.55f), Color.Transparent),
            startY = 0f,
            endY = size.height * 0.42f,
        ),
        size = Size(size.width, size.height * 0.42f),
        cornerRadius = CornerRadius(r, r),
    )
    // Top rim bright, bottom rim shaded. Two passes, one shape.
    drawRoundRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.85f),
                Color.White.copy(alpha = 0.10f),
                lerp(tint, Color.Black, 0.35f).copy(alpha = 0.28f),
            ),
        ),
        cornerRadius = CornerRadius(r, r),
        style = Stroke(width = size.minDimension * 0.020f),
    )
}
