package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink

/**
 * A small mark beside each app's name on the feed guard.
 *
 * The screen groups switches under INSTAGRAM, YOUTUBE, SNAPCHAT and so on, and
 * as plain tracked capitals those headers read as noise sitting above the thing
 * they label — the user could not tell at a glance which block of switches
 * belonged to which app. A shape is recognised before a word is read.
 *
 * These are drawn, not traced, and deliberately generic: a rounded square with
 * a ring and a dot, a rounded rectangle with a play triangle, a ghost, a speech
 * bubble. They carry the same Ink outline as every other object in this app, so
 * they belong to the app's own hand rather than looking like logos pasted in
 * from somewhere else — which is also why shipping actual brand artwork was not
 * the right call for a blocklist that names other people's products.
 *
 * Anything unrecognised falls back to a plain rounded square, so a surface
 * added later still gets a mark rather than a gap.
 */
@Composable
fun AppMark(app: String, size: Dp = 22.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        when {
            app.startsWith("Instagram", true) -> camera()
            app.startsWith("YouTube", true) -> player()
            app.startsWith("Snapchat", true) -> ghost()
            app.startsWith("WhatsApp", true) -> bubble()
            app.startsWith("Facebook", true) -> squareF()
            else -> plate()
        }
    }
}

private val OUTLINE = 1.6f

private fun DrawScope.stroke() = Stroke(width = OUTLINE.dp.toPx())

/** Rounded square, ring, dot — the shape everyone reads as a photo feed. */
private fun DrawScope.camera() {
    val u = size.minDimension
    val pad = u * 0.08f
    drawRoundRect(
        color = Ink,
        topLeft = Offset(pad, pad),
        size = Size(u - pad * 2, u - pad * 2),
        cornerRadius = CornerRadius(u * 0.30f, u * 0.30f),
        style = stroke(),
    )
    drawCircle(Ink, radius = u * 0.20f, center = Offset(u / 2, u / 2), style = stroke())
    drawCircle(Ink, radius = u * 0.055f, center = Offset(u * 0.735f, u * 0.265f))
}

/** Wide rounded rectangle with a play triangle cut into it. */
private fun DrawScope.player() {
    val u = size.minDimension
    val h = u * 0.66f
    val top = (u - h) / 2f
    drawRoundRect(
        color = Ink,
        topLeft = Offset(u * 0.04f, top),
        size = Size(u * 0.92f, h),
        cornerRadius = CornerRadius(u * 0.22f, u * 0.22f),
        style = stroke(),
    )
    val p = Path().apply {
        moveTo(u * 0.41f, top + h * 0.26f)
        lineTo(u * 0.41f, top + h * 0.74f)
        lineTo(u * 0.66f, top + h * 0.50f)
        close()
    }
    drawPath(p, Ink)
}

/** A ghost: domed head, scalloped hem. */
private fun DrawScope.ghost() {
    val u = size.minDimension
    val p = Path().apply {
        moveTo(u * 0.16f, u * 0.80f)
        lineTo(u * 0.16f, u * 0.46f)
        cubicTo(u * 0.16f, u * 0.14f, u * 0.84f, u * 0.14f, u * 0.84f, u * 0.46f)
        lineTo(u * 0.84f, u * 0.80f)
        lineTo(u * 0.70f, u * 0.68f)
        lineTo(u * 0.56f, u * 0.80f)
        lineTo(u * 0.42f, u * 0.68f)
        lineTo(u * 0.28f, u * 0.80f)
        close()
    }
    drawPath(p, Ink, style = stroke())
    drawCircle(Ink, u * 0.055f, Offset(u * 0.40f, u * 0.44f))
    drawCircle(Ink, u * 0.055f, Offset(u * 0.62f, u * 0.44f))
}

/** Speech bubble with a tail. */
private fun DrawScope.bubble() {
    val u = size.minDimension
    drawRoundRect(
        color = Ink,
        topLeft = Offset(u * 0.08f, u * 0.12f),
        size = Size(u * 0.84f, u * 0.62f),
        cornerRadius = CornerRadius(u * 0.30f, u * 0.30f),
        style = stroke(),
    )
    val tail = Path().apply {
        moveTo(u * 0.26f, u * 0.70f)
        lineTo(u * 0.20f, u * 0.92f)
        lineTo(u * 0.44f, u * 0.74f)
        close()
    }
    drawPath(tail, Ink)
}

/** Rounded square with a bar down the right, the shape of a social square. */
private fun DrawScope.squareF() {
    val u = size.minDimension
    val pad = u * 0.08f
    drawRoundRect(
        color = Ink,
        topLeft = Offset(pad, pad),
        size = Size(u - pad * 2, u - pad * 2),
        cornerRadius = CornerRadius(u * 0.26f, u * 0.26f),
        style = stroke(),
    )
    drawRect(
        color = Ink,
        topLeft = Offset(u * 0.54f, u * 0.34f),
        size = Size(u * 0.10f, u * 0.50f),
    )
    drawRect(
        color = Ink,
        topLeft = Offset(u * 0.40f, u * 0.48f),
        size = Size(u * 0.34f, u * 0.09f),
    )
}

/** The fallback. */
private fun DrawScope.plate() {
    val u = size.minDimension
    val pad = u * 0.10f
    drawRoundRect(
        color = Ink,
        topLeft = Offset(pad, pad),
        size = Size(u - pad * 2, u - pad * 2),
        cornerRadius = CornerRadius(u * 0.28f, u * 0.28f),
        style = stroke(),
    )
}
