package com.momentum.focus.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.ByteArrayOutputStream
import kotlin.math.max

/**
 * Turns a gallery photo or a PDF page into a JPEG the chat request can carry.
 *
 * No extra library: [PdfRenderer] is in the framework from API 21, and the
 * picker hands us a content Uri so we never ask for storage permission.
 */
object Attach {

    const val MAX_EDGE = 1280
    const val JPEG_QUALITY = 72

    data class Page(val jpegB64: String, val label: String)

    fun fromUri(context: Context, uri: Uri): Page {
        val type = context.contentResolver.getType(uri).orEmpty()
        return if (type.contains("pdf") || uri.toString().endsWith(".pdf", true)) {
            fromPdf(context, uri)
        } else {
            fromImage(context, uri)
        }
    }

    private fun fromImage(context: Context, uri: Uri): Page {
        val raw = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Could not read that image.")
        val bitmap = BitmapFactory.decodeByteArray(raw, 0, raw.size)
            ?: throw IllegalStateException("That image would not open.")
        return Page(jpegB64 = encode(bitmap), label = "Photo attached")
    }

    private fun fromPdf(context: Context, uri: Uri): Page {
        val pfd: ParcelFileDescriptor = context.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("Could not open that PDF.")
        pfd.use { fd ->
            PdfRenderer(fd).use { renderer ->
                if (renderer.pageCount < 1) throw IllegalStateException("Empty PDF.")
                renderer.openPage(0).use { page ->
                    val scale = 2
                    val bmp = Bitmap.createBitmap(
                        page.width * scale,
                        page.height * scale,
                        Bitmap.Config.ARGB_8888,
                    )
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return Page(jpegB64 = encode(bmp), label = "PDF page 1 attached")
                }
            }
        }
    }

    private fun encode(src: Bitmap): String {
        val longest = max(src.width, src.height).coerceAtLeast(1)
        val scaled = if (longest > MAX_EDGE) {
            val f = MAX_EDGE.toFloat() / longest
            Bitmap.createScaledBitmap(
                src,
                (src.width * f).toInt().coerceAtLeast(1),
                (src.height * f).toInt().coerceAtLeast(1),
                true,
            )
        } else {
            src
        }
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        if (scaled !== src) scaled.recycle()
        return android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)
    }
}
