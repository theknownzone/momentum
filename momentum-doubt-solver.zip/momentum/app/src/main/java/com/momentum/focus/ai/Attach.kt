package com.momentum.focus.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.ByteArrayOutputStream
import kotlin.math.max

/**
 * Turns a gallery photo or a PDF page into a JPEG the chat request can carry.
 *
 * No extra library: [PdfRenderer] is in the framework from API 21, and the
 * picker hands us a content Uri so we never ask for storage permission.
 *
 * Every path here touches disk and allocates bitmaps measured in megabytes, so
 * none of it may run on the main thread. The caller is responsible for that —
 * see the composer in DoubtSheet.
 */
object Attach {

    const val MAX_EDGE = 1280
    const val JPEG_QUALITY = 72

    data class Page(val jpegB64: String, val label: String)

    fun fromUri(context: Context, uri: Uri): Page {
        val type = context.contentResolver.getType(uri).orEmpty()
        return if (type.contains("pdf") || uri.toString().endsWith(".pdf", true)) {
            fromPdf(context, uri)
        } else {
            fromImage(context, uri)
        }
    }

    /**
     * Decoded at roughly the size we need, not at full sensor resolution.
     *
     * A 12MP phone photo decodes to about 48MB as ARGB_8888. Reading the whole
     * file into a byte array and handing that to the decoder — which is what
     * this used to do — is an OutOfMemoryError on exactly the cheap phones this
     * app is built for, and it happens on the photo, before anything can be
     * done with it.
     */
    private fun fromImage(context: Context, uri: Uri): Page {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri).use {
            BitmapFactory.decodeStream(it ?: throw IllegalStateException("Could not read that image."), null, bounds)
        }
        val longest = max(bounds.outWidth, bounds.outHeight)
        if (longest <= 0) throw IllegalStateException("That image would not open.")

        val opts = BitmapFactory.Options().apply {
            var sample = 1
            while (longest / sample > MAX_EDGE * 2) sample *= 2
            inSampleSize = sample
        }
        val decoded = context.contentResolver.openInputStream(uri).use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: throw IllegalStateException("That image would not open.")

        return Page(jpegB64 = encode(upright(context, uri, decoded)), label = "Photo attached")
    }

    /**
     * Puts a camera photo the right way up.
     *
     * Phones store portrait shots as landscape pixels plus an orientation flag,
     * and the decoder ignores the flag. A page of notes arriving on its side is
     * a page the model reads sideways, which is a wrong answer that looks like
     * a bad model rather than a bad upload.
     */
    private fun upright(context: Context, uri: Uri, bitmap: Bitmap): Bitmap {
        val degrees = runCatching {
            context.contentResolver.openInputStream(uri).use { stream ->
                stream ?: return bitmap
                when (
                    ExifInterface(stream).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL,
                    )
                ) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            }
        }.getOrDefault(0f)
        if (degrees == 0f) return bitmap
        val turned = Bitmap.createBitmap(
            bitmap,
            0,
            0,
            bitmap.width,
            bitmap.height,
            Matrix().apply { postRotate(degrees) },
            true,
        )
        if (turned !== bitmap) bitmap.recycle()
        return turned
    }

    private fun fromPdf(context: Context, uri: Uri): Page {
        val pfd: ParcelFileDescriptor = context.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("Could not open that PDF.")
        pfd.use { fd ->
            PdfRenderer(fd).use { renderer ->
                if (renderer.pageCount < 1) throw IllegalStateException("Empty PDF.")
                renderer.openPage(0).use { page ->
                    // Scaled to land near MAX_EDGE rather than always doubled.
                    // A fixed 2x on a large page allocated a bitmap far bigger
                    // than anything that survives the resize two lines later.
                    val longest = max(page.width, page.height).coerceAtLeast(1)
                    val scale = (MAX_EDGE.toFloat() / longest).coerceIn(1f, 3f)
                    val bmp = Bitmap.createBitmap(
                        (page.width * scale).toInt().coerceAtLeast(1),
                        (page.height * scale).toInt().coerceAtLeast(1),
                        Bitmap.Config.ARGB_8888,
                    )
                    // PdfRenderer draws the page's ink and leaves everything
                    // else transparent — it does not paint the paper. JPEG has
                    // no alpha, so transparent flattens to black: every PDF
                    // went to the model as white text on a black page, which is
                    // the worst possible input for reading handwriting. The
                    // page has to be given its paper first.
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return Page(jpegB64 = encode(bmp), label = "PDF page 1 attached")
                }
            }
        }
    }

    private fun encode(src: Bitmap): String {
        val longest = max(src.width, src.height).coerceAtLeast(1)
        val scaled = if (longest > MAX_EDGE) {
            val f = MAX_EDGE.toFloat() / longest
            Bitmap.createScaledBitmap(
                src,
                (src.width * f).toInt().coerceAtLeast(1),
                (src.height * f).toInt().coerceAtLeast(1),
                true,
            )
        } else {
            src
        }
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        if (scaled !== src) scaled.recycle()
        return android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)
    }
}
