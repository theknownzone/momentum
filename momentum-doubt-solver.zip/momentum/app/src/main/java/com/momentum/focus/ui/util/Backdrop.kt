package com.momentum.focus.ui.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.momentum.focus.ai.Ai
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * The generated paper behind a shared poster.
 *
 * Made once and kept. The model is asked for a texture and nothing else — no
 * words, no numbers, no charts — because the checkpoint behind this endpoint is
 * documented as poor at rendering text inside an image, and every figure on the
 * poster is drawn afterwards from stored data anyway. Asking it for the numbers
 * would be asking it to be wrong in a way that looks right.
 *
 * Cached to a file rather than regenerated per share: a backdrop that changes
 * every time is not a look, it is noise, and it would spend a GPU call on every
 * tap of a button people press repeatedly.
 */
object Backdrop {

    private const val FILE = "momentum-backdrop.jpg"

    private const val PROMPT =
        "Abstract warm cream and pale gold paper texture, soft grid lines, " +
            "hand-printed risograph feel, gentle ink smudges, empty composition " +
            "with nothing in the centre, no text, no letters, no numbers, " +
            "no people, no objects, flat matte poster background"

    /**
     * Whether one has been made, without decoding it.
     *
     * The UI asks this on every recomposition to decide whether to show the
     * "new background" chip, and decoding a megapixel JPEG on the main thread
     * that often would drop frames for the whole screen.
     */
    fun exists(context: Context): Boolean = File(context.cacheDir, FILE).exists()

    /**
     * The cached backdrop, generating one if there is none.
     *
     * Returns null on any failure rather than throwing. A poster without a
     * backdrop is a complete poster; a share that fails because a GPU somewhere
     * was cold is not something to put in front of someone.
     */
    suspend fun getOrMake(context: Context): Bitmap? = withContext(Dispatchers.IO) {
        val file = File(context.cacheDir, FILE)
        if (file.exists()) {
            runCatching { BitmapFactory.decodeFile(file.path) }.getOrNull()
                ?.let { return@withContext it }
        }
        if (!Ai.enabled) return@withContext null
        runCatching {
            val bytes = Ai.image(prompt = PROMPT, width = 1024, height = 1280)
            File(context.cacheDir, FILE).writeBytes(bytes)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }.getOrNull()
    }

    /** Throws the cached image away so the next share makes a new one. */
    fun clear(context: Context) {
        runCatching { File(context.cacheDir, FILE).delete() }
    }
}
