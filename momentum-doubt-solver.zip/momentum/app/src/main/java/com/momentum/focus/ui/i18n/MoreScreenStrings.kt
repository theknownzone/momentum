package com.momentum.focus.ui.i18n

interface WhatsNewStrings {
    val justUpdated: String
    val title: String
    fun version(v: String): String
    val fullChangelog: String
    val gotIt: String

    /** The strip that replaced the full-screen changelog. */
    fun updatedTo(version: String): String
    val tapToRead: String

    /** The release log while it loads, and the badge on the newest one. */
    val loading: String
    val current: String

    val sectionNew: String
    val sectionFixed: String

    val newStudyChannels: String
    val newAutoAsk: String
    val newLevelUpOnly: String
    val newSaveButton: String
    val newSubjectFromFocus: String
    val newExamNews: String
    val newHelpSection: String
    val newPremium: String

    fun fixedTimerSurvives(): String
    val fixedRateUpfront: String
    fun fixedLightEarns(level: String): String
    val fixedShortsSplitScreen: String
    val fixedGuardDebug: String
    val fixedLaunchCrash: String
    val fixedCalendarCard: String
    val fixedUpdateInPlace: String
}

object WhatsNewHi : WhatsNewStrings {
    override val justUpdated = "ABHI UPDATE HUA"
    override val title = "What's new"
    override fun version(v: String) = "Version $v"
    override val fullChangelog = "Poora changelog"
    override val gotIt = "Samajh gaya"

    override val sectionNew = "New"
    override val sectionFixed = "Theek kiya"

    override val newStudyChannels =
        "Sirf study channels — apne teachers ke naam daalo, baaki YouTube band"
    override val newAutoAsk =
        "Padh rahe ho to app khud poochta hai timer chalu karna hai ya nahi"
    override val newLevelUpOnly = "Session ke beech level neeche nahi ja sakta, sirf upar"
    override val newSaveButton = "Block list ab Save dabane pe save hoti hai, har tap pe nahi"
    override val newSubjectFromFocus = "Focus screen se hi naya subject bana sakte ho"
    override val newExamNews = "Exam news Home pe, tumhare exam ke hisaab se"
    override val newHelpSection = "Help aur feedback ka apna section, data ki poori baat ke saath"
    override val newPremium = "Momentum Premium — blocking hamesha free rahegi"

    override fun fixedTimerSurvives() = "Timer ab app band karne pe bhi chalta rehta hai"
    override val fixedRateUpfront = "₹ kab milega wo ab pehle se likha aata hai, baad mein nahi"
    override fun fixedLightEarns(level: String) =
        "$level pe bhi session chalta hai aur paise deta hai"
    override val fixedShortsSplitScreen =
        "Shorts split-screen aur floating window mein bhi pakdi jaati hai"
    override val fixedGuardDebug =
        "Feed guard ka debug ab khud dekhta hai, event ka intezaar nahi karta"
    override val fixedLaunchCrash = "App khulte hi crash hona band"
    override val fixedCalendarCard = "Calendar card sirf festival wale din aata hai"
    override val fixedUpdateInPlace =
        "Update ab purane ke upar chadh jaata hai, uninstall nahi karna padta"
    override val loading = "Log aa raha hai…"
    override val current = "ABHI YEHI"
    override fun updatedTo(version: String) = "Update ho gaya — $version"
    override val tapToRead = "Tap karke dekho kya badla"
}

object WhatsNewEn : WhatsNewStrings {
    override val justUpdated = "JUST UPDATED"
    override val title = "What's new"
    override fun version(v: String) = "Version $v"
    override val fullChangelog = "Full Changelog"
    override val gotIt = "Got it"

    override val sectionNew = "New"
    override val sectionFixed = "Fixed"

    override val newStudyChannels =
        "Study channels only — name your teachers, the rest of YouTube stays shut"
    override val newAutoAsk =
        "If you're studying, the app asks whether to start the timer"
    override val newLevelUpOnly = "You can't drop a level mid-session, only raise it"
    override val newSaveButton = "The block list saves when you press Save, not on every tap"
    override val newSubjectFromFocus = "Add a new subject from the Focus screen itself"
    override val newExamNews = "Exam notices on Home, matched to your exam"
    override val newHelpSection = "Help and feedback have their own section, data story included"
    override val newPremium = "Momentum Premium — blocking stays free, always"

    override fun fixedTimerSurvives() = "The timer keeps running even if you close the app"
    override val fixedRateUpfront = "You're told when the ₹ lands before you start, not after"
    override fun fixedLightEarns(level: String) =
        "Sessions run and pay on $level too"
    override val fixedShortsSplitScreen =
        "Shorts is caught in split-screen and floating windows as well"
    override val fixedGuardDebug =
        "Feed guard debug checks for itself instead of waiting on an event"
    override val fixedLaunchCrash = "No more crash on opening the app"
    override val fixedCalendarCard = "The calendar card only shows up on the festival day"
    override val fixedUpdateInPlace =
        "Updates install over the old version — no uninstall needed"
    override val loading = "Loading the log…"
    override val current = "YOU'RE ON THIS"
    override fun updatedTo(version: String) = "Updated to $version"
    override val tapToRead = "Tap to see what changed"
}

interface QuizStrings {
    val hoursQuestion: String
    val pickupsQuestion: String
    fun hrs(hours: Int): String
    fun pickups(count: Int): String
    val roughGuess: String
    val wantItBack: String
    val continueLabel: String

    val last7Days: String
    val heresTheTruth: String
    fun youGuessedHours(hours: Int): String
    val actualDailyAverage: String
    fun longestDay(hours: Int, minutes: Int): String
    fun youGuessedPickups(count: Int): String
    val pickedUpYesterday: String
    val topDistractions: String

    fun aDay(hours: Int, minutes: Int): String
    fun years(value: Double): String
    val ofYourLife: String
    val whatItCouldBe: String
    val now: String
    val target: String
    val targetNote: String
}

object QuizHi : QuizStrings {
    override val hoursQuestion = "How many hours a day do you think you're on your phone?"
    override val pickupsQuestion = "And how many times a day do you pick it up?"
    override fun hrs(hours: Int) = "$hours HRS"
    override fun pickups(count: Int) = "${count}x"
    override val roughGuess = "A ROUGH GUESS IS FINE"
    override val wantItBack = "I want that back"
    override val continueLabel = "Continue"

    override val last7Days = "YOUR LAST 7 DAYS"
    override val heresTheTruth = "Here's the truth"
    override fun youGuessedHours(hours: Int) = "You guessed ${hours}h"
    override val actualDailyAverage = "is your actual daily average"
    override fun longestDay(hours: Int, minutes: Int) =
        "Longest day: %dh %02dm".format(hours, minutes)
    override fun youGuessedPickups(count: Int) = "You guessed ${count}x"
    override val pickedUpYesterday = "times you picked it up yesterday"
    override val topDistractions = "TOP DISTRACTIONS"

    override fun aDay(hours: Int, minutes: Int) = "%02dh %02dm A DAY =".format(hours, minutes)
    override fun years(value: Double) = "%.1f YEARS".format(value)
    override val ofYourLife = "of your life, over the next 30 years"
    override val whatItCouldBe = "WHAT IT COULD BE"
    override val now = "Now"
    override val target = "Target"
    override val targetNote =
        "A target, not a promise — the app only blocks what you tell it to."
}

object QuizEn : QuizStrings {
    override val hoursQuestion = "How many hours a day do you think you're on your phone?"
    override val pickupsQuestion = "And how many times a day do you pick it up?"
    override fun hrs(hours: Int) = "$hours HRS"
    override fun pickups(count: Int) = "${count}x"
    override val roughGuess = "A ROUGH GUESS IS FINE"
    override val wantItBack = "I want that back"
    override val continueLabel = "Continue"

    override val last7Days = "YOUR LAST 7 DAYS"
    override val heresTheTruth = "Here's the truth"
    override fun youGuessedHours(hours: Int) = "You guessed ${hours}h"
    override val actualDailyAverage = "is your actual daily average"
    override fun longestDay(hours: Int, minutes: Int) =
        "Longest day: %dh %02dm".format(hours, minutes)
    override fun youGuessedPickups(count: Int) = "You guessed ${count}x"
    override val pickedUpYesterday = "times you picked it up yesterday"
    override val topDistractions = "TOP DISTRACTIONS"

    override fun aDay(hours: Int, minutes: Int) = "%02dh %02dm A DAY =".format(hours, minutes)
    override fun years(value: Double) = "%.1f YEARS".format(value)
    override val ofYourLife = "of your life, over the next 30 years"
    override val whatItCouldBe = "WHAT IT COULD BE"
    override val now = "Now"
    override val target = "Target"
    override val targetNote =
        "A target, not a promise — the app only blocks what you tell it to."
}

interface FeedGuardStrings {
    val feeds: String
    val title: String
    val body: String
    val allOffNow: String
    val turnOnAccessibility: String
    val blockedLabel: String
    val runningLabel: String

    val reToggleTitle: String
    val reToggleBody: String

    val studyOnly: String
    val studyOnlyTitle: String
    val studyOnlyBody: String
    val channelNameHint: String
    val add: String
    val noChannels: String
    val remove: String
    val handleHint: String
    val footnote: String
    val done: String
}

object FeedGuardHi : FeedGuardStrings {
    override val feeds = "FEEDS"
    override val title = "App khuli, feed band"
    override val body =
        "YouTube pe lecture chalti rahegi, Shorts nahi. Instagram pe chat chalegi, " +
            "Reels nahi. Poori app band karne ki zaroorat nahi."
    override val allOffNow = "Ye sab abhi band hai"
    override val turnOnAccessibility =
        "Accessibility ON karo — tabhi app andar dekh paayegi ki Shorts " +
            "khuli hai ya lecture. Tap karke Settings kholo."
    override val blockedLabel = "BAND"
    override val runningLabel = "CHALU"

    override val reToggleTitle = "Ek baar Accessibility OFF karke wapas ON karo"
    override val reToggleBody =
        "Android service ki setting sirf ON karte waqt padhta hai. Isliye jab " +
            "guard mein kuch naya judta hai, purani permission chalu toh dikhti " +
            "hai par naya kaam nahi karti. Ye har update pe nahi — sirf tab jab " +
            "yahan ye likha ho."

    override val studyOnly = "STUDY ONLY"
    override val studyOnlyTitle = "Sirf study channels"
    override val studyOnlyBody = "Baaki channel ka video khulte hi shield aa jayega"
    override val channelNameHint = "Channel ka naam"
    override val add = "Add"
    override val noChannels =
        "Ek bhi channel nahi. Aise mein har video block ho jayega — " +
            "pehle apne teachers ke naam daalo."
    override val remove = "Hatao"
    override val handleHint =
        "Channel ka handle sabse pakka hai — YouTube pe video ke neeche " +
            "@ ke saath jo likha hota hai, wahi. Poora naam bhi chalega: " +
            "\"PW\" likhoge to \"PhysicsWallah\" bhi match karega."
    override val footnote =
        "Feeds tabhi rukti hain jab Shield on ho. Aur agar koi app apna update " +
            "laakar andar ka naam badal de, wo feed nikal sakti hai — tab batana, " +
            "list update kar denge."
    override val done = "Done"
}

object FeedGuardEn : FeedGuardStrings {
    override val feeds = "FEEDS"
    override val title = "App open, feed shut"
    override val body =
        "Lectures keep playing on YouTube, Shorts doesn't. Chat keeps working " +
            "on Instagram, Reels doesn't. No need to block the whole app."
    override val allOffNow = "All of these are off right now"
    override val turnOnAccessibility =
        "Turn Accessibility on — only then can the app tell whether Shorts is " +
            "open or a lecture is. Tap to open Settings."
    override val blockedLabel = "BLOCKED"
    override val runningLabel = "RUNNING"

    override val reToggleTitle = "Turn Accessibility off and back on once"
    override val reToggleBody =
        "Android reads a service's settings only when it is switched on. So " +
            "when something new is added to the guard, the old permission still " +
            "looks active but the new part does nothing. This isn't every " +
            "update — only when this message is here."

    override val studyOnly = "STUDY ONLY"
    override val studyOnlyTitle = "Study channels only"
    override val studyOnlyBody = "Any other channel's video hits the shield the moment it opens"
    override val channelNameHint = "Channel name"
    override val add = "Add"
    override val noChannels =
        "No channels yet. As it stands every video gets blocked — " +
            "add your teachers first."
    override val remove = "Remove"
    override val handleHint =
        "The channel handle is the surest thing — it's what sits under the " +
            "video on YouTube with an @ in front. A full name works too: type " +
            "\"PW\" and \"PhysicsWallah\" will match."
    override val footnote =
        "Feeds are only stopped while Shield is on. And if an app ships an " +
            "update that renames things inside, that feed can slip through — " +
            "tell us then and we'll update the list."
    override val done = "Done"
}
