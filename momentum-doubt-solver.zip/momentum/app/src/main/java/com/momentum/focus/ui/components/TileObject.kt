package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import kotlin.math.cos
import kotlin.math.sin

/** Which object to draw. */
enum class TileArt {
    Bolt, Journal, Shield, Coin, Wallet, Clock, Camera, Photo, Flame,
    Apps, Feed, Person, Calendar, Medal, Palette, Trophy,
}

/**
 * Tile objects, drawn rather than iconified.
 *
 * A Material icon is a flat glyph: one colour, one weight, no light on it. The
 * app this is modelled on builds its whole surface out of small solids sitting
 * on grid paper, and that only works if each one has a light side, a dark side
 * and something underneath it.
 *
 * Every object here is the same three passes — a cast shadow offset down and
 * right, a face filled with a diagonal gradient, and a highlight where light
 * would land — plus the Ink outline everything in this app wears. Nothing is
 * blurred: the shadow is a hard offset copy, which is the house rule and also
 * the only kind that survives on API 26.
 */
@Composable
fun TileObject(
    art: TileArt,
    fill: Color,
    size: Dp = 40.dp,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier.size(size)) {
        when (art) {
            TileArt.Bolt -> bolt(fill)
            TileArt.Journal -> journal(fill)
            TileArt.Shield -> shield(fill)
            TileArt.Coin -> coin(fill)
            TileArt.Wallet -> wallet(fill)
            TileArt.Clock -> clock(fill)
            TileArt.Camera -> camera(fill)
            TileArt.Photo -> photo(fill)
            TileArt.Flame -> flame(fill)
            TileArt.Apps -> apps(fill)
            TileArt.Feed -> feed(fill)
            TileArt.Person -> person(fill)
            TileArt.Calendar -> calendar(fill)
            TileArt.Medal -> medal(fill)
            TileArt.Palette -> palette(fill)
            TileArt.Trophy -> trophy(fill)
        }
    }
}

/** Light face, dark base — the gradient every solid here is filled with. */
private fun DrawScope.solid(fill: Color) = Brush.linearGradient(
    colors = listOf(
        lerp(fill, Color.White, 0.45f),
        fill,
        lerp(fill, Color.Black, 0.22f),
    ),
    start = Offset(0f, 0f),
    end = Offset(size.width, size.height),
)

/** The shadow pass. Drawn first, offset, flat and dark. */
private fun DrawScope.shadow(path: Path, depth: Float = 0.09f) {
    val d = size.minDimension * depth
    translate(left = d, top = d) {
        drawPath(path, color = Ink.copy(alpha = 0.38f))
    }
}

/** Face, then highlight, then outline. Every object ends this way. */
private fun DrawScope.finish(path: Path, fill: Color, highlight: Path? = null) {
    drawPath(path, brush = solid(fill))
    if (highlight != null) {
        drawPath(highlight, color = Color.White.copy(alpha = 0.38f))
    }
    drawPath(path, color = Ink, style = Stroke(width = size.minDimension * 0.075f))
}

/** Ben-Day dots — the comic print texture, not a gradient fake. */
private fun DrawScope.halftone(origin: Offset, span: Float, colour: Color) {
    val r = size.minDimension * 0.018f
    val gap = r * 3.2f
    var y = origin.y
    var row = 0
    while (y < origin.y + span) {
        var x = origin.x + if (row % 2 == 0) 0f else gap * 0.5f
        while (x < origin.x + span) {
            drawCircle(colour.copy(alpha = 0.28f), r, Offset(x, y))
            x += gap
        }
        y += gap
        row++
    }
}

/** Four short speed lines, like a POW burst without the word. */
private fun DrawScope.burst(center: Offset, radius: Float) {
    val rays = listOf(18f, 108f, 198f, 288f)
    rays.forEach { deg ->
        val a = Math.toRadians(deg.toDouble()).toFloat()
        val inner = Offset(
            center.x + cos(a) * radius * 0.72f,
            center.y + sin(a) * radius * 0.72f,
        )
        val outer = Offset(
            center.x + cos(a) * radius,
            center.y + sin(a) * radius,
        )
        drawLine(Ink, inner, outer, size.minDimension * 0.055f)
    }
}

private fun DrawScope.bolt(fill: Color) {
    val w = size.width
    val h = size.height
    val p = Path().apply {
        moveTo(w * 0.58f, h * 0.06f)
        lineTo(w * 0.24f, h * 0.55f)
        lineTo(w * 0.46f, h * 0.55f)
        lineTo(w * 0.40f, h * 0.94f)
        lineTo(w * 0.76f, h * 0.44f)
        lineTo(w * 0.54f, h * 0.44f)
        close()
    }
    shadow(p)
    // The lit edge runs down the left of the upper stroke, where a bolt this
    // shape would catch light.
    val lit = Path().apply {
        moveTo(w * 0.58f, h * 0.06f)
        lineTo(w * 0.24f, h * 0.55f)
        lineTo(w * 0.34f, h * 0.55f)
        lineTo(w * 0.62f, h * 0.14f)
        close()
    }
    finish(p, fill, lit)
}

private fun DrawScope.journal(fill: Color) {
    val w = size.width
    val h = size.height
    // A slab seen slightly from above: the cover is a parallelogram, the spine
    // is the darker side you can just see.
    val cover = Path().apply {
        moveTo(w * 0.20f, h * 0.16f)
        lineTo(w * 0.84f, h * 0.10f)
        lineTo(w * 0.84f, h * 0.80f)
        lineTo(w * 0.20f, h * 0.86f)
        close()
    }
    shadow(cover)
    val spine = Path().apply {
        moveTo(w * 0.20f, h * 0.16f)
        lineTo(w * 0.20f, h * 0.86f)
        lineTo(w * 0.10f, h * 0.78f)
        lineTo(w * 0.10f, h * 0.08f)
        close()
    }
    drawPath(spine, color = lerp(fill, Color.Black, 0.34f))
    drawPath(spine, color = Ink, style = Stroke(width = w * 0.06f))
    finish(cover, fill)
    // Two ruled lines, so it reads as something written in.
    val rule = Ink.copy(alpha = 0.30f)
    drawLine(rule, Offset(w * 0.32f, h * 0.38f), Offset(w * 0.72f, h * 0.34f), w * 0.045f)
    drawLine(rule, Offset(w * 0.32f, h * 0.54f), Offset(w * 0.72f, h * 0.50f), w * 0.045f)
}

private fun DrawScope.shield(fill: Color) {
    val w = size.width
    val h = size.height
    val p = Path().apply {
        moveTo(w * 0.50f, h * 0.06f)
        lineTo(w * 0.88f, h * 0.22f)
        lineTo(w * 0.88f, h * 0.52f)
        // The point is a curve, not a corner — a straight V reads as an arrow.
        cubicTo(w * 0.88f, h * 0.78f, w * 0.70f, h * 0.90f, w * 0.50f, h * 0.96f)
        cubicTo(w * 0.30f, h * 0.90f, w * 0.12f, h * 0.78f, w * 0.12f, h * 0.52f)
        lineTo(w * 0.12f, h * 0.22f)
        close()
    }
    shadow(p)
    val lit = Path().apply {
        moveTo(w * 0.50f, h * 0.06f)
        lineTo(w * 0.12f, h * 0.22f)
        lineTo(w * 0.12f, h * 0.52f)
        cubicTo(w * 0.12f, h * 0.66f, w * 0.24f, h * 0.76f, w * 0.36f, h * 0.82f)
        lineTo(w * 0.50f, h * 0.30f)
        close()
    }
    finish(p, fill, lit)
}

private fun DrawScope.coin(fill: Color) {
    val w = size.width
    val h = size.height
    val rx = w * 0.40f
    val ry = h * 0.24f
    val cy = h * 0.52f
    // A disc on edge: the rim below the face is what makes it a coin rather
    // than a circle.
    val rim = Path().apply {
        addOval(
            Rect(
                Offset(w * 0.10f, cy - ry + h * 0.14f),
                Size(rx * 2f, ry * 2f),
            ),
        )
    }
    shadow(rim)
    drawPath(rim, color = lerp(fill, Color.Black, 0.34f))
    drawPath(rim, color = Ink, style = Stroke(width = w * 0.07f))

    val face = Path().apply {
        addOval(
            Rect(
                Offset(w * 0.10f, cy - ry),
                Size(rx * 2f, ry * 2f),
            ),
        )
    }
    finish(face, fill)
    // An inner ring, the way a struck coin has one.
    drawOval(
        color = Ink.copy(alpha = 0.34f),
        topLeft = Offset(w * 0.10f + rx * 0.38f, cy - ry + ry * 0.38f),
        size = Size(rx * 1.24f, ry * 1.24f),
        style = Stroke(width = w * 0.045f),
    )
}

private fun DrawScope.wallet(fill: Color) {
    val w = size.width
    val h = size.height
    val body = Path().apply {
        addRoundRect(
            androidx.compose.ui.geometry.RoundRect(
                w * 0.10f, h * 0.32f, w * 0.90f, h * 0.88f,
                CornerRadius(w * 0.10f, w * 0.10f),
            ),
        )
    }
    shadow(body)
    finish(body, fill)
    val flap = Path().apply {
        addRoundRect(
            androidx.compose.ui.geometry.RoundRect(
                w * 0.10f, h * 0.22f, w * 0.90f, h * 0.48f,
                CornerRadius(w * 0.10f, w * 0.10f),
            ),
        )
    }
    finish(flap, lerp(fill, Color.Black, 0.16f))
    drawCircle(lerp(fill, Color.White, 0.35f), w * 0.07f, Offset(w * 0.72f, h * 0.66f))
    drawCircle(Ink, w * 0.07f, Offset(w * 0.72f, h * 0.66f), style = Stroke(width = w * 0.04f))
}

private fun DrawScope.clock(fill: Color) {
    val w = size.width
    val h = size.height
    val r = w * 0.38f
    val c = Offset(w * 0.50f, h * 0.54f)
    val body = Path().apply {
        addOval(
            Rect(
                Offset(c.x - r, c.y - r),
                Size(r * 2f, r * 2f),
            ),
        )
    }
    shadow(body)
    finish(body, fill)
    // The crown on top, which is what separates a timer from a plain circle.
    drawRoundRect(
        color = lerp(fill, Color.Black, 0.28f),
        topLeft = Offset(w * 0.42f, h * 0.04f),
        size = Size(w * 0.16f, h * 0.12f),
        cornerRadius = CornerRadius(w * 0.04f, w * 0.04f),
    )
    drawRoundRect(
        color = Ink,
        topLeft = Offset(w * 0.42f, h * 0.04f),
        size = Size(w * 0.16f, h * 0.12f),
        cornerRadius = CornerRadius(w * 0.04f, w * 0.04f),
        style = Stroke(width = w * 0.055f),
    )
    // Hands at ten past two — the angle every clock in every advert uses,
    // because it is the one that does not hide the face.
    drawLine(Ink, c, Offset(c.x + r * 0.42f, c.y - r * 0.34f), w * 0.065f)
    drawLine(Ink, c, Offset(c.x, c.y - r * 0.60f), w * 0.055f)
}

/** A box camera: body, top finder, round lens. Not a clock. */
private fun DrawScope.camera(fill: Color) {
    val w = size.width
    val h = size.height
    val body = Path().apply {
        moveTo(w * 0.10f, h * 0.38f)
        lineTo(w * 0.90f, h * 0.38f)
        lineTo(w * 0.90f, h * 0.86f)
        lineTo(w * 0.10f, h * 0.86f)
        close()
    }
    shadow(body)
    val roof = Path().apply {
        moveTo(w * 0.28f, h * 0.20f)
        lineTo(w * 0.62f, h * 0.20f)
        lineTo(w * 0.68f, h * 0.38f)
        lineTo(w * 0.22f, h * 0.38f)
        close()
    }
    drawPath(roof, color = lerp(fill, Color.Black, 0.22f))
    drawPath(roof, color = Ink, style = Stroke(width = w * 0.06f))
    finish(body, fill)
    halftone(Offset(w * 0.14f, h * 0.44f), w * 0.28f, Ink)
    burst(Offset(w * 0.50f, h * 0.62f), w * 0.48f)
    // Lens — the thing that stops this reading as a suitcase.
    val lens = Path().apply {
        addOval(Rect(Offset(w * 0.32f, h * 0.46f), Size(w * 0.36f, h * 0.32f)))
    }
    drawPath(lens, color = lerp(fill, Color.Black, 0.38f))
    drawPath(lens, color = Ink, style = Stroke(width = w * 0.055f))
    drawOval(
        color = Color.White.copy(alpha = 0.42f),
        topLeft = Offset(w * 0.40f, h * 0.52f),
        size = Size(w * 0.12f, h * 0.10f),
    )
    // Shutter button on the right shoulder.
    drawCircle(
        color = lerp(fill, Color.White, 0.20f),
        radius = w * 0.045f,
        center = Offset(w * 0.78f, h * 0.30f),
    )
    drawCircle(
        color = Ink,
        radius = w * 0.045f,
        center = Offset(w * 0.78f, h * 0.30f),
        style = Stroke(width = w * 0.04f),
    )
}

/** A polaroid sitting slightly off-square, picture on the face. */
private fun DrawScope.photo(fill: Color) {
    val w = size.width
    val h = size.height
    val card = Path().apply {
        moveTo(w * 0.16f, h * 0.14f)
        lineTo(w * 0.86f, h * 0.10f)
        lineTo(w * 0.90f, h * 0.88f)
        lineTo(w * 0.14f, h * 0.90f)
        close()
    }
    shadow(card)
    finish(card, lerp(fill, Color.White, 0.55f))
    val frame = Path().apply {
        moveTo(w * 0.24f, h * 0.20f)
        lineTo(w * 0.78f, h * 0.17f)
        lineTo(w * 0.80f, h * 0.66f)
        lineTo(w * 0.24f, h * 0.68f)
        close()
    }
    drawPath(frame, brush = solid(fill))
    halftone(Offset(w * 0.28f, h * 0.24f), w * 0.36f, Ink)
    drawPath(frame, color = Ink, style = Stroke(width = w * 0.05f))
    // Two hills and a sun — the cheapest way a rectangle becomes a photo.
    val hills = Path().apply {
        moveTo(w * 0.24f, h * 0.68f)
        lineTo(w * 0.40f, h * 0.46f)
        lineTo(w * 0.54f, h * 0.58f)
        lineTo(w * 0.68f, h * 0.42f)
        lineTo(w * 0.80f, h * 0.66f)
        close()
    }
    drawPath(hills, color = lerp(fill, Color.Black, 0.28f))
    drawCircle(
        color = Color.White.copy(alpha = 0.55f),
        radius = w * 0.055f,
        center = Offset(w * 0.66f, h * 0.30f),
    )
}

/** A short comic flame for the streak tile. */
private fun DrawScope.flame(fill: Color) {
    val w = size.width
    val h = size.height
    val outer = Path().apply {
        moveTo(w * 0.50f, h * 0.06f)
        cubicTo(w * 0.78f, h * 0.28f, w * 0.90f, h * 0.48f, w * 0.78f, h * 0.72f)
        cubicTo(w * 0.70f, h * 0.92f, w * 0.30f, h * 0.92f, w * 0.22f, h * 0.72f)
        cubicTo(w * 0.10f, h * 0.48f, w * 0.22f, h * 0.28f, w * 0.50f, h * 0.06f)
        close()
    }
    shadow(outer)
    finish(outer, fill)
    halftone(Offset(w * 0.28f, h * 0.42f), w * 0.30f, Ink)
    burst(Offset(w * 0.50f, h * 0.22f), w * 0.42f)
    val inner = Path().apply {
        moveTo(w * 0.50f, h * 0.38f)
        cubicTo(w * 0.64f, h * 0.50f, w * 0.66f, h * 0.62f, w * 0.58f, h * 0.76f)
        cubicTo(w * 0.54f, h * 0.84f, w * 0.46f, h * 0.84f, w * 0.42f, h * 0.76f)
        cubicTo(w * 0.34f, h * 0.62f, w * 0.36f, h * 0.50f, w * 0.50f, h * 0.38f)
        close()
    }
    drawPath(inner, color = Color.White.copy(alpha = 0.42f))
    drawPath(inner, color = Ink.copy(alpha = 0.55f), style = Stroke(width = w * 0.04f))
}

/** Four app tiles in a grid — not a bolt. */
private fun DrawScope.apps(fill: Color) {
    val w = size.width
    val h = size.height
    val cells = listOf(
        Offset(w * 0.12f, h * 0.14f) to lerp(fill, Color.White, 0.20f),
        Offset(w * 0.52f, h * 0.14f) to fill,
        Offset(w * 0.12f, h * 0.54f) to lerp(fill, Color.Black, 0.12f),
        Offset(w * 0.52f, h * 0.54f) to lerp(fill, Color.White, 0.08f),
    )
    val cw = w * 0.34f
    val ch = h * 0.32f
    cells.forEach { (o, c) ->
        val p = Path().apply {
            addRoundRect(
                androidx.compose.ui.geometry.RoundRect(
                    o.x, o.y, o.x + cw, o.y + ch,
                    CornerRadius(w * 0.07f, w * 0.07f),
                ),
            )
        }
        if (o == cells.first().first) shadow(p)
        finish(p, c)
    }
}

/** A phone with a play mark — feeds, not stacked notes. */
private fun DrawScope.feed(fill: Color) {
    val w = size.width
    val h = size.height
    val body = Path().apply {
        addRoundRect(
            androidx.compose.ui.geometry.RoundRect(
                w * 0.28f, h * 0.08f, w * 0.72f, h * 0.92f,
                CornerRadius(w * 0.08f, w * 0.08f),
            ),
        )
    }
    shadow(body)
    finish(body, fill)
    val play = Path().apply {
        moveTo(w * 0.42f, h * 0.36f)
        lineTo(w * 0.68f, h * 0.50f)
        lineTo(w * 0.42f, h * 0.64f)
        close()
    }
    drawPath(play, color = Color.White.copy(alpha = 0.85f))
    drawPath(play, color = Ink, style = Stroke(width = w * 0.05f))
}

/** Head + shoulders. Profiles. */
private fun DrawScope.person(fill: Color) {
    val w = size.width
    val h = size.height
    val head = Path().apply {
        addOval(Rect(Offset(w * 0.30f, h * 0.08f), Size(w * 0.40f, h * 0.38f)))
    }
    val body = Path().apply {
        moveTo(w * 0.16f, h * 0.92f)
        cubicTo(w * 0.16f, h * 0.58f, w * 0.84f, h * 0.58f, w * 0.84f, h * 0.92f)
        close()
    }
    shadow(body)
    finish(body, fill)
    finish(head, lerp(fill, Color.White, 0.12f))
}

/** A month grid, not a clock. */
private fun DrawScope.calendar(fill: Color) {
    val w = size.width
    val h = size.height
    val page = Path().apply {
        addRoundRect(
            androidx.compose.ui.geometry.RoundRect(
                w * 0.12f, h * 0.18f, w * 0.88f, h * 0.90f,
                CornerRadius(w * 0.08f, w * 0.08f),
            ),
        )
    }
    shadow(page)
    finish(page, fill)
    drawRect(
        color = lerp(fill, Color.Black, 0.28f),
        topLeft = Offset(w * 0.12f, h * 0.18f),
        size = Size(w * 0.76f, h * 0.18f),
    )
    drawRect(
        color = Ink,
        topLeft = Offset(w * 0.12f, h * 0.18f),
        size = Size(w * 0.76f, h * 0.18f),
        style = Stroke(width = w * 0.05f),
    )
    repeat(2) { ring ->
        drawRoundRect(
            color = Ink,
            topLeft = Offset(w * 0.30f + ring * w * 0.28f, h * 0.08f),
            size = Size(w * 0.12f, h * 0.16f),
            cornerRadius = CornerRadius(w * 0.04f),
            style = Stroke(width = w * 0.045f),
        )
    }
    val ink = Ink.copy(alpha = 0.45f)
    for (r in 0..1) for (c in 0..2) {
        drawCircle(
            ink,
            w * 0.035f,
            Offset(w * 0.30f + c * w * 0.20f, h * 0.56f + r * h * 0.16f),
        )
    }
}

private fun DrawScope.medal(fill: Color) {
    val w = size.width
    val h = size.height
    val ribbon = Path().apply {
        moveTo(w * 0.28f, h * 0.08f)
        lineTo(w * 0.50f, h * 0.38f)
        lineTo(w * 0.72f, h * 0.08f)
        lineTo(w * 0.62f, h * 0.08f)
        lineTo(w * 0.50f, h * 0.26f)
        lineTo(w * 0.38f, h * 0.08f)
        close()
    }
    finish(ribbon, lerp(fill, Color.Black, 0.15f))
    val disc = Path().apply {
        addOval(Rect(Offset(w * 0.22f, h * 0.32f), Size(w * 0.56f, h * 0.56f)))
    }
    shadow(disc)
    finish(disc, fill)
    drawCircle(Ink.copy(alpha = 0.35f), w * 0.14f, Offset(w * 0.50f, h * 0.60f), style = Stroke(width = w * 0.05f))
}

private fun DrawScope.palette(fill: Color) {
    val w = size.width
    val h = size.height
    val board = Path().apply {
        addOval(Rect(Offset(w * 0.10f, h * 0.16f), Size(w * 0.80f, h * 0.70f)))
    }
    shadow(board)
    finish(board, fill)
    drawCircle(Color(0xFFFF6B6B), w * 0.08f, Offset(w * 0.32f, h * 0.38f))
    drawCircle(Color(0xFFFFD84D), w * 0.08f, Offset(w * 0.52f, h * 0.32f))
    drawCircle(Color(0xFF3FE28F), w * 0.08f, Offset(w * 0.70f, h * 0.42f))
    drawCircle(Color(0xFF6FA8FF), w * 0.08f, Offset(w * 0.40f, h * 0.58f))
    drawCircle(Color.White.copy(alpha = 0.85f), w * 0.10f, Offset(w * 0.68f, h * 0.64f))
}

private fun DrawScope.trophy(fill: Color) {
    val w = size.width
    val h = size.height
    val cup = Path().apply {
        moveTo(w * 0.28f, h * 0.18f)
        lineTo(w * 0.72f, h * 0.18f)
        cubicTo(w * 0.78f, h * 0.40f, w * 0.68f, h * 0.55f, w * 0.50f, h * 0.58f)
        cubicTo(w * 0.32f, h * 0.55f, w * 0.22f, h * 0.40f, w * 0.28f, h * 0.18f)
        close()
    }
    shadow(cup)
    finish(cup, fill)
    val stem = Path().apply {
        addRoundRect(
            androidx.compose.ui.geometry.RoundRect(
                w * 0.42f, h * 0.56f, w * 0.58f, h * 0.74f,
                CornerRadius(w * 0.04f),
            ),
        )
    }
    finish(stem, lerp(fill, Color.Black, 0.12f))
    val base = Path().apply {
        addRoundRect(
            androidx.compose.ui.geometry.RoundRect(
                w * 0.26f, h * 0.72f, w * 0.74f, h * 0.88f,
                CornerRadius(w * 0.06f),
            ),
        )
    }
    finish(base, fill)
}
