package com.momentum.focus.ui.i18n

interface WelcomeStrings {
    val howItWorksLabel: String
    val howItWorksTitle: String
    val howItWorksBody: String

    val catchLabel: String
    val catchTitle: String
    val catchBody: String

    val dataLabel: String
    val dataTitle: String
    val dataBody: String

    val hardLabel: String
    val hardTitle: String
    val hardBody: String

    val lastThing: String
    val nameQuestion: String
    val namePlaceholder: String
    val youllSee: String
    fun welcomeBack(name: String): String
    val welcomeBackAnon: String

    val start: String
    val next: String
    val skip: String
}

object WelcomeHi : WelcomeStrings {
    override val howItWorksLabel = "KAAM KAISE KARTA HAI"
    override val howItWorksTitle = "Padhai hi paisa hai"
    override val howItWorksBody = "Ek minute padho, ek minute jama. App ke upar jo balance dikhta hai, " +
            "yahan bas wahi currency hai — aur padhai ke alawa usme kuch nahi jodta."

    override val catchLabel = "PECH YE HAI"
    override val catchTitle = "Distraction ka daam lagta hai"
    override val catchBody = "Scroll karne pe wahi kat-ta hai jo tumne jama kiya. Balance khaali, " +
            "app band. Kaunsi app is hisaab mein aati hai, wo tum chunte ho."

    override val dataLabel = "TUMHARA DATA"
    override val dataTitle = "Sab kuch is phone pe"
    override val dataBody =
        "Koi server nahi, koi account nahi, koi login nahi. Jo tum banate ho " +
            "wo yahin rehta hai. Baad mein app screen padhne ki permission " +
            "maangega — wo sirf ye dekhne ke liye hai ki Shorts khuli hai ya " +
            "nahi, aur wo kahin bhejta nahi."

    override val hardLabel = "JAB MUSHKIL HO"
    override val hardTitle = "Ek tap mein bahar"
    override val hardBody = "Ek urge das minute mein apne peak se utar jati hai. Panic dabao aur " +
            "us daurne wale khayal ke saath ruk jao — timer chalta rahega."

    override val lastThing = "AAKHRI BAAT"
    override val nameQuestion = "Tumhe kya bulaun?"
    override val namePlaceholder = "Tumhara naam"
    override val youllSee = "TUM DEKHOGE"
    override fun welcomeBack(name: String) = "Welcome back, $name."
    override val welcomeBackAnon = "Wapas aa gaye."

    override val start = "Chalo shuru"
    override val next = "Aage"
    override val skip = "Rehne do"
}

object WelcomeEn : WelcomeStrings {
    override val howItWorksLabel = "HOW IT WORKS"
    override val howItWorksTitle = "Focus is money"
    override val howItWorksBody =
        "Study a minute, bank a minute. That balance at the top of the app is " +
            "the only currency here, and nothing but studying adds to it."

    override val catchLabel = "THE CATCH"
    override val catchTitle = "Distraction costs"
    override val catchBody =
        "Scrolling costs what you banked. Empty balance, locked app. You set " +
            "that price now, while you are calm — not at midnight, mid-craving."

    override val dataLabel = "YOUR DATA"
    override val dataTitle = "All of it stays on this phone"
    override val dataBody =
        "No server, no account, no login. What you build here stays here. " +
            "The app will later ask permission to read the screen — that is " +
            "only to tell whether Shorts is open, and it sends nothing anywhere."

    override val hardLabel = "WHEN IT'S HARD"
    override val hardTitle = "One tap out"
    override val hardBody =
        "An urge peaks in about ten minutes. Hit Panic and wait it out with " +
            "something to hold onto. Slip anyway and it gets logged, not " +
            "judged — you delete the app that scolds you."

    override val lastThing = "LAST THING"
    override val nameQuestion = "What should I call you?"
    override val namePlaceholder = "Your name"
    override val youllSee = "YOU'LL SEE"
    override fun welcomeBack(name: String) = "Welcome back, $name."
    override val welcomeBackAnon = "Welcome back."

    override val start = "Start"
    override val next = "Next"
    override val skip = "Skip"
}

interface PermissionStrings {
    val setup: String
    val title: String
    val body: String
    fun progress(done: Int, total: Int): String
    val required: String
    val optional: String
    val crownExtras: String
    val on: String
    val requiredForCrown: String

    val deviceAdmin: String
    val deviceAdminOn: String
    val deviceAdminOff: String

    val shortsGuard: String
    val shortsGuardOn: String
    val shortsGuardOff: String
    val shortsGuardHint: String

    val killsBackground: String
    val autostart: String
    val autostartBody: String

    val start: String
    val grantFirst: String
    val mustHave: String
    val grant: String
}

object PermissionHi : PermissionStrings {
    override val setup = "SETUP"
    override val title = "Give it control"
    override val body =
        "Blocking apps needs real permissions. Nothing leaves your phone — " +
            "there is no server."
    override fun progress(done: Int, total: Int) = "$done / $total zaroori"
    override val required = "REQUIRED"
    override val optional = "OPTIONAL"
    override val crownExtras = "HARD / CROWN — ye do bhi chahiye"
    override val on = "ON"
    override val requiredForCrown = "REQUIRED FOR CROWN"

    override val deviceAdmin = "Device admin"
    override val deviceAdminOn =
        "Uninstall ke liye pehle yahi permission band karni padegi. " +
            "Ek extra kadam, deewar nahi."
    override val deviceAdminOff =
        "Crown mode iske bina on nahi hoga. Uninstall mushkil " +
            "banata hai — factory reset phir bhi kaam karta hai."

    override val shortsGuard = "Shorts / Reels guard"
    override val shortsGuardOn =
        "Shorts aur Reels band, lecture aur chat chalti rahegi."
    override val shortsGuardOff =
        "Iske bina baaki sab chalega — sirf Shorts aur Reels nahi rukengi. " +
            "Poori app band karni ho to wo Block se hota hai."
    override val shortsGuardHint =
        "Toggle wapas off ho jaaye to: App info → ⋮ upar right → " +
            "\"Allow restricted settings\" → phir dobara try karo."

    override val killsBackground = "THIS PHONE KILLS BACKGROUND APPS"
    override val autostart = "Autostart"
    override val autostartBody =
        "Iske bina Shield raat mein chup ho jaati hai. Android is switch ko " +
            "padhne nahi deta, isliye app confirm nahi kar sakta — khud check karna."

    override val start = "Start"
    override val grantFirst = "Grant required first"
    override val mustHave = "Usage + overlay + battery — teeno must. Tab tak aage nahi."
    override val grant = "GRANT"
}

object PermissionEn : PermissionStrings {
    override val setup = "SETUP"
    override val title = "Give it control"
    override val body =
        "Blocking apps needs real permissions. Nothing leaves your phone — " +
            "there is no server."
    override fun progress(done: Int, total: Int) = "$done / $total required"
    override val required = "REQUIRED"
    override val optional = "OPTIONAL"
    override val crownExtras = "HARD / CROWN — these two as well"
    override val on = "ON"
    override val requiredForCrown = "REQUIRED FOR CROWN"

    override val deviceAdmin = "Device admin"
    override val deviceAdminOn =
        "Uninstalling means turning this permission off first. " +
            "One extra step, not a wall."
    override val deviceAdminOff =
        "Crown mode won't turn on without this. It makes uninstalling hard — " +
            "a factory reset still works."

    override val shortsGuard = "Shorts / Reels guard"
    override val shortsGuardOn =
        "Shorts and Reels blocked; lectures and chat keep working."
    override val shortsGuardOff =
        "Everything else still works without this — only Shorts and Reels " +
            "won't be stopped. To block a whole app, use Block instead."
    override val shortsGuardHint =
        "If the toggle flips back off: App info → ⋮ top right → " +
            "\"Allow restricted settings\" → then try again."

    override val killsBackground = "THIS PHONE KILLS BACKGROUND APPS"
    override val autostart = "Autostart"
    override val autostartBody =
        "Without this, Shield goes quiet overnight. Android won't let the app " +
            "read this switch, so it can't confirm — check it yourself."

    override val start = "Start"
    override val grantFirst = "Grant required first"
    override val mustHave = "Usage + overlay + battery — all three. No further until then."
    override val grant = "GRANT"
}
