package com.momentum.focus.ai

import com.momentum.focus.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * The one place the app talks to a model.
 *
 * HttpURLConnection and org.json, matching [com.momentum.focus.ui.util.Updater],
 * so this adds no dependency. Nothing here is on the blocking path of anything
 * — both callers treat a failure as "no answer this time" and carry on.
 *
 * ## The key
 * [BuildConfig.AI_KEY] comes from local.properties or CHUTES_API_KEY at build
 * time. When it is blank [enabled] is false and every entry point in the app
 * hides itself. A build made without the secret has no AI in it at all, which
 * is the only guarantee worth having: an APK cannot leak a key it never held.
 *
 * This is not a substitute for a server. Anyone holding an APK that *was*
 * built with a key can pull it out — so a key must never go into a build that
 * is handed to strangers, and this must not ship in the version that is sold.
 */
object Ai {

    private const val URL_CHAT = "https://llm.chutes.ai/v1/chat/completions"

    /**
     * Text-to-image, on its own host with its own shape.
     *
     * Not the chat endpoint and not OpenAI-compatible: the body is flat and the
     * reply is raw JPEG bytes rather than JSON. Same key.
     *
     * Only ever used for backdrops. Chutes' own notes on this chute say it is
     * not built for rendering text inside an image, which is the whole reason
     * every number on a shared card is drawn by us afterwards instead of asked
     * for in the prompt.
     */
    private const val URL_IMAGE = "https://vonkaiser-imageclassic.chutes.ai/image/flux"

    /**
     * Chutes' own guidance is to read the live catalogue rather than pin an id,
     * because their line-up moves. This is the fallback for when that read
     * fails; [modelOverride] lets a debug screen point at something else
     * without a rebuild.
     */
    /**
     * Chat model, chosen for speed.
     *
     * Not a reasoning model, and that is the whole point. Qwen3-32B was tried
     * here and it is a *thinking* model: it spends tokens on hidden reasoning
     * before it writes anything. With a tight max_tokens it spent the entire
     * budget thinking and returned an empty content field — which is exactly
     * the blank reply bubbles, and exactly the slowness, since every one of
     * those wasted tokens still had to be generated.
     *
     * gemma-4-turbo writes its first word immediately. DeepSeek stays second
     * in the pool so a busy hour falls back rather than failing.
     */
    private const val DEFAULT_MODEL = "google/gemma-4-31B-turbo-TEE,deepseek-ai/DeepSeek-V3.2-TEE"

    /** Used when a turn carries a photo or a rendered PDF page. */
    private const val VISION_MODEL = "google/gemma-4-31B-turbo-TEE"

    @Volatile
    var modelOverride: String? = null

    val enabled: Boolean get() = BuildConfig.AI_ENABLED && BuildConfig.AI_KEY.isNotBlank()

    /** A failure that the UI can show without pretending it was an answer. */
    class AiError(message: String) : Exception(message)

    /**
     * One message in a conversation.
     *
     * The coach only ever sends one of these; the doubt sheet sends a handful,
     * because a follow-up like "aur simple" means nothing without the answer
     * it is following up on.
     */
    data class Turn(
        val fromUser: Boolean,
        val text: String,
        /** JPEG/PNG as base64, only on a user turn that carries a page photo. */
        val imageB64: String? = null,
        val imageMime: String = "image/jpeg",
        /** Extra pages after [imageB64]. Cap is five including the first. */
        val more: List<String> = emptyList(),
        /**
         * True when the pages on this turn were carried over from an earlier
         * question rather than attached to this one.
         *
         * The model still needs them — context() strips images from every
         * history turn, so a follow-up that does not resend the page is asking
         * about a photo nobody can see. But the chat should not draw a
         * thumbnail on a message the user typed without attaching anything.
         * That is why the same screenshot appeared stuck to three messages in
         * a row.
         */
        val carried: Boolean = false,
    ) {
        val allImages: List<String> get() = listOfNotNull(imageB64) + more
    }

    /**
     * One generated image, as JPEG bytes.
     *
     * FLUX-schnell is distilled for a handful of steps, so four is the right
     * number rather than a cheap one — more does not improve it. Negative
     * prompts are ignored by this model, so exclusions belong in the prompt
     * itself.
     */
    suspend fun image(
        prompt: String,
        width: Int = 1024,
        height: Int = 1024,
        seed: Int? = null,
    ): ByteArray = withContext(Dispatchers.IO) {
        if (!enabled) throw AiError("No API key in this build.")

        val body = JSONObject().apply {
            put("prompt", prompt)
            put("width", width)
            put("height", height)
            put("num_inference_steps", 4)
            put("guidance_scale", 3.5)
            if (seed != null) put("seed", seed)
        }.toString()

        val conn = (URL(URL_IMAGE).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            // Longer than chat: a diffusion chute may be cold, and the whole
            // point of this call is that it happens once.
            readTimeout = 90_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer ${BuildConfig.AI_KEY}")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "image/jpeg")
        }
        val onCancel = coroutineContext[Job]?.invokeOnCompletion { conn.disconnect() }
        try {
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val detail = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw AiError(shortReason(code, detail))
            }
            conn.inputStream.use { it.readBytes() }
        } finally {
            onCancel?.dispose()
            conn.disconnect()
        }
    }

    /**
     * One round trip with a single question. Returns the assistant's text.
     *
     * [json] asks the model to reply with an object and nothing else, which is
     * what the coach needs and the doubt sheet does not.
     */
    suspend fun ask(
        system: String,
        user: String,
        maxTokens: Int = 900,
        temperature: Double = 0.4,
        json: Boolean = false,
    ): String = chat(
        system = system,
        turns = listOf(Turn(fromUser = true, text = user)),
        maxTokens = maxTokens,
        temperature = temperature,
        json = json,
    )

    /**
     * One round trip carrying a conversation.
     *
     * Cancellable, and that is the point rather than a nicety: the doubt
     * sheet's send button turns into a stop button while an answer is on its
     * way, and a stop button that leaves the request running would be a lie
     * told in the one place the app asks to be trusted. Cancelling the
     * coroutine disconnects the socket, which unblocks the read instead of
     * leaving a thread parked on it for the rest of the read timeout.
     */
    suspend fun chat(
        system: String,
        turns: List<Turn>,
        maxTokens: Int = 900,
        temperature: Double = 0.4,
        json: Boolean = false,
        onDelta: ((String) -> Unit)? = null,
    ): String = withContext(Dispatchers.IO) {
        if (!enabled) throw AiError("No API key in this build.")

        val wantsVision = turns.any { it.allImages.isNotEmpty() }
        val model = modelOverride
            ?: if (wantsVision && !json) VISION_MODEL else DEFAULT_MODEL
        val body = JSONObject().apply {
            put("model", model)
            put("max_tokens", maxTokens)
            put("temperature", temperature)
            // Streaming, and this is the fix for "timeout", not a nicety.
            //
            // readTimeout on HttpURLConnection applies to each read, not to
            // the request as a whole. With stream off the server sends
            // nothing at all until the last token is generated, so the first
            // read blocks for the entire generation — and an answer that took
            // longer than the eighteen seconds below died on the socket with
            // nothing to show for it. That is every "timeout" on the screen.
            //
            // Streaming turns one long block into a chunk every few tokens,
            // and each chunk resets the clock. The timeout stops meaning "the
            // answer was slow" and starts meaning "the connection died",
            // which is what a timeout should have meant all along.
            //
            // It also fixes the slowness, which was never really slowness:
            // the first word now lands in about a second instead of the
            // screen sitting empty until the whole paragraph exists.
            put("stream", true)
            put(
                "messages",
                JSONArray().apply {
                    put(JSONObject().put("role", "system").put("content", system))
                    turns.forEach { turn ->
                        val msg = JSONObject().put("role", if (turn.fromUser) "user" else "assistant")
                        val pics = turn.allImages
                        if (pics.isNotEmpty() && turn.fromUser) {
                            val parts = JSONArray()
                            if (turn.text.isNotBlank()) {
                                parts.put(JSONObject().put("type", "text").put("text", turn.text))
                            } else {
                                parts.put(
                                    JSONObject().put("type", "text")
                                        .put("text", "Read these pages and answer the doubt on them."),
                                )
                            }
                            pics.take(5).forEach { img ->
                                parts.put(
                                    JSONObject()
                                        .put("type", "image_url")
                                        .put(
                                            "image_url",
                                            JSONObject().put(
                                                "url",
                                                "data:${turn.imageMime};base64,$img",
                                            ),
                                        ),
                                )
                            }
                            msg.put("content", parts)
                        } else {
                            msg.put("content", turn.text)
                        }
                        put(msg)
                    }
                },
            )
            if (json) put("response_format", JSONObject().put("type", "json_object"))
        }.toString()

        val conn = (URL(URL_CHAT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 5_000
            // Per-chunk, not per-answer. See the stream flag above.
            //
            // These used to be a budget for the entire generation, which is
            // why they had to be so different from each other and why the text
            // one was still too small: eighteen seconds had to cover a whole
            // paragraph being written before a single byte came back.
            //
            // Now the clock restarts on every chunk, so what these actually
            // measure is how long to wait for the *next* piece. A vision model
            // reading five pages still thinks for a while before its first
            // token, and a cold chute takes longer to wake, so the gap before
            // the stream opens is what these have to cover — not the length of
            // the answer. A long reply no longer costs more than a short one.
            readTimeout = when {
                wantsVision -> 60_000
                json -> 45_000
                else -> 30_000
            }
            doOutput = true
            setRequestProperty("Authorization", "Bearer ${BuildConfig.AI_KEY}")
            setRequestProperty("Content-Type", "application/json")
        }

        // disconnect() from another thread is what actually interrupts a
        // blocking read. The handle is disposed in the finally below, so this
        // only ever fires on a real cancellation.
        val onCancel = coroutineContext[Job]?.invokeOnCompletion { conn.disconnect() }

        try {
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            if (code !in 200..299) {
                // The error stream carries the reason — a bad key, a spent cap,
                // an unknown model. Swallowing it would leave nothing to debug.
                val detail = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw AiError(shortReason(code, detail))
            }
            val text = conn.inputStream.bufferedReader().use { reader ->
                readStream(reader, onDelta)
            }
            text.trim()
        } finally {
            onCancel?.dispose()
            conn.disconnect()
        }
    }

    /**
     * Server-sent events, folded back into one string.
     *
     * The wire format is a line per event: `data: {json}`, blank lines between
     * them, and a final `data: [DONE]`. Each JSON carries
     * choices[0].delta.content — usually a word or part of one.
     *
     * Malformed events are skipped rather than thrown on. A provider that
     * sends a keep-alive comment or a partial line should not lose an answer
     * that is otherwise arriving fine, and the difference between "the reply
     * is a bit short" and "timeout" is the whole point of this change.
     *
     * [onDelta] is called on the IO thread as text arrives, so callers that
     * want to render progressively must hop to the main thread themselves.
     */
    private fun readStream(
        reader: java.io.BufferedReader,
        onDelta: ((String) -> Unit)?,
    ): String {
        val out = StringBuilder()
        while (true) {
            val line = reader.readLine() ?: break
            if (line.isBlank()) continue
            if (!line.startsWith("data:")) continue
            val payload = line.removePrefix("data:").trim()
            if (payload == "[DONE]") break
            val piece = runCatching {
                val choices = JSONObject(payload).optJSONArray("choices") ?: return@runCatching ""
                if (choices.length() == 0) return@runCatching ""
                val choice = choices.getJSONObject(0)
                // delta while streaming; message is what a provider sends if
                // it ignored the stream flag and answered in one block, which
                // costs one line to survive and would otherwise come back as
                // an empty reply bubble.
                val holder = choice.optJSONObject("delta") ?: choice.optJSONObject("message")
                // Not holder?.optString("content").orEmpty() — delta/message is
                // still the right fallback pair, but optString has a specific
                // trap on the content key itself: org.json's optString(key)
                // does not fall through to the default when the key is present
                // with an explicit JSON null value. It returns the Java string
                // "null". A provider's last chunk before finish_reason is often
                // exactly {"delta":{"content":null}}, so that literal four-letter
                // word was passing isNotEmpty() and landing in the answer. That
                // is the "Hey! Kaisa chal raha hai?null" in the screenshot — not
                // a model mistake, a parser one.
                //
                // isNull(key) is the correct check: true for a missing key or an
                // explicit JSON null, in which case the piece is empty.
                if (holder == null || holder.isNull("content")) "" else holder.getString("content")
            }.getOrDefault("")
            if (piece.isNotEmpty()) {
                out.append(piece)
                onDelta?.invoke(piece)
            }
        }
        if (out.isEmpty()) {
            // An empty stream is a failure, not an answer. Returning "" here
            // would put a blank bubble on screen and look like the model had
            // nothing to say.
            throw AiError("The model sent nothing back. Try again.")
        }
        return out.toString()
    }

    /** Turns a status code into something worth putting on a screen. */
    private fun shortReason(code: Int, detail: String): String = when (code) {
        401, 403 -> "Key rejected. Check chutes.key in local.properties."
        402 -> "Chutes credits are spent."
        404 -> "That model id isn't on Chutes any more."
        429 -> "Rate limit or cap hit. Try again later."
        in 500..599 -> "Chutes is having trouble. Try again."
        else -> "Request failed ($code). ${detail.take(120)}"
    }

    /**
     * Strips the code fence some models wrap JSON in, so the caller can parse
     * without caring which model answered.
     */
    fun unfence(raw: String): String = raw
        .removePrefix("```json").removePrefix("```")
        .removeSuffix("```")
        .trim()
}
