package com.momentum.focus.data

import java.time.LocalDate

/** The four things the score is made of, so the number can be argued with. */
enum class SuccessPart { Consistency, Finishing, Volume, Balance }

data class SuccessScore(
    val total: Int,
    val parts: Map<SuccessPart, Int>,
    val weakest: SuccessPart,
    /** False until there is a single session to read. */
    val hasData: Boolean,
)

/**
 * One number for how the last month went.
 *
 * A score is a claim, so this one is built to be checkable: four parts worth 25
 * each, every part read off something already stored, and the weakest part
 * named on the card so the number always comes with the reason for it. A score
 * nobody can take apart is a score nobody should believe.
 *
 * Phone time is deliberately not in it. It is the app's loudest number and it
 * would have been the obvious fifth part, but it is only available if usage
 * access was granted — so scoring it would quietly punish everyone who skipped
 * that permission, for something they did not do wrong. It stays a fact the
 * cards show, not a mark out of 25.
 */
object Success {

    private const val PART_MAX = 25

    /** Two weeks of unbroken days is full marks. Beyond that it stops paying. */
    private const val STREAK_TARGET = 14

    /** Fifty minutes a day across a month. Real, and not a fantasy target. */
    private const val MINUTES_TARGET = 1500

    private const val WINDOW_DAYS = 30

    fun of(data: AppData): SuccessScore {
        val today = LocalDate.now().toEpochDay()
        val recent = data.sessions.filter { today - it.startedAtEpochDay <= WINDOW_DAYS }
        val done = recent.filter { it.completed }
        val minutes = done.sumOf { it.minutes }

        val touched = data.subjects.count { subject -> done.any { it.subject == subject } }

        val parts = mapOf(
            SuccessPart.Consistency to scaled(data.streakDays, STREAK_TARGET),
            // Finishing, not starting. Abandoning is the habit this app is
            // built against, so it costs the same as never sitting down.
            SuccessPart.Finishing to
                if (recent.isEmpty()) 0 else PART_MAX * done.size / recent.size,
            SuccessPart.Volume to scaled(minutes, MINUTES_TARGET),
            // Untouched subjects are the thing nobody notices until the exam.
            SuccessPart.Balance to
                if (data.subjects.isEmpty()) 0 else PART_MAX * touched / data.subjects.size,
        )

        return SuccessScore(
            total = parts.values.sum(),
            parts = parts,
            weakest = parts.minByOrNull { it.value }?.key ?: SuccessPart.Volume,
            // No sessions means no score, not a zero. A zero out of a hundred
            // on the day someone installs the app is not a measurement, it is
            // an insult with a number on it.
            hasData = recent.isNotEmpty(),
        )
    }

    private fun scaled(value: Int, target: Int): Int =
        (PART_MAX * value / target).coerceIn(0, PART_MAX)
}
