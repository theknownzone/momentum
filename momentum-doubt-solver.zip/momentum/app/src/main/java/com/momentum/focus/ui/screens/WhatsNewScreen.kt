package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.FocusLevels
import com.momentum.focus.ui.i18n.Strings
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.theme.*

/**
 * Shown once after an update lands, then never again for that version.
 *
 * Written per release rather than generated, because "bug fixes and
 * improvements" tells nobody anything and is the reason people stop reading
 * changelogs at all.
 */
object Changelog {

    /**
     * Bumped by hand whenever there is something worth announcing.
     *
     * Keying this off the build number never worked: builds are numbered by CI
     * at push time, so the code could not know its own number and every
     * update fell back to the same stale entry. A counter the source controls
     * is the only version of this that can be correct.
     */
    /**
     * Bump this whenever the bundled list below changes, so the screen shows
     * again. Live release notes are preferred; this is the offline fallback.
     */
    const val LATEST = 10

    /**
     * Built from the string table rather than held as a static list. A top
     * level val is fixed at class-init, long before the language is known.
     */
    fun entries(str: Strings): List<Pair<String, List<String>>> = listOf(
        str.whatsNew.sectionNew to listOf(
            str.whatsNew.newStudyChannels,
            str.whatsNew.newAutoAsk,
            str.whatsNew.newLevelUpOnly,
            str.whatsNew.newSaveButton,
            str.whatsNew.newSubjectFromFocus,
            str.whatsNew.newExamNews,
            str.whatsNew.newHelpSection,
            str.whatsNew.newPremium,
        ),
        str.whatsNew.sectionFixed to listOf(
            str.whatsNew.fixedTimerSurvives(),
            str.whatsNew.fixedRateUpfront,
            str.whatsNew.fixedLightEarns(FocusLevels.NO_BLOCK),
            str.whatsNew.fixedShortsSplitScreen,
            str.whatsNew.fixedGuardDebug,
            str.whatsNew.fixedLaunchCrash,
            str.whatsNew.fixedCalendarCard,
            str.whatsNew.fixedUpdateInPlace,
        ),
    )
}

/**
 * Turns a markdown release body into headed lists.
 *
 * A heading is any `##` line or a bare short line ending in a colon; anything
 * starting with a dash or bullet is an item. Text that fits neither is dropped
 * rather than guessed at — a release note with no structure should fall back
 * to the bundled list, not render as one long unreadable block.
 */
private fun parseNotes(body: String): List<Pair<String, List<String>>>? {
    // Deliberately not a markdown parser any more.
    //
    // The first version only kept lines that began with a dash or a hash and
    // silently dropped everything else, which meant release notes written as
    // ordinary sentences with emoji — the way they are actually written —
    // arrived as a single leftover line about the full changelog. Losing the
    // author's words to make them fit a shape is worse than showing the shape
    // they chose.
    //
    // So: their text, their order, their emoji. Only the two things that would
    // look like debris on screen are removed — bold asterisks, and GitHub's
    // auto-appended compare link, which is a URL nobody is going to type off a
    // phone.
    val lines = body.lines()
        .map { it.trim().removePrefix("- ").removePrefix("* ").removePrefix("• ") }
        .map { it.replace("**", "").replace("__", "") }
        .filter { it.isNotBlank() }
        .filterNot { it.startsWith("Full Changelog", ignoreCase = true) }
        .filterNot { it.startsWith("https://") }

    if (lines.isEmpty()) return null

    val sections = mutableListOf<Pair<String, MutableList<String>>>()
    lines.forEach { line ->
        // A heading is a hash line, or a short line ending in a colon. Anything
        // else is content and is kept verbatim.
        val isHeading = line.startsWith("#") ||
            (line.endsWith(":") && line.length < 40)
        if (isHeading) {
            sections += line.trimStart('#', ' ').trimEnd(':').trim() to mutableListOf()
        } else {
            if (sections.isEmpty()) sections += "" to mutableListOf()
            sections.last().second += line
        }
    }
    val clean = sections.filter { it.second.isNotEmpty() }
        .map { it.first to it.second.toList() }
    return clean.ifEmpty { null }
}


@Composable
fun WhatsNewScreen(version: String, onDone: () -> Unit) {
    val str = strings()
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 40.dp, bottom = 24.dp),
    ) {
        Text(
            str.whatsNew.justUpdated,
            style = MaterialTheme.typography.labelSmall,
            color = Mint.accent,
        )
        Text(
            str.whatsNew.title,
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            str.whatsNew.version(version),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(20.dp))

        // The whole published history, newest first — not just the release
        // that happened to be current. Someone who skipped two versions saw
        // only the third and had no way to find out what they missed, which
        // makes this a notice rather than a log.
        val history by produceState<List<Updater.Entry>?>(initialValue = null) {
            value = runCatching { Updater.history() }.getOrNull()
        }

        when {
            history == null -> Text(
                str.whatsNew.loading,
                style = MaterialTheme.typography.bodyLarge,
                color = InkMid,
            )

            history!!.isEmpty() -> {
                // No releases published yet, or offline. The bundled list is
                // what ships in the APK and it is at least true of this build.
                Changelog.entries(str).forEachIndexed { i, (heading, lines) ->
                    NoteBlock(stickerFor(i), heading, lines)
                }
            }

            else -> history!!.forEachIndexed { idx, entry ->
                // Version and date as a spine down the left, so a long log
                // reads as a list of releases rather than a wall of bullets.
                Row(
                    Modifier.padding(bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (idx == 0) Mint.fill else Sunk)
                            .border(2.dp, Ink, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 3.dp),
                    ) {
                        Text(
                            entry.version,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Ink,
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        entry.date,
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                    )
                    if (idx == 0) {
                        Spacer(Modifier.width(8.dp))
                        Text(
                            str.whatsNew.current,
                            style = MaterialTheme.typography.labelSmall,
                            color = Mint.accent,
                        )
                    }
                }
                parseNotes(entry.notes).forEachIndexed { i, (heading, lines) ->
                    NoteBlock(stickerFor(idx + i), heading, lines)
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        SquishButton(
            label = str.whatsNew.gotIt,
            sticker = Mint,
            modifier = Modifier.fillMaxWidth(),
            onClick = onDone,
        )
    }
}

/** One headed group of lines from a release note. */
@Composable
private fun NoteBlock(sticker: Sticker, heading: String, lines: List<String>) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = Paper.Gap)
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(sticker.fill)
            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
            .padding(16.dp),
    ) {
        // A release note with no headings gets no empty label bar.
        if (heading.isNotBlank()) {
            Text(
                heading.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = sticker.on.copy(alpha = 0.75f),
            )
            Spacer(Modifier.height(8.dp))
        }
        lines.forEach { line ->
            Row(Modifier.padding(vertical = 3.dp)) {
                Text(
                    "—",
                    style = MaterialTheme.typography.bodyLarge,
                    color = sticker.on.copy(alpha = 0.6f),
                )
                Spacer(Modifier.width(8.dp))
                Text(line, style = MaterialTheme.typography.bodyLarge, color = sticker.on)
            }
        }
    }
}
