package com.momentum.focus.data

import com.momentum.focus.BuildConfig
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Offline licence keys.
 *
 * Keys look like MOM-4K7QX-9WBTZ-H2NRD. The first two groups are random, the
 * third is a short HMAC of them under a shared secret, so the app can tell a
 * real key from a typo without ever contacting a server. That matters here:
 * the app has no backend, works with the network off, and asking someone to be
 * online to prove they paid would break it in exactly the places people use it.
 *
 * This is crackable. The secret ships inside the APK, so anyone willing to
 * decompile it can mint their own keys, and no client-side scheme avoids that —
 * only a server does. Every indie desktop and sideloaded app in this category
 * has the same property. It stops casual key sharing, which is what it is for.
 * If revenue ever justifies a server, move validation there and keep this as
 * the offline fallback.
 */
object License {

    /**
     * Injected at build time from `license.secret` in local.properties, or the
     * MOMENTUM_LICENSE_SECRET environment variable in CI.
     *
     * It was a const in this file, which put it in a public repo — the one
     * value the whole scheme rests on was readable by anyone browsing the
     * source, no decompiling needed. Decompiling still gets it, and that is
     * unavoidable without a backend; this only removes the free version of the
     * attack.
     *
     * The fallback is the placeholder this shipped with, so builds with no
     * secret configured behave exactly as before and keys issued so far keep
     * working. Setting a real secret invalidates every key minted under the
     * placeholder — which is the intended effect, and the reason to do it
     * before selling rather than after.
     */
    private val SECRET: String =
        BuildConfig.LICENSE_SECRET.takeIf { it.isNotBlank() }
            ?: "momentum-change-me-before-selling"

    private const val ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
    private const val PREFIX = "MOM"

    /**
     * True if [raw] is a well-formed key whose checksum matches.
     *
     * Case and dashes are ignored because people retype these from an email on
     * a phone keyboard, and rejecting a correct key over a lowercase letter is
     * a support ticket that should never exist.
     */
    fun isValid(raw: String): Boolean {
        val k = normalise(raw)
        if (!k.startsWith(PREFIX)) return false
        val body = k.removePrefix(PREFIX)
        if (body.length != 15) return false
        if (body.any { it !in ALPHABET }) return false
        val payload = body.take(10)
        val given = body.drop(10)
        return given == checksum(payload)
    }

    /** Strips spaces, dashes and case so a retyped key still matches. */
    fun normalise(raw: String): String =
        raw.uppercase().filter { it.isLetterOrDigit() }

    /** Formats a bare key back into MOM-XXXXX-XXXXX-XXXXX for display. */
    fun pretty(raw: String): String {
        val k = normalise(raw)
        if (k.length != 18) return raw
        return "${k.take(3)}-${k.drop(3).take(5)}-${k.drop(8).take(5)}-${k.drop(13)}"
    }

    private fun checksum(payload: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(SECRET.toByteArray(), "HmacSHA256"))
        val digest = mac.doFinal(payload.toByteArray())
        return buildString {
            for (i in 0 until 5) {
                append(ALPHABET[(digest[i].toInt() and 0xFF) % ALPHABET.length])
            }
        }
    }

    /**
     * Mints a key for a given payload. Present so the format has exactly one
     * definition — the seller-side generator must produce what [isValid] reads.
     */
    fun mint(payload10: String): String {
        require(payload10.length == 10 && payload10.all { it in ALPHABET }) {
            "payload must be 10 characters from the alphabet"
        }
        return pretty(PREFIX + payload10 + checksum(payload10))
    }
}
