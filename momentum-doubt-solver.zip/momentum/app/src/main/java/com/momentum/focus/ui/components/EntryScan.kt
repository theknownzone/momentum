package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.abs

/**
 * A halftone scan-line, sweeping down the screen once when this modifier's
 * host first enters composition.
 *
 * Same printed-dot material as the MyAi tab's own glow in [liquidGlow] —
 * full-strength colour carried by dot size, not a smooth gradient wash — so
 * this reads as the same effect the user is already looking at on the tab
 * they just tapped, rather than a second, different-looking animation
 * arriving on the screen behind it.
 *
 * Only a band around the current line is drawn, not the whole screen. A 3dp
 * grid across the full display would be tens of thousands of dots redrawn
 * every frame; restricting the loop to the rows the line is actually near
 * keeps the per-frame count in the same few-hundred range the tab pill uses,
 * for a cost that scales with the band's height, not the screen's.
 *
 * "Once" comes from where this is attached, not from any state this file
 * owns — see the note on the reused pattern in this app: a screen that is
 * disposed and rebuilt every time its tab is left and re-entered gets a
 * fresh `LaunchedEffect(Unit)` on every entry, and nothing about sending a
 * message afterwards touches this composable at all.
 */
@Composable
fun Modifier.entryScan(
    colourA: Color = com.momentum.focus.ui.theme.Tang.fill,
    colourB: Color = com.momentum.focus.ui.theme.Lilac.fill,
): Modifier {
    val progress = remember { Animatable(-0.08f) }
    val alpha = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        progress.animateTo(1.06f, tween(900, easing = FastOutSlowInEasing))
        delay(60)
        alpha.animateTo(0f, tween(240))
    }
    return this.drawWithContent {
        drawContent()
        val a = alpha.value
        if (a < 0.01f) return@drawWithContent

        val lineY = size.height * progress.value
        // Half-height of the lit band. Past this, a dot's own intensity has
        // already fallen to zero, so nothing outside it needs to be visited.
        val reach = 34.dp.toPx()
        val step = 8.dp.toPx()
        val maxR = step * 0.42f

        val topRow = ((lineY - reach) / step).toInt().coerceAtLeast(0)
        val bottomRow = ((lineY + reach) / step).toInt() + 1
        var row = topRow
        while (row <= bottomRow) {
            val y = row * step
            if (y in -reach..(size.height + reach)) {
                val fall = 1f - (abs(y - lineY) / reach).coerceIn(0f, 1f)
                if (fall > 0.02f) {
                    val intensity = fall * fall
                    val colour = lerp(colourA, colourB, (row % 7) / 6f)
                    var x = if (row % 2 == 0) step / 2f else step
                    while (x < size.width) {
                        drawCircle(
                            color = colour.copy(alpha = a * (0.5f + 0.5f * intensity)),
                            radius = maxR * intensity,
                            center = Offset(x, y),
                        )
                        x += step
                    }
                }
            }
            row++
        }
    }
}
