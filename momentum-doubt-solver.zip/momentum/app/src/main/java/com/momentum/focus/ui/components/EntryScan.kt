package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * A halftone scan-line, sweeping down the screen once when this modifier's
 * host first enters composition, with a drop landing and a screen judder at
 * the midpoint.
 *
 * Same printed-dot material as the MyAi tab's own glow in [liquidGlow] —
 * full-strength colour carried by dot size, not a smooth gradient wash — so
 * this reads as the same effect the user is already looking at on the tab
 * they just tapped, rather than a second, different-looking animation
 * arriving on the screen behind it.
 *
 * The first pass at this used a 0.5 alpha floor and a 0.42x radius, sized
 * against a plain dark test background. On this app's actual cream, paper-
 * grained screen, with chat bubbles already on it, that came out close to
 * invisible — watched back, only a stray dot or two registered at all. The
 * floor and radius here are both pushed up specifically because the previous
 * numbers were tuned against the wrong surface.
 *
 * Only a band around the current line is drawn, not the whole screen. A
 * grid across the full display would be tens of thousands of dots redrawn
 * every frame; restricting the loop to the rows the line is actually near
 * keeps the per-frame count bounded by the band's height, not the screen's.
 *
 * "Once" comes from where this is attached, not from any state this file
 * owns — a screen that is disposed and rebuilt every time its tab is left
 * and re-entered gets a fresh `LaunchedEffect(Unit)` on every entry, and
 * nothing about sending a message afterwards touches this composable at all.
 */
@Composable
fun Modifier.entryScan(
    colourA: Color = com.momentum.focus.ui.theme.Tang.fill,
    colourB: Color = com.momentum.focus.ui.theme.Lilac.fill,
): Modifier {
    val haptics = rememberHaptics()
    val progress = remember { Animatable(-0.08f) }
    val alpha = remember { Animatable(1f) }
    val bloom = remember { Animatable(0f) }
    // The judder: a handful of quick, decaying nudges applied to the whole
    // screen at the instant the drop lands, via graphicsLayer -- not drawn
    // dots, an actual displacement of everything under it. This is what
    // makes the landing read as an impact rather than as a light turning on.
    val shakeX = remember { Animatable(0f) }
    val shakeY = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        haptics.tick()
        progress.animateTo(0.5f, tween(850, easing = FastOutSlowInEasing))
        // The drop lands: a firmer tap than the edges get, plus the bloom
        // and the judder, all fired together off the same moment.
        haptics.press()
        launch {
            bloom.animateTo(1f, tween(260, easing = FastOutSlowInEasing))
            bloom.animateTo(0f, tween(420))
        }
        launch {
            // Four decaying cycles, alternating X and Y so it reads as a
            // judder rather than a single directional shove.
            val amps = listOf(10f, -7f, 4f, -2f)
            for ((i, amp) in amps.withIndex()) {
                if (i % 2 == 0) shakeX.animateTo(amp, tween(45)) else shakeY.animateTo(amp, tween(45))
            }
            shakeX.animateTo(0f, tween(60))
            shakeY.animateTo(0f, tween(60))
        }
        progress.animateTo(1.06f, tween(850, easing = FastOutSlowInEasing))
        haptics.tick()
        delay(80)
        alpha.animateTo(0f, tween(320))
    }
    return this
        .graphicsLayer {
            translationX = shakeX.value
            translationY = shakeY.value
        }
        .drawWithContent {
        drawContent()
        val a = alpha.value
        if (a < 0.01f) return@drawWithContent

        val lineY = size.height * progress.value
        val reach = 36.dp.toPx()
        val step = 7.dp.toPx()
        val maxR = step * 0.50f

        val topRow = ((lineY - reach) / step).toInt().coerceAtLeast(0)
        val bottomRow = ((lineY + reach) / step).toInt() + 1
        var row = topRow
        while (row <= bottomRow) {
            val y = row * step
            if (y in -reach..(size.height + reach)) {
                val fall = 1f - (abs(y - lineY) / reach).coerceIn(0f, 1f)
                if (fall > 0.02f) {
                    val intensity = fall * fall
                    val colour = lerp(colourA, colourB, (row % 7) / 6f)
                    var x = if (row % 2 == 0) step / 2f else step
                    while (x < size.width) {
                        drawCircle(
                            // Floor raised from 0.5 to 0.78 -- at the old
                            // floor, most of the band sat under half strength
                            // and blended straight into busy cream paper.
                            color = colour.copy(alpha = a * (0.78f + 0.22f * intensity)),
                            radius = maxR * intensity,
                            center = Offset(x, y),
                        )
                        x += step
                    }
                }
            }
            row++
        }

        // The bloom: the same dot material, expanding outward from the
        // screen's centre as a ring rather than a filled disc -- a filled
        // circle at this size would read as a coloured blob; a ring with a
        // radius that grows over the animation reads as a drop's ripple.
        val b = bloom.value
        if (b > 0.01f) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val ringR = size.minDimension * 0.05f + size.minDimension * 0.32f * b
            val ringBand = 22.dp.toPx()
            val steps = 40
            for (i in 0 until steps) {
                val ang = (i / steps.toFloat()) * 2f * kotlin.math.PI.toFloat()
                val rr = ringR + (pseudoJitter(i) - 0.5f) * ringBand
                val px = cx + cos(ang) * rr
                val py = cy + sin(ang) * rr
                val colour = lerp(colourA, colourB, i / steps.toFloat())
                drawCircle(
                    color = colour.copy(alpha = a * (1f - b) * 0.95f),
                    radius = maxR * (0.7f + 0.3f * (1f - b)),
                    center = Offset(px, py),
                )
            }
        }
    }
}

private fun pseudoJitter(i: Int): Float {
    val v = sin(i * 91.7f) * 43758.5453f
    return v - kotlin.math.floor(v)
}
