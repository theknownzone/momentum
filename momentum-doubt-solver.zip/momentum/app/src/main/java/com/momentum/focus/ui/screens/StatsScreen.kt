package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.momentum.focus.data.AppData
import com.momentum.focus.data.XP_PER_LEVEL
import com.momentum.focus.ui.components.MarkerTitle
import com.momentum.focus.ui.components.CoachCard
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.data.ScreenTime
import com.momentum.focus.data.ScreenTimeReport
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ai.Ai
import com.momentum.focus.ai.Coach
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.data.TimelineEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The dashboard.
 *
 * The headline is time reclaimed against the baseline measured during setup,
 * not a streak. Streaks break and people quit; reclaimed hours only ever go up,
 * so there is nothing to lose and no reason to walk away after a bad day.
 */
@Composable
fun StatsScreen(
    data: AppData,
    coachBusy: Boolean = false,
    coachError: String? = null,
    onRunCoach: () -> Unit = {},
) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current

    var refresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) refresh++
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    // Reading a week of usage stats is slow enough to drop frames on the main
    // thread, so it happens on IO and the screen renders around it.
    val report by produceState<ScreenTimeReport?>(null, refresh) {
        value = kotlinx.coroutines.withContext(Dispatchers.IO) {
            ScreenTime.report(context)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 20.dp, bottom = 28.dp),
    ) {
        val str = strings()

        // Only when a key was compiled in. A build without one has no AI in it
        // and should not advertise a feature it cannot run.
        if (Ai.enabled) {
            val report = remember(data.coachJson) { Coach.decode(data.coachJson) }
            val doneCount = data.sessions.count { it.completed }
            CoachCard(
                report = report,
                busy = coachBusy,
                error = coachError,
                sessionsNeeded = (Coach.MIN_SESSIONS - doneCount).coerceAtLeast(0),
                onRun = onRunCoach,
            )
            Spacer(Modifier.height(Paper.Gap))
        }

        Text(str.stats.dashboard, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        // Marked, like the Focus title. The two screens with a big name at the
        // top now wear the same stroke, which is what makes it read as the
        // app's handwriting rather than as decoration on one page.
        MarkerTitle(
            str.stats.whereItsGoing,
            color = MaterialTheme.colorScheme.onSurface,
            marker = Tang.fill,
            style = MaterialTheme.typography.displayMedium,
            modifier = Modifier.align(Alignment.Start),
        )

        Spacer(Modifier.height(18.dp))

        val r = report
        if (r == null) {
            Loading()
            return@Column
        }

        ReclaimedCard(data, r)

        Spacer(Modifier.height(Paper.Gap))

        FocusPanel(data)

        Spacer(Modifier.height(Paper.Gap))

        Row(horizontalArrangement = Arrangement.spacedBy(Paper.Gap)) {
            MiniStat(
                str.stats.level,
                "${data.level}",
                str.stats.xpProgress(data.xpIntoLevel, XP_PER_LEVEL),
                Butter,
                Modifier.weight(1f),
            )
            MiniStat(
                str.stats.focused,
                "${data.earnedMinutes / 60}h",
                str.stats.sessions(data.sessions.count { it.completed }),
                Mint,
                Modifier.weight(1f),
            )
        }

        Spacer(Modifier.height(Paper.Gap))

        WeekChart(r, data.baselineMinutes)

        if (r.topApps.isNotEmpty()) {
            Spacer(Modifier.height(22.dp))
            Text(str.stats.whereItGoes, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(10.dp))
            val worst = r.topApps.first().minutes.coerceAtLeast(1)
            r.topApps.forEach { app ->
                val blocked = app.pkg in data.blockedPackages
                Column(Modifier.padding(bottom = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            app.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f),
                        )
                        if (blocked) {
                            Box(
                                Modifier
                                    .padding(end = 8.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(Mint.fill)
                                    .border(2.dp, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(50))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    str.stats.blocked,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Mint.on,
                                )
                            }
                        }
                        Text(
                            "%dh %02dm".format(app.minutes / 60, app.minutes % 60),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.height(5.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(2.dp, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(50))
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth((app.minutes.toFloat() / worst).coerceIn(0f, 1f))
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(50))
                                .background(if (blocked) Mint.fill else Tang.fill)
                        )
                    }
                }
            }
        }

        val split = remember(data) {
            data.subjectSplit()
                .filter { it.first in data.subjects.take(3) || it.first == "General" }
                .ifEmpty { data.subjects.take(3).map { it to 0 } }
        }
        if (split.isNotEmpty()) {
            Spacer(Modifier.height(22.dp))
            Text(str.stats.bySubject, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                str.stats.last30Days,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(10.dp))

            val top = split.first().second.coerceAtLeast(1)
            split.forEachIndexed { i, (name, mins) ->
                val sticker = stickerFor(i)
                val neglected = mins == 0
                Column(Modifier.padding(bottom = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            name,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (neglected) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.62f) else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            if (neglected) str.stats.untouched
                            else "%dh %02dm".format(mins / 60, mins % 60),
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (neglected) Tang.accent else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.height(5.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(2.dp, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(50))
                    ) {
                        if (!neglected) {
                            Box(
                                Modifier
                                    .fillMaxWidth((mins.toFloat() / top).coerceIn(0f, 1f))
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(50))
                                    .background(sticker.fill)
                            )
                        }
                    }
                }
            }
        }

        if (data.slips.size >= 3) {
            Spacer(Modifier.height(Paper.Gap))
            val worst = SLIP_REASONS
                .map { it to data.regretRate(it) }
                .filter { it.second.second >= 2 }
                .maxByOrNull { (_, r) -> r.first.toFloat() / r.second }

            if (worst != null) {
                val (reason, rate) = worst
                val percent = (rate.first * 100 / rate.second)
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(Paper.CardRadius))
                        .background(Butter.fill)
                        .border(Paper.Outline, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(Paper.CardRadius))
                        .padding(16.dp)
                ) {
                    Text(
                        str.stats.yourPattern,
                        style = MaterialTheme.typography.labelSmall,
                        color = Butter.on,
                    )
                    Spacer(Modifier.height(6.dp))
                    // Computed from the user's own answers, not a guess. This
                    // is the one thing no other app can tell them.
                    Text(
                        str.stats.regretLine(reason.lowercase(), percent),
                        style = MaterialTheme.typography.headlineSmall,
                        color = Butter.on,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        str.stats.basedOnAnswers(data.slips.size),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Butter.on.copy(alpha = 0.75f),
                    )
                }
            }
        }

        if (data.urges.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            // urges is non-empty here, so the grouping has at least one entry
            // and maxByOrNull cannot actually return null — the compiler just
            // can't see that. The old code interpolated the nullable straight
            // into the sentence, which would have printed "around null:00"
            // rather than failing, so this was never going to be caught by
            // reading the screen.
            val worstHour = data.urges.groupBy { it.hour }
                .maxByOrNull { it.value.size }?.key
                ?: data.urges.first().hour
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    .background(Lilac.fill)
                    .border(Paper.Outline, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(Paper.CardRadius))
                    .padding(16.dp)
            ) {
                Text(str.stats.pattern, style = MaterialTheme.typography.labelSmall, color = Lilac.on)
                Spacer(Modifier.height(6.dp))
                Text(
                    str.stats.urgeHour(worstHour),
                    style = MaterialTheme.typography.bodyLarge,
                    color = Lilac.on,
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Timeline()
    }
}

/**
 * Today, in order.
 *
 * The bars above say where the day went; this says when it started going. The
 * same app at the same hour on consecutive days is a pattern a total can never
 * show.
 */
@Composable
private fun Timeline() {
    val str = strings()
    val context = LocalContext.current
    val entries by produceState(initialValue = emptyList<TimelineEntry>(), context) {
        value = withContext(Dispatchers.IO) {
            runCatching { ScreenTime.timelineToday(context) }.getOrDefault(emptyList())
        }
    }
    if (entries.isEmpty()) return

    val fmt = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()) }

    Text(str.stats.todaysOrder, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(4.dp))
    Text(
        str.stats.whatOpenedWhen,
        style = MaterialTheme.typography.headlineSmall,
        color = MaterialTheme.colorScheme.onBackground,
    )
    Spacer(Modifier.height(10.dp))

    entries.take(25).forEach { e ->
        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                fmt.format(java.util.Date(e.startMs)),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.width(52.dp),
            )
            Text(
                e.label,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f),
            )
            Text(
                if (e.minutes >= 60) "${e.minutes / 60}h ${e.minutes % 60}m" else "${e.minutes}m",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/**
 * Time reclaimed so far today, judged against how much of the day has gone.
 *
 * The first version subtracted today's minutes from a whole day's baseline. At
 * nine in the morning that read "reclaimed 14h 06m" — fourteen hours that had
 * not been lived yet, let alone saved. It is the same failure as a streak that
 * climbs while nobody studies: a number that looks earned and is not.
 *
 * So the baseline is scaled to the fraction of the day elapsed, and the label
 * says "so far" rather than claiming the day is done. Early morning has too
 * little elapsed for the ratio to mean anything, so it shows plain usage until
 * enough of the day has passed.
 */
@Composable
private fun ReclaimedCard(data: AppData, report: ScreenTimeReport) {
    val str = strings()
    val baseline = data.baselineMinutes
    val today = report.dailyMinutes.lastOrNull() ?: 0

    val elapsed = remember { java.time.LocalTime.now().toSecondOfDay() / 60 }
    val dayGone = (elapsed / 1440f).coerceIn(0f, 1f)
    val pacedBaseline = (baseline * dayGone).roundToInt()
    // Under a quarter of the day there is not enough elapsed time for the
    // comparison to say anything, so it does not pretend to.
    val tooEarly = dayGone < 0.25f

    val saved = (pacedBaseline - today).coerceAtLeast(0)
    val over = today > pacedBaseline && baseline > 0

    val animated by animateFloatAsState(saved.toFloat(), Motion.settle(), label = "saved")
    val minutes = animated.roundToInt()

    val sticker = if (over && !tooEarly) Tang else Mint

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(sticker.fill.lit())
            .border(Paper.Outline, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(Paper.CardRadius))
            .padding(18.dp)
    ) {
        Text(
            when {
                baseline == 0 -> str.stats.todaysScreenTime
                tooEarly -> str.stats.todaySoFar
                over -> str.stats.overYourPace
                else -> str.stats.reclaimedSoFar
            },
            style = MaterialTheme.typography.labelSmall,
            color = sticker.on.copy(alpha = 0.75f),
        )
        Spacer(Modifier.height(8.dp))

        val headline = when {
            baseline == 0 || tooEarly -> "%dh %02dm".format(today / 60, today % 60)
            over -> "+%dh %02dm".format(
                abs(today - pacedBaseline) / 60, abs(today - pacedBaseline) % 60
            )
            else -> "%dh %02dm".format(minutes / 60, minutes % 60)
        }
        // One line, shrinking if it has to. displayLarge fits "0h 09m" and
        // does not fit "+0h 09m" — the plus is one glyph wider than the box —
        // so the number broke in half and read as two separate figures stacked
        // on top of each other.
        Text(
            headline,
            style = MaterialTheme.typography.displayLarge,
            color = sticker.on,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Visible,
            modifier = Modifier.fillMaxWidth(),
            fontSize = if (headline.length > 6) 46.sp else 57.sp,
        )

        Spacer(Modifier.height(6.dp))
        Text(
            when {
                baseline == 0 -> str.stats.grantUsageAccess
                tooEarly -> str.stats.dayJustStarted(
                    baseline / 60, baseline % 60
                )
                else -> str.stats.normallyByNow(
                    pacedBaseline / 60, pacedBaseline % 60, today / 60, today % 60
                )
            },
            style = MaterialTheme.typography.bodyMedium,
            color = sticker.on.copy(alpha = 0.8f),
        )
    }
}

@Composable
private fun WeekChart(report: ScreenTimeReport, baseline: Int) {
    val str = strings()
    val peak = (report.dailyMinutes.maxOrNull() ?: 60).coerceAtLeast(baseline).coerceAtLeast(60)
    val today = remember { java.time.LocalDate.now() }
    // The labels were a fixed Monday-to-Sunday list while the data is the last
    // seven days ending today, so every letter sat over the wrong bar unless
    // today happened to be Sunday.
    val dates = remember(today, report.dailyMinutes.size) {
        val n = report.dailyMinutes.size
        (0 until n).map { today.minusDays((n - 1 - it).toLong()) }
    }
    val days = dates.map { it.dayOfWeek.name.take(1) }
    // Null means nothing picked; the summary line then describes the week.
    var picked by remember { mutableStateOf<Int?>(null) }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(MaterialTheme.colorScheme.surface)
            .border(Paper.Outline, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(Paper.CardRadius))
            .padding(16.dp)
    ) {
        Text(str.stats.last7Days, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))

        Box(Modifier.fillMaxWidth().height(130.dp)) {
            if (baseline > 0) {
                // The baseline sits behind the bars as a line to beat. A chart
                // without it just shows numbers; with it, every bar is a result.
                Box(
                    Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomStart)
                        .padding(bottom = 130.dp * (baseline.toFloat() / peak))
                        .height(2.dp)
                        .background(Tang.accent)
                )
            }
            Row(
                Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                report.dailyMinutes.forEachIndexed { i, m ->
                    val frac by animateFloatAsState(
                        m.toFloat() / peak, Motion.bouncy(), label = "b$i"
                    )
                    val beat = baseline > 0 && m < baseline
                    val on = picked == i
                    val sticker = if (beat) Mint else Tang
                    // The tap target is the whole column, not the bar. It was
                    // on the bar itself, whose height is the data — so a quiet
                    // day was a sliver a few pixels tall and effectively
                    // untappable, which is exactly the day someone wants to
                    // check.
                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                picked = if (on) null else i
                            },
                        verticalArrangement = Arrangement.Bottom,
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(frac.coerceAtLeast(0.04f))
                                .clip(RoundedCornerShape(6.dp))
                                // Lighter at the crown, full colour at the base,
                                // so a flat block reads as something with a lit
                                // edge instead of a printed rectangle.
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            sticker.fill.lighten(0.26f),
                                            sticker.fill,
                                            sticker.fill.darken(0.10f),
                                        )
                                    )
                                )
                                .border(
                                    if (on) 4.dp else 2.dp,
                                    MaterialTheme.colorScheme.onSurface,
                                    RoundedCornerShape(6.dp),
                                )
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            days.forEach {
                Text(
                    it,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        val chosen = picked
        Text(
            if (chosen == null) {
                str.stats.averageLine(
                    report.averageMinutes / 60, report.averageMinutes % 60
                )
            } else {
                val m = report.dailyMinutes[chosen]
                val d = dates[chosen]
                val gap = if (baseline > 0) m - baseline else 0
                val verdict = when {
                    baseline <= 0 -> ""
                    gap <= 0 -> str.stats.underBaseline(-gap / 60, -gap % 60)
                    else -> str.stats.overBaseline(gap / 60, gap % 60)
                }
                "%s %d · %dh %02dm%s".format(
                    d.month.name.take(3).lowercase().replaceFirstChar { it.uppercase() },
                    d.dayOfMonth, m / 60, m % 60, verdict,
                )
            },
            style = MaterialTheme.typography.bodyMedium,
            color = if (chosen == null) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun MiniStat(
    label: String,
    value: String,
    caption: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(sticker.fill)
            .border(Paper.Outline, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(Paper.CardRadius))
            .padding(14.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = sticker.on.copy(alpha = 0.75f))
        Spacer(Modifier.height(6.dp))
        Text(value, style = MaterialTheme.typography.displayMedium, color = sticker.on)
        Text(caption, style = MaterialTheme.typography.bodyMedium, color = sticker.on.copy(alpha = 0.8f))
    }
}

@Composable
private fun Loading() {
    val str = strings()
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(MaterialTheme.colorScheme.surface)
            .border(Paper.Outline, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(Paper.CardRadius))
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(str.stats.readingYourWeek, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
    }
}

/**
 * Lifetime, week and today against the shape of the last seven days.
 *
 * The three numbers were previously scattered across separate cards, which
 * made them impossible to read against each other — the interesting thing is
 * not "48m today", it is whether 48m is more or less than the days around it.
 * Putting the rail and the line in one card is what lets the comparison
 * happen without scrolling.
 *
 * The line is drawn from banked sessions rather than phone usage, so it can
 * only move when someone actually studied.
 */
@Composable
private fun FocusPanel(data: AppData) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    val str = strings()
    val today = remember { java.time.LocalDate.now().toEpochDay() }
    val skin = LocalSkin.current

    // Index 0 is six days ago, index 6 is today.
    val daily = remember(data.sessions, today) {
        val buckets = IntArray(7)
        data.sessions.filter { it.completed }.forEach { s ->
            val ago = (today - s.startedAtEpochDay).toInt()
            if (ago in 0..6) buckets[6 - ago] += s.minutes
        }
        buckets.toList()
    }
    val week = daily.sum()
    val todayMin = daily.last()
    val peak = (daily.maxOrNull() ?: 0).coerceAtLeast(1)
    val chartOuterStroke = Stroke(11f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val chartInnerStroke = Stroke(6f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val goalRingBaseStrokePx = with(LocalDensity.current) { 9.dp.toPx() }
    val everStudied = daily.any { it > 0 } || data.earnedMinutes > 0

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(MaterialTheme.colorScheme.surface)
            .border(Paper.Outline, onSurface, RoundedCornerShape(Paper.CardRadius))
            .padding(14.dp),
    ) {
        Row {
            // The coloured rail. Fixed width rather than a weight so the chart
            // keeps a usable area on a narrow phone.
            Column(
                Modifier
                    .width(112.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(skin.accent.lit())
                    .border(Paper.Outline, onSurface, RoundedCornerShape(12.dp))
                    .padding(12.dp),
            ) {
                // Three different spans, none of them repeated elsewhere on
                // this screen. The panel used to open with BANKED — total
                // focused hours — and three rows below, the same figure came
                // back as FOCUSED. One number under two names reads as two
                // facts that happen to match, and the reader has to work out
                // that they do not.
                //
                // TODAY was also here twice over, once from minutesToday and
                // once from daily.last(), which are the same minutes counted
                // two ways.
                RailStat(str.stats.today, "${todayMin}m")
                Spacer(Modifier.height(10.dp))
                RailStat(str.stats.thisWeek, "${week / 60}h ${week % 60}m")
                // The one number on this screen that is a comparison rather
                // than a total.
                //
                // "4h 20m this week" says nothing on its own — it is only
                // good or bad next to the week before it, and until now the
                // app made everyone do that arithmetic from memory. This is
                // also the honest version of the leaderboard idea: the person
                // you were last week is the only opponent this app can
                // actually verify, because every other one would need a server
                // and an account system that do not exist here.
                val lastWeek = remember(data.sessions) { data.weekMinutes(1) }
                if (lastWeek > 0 || week > 0) {
                    val delta = week - lastWeek
                    Text(
                        when {
                            lastWeek == 0 -> str.stats.weekFirstOne
                            delta > 0 -> str.stats.weekUp(delta / 60, delta % 60)
                            delta < 0 -> str.stats.weekDown(-delta / 60, -delta % 60)
                            else -> str.stats.weekSame
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = when {
                            delta > 0 -> Mint.fill
                            delta < 0 -> Tang.accent
                            else -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                        },
                    )
                }
                Spacer(Modifier.height(10.dp))
                RailStat(str.stats.bestDay, "${daily.max()}m")
            }

            Spacer(Modifier.width(10.dp))

            Column(Modifier.weight(1f)) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(str.stats.focusTime, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(9.dp))
                            .background(Butter.fill)
                            .border(2.dp, onSurface, RoundedCornerShape(9.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp),
                    ) {
                        Text(
                            "${todayMin}m",
                            style = MaterialTheme.typography.labelSmall,
                            color = Butter.on,
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (!everStudied) {
                    // Seven zeroes drawn as a line is a flat stroke along the
                    // bottom, which looks like a chart that failed rather than
                    // a week nobody studied. Saying so is more use than
                    // rendering an axis with nothing on it.
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(80.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            str.stats.firstSessionHint,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else Canvas(
                    Modifier
                        .fillMaxWidth()
                        .height(80.dp),
                ) {
                    val stepX = size.width / 6f
                    val pts = daily.mapIndexed { i, m ->
                        Offset(i * stepX, size.height * (1f - m.toFloat() / peak))
                    }
                    val path = Path().apply {
                        moveTo(pts.first().x, pts.first().y)
                        pts.drop(1).forEach { lineTo(it.x, it.y) }
                    }
                    // MaterialTheme.colorScheme.onSurface underneath, colour on top: the same trick the rest of
                    // the app uses to keep an outline around every filled shape.
                    drawPath(path, onSurface, style = chartOuterStroke)
                    drawPath(path, skin.accent, style = chartInnerStroke)
                    drawCircle(onSurface, 9f, pts.last())
                    drawCircle(Butter.fill, 5f, pts.last())
                }
                Spacer(Modifier.height(4.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    remember(today) {
                        (6 downTo 0).map {
                            java.time.LocalDate.ofEpochDay(today - it)
                                .dayOfWeek.name.take(1)
                        }
                    }.forEach {
                        Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

    }

    Spacer(Modifier.height(Paper.Gap))

    // The reference's second card: a rail, a ring and bars in one row. Kept
    // separate from the first card rather than stacked inside it, because a
    // divider inside one card made two unrelated readings look like one.
    GoalPanel(data)
}

/**
 * Streak progress and the shape of the week, read together.
 *
 * A ring alone says how far along the goal is but not whether this week helped.
 * The bars beside it answer that, and the rail gives the totals both are
 * derived from, so nothing on the card needs another screen to make sense of.
 */
@Composable
private fun GoalPanel(data: AppData) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
    val str = strings()
    val skin = LocalSkin.current
    val today = remember { java.time.LocalDate.now().toEpochDay() }
    val daily = remember(data.sessions, today) {
        val b = IntArray(7)
        data.sessions.filter { it.completed }.forEach { s ->
            val ago = (today - s.startedAtEpochDay).toInt()
            if (ago in 0..6) b[6 - ago] += s.minutes
        }
        b.toList()
    }
    val peak = (daily.maxOrNull() ?: 0).coerceAtLeast(1)
    val anyData = daily.any { it > 0 }

    val done = data.streakDays.coerceAtMost(data.streakGoal)
    val frac = if (data.streakGoal <= 0) 0f else done.toFloat() / data.streakGoal
    val sweep by animateFloatAsState(frac, Motion.settle(), label = "goal")

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(MaterialTheme.colorScheme.surface)
            .border(Paper.Outline, onSurface, RoundedCornerShape(Paper.CardRadius))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(
            Modifier
                .width(96.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(skin.petal.lit())
                .border(Paper.Outline, onSurface, RoundedCornerShape(12.dp))
                .padding(10.dp),
        ) {
            RailStat(str.stats.streak, "${data.streakDays}d")
            Spacer(Modifier.height(8.dp))
            RailStat(str.stats.goalCaps, "${data.streakGoal}d")
        }

        Spacer(Modifier.width(10.dp))

        Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = goalRingBaseStrokePx
                val arcSize = Size(size.width - stroke * 1.6f, size.height - stroke * 1.6f)
                val topLeft = Offset(stroke * 0.8f, stroke * 0.8f)
                drawArc(surfaceVariant, -90f, 360f, false, topLeft, arcSize,
                    style = Stroke(stroke, cap = StrokeCap.Round))
                drawArc(onSurface, -90f, 360f * sweep, false, topLeft, arcSize,
                    style = Stroke(stroke + 6f, cap = StrokeCap.Round))
                drawArc(skin.accent, -90f, 360f * sweep, false, topLeft, arcSize,
                    style = Stroke(stroke, cap = StrokeCap.Round))
            }
            Text(
                "${(frac * 100).roundToInt()}%",
                style = MaterialTheme.typography.titleMedium,
                color = onSurface,
            )
        }

        Spacer(Modifier.width(10.dp))

        Column(Modifier.weight(1f)) {
            Text(str.stats.daily, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            if (!anyData) {
                Text(
                    str.stats.emptyYet,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalAlignment = Alignment.Bottom,
                ) {
                    daily.forEachIndexed { i, m ->
                        Box(
                            Modifier
                                .weight(1f)
                                .fillMaxHeight((m.toFloat() / peak).coerceAtLeast(0.06f))
                                .clip(RoundedCornerShape(3.dp))
                                .background((if (i == 6) skin.accent else MaterialTheme.colorScheme.surfaceVariant).lit())
                                .border(2.dp, onSurface, RoundedCornerShape(3.dp))
                        )
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                when {
                    done >= data.streakGoal -> str.stats.goalDone
                    done == 0 -> str.stats.studyTodayStart
                    else -> str.stats.daysMore(data.streakGoal - done)
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun RailStat(label: String, value: String) {
    Text(
        label,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
    )
    Text(value, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurface)
}
