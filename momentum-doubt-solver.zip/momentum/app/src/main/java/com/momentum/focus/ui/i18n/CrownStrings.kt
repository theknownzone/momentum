package com.momentum.focus.ui.i18n

/**
 * Crown mode's cutscene and its brief.
 *
 * The brief's lines are the important half. Crown takes device admin and makes
 * the app hard to remove, and a person should read what that means in plain
 * words before they agree to it — not discover it afterwards as a reveal.
 */
interface CrownStrings {
    val entered: String
    val subtitle: String
    val skip: String

    /**
     * The spoken line.
     *
     * English in both tables, deliberately. The engine is set to US English —
     * a Hinglish line in Latin script fed to an English voice comes out as
     * nonsense syllables, and switching the engine to Hindi would need voice
     * data most phones do not have installed.
     */
    val voiceLine: String

    val briefTitle: String
    val briefApps: String
    val briefUninstall: String
    val briefSettings: String
    val briefOut: String
}

object CrownHi : CrownStrings {
    override val entered = "CROWN MODE"
    override val subtitle = "Ab phone tumhara nahi, session ka hai."
    override val skip = "Tap karke aage badho"
    override val voiceLine = "Welcome to Crown Mode."

    override val briefTitle = "Crown on karne se pehle"
    override val briefApps = "Blocked apps session ke dauraan khulengi nahi."
    override val briefUninstall = "App uninstall karna mushkil ho jayega — device admin on hoga."
    override val briefSettings = "Session chalte waqt Settings lock rahegi."
    override val briefOut = "Nikalna hai to Crown chhod do — par session ki kamai chali jayegi."
}

object CrownEn : CrownStrings {
    override val entered = "CROWN MODE"
    override val subtitle = "The phone belongs to the session now."
    override val skip = "Tap to continue"
    override val voiceLine = "Welcome to Crown Mode."

    override val briefTitle = "Before Crown goes on"
    override val briefApps = "Blocked apps will not open during a session."
    override val briefUninstall = "The app becomes hard to remove — device admin is switched on."
    override val briefSettings = "Settings stay locked while a session runs."
    override val briefOut = "You can drop back down, but the session's earnings go with it."
}
