package com.momentum.focus.ui.i18n

/**
 * Crown mode's cutscene and its brief.
 *
 * The brief's lines are the important half. Crown takes device admin and makes
 * the app hard to remove, and a person should read what that means in plain
 * words before they agree to it — not discover it afterwards as a reveal.
 */
interface CrownStrings {
    val entered: String
    val subtitle: String
    val skip: String

    /**
     * The spoken line.
     *
     * English in both tables, deliberately. The engine is set to US English —
     * a Hinglish line in Latin script fed to an English voice comes out as
     * nonsense syllables, and switching the engine to Hindi would need voice
     * data most phones do not have installed.
     */
    val voiceLine: String

    val briefTitle: String
    val briefApps: String
    val briefUninstall: String
    val briefSettings: String

    /**
     * How long the lock holds, in hours.
     *
     * A function rather than a fixed sentence so the figure comes from
     * FocusLevels.PACT_HOURS. The brief used to name no duration at all, which
     * meant the honest answer to "how long am I stuck" was only discoverable
     * by getting stuck.
     */
    fun briefLock(hours: Int): String

    val briefOut: String

    /** The one button on the brief. */
    val begin: String
}

object CrownHi : CrownStrings {
    override val entered = "Crown chalu"
    override val subtitle = "Ab phone tumhara nahi, session ka hai."
    override val skip = "Tap karke aage badho"
    override val voiceLine = "Welcome to Crown Mode."

    override val briefTitle = "Crown on karne se pehle"
    override val briefApps = "🚫  Blocked apps session ke dauraan khulengi nahi."
    override val briefUninstall = "🔒  App uninstall karna mushkil ho jayega — device admin on hoga."
    override val briefSettings = "⚙️  Session chalte waqt Settings lock rahegi."
    override fun briefLock(hours: Int) =
        "⏳  Tap karte hi $hours ghante ka lock lag jayega. Badha sakte ho, " +
            "ghata nahi — aur in $hours ghanton mein level neeche nahi ja sakta."
    override val briefOut =
        "💸  Lock khatam hone ke baad level neeche la sakte ho — par us " +
            "session ki kamai chali jayegi."
    override val begin = "Chalo shuru karein"
}

object CrownEn : CrownStrings {
    override val entered = "CROWN MODE"
    override val subtitle = "The phone belongs to the session now."
    override val skip = "Tap to continue"
    override val voiceLine = "Welcome to Crown Mode."

    override val briefTitle = "Before Crown goes on"
    override val briefApps = "🚫  Blocked apps will not open during a session."
    override val briefUninstall = "🔒  The app becomes hard to remove — device admin is switched on."
    override val briefSettings = "⚙️  Settings stay locked while a session runs."
    override fun briefLock(hours: Int) =
        "⏳  The moment you tap, a $hours-hour lock starts. You can extend " +
            "it, never shorten it — and you cannot drop a level until it ends."
    override val briefOut =
        "💸  Once the lock ends you can drop back down — but that session's " +
            "earnings go with it."
    override val begin = "Let's begin"
}
