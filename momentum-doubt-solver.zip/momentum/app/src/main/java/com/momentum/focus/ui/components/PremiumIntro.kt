package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.Cream
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay

/**
 * Premium unlock beat after the receipt. Deliberately simple: one check,
 * one title lock-up and one clean hand-off. No competing cards or moving text.
 */
@Composable
fun PremiumIntro(onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val alpha = remember { Animatable(0f) }
    val scale = remember { Animatable(0.90f) }
    val check = remember { Animatable(0f) }
    val text = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        haptics.unlock()
        alpha.animateTo(1f, tween(220))
        scale.animateTo(1.045f, tween(520, easing = FastOutSlowInEasing))
        scale.animateTo(1f, tween(260, easing = FastOutSlowInEasing))
        check.animateTo(1f, tween(360, easing = FastOutSlowInEasing))
        delay(120)
        text.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
        delay(1150)
        haptics.sessionComplete()
        delay(500)
        alpha.animateTo(0f, tween(320, easing = FastOutSlowInEasing))
        onDone()
    }

    Box(
        Modifier.fillMaxSize().alpha(alpha.value).background(Color(0xFF080A0C)),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val radius = size.minDimension * 0.30f
            drawCircle(
                Brush.radialGradient(
                    listOf(Mint.fill.copy(alpha = 0.20f * check.value), Color.Transparent)
                ),
                radius = radius,
                center = center,
            )
        }

        Column(
            Modifier.fillMaxWidth().padding(horizontal = 30.dp).scale(scale.value),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                Modifier.size(82.dp).scale(0.76f + 0.24f * check.value).alpha(check.value)
                    .background(Mint.fill, CircleShape)
                    .border(2.dp, Color.White.copy(alpha = 0.92f), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(46.dp))
            }
            Spacer(Modifier.height(24.dp))
            Text(
                "WELCOME TO PREMIUM",
                fontSize = 28.sp,
                lineHeight = 34.sp,
                fontWeight = FontWeight.Bold,
                color = Cream,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().alpha(text.value),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "LIFETIME ACCESS UNLOCKED",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                letterSpacing = 1.55.sp,
                fontWeight = FontWeight.SemiBold,
                color = GoldNeon,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().alpha(text.value),
            )
            Spacer(Modifier.height(18.dp))
            Text(
                "Your Premium features are ready.",
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.58f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().alpha(text.value),
            )
            Spacer(Modifier.height(30.dp))
            Text(
                "MOMENTUM  •  PREMIUM",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                letterSpacing = 1.3.sp,
                color = Color.White.copy(alpha = 0.34f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().alpha(text.value),
            )
        }
    }
}
