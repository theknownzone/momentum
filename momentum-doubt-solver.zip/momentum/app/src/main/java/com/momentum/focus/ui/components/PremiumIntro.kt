package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.Cream
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

/** Final purchase confirmation. Kept separate from the printer so the receipt
 * can finish cleanly before this short, centered celebration begins. */
@Composable
fun PremiumIntro(onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val alpha = remember { Animatable(0f) }
    val scale = remember { Animatable(0.86f) }
    LaunchedEffect(Unit) {
        haptics.unlock()
        alpha.animateTo(1f, tween(260))
        scale.animateTo(1.06f, tween(360))
        scale.animateTo(1f, tween(280))
        delay(1050)
        haptics.sessionComplete()
        delay(500)
        alpha.animateTo(0f, tween(360))
        onDone()
    }
    Box(Modifier.fillMaxSize().alpha(alpha.value).background(Cream), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width/2f, size.height/2f - 24.dp.toPx())
            for (i in 0 until 24) {
                val a = i * (Math.PI * 2.0 / 24.0)
                val r = 110.dp.toPx() + (i % 4) * 28.dp.toPx()
                val p = Offset(c.x + cos(a).toFloat()*r, c.y + sin(a).toFloat()*r)
                drawCircle(Mint.fill.copy(alpha = 0.16f), radius = 2.dp.toPx() + (i%3), center = p)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(92.dp).scale(scale.value), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    drawCircle(GoldNeon.copy(alpha=0.28f), radius=size.minDimension*0.5f)
                    drawCircle(Mint.fill, radius=size.minDimension*0.34f)
                    val c=Offset(size.width/2f,size.height/2f)
                    val path=androidx.compose.ui.graphics.Path().apply {
                        moveTo(c.x-size.width*0.17f,c.y)
                        lineTo(c.x-size.width*0.04f,c.y+size.height*0.14f)
                        lineTo(c.x+size.width*0.22f,c.y-size.height*0.16f)
                    }
                    drawPath(path, Color.White, style=androidx.compose.ui.graphics.drawscope.Stroke(width=5.dp.toPx(), cap=androidx.compose.ui.graphics.StrokeCap.Round, join=androidx.compose.ui.graphics.StrokeJoin.Round))
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("WELCOME TO PREMIUM", fontSize=30.sp, fontWeight=FontWeight.Black, color=Ink, textAlign=TextAlign.Center)
            Spacer(Modifier.height(7.dp))
            Text("LIFETIME ACCESS UNLOCKED", fontSize=12.sp, fontWeight=FontWeight.Bold, letterSpacing=1.5.sp, color=Ink.copy(alpha=0.58f), textAlign=TextAlign.Center)
            Spacer(Modifier.height(20.dp))
            Text("Momentum Premium", fontSize=14.sp, fontWeight=FontWeight.Medium, color=Ink.copy(alpha=0.55f), modifier=Modifier.padding(horizontal=24.dp))
        }
    }
}
