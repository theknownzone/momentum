package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkLow
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Sunk
import com.momentum.focus.ui.theme.Tang
import java.time.LocalDate

/** The rungs. Each one is a day count and what reaching it is worth. */
private val RUNGS = listOf(7, 14, 30, 60, 90)

/**
 * The streak, and what it is climbing towards.
 *
 * The number on its own answers "how long" and nothing else. A streak is a
 * thing you keep going, so the question it actually raises is "until what" —
 * and the app had no answer anywhere on any screen. Seven days of ticks show
 * the week just gone; the ladder underneath shows the next rung and how far
 * off it is.
 *
 * Rungs are days, not rewards, because nothing is handed out for them. Saying
 * a number is coming and then not paying it would be worse than saying
 * nothing; what a rung buys is the fact of having got there.
 */
@Composable
fun StreakLadder(data: AppData, modifier: Modifier = Modifier) {
    val str = strings()
    val shape = RoundedCornerShape(Paper.CardRadius)
    val streak = data.streakDays
    val next = RUNGS.firstOrNull { it > streak }

    Column(
        modifier
            .fillMaxWidth()
            .drawBehind {
                val d = 4.dp.toPx()
                drawRoundRect(
                    color = Ink.copy(alpha = 0.18f),
                    topLeft = Offset(d, d),
                    size = size,
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(
                        Paper.CardRadius.toPx(),
                        Paper.CardRadius.toPx(),
                    ),
                )
            }
            .clip(shape)
            .background(CreamCard)
            .border(Paper.Outline, Ink, shape)
            .drawBehind {
                comicPrint(Ink)
                tilePunches(Ink)
            }
            .padding(16.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // A soft glow behind the flame, not the Aura component — Aura is
            // reserved for paid surfaces on purpose, and the streak is a free,
            // core feature. This is its own small radial wash, scoped to just
            // the icon, the same trick the reference widget uses to make the
            // flame read as lit rather than flat.
            Box(contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(52.dp)
                        .drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    listOf(Tang.fill.copy(alpha = 0.35f), Color.Transparent),
                                ),
                            )
                        },
                )
                TileObject(art = TileArt.Flame, fill = Tang.fill, size = 34.dp)
            }
            Spacer(Modifier.size(10.dp))
            Column(Modifier.weight(1f)) {
                Text(str.success.streakLabel, style = MaterialTheme.typography.labelSmall, color = InkMid)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        streak.toString(),
                        style = MaterialTheme.typography.displaySmall,
                        fontWeight = FontWeight.Bold,
                        color = Ink,
                    )
                    Spacer(Modifier.size(6.dp))
                    Text(
                        str.success.streakDays,
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        StreakWeekRow(data)

        Spacer(Modifier.height(14.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            RUNGS.forEach { rung ->
                val reached = streak >= rung
                val isNext = rung == next
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (reached) Butter.fill else CreamCard)
                        .border(
                            if (isNext) Paper.Outline else 1.5.dp,
                            if (reached || isNext) Ink else InkLow,
                            RoundedCornerShape(10.dp),
                        )
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        rung.toString(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (reached || isNext) Ink else InkLow,
                        textAlign = TextAlign.Center,
                    )
                    Text(
                        str.success.rungDays,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (reached || isNext) InkMid else InkLow,
                    )
                }
            }
        }

        if (next != null) {
            Spacer(Modifier.height(10.dp))
            Text(
                str.success.toNextRung(next - streak, next),
                style = MaterialTheme.typography.bodyMedium,
                color = Ink,
            )
        }
    }
}

/**
 * The seven days ending today, ticked from the session log.
 *
 * Pulled out of [StreakLadder] so the streak celebration screen can show the
 * same row someone already recognises from the ladder card, instead of a
 * second, slightly different-looking week widget. Marked from the log rather
 * than the streak count itself — a streak that broke on Tuesday should still
 * show Monday's tick.
 */
@Composable
fun StreakWeekRow(data: AppData, modifier: Modifier = Modifier) {
    val today = LocalDate.now()
    val week = (6 downTo 0).map { back ->
        val day = today.minusDays(back.toLong())
        val epoch = day.toEpochDay()
        day to data.sessions.any { it.startedAtEpochDay == epoch && it.completed }
    }
    Row(
        modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        week.forEach { (day, done) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    day.dayOfWeek.name.take(1),
                    style = MaterialTheme.typography.labelSmall,
                    color = InkMid,
                )
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(if (done) Mint.fill else Sunk)
                        .border(2.dp, if (done) Ink else InkLow, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    if (done) {
                        Canvas(Modifier.size(14.dp)) {
                            val p = Path().apply {
                                moveTo(size.width * 0.18f, size.height * 0.52f)
                                lineTo(size.width * 0.42f, size.height * 0.78f)
                                lineTo(size.width * 0.84f, size.height * 0.22f)
                            }
                            drawPath(
                                p,
                                color = Color.White,
                                style = Stroke(width = size.minDimension * 0.22f),
                            )
                        }
                    }
                }
            }
        }
    }
}
