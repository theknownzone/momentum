package com.momentum.focus.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid

/**
 * Three pulsing dots and a word, for the two places the app waits on a model.
 *
 * A spinner would be the obvious thing and the wrong one — there is not one
 * anywhere else in this app, and a Material circle spinning on cut paper reads
 * as a component from a different product that wandered in.
 *
 * Tween rather than a spring, against the usual rule: infiniteRepeatable needs
 * a duration to repeat over, and a spring has none. This is the same exception
 * the skeleton bars already take.
 */
@Composable
fun ThinkingDots(
    label: String,
    modifier: Modifier = Modifier,
    dot: Color = Ink,
    labelColor: Color = InkMid,
) {
    val transition = rememberInfiniteTransition(label = "think")
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        repeat(3) { i ->
            val fade by transition.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    tween(600, delayMillis = i * 180),
                    RepeatMode.Reverse,
                ),
                label = "d$i",
            )
            Spacer(
                Modifier
                    .size(7.dp)
                    .alpha(fade)
                    .clip(CircleShape)
                    .background(dot),
            )
            Spacer(Modifier.width(5.dp))
        }
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = labelColor)
    }
}
