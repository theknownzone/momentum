package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.achievements
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.Doodle
import com.momentum.focus.ui.components.StreakLadder
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.ui.components.GlassSection
import com.momentum.focus.ui.components.Locked
import com.momentum.focus.ui.components.PactBanner
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.components.AVATAR_COUNT
import com.momentum.focus.ui.components.Avatar3D
import com.momentum.focus.ui.components.StickerCard
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.i18n.Lang
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.block.Admin
import com.momentum.focus.ui.util.rememberHaptics

@Composable
fun ProfileScreen(
    data: AppData,
    onCrown: (Boolean) -> Unit,
    onAvatar: (Int, Int) -> Unit,
    onSkin: (Int) -> Unit,
    onName: (String) -> Unit,
    onPlans: () -> Unit,
    onLang: (String) -> Unit = {},
    onSettings: () -> Unit = {},
) {
    val str = strings()
    val haptics = rememberHaptics()
    val context = LocalContext.current
    var name by remember(data.userName) { mutableStateOf(data.userName) }
    // The glass takes its tint from the skin, so choosing one changes the very
    // screen you chose it on instead of a single card two screens away.
    val skinNow = LocalSkin.current

    // Device admin is granted on a system screen, so the only honest way to
    // know whether it stuck is to re-read it every time this screen resumes.
    val owner = LocalLifecycleOwner.current
    var adminRefresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) adminRefresh++
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    val adminOn = remember(adminRefresh) { Admin.isActive(context) }
    // The switch used to flip the moment it was touched and only then ask for
    // admin. Cancel the system dialog, or have it fail to open at all, and the
    // app claimed the app could not be uninstalled while nothing was stopping
    // it. Crown mode is now whatever the system actually granted.
    LaunchedEffect(adminOn) {
        if (!adminOn && data.crownMode && !data.pactLive) onCrown(false)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        // Marks around the player card, the way a page someone owns gets
        // scribbled on. They sit in a Box with the card rather than in the
        // column, so they overlap its corners instead of pushing it down.
        Box(Modifier.fillMaxWidth()) {
            PlayerCard(data)
            Doodle(
                seed = 2,
                color = Mint.accent,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 6.dp, y = (-10).dp)
                    .size(22.dp),
            )
            Doodle(
                seed = 0,
                color = Sky.accent,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .offset(x = (-8).dp, y = 10.dp)
                    .size(26.dp),
            )
            Doodle(
                seed = 1,
                color = Tang.accent,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .offset(x = 12.dp)
                    .size(18.dp),
            )
        }

        Spacer(Modifier.height(18.dp))

        PactBanner(data.lockUntilEpochMs, Modifier.fillMaxWidth())

        Spacer(Modifier.height(Paper.Gap))

        // The loudest card on the screen after the player. It sat here in plain
        // cream, quieter than the four tiles beneath it, which made the one
        // thing on this page that is a decision look like a row of settings.
        Aura(
            color = Tang.accent,
            strength = if (data.premium) 0.55f else 0.42f,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    // Inset so the halo has somewhere to land. The aura draws
                    // behind its content, and a card filling the full width
                    // buries it under opaque paint — the glow was rendering
                    // the whole time and simply had no margin to show in.
                    .padding(horizontal = 10.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(Paper.CardRadius))
                    // Once bought, the card should stop looking like the pitch.
                    // Leaving it gold means the thing someone already paid for
                    // keeps advertising itself at them every time they open
                    // this screen.
                    .background(if (data.premium) Mint.fill.lit() else Butter.fill.lit())
                    .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.tap(); onPlans()
                    }
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Ink),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("\uD83D\uDC51", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    // Dark letters on a gold glow, not gold on gold. Set in
                    // GoldNeon it was yellow text on a yellow card and simply
                    // vanished — the glow behind carries the gold, so the
                    // letters themselves have to contrast with the fill.
                    Aura(color = GoldNeon, strength = 0.5f) {
                        Text(
                            if (data.premium) "MEMBER SINCE DAY ONE" else "MOMENTUM PREMIUM",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Butter.on,
                        )
                    }
                    // The promise stays on the card, not only inside the screen
                    // it opens. Someone who never taps through should still be
                    // able to see that nothing protective sits behind the price.
                    Text(
                        if (data.premium) "Thank you — it keeps this thing alive."
                        // The count ties this card to the blurred rows behind
                        // the paywall, so the number and the thing it refers to
                        // are the same number.
                        else "3 locked · blocking always stays free",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Butter.on.copy(alpha = 0.8f),
                    )
                }
                // The price belongs on the card. Without it the only way to
                // learn what this costs is to tap through, so people tap to
                // find out and leave — which reads as a dead end rather than
                // an offer.
                if (!data.premium) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            "\u20B9399",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Butter.on,
                        )
                        // A gold card reads as a subscription until it says
                        // otherwise, and that assumption is the single biggest
                        // reason a student closes this without tapping.
                        Text(
                            "one-time",
                            style = MaterialTheme.typography.labelSmall,
                            color = Butter.on.copy(alpha = 0.7f),
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    "\u203A",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Butter.on,
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        // One card, four columns — the shape the reference uses, and the reason
        // it works: an icon row scans in a glance where stacked text rows have
        // to be read. These four used to be rows inside a section that stays
        // collapsed, which is how Plans stayed invisible for a whole release.

        GlassSection("Tum", "Naam, avatar, theme", tint = skinNow.petal, initiallyOpen = true) {

            // ---- avatar ----
            Text(
                "AVATAR",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(6) { i ->
                    val sticker = stickerFor(i)
                    val on = data.avatarColor == i
                    Box(
                        Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clip(CircleShape)
                            .background(sticker.fill)
                            .border(if (on) Paper.Outline else 1.dp, Ink, CircleShape)
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick(); onAvatar(data.avatarShape, i)
                            }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // One row of six, matching the colour row above it. It used to
                // split five and one, and with the shape list trimmed that
                // left a single avatar stretched across the full width.
                repeat(AVATAR_COUNT) { shape ->
                    val on = data.avatarShape == shape
                    Box(
                        Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (on) Sunk else CreamCard)
                            .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(12.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick(); onAvatar(shape, data.avatarColor)
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Avatar3D(
                            colorIndex = data.avatarColor,
                            shapeIndex = shape,
                            size = 40.dp,
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            // ---- themes ----
            Text("THEMES", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "Unlocked by levelling up",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(10.dp))
            Skin.entries.filter { it.ordinal < Skin.RAKHI.ordinal }.forEach { skin ->
                val i = skin.ordinal
                // Premium unlocks every theme immediately. This is the only
                // thing the paid tier actually changes, and it changes it by
                // giving something early rather than by taking anything away —
                // a free user still earns every theme by levelling, exactly as
                // before.
                val open = data.premium || skin.unlockedAt(data.level)
                val on = data.skin == i
                // Frosted rather than merely labelled: a locked theme that
                // looks identical to an unlocked one except for a word at the
                // end reads as available, and people tap it and get nothing.
                Locked(
                    locked = !open,
                    label = "LEVEL ${skin.unlockLevel}",
                    modifier = Modifier.fillMaxWidth(),
                ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Sunk else CreamCard)
                        .border(if (on) Paper.Outline else 2.dp, Ink, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            if (open) { haptics.confirm(); onSkin(i) } else haptics.reject()
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (open) skin.petal else Sunk)
                            .border(2.dp, Ink, RoundedCornerShape(10.dp))
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            skin.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (open) Ink else InkLow,
                        )
                        Text(
                            when {
                                !open -> "Unlocks at level ${skin.unlockLevel}"
                                skin.unlockLevel == 1 && skin.ordinal >= Skin.RAKHI.ordinal ->
                                    "Seasonal · ${skin.blurb}"
                                else -> skin.blurb
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMid,
                        )
                    }
                    if (on) {
                        Text("IN USE", style = MaterialTheme.typography.labelSmall, color = Mint.accent)
                    }
                }
                }
            }

            Spacer(Modifier.height(20.dp))

            // ---- lifetime numbers ----
            StickerCard(sticker = Emerald, modifier = Modifier.fillMaxWidth()) {
                Text("LIFETIME", style = MaterialTheme.typography.labelSmall, color = Mint.on.copy(alpha = 0.75f))
                Spacer(Modifier.height(12.dp))
                // Every line uses the card's own dark-on-hue colour. Giving each
                // row its own accent looked like confetti and was unreadable.
                StatLine("Focused", "${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m")
                StatLine("Spent on distraction", "${data.spentMinutes}m")
                StatLine("Sessions finished", "${data.sessions.count { it.completed }}")
                StatLine("Urges beaten", "${data.urgesSurvived}")
                StatLine("Best streak", "${maxOf(data.bestStreak, data.streakDays)} days")
            }

            Spacer(Modifier.height(Paper.Gap))

            // ---- editable name ----
            Text(
                "NAME",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(18); onName(it.trim()) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(Modifier.height(Paper.Gap))

            // ---- language ----
            // Sits with the theme rather than under App, because this is a
            // preference about how the app reads to you, not about what it
            // blocks. Both labels stay in their own language so the option you
            // are not using is still legible.
            Text(
                str.common.languageTitle.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                str.common.languageSubtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Lang.entries.forEach { option ->
                    val on = data.lang == option.code
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(Paper.ChipRadius))
                            // petal, not accent: the Independence skin's accent
                            // is a dark green, and Ink on it is unreadable.
                            // Every petal is a pastel, so the label survives
                            // whichever skin is on.
                            .background(
                                if (on) skinNow.petal else MaterialTheme.colorScheme.surface
                            )
                            .border(
                                if (on) Paper.Outline else 1.dp,
                                Ink,
                                RoundedCornerShape(Paper.ChipRadius),
                            )
                            .clickableNoRipple(remember(option) { MutableInteractionSource() }) {
                                haptics.tick(); onLang(option.code)
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            option.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = Ink,
                        )
                    }
                }
            }

        }

        Spacer(Modifier.height(Paper.Gap))

        // What the streak is climbing towards. The count alone answers "how
        // long" and leaves "until what" unasked anywhere in the app.
        StreakLadder(data, Modifier.fillMaxWidth())

        Spacer(Modifier.height(18.dp))

        // The one door out of this screen. Everything configurable moved
        // behind it, so Profile is now only ever about the person.
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .clickableNoRipple(remember { MutableInteractionSource() }) {
                    haptics.tap(); onSettings()
                }
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.Filled.Tune,
                contentDescription = null,
                tint = Ink,
                modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    str.common.settings,
                    style = MaterialTheme.typography.titleMedium,
                    color = Ink,
                )
                Text(
                    str.common.settingsSub,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                )
            }
            Icon(
                Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = InkMid,
                modifier = Modifier.size(22.dp),
            )
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyLarge,
            color = Mint.on.copy(alpha = 0.72f),
            modifier = Modifier.weight(1f),
        )
        Text(value, style = MaterialTheme.typography.titleMedium, color = Mint.on)
    }
}



/** Rank names by level. Numbers alone are a scoreboard; names are an identity. */
private fun rankFor(level: Int): String = when {
    level >= 20 -> "Untouchable"
    level >= 15 -> "Locked in"
    level >= 10 -> "Relentless"
    level >= 6 -> "Consistent"
    level >= 3 -> "Warming up"
    else -> "Rookie"
}

/**
 * The player card. Level ring, rank, XP to next level, and the badges already
 * earned — the things a game shows first, because progress you can see is the
 * only kind that pulls anyone back tomorrow.
 */
@Composable
private fun PlayerCard(data: AppData) {
    val sticker = stickerFor(data.avatarColor)
    // Premium's only visible reward inside the app itself. Everything else the
    // unlock buys is capacity — more profiles, longer history — which is felt
    // rather than seen, so the card someone looks at every day gets the halo.
    val glow = data.premium
    val progress by animateFloatAsState(
        data.xpIntoLevel / 600f, Motion.settle(), label = "xp"
    )
    val unlocked = data.achievements().filter { it.unlocked }

    Aura(
        color = if (glow) sticker.fill else Color.Transparent,
        strength = if (glow) 0.38f else 0f,
        modifier = Modifier.fillMaxWidth(),
    ) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(Ink)
            .border(
                if (glow) Paper.Outline else 0.dp,
                if (glow) sticker.fill else Color.Transparent,
                RoundedCornerShape(Paper.CardRadius),
            )
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(76.dp)) {
                    val stroke = 7.dp.toPx()
                    val arc = Size(size.width - stroke, size.height - stroke)
                    val tl = Offset(stroke / 2, stroke / 2)
                    drawArc(
                        InkLow.copy(alpha = 0.3f), -90f, 360f, false, tl, arc,
                        style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                    drawArc(
                        sticker.fill, -90f, 360f * progress, false, tl, arc,
                        style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                }
                Avatar3D(
                    colorIndex = data.avatarColor,
                    shapeIndex = data.avatarShape,
                    size = 48.dp,
                )
            }

            Spacer(Modifier.width(16.dp))

            Column(Modifier.weight(1f)) {
                Text(
                    "LEVEL ${data.level} · ${rankFor(data.level).uppercase()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = sticker.fill,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    data.userName,
                    style = MaterialTheme.typography.headlineSmall,
                    color = CreamCard,
                )
                Text(
                    "${600 - data.xpIntoLevel} xp to level ${data.level + 1}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkLow,
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("${data.streakDays}d streak", Butter)
            Chip("${data.earnedMinutes / 60}h focused", Mint)
            Chip("${unlocked.size} badges", Lilac)
        }

        // The chips are three totals with no sense of direction — "14h focused"
        // reads the same whether this week was the best one yet or the first in
        // a fortnight. Seven bars answer that without adding a number to read.
        val today = remember { java.time.LocalDate.now().toEpochDay() }
        val week = remember(data.sessions, today) {
            val b = IntArray(7)
            data.sessions.filter { it.completed }.forEach { s ->
                val ago = (today - s.startedAtEpochDay).toInt()
                if (ago in 0..6) b[6 - ago] += s.minutes
            }
            b.toList()
        }
        if (week.any { it > 0 }) {
            Spacer(Modifier.height(14.dp))
            val peak = week.max().coerceAtLeast(1)
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(38.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                week.forEachIndexed { i, m ->
                    // An empty day still gets a sliver, so the row reads as
                    // seven days rather than as however many were studied.
                    val frac = (m.toFloat() / peak).coerceAtLeast(0.08f)
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight(frac)
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                if (i == 6) sticker.fill
                                else CreamCard.copy(alpha = if (m > 0) 0.55f else 0.18f)
                            )
                    )
                }
            }
        }

        if (unlocked.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                unlocked.take(6).forEachIndexed { i, _ ->
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(stickerFor(i).fill)
                    )
                }
            }
        }
    }
    }
}

@Composable
private fun Chip(text: String, sticker: Sticker) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(sticker.fill.copy(alpha = 0.18f))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text, style = MaterialTheme.typography.bodyMedium, color = sticker.fill)
    }
}
