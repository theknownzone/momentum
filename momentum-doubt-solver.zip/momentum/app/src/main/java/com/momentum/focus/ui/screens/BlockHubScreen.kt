package com.momentum.focus.ui.screens

import com.momentum.focus.ui.util.verticalScrollWithFade

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileCard
import com.momentum.focus.ui.components.TileObject
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

/**
 * Everything that blocks something, in one place.
 *
 * These controls were scattered by accident rather than design: the app list
 * opened from a Home card, per-app caps were buried inside that list, feeds
 * had their own Home card, profiles and class hours sat in a long settings
 * column next to avatars and exam dates. Four related answers to one question
 * — what is switched off — in four unrelated places.
 *
 * The hub does not own any of them. Each row still opens the screen that does
 * the work, so nothing was rewritten to build this; what changed is that there
 * is now one obvious place to look.
 */
@Composable
fun BlockHubScreen(
    data: AppData,
    onApps: () -> Unit,
    onFeeds: () -> Unit,
    onProfiles: () -> Unit,
    onSchedule: () -> Unit,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScrollWithFade(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 24.dp),
    ) {
        Text("BLOCK", style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Text(
            "Kya band hai",
            style = MaterialTheme.typography.displayMedium,
            color = Ink,
        )
        Text(
            "Rokne wali har cheez yahan hai. Apps, feeds, limits, aur kab lagu ho.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp),
        )

        Spacer(Modifier.height(20.dp))

        HubRow(
            title = "Apps",
            detail = if (data.blockedPackages.isEmpty()) "Koi app band nahi"
            else "${data.blockedPackages.size} apps band" +
                if (data.dailyCapMinutes.isEmpty()) ""
                else " · ${data.dailyCapMinutes.size} pe daily limit",
            sticker = Tang,
            art = TileArt.Apps,
        ) { haptics.tap(); onApps() }

        HubRow(
            title = "Feeds",
            detail = if (data.blockedSurfaces.isEmpty()) "Shorts aur Reels chalu hain"
            else "${data.blockedSurfaces.size} feeds band · app khuli rehti hai",
            sticker = Mint,
            art = TileArt.Feed,
        ) { haptics.tap(); onFeeds() }

        HubRow(
            title = "Profiles",
            detail = data.profiles.firstOrNull { it.id == data.activeProfileId }?.let {
                "${it.name} chalu hai"
            } ?: if (data.profiles.isEmpty()) "Koi profile nahi"
            else "${data.profiles.size} saved",
            sticker = Sky,
            art = TileArt.Person,
        ) { haptics.tap(); onProfiles() }

        HubRow(
            title = "Kab lagu ho",
            detail = if (!data.classHoursOn) "Class hours off"
            else "${data.classStartHour}:00–${data.classEndHour}:00 · " +
                "hafte mein ${data.classDays.size} din",
            sticker = Butter,
            art = TileArt.Calendar,
        ) { haptics.tap(); onSchedule() }

        Spacer(Modifier.height(20.dp))

        Text(
            "Pact ke dauran in sab ko sirf kas sakte ho — dheela nahi kar sakte.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(20.dp))

        SquishButton(
            label = "Done",
            sticker = Emerald,
            modifier = Modifier.fillMaxWidth(),
        ) { haptics.confirm(); onDone() }
    }
}

@Composable
private fun HubRow(
    title: String,
    detail: String,
    sticker: Sticker,
    art: TileArt,
    onClick: () -> Unit,
) {
    // Same punched tile as Home — glass rows on this screen sat next to
    // dotted cards everywhere else and read as a different app.
    TileCard(
        fill = sticker.fill,
        dots = Ink,
        onClick = onClick,
        modifier = Modifier.padding(bottom = 10.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TileObject(art = art, fill = sticker.accent, size = 34.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.headlineSmall,
                    color = sticker.on,
                )
                Text(
                    detail,
                    style = MaterialTheme.typography.bodyMedium,
                    color = sticker.on.copy(alpha = 0.8f),
                )
            }
            Text("›", style = MaterialTheme.typography.displayMedium, color = sticker.on)
        }
    }
}
