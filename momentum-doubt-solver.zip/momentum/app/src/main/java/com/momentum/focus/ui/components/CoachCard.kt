package com.momentum.focus.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.momentum.focus.ai.CoachReport
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import java.util.concurrent.TimeUnit

/**
 * The weekly read, as a card rather than a conversation.
 *
 * Still deliberately has no input box, and the reason is unchanged: a report
 * you can argue with is a report you open instead of studying. Typing at a
 * model now happens in one place only —
 * [com.momentum.focus.ui.components.DoubtSheet] — where it is capped at five
 * questions and the session clock keeps running underneath it. Neither of
 * those guards exists here, so neither does the input box.
 */
@Composable
fun CoachCard(
    report: CoachReport,
    busy: Boolean,
    error: String?,
    sessionsNeeded: Int,
    onRun: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val str = strings()
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(Lilac.fill)
            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
            .padding(16.dp),
    ) {
        Text(str.coach.label, style = MaterialTheme.typography.labelSmall, color = Lilac.on)
        Spacer(Modifier.height(4.dp))
        Text(str.coach.title, style = MaterialTheme.typography.headlineSmall, color = Ink)

        when {
            busy -> {
                Spacer(Modifier.height(14.dp))
                ThinkingDots(str.coach.thinking, labelColor = Lilac.on)
                Spacer(Modifier.height(12.dp))
                // Skeleton rather than a blank gap, so the card keeps its shape
                // while the answer is on its way and nothing jumps when it lands.
                repeat(3) {
                    SkeletonBar(widthFraction = if (it == 2) 0.6f else 1f)
                    Spacer(Modifier.height(8.dp))
                }
            }

            error != null -> {
                Spacer(Modifier.height(10.dp))
                Text(error, style = MaterialTheme.typography.bodyMedium, color = Tang.on)
                Spacer(Modifier.height(12.dp))
                SquishButton(str.coach.tryAgain, Lilac, Modifier.fillMaxWidth()) { onRun() }
            }

            sessionsNeeded > 0 -> {
                Spacer(Modifier.height(8.dp))
                Text(
                    str.coach.notEnoughYet(sessionsNeeded),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Lilac.on,
                )
            }

            report.isEmpty -> {
                Spacer(Modifier.height(8.dp))
                Text(str.coach.intro, style = MaterialTheme.typography.bodyMedium, color = Lilac.on)
                Spacer(Modifier.height(14.dp))
                SquishButton(str.coach.readMyWeek, Lilac, Modifier.fillMaxWidth()) { onRun() }
            }

            else -> {
                Spacer(Modifier.height(10.dp))
                Text(report.headline, style = MaterialTheme.typography.bodyLarge, color = Ink)

                if (report.findings.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    Text(
                        str.coach.whatIFound,
                        style = MaterialTheme.typography.labelSmall,
                        color = Lilac.on,
                    )
                    Spacer(Modifier.height(6.dp))
                    report.findings.forEach { Bullet(it) }
                }

                if (report.actions.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    Text(
                        str.coach.whatToDo,
                        style = MaterialTheme.typography.labelSmall,
                        color = Lilac.on,
                    )
                    Spacer(Modifier.height(6.dp))
                    report.actions.forEach { Bullet(it) }
                }

                Spacer(Modifier.height(14.dp))
                val days = ((System.currentTimeMillis() - report.generatedAtMs)
                    .coerceAtLeast(0L) / TimeUnit.DAYS.toMillis(1)).toInt()
                Text(
                    if (days == 0) str.coach.lastReadToday else str.coach.lastRead(days),
                    style = MaterialTheme.typography.labelSmall,
                    color = Lilac.on.copy(alpha = 0.75f),
                )
            }
        }

        // Zomato puts the same admission under its assistant, and it belongs
        // here for the same reason: this is a model reading numbers, not a
        // teacher who knows the student.
        Spacer(Modifier.height(12.dp))
        Text(
            str.coach.disclaimer,
            style = MaterialTheme.typography.labelSmall,
            color = Lilac.on.copy(alpha = 0.7f),
        )
    }
}

@Composable
private fun Bullet(text: String) {
    Row(Modifier.padding(bottom = 6.dp)) {
        Text("·  ", style = MaterialTheme.typography.bodyMedium, color = Lilac.on)
        Text(text, style = MaterialTheme.typography.bodyMedium, color = Ink)
    }
}

@Composable
private fun SkeletonBar(widthFraction: Float) {
    val t = rememberInfiniteTransition(label = "skel")
    val a by t.animateFloat(
        initialValue = 0.18f,
        targetValue = 0.34f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "a",
    )
    Spacer(
        Modifier
            .fillMaxWidth(widthFraction)
            .height(12.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Ink.copy(alpha = a)),
    )
}
