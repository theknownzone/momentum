package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import kotlinx.coroutines.delay
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import com.momentum.focus.ui.theme.Skin
import kotlin.math.PI
import kotlin.math.sin

/**
 * How many pieces are in the air at once.
 *
 * Was twenty-six, which on a hero this size is a piece every eighty pixels —
 * sparse enough that you had to be told the weather was there. It is one draw
 * pass either way, so the cost of tripling it is three times almost nothing.
 */
private const val COUNT = 80

/**
 * The weather a skin is named after.
 *
 * Every earned skin promised something in its own blurb — "rain on the window",
 * "the last hour before an exam" — and delivered a change of four colours. A
 * theme called Monsoon with no rain in it is a name doing work the app never
 * did, and after the second one nobody believes the third.
 *
 * Each piece's position is a pure function of its index and the clock, so
 * nothing is stored, nothing accumulates, and the whole layer is one animation
 * read in the draw phase rather than twenty-six of them recomposing.
 *
 * Festival skins are left alone — they have their own artwork and adding
 * weather on top of a diya would be two ideas fighting.
 */
@Composable
fun SkinWeather(skin: Skin, modifier: Modifier = Modifier) {
    if (!skin.hasWeather()) return

    // Held back until the screen has arrived. Home is the heaviest tree in the
    // app — hero artwork, exam news, the score, the tiles — and starting a
    // frame-rate animation in the same composition meant the tab bar's own
    // animation lost its frames to this one. Switching to Home stuttered while
    // every other tab was smooth, and this was why. Three hundred milliseconds
    // is after the switch and before anyone has looked at the hero.
    var awake by remember(skin) { mutableStateOf(false) }
    LaunchedEffect(skin) {
        delay(300)
        awake = true
    }
    if (!awake) return

    val transition = rememberInfiniteTransition(label = "weather")
    // One slow pass. Every piece takes its own offset from this, so they do not
    // move in lockstep despite sharing a clock.
    val t = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(skin.weatherMs(), easing = LinearEasing)),
        label = "drift",
    )
    // Second, much slower hand — used for the lightning in Monsoon, which must
    // not fire on the same beat as the rain falls.
    val slow = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing)),
        label = "slow",
    )

    Box(
        modifier.drawBehind {
            when (skin) {
                Skin.SAKURA -> petals(t.value, skin.petal)
                Skin.MONSOON -> rain(t.value, slow.value, skin.petal)
                Skin.EMBER -> embers(t.value, skin.petal)
                Skin.MIDNIGHT -> stars(t.value, skin.petal)
                Skin.GOLD -> motes(t.value, skin.petal)
                else -> Unit
            }
        },
    )
}

private fun Skin.hasWeather() = this in setOf(
    Skin.SAKURA, Skin.MONSOON, Skin.EMBER, Skin.MIDNIGHT, Skin.GOLD,
)

/** Rain is quick, embers dawdle, stars barely move. */
private fun Skin.weatherMs() = when (this) {
    Skin.MONSOON -> 1400
    Skin.SAKURA -> 6000
    Skin.EMBER -> 4200
    Skin.GOLD -> 9000
    else -> 12000
}

/** Deterministic pseudo-random in 0..1 from an index and a salt. */
private fun rnd(i: Int, salt: Int): Float {
    val x = sin((i * 12.9898 + salt * 78.233)) * 43758.5453
    return (x - kotlin.math.floor(x)).toFloat()
}

/** Falling, turning, drifting sideways as they go. */
private fun DrawScope.petals(t: Float, colour: Color) {
    repeat(COUNT) { i ->
        val speed = 0.6f + rnd(i, 1) * 0.8f
        val y = ((t * speed + rnd(i, 2)) % 1f) * (size.height + 40f) - 20f
        val sway = sin((t * speed * 2f + rnd(i, 3)) * 2f * PI.toFloat()) * size.width * 0.05f
        val x = rnd(i, 4) * size.width + sway
        val r = 5f + rnd(i, 5) * 7f
        rotate(degrees = (t * 360f * speed + i * 37f), pivot = Offset(x, y)) {
            // A petal, not a dot: wider than tall and rounded at one end.
            drawOval(
                color = colour.copy(alpha = 0.55f + rnd(i, 6) * 0.35f),
                topLeft = Offset(x - r, y - r * 0.55f),
                size = Size(r * 2f, r * 1.1f),
            )
        }
    }
}

/** Streaks, slanted, with the sky flickering behind them now and then. */
private fun DrawScope.rain(t: Float, slow: Float, colour: Color) {
    // The flash: a short window in a long cycle, doubled so it stutters the way
    // real lightning does rather than pulsing like a lamp.
    val flash = when {
        slow < 0.02f -> 1f - slow / 0.02f
        slow in 0.04f..0.06f -> 1f - (slow - 0.04f) / 0.02f
        else -> 0f
    }
    if (flash > 0f) {
        drawRect(color = Color.White.copy(alpha = 0.30f * flash))
    }
    repeat(COUNT + 14) { i ->
        val speed = 0.8f + rnd(i, 11) * 0.5f
        val y = ((t * speed + rnd(i, 12)) % 1f) * (size.height + 60f) - 30f
        val x = rnd(i, 13) * size.width
        val len = 20f + rnd(i, 14) * 26f
        drawLine(
            color = colour.copy(alpha = 0.42f + rnd(i, 15) * 0.34f),
            start = Offset(x, y),
            end = Offset(x - len * 0.28f, y + len),
            strokeWidth = 2.4f,
        )
    }
}

/** Rising, fading as they climb, brighter at the bottom. */
private fun DrawScope.embers(t: Float, colour: Color) {
    repeat(COUNT) { i ->
        val speed = 0.5f + rnd(i, 21) * 0.9f
        val p = (t * speed + rnd(i, 22)) % 1f
        val y = size.height - p * (size.height + 30f)
        val sway = sin((p * 3f + rnd(i, 23)) * 2f * PI.toFloat()) * size.width * 0.035f
        val x = rnd(i, 24) * size.width + sway
        // Fades out as it rises — an ember that reaches the top still burning
        // reads as a bug rather than as fire.
        val fade = (1f - p) * (0.60f + rnd(i, 25) * 0.40f)
        drawCircle(
            color = colour.copy(alpha = fade),
            radius = 2.4f + rnd(i, 26) * 3.4f,
            center = Offset(x, y),
        )
    }
}

/** Fixed points that breathe, each on its own phase. */
private fun DrawScope.stars(t: Float, colour: Color) {
    repeat(COUNT + 10) { i ->
        val x = rnd(i, 31) * size.width
        val y = rnd(i, 32) * size.height
        val phase = (t + rnd(i, 33)) % 1f
        val twinkle = 0.25f + 0.75f * (0.5f + 0.5f * sin(phase * 2f * PI.toFloat()))
        val r = 1.4f + rnd(i, 34) * 2.4f
        drawCircle(
            color = colour.copy(alpha = 0.40f + 0.55f * twinkle),
            radius = r,
            center = Offset(x, y),
        )
        // The brightest few get a cross of light, which is what separates a
        // star field from a dusting of dots.
        if (rnd(i, 35) > 0.86f) {
            val arm = r * 4f * twinkle
            val a = colour.copy(alpha = 0.55f * twinkle)
            drawLine(a, Offset(x - arm, y), Offset(x + arm, y), 1f)
            drawLine(a, Offset(x, y - arm), Offset(x, y + arm), 1f)
        }
    }
}

/** Slow specks going sideways, catching the light as they turn. */
private fun DrawScope.motes(t: Float, colour: Color) {
    repeat(COUNT) { i ->
        val speed = 0.4f + rnd(i, 41) * 0.7f
        val x = ((t * speed + rnd(i, 42)) % 1f) * (size.width + 30f) - 15f
        val drift = sin((t * speed + rnd(i, 43)) * 2f * PI.toFloat()) * size.height * 0.06f
        val y = rnd(i, 44) * size.height + drift
        val glint = 0.5f + 0.5f * sin((t * 4f + rnd(i, 45)) * 2f * PI.toFloat())
        val r = 1.8f + rnd(i, 46) * 3.2f
        drawPath(
            Path().apply {
                moveTo(x, y - r * 2f)
                lineTo(x + r, y)
                lineTo(x, y + r * 2f)
                lineTo(x - r, y)
                close()
            },
            color = colour.copy(alpha = 0.38f + 0.50f * glint),
        )
    }
}
