package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import kotlinx.coroutines.delay
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import com.momentum.focus.ui.theme.Skin
import kotlin.math.PI
import kotlin.math.sin

/**
 * How many pieces are in the air at once.
 *
 * Was twenty-six, which on a hero this size is a piece every eighty pixels —
 * sparse enough that you had to be told the weather was there. It is one draw
 * pass either way, so the cost of tripling it is three times almost nothing.
 */
private const val COUNT = 140

/**
 * The weather a skin is named after.
 *
 * Every earned skin promised something in its own blurb — "rain on the window",
 * "the last hour before an exam" — and delivered a change of four colours. A
 * theme called Monsoon with no rain in it is a name doing work the app never
 * did, and after the second one nobody believes the third.
 *
 * Each piece's position is a pure function of its index and the clock, so
 * nothing is stored, nothing accumulates, and the whole layer is one animation
 * read in the draw phase rather than twenty-six of them recomposing.
 *
 * Festival skins are left alone — they have their own artwork and adding
 * weather on top of a diya would be two ideas fighting.
 */
@Composable
fun SkinWeather(skin: Skin, modifier: Modifier = Modifier) {
    if (!skin.hasWeather()) return

    // Held back until the screen has arrived. Home is the heaviest tree in the
    // app — hero artwork, exam news, the score, the tiles — and starting a
    // frame-rate animation in the same composition meant the tab bar's own
    // animation lost its frames to this one. Switching to Home stuttered while
    // every other tab was smooth, and this was why. Three hundred milliseconds
    // is after the switch and before anyone has looked at the hero.
    var awake by remember(skin) { mutableStateOf(false) }
    LaunchedEffect(skin) {
        delay(300)
        awake = true
    }
    if (!awake) return

    val transition = rememberInfiniteTransition(label = "weather")
    // One slow pass. Every piece takes its own offset from this, so they do not
    // move in lockstep despite sharing a clock.
    val t = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(skin.weatherMs(), easing = LinearEasing)),
        label = "drift",
    )
    // Second, much slower hand — used for the lightning in Monsoon, which must
    // not fire on the same beat as the rain falls.
    val slow = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing)),
        label = "slow",
    )

    Box(
        modifier.drawBehind {
            when (skin) {
                Skin.SAKURA -> petals(t.value, skin.petal)
                Skin.MONSOON -> rain(t.value, slow.value, skin.petal)
                Skin.EMBER -> embers(t.value, skin.petal)
                Skin.MIDNIGHT -> stars(t.value, skin.petal)
                Skin.GOLD -> motes(t.value, skin.petal)
                Skin.RAKHI, Skin.DIWALI, Skin.HOLI, Skin.TIRANGA, Skin.JANMASHTAMI ->
                    confetti(t.value, skin.petal)
                else -> Unit
            }
        },
    )
}

private fun Skin.hasWeather() = this in setOf(
    Skin.SAKURA, Skin.MONSOON, Skin.EMBER, Skin.MIDNIGHT, Skin.GOLD,
    Skin.RAKHI, Skin.DIWALI, Skin.HOLI, Skin.TIRANGA, Skin.JANMASHTAMI,
)

/** Rain is quick, embers dawdle, stars barely move. */
private fun Skin.weatherMs() = when (this) {
    // Rain was 1400ms and the drops were forty pixels long, which together
    // draw ropes rather than rain. Real rain falls slower than it looks and
    // each drop is short — the length comes from many of them in a line, not
    // from one long streak.
    Skin.MONSOON -> 3200
    Skin.SAKURA -> 9000
    Skin.EMBER -> 5200
    Skin.GOLD -> 11000
    else -> 4200
}

/** Deterministic pseudo-random in 0..1 from an index and a salt. */
private fun rnd(i: Int, salt: Int): Float {
    val x = sin((i * 12.9898 + salt * 78.233)) * 43758.5453
    return (x - kotlin.math.floor(x)).toFloat()
}

/** Branch in the corner, petals falling off it — not random pink rain. */
private fun DrawScope.petals(t: Float, colour: Color) {
    // Petals that already landed, resting along the bottom. Without them the
    // fall goes on forever and nothing accumulates — the tree sheds and the
    // ground stays clean, which is the one thing that never happens.
    repeat(14) { i ->
        val x = rnd(i, 70) * size.width
        val y = size.height - 2f - rnd(i, 71) * 7f
        val r = 4f + rnd(i, 72) * 5f
        drawOval(
            color = Color(0xFF1A1A1A).copy(alpha = 0.18f),
            topLeft = Offset(x - r * 0.9f, y + 1.5f),
            size = Size(r * 2.2f, r * 0.55f),
        )
        rotate(degrees = rnd(i, 73) * 180f, pivot = Offset(x, y)) {
            drawOval(
                color = colour.copy(alpha = 0.30f + rnd(i, 74) * 0.20f),
                topLeft = Offset(x - r, y - r * 0.4f),
                size = Size(r * 2f, r * 0.8f),
            )
        }
    }

    val bark = Color(0xFF5A3A28)
    val limb = Path().apply {
        moveTo(0f, size.height * 0.08f)
        cubicTo(
            size.width * 0.18f, size.height * 0.02f,
            size.width * 0.38f, size.height * 0.16f,
            size.width * 0.62f, size.height * 0.12f,
        )
    }
    drawPath(limb, color = bark, style = Stroke(width = 7f, cap = StrokeCap.Round))
    val twig = Path().apply {
        moveTo(size.width * 0.28f, size.height * 0.08f)
        cubicTo(
            size.width * 0.34f, size.height * 0.00f,
            size.width * 0.40f, size.height * 0.04f,
            size.width * 0.46f, size.height * 0.01f,
        )
    }
    drawPath(twig, color = bark, style = Stroke(width = 4f, cap = StrokeCap.Round))
    repeat(9) { i ->
        val u = (i + 1) / 10f
        val bx = size.width * 0.06f + u * size.width * 0.52f
        val by = size.height * 0.09f + sin(i * 1.7f) * size.height * 0.04f
        drawCircle(colour.copy(alpha = 0.85f), 5.5f + (i % 3), Offset(bx, by))
        drawCircle(Color.White.copy(alpha = 0.35f), 2.2f, Offset(bx - 1.5f, by - 1.5f))
    }
    repeat(COUNT) { i ->
        val speed = 0.45f + rnd(i, 1) * 0.7f
        val born = rnd(i, 4) * 0.58f
        val y = size.height * 0.10f + ((t * speed + rnd(i, 2)) % 1f) * (size.height * 0.95f)
        val sway = sin((t * speed * 2f + rnd(i, 3)) * 2f * PI.toFloat()) * size.width * 0.06f
        val x = born * size.width + sway
        val r = 7f + rnd(i, 5) * 9f
        rotate(degrees = (t * 280f * speed + i * 37f), pivot = Offset(x, y)) {
            drawOval(
                color = colour.copy(alpha = 0.50f + rnd(i, 6) * 0.40f),
                topLeft = Offset(x - r, y - r * 0.55f),
                size = Size(r * 2f, r * 1.1f),
            )
        }
    }
}

/** Streaks, slanted, with the sky flickering behind them now and then. */
private fun DrawScope.rain(t: Float, slow: Float, colour: Color) {
    // Fog first, under everything. Two soft bands, one low and one lower,
    // drifting at different speeds — the thing that makes rain read as weather
    // rather than as lines is that the air behind it is not clear.
    repeat(2) { band ->
        val drift = ((slow * (0.4f + band * 0.3f)) % 1f) * size.width
        val y = size.height * (0.62f + band * 0.18f)
        val h = size.height * 0.34f
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color.Transparent,
                    colour.copy(alpha = 0.10f - band * 0.03f),
                    Color.Transparent,
                ),
                startY = y - h / 2f,
                endY = y + h / 2f,
            ),
            topLeft = Offset(-size.width + drift, y - h / 2f),
            size = Size(size.width * 3f, h),
        )
    }

    // The flash, doubled so it stutters the way lightning does.
    val flash = when {
        slow < 0.02f -> 1f - slow / 0.02f
        slow in 0.04f..0.06f -> 1f - (slow - 0.04f) / 0.02f
        else -> 0f
    }
    if (flash > 0f) {
        drawRect(color = Color.White.copy(alpha = 0.28f * flash))
        val bolt = Path().apply {
            moveTo(size.width * 0.58f, 0f)
            lineTo(size.width * 0.50f, size.height * 0.28f)
            lineTo(size.width * 0.57f, size.height * 0.28f)
            lineTo(size.width * 0.44f, size.height * 0.62f)
            lineTo(size.width * 0.53f, size.height * 0.42f)
            lineTo(size.width * 0.46f, size.height * 0.42f)
            close()
        }
        drawPath(bolt, Color.White.copy(alpha = 0.85f * flash))
        drawPath(bolt, Color(0xFFB8E0FF).copy(alpha = 0.55f * flash), style = Stroke(width = 2.2f))
    }

    // Two depths of falling drop.
    repeat(COUNT) { i ->
        val near = rnd(i, 10) > 0.55f
        val speed = if (near) 0.9f + rnd(i, 11) * 0.3f else 0.45f + rnd(i, 11) * 0.25f
        val cycle = (t * speed + rnd(i, 12)) % 1f
        val y = cycle * (size.height + 60f) - 30f
        val x = rnd(i, 13) * size.width
        val len = if (near) 14f + rnd(i, 14) * 9f else 8f + rnd(i, 14) * 6f
        drawLine(
            color = colour.copy(alpha = if (near) 0.55f else 0.26f),
            start = Offset(x, y),
            end = Offset(x - len * 0.16f, y + len),
            strokeWidth = if (near) 2.2f else 1.4f,
            cap = StrokeCap.Round,
        )
    }

    // Splashes along the bottom edge. Each drop that lands throws two small
    // arcs sideways and fades. This is the detail that separates rain drawn
    // on a screen from rain hitting something — without it the drops simply
    // vanish at the bottom, which is what nothing real does.
    val floor = size.height - 3f
    repeat(COUNT / 3) { i ->
        // Each splash runs on its own offset phase, so they land scattered in
        // time rather than all at once.
        val phase = (t * (1.4f + rnd(i, 50) * 0.6f) + rnd(i, 51)) % 1f
        if (phase > 0.30f) return@repeat
        val life = phase / 0.30f
        val x = rnd(i, 52) * size.width
        val spread = 5f + life * 11f
        val fade = (1f - life) * 0.45f
        // Two arms out, and a bounced droplet over each.
        drawLine(
            color = colour.copy(alpha = fade),
            start = Offset(x, floor),
            end = Offset(x - spread, floor - spread * 0.42f),
            strokeWidth = 1.6f,
            cap = StrokeCap.Round,
        )
        drawLine(
            color = colour.copy(alpha = fade),
            start = Offset(x, floor),
            end = Offset(x + spread, floor - spread * 0.42f),
            strokeWidth = 1.6f,
            cap = StrokeCap.Round,
        )
        drawCircle(
            color = colour.copy(alpha = fade * 0.9f),
            radius = 1.8f * (1f - life),
            center = Offset(x + spread * 1.1f, floor - spread * 0.62f),
        )
        drawCircle(
            color = colour.copy(alpha = fade * 0.9f),
            radius = 1.8f * (1f - life),
            center = Offset(x - spread * 1.1f, floor - spread * 0.62f),
        )
        // The ring left on the surface.
        drawCircle(
            color = colour.copy(alpha = fade * 0.5f),
            radius = spread * 0.75f,
            center = Offset(x, floor),
            style = Stroke(width = 1.2f),
        )
        drawCircle(
            color = colour.copy(alpha = fade * 0.22f),
            radius = spread * 1.35f,
            center = Offset(x, floor),
            style = Stroke(width = 1f),
        )
    }

    frog(size.width * 0.20f, size.height - 8f, t, 0)
    frog(size.width * 0.78f, size.height - 8f, t, 1)
}

private fun DrawScope.frog(fx: Float, fy: Float, t: Float, id: Int) {
    val hop = (sin((t * 1.6f + id) * 2f * PI.toFloat())).let { if (it > 0.65f) (it - 0.65f) * 18f else 0f }
    val blink = sin((t * 3.2f + id * 1.7f) * 2f * PI.toFloat()) > 0.92f
    val y = fy - hop
    val green = Color(0xFF3FAE5A)
    val dark = Color(0xFF2A7A3E)
    val belly = Color(0xFFC8E86A)
    // Back legs
    drawOval(dark, Offset(fx - 30f, y - 14f), Size(20f, 14f))
    drawOval(dark, Offset(fx + 10f, y - 14f), Size(20f, 14f))
    drawOval(green, Offset(fx - 26f, y - 28f), Size(52f, 30f))
    drawOval(belly, Offset(fx - 14f, y - 18f), Size(28f, 16f))
    drawCircle(green, 6.5f, Offset(fx - 22f, y - 6f))
    drawCircle(green, 6.5f, Offset(fx + 22f, y - 6f))
    drawCircle(green, 16f, Offset(fx, y - 36f))
    // Eyes
    drawCircle(green, 8.5f, Offset(fx - 10f, y - 48f))
    drawCircle(green, 8.5f, Offset(fx + 10f, y - 48f))
    if (blink) {
        drawLine(Color(0xFF1A1A1A), Offset(fx - 15f, y - 48f), Offset(fx - 5f, y - 48f), 2.2f)
        drawLine(Color(0xFF1A1A1A), Offset(fx + 5f, y - 48f), Offset(fx + 15f, y - 48f), 2.2f)
    } else {
        drawCircle(Color(0xFFF7FBE8), 4.4f, Offset(fx - 10f, y - 48f))
        drawCircle(Color(0xFFF7FBE8), 4.4f, Offset(fx + 10f, y - 48f))
        drawCircle(Color(0xFF1A1A1A), 2.2f, Offset(fx - 9f, y - 47f))
        drawCircle(Color(0xFF1A1A1A), 2.2f, Offset(fx + 11f, y - 47f))
    }
    drawLine(
        Color(0xFF1A1A1A).copy(alpha = 0.7f),
        Offset(fx - 7f, y - 30f),
        Offset(fx + 7f, y - 30f),
        2f,
    )
}

/** Rising, fading as they climb, brighter at the bottom. */
private fun DrawScope.embers(t: Float, colour: Color) {
    // Ash: grey, slower than the embers and drifting further sideways. Fire
    // throws two things up and only one of them glows; without the dull half
    // the effect reads as fireflies.
    repeat(18) { i ->
        val speed = 0.25f + rnd(i, 60) * 0.35f
        val p = (t * speed + rnd(i, 61)) % 1f
        val y = size.height - p * (size.height + 40f)
        val sway = sin((p * 2.2f + rnd(i, 62)) * 2f * PI.toFloat()) * size.width * 0.10f
        val x = rnd(i, 63) * size.width + sway
        drawCircle(
            color = Color(0xFF8A8A8A).copy(alpha = (1f - p) * 0.22f),
            radius = 1.2f + rnd(i, 64) * 1.8f,
            center = Offset(x, y),
        )
    }

    // A winter fire: logs leaned into a cone, a real flame on them, and smoke
    // climbing the whole hero.
    //
    // It was three flat ovals with a leaf-shaped blob on top — the shape of a
    // fire without any of the parts that make one. Wood stacked the way people
    // actually stack it, a flame with an inner core, and smoke that keeps
    // rising past the top of the frame is what turns a symbol into a scene.
    val cx = size.width * 0.50f
    val base = size.height - 8f
    val wood = Color(0xFF6B3E22)
    val woodDark = Color(0xFF4A2A16)
    val flicker = 0.85f + 0.15f * sin(t * 14f * PI.toFloat())

    // Smoke first, so it passes behind the flame rather than over it.
    repeat(16) { i ->
        val speed = 0.16f + rnd(i, 80) * 0.14f
        val p = (t * speed + rnd(i, 81)) % 1f
        val y = base - 34f - p * (size.height * 0.9f)
        // Widens and thins as it climbs, the way a column of smoke spreads.
        val drift = sin((p * 2.4f + rnd(i, 82)) * 2f * PI.toFloat()) * (14f + p * 46f)
        drawCircle(
            color = Color(0xFFBFB6AC).copy(alpha = (1f - p) * 0.16f),
            radius = 5f + p * 20f + rnd(i, 83) * 5f,
            center = Offset(cx + drift, y),
        )
    }

    // Three logs leaning into each other, plus one lying flat at the front.
    listOf(-1f, 0f, 1f).forEach { lean ->
        val topX = cx + lean * 9f
        val botX = cx + lean * 30f
        drawLine(
            color = if (lean == 0f) woodDark else wood,
            start = Offset(topX, base - 30f),
            end = Offset(botX, base),
            strokeWidth = 9f,
            cap = StrokeCap.Round,
        )
        // The lit face: the side of each log the fire is on.
        drawLine(
            color = colour.copy(alpha = 0.30f),
            start = Offset(topX, base - 30f),
            end = Offset(botX - lean * 3f, base - 6f),
            strokeWidth = 3f,
            cap = StrokeCap.Round,
        )
    }
    drawLine(
        color = wood,
        start = Offset(cx - 42f, base - 2f),
        end = Offset(cx + 40f, base - 5f),
        strokeWidth = 10f,
        cap = StrokeCap.Round,
    )

    // Glow on the ground under it, so the fire is lighting something.
    drawOval(
        color = colour.copy(alpha = 0.16f * flicker),
        topLeft = Offset(cx - 62f, base - 12f),
        size = Size(124f, 22f),
    )

    // The flame: outer body, then a brighter core inside it. One shape is a
    // leaf; two is fire.
    val fh = 40f * flicker
    fun flame(scale: Float, tint: Color, alpha: Float) {
        val h = fh * scale
        val w = 17f * scale
        drawPath(
            Path().apply {
                moveTo(cx, base - 14f)
                cubicTo(cx - w, base - 20f, cx - w * 0.55f, base - 14f - h, cx, base - 14f - h)
                cubicTo(cx + w * 0.55f, base - 14f - h, cx + w, base - 20f, cx, base - 14f)
                close()
            },
            tint.copy(alpha = alpha),
        )
    }
    flame(1f, colour, 0.85f)
    flame(0.55f, Color(0xFFFFF1A8), 0.75f)

    repeat(COUNT) { i ->
        val speed = 0.5f + rnd(i, 21) * 0.9f
        val p = (t * speed + rnd(i, 22)) % 1f
        val y = size.height - p * (size.height + 30f)
        val sway = sin((p * 3f + rnd(i, 23)) * 2f * PI.toFloat()) * size.width * 0.035f
        val x = rnd(i, 24) * size.width + sway
        // Fades out as it rises — an ember that reaches the top still burning
        // reads as a bug rather than as fire.
        val fade = (1f - p) * (0.60f + rnd(i, 25) * 0.40f)
        drawCircle(
            color = colour.copy(alpha = fade),
            radius = 2.4f + rnd(i, 26) * 3.4f,
            center = Offset(x, y),
        )
    }
    repeat(12) { i ->
        val p = (t * (2.2f + rnd(i, 80)) + rnd(i, 81)) % 1f
        if (p > 0.22f) return@repeat
        val life = p / 0.22f
        val ang = rnd(i, 82) * 2f * PI.toFloat()
        val dist = life * 36f
        drawCircle(
            color = Color(0xFFFFF1A8).copy(alpha = (1f - life) * 0.9f),
            radius = 2.2f * (1f - life),
            center = Offset(cx + kotlin.math.cos(ang) * dist, base - 18f - dist * 0.55f),
        )
    }
}

/**
 * A moon, cloud drifting across it, and stars behind.
 *
 * This was stars alone, which is a dusting of dots and not a night. The name
 * is Midnight and the blurb says people who study after everyone sleeps — a
 * theme someone levelled up to earn should look like the thing it is called.
 */
private fun DrawScope.stars(t: Float, colour: Color) {
    // The moon, upper right, with a halo around it. Drawn as rings rather than
    // a blur, same rule as everywhere else in this app.
    val moon = Offset(size.width * 0.80f, size.height * 0.26f)
    val r = size.minDimension * 0.075f
    for (ring in 7 downTo 1) {
        drawCircle(
            color = colour.copy(alpha = 0.10f / ring),
            radius = r * (1f + ring * 0.62f),
            center = moon,
        )
    }
    drawCircle(color = colour.copy(alpha = 0.85f), radius = r, center = moon)
    // A bite out of it, in the page's own colour, so it reads as a crescent
    // without needing a second shape.
    drawCircle(
        color = Color(0xFF1A1A1A).copy(alpha = 0.55f),
        radius = r * 0.88f,
        center = Offset(moon.x + r * 0.42f, moon.y - r * 0.22f),
    )

    // Stars: three sizes, each on its own phase, and the small ones far more
    // numerous. A field where every dot is the same size reads as a texture;
    // depth comes from most of them being almost too faint to see.
    repeat(COUNT * 3) { i ->
        val x = rnd(i, 31) * size.width
        val y = rnd(i, 32) * size.height * 0.88f
        val phase = (t * (1.1f + rnd(i, 36) * 2.4f) + rnd(i, 33)) % 1f
        val wave = 0.5f + 0.5f * sin(phase * 2f * PI.toFloat())
        val twinkle = 0.12f + 0.88f * (wave * wave)
        val tier = rnd(i, 37)
        val sr = when {
            tier > 0.93f -> 3.2f
            tier > 0.70f -> 1.9f
            else -> 1.0f
        }
        if (tier > 0.70f) {
            drawCircle(
                color = colour.copy(alpha = 0.18f * twinkle),
                radius = sr * (2.8f + 2.2f * twinkle),
                center = Offset(x, y),
            )
        }
        drawCircle(
            color = colour.copy(alpha = (0.35f + 0.65f * twinkle) * (0.45f + sr / 3.2f)),
            radius = sr,
            center = Offset(x, y),
        )
        if (tier > 0.88f) {
            val arm = sr * (5.5f + 3f * twinkle)
            val a = colour.copy(alpha = 0.70f * twinkle)
            drawLine(a, Offset(x - arm, y), Offset(x + arm, y), 1.15f)
            drawLine(a, Offset(x, y - arm), Offset(x, y + arm), 1.15f)
        }
    }

    repeat(3) { k ->
        val cycle = (t * (0.7f + k * 0.4f) + k * 0.55f) % 1f
        if (cycle > 0.09f) return@repeat
        val p = cycle / 0.09f
        val sx = size.width * (0.15f + k * 0.45f) + p * size.width * 0.55f
        val sy = size.height * (0.10f + k * 0.18f) + p * size.height * 0.30f
        // Fades in and out rather than appearing at full brightness.
        val fade = sin(p * PI.toFloat())
        val len = 34f + 26f * fade
        drawLine(
            color = Color.White.copy(alpha = 0.85f * fade),
            start = Offset(sx, sy),
            end = Offset(sx - len, sy - len * 0.52f),
            strokeWidth = 2.2f,
            cap = StrokeCap.Round,
        )
        drawCircle(Color.White.copy(alpha = 0.9f * fade), 2.4f, Offset(sx, sy))
    }

    // Clouds: overlapping circles with a lit top and a shaded underside, not
    // one flat blob. A cloud is only round on top — the bottom is where it
    // stops catching the moon.
    repeat(3) { c ->
        val speed = 0.18f + c * 0.09f
        val cx = ((t * speed + c * 0.37f) % 1.35f) * (size.width + 240f) - 120f
        val cy = size.height * (0.16f + c * 0.24f)
        val cw = size.minDimension * (0.15f + c * 0.045f)
        val puffs = listOf(0f to 1f, 0.55f to 1.35f, 1.15f to 1.05f, 1.65f to 0.72f)
        // Shaded belly first, offset down.
        puffs.forEach { (dx, scale) ->
            drawCircle(
                color = Color(0xFF2A2438).copy(alpha = 0.20f),
                radius = cw * 0.5f * scale,
                center = Offset(cx + dx * cw * 0.62f, cy + cw * 0.16f),
            )
        }
        puffs.forEach { (dx, scale) ->
            drawCircle(
                color = colour.copy(alpha = 0.13f),
                radius = cw * 0.5f * scale,
                center = Offset(cx + dx * cw * 0.62f, cy),
            )
        }
        // Lit crown along the top, where the moon would reach.
        puffs.forEach { (dx, scale) ->
            drawCircle(
                color = Color.White.copy(alpha = 0.07f),
                radius = cw * 0.38f * scale,
                center = Offset(cx + dx * cw * 0.62f, cy - cw * 0.14f),
            )
        }
    }
}

/** Slow specks going sideways, catching the light as they turn. */
private fun DrawScope.motes(t: Float, colour: Color) {
    // A band of light crossing the whole hero, once every pass. Gold is the
    // rarest skin in the app and it was the quietest thing on screen — a sweep
    // is what a polished surface does when it catches the light.
    val sweep = ((t * 0.5f) % 1f) * (size.width * 1.6f) - size.width * 0.3f
    drawRect(
        brush = Brush.linearGradient(
            colors = listOf(
                Color.Transparent,
                colour.copy(alpha = 0.16f),
                Color.White.copy(alpha = 0.10f),
                colour.copy(alpha = 0.16f),
                Color.Transparent,
            ),
            start = Offset(sweep - size.width * 0.22f, 0f),
            end = Offset(sweep + size.width * 0.22f, size.height),
        ),
    )

    repeat(COUNT) { i ->
        val speed = 0.4f + rnd(i, 41) * 0.7f
        val x = ((t * speed + rnd(i, 42)) % 1f) * (size.width + 30f) - 15f
        val drift = sin((t * speed + rnd(i, 43)) * 2f * PI.toFloat()) * size.height * 0.06f
        val y = rnd(i, 44) * size.height + drift
        val glint = 0.5f + 0.5f * sin((t * 4f + rnd(i, 45)) * 2f * PI.toFloat())
        val r = 1.8f + rnd(i, 46) * 3.2f
        rotate(degrees = t * 220f * speed + i * 18f, pivot = Offset(x, y)) {
        drawPath(
            Path().apply {
                moveTo(x, y - r * 2f)
                lineTo(x + r, y)
                lineTo(x, y + r * 2f)
                lineTo(x - r, y)
                close()
            },
            color = colour.copy(alpha = 0.38f + 0.50f * glint),
        )
        if (rnd(i, 47) > 0.82f) {
            drawOval(
                color = colour.copy(alpha = 0.22f + 0.25f * glint),
                topLeft = Offset(x - r * 1.6f, y - r * 0.7f),
                size = Size(r * 3.2f, r * 1.4f),
            )
        }
        }
    }
}

private fun DrawScope.confetti(t: Float, colour: Color) {
    val palette = listOf(
        colour,
        Color(0xFFFF5D8F),
        Color(0xFFFFD84D),
        Color(0xFF3FE28F),
        Color(0xFF7FD4FF),
    )
    repeat(COUNT) { i ->
        val speed = 0.55f + rnd(i, 90) * 0.9f
        val p = (t * speed + rnd(i, 91)) % 1f
        val x = rnd(i, 92) * size.width +
            sin((p + rnd(i, 93)) * 2f * PI.toFloat()) * 18f
        val y = -8f + p * (size.height + 16f)
        val w = 4f + rnd(i, 94) * 6f
        rotate(degrees = t * 360f * speed + i * 20f, pivot = Offset(x, y)) {
            drawRect(
                color = palette[i % palette.size].copy(alpha = 0.75f),
                topLeft = Offset(x - w, y - w * 0.4f),
                size = Size(w * 2f, w * 0.8f),
            )
        }
    }
}
