package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import kotlinx.coroutines.delay
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import com.momentum.focus.ui.theme.Skin
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * How many pieces are in the air at once.
 *
 * Was twenty-six, which on a hero this size is a piece every eighty pixels —
 * sparse enough that you had to be told the weather was there. It is one draw
 * pass either way, so the cost of tripling it is three times almost nothing.
 */
private const val COUNT = 80

/**
 * The weather a skin is named after.
 *
 * Every earned skin promised something in its own blurb — "rain on the window",
 * "the last hour before an exam" — and delivered a change of four colours. A
 * theme called Monsoon with no rain in it is a name doing work the app never
 * did, and after the second one nobody believes the third.
 *
 * Each piece's position is a pure function of its index and the clock, so
 * nothing is stored, nothing accumulates, and the whole layer is one animation
 * read in the draw phase rather than twenty-six of them recomposing.
 *
 * Festival skins are left alone — they have their own artwork and adding
 * weather on top of a diya would be two ideas fighting.
 */
@Composable
fun SkinWeather(skin: Skin, modifier: Modifier = Modifier) {
    if (!skin.hasWeather()) return

    // Held back until the screen has arrived. Home is the heaviest tree in the
    // app — hero artwork, exam news, the score, the tiles — and starting a
    // frame-rate animation in the same composition meant the tab bar's own
    // animation lost its frames to this one. Switching to Home stuttered while
    // every other tab was smooth, and this was why. Three hundred milliseconds
    // is after the switch and before anyone has looked at the hero.
    var awake by remember(skin) { mutableStateOf(false) }
    LaunchedEffect(skin) {
        delay(300)
        awake = true
    }
    if (!awake) return

    val transition = rememberInfiniteTransition(label = "weather")
    // One slow pass. Every piece takes its own offset from this, so they do not
    // move in lockstep despite sharing a clock.
    val t = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(skin.weatherMs(), easing = LinearEasing)),
        label = "drift",
    )
    // Second, much slower hand — used for the lightning in Monsoon, which must
    // not fire on the same beat as the rain falls.
    val slow = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing)),
        label = "slow",
    )

    Box(
        modifier.drawBehind {
            when (skin) {
                Skin.SAKURA -> petals(t.value, skin.petal)
                Skin.MONSOON -> rain(t.value, slow.value, skin.petal)
                Skin.EMBER -> embers(t.value, skin.petal)
                Skin.MIDNIGHT -> stars(t.value, skin.petal)
                Skin.GOLD -> motes(t.value, skin.petal)
                else -> Unit
            }
        },
    )
}

private fun Skin.hasWeather() = this in setOf(
    Skin.SAKURA, Skin.MONSOON, Skin.EMBER, Skin.MIDNIGHT, Skin.GOLD,
)

/** Rain is quick, embers dawdle, stars barely move. */
private fun Skin.weatherMs() = when (this) {
    // Rain was 1400ms and the drops were forty pixels long, which together
    // draw ropes rather than rain. Real rain falls slower than it looks and
    // each drop is short — the length comes from many of them in a line, not
    // from one long streak.
    Skin.MONSOON -> 3200
    Skin.SAKURA -> 9000
    Skin.EMBER -> 5200
    Skin.GOLD -> 11000
    else -> 16000
}

/** Deterministic pseudo-random in 0..1 from an index and a salt. */
private fun rnd(i: Int, salt: Int): Float {
    val x = sin((i * 12.9898 + salt * 78.233)) * 43758.5453
    return (x - kotlin.math.floor(x)).toFloat()
}

/** Branch in the corner, petals falling off it — not random pink rain. */
private fun DrawScope.petals(t: Float, colour: Color) {
    val bark = Color(0xFF5A3A28)
    val limb = Path().apply {
        moveTo(0f, size.height * 0.08f)
        cubicTo(
            size.width * 0.18f, size.height * 0.02f,
            size.width * 0.38f, size.height * 0.16f,
            size.width * 0.62f, size.height * 0.12f,
        )
    }
    drawPath(limb, color = bark, style = Stroke(width = 7f, cap = StrokeCap.Round))
    val twig = Path().apply {
        moveTo(size.width * 0.28f, size.height * 0.08f)
        cubicTo(
            size.width * 0.34f, size.height * 0.00f,
            size.width * 0.40f, size.height * 0.04f,
            size.width * 0.46f, size.height * 0.01f,
        )
    }
    drawPath(twig, color = bark, style = Stroke(width = 4f, cap = StrokeCap.Round))
    repeat(9) { i ->
        val u = (i + 1) / 10f
        val bx = size.width * 0.06f + u * size.width * 0.52f
        val by = size.height * 0.09f + sin(i * 1.7f) * size.height * 0.04f
        drawCircle(colour.copy(alpha = 0.85f), 5.5f + (i % 3), Offset(bx, by))
        drawCircle(Color.White.copy(alpha = 0.35f), 2.2f, Offset(bx - 1.5f, by - 1.5f))
    }
    repeat(COUNT) { i ->
        val speed = 0.45f + rnd(i, 1) * 0.7f
        val born = rnd(i, 4) * 0.58f
        val y = size.height * 0.10f + ((t * speed + rnd(i, 2)) % 1f) * (size.height * 0.95f)
        val sway = sin((t * speed * 2f + rnd(i, 3)) * 2f * PI.toFloat()) * size.width * 0.06f
        val x = born * size.width + sway
        val r = 4.5f + rnd(i, 5) * 6.5f
        rotate(degrees = (t * 280f * speed + i * 37f), pivot = Offset(x, y)) {
            drawOval(
                color = colour.copy(alpha = 0.50f + rnd(i, 6) * 0.40f),
                topLeft = Offset(x - r, y - r * 0.55f),
                size = Size(r * 2f, r * 1.1f),
            )
        }
    }
}

/** Streaks, slanted, with the sky flickering behind them now and then. */
private fun DrawScope.rain(t: Float, slow: Float, colour: Color) {
    // Fog first, under everything. Two soft bands, one low and one lower,
    // drifting at different speeds — the thing that makes rain read as weather
    // rather than as lines is that the air behind it is not clear.
    repeat(2) { band ->
        val drift = ((slow * (0.4f + band * 0.3f)) % 1f) * size.width
        val y = size.height * (0.62f + band * 0.18f)
        val h = size.height * 0.34f
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color.Transparent,
                    colour.copy(alpha = 0.10f - band * 0.03f),
                    Color.Transparent,
                ),
                startY = y - h / 2f,
                endY = y + h / 2f,
            ),
            topLeft = Offset(-size.width + drift, y - h / 2f),
            size = Size(size.width * 3f, h),
        )
    }

    // The flash, doubled so it stutters the way lightning does.
    val flash = when {
        slow < 0.02f -> 1f - slow / 0.02f
        slow in 0.04f..0.06f -> 1f - (slow - 0.04f) / 0.02f
        else -> 0f
    }
    if (flash > 0f) {
        drawRect(color = Color.White.copy(alpha = 0.28f * flash))
        val bolt = Path().apply {
            moveTo(size.width * 0.58f, 0f)
            lineTo(size.width * 0.50f, size.height * 0.28f)
            lineTo(size.width * 0.57f, size.height * 0.28f)
            lineTo(size.width * 0.44f, size.height * 0.62f)
            lineTo(size.width * 0.53f, size.height * 0.42f)
            lineTo(size.width * 0.46f, size.height * 0.42f)
            close()
        }
        drawPath(bolt, Color.White.copy(alpha = 0.85f * flash))
        drawPath(bolt, Color(0xFFB8E0FF).copy(alpha = 0.55f * flash), style = Stroke(width = 2.2f))
    }

    // Two depths of falling drop.
    repeat(COUNT) { i ->
        val near = rnd(i, 10) > 0.55f
        val speed = if (near) 0.9f + rnd(i, 11) * 0.3f else 0.45f + rnd(i, 11) * 0.25f
        val cycle = (t * speed + rnd(i, 12)) % 1f
        val y = cycle * (size.height + 60f) - 30f
        val x = rnd(i, 13) * size.width
        val len = if (near) 9f + rnd(i, 14) * 6f else 5f + rnd(i, 14) * 4f
        drawLine(
            color = colour.copy(alpha = if (near) 0.55f else 0.26f),
            start = Offset(x, y),
            end = Offset(x - len * 0.16f, y + len),
            strokeWidth = if (near) 2.2f else 1.4f,
            cap = StrokeCap.Round,
        )
    }

    // Splashes along the bottom edge. Each drop that lands throws two small
    // arcs sideways and fades. This is the detail that separates rain drawn
    // on a screen from rain hitting something — without it the drops simply
    // vanish at the bottom, which is what nothing real does.
    val floor = size.height - 3f
    repeat(COUNT / 3) { i ->
        // Each splash runs on its own offset phase, so they land scattered in
        // time rather than all at once.
        val phase = (t * (1.4f + rnd(i, 50) * 0.6f) + rnd(i, 51)) % 1f
        if (phase > 0.30f) return@repeat
        val life = phase / 0.30f
        val x = rnd(i, 52) * size.width
        val spread = 5f + life * 11f
        val fade = (1f - life) * 0.45f
        // Two arms out, and a bounced droplet over each.
        drawLine(
            color = colour.copy(alpha = fade),
            start = Offset(x, floor),
            end = Offset(x - spread, floor - spread * 0.42f),
            strokeWidth = 1.6f,
            cap = StrokeCap.Round,
        )
        drawLine(
            color = colour.copy(alpha = fade),
            start = Offset(x, floor),
            end = Offset(x + spread, floor - spread * 0.42f),
            strokeWidth = 1.6f,
            cap = StrokeCap.Round,
        )
        drawCircle(
            color = colour.copy(alpha = fade * 0.9f),
            radius = 1.8f * (1f - life),
            center = Offset(x + spread * 1.1f, floor - spread * 0.62f),
        )
        drawCircle(
            color = colour.copy(alpha = fade * 0.9f),
            radius = 1.8f * (1f - life),
            center = Offset(x - spread * 1.1f, floor - spread * 0.62f),
        )
        // The ring left on the surface.
        drawCircle(
            color = colour.copy(alpha = fade * 0.5f),
            radius = spread * 0.75f,
            center = Offset(x, floor),
            style = Stroke(width = 1.2f),
        )
    }

    // Two frogs on the sill. Bob only — they sit in the rain, they do not hop
    // off the card.
    repeat(2) { f ->
        val fx = size.width * (0.18f + f * 0.55f)
        val bob = sin((t * 2f + f) * 2f * PI.toFloat()) * 2.4f
        val fy = size.height - 16f + bob
        val body = Color(0xFF3FAE5A)
        drawOval(body, Offset(fx - 16f, fy - 11f), Size(32f, 18f))
        drawCircle(body, 7.5f, Offset(fx - 8f, fy - 14f))
        drawCircle(body, 7.5f, Offset(fx + 8f, fy - 14f))
        drawCircle(Color(0xFFF2F7C8), 3.4f, Offset(fx - 8f, fy - 14f))
        drawCircle(Color(0xFFF2F7C8), 3.4f, Offset(fx + 8f, fy - 14f))
        drawCircle(Color(0xFF1A1A1A), 1.6f, Offset(fx - 8f, fy - 14f))
        drawCircle(Color(0xFF1A1A1A), 1.6f, Offset(fx + 8f, fy - 14f))
    }
}

/** Rising, fading as they climb, brighter at the bottom. */
private fun DrawScope.embers(t: Float, colour: Color) {
    // Flame tongues along the hearth. Flicker from the shared clock so they
    // loop cleanly and never accumulate.
    repeat(5) { f ->
        val flicker = 0.82f + 0.18f * sin((t * 8f + f) * 2f * PI.toFloat())
        val cx = size.width * (0.12f + f * 0.19f)
        val h = size.height * (0.22f + rnd(f, 70) * 0.10f) * flicker
        val flame = Path().apply {
            moveTo(cx, size.height)
            cubicTo(cx - 18f, size.height - h * 0.4f, cx - 8f, size.height - h * 0.75f, cx, size.height - h)
            cubicTo(cx + 8f, size.height - h * 0.75f, cx + 18f, size.height - h * 0.4f, cx, size.height)
            close()
        }
        drawPath(flame, colour.copy(alpha = 0.42f))
        drawPath(flame, Color.White.copy(alpha = 0.12f))
    }
    repeat(COUNT) { i ->
        val speed = 0.5f + rnd(i, 21) * 0.9f
        val p = (t * speed + rnd(i, 22)) % 1f
        val y = size.height - p * (size.height + 30f)
        val sway = sin((p * 3f + rnd(i, 23)) * 2f * PI.toFloat()) * size.width * 0.035f
        val x = rnd(i, 24) * size.width + sway
        // Fades out as it rises — an ember that reaches the top still burning
        // reads as a bug rather than as fire.
        val fade = (1f - p) * (0.60f + rnd(i, 25) * 0.40f)
        drawCircle(
            color = colour.copy(alpha = fade),
            radius = 2.4f + rnd(i, 26) * 3.4f,
            center = Offset(x, y),
        )
    }
}

/**
 * A moon, cloud drifting across it, and stars behind.
 *
 * This was stars alone, which is a dusting of dots and not a night. The name
 * is Midnight and the blurb says people who study after everyone sleeps — a
 * theme someone levelled up to earn should look like the thing it is called.
 */
private fun DrawScope.stars(t: Float, colour: Color) {
    // The moon, upper right, with a halo around it. Drawn as rings rather than
    // a blur, same rule as everywhere else in this app.
    val moon = Offset(size.width * 0.80f, size.height * 0.26f)
    val r = size.minDimension * 0.075f
    for (ring in 5 downTo 1) {
        drawCircle(
            color = colour.copy(alpha = 0.05f / ring),
            radius = r * (1f + ring * 0.55f),
            center = moon,
        )
    }
    drawCircle(color = colour.copy(alpha = 0.85f), radius = r, center = moon)
    // A bite out of it, in the page's own colour, so it reads as a crescent
    // without needing a second shape.
    drawCircle(
        color = Color(0xFF1A1A1A).copy(alpha = 0.55f),
        radius = r * 0.88f,
        center = Offset(moon.x + r * 0.42f, moon.y - r * 0.22f),
    )

    repeat(COUNT + 10) { i ->
        val x = rnd(i, 31) * size.width
        val y = rnd(i, 32) * size.height
        val phase = (t + rnd(i, 33)) % 1f
        val twinkle = 0.25f + 0.75f * (0.5f + 0.5f * sin(phase * 2f * PI.toFloat()))
        val sr = 1.4f + rnd(i, 34) * 2.4f
        drawCircle(
            color = colour.copy(alpha = 0.40f + 0.55f * twinkle),
            radius = sr,
            center = Offset(x, y),
        )
        if (rnd(i, 35) > 0.86f) {
            val arm = sr * 4f * twinkle
            val a = colour.copy(alpha = 0.55f * twinkle)
            drawLine(a, Offset(x - arm, y), Offset(x + arm, y), 1f)
            drawLine(a, Offset(x, y - arm), Offset(x, y + arm), 1f)
        }
    }

    // Three clouds crossing, slowly, each a row of overlapping circles.
    repeat(3) { c ->
        val speed = 0.25f + c * 0.12f
        val cx = ((t * speed + c * 0.37f) % 1.3f) * (size.width + 200f) - 100f
        val cy = size.height * (0.18f + c * 0.26f)
        val cw = size.minDimension * (0.16f + c * 0.05f)
        repeat(4) { k ->
            drawCircle(
                color = colour.copy(alpha = 0.10f),
                radius = cw * (0.5f + 0.12f * sin(k.toFloat())),
                center = Offset(cx + k * cw * 0.55f, cy + sin(k.toFloat()) * cw * 0.12f),
            )
        }
    }
}

/** Slow specks going sideways, catching the light as they turn. */
private fun DrawScope.motes(t: Float, colour: Color) {
    repeat(COUNT) { i ->
        val speed = 0.4f + rnd(i, 41) * 0.7f
        val x = ((t * speed + rnd(i, 42)) % 1f) * (size.width + 30f) - 15f
        val drift = sin((t * speed + rnd(i, 43)) * 2f * PI.toFloat()) * size.height * 0.06f
        val y = rnd(i, 44) * size.height + drift
        val glint = 0.5f + 0.5f * sin((t * 4f + rnd(i, 45)) * 2f * PI.toFloat())
        val r = 1.8f + rnd(i, 46) * 3.2f
        drawPath(
            Path().apply {
                moveTo(x, y - r * 2f)
                lineTo(x + r, y)
                lineTo(x, y + r * 2f)
                lineTo(x - r, y)
                close()
            },
            color = colour.copy(alpha = 0.38f + 0.50f * glint),
        )
        if (rnd(i, 47) > 0.82f) {
            drawOval(
                color = colour.copy(alpha = 0.22f + 0.25f * glint),
                topLeft = Offset(x - r * 1.6f, y - r * 0.7f),
                size = Size(r * 3.2f, r * 1.4f),
            )
        }
    }
}
