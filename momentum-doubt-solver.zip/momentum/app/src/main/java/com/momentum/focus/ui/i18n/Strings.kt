package com.momentum.focus.ui.i18n

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf

/**
 * The languages the app ships in.
 *
 * [HI] is Hinglish — Hindi written in Latin script, mixed with the English
 * words students actually use ("focus", "streak", "session"). It is not
 * Devanagari Hindi, and translating it as though it were would produce
 * something no user of this app speaks.
 *
 * [label] is deliberately written in the language it names, so the picker
 * reads correctly whichever language is currently active.
 */
enum class Lang(val code: String, val label: String) {
    HI("hi", "Hinglish"),
    EN("en", "English");

    companion object {
        /** Falls back to Hinglish for unknown or empty codes. */
        fun from(code: String): Lang = entries.firstOrNull { it.code == code } ?: HI
    }
}

/**
 * Every user-facing string in the app, grouped by the screen that shows it.
 *
 * Sections are separate interfaces in separate files rather than one flat list
 * of a thousand members, for two reasons. It keeps a screen's text next to
 * that screen conceptually, and it lets the migration land one screen at a
 * time — a screen that has not been converted yet keeps its hardcoded text and
 * still compiles.
 *
 * Strings that contain no words are not here. `"+${Currency.format(n)}"` is
 * the same in both languages, so putting it behind a lookup would add a layer
 * and change nothing.
 */
interface Strings {
    val lang: Lang
    val coach: CoachStrings
    val common: CommonStrings
    val doubt: DoubtStrings
    val focus: FocusStrings
    val home: HomeStrings
    val feedGuard: FeedGuardStrings
    val perms: PermissionStrings
    val quiz: QuizStrings
    val stats: StatsStrings
    val welcome: WelcomeStrings
    val whatsNew: WhatsNewStrings
    val wallet: WalletStrings
}

object HiStrings : Strings {
    override val lang = Lang.HI
    override val coach = CoachHi
    override val common = CommonHi
    override val doubt = DoubtHi
    override val focus = FocusHi
    override val home = HomeHi
    override val feedGuard = FeedGuardHi
    override val perms = PermissionHi
    override val quiz = QuizHi
    override val stats = StatsHi
    override val welcome = WelcomeHi
    override val whatsNew = WhatsNewHi
    override val wallet = WalletHi
}

object EnStrings : Strings {
    override val lang = Lang.EN
    override val coach = CoachEn
    override val common = CommonEn
    override val doubt = DoubtEn
    override val focus = FocusEn
    override val home = HomeEn
    override val feedGuard = FeedGuardEn
    override val perms = PermissionEn
    override val quiz = QuizEn
    override val stats = StatsEn
    override val welcome = WelcomeEn
    override val whatsNew = WhatsNewEn
    override val wallet = WalletEn
}

fun stringsFor(lang: Lang): Strings = when (lang) {
    Lang.HI -> HiStrings
    Lang.EN -> EnStrings
}

/** Convenience for services and notifications, which have no composition. */
fun stringsFor(code: String): Strings = stringsFor(Lang.from(code))

/**
 * Static rather than dynamic because language changes roughly never, and when
 * it does every string on screen is stale — recomposing the whole tree is
 * exactly what we want, and static skips the per-read bookkeeping that would
 * otherwise be paid on all thousand-odd reads.
 *
 * Mirrors how [com.momentum.focus.ui.theme.LocalSkin] is provided.
 */
val LocalStrings = staticCompositionLocalOf<Strings> { HiStrings }

/**
 * Shorthand so screens read `val str = strings()` instead of the full path.
 *
 * Bind it as `str`, never `s`. Lambdas in this codebase use `s` constantly —
 * for a session, a subject, a sticker — and a Strings binding called `s`
 * gets silently shadowed inside them. That has already happened twice, in
 * WalletScreen and FocusScreen, and tools/scan.py now fails the build for it.
 */
@Composable
@ReadOnlyComposable
fun strings(): Strings = LocalStrings.current
