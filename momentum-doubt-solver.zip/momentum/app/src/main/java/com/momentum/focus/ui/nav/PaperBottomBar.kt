package com.momentum.focus.ui.nav

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.momentum.focus.ui.components.FrostPill
import com.momentum.focus.ui.components.liquidGlow
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

/**
 * [inBar] is what separates a destination from a tab.
 *
 * Six tabs meant six icons the size of a fingernail and no clue which one held
 * what. Rewards and Journal already have their own cards in Home's quick
 * actions, so they were being offered twice while crowding the four screens
 * people move between all day. They stay reachable, they just stop competing
 * for the bar.
 */
enum class Tab(
    val icon: ImageVector,
    val sticker: Sticker,
    val label: String,
    val inBar: Boolean = true,
) {
    HOME(Icons.Filled.Home, Mint, "Home"),
    FOCUS(Icons.Filled.Timer, Sky, "Focus"),
    // Gold, not Lilac. MyAi is the premium surface and everything else about
    // it — the aura behind the header, the unlock screen, the data card — is
    // gold; a purple pill in the bar was the one place that disagreed, and it
    // read as a blob rather than as part of the app. Only the selected tab is
    // ever filled, so sharing a colour with Wallet never shows.
    MYAI(Icons.Filled.AutoAwesome, Gold, "MyAi"),
    WALLET(Icons.Filled.AccountBalanceWallet, Butter, "Wallet"),
    STATS(Icons.Filled.BarChart, Tang, "Stats"),
    REWARDS(Icons.Filled.MilitaryTech, Lilac, "Rewards", inBar = false),
    JOURNAL(Icons.Filled.EditNote, Candy, "Journal", inBar = false),
}

@Composable
fun PaperBottomBar(
    current: Tab,
    onSelect: (Tab) -> Unit,
) {
    val haptics = rememberHaptics()
    Box(
        Modifier
            .fillMaxWidth()
            .background(Color.Transparent)
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
    FrostPill(Modifier.fillMaxWidth()) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        // Even weights rather than even spacing. SpaceEvenly sized each tab to
        // its own label, so on a narrow phone — or at a large system text size
        // — "Wallet" and "Focus" grew until the row overflowed and the names
        // were cut mid-word. Equal shares cannot overflow.
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Tab.entries.filter { it.inBar }.forEach { tab ->
            val selected = tab == current
            // The selected tab lifts and fills with its own colour. The
            // comment here used to say labels were unnecessary because there
            // were four destinations; there are six, and six unlabelled icons
            // is a guessing game for anyone opening the app for the first
            // time. Names cost one line each and remove the guessing.
            val scale by animateFloatAsState(
                if (selected) 1f else 0.86f, Motion.bouncy(), label = tab.name
            )
            // The fill rises into the pill rather than appearing on it, and it
            // is a gradient rather than a flat colour — lighter along the top
            // edge, the way light sits on something with a surface. A flat
            // rectangle swapping colour is a state change; this is a thing
            // moving, and the difference is the whole reason a tab bar is worth
            // touching twice.
            val lift by animateFloatAsState(
                if (selected) 1f else 0f, Motion.settle(), label = "lift" + tab.name
            )
            // The AI tab keeps a slow glow whether it is selected or not. It is
            // the one destination people forget they have, and a pill that
            // moves is the difference between a tab bar you scan and a tab bar
            // you have stopped seeing. Only one tab gets it — two would be a
            // fairground.
            //
            // This was two gold rings outside the pill, fading in and out
            // together on a 1400ms reverse. A blink is what every app does to
            // say "look here", and it stops working the second time you look.
            // The lights now move instead, inside the pill and under the icon:
            // nothing fades, so there is nothing to become used to. See
            // liquidGlow.
            val ai = tab == Tab.MYAI
            Box(
                Modifier
                    .weight(1f)
                    // Plain scale. The stretch-and-squash that was here read as
                    // a wobble rather than as speed — on a pill this small the
                    // shape distorting is just the thing looking wrong for a
                    // moment. The rising fill already says which tab arrived.
                    .scale(scale)
                    .clip(RoundedCornerShape(15.dp))
                    .background(CreamCard)
                    // After the clip and the fill, so the lights are bounded by
                    // the pill and sit on top of whatever is under them.
                    //
                    // It used to be gated on !selected, so the glow stopped
                    // dead the instant the tab was tapped — the animation the
                    // whole point of which is that it never stops. Tapping the
                    // one moving thing in the bar and having it switch off is
                    // the harshest cut of the lot. It keeps running; it just
                    // drops to a whisper once the tab has its own fill
                    // underneath, because at full strength it would fight the
                    // colour that says which tab you are on.
                    .then(
                        if (ai) {
                            Modifier.liquidGlow(
                                a = Tang.fill,
                                b = Lilac.fill,
                                strength = if (selected) 0.30f else 0.85f,
                            )
                        } else {
                            Modifier
                        },
                    )
                    .drawBehind {
                        if (lift <= 0.01f) return@drawBehind
                        val h = size.height * lift
                        val top = size.height - h
                        // The same glass the earned-today strip on Home wears,
                        // rising into the pill instead of switching on: the
                        // colour, then a lit top lip, then a shadow at the
                        // bottom. Three flat passes — the lip is what sells it
                        // as a surface rather than as a filled rectangle.
                        // Diagonal, not vertical. A top-left to bottom-right
                        // sweep is what makes the reference's active pill look
                        // lit from somewhere rather than shaded; straight down
                        // reads as a gradient someone applied.
                        drawRect(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    lerp(tab.sticker.fill, Color.White, 0.42f),
                                    tab.sticker.fill,
                                    lerp(tab.sticker.accent, Color.Black, 0.10f),
                                ),
                                start = Offset(0f, top),
                                end = Offset(size.width, size.height),
                            ),
                            topLeft = Offset(0f, top),
                            size = Size(size.width, h),
                        )
                        val lip = h * 0.34f
                        drawRect(
                            brush = Brush.verticalGradient(
                                listOf(Color.White.copy(alpha = 0.42f), Color.Transparent),
                                startY = top,
                                endY = top + lip,
                            ),
                            topLeft = Offset(0f, top),
                            size = Size(size.width, lip),
                        )
                        drawRect(
                            brush = Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.14f)),
                                startY = size.height - lip,
                                endY = size.height,
                            ),
                            topLeft = Offset(0f, size.height - lip),
                            size = Size(size.width, lip),
                        )
                    }
                    .border(
                        if (selected) Paper.Outline else 2.dp,
                        Ink,
                        RoundedCornerShape(15.dp),
                    )
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        if (!selected) { haptics.tap(); onSelect(tab) }
                    }
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        tab.icon,
                        contentDescription = tab.label,
                        tint = if (selected) tab.sticker.on else Ink,
                        modifier = Modifier.size(18.dp),
                    )
                    Text(
                        tab.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) tab.sticker.on else InkMid,
                        maxLines = 1,
                        softWrap = false,
                        // Ellipsis, not the default clip: a name that has run
                        // out of room should say so rather than end on a
                        // half-drawn letter that looks like a rendering fault.
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
    }
    }
}
