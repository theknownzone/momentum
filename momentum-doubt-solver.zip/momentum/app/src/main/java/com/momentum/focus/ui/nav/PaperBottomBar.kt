package com.momentum.focus.ui.nav

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import com.momentum.focus.ui.components.FrostPill
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

/**
 * [inBar] is what separates a destination from a tab.
 *
 * Six tabs meant six icons the size of a fingernail and no clue which one held
 * what. Rewards and Journal already have their own cards in Home's quick
 * actions, so they were being offered twice while crowding the four screens
 * people move between all day. They stay reachable, they just stop competing
 * for the bar.
 */
enum class Tab(
    val icon: ImageVector,
    val sticker: Sticker,
    val label: String,
    val inBar: Boolean = true,
) {
    HOME(Icons.Filled.Home, Mint, "Home"),
    FOCUS(Icons.Filled.Timer, Sky, "Focus"),
    MYAI(Icons.Filled.AutoAwesome, Lilac, "MyAi"),
    WALLET(Icons.Filled.AccountBalanceWallet, Butter, "Wallet"),
    STATS(Icons.Filled.BarChart, Tang, "Stats"),
    REWARDS(Icons.Filled.MilitaryTech, Lilac, "Rewards", inBar = false),
    JOURNAL(Icons.Filled.EditNote, Candy, "Journal", inBar = false),
}

@Composable
fun PaperBottomBar(
    current: Tab,
    onSelect: (Tab) -> Unit,
) {
    val haptics = rememberHaptics()
    Box(
        Modifier
            .fillMaxWidth()
            .background(Color.Transparent)
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
    FrostPill(Modifier.fillMaxWidth()) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Tab.entries.filter { it.inBar }.forEach { tab ->
            val selected = tab == current
            // The selected tab lifts and fills with its own colour. The
            // comment here used to say labels were unnecessary because there
            // were four destinations; there are six, and six unlabelled icons
            // is a guessing game for anyone opening the app for the first
            // time. Names cost one line each and remove the guessing.
            val scale by animateFloatAsState(
                if (selected) 1f else 0.86f, Motion.bouncy(), label = tab.name
            )
            Box(
                Modifier
                    .scale(scale)
                    .clip(RoundedCornerShape(15.dp))
                    .background(
                        if (selected) tab.sticker.fill
                        else CreamCard
                    )
                    .border(
                        if (selected) Paper.Outline else 2.dp,
                        Ink,
                        RoundedCornerShape(15.dp),
                    )
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        if (!selected) { haptics.tap(); onSelect(tab) }
                    }
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        tab.icon,
                        contentDescription = tab.label,
                        tint = if (selected) tab.sticker.on else Ink,
                        modifier = Modifier.size(18.dp),
                    )
                    Text(
                        tab.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) tab.sticker.on else InkMid,
                        maxLines = 1,
                    )
                }
            }
        }
    }
    }
    }
}
