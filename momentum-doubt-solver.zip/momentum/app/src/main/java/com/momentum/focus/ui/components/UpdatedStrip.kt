package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Paper

/**
 * "Updated to 1.0.147" — one line, dismissed where it sits.
 *
 * This replaces a full-screen changelog that opened on every launch after an
 * update and returned early from the whole app. The first thing anyone saw
 * after installing was a page of release notes with the button below the fold,
 * so the behaviour it actually trained was: scroll to the bottom, tap Got it,
 * read nothing. Twenty routine updates got the same ceremony as the one that
 * changed something, which is how a changelog stops meaning anything.
 *
 * Tapping it opens the full log. Tapping the cross marks the version seen. The
 * app is usable either way, which is the point.
 */
@Composable
fun UpdatedStrip(
    version: String,
    onOpen: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val str = strings()
    val shape = RoundedCornerShape(Paper.CardRadius)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Butter.fill)
            .border(Paper.Outline, Ink, shape)
            .clickableNoRipple(remember2()) { onOpen() }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        TileObject(art = TileArt.Medal, fill = Butter.accent, size = 28.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                str.whatsNew.updatedTo(version),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Butter.on,
            )
            Spacer(Modifier.height(1.dp))
            Text(
                str.whatsNew.tapToRead,
                style = MaterialTheme.typography.bodyMedium,
                color = Butter.on.copy(alpha = 0.8f),
            )
        }
        // Its own target, well away from the row's, so dismissing is never a
        // mis-tap into the log.
        Row(
            Modifier
                .clip(CircleShape)
                .clickableNoRipple(remember2()) { onDismiss() }
                .padding(8.dp),
        ) {
            Icon(
                Icons.Filled.Close,
                contentDescription = null,
                tint = Butter.on,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

/** Two interaction sources are needed here and both must survive recomposition. */
@Composable
private fun remember2() = androidx.compose.runtime.remember { MutableInteractionSource() }
