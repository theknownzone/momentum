package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.Candy
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import kotlin.math.cos
import kotlin.math.sin

/**
 * Short, Zomato-inspired AI entry choreography: dim the existing screen,
 * centre the greeting, bloom a chromatic AI core, reveal two soft skeletons,
 * then hand the screen back. It deliberately stops after 3.2s; the chat itself
 * is the product, not a loading screen.
 */
@Composable
fun AiZomatoReveal(
    name: String,
    onFinished: () -> Unit,
) {
    val phase = remember { Animatable(0f) }
    var alive by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        phase.animateTo(0.28f, tween(650, easing = FastOutSlowInEasing))
        phase.animateTo(0.56f, tween(700, easing = FastOutSlowInEasing))
        phase.animateTo(0.78f, tween(700, easing = FastOutSlowInEasing))
        phase.animateTo(1f, tween(1150, easing = LinearEasing))
        alive = false
        onFinished()
    }

    if (!alive) return

    val p = phase.value
    val greetingAlpha = (1f - ((p - 0.55f) / 0.35f)).coerceIn(0f, 1f)
    val cardsAlpha = ((p - 0.28f) / 0.35f).coerceIn(0f, 1f)
    val composerAlpha = ((p - 0.56f) / 0.28f).coerceIn(0f, 1f)
    val exitAlpha = ((p - 0.82f) / 0.18f).coerceIn(0f, 1f)
    val scrim = (0.82f - exitAlpha * 0.82f).coerceIn(0f, 0.82f)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0E14).copy(alpha = scrim)),
        contentAlignment = Alignment.Center,
    ) {
        // Cheap Canvas primitives only. No blur, no per-frame text measuring,
        // no infinite transition: this is intentionally light on mid-range phones.
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width * 0.5f
            val cy = size.height * 0.47f
            val pulse = 1f + 0.12f * sin(p * Math.PI * 5.0).toFloat()
            val radius = size.minDimension * (0.045f + 0.075f * cardsAlpha)
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(
                        Color.White.copy(alpha = 0.34f * (1f - exitAlpha)),
                        Lilac.fill.copy(alpha = 0.25f * (1f - exitAlpha)),
                        Sky.fill.copy(alpha = 0.12f * (1f - exitAlpha)),
                        Color.Transparent,
                    ),
                    radius = radius * 3.8f,
                ),
                radius = radius * 3.8f,
                center = Offset(cx, cy),
            )
            val dots = 5
            for (ring in 1..3) {
                val ringR = radius * (1.25f + ring * 0.65f) * pulse
                for (i in 0 until dots * ring) {
                    val a = (i.toFloat() / (dots * ring)) * (Math.PI * 2.0) + p * (1.8f - ring * 0.25f)
                    val dot = Offset(cx + cos(a).toFloat() * ringR, cy + sin(a).toFloat() * ringR)
                    val alpha = (0.72f - ring * 0.13f) * (1f - exitAlpha)
                    val c = when ((i + ring) % 4) {
                        0 -> Mint.fill
                        1 -> Sky.fill
                        2 -> Lilac.fill
                        else -> Candy.fill
                    }
                    drawCircle(c.copy(alpha = alpha), radius * (0.10f + 0.035f * cardsAlpha), dot)
                }
            }
        }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp)
                .alpha(greetingAlpha.coerceAtLeast(composerAlpha) * (1f - exitAlpha)),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                if (name.isBlank()) "Hi!" else "Hi, $name!",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = 0.96f),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "What would you like to know?",
                fontSize = 17.sp,
                color = Color.White.copy(alpha = 0.86f),
            )

            Spacer(Modifier.height(72.dp))

            Column(
                Modifier
                    .fillMaxWidth()
                    .alpha(cardsAlpha * (1f - exitAlpha))
                    .scale(0.96f + cardsAlpha * 0.04f),
            ) {
                SkeletonCard()
                Spacer(Modifier.height(12.dp))
                SkeletonCard(short = true)
            }

            Spacer(Modifier.height(18.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .alpha(composerAlpha * (1f - exitAlpha))
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.White.copy(alpha = 0.07f)),
            )
        }
    }
}

@Composable
private fun SkeletonCard(short: Boolean = false) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(if (short) 88.dp else 116.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.065f))
            .padding(16.dp),
    ) {
        Column {
            Box(
                Modifier
                    .fillMaxWidth(0.58f)
                    .height(12.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White.copy(alpha = 0.08f)),
            )
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(if (short) 42.dp else 64.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Sky.fill.copy(alpha = 0.035f),
                                Lilac.fill.copy(alpha = 0.055f),
                                GoldNeon.copy(alpha = 0.035f),
                            ),
                        ),
                    ),
            )
        }
    }
}
