package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.Candy
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.cos
import kotlin.math.sin

/**
 * Cinematic AI opener. The orb is the hero, not a loader: a large dark-glass
 * sphere with an internal iridescent flow, a physical rim highlight and the
 * supplied purple aura ribbons wrapping into it. The old skeleton cards were
 * removed because they looked like fake network latency rather than a real AI
 * arriving.
 */
@Composable
fun AiZomatoReveal(
    name: String,
    onFinished: () -> Unit,
) {
    val phase = remember { Animatable(0f) }
    var alive by remember { mutableStateOf(true) }
    val haptics = rememberHaptics()
    val context = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(Unit) {
        Sfx.init(context)
        // One audio timeline, matched to the visual playhead below.
        Sfx.play(Sound.RISER)
        phase.animateTo(0.30f, tween(650, easing = FastOutSlowInEasing))
        Sfx.play(Sound.SHIMMER)
        haptics.tick()
        phase.animateTo(0.58f, tween(560, easing = FastOutSlowInEasing))
        Sfx.play(Sound.POP)
        haptics.press()
        phase.animateTo(0.80f, tween(460, easing = FastOutSlowInEasing))
        Sfx.play(Sound.REPLY)
        haptics.tick()
        phase.animateTo(1f, tween(720, easing = LinearEasing))
        alive = false
        onFinished()
    }

    if (!alive) return

    val p = phase.value
    val enter = (p / 0.34f).coerceIn(0f, 1f)
    val hold = ((p - 0.20f) / 0.60f).coerceIn(0f, 1f)
    val exit = ((p - 0.82f) / 0.18f).coerceIn(0f, 1f)
    val textIn = ((p - 0.48f) / 0.28f).coerceIn(0f, 1f)
    val fade = 1f - exit

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF05070E).copy(alpha = 0.97f)),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width * 0.5f
            val cy = size.height * 0.39f
            val r = 76.dp.toPx() * (0.70f + 0.30f * enter)
            val glow = r * (4.8f + 1.6f * sin(p * Math.PI).toFloat())

            // Deep ambient bloom behind the entire object.
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(
                        Lilac.fill.copy(alpha = 0.28f * fade),
                        Sky.fill.copy(alpha = 0.12f * fade),
                        Color.Transparent,
                    ),
                    radius = glow,
                ),
                radius = glow,
                center = Offset(cx, cy),
            )

            // The aura is one continuous system: broad ribbons pass behind
            // the orb, then their paths converge into the sphere's sides.
            drawAuraRibbon(cx, cy, r, p, fade, 0f, 0.55f)
            drawAuraRibbon(cx, cy, r, p, fade, 1f, 0.34f)

            val sphere = Path().apply {
                addOval(Rect(center = Offset(cx, cy), radius = r))
            }
            clipPath(sphere) {
                // Dark glass body, shaded away from the light source.
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(
                            Color(0xFF3A3458).copy(alpha = 0.98f * fade),
                            Color(0xFF171526).copy(alpha = 0.98f * fade),
                            Color(0xFF05060D).copy(alpha = 0.99f * fade),
                        ),
                        center = Offset(cx - r * 0.34f, cy - r * 0.42f),
                        radius = r * 1.35f,
                    ),
                    radius = r,
                    center = Offset(cx, cy),
                )

                // Internal flowing ribbon — clipped inside the glass so it
                // feels refracted through the sphere instead of painted on it.
                rotate(degrees = p * 150f, pivot = Offset(cx, cy)) {
                    val path = Path().apply {
                        moveTo(cx - r * 1.15f, cy + r * 0.45f)
                        cubicTo(
                            cx - r * 0.45f, cy - r * 1.05f,
                            cx + r * 0.15f, cy + r * 1.10f,
                            cx + r * 1.18f, cy - r * 0.32f,
                        )
                    }
                    drawPath(
                        path,
                        brush = Brush.linearGradient(
                            listOf(
                                Sky.fill.copy(alpha = 0.04f),
                                Sky.fill.copy(alpha = 0.74f),
                                Candy.fill.copy(alpha = 0.66f),
                                Lilac.fill.copy(alpha = 0.78f),
                                Color.Transparent,
                            ),
                            start = Offset(cx - r, cy - r),
                            end = Offset(cx + r, cy + r),
                        ),
                        style = Stroke(width = r * 0.28f, cap = StrokeCap.Round),
                    )
                }

                rotate(degrees = -p * 95f, pivot = Offset(cx, cy)) {
                    val path = Path().apply {
                        moveTo(cx - r * 1.25f, cy - r * 0.18f)
                        cubicTo(
                            cx - r * 0.30f, cy + r * 0.90f,
                            cx + r * 0.48f, cy - r * 0.90f,
                            cx + r * 1.20f, cy + r * 0.20f,
                        )
                    }
                    drawPath(
                        path,
                        brush = Brush.linearGradient(
                            listOf(
                                Color.Transparent,
                                Lilac.fill.copy(alpha = 0.58f),
                                Color.White.copy(alpha = 0.58f),
                                Sky.fill.copy(alpha = 0.46f),
                                Color.Transparent,
                            ),
                            start = Offset(cx - r, cy),
                            end = Offset(cx + r, cy),
                        ),
                        style = Stroke(width = r * 0.14f, cap = StrokeCap.Round),
                    )
                }

                // Soft inner reflection.
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.20f * hold), Color.Transparent),
                        center = Offset(cx - r * 0.36f, cy - r * 0.46f),
                        radius = r * 0.42f,
                    ),
                    radius = r * 0.42f,
                    center = Offset(cx - r * 0.36f, cy - r * 0.46f),
                )
            }

            // Physical glass edge: a bright crescent and a quieter lower rim.
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(
                        Color.Transparent,
                        Color.White.copy(alpha = 0.92f * fade),
                        Sky.fill.copy(alpha = 0.78f * fade),
                        Color.Transparent,
                        Lilac.fill.copy(alpha = 0.62f * fade),
                    ),
                    center = Offset(cx, cy),
                ),
                startAngle = -118f,
                sweepAngle = 290f,
                useCenter = false,
                topLeft = Offset(cx - r, cy - r),
                size = androidx.compose.ui.geometry.Size(r * 2f, r * 2f),
                style = Stroke(width = r * 0.055f),
            )

            // Specular streak, moving subtly as the orb settles.
            val sx = cx - r * 0.30f + sin(p * Math.PI * 2.0).toFloat() * r * 0.08f
            val sy = cy - r * 0.47f
            drawOval(
                brush = Brush.linearGradient(
                    listOf(Color.White.copy(alpha = 0.82f * fade), Color.Transparent),
                ),
                topLeft = Offset(sx - r * 0.16f, sy - r * 0.055f),
                size = androidx.compose.ui.geometry.Size(r * 0.28f, r * 0.10f),
            )

            // A single pulse ring at the "AI online" beat.
            if (p > 0.55f && p < 0.82f) {
                val q = ((p - 0.55f) / 0.27f).coerceIn(0f, 1f)
                drawCircle(
                    color = Sky.fill.copy(alpha = 0.28f * (1f - q)),
                    radius = r * (1.05f + q * 0.55f),
                    center = Offset(cx, cy),
                    style = Stroke(width = 2.dp.toPx()),
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 26.dp)
                .alpha(fade),
        ) {
            Spacer(Modifier.height(230.dp))
            Text(
                if (name.isBlank()) "Hello" else "Hello $name",
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.64f * textIn),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "How can I help you today?",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = 0.96f * textIn),
            )
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawAuraRibbon(
    cx: Float,
    cy: Float,
    r: Float,
    p: Float,
    alpha: Float,
    phaseOffset: Float,
    strength: Float,
) {
    val w = size.width
    val drift = sin((p + phaseOffset) * Math.PI * 2.0).toFloat()
    val y = cy + drift * r * 0.95f
    val path = Path().apply {
        moveTo(-w * 0.10f, y + r * 0.18f)
        cubicTo(
            w * 0.18f, cy - r * 1.55f + drift * r * 0.40f,
            w * 0.42f, cy + r * 1.55f - drift * r * 0.25f,
            cx - r * 0.72f, cy + r * 0.18f,
        )
        cubicTo(
            cx - r * 0.10f, cy - r * 0.92f,
            cx + r * 0.42f, cy + r * 0.96f,
            w * 1.10f, y - r * 0.14f,
        )
    }
    drawPath(
        path,
        brush = Brush.horizontalGradient(
            listOf(
                Color.Transparent,
                Lilac.fill.copy(alpha = 0.18f * strength * alpha),
                Sky.fill.copy(alpha = 0.72f * strength * alpha),
                Lilac.fill.copy(alpha = 0.50f * strength * alpha),
                Color.Transparent,
            )
        ),
        style = Stroke(
            width = r * (0.22f + 0.08f * sin(p * Math.PI * 2.0).toFloat()),
            cap = StrokeCap.Round,
            join = StrokeJoin.Round,
        ),
    )
}
