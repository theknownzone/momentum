package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.rememberInfiniteTransition
import com.momentum.focus.ui.theme.Candy
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import kotlin.math.cos
import kotlin.math.sin

/**
 * Lightweight entrance choreography based on the supplied Zomato reference:
 * tiny four-point AI mark, short Thinking state, side chromatic bloom/halftone,
 * then the hunting message. No skeleton cards, no orb, no per-frame layout.
 */
@Composable
fun AiZomatoReveal(name: String, onFinished: () -> Unit) {
    val timeline = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        timeline.animateTo(1f, tween(2500, easing = LinearEasing))
        onFinished()
    }

    val p = timeline.value
    val intro = (p / 0.14f).coerceIn(0f, 1f)
    val thinking = ((p - 0.08f) / 0.22f).coerceIn(0f, 1f)
    val hunt = ((p - 0.30f) / 0.24f).coerceIn(0f, 1f)
    val fade = ((p - 0.78f) / 0.22f).coerceIn(0f, 1f)
    val visible = 1f - fade

    val drift = rememberInfiniteTransition(label = "aiEntranceDrift")
    val phase by drift.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse),
        label = "aiEntranceDriftPhase",
    )

    Box(
        Modifier.fillMaxSize().background(Color(0xFF0D0E13).copy(alpha = 0.18f * visible)),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width * 0.50f
            val cy = size.height * 0.49f
            val mark = (thinking * visible).coerceIn(0f, 1f)

            // Soft colour pools sweep in from the sides, like the reference.
            val sweep = ((p * 1.55f + phase * 0.10f) % 1f)
            val leftX = size.width * (-0.08f + sweep * 0.48f)
            val rightX = size.width * (1.08f - sweep * 0.48f)
            drawCircle(
                Brush.radialGradient(listOf(Lilac.fill.copy(alpha = 0.22f * hunt), Color.Transparent)),
                radius = size.minDimension * 0.30f,
                center = Offset(leftX, cy),
            )
            drawCircle(
                Brush.radialGradient(listOf(Candy.fill.copy(alpha = 0.16f * hunt), Color.Transparent)),
                radius = size.minDimension * 0.25f,
                center = Offset(rightX, cy + 8.dp.toPx()),
            )

            // Halftone dots only appear around the moving colour pools.
            if (hunt > 0f) {
                val step = 8.dp.toPx()
                val bx = size.width * (0.20f + sweep * 0.60f)
                val by = cy
                for (row in -5..5) for (col in -6..6) {
                    val dx = col * step
                    val dy = row * step
                    val d = kotlin.math.sqrt(dx * dx + dy * dy)
                    val a = (1f - d / (step * 6.2f)).coerceIn(0f, 1f) * 0.28f * hunt * visible
                    if (a > 0.01f) drawCircle(
                        when ((row + col + 20) and 3) {
                            0 -> Lilac.fill
                            1 -> Sky.fill
                            2 -> Candy.fill
                            else -> Mint.fill
                        }.copy(alpha = a),
                        1.15.dp.toPx(),
                        Offset(bx + dx, by + dy),
                    )
                }
            }

            // Zomato-like tiny sparkle/cross, deliberately not an orb.
            if (mark > 0f) {
                val pulse = 0.82f + 0.18f * sin((p * 18f).toDouble()).toFloat()
                val r = size.minDimension * 0.010f * pulse
                drawCircle(Color.White.copy(alpha = 0.78f * mark), r * 2.8f, Offset(cx, cy))
                repeat(4) { i ->
                    val a = i * Math.PI / 2.0
                    val inner = r * 0.8f
                    val outer = r * (3.6f + 1.5f * sin((p * 10f + i).toDouble()).toFloat())
                    drawLine(
                        listOf(Lilac.fill, Sky.fill, Mint.fill, Candy.fill)[i].copy(alpha = 0.88f * mark),
                        Offset(cx + cos(a).toFloat() * inner, cy + sin(a).toFloat() * inner),
                        Offset(cx + cos(a).toFloat() * outer, cy + sin(a).toFloat() * outer),
                        strokeWidth = 1.5.dp.toPx(),
                    )
                }
            }
        }

        Column(
            Modifier.fillMaxWidth().padding(horizontal = 28.dp).alpha(intro * visible),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "Thinking",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.82f * thinking),
                modifier = Modifier.alpha((1f - hunt * 1.25f).coerceIn(0f, 1f)),
            )
            Text(
                "Hunting for the perfect spots...",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.82f * hunt),
                modifier = Modifier.alpha(hunt),
            )
        }
    }
}
