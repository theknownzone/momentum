package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.Candy
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import kotlin.math.cos
import kotlin.math.sin

/**
 * Momentum's own take on the reference choreography: dim the live screen,
 * greet, show two lightweight skeleton surfaces, move to a tiny AI mark with
 * a short "Thinking" state, then hand the screen back. One timeline drives the
 * whole thing; there are no infinite animations or per-frame layout changes.
 */
@Composable
fun AiZomatoReveal(name: String, onFinished: () -> Unit) {
    val phase = remember { Animatable(0f) }
    var alive by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        phase.animateTo(0.18f, tween(520, easing = FastOutSlowInEasing))
        phase.animateTo(0.40f, tween(620, easing = FastOutSlowInEasing))
        phase.animateTo(0.68f, tween(1_150, easing = FastOutSlowInEasing))
        phase.animateTo(1f, tween(1_000, easing = LinearEasing))
        alive = false
        onFinished()
    }

    if (!alive) return

    val p = phase.value
    val greeting = (1f - p / 0.28f).coerceIn(0f, 1f)
    val cards = ((p - 0.12f) / 0.25f).coerceIn(0f, 1f)
    val thinking = ((p - 0.36f) / 0.28f).coerceIn(0f, 1f)
    val fade = ((p - 0.72f) / 0.28f).coerceIn(0f, 1f)

    Box(
        Modifier.fillMaxSize().background(Color(0xFF0D0E13).copy(alpha = 0.82f * (1f - fade))),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width * 0.5f
            val cy = size.height * 0.50f
            val a = (1f - fade)

            // Small chromatic halftone bloom, intentionally offset like the
            // reference rather than turning the whole screen into a gradient.
            val bloom = thinking * (1f - fade)
            if (bloom > 0f) {
                val bx = size.width * 0.76f
                val by = size.height * 0.48f
                val step = 13.dp.toPx()
                for (row in 0 until 9) {
                    for (col in 0 until 10) {
                        val dx = (col - 4.5f) * step
                        val dy = (row - 4f) * step
                        val d = kotlin.math.sqrt(dx * dx + dy * dy)
                        val alpha = (1f - d / (step * 6f)).coerceIn(0f, 1f) * 0.30f * bloom
                        val c = when ((row + col) % 4) {
                            0 -> Lilac.fill
                            1 -> Sky.fill
                            2 -> Candy.fill
                            else -> Mint.fill
                        }
                        drawCircle(c.copy(alpha = alpha), (2.4f - d / (step * 8f)).coerceAtLeast(0.7f), Offset(bx + dx, by + dy))
                    }
                }
            }

            // Tiny four-point AI mark: this is the focal cue, not a giant orb.
            val mark = (thinking * (1f - fade)).coerceIn(0f, 1f)
            if (mark > 0f) {
                val r = size.minDimension * (0.018f + 0.012f * mark)
                drawCircle(
                    brush = Brush.radialGradient(listOf(Color.White.copy(alpha = 0.95f * mark), Lilac.fill.copy(alpha = 0.45f * mark), Color.Transparent)),
                    radius = r * 4f,
                    center = Offset(cx, cy),
                )
                repeat(4) { i ->
                    val ang = i * Math.PI / 2.0
                    val inner = r * 1.3f
                    val outer = r * (2.8f + mark * 2f)
                    drawLine(
                        color = listOf(Lilac.fill, Sky.fill, Mint.fill, GoldNeon)[i].copy(alpha = 0.78f * mark),
                        start = Offset(cx + cos(ang).toFloat() * inner, cy + sin(ang).toFloat() * inner),
                        end = Offset(cx + cos(ang).toFloat() * outer, cy + sin(ang).toFloat() * outer),
                        strokeWidth = 1.8.dp.toPx(),
                    )
                }
            }
        }

        Column(
            Modifier.fillMaxWidth().padding(horizontal = 28.dp).alpha(a),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                if (name.isBlank()) "Hi!" else "Hi, $name!",
                fontSize = 20.sp,
                color = Color.White.copy(alpha = 0.96f * greeting),
            )
            Spacer(Modifier.height(5.dp))
            Text(
                "What do you want to solve?",
                fontSize = 16.sp,
                color = Color.White.copy(alpha = 0.82f * greeting),
            )

            Spacer(Modifier.height(62.dp))
            Column(
                Modifier.fillMaxWidth().alpha(cards * (1f - fade)).scale(0.96f + cards * 0.04f),
            ) {
                SkeletonCard()
                Spacer(Modifier.height(10.dp))
                SkeletonCard(short = true)
            }

            Spacer(Modifier.height(28.dp))
            Text(
                if (p < 0.55f) "Preparing your space" else "Thinking",
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.72f * thinking * (1f - fade)),
            )
        }
    }
}

@Composable
private fun SkeletonCard(short: Boolean = false) {
    Box(
        Modifier.fillMaxWidth().height(if (short) 82.dp else 106.dp)
            .clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = 0.055f))
            .padding(15.dp),
    ) {
        Column {
            Box(Modifier.fillMaxWidth(0.52f).height(11.dp).clip(RoundedCornerShape(8.dp)).background(Color.White.copy(alpha = 0.075f)))
            Spacer(Modifier.height(13.dp))
            Box(
                Modifier.fillMaxWidth().height(if (short) 38.dp else 57.dp).clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(listOf(Sky.fill.copy(alpha = 0.025f), Lilac.fill.copy(alpha = 0.045f), GoldNeon.copy(alpha = 0.025f)))),
            )
        }
    }
}
