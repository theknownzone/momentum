package com.momentum.focus.ui.components

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.platform.LocalClipboardManager
import android.net.Uri
import com.momentum.focus.ai.Attach
import androidx.compose.foundation.background
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ai.Ai
import com.momentum.focus.ai.DoubtState
import com.momentum.focus.ai.MyAiMode
import com.momentum.focus.ai.StudyPulse
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import androidx.core.content.FileProvider
import com.momentum.focus.ui.util.ExportChat
import com.momentum.focus.ui.util.rememberHaptics
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Rounded at the top only. The bottom edge is the bottom of the screen. */
private val SheetShape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)

/**
 * How much of the input glow is on when nothing is happening.
 *
 * Not zero: the ring is part of how the composer looks, and a box that only
 * glows while an answer is being written shows the effect for a few seconds at
 * the exact moment the reader is watching the reply instead.
 */
private const val REST = 0.42f

/**
 * The one place in this app where a person types at a model.
 *
 * Everything that could make it a hiding place is on screen rather than in a
 * comment: the questions left, the clock still running, and an answer that
 * ends instead of inviting another. Closing the sheet does not cancel a
 * request in flight — the answer will be waiting when it is reopened — because
 * a request that has already been paid for should not have to be paid for
 * twice.
 */
@Composable
fun DoubtSheet(
    state: DoubtState,
    /** The live countdown, or null when no session is running. */
    clock: String?,
    /** Question, pages, and whether those pages were carried from an earlier turn. */
    onAsk: (String, List<String>, Boolean) -> Unit,
    onRetry: () -> Unit,
    onStop: () -> Unit,
    onClose: () -> Unit,
    mode: MyAiMode = MyAiMode.Study,
    onMode: (MyAiMode) -> Unit = {},
    pulse: StudyPulse? = null,
    embedded: Boolean = false,
    premium: Boolean = false,
    onPlans: () -> Unit = {},
    /** Null hides the drill entirely, same as a build with no key. */
    onMock: ((String?) -> Unit)? = null,
    /** Shown in the greeting. Blank hides it rather than saying "hello, ". */
    name: String = "",
) {
    val str = strings()
    val haptics = rememberHaptics()
    val context = LocalContext.current
    var text by rememberSaveable { mutableStateOf("") }
    var pendingJpegs by remember { mutableStateOf<List<String>>(emptyList()) }
    var pendingLabel by remember { mutableStateOf<String?>(null) }
    var lastPages by remember { mutableStateOf<List<String>>(emptyList()) }
    val pendingJpeg = pendingJpegs.firstOrNull()
    val listState = rememberLazyListState()
    val spent = state.left <= 0
    val modeLabel = when (mode) {
        MyAiMode.Study -> str.doubt.modeStudy
        MyAiMode.Friend -> str.doubt.modeFriend
        MyAiMode.Guru -> str.doubt.modeGuru
    }

    // Decoding a photo or rendering a PDF page allocates megabytes and touches
    // disk. Run inline on the picker callback — which is the main thread — it
    // froze the composer for as long as the work took, and on a big photo that
    // is long enough to be an ANR rather than a stutter.
    val scope = rememberCoroutineScope()
    fun ingest(uri: Uri?) {
        if (uri == null) return
        pendingLabel = str.doubt.attaching
        scope.launch {
            withContext(Dispatchers.IO) { runCatching { Attach.fromUri(context, uri) } }
                .onSuccess {
                    pendingJpegs = (pendingJpegs + it.jpegB64).distinct().take(5)
                    pendingLabel = "${pendingJpegs.size}/5"
                    lastPages = pendingJpegs
                    haptics.confirm()
                }
                .onFailure {
                    pendingLabel = it.message ?: str.doubt.attachFailed
                    haptics.reject()
                }
        }
    }

    var shotUri by remember { mutableStateOf<Uri?>(null) }
    // TakePicture writes into a Uri we own rather than returning a bitmap, so
    // no CAMERA permission is needed — the system camera app holds that, and
    // asking for it here would be one more dialog for nothing.
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) ingest(shotUri)
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        uris.take(5 - pendingJpegs.size).forEach { ingest(it) }
    }
    val pickPdf = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { ingest(it) }

    BackHandler { onClose() }

    // Two rules, because one scroll was doing two jobs badly.
    //
    // It followed every change, so scrolling back to re-read something was
    // undone the moment an answer landed. Now it only follows if you were
    // already down at the newest part.
    //
    // And it scrolled to the very end, which for a long answer means the list
    // stops with the last line against the bottom and the first line pushed off
    // the top — the answer arrives already half buried. An answer is scrolled
    // to its own start instead, so it is read from the first word.
    // Chat deliberately has no repeating haptic while the model is thinking.
    // One semantic cue on send is enough; the reply itself is announced by SFX.

    // Straight to the last item, every time, with no condition on it.
    //
    // Every previous version guarded this with "only if they were already at
    // the bottom" and every version of that guard was wrong in a different
    // way — first firstVisibleItemIndex, then the visible-items window — and
    // each one failed exactly when the thread got long enough to matter. The
    // guard was protecting against dragging someone away from something they
    // were re-reading, which is a real thing but a rarer one than the reply
    // simply never appearing. This does the obvious thing instead.
    // state.streaming too, so the view follows the answer down as it is
    // written rather than jumping once at the end.
    // Only animate when a real message is added. The previous effect was keyed
    // to the entire streaming string, so every token restarted an
    // animateScrollToItem() animation. That made the chat fight the user's
    // finger and is the main source of the visible lag.
    LaunchedEffect(state.thread.size, state.busy, state.error) {
        if (state.thread.isEmpty()) return@LaunchedEffect
        val end = state.thread.size
        listState.animateScrollToItem(end)
        delay(120)
        listState.scrollToItem(end)
    }

    fun submit() {
        val question = text.trim()
        if ((question.isBlank() && pendingJpegs.isEmpty()) || state.busy || spent) return
        // Its own sound. This used to be confirm(), which is what a completed
        // session sounds like — so asking a question and finishing an hour of
        // study were indistinguishable with your eyes shut.
        haptics.send()
        // Pages carry to the *next* question and no further.
        //
        // They used to stick for the rest of the session: attach a photo once
        // and every message after it re-sent the same photo, forever, with no
        // way to stop. A follow-up like "I still don't get step two" needs the
        // page; the question after that is usually about something else, and
        // silently re-uploading a stale photo makes every later answer worse
        // and every request slower.
        val carried = pendingJpegs.isEmpty() && lastPages.isNotEmpty()
        val pics = pendingJpegs.ifEmpty { lastPages }
        onAsk(question, pics, carried)
        text = ""
        // Consumed here, and this is the fix.
        //
        // The comment above has always said pages carry to the next question
        // "and no further" — and nothing ever cleared lastPages, so they
        // carried to every question for the rest of the session. Attach one
        // screenshot and it rode along with every message after it, which is
        // the same picture stuck to three bubbles in a row.
        //
        // Set from a fresh attach, emptied once it has been spent on a
        // follow-up.
        lastPages = if (pendingJpegs.isNotEmpty()) pendingJpegs else emptyList()
        pendingJpegs = emptyList()
        // The composer empties on send. lastPages keeps the photo as context
        // for a follow-up, but it is no longer *pending* — and the label was
        // still being rebuilt from it, so the thumbnail and the "1/5" stayed
        // sitting in the box after the message had gone. It read as though the
        // send had failed and the picture was still waiting to be sent.
        pendingLabel = null
    }

    // Embedded, this paints nothing of its own. It used to carry an opaque
    // Cream fill across fillMaxSize, which sat on top of the ghost word and
    // the gold aura the MyAi screen draws underneath — both were being
    // rendered and then covered, which is why neither had ever been seen. The
    // screen owns the paper now; the panel is just the layout on it.
    // Remembered out here rather than inside the branch: a remember() reached
    // only on one side of an if is a slot that moves if the condition ever
    // changes.
    val panelTaps = remember { MutableInteractionSource() }
    val panel = Modifier
        .fillMaxWidth()
        .then(
            if (embedded) {
                Modifier.fillMaxSize()
            } else {
                Modifier
                    .fillMaxHeight(0.88f)
                    .clip(SheetShape)
                    .border(Paper.Outline, Ink, SheetShape)
                    .background(Cream)
                    // Swallows taps so they do not reach the scrim's closer
                    // behind the sheet. Only the modal needs it; embedded there
                    // is no scrim to fall through to.
                    .clickableNoRipple(panelTaps) { }
                    .paperGrain()
            },
        )
        .padding(horizontal = 16.dp)
        // Extra room at the top when embedded: MyAi draws its own back arrow
        // up there now, and without this the first bubble slid under it.
        .padding(top = if (embedded) 46.dp else 14.dp, bottom = 10.dp)

    @Composable
    fun Panel() {
            Column(panel) {
                // Embedded there is no title and no close button — the tab bar
                // is the way out — so the header row is skipped rather than
                // laid out empty. It was costing a spacer's worth of height
                // above the counts for nothing.
                if (!embedded) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            str.doubt.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = InkMid,
                        )
                        Text(
                            str.doubt.title,
                            style = MaterialTheme.typography.headlineSmall,
                            color = Ink,
                        )
                    }
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                onClose()
                            }
                            .padding(6.dp),
                    ) {
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = str.doubt.close,
                            tint = Ink,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                }

                // The price, always visible. A limit nobody can see is not a
                // limit, it is a surprise waiting to happen.
                // Solid, not glass. On Home this strip sits on a near-black
                // hero and reads fine; here it sits on cream paper with a
                // giant ghost word behind it, and translucent green on that
                // was unreadable at any size. The two numbers it carries are
                // the price of this screen — they have to be legible before
                // they can be tasteful.
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Ink)
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        str.doubt.left(state.left),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (spent) Tang.fill else Mint.fill,
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        clock?.let { str.doubt.clockRunning(it) } ?: str.doubt.clockPaused,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (clock != null) Tang.fill else Cream.copy(alpha = 0.55f),
                    )
                    Spacer(Modifier.weight(1f))
                    if (state.thread.isNotEmpty()) {
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    ExportChat.share(
                                        context = context,
                                        thread = state.thread,
                                        mode = modeLabel,
                                        you = str.doubt.exportYou,
                                        ai = str.doubt.exportAi,
                                    )
                                }
                                .padding(4.dp),
                        ) {
                            Icon(
                                Icons.Filled.IosShare,
                                contentDescription = str.doubt.export,
                                tint = Mint.fill,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                // Modes moved to the sheet behind the header's menu button. A
                // permanent row of three, two of them with a "· Pro" suffix,
                // was most of the width of a phone spent on a control touched
                // once a session — and every pixel it held is a pixel the
                // conversation did not get.
                if (!embedded) {
                    ModeRow(mode = mode, onMode = onMode, premium = premium, onPlans = onPlans)
                }
                Spacer(Modifier.height(10.dp))

                Box(Modifier.weight(1f)) {
                    if (state.thread.isEmpty()) {
                        EmptyThread(name = name, onPick = { text = it }, pulse = pulse)
                    } else {
                        Box(Modifier.fillMaxSize()) {
                            LazyColumn(
                                state = listState,
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(14.dp),
                            ) {
                                items(state.thread) { turn -> Bubble(turn) }
                                item {
                                    Status(
                                        state = state,
                                        onRetry = { haptics.press(); onRetry() },
                                    )
                                }
                            }
                            // iOS-style edge fade: content softly disappears
                            // under the top/bottom edges while the user scrolls.
                            // It is a cheap gradient overlay, not blur, so it does
                            // not add frame-time work to the chat.
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(22.dp)
                                    .align(Alignment.TopCenter)
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(MaterialTheme.colorScheme.background.copy(alpha = 0.98f), Color.Transparent)
                                        )
                                    )
                            )
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(28.dp)
                                    .align(Alignment.BottomCenter)
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color.Transparent, MaterialTheme.colorScheme.background.copy(alpha = 0.99f))
                                        )
                                    )
                            )
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                Column(Modifier.imePadding()) {
                if (spent) {
                    // The dead input box is replaced rather than disabled. A
                    // box you can tap that refuses to take a letter reads as a
                    // bug; a sentence saying why reads as a rule.
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(Paper.ChipRadius))
                            .background(Tang.fill)
                            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.ChipRadius))
                            .padding(14.dp),
                    ) {
                        Text(
                            str.doubt.noneLeftTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = Tang.on,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            str.doubt.noneLeftBody,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Tang.on,
                        )
                    }
                } else {
                    Composer(
                        text = text,
                        onText = { text = it },
                        busy = state.busy,
                        canSend = text.isNotBlank() || pendingJpegs.isNotEmpty() || lastPages.isNotEmpty(),
                        premium = premium,
                        attachmentLabel = pendingLabel,
                        // Only what is actually pending. Falling back to
                        // lastPages here is what kept a sent photo on screen:
                        // the list the composer displayed and the list waiting
                        // to be sent were not the same list.
                        attachmentJpegs = pendingJpegs,
                        onClearAttach = {
                            pendingJpegs = emptyList()
                            lastPages = emptyList()
                            pendingLabel = null
                        },
                        onRemoveAttach = { i ->
                            val src = pendingJpegs.ifEmpty { lastPages }
                            val next = src.filterIndexed { idx, _ -> idx != i }
                            pendingJpegs = next
                            lastPages = next
                            pendingLabel = next.size.takeIf { it > 0 }?.let { "$it/5" }
                        },
                        onAttach = { what ->
                            when (what) {
                                Attachment.Camera -> {
                                    if (pendingJpegs.size >= 5) return@Composer
                                    val file = File(context.cacheDir, "momentum-shot-${pendingJpegs.size}.jpg")
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        file,
                                    )
                                    shotUri = uri
                                    runCatching { takePhoto.launch(uri) }
                                }
                                Attachment.Photo -> pickImage.launch("image/*")
                                Attachment.Pdf -> pickPdf.launch("application/pdf")
                                Attachment.Mock -> onMock?.invoke(pendingJpegs.firstOrNull())
                            }
                        },
                        onSend = { submit() },
                        onStop = { haptics.reject(); onStop() },
                        onPlans = onPlans,
                    )
                }

                Spacer(Modifier.height(4.dp))
                Text(
                    str.doubt.disclaimer,
                    style = MaterialTheme.typography.labelSmall,
                    color = InkMid.copy(alpha = 0.85f),
                )
                }
            }
    }

    if (embedded) {
        Box(Modifier.fillMaxSize()) { Panel() }
    } else {
        FrostScrim {
            Box(
                Modifier
                    .fillMaxSize()
                    .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
            )
            Box(
                Modifier.fillMaxSize(),
                contentAlignment = Alignment.BottomCenter,
            ) { Panel() }
        }
    }
}

/**
 * What sits under the last question: the dots, a failure, or an offer to ask
 * it again after a stop.
 */
@Composable
private fun Status(state: DoubtState, onRetry: () -> Unit) {
    val str = strings()
    val haptics = rememberHaptics()
    var lastReceivedThreadSize by remember { mutableIntStateOf(state.thread.size) }

    // Give the reply itself a tactile rhythm, but never one pulse per token.
    // One soft beat about every 720ms while text is actually arriving is
    // enough to communicate "AI is writing" and remains comfortable on long
    // answers. A final receive cue lands when streaming finishes.
    LaunchedEffect(state.busy, state.streaming.isNotEmpty()) {
        if (!state.busy) return@LaunchedEffect
        while (state.busy) {
            if (state.streaming.isNotEmpty()) haptics.waiting()
            delay(720)
        }
    }

    LaunchedEffect(state.busy, state.thread.size) {
        val size = state.thread.size
        if (size > lastReceivedThreadSize && !state.busy && state.thread.lastOrNull()?.fromUser == false) {
            haptics.receive()
        }
        if (size > lastReceivedThreadSize) lastReceivedThreadSize = size
    }

    when {
        // Once text is arriving, the text is the status.
        //
        // The pulse is honest for the second or two before the model starts
        // writing, and a lie after that: it says "being looked at" while the
        // answer already exists and is being withheld. Swapping to the words
        // as soon as there are any is the whole reason streaming was worth
        // doing — the wait stops being a wait and becomes reading.
        state.busy && state.streaming.isNotEmpty() -> {
            val cursor by androidx.compose.animation.core.rememberInfiniteTransition(label = "streamCursor")
                .animateFloat(
                    initialValue = 0.18f,
                    targetValue = 1f,
                    animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                        animation = tween(620),
                        repeatMode = androidx.compose.animation.core.RepeatMode.Reverse,
                    ),
                    label = "cursorAlpha",
                )
            Row(
                verticalAlignment = Alignment.Bottom,
                modifier = Modifier.padding(vertical = 4.dp),
            ) {
                Text(
                    state.streaming,
                    style = MaterialTheme.typography.bodyLarge.copy(lineHeight = 25.sp),
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(Modifier.width(4.dp))
                Box(
                    Modifier
                        .size(width = 2.dp, height = 18.dp)
                        .alpha(cursor)
                        .background(LocalSkin.current.accent),
                )
            }
        }

        // The scan, not the three dots. Dots said "loading"; a pulse going out
        // from the middle says the thing you sent is being looked at, which is
        // what is actually happening.
        state.busy -> ScanPulse(str.doubt.thinking, Modifier.padding(vertical = 18.dp))

        state.error != null -> {
            Column {
                Text(
                    state.error,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
                Spacer(Modifier.height(8.dp))
                SquishButton(str.doubt.retry, Sky, Modifier.fillMaxWidth(0.6f)) { onRetry() }
            }
        }

        state.awaitingRetry -> {
            Column {
                Text(
                    str.doubt.stopped,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                )
                Spacer(Modifier.height(8.dp))
                // Re-asks the question already on screen. Stopping an answer
                // should not cost the typing that led to it.
                SquishButton(str.doubt.retry, Sky, Modifier.fillMaxWidth(0.6f)) { onRetry() }
            }
        }
    }
}

/**
 * The empty sheet.
 *
 * The examples are tappable because the first question sets the size of every
 * one after it, and three one-line doubts teach that faster than an
 * instruction to keep it short.
 */
@Composable
private fun EmptyThread(
    name: String,
    onPick: (String) -> Unit,
    pulse: StudyPulse? = null,
) {
    val str = strings()
    val haptics = rememberHaptics()
    Column {
        pulse?.let { PulseCard(it) }
        Text(
            str.doubt.intro,
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
        )
        Spacer(Modifier.height(14.dp))
        str.doubt.examples.forEach { example ->
            Box(
                Modifier
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(Paper.ChipRadius))
                    .background(CreamCard)
                    .border(2.dp, Ink, RoundedCornerShape(Paper.ChipRadius))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        onPick(example)
                    }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
            ) {
                Text(
                    example,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Ink,
                )
            }
        }
    }
}

/**
 * One message, copyable.
 *
 * Long-press rather than a button on every bubble: a copy icon repeated down
 * the whole thread is a row of clutter for something used once in twenty
 * messages, and long-press-to-copy is what every chat app already trained
 * people to try.
 */
@Composable
private fun Bubble(turn: Ai.Turn) {
    val clipboard = LocalClipboardManager.current
    val haptics = rememberHaptics()
    val str = strings()
    var copied by remember { mutableStateOf(false) }
    // The confirmation disappears on its own. A copied badge that stays is a
    // second thing to dismiss.
    LaunchedEffect(copied) {
        if (copied) { delay(1400); copied = false }
    }
    Row(Modifier.fillMaxWidth(),
        horizontalArrangement = if (turn.fromUser) Arrangement.End else Arrangement.Start,
    ) {
        val shape = RoundedCornerShape(Paper.CardRadius)
        val accent = LocalSkin.current.accent
        Box(
            Modifier
                .fillMaxWidth(0.88f)
                .then(
                    if (!turn.fromUser) Modifier.drawBehind {
                        // Radius taken from the bubble's own corner and grown
                        // with each ring. It was a bare 18f — raw pixels, so
                        // the corners were a different shape on every screen
                        // density, and square against the bubble's rounding.
                        val radius = Paper.CardRadius.toPx()
                        listOf(5.dp to 0.35f, 11.dp to 0.16f).forEach { ring ->
                            val out = ring.first.toPx()
                            drawRoundRect(
                                color = accent.copy(alpha = ring.second),
                                topLeft = Offset(-out, -out),
                                size = Size(size.width + out * 2, size.height + out * 2),
                                cornerRadius = CornerRadius(radius + out, radius + out),
                                style = Stroke(width = 2.dp.toPx()),
                            )
                        }
                    } else Modifier
                )
                .clip(shape)
                // detectTapGestures, not combinedClickable. The latter is
                // still @ExperimentalFoundationApi and this project carries no
                // foundation opt-in anywhere — adding one for a long-press
                // would put an experimental annotation on a file for a feature
                // that a pointer handler does exactly as well.
                .pointerInput(turn.text) {
                    detectTapGestures(
                        onLongPress = {
                            clipboard.setText(AnnotatedString(turn.text))
                            haptics.confirm()
                            copied = true
                        },
                    )
                }
                .background(if (turn.fromUser) Sky.fill else CreamCard)
                .border(Paper.Outline, Ink, shape)
                .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            Column {
                // Not on a carried turn. The pages still go up so the model
                // can see the page a follow-up is about, but drawing them here
                // put the same screenshot on a message the user typed without
                // attaching anything — which is the repeat.
                if (turn.allImages.isNotEmpty() && !turn.carried) {
                    Row {
                        turn.allImages.take(5).forEach { img ->
                            JpegThumb(
                                jpegB64 = img,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(88.dp)
                                    .padding(end = 4.dp),
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Text(
                    turn.text,
                    // Larger and looser for the answer. It is a paragraph
                    // someone reads once and has to follow; the question is
                    // three words they already know.
                    style = if (turn.fromUser) MaterialTheme.typography.bodyMedium
                    else MaterialTheme.typography.bodyLarge.copy(lineHeight = 25.sp),
                    color = if (turn.fromUser) Sky.on else Ink,
                )
                if (copied) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        str.doubt.copied,
                        style = MaterialTheme.typography.labelSmall,
                        color = Mint.accent,
                    )
                }
            }
        }
    }
}




@Composable
private fun ModeRow(mode: MyAiMode, onMode: (MyAiMode) -> Unit, premium: Boolean, onPlans: () -> Unit) {
    val str = strings()
    val haptics = rememberHaptics()
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MyAiMode.entries.forEach { item ->
            val on = item == mode
            val paid = item != MyAiMode.Study
            val locked = paid && !premium
            val label = when (item) {
                MyAiMode.Study -> str.doubt.modeStudy
                MyAiMode.Friend -> str.doubt.modeFriend
                MyAiMode.Guru -> str.doubt.modeGuru
            }
            val sticker = when (item) {
                MyAiMode.Study -> Mint
                MyAiMode.Friend -> Lilac
                MyAiMode.Guru -> Butter
            }
            val art = when (item) {
                MyAiMode.Study -> TileArt.Journal
                MyAiMode.Friend -> TileArt.Person
                MyAiMode.Guru -> TileArt.Medal
            }

            // The fill floods in from the left rather than switching on, and
            // the chip swells past its size and settles back. Three flat
            // rectangles changing colour told you which was selected and
            // nothing else; this makes the tap feel like it did something,
            // which is the whole reason anyone presses it twice.
            val flood by animateFloatAsState(
                targetValue = if (on) 1f else 0f,
                animationSpec = Motion.settle(),
                label = "flood",
            )
            val swell by animateFloatAsState(
                targetValue = if (on) 1f else 0.96f,
                animationSpec = Motion.bouncy(),
                label = "swell",
            )
            val shape = RoundedCornerShape(20.dp)

            Box(
                Modifier
                    .scale(swell)
                    .clip(shape)
                    .background(CreamCard)
                    .drawBehind {
                        if (flood <= 0.01f) return@drawBehind
                        // A rising level, not a fade. Drawn from the bottom up
                        // so it reads as the chip filling rather than lighting.
                        val h = size.height * flood
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    sticker.fill.copy(alpha = 0.85f),
                                    sticker.fill,
                                ),
                                startY = size.height - h,
                                endY = size.height,
                            ),
                            topLeft = Offset(0f, size.height - h),
                            size = Size(size.width, h),
                        )
                    }
                    .border(if (on) Paper.Outline else 1.5.dp, Ink, shape)
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        when {
                            locked -> { onPlans() }
                            !on -> { onMode(item) }
                        }
                    }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                TileObject(art = art, fill = if (on) sticker.fill else InkLow, size = 18.dp)
                Spacer(Modifier.width(6.dp))
                Text(
                    if (locked) "$label  ·  ${str.doubt.proTag}" else label,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (on) Ink else Ink.copy(alpha = if (locked) 0.45f else 1f),
                )
                }
            }
        }
    }
}

@Composable
private fun PulseCard(pulse: StudyPulse) {
    val str = strings()
    Aura(color = GoldNeon, strength = 0.42f, modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(16.dp),
        ) {
            Text(
                str.doubt.pulseLabel,
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(4.dp))
            Text(pulse.headline, style = MaterialTheme.typography.titleMedium, color = Ink)
            Spacer(Modifier.height(8.dp))
            pulse.lines.forEach { line ->
                Text(line, style = MaterialTheme.typography.bodyMedium, color = InkMid)
            }
            Spacer(Modifier.height(10.dp))
            Text(pulse.next, style = MaterialTheme.typography.bodyMedium, color = Ink)
        }
    }
}
