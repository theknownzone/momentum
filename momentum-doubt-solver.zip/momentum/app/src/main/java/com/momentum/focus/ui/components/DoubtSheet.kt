package com.momentum.focus.ui.components

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.PictureAsPdf
import android.net.Uri
import com.momentum.focus.ai.Attach
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.momentum.focus.ai.Ai
import com.momentum.focus.ai.Doubt
import com.momentum.focus.ai.DoubtState
import com.momentum.focus.ai.MyAiMode
import com.momentum.focus.ai.StudyPulse
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.ExportChat
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Rounded at the top only. The bottom edge is the bottom of the screen. */
private val SheetShape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)

/**
 * How much of the input glow is on when nothing is happening.
 *
 * Not zero: the ring is part of how the composer looks, and a box that only
 * glows while an answer is being written shows the effect for a few seconds at
 * the exact moment the reader is watching the reply instead.
 */
private const val REST = 0.42f

/**
 * The one place in this app where a person types at a model.
 *
 * Everything that could make it a hiding place is on screen rather than in a
 * comment: the questions left, the clock still running, and an answer that
 * ends instead of inviting another. Closing the sheet does not cancel a
 * request in flight — the answer will be waiting when it is reopened — because
 * a request that has already been paid for should not have to be paid for
 * twice.
 */
@Composable
fun DoubtSheet(
    state: DoubtState,
    /** The live countdown, or null when no session is running. */
    clock: String?,
    onAsk: (String, String?) -> Unit,
    onRetry: () -> Unit,
    onStop: () -> Unit,
    onClose: () -> Unit,
    mode: MyAiMode = MyAiMode.Study,
    onMode: (MyAiMode) -> Unit = {},
    pulse: StudyPulse? = null,
    embedded: Boolean = false,
    premium: Boolean = false,
    onPlans: () -> Unit = {},
    /** Null hides the drill entirely, same as a build with no key. */
    onMock: ((String?) -> Unit)? = null,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val context = LocalContext.current
    var text by rememberSaveable { mutableStateOf("") }
    var pendingJpeg by remember { mutableStateOf<String?>(null) }
    var pendingLabel by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()
    val spent = state.left <= 0
    val modeLabel = when (mode) {
        MyAiMode.Study -> str.doubt.modeStudy
        MyAiMode.Friend -> str.doubt.modeFriend
        MyAiMode.Guru -> str.doubt.modeGuru
    }

    // Decoding a photo or rendering a PDF page allocates megabytes and touches
    // disk. Run inline on the picker callback — which is the main thread — it
    // froze the composer for as long as the work took, and on a big photo that
    // is long enough to be an ANR rather than a stutter.
    val scope = rememberCoroutineScope()
    fun ingest(uri: Uri?) {
        if (uri == null) return
        pendingLabel = str.doubt.attaching
        scope.launch {
            withContext(Dispatchers.IO) { runCatching { Attach.fromUri(context, uri) } }
                .onSuccess {
                    pendingJpeg = it.jpegB64
                    pendingLabel = it.label
                    haptics.confirm()
                }
                .onFailure {
                    pendingJpeg = null
                    pendingLabel = it.message ?: str.doubt.attachFailed
                    haptics.reject()
                }
        }
    }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { ingest(it) }
    val pickPdf = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { ingest(it) }

    BackHandler { onClose() }

    // Two rules, because one scroll was doing two jobs badly.
    //
    // It followed every change, so scrolling back to re-read something was
    // undone the moment an answer landed. Now it only follows if you were
    // already down at the newest part.
    //
    // And it scrolled to the very end, which for a long answer means the list
    // stops with the last line against the bottom and the first line pushed off
    // the top — the answer arrives already half buried. An answer is scrolled
    // to its own start instead, so it is read from the first word.
    LaunchedEffect(state.thread.size, state.busy, state.error) {
        if (state.thread.isEmpty()) return@LaunchedEffect
        val last = state.thread.lastIndex
        val following = listState.firstVisibleItemIndex >= last - 2
        if (!following) return@LaunchedEffect
        val target = if (state.thread[last].fromUser) state.thread.size else last
        listState.animateScrollToItem(target)
    }

    fun submit() {
        val question = text.trim()
        if ((question.isBlank() && pendingJpeg == null) || state.busy || spent) return
        haptics.confirm()
        onAsk(question, pendingJpeg)
        text = ""
        pendingJpeg = null
        pendingLabel = null
    }

    // Embedded, this paints nothing of its own. It used to carry an opaque
    // Cream fill across fillMaxSize, which sat on top of the ghost word and
    // the gold aura the MyAi screen draws underneath — both were being
    // rendered and then covered, which is why neither had ever been seen. The
    // screen owns the paper now; the panel is just the layout on it.
    // Remembered out here rather than inside the branch: a remember() reached
    // only on one side of an if is a slot that moves if the condition ever
    // changes.
    val panelTaps = remember { MutableInteractionSource() }
    val panel = Modifier
        .fillMaxWidth()
        .then(
            if (embedded) {
                Modifier.fillMaxSize()
            } else {
                Modifier
                    .fillMaxHeight(0.88f)
                    .clip(SheetShape)
                    .border(Paper.Outline, Ink, SheetShape)
                    .background(Cream)
                    // Swallows taps so they do not reach the scrim's closer
                    // behind the sheet. Only the modal needs it; embedded there
                    // is no scrim to fall through to.
                    .clickableNoRipple(panelTaps) { }
                    .paperGrain()
            },
        )
        .padding(horizontal = 16.dp)
        .padding(top = 14.dp, bottom = 12.dp)

    @Composable
    fun Panel() {
            Column(panel) {
                // Embedded there is no title and no close button — the tab bar
                // is the way out — so the header row is skipped rather than
                // laid out empty. It was costing a spacer's worth of height
                // above the counts for nothing.
                if (!embedded) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            str.doubt.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = InkMid,
                        )
                        Text(
                            str.doubt.title,
                            style = MaterialTheme.typography.headlineSmall,
                            color = Ink,
                        )
                    }
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick(); onClose()
                            }
                            .padding(6.dp),
                    ) {
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = str.doubt.close,
                            tint = Ink,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                }

                // The price, always visible. A limit nobody can see is not a
                // limit, it is a surprise waiting to happen.
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        str.doubt.left(state.left),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (spent) Tang.accent else InkMid,
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        clock?.let { str.doubt.clockRunning(it) } ?: str.doubt.clockPaused,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (clock != null) Tang.accent else InkMid,
                    )
                    Spacer(Modifier.weight(1f))
                    // Only once there is something to send. An export button
                    // above an empty thread is a control that can only
                    // disappoint.
                    if (state.thread.isNotEmpty()) {
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    haptics.tick()
                                    ExportChat.share(
                                        context = context,
                                        thread = state.thread,
                                        mode = modeLabel,
                                        you = str.doubt.exportYou,
                                        ai = str.doubt.exportAi,
                                    )
                                }
                                .padding(4.dp),
                        ) {
                            Icon(
                                Icons.Filled.IosShare,
                                contentDescription = str.doubt.export,
                                tint = InkMid,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ModeRow(mode = mode, onMode = onMode, premium = premium, onPlans = onPlans)
                    Spacer(Modifier.weight(1f))
                    // Sits beside the modes because it is the same thing seen
                    // from the other side: modes are asking, this is being
                    // asked. It costs one of the session's questions, which is
                    // why it is not free to keep re-rolling.
                    if (onMock != null) {
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(Butter.fill)
                                .border(1.5.dp, Ink, RoundedCornerShape(20.dp))
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    haptics.tick()
                                    // Free taps go to Plans rather than to a
                                    // request that the ViewModel would refuse
                                    // in silence.
                                    if (premium) onMock(pendingJpeg) else onPlans()
                                }
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                        ) {
                            Text(
                                if (premium) str.mock.label
                                else "${str.mock.label} · ${str.doubt.proTag}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Butter.on,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))

                Box(Modifier.weight(1f)) {
                    if (state.thread.isEmpty()) {
                        EmptyThread(onPick = { text = it }, pulse = pulse)
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            items(state.thread) { turn -> Bubble(turn) }
                            item {
                                Status(
                                    state = state,
                                    onRetry = { haptics.press(); onRetry() },
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                Column(Modifier.imePadding()) {
                if (spent) {
                    // The dead input box is replaced rather than disabled. A
                    // box you can tap that refuses to take a letter reads as a
                    // bug; a sentence saying why reads as a rule.
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(Paper.ChipRadius))
                            .background(Tang.fill)
                            .border(Paper.Outline, Ink, RoundedCornerShape(Paper.ChipRadius))
                            .padding(14.dp),
                    ) {
                        Text(
                            str.doubt.noneLeftTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = Tang.on,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            str.doubt.noneLeftBody,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Tang.on,
                        )
                    }
                } else {
                    if (pendingLabel != null) {
                        Text(
                            pendingLabel!!,
                            style = MaterialTheme.typography.labelSmall,
                            color = Mint.accent,
                            modifier = Modifier.padding(bottom = 6.dp),
                        )
                    }
                    Row(verticalAlignment = Alignment.Bottom) {
                        Locked(
                            locked = !premium,
                            modifier = Modifier.clickableNoRipple(remember { MutableInteractionSource() }) {
                                if (!premium) onPlans()
                            },
                            label = "PRO",
                        ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(Paper.ChipRadius))
                                    .background(CreamCard)
                                    .border(2.dp, Ink, RoundedCornerShape(Paper.ChipRadius))
                                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                                        if (!premium) onPlans() else { haptics.tick(); pickImage.launch("image/*") }
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Filled.AddPhotoAlternate, contentDescription = str.doubt.photo, tint = Ink, modifier = Modifier.size(20.dp))
                            }
                            Spacer(Modifier.height(6.dp))
                            Box(
                                Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(Paper.ChipRadius))
                                    .background(CreamCard)
                                    .border(2.dp, Ink, RoundedCornerShape(Paper.ChipRadius))
                                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                                        if (!premium) onPlans() else { haptics.tick(); pickPdf.launch("application/pdf") }
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Filled.PictureAsPdf, contentDescription = str.doubt.pdf, tint = Ink, modifier = Modifier.size(20.dp))
                            }
                        }
                        }
                        Spacer(Modifier.width(8.dp))
                        // Tied back to busy. Hardcoded true meant the box glowed
                        // identically whether an answer was coming or not, which
                        // is the one thing the glow exists to say. The resting
                        // state keeps a faint ring so the look survives; busy is
                        // what makes it move.
                        GlowBox(glowing = state.busy, modifier = Modifier.weight(1f)) {
                            BasicTextField(
                                value = text,
                                onValueChange = { text = it.take(Doubt.MAX_CHARS) },
                                enabled = !state.busy,
                                textStyle = MaterialTheme.typography.bodyLarge.copy(color = Ink),
                                cursorBrush = SolidColor(LocalSkin.current.accent),
                                maxLines = 4,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                keyboardActions = KeyboardActions(onSend = { submit() }),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                // One subtree, not two siblings: the decoration
                                // is placed straight into the field's layout,
                                // and a bare hint next to the field would be
                                // laid out beside it rather than under it.
                                decorationBox = { field ->
                                    Box {
                                        if (text.isEmpty()) {
                                            Text(
                                                str.doubt.hint,
                                                style = MaterialTheme.typography.bodyLarge,
                                                color = InkLow,
                                            )
                                        }
                                        field()
                                    }
                                },
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        SendStop(
                            busy = state.busy,
                            enabled = text.isNotBlank() || pendingJpeg != null,
                            onSend = { submit() },
                            onStop = { haptics.reject(); onStop() },
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text(
                    str.doubt.disclaimer,
                    style = MaterialTheme.typography.labelSmall,
                    color = InkMid.copy(alpha = 0.85f),
                )
                }
            }
    }

    if (embedded) {
        Box(Modifier.fillMaxSize()) { Panel() }
    } else {
        FrostScrim {
            Box(
                Modifier
                    .fillMaxSize()
                    .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
            )
            Box(
                Modifier.fillMaxSize(),
                contentAlignment = Alignment.BottomCenter,
            ) { Panel() }
        }
    }
}

/**
 * What sits under the last question: the dots, a failure, or an offer to ask
 * it again after a stop.
 */
@Composable
private fun Status(state: DoubtState, onRetry: () -> Unit) {
    val str = strings()
    when {
        state.busy -> ThinkingDots(str.doubt.thinking)

        state.error != null -> {
            Column {
                Text(
                    state.error,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
                Spacer(Modifier.height(8.dp))
                SquishButton(str.doubt.retry, Sky, Modifier.fillMaxWidth(0.6f)) { onRetry() }
            }
        }

        state.awaitingRetry -> {
            Column {
                Text(
                    str.doubt.stopped,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                )
                Spacer(Modifier.height(8.dp))
                // Re-asks the question already on screen. Stopping an answer
                // should not cost the typing that led to it.
                SquishButton(str.doubt.retry, Sky, Modifier.fillMaxWidth(0.6f)) { onRetry() }
            }
        }
    }
}

/**
 * The empty sheet.
 *
 * The examples are tappable because the first question sets the size of every
 * one after it, and three one-line doubts teach that faster than an
 * instruction to keep it short.
 */
@Composable
private fun EmptyThread(onPick: (String) -> Unit, pulse: StudyPulse? = null) {
    val str = strings()
    val haptics = rememberHaptics()
    Column {
        pulse?.let { PulseCard(it) }
        Text(
            str.doubt.intro,
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
        )
        Spacer(Modifier.height(14.dp))
        str.doubt.examples.forEach { example ->
            Box(
                Modifier
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(Paper.ChipRadius))
                    .background(CreamCard)
                    .border(2.dp, Ink, RoundedCornerShape(Paper.ChipRadius))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.tick(); onPick(example)
                    }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
            ) {
                Text(
                    example,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Ink,
                )
            }
        }
    }
}

@Composable
private fun Bubble(turn: Ai.Turn) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (turn.fromUser) Arrangement.End else Arrangement.Start,
    ) {
        val shape = RoundedCornerShape(Paper.CardRadius)
        val accent = LocalSkin.current.accent
        Box(
            Modifier
                .fillMaxWidth(0.88f)
                .then(
                    if (!turn.fromUser) Modifier.drawBehind {
                        // Radius taken from the bubble's own corner and grown
                        // with each ring. It was a bare 18f — raw pixels, so
                        // the corners were a different shape on every screen
                        // density, and square against the bubble's rounding.
                        val radius = Paper.CardRadius.toPx()
                        listOf(5.dp to 0.35f, 11.dp to 0.16f).forEach { ring ->
                            val out = ring.first.toPx()
                            drawRoundRect(
                                color = accent.copy(alpha = ring.second),
                                topLeft = Offset(-out, -out),
                                size = Size(size.width + out * 2, size.height + out * 2),
                                cornerRadius = CornerRadius(radius + out, radius + out),
                                style = Stroke(width = 2.dp.toPx()),
                            )
                        }
                    } else Modifier
                )
                .clip(shape)
                .background(if (turn.fromUser) Sky.fill else CreamCard)
                .border(Paper.Outline, Ink, shape)
                .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            Text(
                turn.text,
                style = MaterialTheme.typography.bodyMedium,
                color = if (turn.fromUser) Sky.on else Ink,
            )
        }
    }
}

/**
 * The input box, with a glow that says an answer is being written.
 *
 * Rings of the current skin's accent stepped outward at falling alpha, not a
 * blur: blur is API 31+ and would leave every older phone looking at a plain
 * box, which is exactly the phone this app is most often installed on. The
 * outline itself stays Ink at its usual weight — vary that and the printed
 * look goes with it.
 */
@Composable
private fun GlowBox(
    glowing: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val accent = LocalSkin.current.accent
    val shape = RoundedCornerShape(Paper.ChipRadius)
    val transition = rememberInfiniteTransition(label = "glow")
    // Held as State and read inside the draw lambda rather than unwrapped
    // here. Unwrapping makes the read happen during composition, which would
    // recompose this box — and the text field inside it — on every frame the
    // pulse advances. Read in the draw phase, a frame costs three stroked
    // rectangles and nothing else.
    val pulse = transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "pulse",
    )
    // Fades in and out rather than appearing, so a fast answer does not leave
    // a flash of colour behind it.
    // A ring is always there — that is the look. What busy changes is how
    // bright and how wide it is, and whether it moves.
    //
    // Tying the whole thing to busy left the resting box bare, so the effect
    // was simply not on screen except during the few seconds an answer takes,
    // which is the one moment nobody is looking at the input box.
    val presence = animateFloatAsState(
        targetValue = if (glowing) 1f else REST,
        animationSpec = Motion.settle(),
        label = "presence",
    )

    Box(
        modifier
            .drawBehind {
                // The pulse only bites on the part above the resting floor, so
                // an idle box holds a steady ring and a busy one breathes.
                val heat = presence.value
                val strength = REST + (heat - REST) * pulse.value
                if (strength <= 0.01f) return@drawBehind
                val radius = Paper.ChipRadius.toPx()
                // Rings spread as they brighten. Fixed spreads meant the glow
                // could only get paler, never bloom, which is most of what
                // reads as "it is working" in the effect this copies.
                val bloom = 0.55f + 0.45f * strength
                // Stops at 16dp even at full bloom. The gaps either side of
                // this box are 8dp, and a wider halo is drawn over the attach
                // column and the send button rather than around the input.
                listOf(4.dp to 0.78f, 9.dp to 0.46f, 16.dp to 0.24f).forEach { ring ->
                    val out = ring.first.toPx() * bloom
                    drawRoundRect(
                        color = accent.copy(alpha = ring.second * strength),
                        topLeft = Offset(-out, -out),
                        size = Size(size.width + out * 2, size.height + out * 2),
                        cornerRadius = CornerRadius(radius + out, radius + out),
                        style = Stroke(width = 2.dp.toPx()),
                    )
                }
            }
            .clip(shape)
            .background(CreamCard)
            .border(Paper.Outline, Ink, shape),
    ) {
        content()
    }
}

/**
 * Send, until there is something to stop.
 *
 * One button rather than two, in the same square, because a stop control that
 * appears somewhere else is one the thumb has to go looking for while it is
 * already resting here.
 */
@Composable
private fun SendStop(
    busy: Boolean,
    enabled: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val live = busy || enabled
    val scale by animateFloatAsState(
        targetValue = if (busy) 1.04f else 1f,
        animationSpec = Motion.bouncy(),
        label = "scale",
    )
    val shape = RoundedCornerShape(Paper.ChipRadius)
    val sticker = if (busy) Tang else Mint
    // Named on the button rather than on what is inside it, because what is
    // inside it changes and a drawn square has nothing to announce itself as.
    val spoken = if (busy) str.doubt.stop else str.doubt.send

    Box(
        Modifier
            .scale(scale)
            .size(52.dp)
            .alpha(if (live) 1f else 0.45f)
            .clip(shape)
            .background(sticker.fill)
            .border(Paper.Outline, Ink, shape)
            .clickableNoRipple(remember { MutableInteractionSource() }, enabled = live) {
                if (busy) onStop() else { haptics.tick(); onSend() }
            }
            .semantics { contentDescription = spoken },
        contentAlignment = Alignment.Center,
    ) {
        if (busy) {
            // A square, drawn rather than iconified: it is two shapes on a
            // page and reads as stop everywhere in the world.
            Spacer(
                Modifier
                    .size(16.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Ink),
            )
        } else {
            Icon(
                Icons.Filled.Send,
                contentDescription = null,
                tint = sticker.on,
                modifier = Modifier.size(22.dp),
            )
        }
    }
}


@Composable
private fun ModeRow(mode: MyAiMode, onMode: (MyAiMode) -> Unit, premium: Boolean, onPlans: () -> Unit) {
    val str = strings()
    val haptics = rememberHaptics()
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MyAiMode.entries.forEach { item ->
            val on = item == mode
            val paid = item != MyAiMode.Study
            val locked = paid && !premium
            val label = when (item) {
                MyAiMode.Study -> str.doubt.modeStudy
                MyAiMode.Friend -> str.doubt.modeFriend
                MyAiMode.Guru -> str.doubt.modeGuru
            }
            val fill = when {
                on && item == MyAiMode.Guru -> Butter.fill
                on -> Mint.fill
                else -> CreamCard
            }
            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(fill)
                    .border(if (on) Paper.Outline else 1.5.dp, Ink, RoundedCornerShape(20.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        when {
                            locked -> { haptics.tick(); onPlans() }
                            !on -> { haptics.tick(); onMode(item) }
                        }
                    }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) {
                Text(
                    if (locked) "$label  ·  ${str.doubt.proTag}" else label,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (on) Ink else Ink.copy(alpha = if (locked) 0.45f else 1f),
                )
            }
        }
    }
}

@Composable
private fun PulseCard(pulse: StudyPulse) {
    val str = strings()
    Aura(color = GoldNeon, strength = 0.42f, modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(CreamCard)
                .border(Paper.Outline, Ink, RoundedCornerShape(Paper.CardRadius))
                .padding(16.dp),
        ) {
            Text(
                str.doubt.pulseLabel,
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(4.dp))
            Text(pulse.headline, style = MaterialTheme.typography.titleMedium, color = Ink)
            Spacer(Modifier.height(8.dp))
            pulse.lines.forEach { line ->
                Text(line, style = MaterialTheme.typography.bodyMedium, color = InkMid)
            }
            Spacer(Modifier.height(10.dp))
            Text(pulse.next, style = MaterialTheme.typography.bodyMedium, color = Ink)
        }
    }
}
