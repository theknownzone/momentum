package com.momentum.focus.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

/**
 * Exam notifications from across India, pulled from the repo.
 *
 * An item is either a standing link to an official notice board or a dated
 * announcement — a form date, an admit card, a result, a postponement. Only
 * the second kind sets [ExamNewsItem.alert] and is allowed to interrupt. The bundled copy in assets is what a fresh install reads, and
 * the remote copy is what keeps it current — same arrangement the cards and
 * the exam catalogue already use, so publishing an alert is editing one JSON
 * file rather than shipping a build.
 *
 * The app never invents an item. Everything shown here is something written
 * into that file with a source, because a wrong date on an exam alert is worse
 * than no alert at all.
 */
data class ExamNewsItem(
    val id: String,
    val title: String,
    val body: String,
    val exam: String,
    val region: String,
    val date: String,
    val url: String,
    /**
     * Whether this item may interrupt with a popup.
     *
     * Most of the feed is standing links to official notice boards, which are
     * true every day of the year and are not news. Those belong in the card,
     * where they can be browsed, and nowhere else — a portal link that arrives
     * as an alert teaches people to dismiss alerts. Only a dated announcement
     * with a deadline attached should be allowed to take over the screen.
     */
    val alert: Boolean = false,
) {
    /**
     * True when this item is about the exam the user is actually preparing for.
     *
     * Matching is on whole words, not substrings. "CA" reads as a substring of
     * "CAT" and "cat" of "CA Intermediate", so a substring test quietly serves
     * chartered-accountancy notices to MBA candidates and the other way round.
     * Splitting both sides into words and asking whether ours are all present
     * lets a family key like "SSC" still cover "SSC CGL" without that risk.
     */
    fun matches(examName: String?): Boolean {
        // A blank exam means the item is genuinely for everyone.
        //
        // "Sarkari" is one of these. It is not an exam — it is the bucket the
        // aggregator feeds put every government job and recruitment notice
        // into, and this filter was reading it as a specific exam nobody had
        // chosen. So `["cbse"].containsAll(["sarkari"])` came back false and
        // every single scraped notice was dropped before it reached the
        // screen: four hundred lines arriving in the repo every morning, and
        // the app showing the two hand-written board entries.
        if (
            exam.isBlank() ||
            exam.equals("All", true) ||
            exam.equals("Sarkari", true)
        ) {
            return true
        }
        val theirs = examName.orEmpty().lowercase().split(WORDS).filter { it.isNotBlank() }
        // Nothing chosen yet, so there is nothing to filter against. Showing
        // the whole board beats showing an empty one.
        if (theirs.isEmpty()) return true
        val ours = exam.lowercase().split(WORDS).filter { it.isNotBlank() }
        return ours.isNotEmpty() && theirs.containsAll(ours)
    }

    private companion object {
        val WORDS = Regex("[^a-z0-9]+")
    }
}

object ExamNews {

    private const val REMOTE =
        "https://raw.githubusercontent.com/theknownzone/momentum/main/exam-news.json"

    private const val PREFS = "exam_news"
    private const val KEY_SEEN = "seen_ids"

    @Volatile
    private var cached: List<ExamNewsItem> = emptyList()

    fun bundled(context: Context): List<ExamNewsItem> {
        if (cached.isNotEmpty()) return cached
        val text = runCatching {
            context.assets.open("exam-news.json").bufferedReader().use { it.readText() }
        }.getOrDefault("[]")
        cached = parse(text)
        return cached
    }

    /**
     * Bundled list, replaced by the remote one when it is reachable.
     *
     * A failed fetch is not an error state here — it returns what is already
     * on the device. The app is used with the network off constantly.
     */
    suspend fun refresh(context: Context): List<ExamNewsItem> = withContext(Dispatchers.IO) {
        val local = bundled(context)
        val remote = runCatching {
            // A changing query string, and a no-cache header on top of it.
            //
            // raw.githubusercontent.com sits behind a CDN that will happily
            // serve a copy from five minutes ago — which on a feed updated
            // once a day is usually fine and occasionally means someone stares
            // at yesterday's notices right after they were replaced. The
            // parameter is ignored by the server and only exists to make the
            // URL unique per hour.
            val bust = System.currentTimeMillis() / 3_600_000L
            val conn = (URL("$REMOTE?t=$bust").openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
                setRequestProperty("Cache-Control", "no-cache")
            }
            if (conn.responseCode != 200) return@runCatching null
            parse(conn.inputStream.bufferedReader().use { it.readText() })
        }.getOrNull()
        if (!remote.isNullOrEmpty()) {
            cached = remote
            remote
        } else local
    }

    /**
     * The newest unseen item that is relevant to this user, or null.
     *
     * Relevance is checked before novelty so a UPSC alert never interrupts
     * someone studying for NEET. Everything marked All India is relevant to
     * everyone.
     */
    fun nextUnseen(
        context: Context,
        items: List<ExamNewsItem>,
        examName: String?,
    ): ExamNewsItem? {
        val seen = seenIds(context)
        return items
            .filter { it.alert && it.id !in seen && it.matches(examName) }
            .maxByOrNull { it.date }
    }

    fun relevant(
        items: List<ExamNewsItem>,
        examName: String?,
    ): List<ExamNewsItem> =
        items.filter { it.matches(examName) }.sortedByDescending { it.date }

    /**
     * How many notices this person has not opened yet.
     *
     * The seen-set already existed and nothing counted it, so a notice could
     * arrive and sit on Home with no sign that it was new. A number on the
     * bell is the whole point of having a bell — without it the icon is
     * decoration and the news only gets read by someone who happened to
     * scroll.
     *
     * Capped at nine plus, because past that the exact figure is not the
     * message; "a lot" is.
     *
     * Filtered through [unseen] rather than counting the raw list, so the
     * badge and the sheet cannot disagree. Counting unfiltered meant the bell
     * could read "6" over a sheet holding two, because the other four were
     * notices for somebody else's exam.
     */
    fun unseenCount(
        context: Context,
        items: List<ExamNewsItem>,
        examName: String?,
    ): Int = unseen(context, items, examName).size

    /**
     * The notices this person has not opened yet, newest first.
     *
     * [unseenCount] already walked this exact set and threw the items away,
     * which is why the bell could say "3" and then open onto a sheet with
     * nothing in it. Filtered by [ExamNewsItem.matches] for the same reason
     * the card is: a badge that counts notices the screen will not show is a
     * number nobody can ever clear by reading.
     */
    fun unseen(
        context: Context,
        items: List<ExamNewsItem>,
        examName: String?,
    ): List<ExamNewsItem> {
        if (items.isEmpty()) return emptyList()
        val seen = seenIds(context)
        return items
            .filter { it.id !in seen && it.matches(examName) }
            .sortedByDescending { it.date }
    }

    /** Everything currently shown, marked read in one go. */
    fun markAllSeen(context: Context, items: List<ExamNewsItem>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val seen = prefs.getStringSet(KEY_SEEN, emptySet()).orEmpty().toMutableSet()
        seen += items.map { it.id }
        prefs.edit().putStringSet(KEY_SEEN, seen.toList().takeLast(200).toSet()).apply()
    }

    fun markSeen(context: Context, id: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val seen = prefs.getStringSet(KEY_SEEN, emptySet()).orEmpty().toMutableSet()
        seen += id
        // Trimmed so the set cannot grow without bound on a long-lived install.
        val kept = seen.toList().takeLast(200).toSet()
        prefs.edit().putStringSet(KEY_SEEN, kept).apply()
    }

    private fun seenIds(context: Context): Set<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_SEEN, emptySet()).orEmpty()

    private fun parse(text: String): List<ExamNewsItem> = runCatching {
        val arr = JSONArray(text)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ExamNewsItem(
                id = o.optString("id"),
                title = o.optString("title"),
                body = o.optString("body"),
                exam = o.optString("exam"),
                region = o.optString("region", "All India"),
                date = o.optString("date"),
                url = o.optString("url"),
                alert = o.optBoolean("alert", false),
            )
        }.filter { it.id.isNotBlank() && it.title.isNotBlank() }
    }.getOrDefault(emptyList())
}
