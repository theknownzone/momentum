package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Paper

/** One reading: an icon, a number, its unit, and what it is. */
data class Stat(
    val icon: ImageVector,
    val value: String,
    val unit: String = "",
    val label: String,
)

/**
 * Four readings across, divided by hairlines.
 *
 * Lifted from a weather app's top strip, which does something this app was
 * doing badly: it puts four unrelated numbers side by side and still lets each
 * one be read on its own, because every column repeats the same three-part
 * shape — mark, figure, name. Momentum had the same four numbers scattered as
 * cards of different sizes down a scroll, so comparing any two meant
 * remembering the first one.
 *
 * Not dark, and not gradient-filled. What makes the original work is the
 * rhythm, not the colour; on cream the same rhythm reads as a printed table,
 * which is what this app already is.
 */
@Composable
fun StatStrip(
    stats: List<Stat>,
    modifier: Modifier = Modifier,
) {
    if (stats.isEmpty()) return
    val shape = RoundedCornerShape(Paper.CardRadius)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(CreamCard)
            .border(Paper.Outline, Ink, shape)
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        stats.forEachIndexed { i, stat ->
            Column(
                Modifier
                    .weight(1f)
                    .padding(horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(
                    stat.icon,
                    contentDescription = null,
                    tint = InkMid,
                    modifier = Modifier.size(19.dp),
                )
                Spacer(Modifier.height(7.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        stat.value,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Ink,
                        maxLines = 1,
                    )
                    if (stat.unit.isNotBlank()) {
                        Spacer(Modifier.width(2.dp))
                        Text(
                            stat.unit,
                            style = MaterialTheme.typography.labelSmall,
                            color = InkMid,
                            modifier = Modifier.padding(bottom = 3.dp),
                        )
                    }
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    stat.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = InkMid,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    // Clipped, not wrapped. A label that goes to two lines in
                    // one column and one in the next breaks the alignment that
                    // is the entire point of putting them in a row.
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (i != stats.lastIndex) {
                // A hairline, not a gap. Four numbers with only space between
                // them read as one number that has been spread out.
                Box(
                    Modifier
                        .height(38.dp)
                        .width(1.5.dp)
                        .background(Ink.copy(alpha = 0.18f)),
                )
            }
        }
    }
}
