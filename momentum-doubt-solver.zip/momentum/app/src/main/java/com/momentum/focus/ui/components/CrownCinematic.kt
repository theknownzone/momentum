package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.GoldNeon
import androidx.compose.ui.platform.LocalContext
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.SystemVoice
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Total run time.
 *
 * Ten seconds. It ran in four, which is a transition rather than a cutscene —
 * the lock had barely finished drawing before it was already breaking, and the
 * title arrived while the shards were still in the air. Everything downstream
 * is a fraction of this number, so the whole thing stretches together and the
 * beats stay in the same places relative to each other.
 *
 * Still skippable on a tap. Ten seconds is a long time to be stuck watching
 * something twice, which is why this only ever plays once.
 */
private const val RUN_MS = 10_000

/** Warm black, not pure black — the app's own paper, with the lights off. */
private val Night = Color(0xFF14110A)
private val Ember = Color(0xFFFFB020)

private const val SHARDS = 44

/**
 * The Crown cutscene. Plays once, ever.
 *
 * Deliberately not made of paper, and that is the one place in this app where
 * breaking the house style is the right call: a cutscene is allowed to look
 * like nowhere else, because it happens once and then never again. It still
 * uses the app's gold and a warm black rather than a stock neon, so it reads as
 * this app with the lights off rather than a screen borrowed from another one.
 *
 * Drawn entirely with gradients and paths. No Modifier.blur anywhere — it is
 * API 31+, and the phones this ships to are mostly older than that, so a blur
 * would mean the one moment built to impress is the one moment that quietly
 * does nothing.
 *
 * Sound: there is none, and it is not an oversight. Shipping an anime voice
 * line would mean either the system text-to-speech, which sounds like a robot
 * reading a menu, or an audio file nobody here has the rights to. The beats are
 * marked with haptics instead, which work in a library at midnight. Drop a
 * MediaPlayer call into the beat block below if you have a clip of your own.
 */
@Composable
fun CrownCinematic(onDone: () -> Unit) {
    val str = strings()
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val progress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        // Warmed here rather than at the beat: building the engine is
        // asynchronous, so asking it to speak the moment it is created loses
        // the line entirely.
        SystemVoice.init(context)
        progress.animateTo(1f, tween(RUN_MS, easing = LinearEasing))
        onDone()
    }

    // Beats. Each fires once as the playhead crosses it.
    //
    // The sounds are synthesised, not shipped — the app already builds its
    // tones from raw PCM, so a riser and a low hit cost a few lines of maths
    // instead of an audio file nobody owns the rights to. They go through
    // playOnce, which ignores the UI-sound switch (that switch is there to stop
    // fifty taps a day chirping, not to silence something that happens once
    // ever) but still obeys the physical silent switch.
    val t = progress.value
    LaunchedEffect(t > 0.03f) { if (t > 0.03f) Sfx.playOnce(Sound.RISER) }
    LaunchedEffect(t > 0.12f) { if (t > 0.12f) haptics.tick() }
    LaunchedEffect(t > 0.38f) {
        if (t > 0.38f) { Sfx.playOnce(Sound.CRACK); haptics.press() }
    }
    LaunchedEffect(t > 0.52f) {
        if (t > 0.52f) { Sfx.playOnce(Sound.BOOM); haptics.celebrate() }
    }
    LaunchedEffect(t > 0.64f) {
        if (t > 0.64f) { Sfx.playOnce(Sound.SHIMMER); haptics.festive() }
    }
    // Lands over the title, with enough of the run left for the line to
    // finish inside the cutscene rather than trailing onto the next screen.
    LaunchedEffect(t > 0.66f) { if (t > 0.66f) SystemVoice.say(str.crown.voiceLine) }

    Box(
        Modifier
            .fillMaxSize()
            .drawBehind { drawScene(t) }
            .clickableNoRipple(remember { MutableInteractionSource() }) { onDone() },
        contentAlignment = Alignment.Center,
    ) {
        // The title slams in after the lock breaks. Scale and tracking both
        // collapse inward, which is what makes it land rather than fade.
        val titleIn = ((t - 0.60f) / 0.18f).coerceIn(0f, 1f)
        val settle = 1f - (1f - titleIn) * (1f - titleIn)
        Column(
            Modifier.padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(150.dp))
            Text(
                str.crown.entered,
                fontSize = 34.sp,
                lineHeight = 40.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (0.60f - 0.42f * settle).em,
                textAlign = TextAlign.Center,
                color = GoldNeon.copy(alpha = titleIn),
                modifier = Modifier.graphicsLayer {
                    scaleX = 2.2f - 1.2f * settle
                    scaleY = 2.2f - 1.2f * settle
                },
            )
            Spacer(Modifier.height(14.dp))
            val subIn = ((t - 0.74f) / 0.16f).coerceIn(0f, 1f)
            Text(
                str.crown.subtitle,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = Color.White.copy(alpha = 0.72f * subIn),
            )
            Spacer(Modifier.height(26.dp))
            val hintIn = ((t - 0.88f) / 0.12f).coerceIn(0f, 1f)
            Text(
                str.crown.skip,
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.42f * hintIn),
            )
        }
    }
}

/**
 * The whole scene in one pass.
 *
 * Everything is derived from the playhead rather than held in state, so a
 * dropped frame skips ahead instead of falling behind — a cutscene that
 * stutters and then finishes late is worse than one that loses a frame.
 */
private fun DrawScope.drawScene(t: Float) {
    val centre = Offset(size.width / 2f, size.height * 0.42f)
    val unit = size.minDimension

    // 1. Night falls, warm at the middle so the gold has somewhere to sit.
    val dark = (t / 0.12f).coerceIn(0f, 1f)
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFF2A2411), Night),
            center = centre,
            radius = unit * 0.9f,
        ),
        alpha = dark,
    )

    // 2. A grid, the app's own paper lines, sliding in from the dark.
    val gridIn = ((t - 0.04f) / 0.16f).coerceIn(0f, 1f)
    if (gridIn > 0f) {
        val step = unit / 9f
        var x = 0f
        while (x < size.width) {
            drawLine(
                color = Ember.copy(alpha = 0.09f * gridIn),
                start = Offset(x, 0f),
                end = Offset(x, size.height),
                strokeWidth = 1.5f,
            )
            x += step
        }
        var y = 0f
        while (y < size.height) {
            drawLine(
                color = Ember.copy(alpha = 0.09f * gridIn),
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1.5f,
            )
            y += step
        }
    }

    val burst = ((t - 0.50f) / 0.08f).coerceIn(0f, 1f)

    // 3. The lock: drawn, then shaken, then gone.
    if (t < 0.58f) {
        val draw = ((t - 0.10f) / 0.22f).coerceIn(0f, 1f)
        val shake = ((t - 0.36f) / 0.14f).coerceIn(0f, 1f)
        // Jitter grows as it strains. sin of a fast phase, scaled by how far
        // into the strain we are, so it builds instead of buzzing evenly.
        val jitter = sin(t * 190f) * unit * 0.012f * shake
        val body = unit * 0.16f
        rotate(degrees = jitter * 12f, pivot = centre) {
            run {
                val left = centre.x - body + jitter
                val top = centre.y - body * 0.35f
                // Shackle.
                drawArc(
                    color = GoldNeon.copy(alpha = draw),
                    startAngle = 180f,
                    sweepAngle = 180f * draw,
                    useCenter = false,
                    topLeft = Offset(centre.x - body * 0.62f, top - body * 0.95f),
                    size = Size(body * 1.24f, body * 1.24f),
                    style = Stroke(width = unit * 0.026f),
                )
                // Body.
                drawRoundRect(
                    color = Ember.copy(alpha = 0.16f * draw),
                    topLeft = Offset(left, top),
                    size = Size(body * 2f, body * 1.5f),
                    cornerRadius = CornerRadius(unit * 0.03f, unit * 0.03f),
                )
                drawRoundRect(
                    color = GoldNeon.copy(alpha = draw),
                    topLeft = Offset(left, top),
                    size = Size(body * 2f, body * 1.5f),
                    cornerRadius = CornerRadius(unit * 0.03f, unit * 0.03f),
                    style = Stroke(width = unit * 0.022f),
                )
                // Cracks, spreading from the keyhole as the strain builds.
                if (shake > 0f) {
                    repeat(5) { i ->
                        val a = (i * 72f + 18f) * PI.toFloat() / 180f
                        val reach = body * 1.1f * shake
                        drawLine(
                            color = Color.White.copy(alpha = 0.8f * shake),
                            start = centre,
                            end = Offset(
                                centre.x + cos(a) * reach,
                                centre.y + sin(a) * reach * 0.8f,
                            ),
                            strokeWidth = unit * 0.008f,
                        )
                    }
                }
            }
        }
    }

    // 4. The break: white flash, shockwave, shards.
    if (burst > 0f) {
        val fade = 1f - burst
        drawRect(Color.White.copy(alpha = 0.55f * fade * fade))

        val wave = ((t - 0.50f) / 0.34f).coerceIn(0f, 1f)
        if (wave > 0f && wave < 1f) {
            drawCircle(
                color = GoldNeon.copy(alpha = (1f - wave) * 0.9f),
                radius = unit * 0.12f + unit * 0.85f * wave,
                center = centre,
                style = Stroke(width = unit * 0.02f * (1f - wave)),
            )
            drawCircle(
                color = Color.White.copy(alpha = (1f - wave) * 0.4f),
                radius = unit * 0.06f + unit * 0.62f * wave,
                center = centre,
                style = Stroke(width = unit * 0.01f * (1f - wave)),
            )
        }

        val fly = ((t - 0.50f) / 0.40f).coerceIn(0f, 1f)
        repeat(SHARDS) { i ->
            // Golden angle, so the shards spread evenly without a random
            // source and look the same on every run.
            val a = i * 2.39996f
            val speed = 0.55f + ((i * 37) % 100) / 100f * 0.75f
            val dist = unit * 0.9f * fly * speed
            val px = centre.x + cos(a) * dist
            val py = centre.y + sin(a) * dist + unit * 0.55f * fly * fly
            val len = unit * (0.02f + ((i * 17) % 30) / 1000f)
            rotate(degrees = a * 57f + fly * 320f, pivot = Offset(px, py)) {
                drawRect(
                    color = GoldNeon.copy(alpha = (1f - fly) * 0.95f),
                    topLeft = Offset(px - len / 2f, py - len / 6f),
                    size = Size(len, len / 3f),
                )
            }
        }
    }

    // 5. Rays turning behind the title, and the crown itself.
    val rays = ((t - 0.56f) / 0.24f).coerceIn(0f, 1f)
    if (rays > 0f) {
        rotate(degrees = t * 90f, pivot = centre) {
            repeat(12) { i ->
                val a = i * 30f * PI.toFloat() / 180f
                val inner = unit * 0.18f
                val outer = inner + unit * 0.75f * rays
                drawLine(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            GoldNeon.copy(alpha = 0.30f * rays),
                            Color.Transparent,
                        ),
                        start = Offset(centre.x + cos(a) * inner, centre.y + sin(a) * inner),
                        end = Offset(centre.x + cos(a) * outer, centre.y + sin(a) * outer),
                    ),
                    start = Offset(centre.x + cos(a) * inner, centre.y + sin(a) * inner),
                    end = Offset(centre.x + cos(a) * outer, centre.y + sin(a) * outer),
                    strokeWidth = unit * 0.03f,
                )
            }
        }
        drawCrown(centre, unit * 0.20f, rays)
    }
}

/** Five points, drawn as one path so the outline stays a single stroke. */
private fun DrawScope.drawCrown(centre: Offset, w: Float, alpha: Float) {
    val h = w * 0.72f
    val left = centre.x - w
    val base = centre.y + h * 0.45f
    val top = centre.y - h * 0.55f
    val path = Path().apply {
        moveTo(left, base)
        lineTo(left, top + h * 0.30f)
        lineTo(left + w * 0.5f, top + h * 0.62f)
        lineTo(centre.x, top)
        lineTo(left + w * 1.5f, top + h * 0.62f)
        lineTo(left + w * 2f, top + h * 0.30f)
        lineTo(left + w * 2f, base)
        close()
    }
    drawPath(path, color = Ember.copy(alpha = 0.22f * alpha))
    drawPath(
        path,
        color = GoldNeon.copy(alpha = alpha),
        style = Stroke(width = w * 0.10f),
    )
}
