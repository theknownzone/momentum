package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Ink

/**
 * The app's crown, drawn rather than typed.
 *
 * It replaces a 👑 emoji, which rendered as a different picture on every phone
 * — flat on one, glossy on another, a completely different silhouette on a
 * third — and never matched a cut-paper app on any of them. This one is the
 * same shape everywhere.
 *
 * The depth comes from three flat passes: a hard offset shadow, a vertical
 * gradient from a pale top to a deep base, and a highlight band across the
 * upper third. No blur anywhere — it is API 31+, and the house rule is offset
 * shadows precisely because they survive on the phones this ships to.
 */
@Composable
fun CrownMark(size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) { drawCrownMark() }
}

private fun DrawScope.drawCrownMark() {
    val w = size.width
    val h = size.height
    val depth = w * 0.09f

    fun crown(inset: Float): Path = Path().apply {
        val l = inset
        val r = w - inset
        val base = h * 0.86f - inset
        val top = h * 0.16f + inset
        val mid = h * 0.46f
        moveTo(l, base)
        lineTo(l, top + h * 0.10f)
        lineTo(l + (r - l) * 0.28f, mid)
        lineTo(l + (r - l) * 0.5f, top)
        lineTo(l + (r - l) * 0.72f, mid)
        lineTo(r, top + h * 0.10f)
        lineTo(r, base)
        close()
    }

    val body = crown(w * 0.06f)

    // 1. The shadow, offset down and right. Hard edged, like a paper cutout
    //    lifted off the page.
    translate(left = depth, top = depth) {
        drawPath(body, color = Ink.copy(alpha = 0.55f))
    }

    // 2. The metal. Pale at the crown, deep at the base — the whole reason it
    //    reads as an object rather than a symbol.
    drawPath(
        body,
        brush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFFFFF0B0),
                GoldNeon,
                Color(0xFFC98A12),
            ),
            startY = 0f,
            endY = h,
        ),
    )

    // 3. A highlight across the upper third, where light would catch.
    drawPath(
        body,
        brush = Brush.verticalGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.55f),
                Color.Transparent,
            ),
            startY = h * 0.10f,
            endY = h * 0.46f,
        ),
    )

    // 4. The outline, the same weight everything else in this app carries.
    drawPath(body, color = Ink, style = Stroke(width = w * 0.09f))

    // Three studs along the band, dark then light, so each one has a side.
    val studY = h * 0.70f
    listOf(0.26f, 0.5f, 0.74f).forEach { x ->
        drawCircle(
            color = Color(0xFF8A5B08),
            radius = w * 0.055f,
            center = Offset(w * x, studY),
        )
        drawCircle(
            color = Color(0xFFFFF3C4),
            radius = w * 0.028f,
            center = Offset(w * x - w * 0.012f, studY - h * 0.012f),
        )
    }
}
