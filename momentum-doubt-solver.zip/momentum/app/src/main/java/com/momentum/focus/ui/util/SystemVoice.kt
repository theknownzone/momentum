package com.momentum.focus.ui.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * The announcement over the Crown cutscene.
 *
 * Built on the device's own text-to-speech rather than a recorded clip. That
 * was first rejected here for sounding synthetic, which was the wrong call: the
 * thing being imitated is a *system* announcing itself, and a synthetic voice is
 * what that is. Pitched down and slowed, over a low hit, it reads as the
 * machine talking rather than as a person failing to.
 *
 * It also means no audio file to license, nothing added to the APK, and a line
 * that can be changed by editing a string.
 *
 * Everything about this degrades quietly. Plenty of phones ship with a broken
 * or absent engine, and some have no English voice data at all; on those this
 * simply says nothing and the cutscene plays with its music and haptics. A
 * silent line is a missing flourish, not a broken feature.
 */
object SystemVoice {

    private var tts: TextToSpeech? = null
    private var ready = false
    private var audioManager: AudioManager? = null

    /**
     * Warms the engine up.
     *
     * Called early because construction is asynchronous — ask it to speak in
     * the same breath as creating it and the line is dropped. The cutscene
     * needs it roughly two seconds in, so a moment's head start is plenty.
     */
    fun init(context: Context) {
        if (tts != null) return
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        runCatching {
            tts = TextToSpeech(context.applicationContext) { status ->
                val engine = tts ?: return@TextToSpeech
                if (status != TextToSpeech.SUCCESS) return@TextToSpeech
                val result = runCatching { engine.setLanguage(Locale.US) }.getOrNull()
                // MISSING_DATA and NOT_SUPPORTED both mean there is no voice to
                // speak with. Speaking anyway produces silence on some engines
                // and gibberish on others.
                if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    return@TextToSpeech
                }
                runCatching {
                    // Below one is heavier. Slower than normal so it lands like
                    // a announcement rather than a notification being read out.
                    engine.setPitch(0.72f)
                    engine.setSpeechRate(0.86f)
                    engine.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build(),
                    )
                }
                ready = true
            }
        }
    }

    /**
     * Says one line, if it can.
     *
     * Obeys the physical silent switch, like every other sound in the app. A
     * phone on silent is a phone in a room where a voice is not wanted.
     */
    fun say(line: String) {
        if (!ready) return
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        runCatching {
            tts?.speak(line, TextToSpeech.QUEUE_FLUSH, null, "crown")
        }
    }

    fun release() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
        ready = false
    }
}
