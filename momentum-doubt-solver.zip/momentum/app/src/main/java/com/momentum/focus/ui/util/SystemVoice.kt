package com.momentum.focus.ui.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * The announcement over the Crown cutscene.
 *
 * Built on the device's own text-to-speech rather than a recorded clip. That
 * was first rejected here for sounding synthetic, which was the wrong call: the
 * thing being imitated is a *system* announcing itself, and a synthetic voice
 * is what that is. Pitched down and slowed, over a low hit, it reads as the
 * machine talking rather than as a person failing to.
 *
 * Two things have to be right for a word to come out, and both have bitten:
 *  - TTS_SERVICE must be declared in the manifest's queries block. Without it,
 *    package visibility on Android 11 and up hides the engine, the bind fails
 *    before anything is spoken, and nothing obvious appears in the log.
 *  - Nothing may touch the engine from inside the init callback. That callback
 *    can arrive before the constructor has returned, so the field it would read
 *    is still null. Configuration happens on the first say() instead, by which
 *    point the field is certainly set.
 *
 * Everything degrades quietly. A phone with no English voice data says nothing
 * and the cutscene runs on its music and haptics — a missing flourish, not a
 * broken feature.
 */
object SystemVoice {

    private var engine: TextToSpeech? = null

    /** Set by the init callback, which writes nothing else. */
    @Volatile
    private var initOk = false

    private var configured = false
    private var audioManager: AudioManager? = null

    /**
     * Warms the engine up.
     *
     * Called ahead of the beat that needs it because construction is
     * asynchronous — ask it to speak in the same breath as creating it and the
     * line is dropped.
     */
    fun init(context: Context) {
        if (engine != null) return
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        runCatching {
            engine = TextToSpeech(context.applicationContext) { status ->
                initOk = status == TextToSpeech.SUCCESS
            }
        }
    }

    /**
     * Says one line, if it can.
     *
     * Obeys the physical silent switch, like every other sound in the app. A
     * phone on silent is a phone in a room where a voice is not wanted.
     */
    fun say(line: String) {
        if (!initOk) return
        val tts = engine ?: return
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return

        if (!configured) {
            val language = runCatching { tts.setLanguage(Locale.US) }.getOrNull()
            // Both of these mean there is no voice to speak with. Speaking
            // anyway is silence on some engines and nonsense on others.
            if (language == TextToSpeech.LANG_MISSING_DATA ||
                language == TextToSpeech.LANG_NOT_SUPPORTED
            ) {
                initOk = false
                return
            }
            runCatching {
                // Below one is heavier. Slower than normal so it lands as an
                // announcement rather than a notification being read out.
                tts.setPitch(0.72f)
                tts.setSpeechRate(0.86f)
                tts.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                )
            }
            configured = true
        }

        runCatching { tts.speak(line, TextToSpeech.QUEUE_FLUSH, null, "crown") }
    }

    fun release() {
        runCatching {
            engine?.stop()
            engine?.shutdown()
        }
        engine = null
        initOk = false
        configured = false
    }
}
