package com.momentum.focus.ui.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import com.momentum.focus.R

/**
 * The line spoken over the Crown cutscene.
 *
 * A recorded clip, not the device's speech engine. Text-to-speech was the right
 * call while there was no audio to ship — it gave a synthetic system voice,
 * which suits a system announcing itself — but a real take beats it on every
 * axis: it sounds the same on every phone, needs no engine, no package
 * visibility entry, no language data, and cannot be silently unavailable.
 *
 * Roughly two seconds, mono, 24kHz. Small enough that the APK does not notice.
 */
object SystemVoice {

    private var player: MediaPlayer? = null
    private var audioManager: AudioManager? = null

    /**
     * Loads the clip.
     *
     * Prepared ahead of the beat that needs it, because decoding on the beat
     * would put the line a moment late — and late, over a cutscene, is worse
     * than absent.
     */
    fun init(context: Context) {
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (player != null) return
        runCatching {
            player = MediaPlayer.create(
                context.applicationContext,
                R.raw.welcome_crown_mode_rex,
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
                0,
            )
        }
    }

    /**
     * Plays it, if the room allows.
     *
     * Obeys the physical silent switch like every other sound here. The [line]
     * argument is ignored — the clip says what it says — but it is kept so the
     * call site still names what is being spoken, and so a future second clip
     * has somewhere obvious to hang.
     */
    @Suppress("UNUSED_PARAMETER")
    fun say(line: String) {
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val p = player ?: return
        runCatching {
            if (p.isPlaying) {
                p.pause()
                p.seekTo(0)
            }
            p.start()
        }
    }

    fun release() {
        runCatching {
            player?.stop()
            player?.release()
        }
        player = null
    }
}
