package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.LocalSkin
import kotlin.math.abs

/** Lightweight Zomato-inspired AI search state: a small sparkle plus a
 * directional halftone field, not a giant orb and not one animation per dot. */
@Composable
fun ScanPulse(label: String, modifier: Modifier = Modifier) {
    val accent = LocalSkin.current.accent
    val t = rememberInfiniteTransition(label = "aiSearch")
    val phase by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1900, easing = LinearEasing)), label = "phase")
    val breathe by t.animateFloat(0.82f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "breathe")
    val second = rememberInfiniteTransition(label = "aiSearchText")
    val textPhase by second.animateFloat(0f, 1f, infiniteRepeatable(tween(2200), RepeatMode.Restart), label = "textPhase")
    val caption = if (textPhase < 0.48f) label else "Hunting for the perfect answer…"

    Column(
        modifier.fillMaxWidth().padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(154.dp).drawBehind {
            val cx = size.width * 0.48f
            val cy = size.height * 0.48f
            val cell = 10.dp.toPx()
            // right-heavy halftone field, like the reference's search cloud
            for (ix in 0..8) for (iy in 0..8) {
                val dx = ix - 4f
                val dy = iy - 4f
                val d = kotlin.math.sqrt(dx * dx + dy * dy)
                val travel = phase * 7.5f
                val lit = (1f - abs(d - travel) / 1.8f).coerceIn(0f, 1f)
                if (lit > 0.02f) {
                    val alpha = lit * (0.10f + 0.18f * (1f - d / 7f))
                    drawCircle(accent.copy(alpha = alpha), 1.7f + 1.3f * lit, Offset(cx + (ix-1.5f)*cell, cy + (iy-3f)*cell))
                }
            }
            // tiny four-point sparkle at the source
            val s = 7.dp.toPx() * breathe
            val c = Offset(cx - 22.dp.toPx(), cy)
            drawLine(accent.copy(alpha=0.9f), Offset(c.x-s,c.y), Offset(c.x+s,c.y), strokeWidth=1.7f)
            drawLine(accent.copy(alpha=0.9f), Offset(c.x,c.y-s), Offset(c.x,c.y+s), strokeWidth=1.7f)
            drawCircle(accent.copy(alpha=0.95f), 2.1f, c)
        })
        Spacer(Modifier.height(2.dp))
        Text(caption, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = InkMid)
    }
}
