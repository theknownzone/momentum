package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.LocalSkin
import kotlin.math.abs
import kotlin.math.max

/** How far the grid reaches from the middle, in cells. */
private const val REACH = 4

/**
 * The wait, as a pulse going out from the middle.
 *
 * A grid of small squares arranged in a diamond, lighting up in rings that
 * travel outward from the centre and fade at the edge — a scan, not a spinner.
 * The three dots this replaces said "something is loading"; a pulse leaving the
 * middle says something is being *looked at*, which is what is actually
 * happening while a page or a question is with the model.
 *
 * Distance is measured as `abs(x) + abs(y)`, which is why the rings come out as
 * diamonds rather than circles. That is deliberate: it lands on whole cells, so
 * every square is either lit or not and nothing renders as a half-tone smudge
 * on a low-density screen.
 *
 * One infinite transition for the whole grid, read inside the draw lambda —
 * forty-one squares each animating themselves would be forty-one animations
 * where one will do.
 */
@Composable
fun ScanPulse(
    label: String,
    modifier: Modifier = Modifier,
) {
    val accent = LocalSkin.current.accent
    val transition = rememberInfiniteTransition(label = "scan")
    val wave = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing)),
        label = "wave",
    )
    // A slow breath under the wave, so the whole shape swells rather than only
    // the ring travelling through it.
    val breath = transition.animateFloat(
        initialValue = 0.86f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "breath",
    )

    Column(
        modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier
                .size(120.dp)
                .drawBehind {
                    val centre = Offset(size.width / 2f, size.height / 2f)
                    val glow = size.minDimension * (0.36f + 0.08f * breath.value)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                accent.copy(alpha = 0.18f),
                                Lilac.accent.copy(alpha = 0.10f),
                                GoldNeon.copy(alpha = 0.055f),
                                Color.Transparent,
                            ),
                            center = centre,
                            radius = glow,
                        ),
                        radius = glow,
                        center = centre,
                    )
                    val cell = size.minDimension / (REACH * 2 + 1)
                    val dot = cell * 0.34f * breath.value
                    for (x in -REACH..REACH) {
                        for (y in -REACH..REACH) {
                            val ring = abs(x) + abs(y)
                            if (ring > REACH) continue
                            // Each ring lights as the wave passes its radius.
                            val phase = (wave.value * (REACH + 2)) - ring
                            val lit = max(0f, 1f - abs(phase) / 1.6f)
                            if (lit <= 0.02f) continue
                            val fade = 1f - ring / (REACH + 1f)
                            drawRect(
                                color = accent.copy(alpha = lit * fade * 0.9f),
                                topLeft = Offset(
                                    centre.x + x * cell - dot / 2f,
                                    centre.y + y * cell - dot / 2f,
                                ),
                                size = Size(dot, dot),
                            )
                        }
                    }
                },
        )
        Spacer(Modifier.height(6.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}
