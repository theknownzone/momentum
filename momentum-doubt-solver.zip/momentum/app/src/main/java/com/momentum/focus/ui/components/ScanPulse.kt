package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Candy
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.LocalSkin
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import kotlin.math.cos
import kotlin.math.sin

/**
 * Lightweight AI thinking indicator. The reference choreography uses a small
 * dotted field that breathes and shifts colour, not a giant glowing orb. One
 * animation clock drives the whole canvas to keep CPU/GPU work predictable.
 */
@Composable
fun ScanPulse(label: String, modifier: Modifier = Modifier) {
    val accent = LocalSkin.current.accent
    val transition = rememberInfiniteTransition(label = "aiDots")
    val phase = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing)),
        label = "aiDotsPhase",
    )
    val breath = transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "aiDotsBreath",
    )

    Column(
        modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(112.dp)) {
            Canvas(Modifier.matchParentSize()) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val unit = size.minDimension / 10f
                val p = phase.value
                val b = breath.value
                val colors = listOf(accent, Sky.fill, Lilac.fill, Candy.fill, GoldNeon, Mint.fill)

                // 7x7 dotted core. Each dot has a tiny phase offset so the
                // field feels fluid without drawing rings/blur every frame.
                for (row in -3..3) {
                    for (col in -3..3) {
                        val d = kotlin.math.sqrt((row * row + col * col).toFloat())
                        val falloff = (1f - d / 5f).coerceIn(0f, 1f)
                        if (falloff <= 0f) continue
                        val local = (p + (row + col + 6) * 0.045f) % 1f
                        val pulse = 0.55f + 0.45f * sin(local * 6.2831853f)
                        val r = (1.6f + 2.0f * falloff * b * (0.72f + 0.28f * pulse))
                        val x = cx + col * unit * 0.82f
                        val y = cy + row * unit * 0.82f
                        val c = colors[((row - col + 12) % colors.size)]
                        drawCircle(c.copy(alpha = 0.22f + 0.58f * falloff), r, androidx.compose.ui.geometry.Offset(x, y))
                    }
                }

                // A small moving highlight gives the cluster the same scanning
                // character as the reference without a full-screen sweep.
                val a = p * 6.2831853f
                val hx = cx + cos(a) * unit * 2.5f
                val hy = cy + sin(a * 1.3f) * unit * 2.5f
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.78f), accent.copy(alpha = 0.30f), Color.Transparent),
                        radius = unit * 2.2f,
                    ),
                    radius = unit * 2.2f,
                    center = androidx.compose.ui.geometry.Offset(hx, hy),
                )
            }
        }
        Spacer(Modifier.height(2.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}
