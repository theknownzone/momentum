package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.LocalSkin
import com.momentum.focus.ui.theme.InkMid
import kotlin.math.cos
import kotlin.math.sin

/**
 * A continuous AI-thinking visual inspired by modern food/commerce app
 * loading choreography: a living chromatic core, liquid rings and orbiting
 * particles. It never hard-stops after a few seconds; only the amplitude
 * settles, so a slow model still looks intentional rather than broken.
 */
@Composable
fun ScanPulse(
    label: String,
    modifier: Modifier = Modifier,
) {
    val accent = LocalSkin.current.accent
    val transition = rememberInfiniteTransition(label = "aiPulse")
    val t = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing)),
        label = "aiPhase",
    )
    val breath = transition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "aiBreath",
    )
    val sweep = transition.animateFloat(
        initialValue = -1f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(tween(1900, easing = LinearEasing)),
        label = "aiSweep",
    )

    Column(
        modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier
                .size(150.dp)
                .drawBehind {
                    val c = Offset(size.width / 2f, size.height / 2f)
                    val base = size.minDimension * 0.19f * breath.value
                    val phase = t.value * 6.2831853f

                    // Broad liquid aura.
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(
                                accent.copy(alpha = 0.22f),
                                Lilac.accent.copy(alpha = 0.12f),
                                GoldNeon.copy(alpha = 0.055f),
                                Color.Transparent,
                            ),
                            center = c,
                            radius = base * 3.8f,
                        ),
                        radius = base * 3.8f,
                        center = c,
                    )

                    // Two soft expanding rings. They are deliberately not
                    // uniform circles: the changing alpha makes them feel like
                    // a fluid surface rather than a Material spinner.
                    for (ring in 0..1) {
                        val rPhase = ((t.value + ring * 0.32f) % 1f)
                        val radius = base * (1.5f + rPhase * 3.7f)
                        val alpha = (1f - rPhase) * 0.24f
                        drawCircle(
                            color = accent.copy(alpha = alpha),
                            radius = radius,
                            center = c,
                        )
                    }

                    // Chromatic sweep across the core.
                    val sx = c.x + (sweep.value - 0.5f) * size.width * 0.9f
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(Color.White.copy(alpha = 0.48f), accent.copy(alpha = 0.22f), Color.Transparent),
                            center = Offset(sx, c.y - size.height * 0.06f),
                            radius = base * 1.9f,
                        ),
                        radius = base * 1.9f,
                        center = Offset(sx, c.y - size.height * 0.06f),
                    )

                    // Small orbiting points: a visual acknowledgement that the
                    // model is doing work, without a spinner or fake percentage.
                    for (i in 0 until 5) {
                        val a = phase + i * (6.2831853f / 5f)
                        val orbit = base * (2.0f + 0.22f * sin(phase + i))
                        val p = Offset(c.x + cos(a) * orbit, c.y + sin(a) * orbit)
                        val dot = base * (0.11f + 0.04f * (1f + sin(a)) / 2f)
                        drawCircle(accent.copy(alpha = 0.42f), dot, p)
                    }

                    // Bright core + glassy inner highlight.
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(Color.White.copy(alpha = 0.92f), accent.copy(alpha = 0.78f), Lilac.fill.copy(alpha = 0.38f), Color.Transparent),
                            radius = base * 1.7f,
                        ),
                        radius = base * 1.7f,
                        center = c,
                    )
                    drawCircle(Color.White.copy(alpha = 0.78f), base * 0.16f, Offset(c.x - base * 0.25f, c.y - base * 0.30f))
                },
        )
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}
