package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Tang
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * Shown wherever the user might reach for a setting the pact will refuse.
 *
 * It ticks on its own clock. pactLive is derived from the wall clock and no
 * state changes when the lock runs out, so a banner that read the time once at
 * composition would sit there claiming to be locked long after it wasn't.
 */
@Composable
fun PactBanner(
    lockUntilEpochMs: Long,
    modifier: Modifier = Modifier,
    /**
     * Optional extras drawn inside the card, below the countdown.
     *
     * Focus puts the extend controls here. They used to sit loose on that
     * screen directly under the level chips, built from the same Chip, so
     * "+6h lock" read as a fourth level rather than as something that acts on
     * the pact. Inside the card there is no question what they belong to.
     */
    controls: (@Composable ColumnScope.() -> Unit)? = null,
) {
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(lockUntilEpochMs) {
        while (true) {
            delay(1_000)
            nowMs = System.currentTimeMillis()
        }
    }
    if (lockUntilEpochMs <= nowMs) return

    // A bare "HH:mm" was fine while a pact could only run a few hours. Now
    // that it can run days, the clock time alone would say 14:30 for a lock
    // that ends on Tuesday, so the date comes along whenever the end is not
    // today.
    val until = remember(lockUntilEpochMs, nowMs / 3_600_000L) {
        runCatching {
            val zone = ZoneId.systemDefault()
            val end = Instant.ofEpochMilli(lockUntilEpochMs).atZone(zone)
            val today = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate()
            val pattern = if (end.toLocalDate() == today) "HH:mm" else "d MMM, HH:mm"
            DateTimeFormatter.ofPattern(pattern).format(end)
        }.getOrDefault("--:--")
    }
    val leftMs = lockUntilEpochMs - nowMs
    val days = leftMs / 86_400_000L
    val h = (leftMs % 86_400_000L) / 3_600_000L
    val m = (leftMs % 3_600_000L) / 60_000L
    // "168h 0m baaki" is a number to decode, not a duration to feel.
    val left = when {
        days > 0 -> "${days}d ${h}h"
        h > 0 -> "${h}h ${m}m"
        else -> "${m.coerceAtLeast(1)} min"
    }

    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(Tang.fill)
            // Lit for as long as the pact is. This banner only exists while
            // one is running — the composable returns early otherwise — so the
            // glow here means exactly one thing: the phone is committed right
            // now and cannot be talked out of it.
            .glowEdge(active = true, shape = RoundedCornerShape(Paper.CardRadius))
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Text(
            "PACT",
            style = MaterialTheme.typography.labelSmall,
            color = Tang.on,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            "Locked until $until — only extend",
            style = MaterialTheme.typography.headlineSmall,
            color = Tang.on,
        )
        Text(
            "$left baaki · level gira nahi sakte, shield off nahi kar sakte",
            style = MaterialTheme.typography.bodyMedium,
            color = Tang.on,
        )
        controls?.invoke(this)
    }
}
