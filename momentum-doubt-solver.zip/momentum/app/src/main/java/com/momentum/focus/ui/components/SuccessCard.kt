package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.Success
import com.momentum.focus.data.SuccessPart
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Motion
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Sunk
import com.momentum.focus.ui.util.Backdrop
import com.momentum.focus.ui.util.ShareCard
import kotlinx.coroutines.launch

/**
 * The last thirty days as one number, with the number taken apart underneath.
 *
 * Drawn here rather than generated. An image model was the obvious way to make
 * this look impressive and it is the wrong tool: diffusion models cannot render
 * digits or words reliably, so the one thing this card exists to show — a real
 * streak, real minutes, a real ratio — would have come back as convincing
 * gibberish. This app's own rule is that it never shows a number it did not
 * measure, and a picture of a wrong number is still a wrong number.
 */
@Composable
fun SuccessCard(data: AppData, modifier: Modifier = Modifier) {
    val str = strings()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val score = remember(data) { Success.of(data) }
    val shape = RoundedCornerShape(Paper.CardRadius)
    var sharing by remember { mutableStateOf(false) }
    // Bumped when the cached art is thrown away, so the row re-reads the cache
    // and the "new background" chip disappears until one exists again.
    var artStamp by remember { mutableStateOf(0) }

    Aura(color = GoldNeon, strength = 0.34f, modifier = modifier) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(CreamCard)
                .border(Paper.Outline, Ink, shape)
                .padding(16.dp),
        ) {
            Text(str.success.label, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(8.dp))

            if (!score.hasData) {
                Text(
                    str.success.emptyTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = Ink,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    str.success.emptyBody,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                )
                return@Column
            }

            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    score.total.toString(),
                    style = MaterialTheme.typography.displaySmall,
                    color = Ink,
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    str.success.outOf,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMid,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
            }

            Spacer(Modifier.height(12.dp))

            // Every part shown, not just the total. The number is only worth
            // anything if the four things behind it are on the same card.
            Part(str.success.consistency, score.parts[SuccessPart.Consistency] ?: 0)
            Part(str.success.finishing, score.parts[SuccessPart.Finishing] ?: 0)
            Part(str.success.volume, score.parts[SuccessPart.Volume] ?: 0)
            Part(str.success.balance, score.parts[SuccessPart.Balance] ?: 0)

            Spacer(Modifier.height(10.dp))
            Text(
                when (score.weakest) {
                    SuccessPart.Consistency -> str.success.nextConsistency
                    SuccessPart.Finishing -> str.success.nextFinishing
                    SuccessPart.Volume -> str.success.nextVolume
                    SuccessPart.Balance -> str.success.nextBalance
                },
                style = MaterialTheme.typography.bodyMedium,
                color = Ink,
            )

            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                SquishButton(
                    if (sharing) str.success.sharing else str.success.share,
                    Butter,
                    Modifier.weight(1f),
                    enabled = !sharing,
                ) {
                    sharing = true
                    scope.launch {
                        // The backdrop is generated once and reused. If it
                        // fails — no key, cold GPU, no network — the poster is
                        // shared without it rather than not shared at all.
                        val art = Backdrop.getOrMake(context)
                        ShareCard.share(context, data, data.earnedMinutes, art)
                        sharing = false
                    }
                }
                val hasArt = remember(artStamp, sharing) { Backdrop.exists(context) }
                if (hasArt) {
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(Paper.ChipRadius))
                            .background(CreamCard)
                            .border(1.5.dp, Ink, RoundedCornerShape(Paper.ChipRadius))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                Backdrop.clear(context)
                                artStamp++
                            }
                            .padding(horizontal = 12.dp, vertical = 14.dp),
                    ) {
                        Text(
                            str.success.newArt,
                            style = MaterialTheme.typography.labelSmall,
                            color = Ink,
                        )
                    }
                }
            }
        }
    }
}

/** One of the four, out of twenty-five. */
@Composable
private fun Part(label: String, value: Int) {
    val fill by animateFloatAsState(
        targetValue = (value / 25f).coerceIn(0f, 1f),
        animationSpec = Motion.settle(),
        label = label,
    )
    Column(Modifier.padding(bottom = 8.dp)) {
        Row {
            Text(label, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.weight(1f))
            Text("$value", style = MaterialTheme.typography.labelSmall, color = Ink)
        }
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Sunk)
                .border(1.5.dp, Ink, RoundedCornerShape(4.dp)),
        ) {
            Box(
                Modifier
                    .fillMaxWidth(fill)
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(GoldNeon),
            )
        }
    }
}
