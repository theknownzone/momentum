package com.momentum.focus.ui.screens

import com.momentum.focus.ui.util.verticalScrollWithFade

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

private val TRIGGERS = listOf("Bored", "Stressed", "Alone", "Late night", "Reels", "Tired")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JournalScreen(
    data: AppData,
    onSave: (Int, String, String) -> Unit,
) {
    val haptics = rememberHaptics()
    val existing = data.todayJournal

    var mood by remember(existing) { mutableIntStateOf(existing?.mood ?: 3) }
    var text by remember(existing) { mutableStateOf(existing?.text ?: "") }
    var trigger by remember(existing) { mutableStateOf(existing?.trigger ?: "") }
    var saved by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .verticalScrollWithFade(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 28.dp, bottom = 32.dp),
    ) {
        Text(
            "TODAY",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            "Aaj ka hisaab",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )

        Spacer(Modifier.height(20.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            (1..5).forEach { value ->
                val selected = mood == value
                val scale by animateFloatAsState(
                    if (selected) 1.12f else 1f, Motion.bouncy(), label = "mood$value"
                )
                val sticker = stickerFor(value + 1)
                Box(
                    Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .scale(scale)
                        .clip(CircleShape)
                        .background(
                            if (selected) sticker.fill
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .border(if (selected) Paper.Outline else 2.dp, Ink, CircleShape)
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); mood = value; saved = false
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "$value",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (selected) Lilac.on else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        Text(
            "WHAT SET YOU OFF",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(10.dp))

        FlowRow(Modifier.fillMaxWidth()) {
            TRIGGERS.forEach { t ->
                val selected = trigger == t
                Box(
                    Modifier
                        .padding(end = 8.dp, bottom = 8.dp)
                        .clip(RoundedCornerShape(Paper.ChipRadius))
                        .background(if (selected) Lilac.fill else MaterialTheme.colorScheme.surfaceVariant)
                        .border(2.dp, Ink, RoundedCornerShape(Paper.ChipRadius))
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            haptics.tick(); trigger = if (selected) "" else t; saved = false
                        }
                        .padding(horizontal = 16.dp, vertical = 9.dp)
                ) {
                    Text(
                        t,
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (selected) Lilac.on else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = text,
            onValueChange = { text = it; saved = false },
            placeholder = { Text("Three lines is enough. What happened?") },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 130.dp),
            shape = RoundedCornerShape(14.dp),
        )

        Spacer(Modifier.height(18.dp))

        SquishButton(
            label = if (saved) "Saved" else "Save entry",
            sticker = if (saved) Jade else Cobalt,
            modifier = Modifier.fillMaxWidth(),
        ) {
            onSave(mood, text, trigger)
            saved = true
            haptics.confirm()
        }
    }
}

