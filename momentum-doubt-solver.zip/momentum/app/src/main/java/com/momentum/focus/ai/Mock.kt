package com.momentum.focus.ai

import com.momentum.focus.data.AppData
import org.json.JSONObject

/** One question, its options, the key, and why the key is the key. */
data class Mcq(
    val question: String,
    val options: List<String>,
    val answerIndex: Int,
    /** One line for why. Never optional — see [Mock]. */
    val reason: String,
)

/**
 * A short mock test, built from the student's own subjects or from a page they
 * uploaded.
 *
 * Two rules here are safety rules, not features, and both are in the prompt and
 * checked again in the parser:
 *
 *  - **Every question carries its reason.** A model that is confidently wrong
 *    about an answer key teaches a student the wrong thing, and they will trust
 *    it because it came with four neat options. The reason line is what lets
 *    them catch it. A question that arrives without one is dropped rather than
 *    shown.
 *  - **An uploaded page wins over the model's memory.** When there is a photo
 *    or a PDF, questions must come from what is on it. Recall invents dates and
 *    formulae; a page cannot.
 *
 * Neither rule makes the questions correct. They make a wrong one survivable,
 * which is the most an offline model can promise, and it is why the card that
 * shows these says out loud that they are AI-written.
 */
object Mock {

    /** Short on purpose: a drill between sessions, not a paper. */
    const val COUNT = 5

    private const val MAX_OPTIONS = 4

    fun systemPrompt(data: AppData, fromPage: Boolean): String {
        val exam = data.examName.ifBlank { "a competitive exam" }
        val subjects = data.subjects.joinToString().ifBlank { "school and exam subjects" }
        val source = if (fromPage) {
            """
            The student has attached a page. Every question must come from what
            is written on that page. Do not add questions from memory, and do
            not test anything the page does not cover. If the page is unreadable
            or has no testable content, return an empty items array.
            """.trimIndent()
        } else {
            """
            Draw the questions from the standard syllabus for $exam in
            $subjects. Stay on the settled, commonly examined material. Do not
            reach for obscure facts, exact dates, or record figures — those are
            where a recalled answer key goes wrong.
            """.trimIndent()
        }
        return """
            You are setting a short practice test for a student preparing for
            $exam. Subjects: $subjects.

            $source

            Return JSON only, in exactly this shape and nothing else:
            {"items":[{"q":"...","options":["...","...","...","..."],"answer":0,"why":"..."}]}

            Rules:
            - Exactly $COUNT items, each with exactly $MAX_OPTIONS options.
            - "answer" is the zero-based index of the correct option.
            - "why" is one line saying why that option is right — the rule, the
              step, or the line on the page it came from. It is not optional. A
              student has to be able to check you.
            - Only one option may be correct. The other three must be wrong,
              not merely worse.
            - No trick wording, no "all of the above", no negative phrasing.
            - Plain text in every field. No markdown, no LaTeX.
        """.trimIndent()
    }

    /**
     * Parses the model's reply, keeping only questions that are properly formed.
     *
     * Everything here is a discard rather than a repair. A missing reason, an
     * out-of-range key or three options instead of four all mean the model was
     * not doing what it was told, and patching such an item up would produce a
     * question that looks finished and is not.
     */
    fun parse(raw: String): List<Mcq> {
        val body = raw.substringAfter("```json", raw).substringBefore("```").trim()
        val json = runCatching { JSONObject(body) }.getOrNull() ?: return emptyList()
        val items = json.optJSONArray("items") ?: return emptyList()
        val out = mutableListOf<Mcq>()
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            val question = item.optString("q").trim()
            val why = item.optString("why").trim()
            val answer = item.optInt("answer", -1)
            val optionsArray = item.optJSONArray("options") ?: continue
            val options = (0 until optionsArray.length())
                .map { optionsArray.optString(it).trim() }
                .filter { it.isNotBlank() }
            if (question.isBlank()) continue
            if (why.isBlank()) continue
            if (options.size != MAX_OPTIONS) continue
            if (answer !in options.indices) continue
            if (options.distinct().size != options.size) continue
            out += Mcq(question, options, answer, why)
        }
        return out
    }

    suspend fun generate(
        data: AppData,
        subject: String,
        pageJpegB64: String? = null,
    ): List<Mcq> {
        val fromPage = !pageJpegB64.isNullOrBlank()
        val ask = if (fromPage) {
            "Set the test from this page."
        } else {
            "Set the test on $subject."
        }
        val reply = Ai.chat(
            system = systemPrompt(data, fromPage),
            turns = listOf(Ai.Turn(fromUser = true, text = ask, imageB64 = pageJpegB64)),
            maxTokens = 1200,
            // Low. A test is not the place for the model to be inventive.
            temperature = 0.2,
            // Not requested as a JSON response when a page is attached: the
            // vision model this routes to does not take response_format, and
            // asking for it there fails the whole call rather than the format.
            json = !fromPage,
        )
        return parse(reply)
    }
}

/** What the mock screen is doing right now. */
data class MockState(
    val items: List<Mcq> = emptyList(),
    val chosen: Map<Int, Int> = emptyMap(),
    val busy: Boolean = false,
    val error: String? = null,
    /** True once answers are revealed and the score is final. */
    val marked: Boolean = false,
) {
    val score: Int get() = items.indices.count { chosen[it] == items[it].answerIndex }
    val answeredAll: Boolean get() = items.isNotEmpty() && chosen.size == items.size
}
