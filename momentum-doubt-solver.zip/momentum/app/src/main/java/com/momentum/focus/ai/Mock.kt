package com.momentum.focus.ai

import com.momentum.focus.data.AppData
import org.json.JSONObject

/** One question, its options, the key, and why the key is the key. */
data class Mcq(
    val question: String,
    val options: List<String>,
    val answerIndex: Int,
    /** One line for why. Never optional — see [Mock]. */
    val reason: String,
)

/**
 * A short mock test, built from the student's own subjects or from a page they
 * uploaded.
 *
 * Two rules here are safety rules, not features, and both are in the prompt and
 * checked again in the parser:
 *
 *  - **Every question carries its reason.** A model that is confidently wrong
 *    about an answer key teaches a student the wrong thing, and they will trust
 *    it because it came with four neat options. The reason line is what lets
 *    them catch it. A question that arrives without one is dropped rather than
 *    shown.
 *  - **An uploaded page wins over the model's memory.** When there is a photo
 *    or a PDF, questions must come from what is on it. Recall invents dates and
 *    formulae; a page cannot.
 *
 * Neither rule makes the questions correct. They make a wrong one survivable,
 * which is the most an offline model can promise, and it is why the card that
 * shows these says out loud that they are AI-written.
 */
object Mock {

    /** Short on purpose: a drill between sessions, not a paper. */
    /**
     * Questions in a drill.
     *
     * Ten, not five. Five is a sample and it tells you almost nothing — get
     * three right and you cannot tell whether you know the topic or guessed
     * well. Ten is the shortest set where the score means something, and it is
     * still short enough to sit inside a study session rather than replacing
     * one.
     */
    const val COUNT = 10

    /**
     * How long the drill runs, in seconds.
     *
     * Ten minutes for ten questions — a minute each. Bank and SSC papers run
     * closer to forty-five seconds, so this is slightly generous on purpose:
     * the point of the timer is to stop someone sitting on question three for
     * six minutes, not to recreate exam pressure at a desk at home.
     */
    const val SECONDS = 600

    private const val MAX_OPTIONS = 4

    /**
     * [subject] and [topic] are what the student picked for this drill.
     *
     * They matter more than they look. This prompt used to be handed every
     * subject on the profile at once — "Subjects: Biology, Chemistry, Maths" —
     * while the user message said "Set the test on Biology", chosen by taking
     * the first of the three. So a student revising Maths got a Biology paper,
     * and there was no way to say otherwise: the picker did not exist, and the
     * only other input was whatever subject a running focus session happened
     * to carry.
     *
     * Now the chosen subject is the only one named, and a topic narrows it
     * further. A drill on "integration by parts" is worth ten times one on
     * "Maths", because the thing a student is stuck on is never a whole
     * subject.
     */
    fun systemPrompt(
        data: AppData,
        fromPage: Boolean,
        subject: String = "",
        topic: String = "",
        missed: List<String> = emptyList(),
    ): String {
        val exam = data.examName.ifBlank { "a competitive exam" }
        // The chosen subject wins outright. Listing the others alongside it is
        // an invitation to drift back to them.
        val subjects = subject.ifBlank {
            data.subjects.joinToString().ifBlank { "school and exam subjects" }
        }
        // What this student actually got wrong last time on this ground.
        //
        // This is the difference between a drill and a quiz. Setting another
        // general paper on a subject someone already failed a paper on tests
        // the same thing again and teaches nothing; aiming at the misses is
        // the entire reason for keeping them.
        val weak = if (missed.isEmpty()) "" else """

            This student recently got these wrong. Set questions that test the
            same ideas from a different angle — do not repeat the questions
            themselves:
            ${missed.joinToString("\n") { "- $it" }}
        """.trimIndent()
        val narrow = if (topic.isBlank()) "" else """

            Every question must be on this specific topic: $topic. If the topic
            is too narrow for $COUNT distinct questions, stay on it anyway and
            approach it from different angles — do not widen to the rest of
            $subjects to fill the count.
        """.trimIndent()
        val source = if (fromPage) {
            """
            The student has attached a page. Every question must come from what
            is written on that page. Do not add questions from memory, and do
            not test anything the page does not cover. If the page is unreadable
            or has no testable content, return an empty items array.
            """.trimIndent()
        } else {
            """
            Draw the questions from the standard syllabus for $exam in
            $subjects. Stay on the settled, commonly examined material. Do not
            reach for obscure facts, exact dates, or record figures — those are
            where a recalled answer key goes wrong.
            """.trimIndent()
        }
        return """
            You are setting a short practice test for a student preparing for
            $exam. Subject: $subjects.

            $source$narrow$weak

            Return JSON only, in exactly this shape and nothing else:
            {"items":[{"q":"...","options":["...","...","...","..."],"answer":0,"why":"..."}]}

            Rules:
            - Exactly $COUNT items, each with exactly $MAX_OPTIONS options.
            - "answer" is the zero-based index of the correct option.
            - "why" is two or three sentences, not one line. Give the rule or
              formula, then the step that applies it, then why the closest
              wrong option is wrong. This is the part the student actually
              learns from — a bare "because it is 42" teaches nothing and
              cannot be checked.
            - Only one option may be correct. The other three must be wrong,
              not merely worse.
            - No trick wording, no "all of the above", no negative phrasing.
            - Plain text in every field. No markdown, no LaTeX.
        """.trimIndent()
    }

    /**
     * Parses the model's reply, keeping only questions that are properly formed.
     *
     * Everything here is a discard rather than a repair. A missing reason, an
     * out-of-range key or three options instead of four all mean the model was
     * not doing what it was told, and patching such an item up would produce a
     * question that looks finished and is not.
     */
    fun parse(raw: String): List<Mcq> {
        val body = raw.substringAfter("```json", raw).substringBefore("```").trim()
        val json = runCatching { JSONObject(body) }.getOrNull() ?: return emptyList()
        val items = json.optJSONArray("items") ?: return emptyList()
        val out = mutableListOf<Mcq>()
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            val question = item.optString("q").trim()
            val why = item.optString("why").trim()
            val answer = item.optInt("answer", -1)
            val optionsArray = item.optJSONArray("options") ?: continue
            val options = (0 until optionsArray.length())
                .map { optionsArray.optString(it).trim() }
                .filter { it.isNotBlank() }
            if (question.isBlank()) continue
            if (why.isBlank()) continue
            if (options.size != MAX_OPTIONS) continue
            if (answer !in options.indices) continue
            if (options.distinct().size != options.size) continue
            out += Mcq(question, options, answer, why)
        }
        return out
    }

    suspend fun generate(
        data: AppData,
        subject: String,
        topic: String = "",
        missed: List<String> = emptyList(),
        pageJpegB64: String? = null,
    ): List<Mcq> {
        val fromPage = !pageJpegB64.isNullOrBlank()
        val ask = when {
            fromPage -> "Set the test from this page."
            topic.isNotBlank() -> "Set the test on $topic, within $subject."
            else -> "Set the test on $subject."
        }
        val reply = Ai.chat(
            system = systemPrompt(data, fromPage, subject, topic, missed),
            turns = listOf(Ai.Turn(fromUser = true, text = ask, imageB64 = pageJpegB64)),
            // Doubled with the question count, and then some: ten questions
            // with three-sentence reasons is roughly twice the text of five
            // with one-line ones. A ceiling that truncates the JSON does not
            // give a shorter test, it gives a parse failure and no test at
            // all.
            maxTokens = 3000,
            // Low. A test is not the place for the model to be inventive.
            temperature = 0.2,
            // Not requested as a JSON response when a page is attached: the
            // vision model this routes to does not take response_format, and
            // asking for it there fails the whole call rather than the format.
            json = !fromPage,
        )
        return parse(reply)
    }
}

/** What the mock screen is doing right now. */
data class MockState(
    val items: List<Mcq> = emptyList(),
    val chosen: Map<Int, Int> = emptyMap(),
    val busy: Boolean = false,
    val error: String? = null,
    /** True once answers are revealed and the score is final. */
    val marked: Boolean = false,
) {
    val score: Int get() = items.indices.count { chosen[it] == items[it].answerIndex }
    val answeredAll: Boolean get() = items.isNotEmpty() && chosen.size == items.size
}
