package com.momentum.focus.ui.i18n

/**
 * Words that show up on more than one screen. Anything used once belongs in
 * that screen's own section instead.
 */
interface CommonStrings {
    val today: String
    val yesterday: String
    fun daysAgo(days: Int): String

    // Buttons that recur on nearly every screen and sheet.
    val cancel: String
    val save: String
    val yes: String
    val no: String

    // ---- language picker, on Profile ----
    val languageTitle: String
    val languageSubtitle: String

    // ---- the settings screen, split out of Profile ----
    val back: String
    val settings: String
    val settingsSub: String
}

object CommonHi : CommonStrings {
    override val today = "Aaj"
    override val yesterday = "Kal"
    override fun daysAgo(days: Int) = "$days din pehle"

    override val cancel = "Cancel"
    override val save = "Save"
    override val yes = "Haan"
    override val no = "Nahi"

    override val languageTitle = "Language"
    override val languageSubtitle = "Poora app is bhasha mein dikhega"
    override val back = "Peeche"
    override val settings = "Settings"
    override val settingsSub = "Target, rules, blocking, permissions"
}

object CommonEn : CommonStrings {
    override val today = "Today"
    override val yesterday = "Yesterday"
    override fun daysAgo(days: Int) = if (days == 1) "1 day ago" else "$days days ago"

    override val cancel = "Cancel"
    override val save = "Save"
    override val yes = "Yes"
    override val no = "No"

    override val languageTitle = "Language"
    override val languageSubtitle = "The whole app switches to this language"
    override val back = "Back"
    override val settings = "Settings"
    override val settingsSub = "Target, rules, blocking, permissions"
}
