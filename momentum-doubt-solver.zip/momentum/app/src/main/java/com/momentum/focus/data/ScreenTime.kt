package com.momentum.focus.data

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.getSystemService
import java.util.Calendar
import java.util.concurrent.TimeUnit

data class AppUsage(
    val pkg: String,
    val label: String,
    val minutes: Int,
)

data class ScreenTimeReport(
    val dailyMinutes: List<Int>,      // last 7 days, oldest first
    val averageMinutes: Int,
    val longestDayIndex: Int,
    val longestDayMinutes: Int,
    val pickups: Int,
    val topApps: List<AppUsage>,
) {
    /**
     * Hours per day projected across thirty years, expressed in years.
     *
     * This is the number that lands. "Nine hours a day" is abstract; "twelve
     * years of your life" is not, and it is the same fact.
     */
    val yearsOverThirty: Double
        get() = (averageMinutes / 60.0) * 365 * 30 / (24 * 365)

    val hasData: Boolean get() = dailyMinutes.any { it > 0 }
}

/**
 * Real numbers from UsageStats — never estimates.
 *
 * The whole onboarding rests on the gap between what someone guesses and what
 * is actually true, so a fabricated figure would destroy the only thing that
 * makes the screen work.
 */

/** One app coming to the front, for the timeline. */
data class TimelineEntry(
    val pkg: String,
    val label: String,
    val startMs: Long,
    val minutes: Int,
)

object ScreenTime {

    /**
     * Minutes the user actually spent in [study] packages between start and end.
     * Also returns minutes in [blocked] — those kill the session.
     */
    fun sessionAudit(
        context: Context,
        startMs: Long,
        endMs: Long,
        study: Set<String>,
        blocked: Set<String>,
    ): Pair<Int, Int> {
        val usage = context.getSystemService<UsageStatsManager>() ?: return 0 to 0
        val events = runCatching { usage.queryEvents(startMs, endMs) }.getOrNull()
            ?: return 0 to 0
        val ev = UsageEvents.Event()
        var current = ""
        var last = startMs
        var studyMs = 0L
        var junkMs = 0L
        fun credit(until: Long) {
            val dt = (until - last).coerceAtLeast(0)
            if (current.isBlank() || isSystemNoise(current)) return
            when {
                StudyApps.isForbidden(current) ||
                    blocked.any { current == it || current.startsWith(it) } -> junkMs += dt
                study.any { current.startsWith(it) } -> studyMs += dt
            }
        }
        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            if (ev.timeStamp < startMs) continue
            when (ev.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> {
                    credit(ev.timeStamp)
                    current = ev.packageName ?: ""
                    last = ev.timeStamp
                }
                // Without this the clock kept running on whatever was last in
                // front. Open a lecture app, lock the phone, walk away, and the
                // whole idle stretch was paid out as honest study time — the
                // cheapest possible way to farm the wallet. A pause fires when
                // the screen goes off too, so this closes both.
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    if (ev.packageName == current) {
                        credit(ev.timeStamp)
                        current = ""
                        last = ev.timeStamp
                    }
                }
                else -> continue
            }
        }
        credit(endMs)
        return TimeUnit.MILLISECONDS.toMinutes(studyMs).toInt() to
            TimeUnit.MILLISECONDS.toMinutes(junkMs).toInt()
    }

    /**
     * One day's foreground time, walked from events instead of summed.
     *
     * Adding up every package's totalTimeInForeground is what produced the
     * numbers this app was showing: a 19-hour daily average and a "longest
     * day" of exactly 1440 minutes, which is not a heavy day, it is the 24-hour
     * clamp being hit. Those totals overlap — services, split screen and
     * packages that were never on screen all report foreground time — so the
     * sum is larger than the day it is measuring.
     *
     * Walking foreground and background events counts each stretch once,
     * because only one app is in front at a time. Returns null when the system
     * has no events for the window, which happens past its retention, and the
     * caller falls back to the old sum for that day.
     */
    private fun dayFromEvents(
        usage: UsageStatsManager,
        start: Long,
        end: Long,
        perApp: MutableMap<String, Long>,
    ): Int? {
        val events = runCatching { usage.queryEvents(start, end) }.getOrNull() ?: return null
        val ev = UsageEvents.Event()
        var current = ""
        var since = start
        var total = 0L
        var saw = false

        fun credit(until: Long) {
            if (current.isBlank() || isSystemNoise(current)) return
            val dt = (until - since).coerceAtLeast(0)
            if (dt <= 0) return
            total += dt
            perApp[current] = (perApp[current] ?: 0) + dt
        }

        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            when (ev.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> {
                    credit(ev.timeStamp)
                    current = ev.packageName ?: ""
                    since = ev.timeStamp
                    saw = true
                }
                // Also fires when the screen goes off, which is what stops an
                // open app being paid for the whole night.
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    if (ev.packageName == current) {
                        credit(ev.timeStamp)
                        current = ""
                        since = ev.timeStamp
                    }
                }
                else -> continue
            }
        }
        credit(minOf(end, System.currentTimeMillis()))
        if (!saw) return null
        return TimeUnit.MILLISECONDS
            .toMinutes(total.coerceAtMost(TimeUnit.DAYS.toMillis(1)))
            .toInt()
    }

    fun report(context: Context, days: Int = 7): ScreenTimeReport {
        val usage = context.getSystemService<UsageStatsManager>()
            ?: return empty(days)
        val pm = context.packageManager

        val daily = mutableListOf<Int>()
        val perApp = mutableMapOf<String, Long>()

        for (back in (days - 1) downTo 0) {
            val (start, end) = dayRange(back)
            val measured = dayFromEvents(usage, start, end, perApp)
            if (measured != null) {
                daily += measured
                continue
            }

            // Fallback for days the event log no longer covers. Still the
            // overlapping sum, so it can read high — but a rough figure for an
            // old day beats a hole in the week.
            val stats = runCatching {
                usage.queryAndAggregateUsageStats(start, end)
            }.getOrNull().orEmpty()

            var dayTotal = 0L
            stats.forEach { (pkg, s) ->
                if (s.totalTimeInForeground <= 0) return@forEach
                if (isSystemNoise(pkg)) return@forEach
                val capped = s.totalTimeInForeground.coerceAtMost(TimeUnit.DAYS.toMillis(1))
                dayTotal += capped
                perApp[pkg] = (perApp[pkg] ?: 0) + capped
            }
            dayTotal = dayTotal.coerceAtMost(TimeUnit.DAYS.toMillis(1))
            daily += TimeUnit.MILLISECONDS.toMinutes(dayTotal).toInt()
        }

        val average = if (daily.isEmpty()) 0 else daily.sum() / daily.size
        val longest = daily.indices.maxByOrNull { daily[it] } ?: 0

        val top = perApp.entries
            .sortedByDescending { it.value }
            .take(6)
            .map { (pkg, ms) ->
                AppUsage(
                    pkg = pkg,
                    label = label(pm, pkg),
                    minutes = TimeUnit.MILLISECONDS.toMinutes(ms).toInt(),
                )
            }

        return ScreenTimeReport(
            dailyMinutes = daily,
            averageMinutes = average,
            longestDayIndex = longest,
            longestDayMinutes = daily.getOrElse(longest) { 0 },
            pickups = pickupsYesterday(context),
            topApps = top,
        )
    }

    /**
     * A pickup is the screen becoming interactive, not an app opening. Counting
     * app launches would triple the number every time someone switches tabs.
     */
    private fun pickupsYesterday(context: Context): Int {
        val usage = context.getSystemService<UsageStatsManager>() ?: return 0
        val (start, end) = dayRange(0)
        val events = runCatching { usage.queryEvents(start, end) }.getOrNull() ?: return 0
        val event = UsageEvents.Event()
        var count = 0
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.SCREEN_INTERACTIVE) count++
        }
        return count
    }

    /**
     * Minutes each of these packages has spent in the foreground since
     * midnight. Used by the daily cap check, which runs on a timer inside the
     * blocker, so it asks for the packages it cares about rather than building
     * a whole report.
     */
    fun minutesTodayFor(context: Context, packages: Set<String>): Map<String, Int> {
        if (packages.isEmpty()) return emptyMap()
        val usage = context.getSystemService<UsageStatsManager>() ?: return emptyMap()
        val (start, end) = dayRange(0)
        // Same aggregation fix as report(): the bucketed query double-counted,
        // which here meant a daily cap could fire hours before it was reached.
        val stats = runCatching {
            usage.queryAndAggregateUsageStats(start, end)
        }.getOrNull().orEmpty()

        val out = mutableMapOf<String, Long>()
        stats.forEach { (pkg, s) ->
            if (pkg !in packages) return@forEach
            if (s.totalTimeInForeground <= 0) return@forEach
            out[pkg] = s.totalTimeInForeground.coerceAtMost(TimeUnit.DAYS.toMillis(1))
        }
        return out.mapValues { TimeUnit.MILLISECONDS.toMinutes(it.value).toInt() }
    }

    /**
     * Today in order: which app, when, for how long.
     *
     * Totals answer "where did the day go" but not "when did it start going",
     * and the second question is the one that shows a pattern — the same app
     * at the same hour every evening. Runs under a minute are dropped; a
     * timeline of one-second glances is noise, not a record.
     */
    fun timelineToday(context: Context, limit: Int = 40): List<TimelineEntry> {
        val usage = context.getSystemService<UsageStatsManager>() ?: return emptyList()
        val pm = context.packageManager
        val (start, end) = dayRange(0)
        val events = runCatching { usage.queryEvents(start, end) }.getOrNull() ?: return emptyList()

        val out = mutableListOf<TimelineEntry>()
        val ev = UsageEvents.Event()
        var currentPkg: String? = null
        var currentStart = 0L

        fun close(at: Long) {
            val pkg = currentPkg ?: return
            val mins = ((at - currentStart) / 60000L).toInt()
            if (mins >= 1 && !isSystemNoise(pkg)) {
                out += TimelineEntry(pkg, label(pm, pkg), currentStart, mins)
            }
            currentPkg = null
        }

        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            when (ev.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> {
                    close(ev.timeStamp)
                    currentPkg = ev.packageName
                    currentStart = ev.timeStamp
                }
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    if (ev.packageName == currentPkg) close(ev.timeStamp)
                }
                else -> continue
            }
        }
        close(System.currentTimeMillis().coerceAtMost(end))
        return out.sortedByDescending { it.startMs }.take(limit)
    }

    private fun dayRange(daysBack: Int): Pair<Long, Long> {
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -daysBack)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val start = cal.timeInMillis
        return start to (start + TimeUnit.DAYS.toMillis(1))
    }

    private fun isSystemNoise(pkg: String): Boolean =
        pkg.contains("launcher", true) ||
            pkg.startsWith("com.android.systemui") ||
            pkg.startsWith("com.android.settings") ||
            pkg.startsWith("com.miui.home")

    private fun label(pm: PackageManager, pkg: String): String = runCatching {
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    private fun empty(days: Int) = ScreenTimeReport(
        dailyMinutes = List(days) { 0 },
        averageMinutes = 0,
        longestDayIndex = 0,
        longestDayMinutes = 0,
        pickups = 0,
        topApps = emptyList(),
    )
}
