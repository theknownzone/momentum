package com.momentum.focus.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.delay
import java.time.LocalTime

/**
 * Greeting that types itself, once per app launch.
 *
 * The trailing cursor and per-character delay are what make it read as being
 * addressed rather than labelled. Repeating it on every recomposition would
 * turn a nice touch into a stutter, so the animation is keyed to the name and
 * runs a single time.
 *
 * There was an `animateFloatAsState` here driving `alpha(1f - cursor * 0f)`.
 * Multiplied by zero it resolved to a constant 1f, so it faded nothing and
 * only cost a recomposition per frame for 300ms. The cursor already disappears
 * when [done] flips; the dead animation is gone.
 */
@Composable
fun TypedGreeting(
    name: String,
    modifier: Modifier = Modifier,
    nameColor: Color = MaterialTheme.colorScheme.onBackground,
    labelColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
) {
    val greeting = remember {
        when (LocalTime.now().hour) {
            in 5..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            in 17..20 -> "Good evening"
            else -> "Good night"
        }
    }

    val full = remember(name, greeting) { "$greeting, $name" }
    var shown by remember(full) { mutableIntStateOf(0) }
    var done by remember(full) { mutableStateOf(false) }

    LaunchedEffect(full) {
        shown = 0
        done = false
        // A short lead-in so the text is not already typing before the screen
        // has settled into place.
        delay(220)
        while (shown < full.length) {
            delay(38)
            shown++
        }
        delay(400)
        done = true
    }

    Box(modifier) {
        // The finished string, laid out invisibly, purely to fix the height.
        //
        // Without it this composable is one line tall on the first frame and
        // two lines tall a second later: at headlineSmall, in the column that
        // is left over after the avatar and the bell, "Good afternoon, <name>"
        // wraps partway through the typing. That second line grew the Row, the
        // Row grew the hero, and because SkinWeather is matchParentSize the
        // weather re-laid-out with it — which is the theme band that "stretches
        // once and settles" when you land on Home. Reserving the final height
        // up front means the box the weather draws into never changes size.
        //
        // Sized on "$full|" rather than full, because the cursor is still
        // appended for the 400ms after the last character lands.
        Text(
            text = "$full|",
            style = MaterialTheme.typography.headlineSmall,
            color = Color.Transparent,
        )
        Text(
            text = full.take(shown) + if (done) "" else "|",
            style = MaterialTheme.typography.headlineSmall,
            color = nameColor,
        )
    }
}
