package com.momentum.focus.ui.i18n

/**
 * What to say when a feature is switched on but cannot actually work.
 *
 * Each line names the feature, says plainly that it is not running, and says
 * what is missing — in that order. "Permission denied" tells someone nothing;
 * "the shield is on but cannot cover the screen" tells them what they lost.
 */
interface TroubleStrings {
    val fix: String
    val allGood: String

    val shieldTitle: String
    val shieldBody: String

    val usageTitle: String
    val usageBody: String

    val crownTitle: String
    val crownBody: String
}

object TroubleHi : TroubleStrings {
    override val fix = "Theek karo"
    override val allGood = "Ho gaya — ab sab chalu hai."

    override val shieldTitle = "Shield chalu hai par kaam nahi kar raha"
    override val shieldBody =
        "App ke upar dikhne ki permission nahi hai, isliye blocked app khul jayegi."

    override val usageTitle = "Screen time nahi gina ja raha"
    override val usageBody =
        "Usage access band hai — phone ke ghante, caps aur stats khaali rahenge."

    override val crownTitle = "Crown chalu hai par uninstall lock nahi"
    override val crownBody =
        "Device admin off hai, to app abhi bhi hataya ja sakta hai."
}

object TroubleEn : TroubleStrings {
    override val fix = "Fix"
    override val allGood = "Done — everything is running now."

    override val shieldTitle = "Shield is on but not working"
    override val shieldBody =
        "It cannot draw over other apps, so a blocked app will just open."

    override val usageTitle = "Screen time is not being counted"
    override val usageBody =
        "Usage access is off — phone hours, daily caps and stats stay empty."

    override val crownTitle = "Crown is on without the uninstall lock"
    override val crownBody =
        "Device admin is off, so the app can still be removed."
}
