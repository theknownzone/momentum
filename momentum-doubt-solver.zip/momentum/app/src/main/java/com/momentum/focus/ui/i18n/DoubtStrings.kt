package com.momentum.focus.ui.i18n

/**
 * The doubt sheet's text.
 *
 * The counting lines carry more weight here than they look like they do. A
 * student who cannot see how many questions are left, or that the clock is
 * still running, is being quietly charged for something nobody told them the
 * price of — so those two strings are on screen the whole time the sheet is.
 */
interface DoubtStrings {
    /** The chip on the Focus screen that opens the sheet. */
    val ask: String
    val label: String
    val title: String
    val intro: String
    val hint: String
    val thinking: String
    val send: String
    val stop: String
    val stopped: String
    val retry: String
    fun left(count: Int): String
    val noneLeftTitle: String
    val noneLeftBody: String
    fun clockRunning(time: String): String
    val clockPaused: String
    val disclaimer: String
    val close: String

    /**
     * Shown in the empty sheet, and tappable.
     *
     * They are short on purpose: the first question someone asks sets the size
     * of every question after it, and three examples of one-line doubts teach
     * that faster than a sentence explaining it would.
     */
    val examples: List<String>
}

object DoubtHi : DoubtStrings {
    override val ask = "Doubt poochho"
    override val label = "DOUBT"
    override val title = "Ek doubt poochho"
    override val intro =
        "Ek session mein 5 sawaal, aur timer chalta rahega. Chhote sawaal " +
            "poochho — ek step, ek formula, ek line ka farak."
    override val hint = "Kahan atke ho?"
    override val thinking = "Soch raha hoon"
    override val send = "Bhejo"
    override val stop = "Roko"
    override val stopped = "Rok diya."
    override val retry = "Phir se poochho"
    override fun left(count: Int) =
        if (count == 1) "1 sawaal bacha hai" else "$count sawaal bache hain"
    override val noneLeftTitle = "Is session ke sawaal khatam"
    override val noneLeftBody =
        "Paanchon ho gaye. Agli session shuru karoge to phir se paanch milenge. " +
            "Abhi kitaab kholo."
    override fun clockRunning(time: String) = "Timer chal raha hai · $time"
    override val clockPaused = "Timer band hai"
    override val disclaimer = "AI ne likha hai. Galat ho sakta hai — book se milao."
    override val close = "Band karo"
    override val examples = listOf(
        "Ye step samajh nahi aaya",
        "Iska short trick kya hai?",
        "Ek line mein farak batao",
    )
}

object DoubtEn : DoubtStrings {
    override val ask = "Ask a doubt"
    override val label = "DOUBT"
    override val title = "Ask one doubt"
    override val intro =
        "Five questions a session, and the clock keeps running. Keep them " +
            "small — one step, one formula, one difference."
    override val hint = "Where are you stuck?"
    override val thinking = "Thinking"
    override val send = "Send"
    override val stop = "Stop"
    override val stopped = "Stopped."
    override val retry = "Ask it again"
    override fun left(count: Int) =
        if (count == 1) "1 question left" else "$count questions left"
    override val noneLeftTitle = "That was the fifth"
    override val noneLeftBody =
        "Five is all a session gets. The next one starts you at five again. " +
            "Open the book."
    override fun clockRunning(time: String) = "Clock running · $time"
    override val clockPaused = "Clock stopped"
    override val disclaimer = "Written by AI. It can be wrong — check it against your book."
    override val close = "Close"
    override val examples = listOf(
        "I don't get this step",
        "Is there a shorter way?",
        "The difference in one line",
    )
}
