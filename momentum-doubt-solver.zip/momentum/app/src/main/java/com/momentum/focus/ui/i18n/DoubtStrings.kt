package com.momentum.focus.ui.i18n

/**
 * The doubt sheet's text.
 *
 * The counting lines carry more weight here than they look like they do. A
 * student who cannot see how many questions are left, or that the clock is
 * still running, is being quietly charged for something nobody told them the
 * price of — so those two strings are on screen the whole time the sheet is.
 */
interface DoubtStrings {
    /** The chip on the Focus screen that opens the sheet. */
    val ask: String
    val label: String
    val title: String
    val intro: String
    val hint: String
    val thinking: String
    val send: String
    val stop: String
    val stopped: String
    val retry: String
    fun left(count: Int): String
    val noneLeftTitle: String
    val noneLeftBody: String
    fun clockRunning(time: String): String
    val clockPaused: String
    val disclaimer: String
    val close: String

    /** Attach flow: shown while a photo or PDF page is being prepared. */
    val attaching: String
    val attachFailed: String
    val photo: String
    val pdf: String
    val camera: String

    /** The plus button that opens the attachment tray. */
    val attachMore: String

    /** Shown for a moment under a message that was long-pressed. */
    val copied: String

    /** The header and its menu. */
    val menu: String
    fun welcome(name: String): String
    val welcomeSub: String
    val modesTitle: String
    val modeStudyWhat: String
    val modeFriendWhat: String
    val modeGuruWhat: String

    /** MyAi personas, and the marker on the two that are paid. */
    val modeStudy: String
    val modeFriend: String
    val modeGuru: String
    val proTag: String

    /** Header on the data card in an empty thread. */
    val pulseLabel: String

    /** Sends the thread out through the share sheet. */
    val export: String
    val exportYou: String
    val exportAi: String

    /**
     * Shown in the empty sheet, and tappable.
     *
     * They are short on purpose: the first question someone asks sets the size
     * of every question after it, and three examples of one-line doubts teach
     * that faster than a sentence explaining it would.
     */
    val examples: List<String>
}

object DoubtHi : DoubtStrings {
    override val ask = "MyAi"
    override val label = "MYAI"
    override val title = "MyAi"
    override val intro =
        "Timer chalta rahega. Chhote sawaal poochho — ek step, ek formula, ek line ka farak."
    override val hint = "Kahan atke ho?"
    override val thinking = "Soch raha hoon"
    override val send = "Bhejo"
    override val stop = "Roko"
    override val stopped = "Rok diya."
    override val retry = "Phir se poochho"
    override fun left(count: Int) =
        if (count == 1) "1 sawaal bacha hai" else "$count sawaal bache hain"
    override val noneLeftTitle = "Is session ke sawaal khatam"
    override val noneLeftBody =
        "Is session ke sawaal khatam. Naya session shuru karoge to phir milenge. Abhi kitaab kholo."
    override fun clockRunning(time: String) = "Timer chal raha hai · $time"
    override val clockPaused = "Timer band hai"
    override val disclaimer = "AI ne likha hai. Galat ho sakta hai — book se milao."
    override val close = "Band karo"
    override val attaching = "Page taiyaar ho raha hai…"
    override val attachFailed = "Attach nahi hua."
    override val photo = "Photo"
    override val pdf = "PDF"
    override val camera = "Camera"
    override val attachMore = "Aur jodo"
    override val copied = "Copy ho gaya"
    override val menu = "Menu"
    override fun welcome(name: String) = "Kya poochhna hai, $name?"
    override val welcomeSub = "Ek step, ek formula, ek line ka farak. Chhota rakho."
    override val modesTitle = "MyAi kaise baat kare"
    override val modeStudyWhat = "Seedha jawab. Sirf padhai."
    override val modeFriendWhat = "Dost jaisa. Bakchodi bhi chalegi."
    override val modeGuruWhat = "Ustaad jaisa. Kadak, bina naram kiye."
    override val modeStudy = "Study"
    override val modeFriend = "Friend"
    override val modeGuru = "Guru"
    override val proTag = "Pro"
    override val pulseLabel = "IS HAFTE"
    override val export = "Chat bhejo"
    override val exportYou = "Tum"
    override val exportAi = "MyAi"
    override val examples = listOf(
        "Ye step samajh nahi aaya",
        "Iska short trick kya hai?",
        "Ek line mein farak batao",
    )
}

object DoubtEn : DoubtStrings {
    override val ask = "MyAi"
    override val label = "MYAI"
    override val title = "MyAi"
    override val intro =
        "The clock keeps running. Keep questions small — one step, one formula, one difference."
    override val hint = "Where are you stuck?"
    override val thinking = "Thinking"
    override val send = "Send"
    override val stop = "Stop"
    override val stopped = "Stopped."
    override val retry = "Ask it again"
    override fun left(count: Int) =
        if (count == 1) "1 question left" else "$count questions left"
    override val noneLeftTitle = "That was the last one"
    override val noneLeftBody =
        "No questions left this session. Start the next one to refill. Open the book."
    override fun clockRunning(time: String) = "Clock running · $time"
    override val clockPaused = "Clock stopped"
    override val disclaimer = "Written by AI. It can be wrong — check it against your book."
    override val close = "Close"
    override val attaching = "Preparing the page…"
    override val attachFailed = "That would not attach."
    override val photo = "Photo"
    override val pdf = "PDF"
    override val camera = "Camera"
    override val attachMore = "Add more"
    override val copied = "Copied"
    override val menu = "Menu"
    override fun welcome(name: String) = "What are you stuck on, $name?"
    override val welcomeSub = "One step, one formula, one difference. Keep it small."
    override val modesTitle = "How MyAi talks"
    override val modeStudyWhat = "Straight answers. Study only."
    override val modeFriendWhat = "Like a friend. Nonsense allowed."
    override val modeGuruWhat = "Like a teacher. Hard, and not sorry."
    override val modeStudy = "Study"
    override val modeFriend = "Friend"
    override val modeGuru = "Guru"
    override val proTag = "Pro"
    override val pulseLabel = "THIS WEEK"
    override val export = "Send chat"
    override val exportYou = "You"
    override val exportAi = "MyAi"
    override val examples = listOf(
        "I don't get this step",
        "Is there a shorter way?",
        "The difference in one line",
    )
}
