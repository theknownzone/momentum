package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.momentum.focus.ai.Doubt
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

private val BoxShape = RoundedCornerShape(22.dp)

/** What the plus menu can offer. */
enum class Attachment { Camera, Photo, Pdf, Mock }

/**
 * The composer, as one box.
 *
 * Rebuilt from the shape it was copying. The reference puts the text on its own
 * line with the controls in a row underneath, all inside a single rounded
 * card — the old version here had a column of attach buttons stacked to the
 * left of the field, which took vertical space from the conversation and left
 * the field itself a narrow slot.
 *
 * It also fixes the effect that had never actually been reproduced. The glow is
 * a thin bright line *on the border*, with a highlight travelling along it —
 * not a halo bloomed outside the box, which is what was built here and is a
 * different effect that happens to also involve a glow. Being outside meant it
 * spilled over whatever sat beside it, and being soft meant it read as a
 * smudge rather than as a signal.
 *
 * Fixed height, so the thread above owns every pixel the composer does not.
 */
@Composable
fun Composer(
    text: String,
    onText: (String) -> Unit,
    busy: Boolean,
    canSend: Boolean,
    premium: Boolean,
    /** Null hides an option entirely, e.g. the drill on a build with no key. */
    onAttach: (Attachment) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onPlans: () -> Unit,
    attachmentLabel: String? = null,
    modifier: Modifier = Modifier,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val accent = LocalSkin.current.accent
    var menuOpen by remember { mutableStateOf(false) }

    // Ceramic rather than printed card. This is the one surface on the screen
    // you put your hands on, and the reference this look comes from reserves
    // its translucent slabs for exactly that — the thing being interacted with
    // sits above the page instead of being drawn onto it. The glow edge still
    // runs the rim when an answer is on its way.
    CeramicPanel(
        modifier.fillMaxWidth(),
        radius = 22.dp,
        tint = accent,
    ) {
    Column(
        Modifier
            .fillMaxWidth()
            .glowEdge(active = busy, shape = BoxShape)
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        if (attachmentLabel != null) {
            Text(
                attachmentLabel,
                style = MaterialTheme.typography.labelSmall,
                color = Mint.accent,
                modifier = Modifier.padding(bottom = 6.dp),
            )
        }

        BasicTextField(
            value = text,
            onValueChange = { onText(it.take(Doubt.MAX_CHARS)) },
            enabled = !busy,
            textStyle = MaterialTheme.typography.bodyLarge.copy(color = Ink),
            cursorBrush = SolidColor(accent),
            maxLines = 4,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSend() }),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 26.dp),
            decorationBox = { field ->
                Box {
                    if (text.isEmpty()) {
                        Text(
                            str.doubt.hint,
                            style = MaterialTheme.typography.bodyLarge,
                            color = InkLow,
                        )
                    }
                    field()
                }
            },
        )

        Spacer(Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            // Plus, turning into a close as the tray opens. One control doing
            // both jobs, in the place the thumb already is.
            val spin by animateFloatAsState(
                targetValue = if (menuOpen) 135f else 0f,
                animationSpec = Motion.bouncy(),
                label = "spin",
            )
            RoundButton(
                fill = if (menuOpen) Ink else Cream,
                onClick = { haptics.tick(); menuOpen = !menuOpen },
                description = str.doubt.attachMore,
            ) {
                Icon(
                    Icons.Filled.Add,
                    contentDescription = null,
                    tint = if (menuOpen) Cream else Ink,
                    modifier = Modifier
                        .size(22.dp)
                        .rotate(spin),
                )
            }

            Spacer(Modifier.weight(1f))

            SendStopButton(
                busy = busy,
                enabled = canSend,
                onSend = onSend,
                onStop = onStop,
            )
        }

        if (menuOpen) {
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AttachChip(Icons.Filled.PhotoCamera, str.doubt.camera, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Camera) } else onPlans()
                }
                AttachChip(Icons.Filled.AddPhotoAlternate, str.doubt.photo, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Photo) } else onPlans()
                }
                AttachChip(Icons.Filled.PictureAsPdf, str.doubt.pdf, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Pdf) } else onPlans()
                }
                // The drill lives here now. As a fourth chip in the mode row it
                // pushed that row past the width of a phone and broke across
                // three lines — and it never belonged there anyway: the modes
                // are how MyAi talks, this is a thing you set it doing.
                AttachChip(Icons.Filled.Quiz, str.mock.label, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Mock) } else onPlans()
                }
            }
        }
    }
    }
}

@Composable
private fun RoundButton(
    fill: Color,
    onClick: () -> Unit,
    description: String,
    content: @Composable () -> Unit,
) {
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(fill)
            .border(2.dp, Ink, CircleShape)
            .clickableNoRipple(remember { MutableInteractionSource() }) { onClick() }
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) { content() }
}

/**
 * One option in the plus tray.
 *
 * Locked options are shown rather than hidden. Someone who cannot see a feature
 * cannot decide they want it, and this app's whole paid tier is things it can
 * already almost do.
 */
@Composable
private fun AttachChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    unlocked: Boolean,
    onClick: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        // Ceramic too, so the tray reads as part of the same object rather
        // than as buttons that appeared underneath it.
        CeramicPanel(
            Modifier
                .size(46.dp)
                .clickableNoRipple(remember { MutableInteractionSource() }) { onClick() },
            radius = 15.dp,
            layers = 1,
        ) {
        Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
            Icon(
                icon,
                contentDescription = label,
                tint = if (unlocked) Ink else InkLow,
                modifier = Modifier.size(21.dp),
            )
        }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (unlocked) InkMid else InkLow,
        )
    }
}

/**
 * Send, until there is something to stop.
 *
 * One button in one place, because a stop control that appears elsewhere is one
 * the thumb has to go looking for while it is already resting here.
 */
@Composable
private fun SendStopButton(
    busy: Boolean,
    enabled: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val live = busy || enabled
    val scale by animateFloatAsState(
        targetValue = if (busy) 1.06f else 1f,
        animationSpec = Motion.bouncy(),
        label = "scale",
    )
    val spoken = if (busy) str.doubt.stop else str.doubt.send

    Box(
        Modifier
            .scale(scale)
            .size(44.dp)
            .clip(CircleShape)
            .background(if (busy) Tang.fill else if (live) Mint.fill else Sunk)
            .border(2.dp, if (live) Ink else InkLow, CircleShape)
            .clickableNoRipple(remember { MutableInteractionSource() }, enabled = live) {
                if (busy) onStop() else { haptics.tick(); onSend() }
            }
            .semantics { contentDescription = spoken },
        contentAlignment = Alignment.Center,
    ) {
        if (busy) {
            // A square, drawn rather than iconified: two shapes on a page, and
            // it reads as stop everywhere in the world.
            Spacer(
                Modifier
                    .size(15.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Ink),
            )
        } else {
            Icon(
                Icons.Filled.Send,
                contentDescription = null,
                tint = if (live) Mint.on else InkLow,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}
