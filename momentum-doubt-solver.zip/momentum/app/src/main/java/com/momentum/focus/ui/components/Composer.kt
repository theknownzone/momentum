package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.momentum.focus.ai.Doubt
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

private val BoxShape = RoundedCornerShape(22.dp)

/** What the plus menu can offer. */
enum class Attachment { Camera, Photo, Pdf, Mock }

/**
 * The composer, as one box.
 *
 * Rebuilt from the shape it was copying. The reference puts the text on its own
 * line with the controls in a row underneath, all inside a single rounded
 * card — the old version here had a column of attach buttons stacked to the
 * left of the field, which took vertical space from the conversation and left
 * the field itself a narrow slot.
 *
 * It also fixes the effect that had never actually been reproduced. The glow is
 * a thin bright line *on the border*, with a highlight travelling along it —
 * not a halo bloomed outside the box, which is what was built here and is a
 * different effect that happens to also involve a glow. Being outside meant it
 * spilled over whatever sat beside it, and being soft meant it read as a
 * smudge rather than as a signal.
 *
 * Fixed height, so the thread above owns every pixel the composer does not.
 */
@Composable
fun Composer(
    text: String,
    onText: (String) -> Unit,
    busy: Boolean,
    canSend: Boolean,
    premium: Boolean,
    /** Null hides an option entirely, e.g. the drill on a build with no key. */
    onAttach: (Attachment) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onPlans: () -> Unit,
    attachmentLabel: String? = null,
    modifier: Modifier = Modifier,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val accent = LocalSkin.current.accent
    var menuOpen by remember { mutableStateOf(false) }

    // Ceramic rather than printed card. This is the one surface on the screen
    // you put your hands on, and the reference this look comes from reserves
    // its translucent slabs for exactly that — the thing being interacted with
    // sits above the page instead of being drawn onto it. The glow edge still
    // runs the rim when an answer is on its way.
    Column(modifier.fillMaxWidth()) {
        if (attachmentLabel != null) {
            Text(
                attachmentLabel,
                style = MaterialTheme.typography.labelSmall,
                color = Mint.accent,
                modifier = Modifier.padding(start = 20.dp, bottom = 6.dp),
            )
        }

        // One row, not a box with things stacked in it. Plus on the left,
        // field in the middle taking whatever is left, send on the right — the
        // shape every chat app has settled on, and the reason is that it puts
        // both thumbs' targets at the two edges with nothing to aim between.
        // The old version was a tall card with the field on one line and the
        // buttons on another, which cost the conversation forty pixels and
        // read as a form.
        CeramicPanel(
            Modifier.fillMaxWidth(),
            radius = 26.dp,
            tint = accent,
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .glowEdge(active = busy, shape = RoundedCornerShape(26.dp))
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                val spin by animateFloatAsState(
                    targetValue = if (menuOpen) 135f else 0f,
                    animationSpec = Motion.bouncy(),
                    label = "spin",
                )
                RoundButton(
                    fill = if (menuOpen) Ink else Cream,
                    onClick = { haptics.tick(); menuOpen = !menuOpen },
                    description = str.doubt.attachMore,
                ) {
                    Icon(
                        Icons.Filled.Add,
                        contentDescription = null,
                        tint = if (menuOpen) Cream else Ink,
                        modifier = Modifier
                            .size(22.dp)
                            .rotate(spin),
                    )
                }

                Spacer(Modifier.width(8.dp))

                BasicTextField(
                    value = text,
                    onValueChange = {
                        val next = it.take(Doubt.MAX_CHARS)
                        // A tick per keystroke, not per recomposition. Only
                        // when the text actually grew, so backspace and the
                        // cursor moving stay silent.
                        if (next.length > text.length) haptics.typing()
                        onText(next)
                    },
                    enabled = !busy,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = Ink),
                    cursorBrush = SolidColor(accent),
                    maxLines = 5,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onSend() }),
                    modifier = Modifier
                        .weight(1f)
                        // Grows with the text and then stops. One line at rest,
                        // five at most — past that the conversation above is
                        // being eaten by the thing used to add to it.
                        .heightIn(min = 44.dp, max = 140.dp)
                        .padding(vertical = 11.dp),
                    decorationBox = { field ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (text.isEmpty()) {
                                Text(
                                    str.doubt.hint,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = InkLow,
                                )
                            }
                            field()
                        }
                    },
                )

                Spacer(Modifier.width(8.dp))

                SendStopButton(
                    busy = busy,
                    enabled = canSend,
                    onSend = onSend,
                    onStop = onStop,
                )
            }
        }

        // Chips below the pill, not inside it. Opening the tray should not
        // change the shape of the thing you are typing into.
        if (menuOpen) {
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AttachChip(Icons.Filled.PhotoCamera, str.doubt.camera, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Camera) } else onPlans()
                }
                AttachChip(Icons.Filled.AddPhotoAlternate, str.doubt.photo, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Photo) } else onPlans()
                }
                AttachChip(Icons.Filled.PictureAsPdf, str.doubt.pdf, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Pdf) } else onPlans()
                }
                AttachChip(Icons.Filled.Quiz, str.mock.label, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Mock) } else onPlans()
                }
            }
        }
    }
}

@Composable
private fun RoundButton(
    fill: Color,
    onClick: () -> Unit,
    description: String,
    content: @Composable () -> Unit,
) {
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(fill)
            .border(2.dp, Ink, CircleShape)
            .clickableNoRipple(remember { MutableInteractionSource() }) { onClick() }
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) { content() }
}

/**
 * One option in the plus tray.
 *
 * Locked options are shown rather than hidden. Someone who cannot see a feature
 * cannot decide they want it, and this app's whole paid tier is things it can
 * already almost do.
 */
@Composable
private fun AttachChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    unlocked: Boolean,
    onClick: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        // Ceramic too, so the tray reads as part of the same object rather
        // than as buttons that appeared underneath it.
        CeramicPanel(
            Modifier
                .size(46.dp)
                .clickableNoRipple(remember { MutableInteractionSource() }) { onClick() },
            radius = 15.dp,
            layers = 1,
        ) {
        Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
            Icon(
                icon,
                contentDescription = label,
                tint = if (unlocked) Ink else InkLow,
                modifier = Modifier.size(21.dp),
            )
        }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (unlocked) InkMid else InkLow,
        )
    }
}

/**
 * Send, until there is something to stop.
 *
 * One button in one place, because a stop control that appears elsewhere is one
 * the thumb has to go looking for while it is already resting here.
 */
@Composable
private fun SendStopButton(
    busy: Boolean,
    enabled: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val live = busy || enabled
    val scale by animateFloatAsState(
        targetValue = if (busy) 1.06f else 1f,
        animationSpec = Motion.bouncy(),
        label = "scale",
    )
    val spoken = if (busy) str.doubt.stop else str.doubt.send

    Box(
        Modifier
            .scale(scale)
            .size(44.dp)
            .clip(CircleShape)
            .background(if (busy) Tang.fill else if (live) Mint.fill else Sunk)
            .border(2.dp, if (live) Ink else InkLow, CircleShape)
            .clickableNoRipple(remember { MutableInteractionSource() }, enabled = live) {
                if (busy) onStop() else { haptics.tick(); onSend() }
            }
            .semantics { contentDescription = spoken },
        contentAlignment = Alignment.Center,
    ) {
        if (busy) {
            // A square, drawn rather than iconified: two shapes on a page, and
            // it reads as stop everywhere in the world.
            Spacer(
                Modifier
                    .size(15.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Ink),
            )
        } else {
            Icon(
                Icons.Filled.Send,
                contentDescription = null,
                tint = if (live) Mint.on else InkLow,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}
