package com.momentum.focus.ui.components
import com.momentum.focus.ui.util.horizontalScrollWithFade

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.momentum.focus.ai.Doubt
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

private val BoxShape = RoundedCornerShape(22.dp)

/** What the plus menu can offer. */
enum class Attachment { Camera, Photo, Pdf, Mock }

/**
 * The composer, as one box.
 *
 * Rebuilt from the shape it was copying. The reference puts the text on its own
 * line with the controls in a row underneath, all inside a single rounded
 * card — the old version here had a column of attach buttons stacked to the
 * left of the field, which took vertical space from the conversation and left
 * the field itself a narrow slot.
 *
 * It also fixes the effect that had never actually been reproduced. The glow is
 * a thin bright line *on the border*, with a highlight travelling along it —
 * not a halo bloomed outside the box, which is what was built here and is a
 * different effect that happens to also involve a glow. Being outside meant it
 * spilled over whatever sat beside it, and being soft meant it read as a
 * smudge rather than as a signal.
 *
 * Fixed height, so the thread above owns every pixel the composer does not.
 */
@Composable
fun Composer(
    text: String,
    onText: (String) -> Unit,
    busy: Boolean,
    canSend: Boolean,
    premium: Boolean,
    /** Null hides an option entirely, e.g. the drill on a build with no key. */
    onAttach: (Attachment) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onPlans: () -> Unit,
    attachmentLabel: String? = null,
    attachmentJpeg: String? = null,
    attachmentJpegs: List<String> = emptyList(),
    onClearAttach: () -> Unit = {},
    onRemoveAttach: (Int) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val accent = LocalSkin.current.accent
    var menuOpen by remember { mutableStateOf(false) }

    // Ceramic rather than printed card. This is the one surface on the screen
    // you put your hands on, and the reference this look comes from reserves
    // its translucent slabs for exactly that — the thing being interacted with
    // sits above the page instead of being drawn onto it. The glow edge still
    // runs the rim when an answer is on its way.
    Column(modifier.fillMaxWidth()) {
        // The tray sits above the pill, as a list, the way every app that has
        // more than three attach options ends up doing it. A row of chips
        // works for three and breaks for four — the fourth either wraps or
        // shrinks the labels until they are guesses. A list has room for a
        // name, room for a divider, and room to grow.
        if (menuOpen) {
            Column(
                Modifier
                    .padding(start = 4.dp, bottom = 10.dp)
                    .widthIn(min = 200.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(CreamCard)
                    .border(Paper.Outline, Ink, RoundedCornerShape(20.dp))
                    .padding(vertical = 6.dp),
            ) {
                AttachRow(TileArt.Camera, Tang.fill, str.doubt.camera, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Camera) } else onPlans()
                }
                AttachRow(TileArt.Photo, Sky.fill, str.doubt.photo, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Photo) } else onPlans()
                }
                AttachRow(TileArt.Journal, Lilac.fill, str.doubt.pdf, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Pdf) } else onPlans()
                }
                // A rule before the drill: the three above attach something to
                // this question, the one below starts a different thing.
                Box(
                    Modifier
                        .padding(horizontal = 16.dp, vertical = 5.dp)
                        .fillMaxWidth()
                        .height(1.5.dp)
                        .background(Ink.copy(alpha = 0.18f)),
                )
                AttachRow(TileArt.Shield, Mint.fill, str.mock.label, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Mock) } else onPlans()
                }
            }
        }

        val pics = attachmentJpegs.ifEmpty { listOfNotNull(attachmentJpeg) }
        if (pics.isNotEmpty() || attachmentLabel != null) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScrollWithFade(rememberScrollState())
                    .padding(start = 4.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                pics.forEachIndexed { i, b64 ->
                    AttachPreview(
                        jpegB64 = b64,
                        label = null,
                        onClear = { onRemoveAttach(i) },
                        modifier = Modifier.padding(end = 8.dp),
                    )
                }
            }
        }

        // One row, not a box with things stacked in it. Plus on the left,
        // field in the middle taking whatever is left, send on the right — the
        // shape every chat app has settled on, and the reason is that it puts
        // both thumbs' targets at the two edges with nothing to aim between.
        // The old version was a tall card with the field on one line and the
        // buttons on another, which cost the conversation forty pixels and
        // read as a form.
        CeramicPanel(
            Modifier.fillMaxWidth(),
            radius = 26.dp,
            tint = accent,
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .glowEdge(active = busy, shape = RoundedCornerShape(26.dp))
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                val spin by animateFloatAsState(
                    targetValue = if (menuOpen) 135f else 0f,
                    animationSpec = Motion.bouncy(),
                    label = "spin",
                )
                RoundButton(
                    fill = if (menuOpen) Ink else Cream,
                    onClick = { haptics.tick(); menuOpen = !menuOpen },
                    description = str.doubt.attachMore,
                ) {
                    Icon(
                        Icons.Filled.Add,
                        contentDescription = null,
                        tint = if (menuOpen) Cream else Ink,
                        modifier = Modifier
                            .size(22.dp)
                            .rotate(spin),
                    )
                }

                Spacer(Modifier.width(8.dp))

                BasicTextField(
                    value = text,
                    onValueChange = {
                        val next = it.take(Doubt.MAX_CHARS)
                        // A tick per keystroke, not per recomposition. Only
                        // when the text actually grew, so backspace and the
                        // cursor moving stay silent.
                        if (next.length > text.length) haptics.typing()
                        onText(next)
                    },
                    enabled = !busy,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = Ink),
                    cursorBrush = SolidColor(accent),
                    maxLines = 5,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onSend() }),
                    modifier = Modifier
                        .weight(1f)
                        // Grows with the text and then stops. One line at rest,
                        // five at most — past that the conversation above is
                        // being eaten by the thing used to add to it.
                        .heightIn(min = 44.dp, max = 140.dp)
                        .padding(vertical = 11.dp),
                    decorationBox = { field ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (text.isEmpty()) {
                                Text(
                                    str.doubt.hint,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = InkLow,
                                )
                            }
                            field()
                        }
                    },
                )

                Spacer(Modifier.width(8.dp))

                SendStopButton(
                    busy = busy,
                    enabled = canSend,
                    onSend = onSend,
                    onStop = onStop,
                )
            }
        }

        // Chips below the pill, not inside it. Opening the tray should not
        // change the shape of the thing you are typing into.
    }
}

@Composable
private fun RoundButton(
    fill: Color,
    onClick: () -> Unit,
    description: String,
    content: @Composable () -> Unit,
) {
    // The button pressed on every single message with nothing on it at all —
    // flat clickableNoRipple, no scale, no highlight. Of every static surface
    // found while chasing "the chat has no liquid motion", this is the one
    // that should have moved first: it is the highest-frequency touch in the
    // whole screen.
    //
    // A centre bloom rather than LiquidGlass's sliding specular. That slide
    // reads finger position across a wide bar; a 40dp circle has no
    // meaningful left-versus-right, so tracking touchX here would just jitter.
    // What a small round control does under a tap — Siri's own mic button
    // included — is bloom from the middle and fade, which is a radius and an
    // alpha, not a position.
    val press = remember { MutableInteractionSource() }
    val down by press.collectIsPressedAsState()
    val squish by animateFloatAsState(
        targetValue = if (down) 0.88f else 1f,
        // Same spring as LiquidGlass — one physics for every glass control in
        // the app rather than a different feel per screen.
        animationSpec = spring(dampingRatio = 0.75f, stiffness = 400f),
        label = "roundSquish",
    )
    val bloom by animateFloatAsState(
        targetValue = if (down) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.75f, stiffness = 400f),
        label = "roundBloom",
    )
    Box(
        Modifier
            .size(40.dp)
            .graphicsLayer { scaleX = squish; scaleY = squish }
            .clip(CircleShape)
            .background(fill)
            .drawWithContent {
                drawContent()
                if (bloom > 0.01f) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.38f * bloom),
                        radius = size.minDimension * 0.5f * bloom,
                    )
                }
            }
            .border(2.dp, Ink, CircleShape)
            .clickableNoRipple(press) { onClick() }
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) { content() }
}

/**
 * One option in the plus tray.
 *
 * Locked options are shown rather than hidden. Someone who cannot see a feature
 * cannot decide they want it, and this app's whole paid tier is things it can
 * already almost do.
 */
/**
 * One line in the attach tray: a drawn glyph, a name, and a lock if it is paid.
 *
 * The glyph is a TileObject rather than a Material icon for the same reason
 * the quick actions on Home are — a flat mono glyph next to a gradient tile
 * looks like it came from a different app.
 */
@Composable
private fun AttachRow(
    art: TileArt,
    glyphFill: Color,
    label: String,
    unlocked: Boolean,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickableNoRipple(remember { MutableInteractionSource() }) { onClick() }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        TileObject(
            art = art,
            fill = if (unlocked) glyphFill else InkLow,
            size = 26.dp,
        )
        Spacer(Modifier.width(12.dp))
        Text(
            label,
            style = MaterialTheme.typography.titleMedium,
            color = if (unlocked) Ink else InkLow,
            modifier = Modifier.weight(1f),
        )
        if (!unlocked) {
            Icon(
                Icons.Filled.Lock,
                contentDescription = null,
                tint = InkLow,
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

/**
 * Send, until there is something to stop.
 *
 * One button in one place, because a stop control that appears elsewhere is one
 * the thumb has to go looking for while it is already resting here.
 */
@Composable
private fun SendStopButton(
    busy: Boolean,
    enabled: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val live = busy || enabled
    val scale by animateFloatAsState(
        targetValue = if (busy) 1.06f else 1f,
        animationSpec = Motion.bouncy(),
        label = "scale",
    )
    val spoken = if (busy) str.doubt.stop else str.doubt.send

    Box(
        Modifier
            .scale(scale)
            .size(44.dp)
            .clip(CircleShape)
            .background(if (busy) Tang.fill else if (live) Mint.fill else Sunk)
            .border(2.dp, if (live) Ink else InkLow, CircleShape)
            .clickableNoRipple(remember { MutableInteractionSource() }, enabled = live) {
                if (busy) onStop() else { haptics.tick(); onSend() }
            }
            .semantics { contentDescription = spoken },
        contentAlignment = Alignment.Center,
    ) {
        if (busy) {
            // A square, drawn rather than iconified: two shapes on a page, and
            // it reads as stop everywhere in the world.
            Spacer(
                Modifier
                    .size(15.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Ink),
            )
        } else {
            Icon(
                Icons.Filled.Send,
                contentDescription = null,
                tint = if (live) Mint.on else InkLow,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

/** Thumbnail chip for a pending camera/gallery/PDF page. */
@Composable
fun AttachPreview(
    jpegB64: String?,
    label: String?,
    onClear: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Box(modifier.size(64.dp)) {
        JpegThumb(jpegB64, Modifier.size(64.dp))
        if (onClear != null) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(CreamCard)
                    .border(1.5.dp, Ink, CircleShape)
                    .clickableNoRipple(remember { MutableInteractionSource() }) { onClear() },
                contentAlignment = Alignment.Center,
            ) {
                Text("×", style = MaterialTheme.typography.labelSmall, color = Ink)
            }
        }
    }
}

@Composable
fun JpegThumb(jpegB64: String?, modifier: Modifier = Modifier) {
    val bmp = remember(jpegB64) {
        if (jpegB64.isNullOrBlank()) null
        else runCatching {
            val bytes = Base64.decode(jpegB64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }.getOrNull()
    }
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier
            .clip(shape)
            .background(Sunk)
            .border(1.5.dp, Ink, shape),
        contentAlignment = Alignment.Center,
    ) {
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.Crop,
            )
        } else {
            TileObject(art = TileArt.Photo, fill = Sky.fill, size = 22.dp)
        }
    }
}
