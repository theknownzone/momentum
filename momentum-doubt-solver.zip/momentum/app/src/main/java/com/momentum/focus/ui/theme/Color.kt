package com.momentum.focus.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * Which paper the app is printed on.
 *
 * One flag, read by the colour properties below. Every one of them is a getter
 * with no backing field, so all five hundred-odd places that already say `Ink`
 * or `CreamCard` pick up the change without being touched — the alternative
 * was rewriting fifty files by hand and hoping.
 *
 * A `mutableStateOf` rather than a plain var: Compose tracks the read wherever
 * it happens during composition, including inside a property getter, so
 * flipping this recomposes the whole app rather than requiring a restart.
 */
object Palette {
    /**
     * Dark. Named after what it is for rather than after "dark mode" — this is
     * not a system-following theme, it is a look you choose, and it stays
     * chosen when the phone switches to night.
     */
    var neon by mutableStateOf(false)
}

// ---- Paper -----------------------------------------------------------------
// Butter-yellow page with a printed grid, like an engineer's notebook — or, on
// neon, a near-black sheet with the grid glowing faintly through it.
val Cream: Color
    get() = if (Palette.neon) Color(0xFF0D0A16) else Color(0xFFFBF3D5)
val CreamCard: Color
    get() = if (Palette.neon) Color(0xFF191330) else Color(0xFFFFFDF2)
val GridLine: Color
    get() = if (Palette.neon) Color(0xFF2B2148) else Color(0xFFE8D98E)
val Sunk: Color
    get() = if (Palette.neon) Color(0xFF090713) else Color(0xFFF2E7BE)

// ---- Ink -------------------------------------------------------------------
// One near-black used for every border and every heading. Consistency of the
// outline is what makes the whole screen read as a single printed object. On
// neon it inverts to a near-white, and the same rule holds for the same reason.
val Ink: Color
    get() = if (Palette.neon) Color(0xFFF4F0FF) else Color(0xFF1A1A1A)
val InkMid: Color
    get() = if (Palette.neon) Color(0xFFA79ACF) else Color(0xFF8A7A3E)
val InkLow: Color
    get() = if (Palette.neon) Color(0xFF6E639A) else Color(0xFFB0A26A)
val GoldNeon = Color(0xFFFFD54A)

/**
 * A block of colour with a hard black outline.
 *
 * `fill` is the flat colour, `on` is the text that sits on it — always a very
 * dark shade of the same hue, never pure black, so the block still reads as
 * coloured rather than as a hole in the page.
 */
data class Sticker(
    val fill: Color,
    val edge: Color,
    val on: Color,
    val accent: Color = fill,
) {
    val brush: Brush get() = Brush.linearGradient(listOf(fill, fill))
    val bloom: Brush get() = Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
}

// The stickers do not flip. Bright blocks with dark text on them are correct
// on either paper, and the reference this look comes from is exactly that:
// saturated colour blocks on near-black. Their outline is captured at load
// time, which on neon leaves a dark edge under a bright fill — still visible,
// and it keeps the blocks feeling stuck onto the page rather than glowing out
// of it.
val Mint   = Sticker(Color(0xFF3FE28F), Ink, Color(0xFF0B3D26), Color(0xFF1D9E55))
val Butter = Sticker(Color(0xFFFFD84D), Ink, Color(0xFF4A3600), Color(0xFF8A6400))
val Tang   = Sticker(Color(0xFFFF8A5C), Ink, Color(0xFF4A1B08), Color(0xFFB24A1E))
val Lilac  = Sticker(Color(0xFFB9A7FF), Ink, Color(0xFF231457), Color(0xFF5A3FC0))
val Sky    = Sticker(Color(0xFF7FD4FF), Ink, Color(0xFF073048), Color(0xFF1A6E96))
val Candy  = Sticker(Color(0xFFFF9EC4), Ink, Color(0xFF4A0F2A), Color(0xFFB2306A))

// Old names kept so every screen keeps compiling.
val Emerald = Mint
val Gold = Butter
val Violet = Lilac
val Ember = Tang
val Ice = Sky
val Rose = Candy
val Jade = Mint
val Marigold = Butter
val Grape = Lilac
val Coral = Tang
val Cobalt = Sky
val Blush = Candy

val StickerCycle = listOf(Mint, Butter, Tang, Lilac, Sky, Candy)

fun stickerFor(seed: Int): Sticker = StickerCycle[Math.floorMod(seed, StickerCycle.size)]


/**
 * Lightens a colour toward white by [amount].
 *
 * Used to build the two-stop gradients on filled shapes. Every fill in the app
 * still starts from one of the palette colours above — the gradient is derived
 * from it rather than picked separately, so a shape lit at its crown is
 * unmistakably the same colour as the flat version of itself.
 */
fun Color.lighten(amount: Float): Color = Color(
    red + (1f - red) * amount,
    green + (1f - green) * amount,
    blue + (1f - blue) * amount,
    alpha,
)

/** Darkens a colour toward black by [amount]. The other half of a gradient. */
fun Color.darken(amount: Float): Color = Color(
    red * (1f - amount),
    green * (1f - amount),
    blue * (1f - amount),
    alpha,
)

/** A top-lit vertical gradient built from a single palette colour. */
fun Color.lit(): Brush = Brush.verticalGradient(
    listOf(lighten(0.24f), this, darken(0.08f))
)
