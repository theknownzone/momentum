package com.momentum.focus.ui.util

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import androidx.core.content.getSystemService

/**
 * Cheap phones keep the same features. They drop petals, festival bitmaps
 * and long splash so 4 GB / Helio devices stay usable.
 */
object DeviceProfile {

    /**
     * Worked out once. This was being called straight from composables and
     * from the petal renderer, so a system service lookup and a MemoryInfo
     * allocation ran on every recomposition and every frame — on precisely
     * the cheap phones the check exists to protect. The answer cannot change
     * while the process is alive, so it is settled once and kept.
     */
    @Volatile private var cached: Boolean? = null

    fun isLowEnd(context: Context): Boolean =
        cached ?: compute(context).also { cached = it }

    /**
     * Whether continuous background animation is worth its cost here.
     *
     * The flag existed and was honoured in exactly two places — the hero
     * weather and the splash — so a 3 GB phone was still running an infinite
     * gradient in the tab bar, a halftone field redrawn per frame, and a
     * ten-second cutscene of forty-four shards. The check was there; almost
     * nothing asked it.
     *
     * Named for what it decides rather than for the hardware, so call sites
     * read as a decision about the effect instead of a guess about the phone.
     */
    fun wantsAmbientMotion(context: Context): Boolean = !isLowEnd(context)

    /**
     * How many particles an effect should draw, from the count it would like.
     *
     * A third on a cheap phone. Halving was tried and is not enough: the cost
     * is the per-particle draw call, and these effects run every frame for as
     * long as the screen is up.
     */
    fun particles(context: Context, wanted: Int): Int =
        if (isLowEnd(context)) (wanted / 3).coerceAtLeast(6) else wanted

    private fun compute(context: Context): Boolean {
        val am = context.getSystemService<ActivityManager>() ?: return Build.VERSION.SDK_INT < 29
        if (am.isLowRamDevice) return true
        val mem = runCatching { ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) } }.getOrNull()
        val totalBytes = mem?.totalMem ?: 0L
        // A "4 GB" phone reports about 3.7 GB, so the cut is made in bytes
        // rather than on a truncated integer count of gigabytes.
        val fourGb = 4L * 1024L * 1024L * 1024L
        if (totalBytes in 1 until fourGb) return true
        return Build.VERSION.SDK_INT < 29
    }
}
