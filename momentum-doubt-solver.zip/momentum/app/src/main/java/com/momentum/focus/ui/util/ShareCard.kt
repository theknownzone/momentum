package com.momentum.focus.ui.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import androidx.core.content.FileProvider
import com.momentum.focus.data.AppData
import com.momentum.focus.data.unlockedCount
import java.io.File

/**
 * Builds a progress poster and hands it to the share sheet.
 *
 * Drawn straight onto a Bitmap rather than captured from the UI: screen
 * capture gives you whatever size the phone happens to be, while this is a
 * fixed 1080x1350 that looks right in WhatsApp and on a status.
 */
object ShareCard {

    private const val W = 1080
    private const val H = 1350

    /**
     * [backdrop] is an optional generated image painted behind the poster.
     *
     * Behind, and under a heavy cream wash, because that is the only safe place
     * for a generated picture on a card like this. The models available cannot
     * render digits or words reliably — Chutes says so about this chute itself
     * — so nothing that has to be read comes from them. The streak, the hours
     * and the date are drawn on top afterwards, by us, from stored numbers.
     *
     * Null is the normal case. The poster is complete without it and no share
     * ever waits on a network call.
     */
    fun share(
        context: Context,
        data: AppData,
        reclaimedMinutes: Int,
        backdrop: Bitmap? = null,
    ) {
        val bitmap = render(data, reclaimedMinutes, backdrop)
        val file = File(context.cacheDir, "momentum-progress.png")
        runCatching {
            file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }

            val uri = FileProvider.getUriForFile(
                context, "${context.packageName}.fileprovider", file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(
                    Intent.EXTRA_TEXT,
                    "My week on Momentum. ${data.earnedMinutes / 60}h focused, " +
                        "${data.streakDays} day streak.",
                )
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share progress"))
        }
    }

    private fun render(data: AppData, reclaimed: Int, backdrop: Bitmap? = null): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        val cream = Color.parseColor("#FBF3D5")
        val hasBackdrop = backdrop != null
        if (backdrop != null) {
            // Filled to the poster, centre-cropped, then washed out to a
            // texture. At full strength it would fight every line drawn over
            // it; at this alpha it reads as paper that happens to have
            // something on it, which is all a backdrop should ever be.
            val scale = maxOf(W.toFloat() / backdrop.width, H.toFloat() / backdrop.height)
            val dw = (backdrop.width * scale).toInt()
            val dh = (backdrop.height * scale).toInt()
            val scaled = Bitmap.createScaledBitmap(backdrop, dw, dh, true)
            c.drawBitmap(scaled, ((W - dw) / 2f), ((H - dh) / 2f), null)
            if (scaled !== backdrop) scaled.recycle()
            c.drawColor(Color.argb(214, 251, 243, 213))
        }
        val ink = Color.parseColor("#1A1A1A")
        val mint = Color.parseColor("#3FE28F")
        val butter = Color.parseColor("#FFD84D")
        val grid = Color.parseColor("#E8D98E")

        // Only when there is nothing underneath. drawColor fills the whole
        // canvas at full opacity, so running it unconditionally painted over
        // the backdrop that had just been drawn — the same mistake as an
        // opaque panel covering the ghost word on MyAi, one layer down.
        if (!hasBackdrop) c.drawColor(cream)

        val gridPaint = Paint().apply { color = grid; strokeWidth = 2f }
        var g = 0f
        while (g < W) { c.drawLine(g, 0f, g, H.toFloat(), gridPaint); g += 90f }
        g = 0f
        while (g < H) { c.drawLine(0f, g, W.toFloat(), g, gridPaint); g += 90f }

        val bold = Paint().apply {
            color = ink
            isAntiAlias = true
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val body = Paint().apply {
            color = ink
            isAntiAlias = true
            typeface = Typeface.DEFAULT
        }

        fun card(top: Float, height: Float, fill: Int) {
            val rect = RectF(70f, top, W - 70f, top + height)
            c.drawRoundRect(rect, 40f, 40f, Paint().apply { color = fill; isAntiAlias = true })
            c.drawRoundRect(rect, 40f, 40f, Paint().apply {
                color = ink; style = Paint.Style.STROKE; strokeWidth = 8f; isAntiAlias = true
            })
        }

        bold.textSize = 46f
        c.drawText("MOMENTUM", 80f, 130f, bold)
        body.textSize = 40f
        body.color = Color.parseColor("#8A7A3E")
        c.drawText("${data.userName}'s week", 80f, 190f, body)

        // Headline card: the one number worth showing anyone.
        card(240f, 380f, mint)
        bold.textSize = 40f
        bold.color = Color.parseColor("#0B3D26")
        c.drawText("TIME RECLAIMED", 130f, 330f, bold)
        bold.textSize = 190f
        c.drawText("${reclaimed / 60}h ${reclaimed % 60}m", 130f, 500f, bold)
        body.textSize = 38f
        body.color = Color.parseColor("#0B3D26")
        c.drawText("versus my own baseline", 130f, 560f, body)

        card(660f, 250f, butter)
        bold.color = Color.parseColor("#4A3600")
        bold.textSize = 36f
        c.drawText("FOCUSED", 130f, 740f, bold)
        bold.textSize = 110f
        c.drawText("${data.earnedMinutes / 60}h", 130f, 850f, bold)

        bold.textSize = 36f
        c.drawText("STREAK", 620f, 740f, bold)
        bold.textSize = 110f
        c.drawText("${data.streakDays}d", 620f, 850f, bold)

        card(950f, 220f, Color.parseColor("#FFFDF2"))
        bold.color = ink
        bold.textSize = 36f
        c.drawText("LEVEL ${data.level}", 130f, 1030f, bold)
        body.color = Color.parseColor("#8A7A3E")
        body.textSize = 36f
        c.drawText("${data.unlockedCount} badges earned", 130f, 1090f, body)

        val left = data.daysToExam
        if (left != null && left >= 0) {
            bold.textSize = 34f
            bold.color = Color.parseColor("#B24A1E")
            c.drawText(
                "$left days to ${data.examName.ifBlank { "the exam" }}",
                130f, 1140f, bold,
            )
        }

        body.textSize = 32f
        body.color = Color.parseColor("#B0A26A")
        c.drawText("Earned, not claimed.", 80f, 1280f, body)

        return bmp
    }
}
