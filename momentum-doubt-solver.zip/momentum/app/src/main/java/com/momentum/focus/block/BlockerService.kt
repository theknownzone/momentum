package com.momentum.focus.block

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.getSystemService
import com.momentum.focus.MainActivity
import com.momentum.focus.R
import com.momentum.focus.data.AppStore
import com.momentum.focus.data.ScreenTime
import com.momentum.focus.ui.util.StudyNudge
import com.momentum.focus.ui.util.UpdateNotice
import com.momentum.focus.ui.util.Updater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Watches the foreground app and throws up the shield when a blocked one opens.
 *
 * Polling UsageStats is used rather than an AccessibilityService on purpose:
 * accessibility can read the whole screen, Play reviews it harshly, and it is
 * overkill when all we need is the current package name.
 *
 * The poll is 700ms. Faster drains battery for no gain; slower and the user
 * gets a visible second of Instagram before the shield lands, which is exactly
 * the second that matters.
 */
class BlockerService : Service() {

    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    companion object {
        const val CHANNEL = "momentum_blocker"
        const val NOTIF_ID = 41

        /** Kept up to date by the app so the notification can show real data. */
        @Volatile var balanceMinutes: Int = 0
        @Volatile var earnedTodayMinutes: Int = 0
        @Volatile var streakDays: Int = 0

        /** Packages currently blocked. Set by the app when settings change. */
        @Volatile var blocked: Set<String> = emptySet()

        /** package -> minutes per day. Optional, set by the app. */
        @Volatile var dailyCaps: Map<String, Int> = emptyMap()

        /** Study apps, for the offer to start a session. Set by the app. */
        @Volatile var studyPackages: Set<String> = emptySet()

        /** True while a session is running, so the offer stays quiet. */
        @Volatile var sessionRunning: Boolean = false

        /**
         * When the running session ends, as persisted by the app.
         *
         * Zero when nothing is running. Read from the store by the service so
         * it survives a restart with no UI; see onCreate.
         */
        @Volatile var sessionEndsAtMs: Long = 0L

        @Volatile var pactLive: Boolean = false

        /**
         * Whether the user is on Crown. Together with [sessionRunning] this is
         * the only condition under which Settings is blocked.
         */
        @Volatile var crownActive: Boolean = false

        /** Packages that have already burned their cap today. */
        @Volatile private var overCap: Set<String> = emptySet()

        fun isOverCap(pkg: String): Boolean = pkg in overCap

        /** package -> epoch millis until which it is temporarily allowed. */
        private val allowances = mutableMapOf<String, Long>()

        fun allow(pkg: String, minutes: Int) {
            synchronized(allowances) {
                allowances[pkg] = System.currentTimeMillis() + minutes * 60_000L
            }
        }

        /**
         * Never blocked, whatever the settings say.
         *
         * A pact cannot be shortened, so a blocklist that swallowed the dialer
         * meant a locked-out phone with no way to call anyone for hours. These
         * are checked above the blocklist and above the daily cap, so no
         * combination of user choices can take them away.
         */
        private val NEVER_BLOCK = listOf(
            "com.android.dialer", "com.google.android.dialer", "com.samsung.android.dialer",
            "com.android.server.telecom", "com.android.incallui",
            "com.android.contacts", "com.google.android.contacts",
            "com.android.emergency", "com.google.android.apps.safetyhub",
            "com.android.mms", "com.google.android.apps.messaging",
            "com.google.android.apps.maps",
            "com.android.deskclock", "com.google.android.deskclock",
        )

        private const val SETTINGS_PKG = "com.android.settings"
        private val SETTINGS_PKGS = listOf(
            "com.android.settings",
            "com.android.settings.intelligence",
            "com.xiaomi.misettings",
            "com.miui.securitycenter",
            "com.miui.securityadd",
            "com.miui.securitycore",
            "com.miui.notification",
            "com.miui.permcenter",
            "com.lbe.security.miui",
            "com.iqoo.secure",
            "com.coloros.phonemanager",
            "com.oplus.safecenter",
            "com.samsung.android.settings",
            "com.samsung.android.lool",
        )
        private fun isSettingsPkg(pkg: String): Boolean {
            val p = pkg.lowercase()
            return SETTINGS_PKGS.any { pkg == it || pkg.startsWith("$it.") } ||
                "settings" in p ||
                "securitycenter" in p ||
                "permcenter" in p ||
                "misettings" in p
        }

        /**
         * Settings is blocked only while a Crown session is actually running.
         *
         * It used to sit in [NEVER_BLOCK] permanently, and that was the right
         * default: Settings is where you turn this app off. Crown without it
         * is theatre, though — anyone can walk to Accessibility and switch the
         * guard off mid-session.
         *
         * So it is blocked for the length of a session and no longer. Crown
         * already stops you uninstalling and arms a pact that cannot be
         * shortened; if Settings were sealed for the pact's whole run, a stuck
         * shield would leave someone with no way out of their own phone for up
         * to thirty days. A session is at most a couple of hours, and ending it
         * from inside the app unblocks Settings immediately — see
         * [com.momentum.focus.block.ShieldActivity], which says exactly that.
         *
         * The phone, emergency, contacts and clock stay untouchable throughout.
         */
        fun isSettingsLockedNow(): Boolean =
            crownActive && (sessionRunning || sessionEndsAtMs > System.currentTimeMillis())

        fun isNeverBlocked(pkg: String): Boolean {
            if (isSettingsPkg(pkg)) {
                return !isSettingsLockedNow()
            }
            return pkg == "com.android.systemui" ||
                NEVER_BLOCK.any { pkg == it || pkg.startsWith("$it.") } ||
                pkg.contains("dialer", true) ||
                pkg.contains("telecom", true) ||
                pkg.contains("emergency", true)
        }

        private fun isAllowed(pkg: String): Boolean = synchronized(allowances) {
            val until = allowances[pkg] ?: return false
            if (System.currentTimeMillis() > until) {
                allowances.remove(pkg); false
            } else true
        }

        fun start(context: Context) {
            val intent = Intent(context, BlockerService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            // Deliberate stop, so the gap that follows is not an OEM kill.
            Heartbeat.disarm(context)
            context.stopService(Intent(context, BlockerService::class.java))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())

        // The service reads its own state, rather than waiting to be told.
        //
        // Every field below used to be written from one place only: a
        // LaunchedEffect in MainActivity. That is correct exactly as long as
        // the UI has run since the process started — and the one case this
        // service exists for is the case where it has not.
        //
        // START_STICKY brings the service back after an OEM kill without
        // bringing the activity back. Fresh process, so the companion object
        // is at its defaults again: `blocked` is an empty set, `dailyCaps` is
        // empty, `crownActive` is false. The tray notification returns and
        // looks exactly right, the loop runs, and nothing is blocked.
        //
        // Worse, it conceals itself. The heartbeat below starts stamping again
        // straight away, so Heartbeat.deadMinutes reads zero and the "shield
        // was killed" card on Home never appears. The shield is off, the app
        // says it is on, and there is nothing on screen that disagrees. This
        // is the silent failure the whole blocking package is written against.
        //
        // Collecting the store here makes the service the owner of its own
        // state. MainActivity still assigns the same values; they now agree
        // instead of one of them being the only source.
        scope.launch {
            runCatching {
                AppStore(this@BlockerService).data.collect { d ->
                    blocked = d.blockedPackages
                    dailyCaps = d.dailyCapMinutes
                    balanceMinutes = d.balanceMinutes
                    earnedTodayMinutes = d.minutesToday
                    streakDays = d.streakDays
                    studyPackages = d.studyPackages
                    pactLive = d.pactLive
                    crownActive = d.focusLevel >= 3 && d.crownMode
                    // The timer lives in the ViewModel, which does not exist
                    // in a UI-less process. liveSessionEndsAtMs is the
                    // persisted half of it and is written on both start and
                    // pause, so it is the only version of "a session is
                    // running" this service can read on its own.
                    //
                    // Held as the timestamp, not as a boolean. A session can
                    // end by its clock simply running out, with nothing
                    // written to the store to announce it — so a boolean
                    // latched here would stay true afterwards and keep
                    // Settings sealed. The loop below turns it into an answer
                    // every cycle instead.
                    sessionEndsAtMs = d.liveSessionEndsAtMs
                }
            }
        }

        job = scope.launch {
            var lastShielded = ""
            var lastFiredAt = 0L
            var lastNotify = 0L
            var lastBeat = 0L
            var lastCapScan = 0L
            var lastUpdateScan = 0L
            while (true) {
                // Turned into an answer here rather than latched in the
                // collector, so a session that simply runs out of clock stops
                // counting as running even though nothing was written to the
                // store to say so.
                //
                // While the UI is alive MainActivity assigns this too, from
                // timer.running, and the two agree: starting a session writes
                // liveSessionEndsAtMs and pausing writes zero. The store write
                // is asynchronous, so for a fraction of a second after a pause
                // this can still read true — which errs towards the shield
                // staying up, which is the right way for it to be wrong.
                if (sessionEndsAtMs > 0L) {
                    sessionRunning = sessionEndsAtMs > System.currentTimeMillis()
                }
                // Proof of life. If these stamps stop while the shield is armed,
                // the OEM killed us and the app can say so when it next opens.
                if (System.currentTimeMillis() - lastBeat > 20_000) {
                    lastBeat = System.currentTimeMillis()
                    runCatching { Heartbeat.beat(this@BlockerService) }
                }
                val current = foregroundPackage()
                // The foreground package is already read here every cycle, so
                // the offer costs nothing beyond a couple of comparisons.
                runCatching {
                    StudyNudge.onForeground(
                        context = this@BlockerService,
                        pkg = current,
                        studyPackages = studyPackages,
                        studying = sessionRunning,
                    )
                }
                // Every twenty seconds. It was once a minute, which on a
                // fifteen minute cap means the app stays open for up to a
                // minute past the limit — long enough that the cap looks like
                // it did not fire at all.
                if (System.currentTimeMillis() - lastCapScan > 20_000) {
                    lastCapScan = System.currentTimeMillis()
                    runCatching {
                        val caps = dailyCaps
                        overCap = if (caps.isEmpty()) emptySet() else {
                            val used = ScreenTime.minutesTodayFor(
                                this@BlockerService, caps.keys,
                            )
                            caps.filter { (pkg, cap) -> (used[pkg] ?: 0) >= cap }.keys
                        }
                    }
                }

                // The update check used to run only when Home was composed, so
                // a release landed silently until the app was next opened — and
                // the app being closed is exactly when an update is convenient.
                // This service is already alive, so it does the asking.
                if (System.currentTimeMillis() - lastUpdateScan > 4 * 60 * 60 * 1000L) {
                    lastUpdateScan = System.currentTimeMillis()
                    runCatching {
                        Updater.check(this@BlockerService)?.let {
                            UpdateNotice.show(this@BlockerService, it.version)
                        }
                    }
                }

                val cappedOut = current != null && isOverCap(current)
                val settingsNow = current != null && isSettingsPkg(current) && isSettingsLockedNow()
                val blockedNow = current != null &&
                    current != packageName &&
                    !isNeverBlocked(current) &&
                    (
                        cappedOut ||
                            (current in blocked && !isAllowed(current)) ||
                            settingsNow
                        )

                if (blockedNow && !weAreFront) {
                    val now = System.currentTimeMillis()
                    // Only launch when the blocked app is in front AND our
                    // shield is not. Re-firing every 2s while the shield was
                    // already up rebuilt the activity on every poll — the
                    // flicker the user called refresh.
                    if (current != lastShielded || now - lastFiredAt > 2500) {
                        lastShielded = current!!
                        lastFiredAt = now
                        launchShield(current)
                    }
                } else if (current != null && current != packageName) {
                    lastShielded = ""
                }
                // Cheap enough to redraw once a minute; the tray line then
                // stays current instead of freezing at whatever it was when
                // the service started.
                if (System.currentTimeMillis() - lastNotify > 60_000) {
                    lastNotify = System.currentTimeMillis()
                    runCatching {
                        getSystemService<NotificationManager>()
                            ?.notify(NOTIF_ID, buildNotification())
                    }
                }
                delay(350)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        job?.cancel()
        super.onDestroy()
    }

    /**
     * queryEvents rather than queryUsageStats: the latter reports aggregate
     * totals that lag by minutes, which is useless for "what is on screen now".
     */
    /** Survives polls that see no new event. See below for why that matters. */
    @Volatile private var lastKnownForeground: String? = null
    @Volatile private var weAreFront: Boolean = false

    /**
     * What is in front right now.
     *
     * This used to return only what it found in a ten second window and null
     * otherwise, which quietly meant "nothing is in front" every time an app
     * had already been open for a while, or whenever UsageStats reported the
     * switch late — and a slow splash screen is long enough for both. The app
     * would open, the one event would fall outside the window, and the shield
     * would never fire for as long as it stayed open.
     *
     * The window is also widened, because UsageStats batches its writes and a
     * ten second view can miss a switch that happened eleven seconds ago.
     */
    private fun foregroundPackage(): String? {
        val usage = getSystemService<UsageStatsManager>() ?: return null
        val now = System.currentTimeMillis()
        val events = runCatching {
            usage.queryEvents(now - 60_000, now)
        }.getOrNull() ?: return lastKnownForeground

        val event = UsageEvents.Event()
        var latest: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            when (event.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> {
                    if (event.packageName == packageName) {
                        weAreFront = true
                    } else {
                        weAreFront = false
                        latest = event.packageName
                    }
                }
                // A pause with nothing taking its place means the screen went
                // off or the launcher took over; either way the app is no
                // longer in front and the remembered value has to clear.
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    if (event.packageName == packageName) weAreFront = false
                    if (event.packageName == latest) latest = null
                }
                else -> Unit
            }
        }
        if (latest != null) lastKnownForeground = latest
        return latest ?: lastKnownForeground
    }

    private fun launchShield(pkg: String) {
        val intent = Intent(this, ShieldActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT,
            )
            putExtra(ShieldActivity.EXTRA_PACKAGE, pkg)
        }
        runCatching { startActivity(intent) }
    }

    private fun buildNotification(): Notification {
        val manager = getSystemService<NotificationManager>()
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL,
                "Shield",
                NotificationManager.IMPORTANCE_MIN,
            ).apply { setShowBadge(false) }
            manager?.createNotificationChannel(channel)
        }

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE,
        )

        val rupees = balanceMinutes
        val earned = earnedTodayMinutes

        // A blocker notification that only says "blocking" reads like spyware
        // sitting in the tray. Showing what has been earned makes the same
        // line read as a study app keeping score.
        val headline = when {
            earned > 0 -> "₹$rupees banked · +₹$earned today"
            rupees > 0 -> "₹$rupees in your wallet"
            else -> "Start a session to earn"
        }
        val detail = buildString {
            append("${blocked.size} apps guarded")
            if (streakDays > 0) append(" · $streakDays day streak")
            append("\n${rupees / 60}h ${rupees % 60}m of screen time already paid for.")
        }

        return NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle(headline)
            .setContentText(detail.substringBefore('\n'))
            .setStyle(NotificationCompat.BigTextStyle().bigText(detail))
            .setSubText("Momentum")
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setShowWhen(false)
            .setContentIntent(open)
            .build()
    }
}
