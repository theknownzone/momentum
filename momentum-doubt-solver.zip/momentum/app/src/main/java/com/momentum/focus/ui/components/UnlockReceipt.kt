package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.util.PrintSound
import com.momentum.focus.ui.util.Receipt
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * A deliberately long 20-second premium unlock sequence.
 *
 * This is not a generic "premium" splash. It behaves like a tiny product
 * reveal: boot -> calibrate -> print -> colour pass -> verify -> settle.
 * The receipt is physically fed out while a scan beam and printer indicators
 * track the same playhead. The result is longer, but every second has a job.
 */
private const val RUN_MS = 20_000L
private const val FEED_START = 0.15f
private const val FEED_END = 0.62f

@Composable
fun UnlockReceipt(data: AppData, onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val context = LocalContext.current
    val progress = remember { Animatable(0f) }
    val lift = remember { Animatable(1f) }
    var saved by remember { mutableStateOf<String?>(null) }
    var savedShown by remember { mutableStateOf(false) }
    var skipRequested by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        PrintSound.init(context)
        // One light boot tick. The old sequence vibrated at the beginning,
        // every print milestone, and again at the end; the result was a phone
        // that felt busy instead of a printer. Major state changes only.
        haptics.tick()
        progress.animateTo(0.05f, tween(1000, easing = FastOutSlowInEasing))
        // Feed a genuinely blank slip first. The paper exists before the ink.
        progress.animateTo(0.18f, tween(2500, easing = FastOutSlowInEasing))

        haptics.press()
        PrintSound.play(loop = true)
        // This is the actual print pass. The paper keeps feeding while the
        // print mask reveals the receipt from top to bottom.
        progress.animateTo(0.78f, tween(11_500, easing = LinearEasing))
        PrintSound.stop()

        haptics.confirm()
        progress.animateTo(0.92f, tween(2500, easing = FastOutSlowInEasing))
        haptics.unlock()
        progress.animateTo(1f, tween(1500, easing = FastOutSlowInEasing))

        if (saved == null) {
            saved = Receipt.saveToDownloads(context, data)
            savedShown = true
        }
        delay(500)
        lift.animateTo(0f, tween(500, easing = FastOutSlowInEasing))
        onDone()
    }

    LaunchedEffect(skipRequested) {
        if (!skipRequested) return@LaunchedEffect
        PrintSound.stop()
        if (saved == null) {
            saved = Receipt.saveToDownloads(context, data)
            savedShown = true
        }
        onDone()
    }

    DisposableEffect(Unit) {
        onDispose { PrintSound.stop() }
    }

    val p = progress.value
    // Paper emerges blank first. Printing is a separate playhead and starts
    // only after the paper is visibly outside the slot.
    val feed = ((p - 0.05f) / 0.20f).coerceIn(0f, 1f)
    val printed = ((p - 0.18f) / 0.60f).coerceIn(0f, 1f)
    val status = when {
        p < 0.05f -> "POWERING PRINTER"
        p < 0.18f -> "FEEDING BLANK PAPER"
        p < 0.78f -> "PRINTING YOUR RECEIPT"
        p < 0.92f -> "VERIFYING PURCHASE"
        else -> "PREMIUM UNLOCKED"
    }

    Box(
        Modifier
            .fillMaxSize()
            .alpha(lift.value)
            .background(Color(0xFF090A10))
            .drawBehind { drawUnlockAtmosphere(p) },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 22.dp),
        ) {
            Text(
                "MOMENTUM / PREMIUM",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = GoldNeon.copy(alpha = 0.86f),
                letterSpacing = 1.8.sp,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                status,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.72f),
            )
            Spacer(Modifier.height(18.dp))

            Box(
                Modifier
                    .width(316.dp)
                    .height(472.dp),
                contentAlignment = Alignment.TopCenter,
            ) {
                // The paper is fed down as a physical object. It starts blank;
                // Slip's own mask controls when the ink appears.
                Box(
                    Modifier
                        .padding(top = 36.dp)
                        .graphicsLayer {
                            val maxTravel = 310.dp.toPx()
                            translationY = -maxTravel * (1f - feed)
                            alpha = if (feed > 0.005f) 1f else 0f
                        },
                ) {
                    Slip(data, printed)
                }

                // Printer body stays in front of the paper, like a real slot.
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(74.dp)
                        .align(Alignment.TopCenter)
                        .clip(RoundedCornerShape(24.dp))
                        .drawBehind {
                            drawRoundRect(
                                brush = Brush.verticalGradient(
                                    listOf(Color(0xFF30323B), Color(0xFF111218)),
                                ),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(24.dp.toPx(), 24.dp.toPx()),
                            )
                            drawRoundRect(
                                color = Color.White.copy(alpha = 0.10f),
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.2.dp.toPx()),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(24.dp.toPx(), 24.dp.toPx()),
                            )
                            // The head moves only while ink is being laid down.
                            val head = size.width * (0.18f + printed * 0.64f)
                            val active = if (p in 0.18f..0.78f) 1f else 0.35f
                            drawCircle(GoldNeon.copy(alpha = 0.8f * active), 4.dp.toPx(), Offset(head, 22.dp.toPx()))
                            drawCircle(Mint.fill.copy(alpha = 0.8f * active), 3.dp.toPx(), Offset(head + 18.dp.toPx(), 22.dp.toPx()))
                            drawRect(
                                color = Color.Black.copy(alpha = 0.72f),
                                topLeft = Offset(size.width * 0.10f, size.height * 0.54f),
                                size = Size(size.width * 0.80f, 18.dp.toPx()),
                            )
                            val beamY = size.height * (0.54f + 0.06f * ((p * 9f) % 1f))
                            drawRect(
                                brush = Brush.horizontalGradient(
                                    listOf(Color.Transparent, Sky.fill.copy(alpha = 0.48f), Lilac.fill.copy(alpha = 0.34f), Color.Transparent),
                                ),
                                topLeft = Offset(size.width * 0.12f, beamY),
                                size = Size(size.width * 0.76f, 2.dp.toPx()),
                            )
                        },
                )
            }

            Spacer(Modifier.height(8.dp))
            Text(
                if (savedShown && saved != null) "Receipt saved · ${saved!!.takeLast(12)}"
                else if (p < 0.18f) "Paper feed · ${((feed * 100).toInt()).coerceIn(0, 100)}%"
                else "Ink pass · ${((printed * 100).toInt()).coerceIn(0, 100)}%",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.50f),
            )
            Spacer(Modifier.height(18.dp))

            Box(
                Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.08f))
                    .drawBehind {
                        drawRoundRect(
                            brush = Brush.horizontalGradient(
                                listOf(Tang.fill, GoldNeon, Sky.fill, Lilac.fill, Mint.fill),
                            ),
                            size = Size(size.width * p.coerceIn(0f, 1f), size.height),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx(), 2.dp.toPx()),
                        )
                    },
            )
            Spacer(Modifier.height(16.dp))

            if (p < 0.92f) {
                Text(
                    "20s unlock sequence · tap to skip",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = Color.White.copy(alpha = 0.35f),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.06f))
                        .then(
                            Modifier.clickableNoRipple(
                                remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            ) { skipRequested = true },
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawUnlockAtmosphere(p: Float) {
    val pulse = 0.55f + 0.45f * kotlin.math.sin(p * kotlin.math.PI.toFloat() * 12f).let { (it + 1f) / 2f }
    val r = size.minDimension * (0.25f + 0.16f * pulse)
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                GoldNeon.copy(alpha = 0.08f + 0.05f * pulse),
                Sky.fill.copy(alpha = 0.045f),
                Color.Transparent,
            ),
            center = Offset(size.width * 0.50f, size.height * 0.44f),
            radius = r,
        ),
        radius = r,
        center = Offset(size.width * 0.50f, size.height * 0.44f),
    )
    // End burst: sparse rays instead of a particle storm, so the receipt stays
    // readable and the final beat still feels expensive rather than noisy.
    if (p > 0.88f) {
        val q = ((p - 0.88f) / 0.12f).coerceIn(0f, 1f)
        val cx = size.width / 2f
        val cy = size.height * 0.44f
        repeat(18) { i ->
            val a = i / 18f * kotlin.math.PI.toFloat() * 2f
            val inner = size.minDimension * (0.12f + 0.04f * q)
            val outer = inner + size.minDimension * 0.11f * q
            drawLine(
                color = listOf(GoldNeon, Sky.fill, Lilac.fill, Mint.fill, Tang.fill)[i % 5].copy(alpha = 0.72f * (1f - q * 0.35f)),
                start = Offset(cx + kotlin.math.cos(a) * inner, cy + kotlin.math.sin(a) * inner),
                end = Offset(cx + kotlin.math.cos(a) * outer, cy + kotlin.math.sin(a) * outer),
                strokeWidth = 2.dp.toPx(),
            )
        }
    }
}

/**
 * The slip itself. Monospace and dotted rules, matching the saved PNG.
 *
 * [printed] is the same feed value driving the outer translation. Slip masks
 * its own lower portion in white while printed < 1, so the paper is not just
 * sliding into frame already finished -- each line's turn to appear tracks
 * the same motor pulse the haptics are ticking to.
 */
@Composable
private fun Slip(data: AppData, printed: Float) {
    val stamp = remember {
        LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy · HH:mm"))
    }
    // The app's own paper, not thermal-till white.
    //
    // Plain black-on-white was the honest thermal reference, and it was also
    // the one screen in the whole app with none of its colour language on
    // it -- every card elsewhere is cream with a coloured header band and one
    // accent doing the talking. A Tang header and a Sky-tinted key box are
    // the same move Plans and Home already make; this just brings the
    // receipt in line with them instead of leaving it looking imported.
    Column(
        Modifier
            .width(272.dp)
            .clip(RoundedCornerShape(10.dp))
            .drawWithContent {
                drawContent()
                if (printed < 0.999f) {
                    // Ink is printed from the top down. The paper is already
                    // physically present, so the unprinted lower section is
                    // simply the same blank paper colour.
                    val cut = (size.height * printed).coerceIn(0f, size.height)
                    val headerPx = 64.dp.toPx()
                    if (cut < headerPx) {
                        drawRect(
                            color = Tang.fill,
                            topLeft = Offset(0f, cut),
                            size = Size(size.width, headerPx - cut),
                        )
                        drawRect(
                            color = CreamCard,
                            topLeft = Offset(0f, headerPx),
                            size = Size(size.width, size.height - headerPx),
                        )
                    } else {
                        drawRect(
                            color = CreamCard,
                            topLeft = Offset(0f, cut),
                            size = Size(size.width, size.height - cut),
                        )
                    }
                }
            },
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Tang.fill)
                .padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "MOMENTUM",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = Ink,
            )
            Text(
                "focus, banked",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Ink.copy(alpha = 0.75f),
            )
        }

        Column(
            Modifier
                .background(CreamCard)
                .padding(horizontal = 18.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(stamp, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = InkMid)

            Spacer(Modifier.height(12.dp))
            DottedRule()
            Spacer(Modifier.height(12.dp))

            Text(
                "LICENCE KEY",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = InkMid,
            )
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Sky.fill.copy(alpha = 0.30f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            ) {
                Text(
                    License.pretty(data.licenseKey),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Ink,
                )
            }

            Spacer(Modifier.height(14.dp))
            DottedRule()
            Spacer(Modifier.height(12.dp))

            SlipRow("Item", "Lifetime")
            SlipRow("Holder", data.userName.ifBlank { "friend" })
            SlipRow("Focused", "${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m")
            // PAID in Mint -- the same colour this app already reaches for
            // whenever something is confirmed and settled.
            SlipRow("Status", "PAID", valueColor = Mint.accent)

            Spacer(Modifier.height(12.dp))
            DottedRule()
            Spacer(Modifier.height(10.dp))
            Text(
                "Blocking stays free. Always.",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = InkMid,
            )
        }
    }
}

@Composable
private fun SlipRow(label: String, value: String, valueColor: Color = Ink) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = InkMid)
        Text(
            value,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = valueColor,
        )
    }
}

@Composable
private fun DottedRule() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(1.dp)
            .drawBehind {
                var x = 0f
                while (x < size.width) {
                    drawRect(
                        color = Ink.copy(alpha = 0.45f),
                        topLeft = Offset(x, 0f),
                        size = androidx.compose.ui.geometry.Size(3f, size.height),
                    )
                    x += 7f
                }
            },
    )
}
