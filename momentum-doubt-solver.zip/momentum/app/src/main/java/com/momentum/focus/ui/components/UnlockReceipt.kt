package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.util.PrintSound
import com.momentum.focus.ui.util.Receipt
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * The unlock moment: a slip printing out of a slot, then saving itself.
 *
 * Staged like a small product reveal -- boot, calibrate, print, verify,
 * unlocked -- rather than one flat "printing" state, because that staging is
 * what made an earlier version of this feel like an actual machine working
 * rather than a progress bar. That earlier version's numbers were wrong
 * though: a 20-second run with the feed only occupying the middle 47% of it
 * meant three full seconds of a fully-hidden slip before anything moved, and
 * nearly eight seconds of a static "PREMIUM UNLOCKED" screen doing nothing
 * afterwards -- which is exactly what reads as the animation being stuck.
 * The stages are kept; the runtime is 6s, and the feed occupies the bulk of
 * it with no dead time on either side.
 */
private const val RUN_MS = 5800
private const val BOOT_END = 0.06f       // POWERING PRINTER
private const val CALIBRATE_END = 0.095f // CALIBRATING HEAD
private const val FEED_END = 0.655f      // PRINTING RECEIPT
private const val COLOUR_END = 0.79f     // COLOUR PASS
private const val VERIFY_END = 0.90f     // VERIFYING PURCHASE
// past VERIFY_END: PREMIUM UNLOCKED

@Composable
fun UnlockReceipt(data: AppData, onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val context = LocalContext.current

    val slot = remember { Animatable(0f) }
    val progress = remember { Animatable(0f) }
    val lift = remember { Animatable(1f) }
    var saved by remember { mutableStateOf<String?>(null) }
    var savedShown by remember { mutableStateOf(false) }

    // The feed the Slip masks against, derived from progress rather than
    // driven separately -- one clock for the whole sequence, so the status
    // text and the paper can never drift out of sync with each other the
    // way a status label on its own timeline and a feed on its own timeline
    // eventually would.
    val feed = ((progress.value - CALIBRATE_END) / (FEED_END - CALIBRATE_END)).coerceIn(0f, 1f)

    LaunchedEffect(Unit) {
        PrintSound.init(context)
        haptics.unlock()
        slot.animateTo(1f, tween(260, easing = FastOutSlowInEasing))

        // The sound, once, not looped.
        //
        // The previous version looped a ~2.2s clip that already had a fade
        // baked into both ends, across a much longer print window -- every
        // loop restart audibly dipped and swelled, which is the "sound
        // doesn't align" complaint. The fix here is not a better loop point;
        // it is not looping a clip that was never meant to loop. The feed
        // stage is now close to that clip's own natural length (about
        // (FEED_END-CALIBRATE_END)*RUN_MS ≈ 2.6s), so a single play very
        // nearly covers the printing stage on its own.
        launch {
            delay((CALIBRATE_END * RUN_MS).toLong())
            PrintSound.play()
        }
        launch {
            val beats = listOf(
                (BOOT_END * RUN_MS).toLong() to false,
                (CALIBRATE_END * RUN_MS).toLong() to true,
                (CALIBRATE_END * RUN_MS + (FEED_END - CALIBRATE_END) * RUN_MS * 0.3f).toLong() to false,
                (CALIBRATE_END * RUN_MS + (FEED_END - CALIBRATE_END) * RUN_MS * 0.65f).toLong() to false,
                (FEED_END * RUN_MS).toLong() to true,
                (COLOUR_END * RUN_MS).toLong() to false,
                (VERIFY_END * RUN_MS).toLong() to true,
            )
            var elapsed = 0L
            for ((at, heavy) in beats) {
                delay((at - elapsed).coerceAtLeast(0L))
                if (heavy) haptics.press() else haptics.tick()
                elapsed = at
            }
        }

        progress.animateTo(1f, tween(RUN_MS, easing = LinearEasing))
        haptics.sessionComplete()

        // Written while the slip is already fully visible, so a slow
        // filesystem never holds up the animation.
        saved = Receipt.saveToDownloads(context, data)
        savedShown = true

        delay(500)
        lift.animateTo(0f, tween(420, easing = FastOutSlowInEasing))
        onDone()
    }

    // Stopped if this leaves the composition early -- backing out of the
    // screen mid-print should take the sound with it, not leave a printer
    // running over whatever comes next.
    DisposableEffect(Unit) {
        onDispose { PrintSound.stop() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .alpha(lift.value)
            .background(Color(0xFF0B0B10)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {

            // --- the slot, and the paper coming out of it ---
            Box(
                Modifier
                    .width(300.dp)
                    .height(420.dp),
                contentAlignment = Alignment.TopCenter,
            ) {
                // The glow behind the slot. Drawn before the clip so it spills
                // out around the opening rather than being cut to it.
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .alpha(slot.value)
                        .drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colorStops = arrayOf(
                                        0f to Color(0xFF7FD4FF).copy(alpha = 0.45f),
                                        0.5f to Color(0xFF7FD4FF).copy(alpha = 0.14f),
                                        1f to Color.Transparent,
                                    ),
                                    center = Offset(size.width / 2f, 30f),
                                    radius = size.width * 0.7f,
                                ),
                                radius = size.width * 0.7f,
                                center = Offset(size.width / 2f, 30f),
                            )
                        },
                )

                // The paper. Offset upward by its own height at feed = 0, so
                // at rest it sits entirely above the visible area and slides
                // down into view as feed goes to 1.
                Box(
                    Modifier
                        .padding(top = 26.dp)
                        .graphicsLayer {
                            translationY = -size.height * (1f - feed)
                            alpha = if (feed > 0.02f) 1f else 0f
                        },
                ) {
                    Slip(data, feed)
                }

                // The printer itself, drawn last so the paper passes behind
                // its slot -- see PrinterMark for why this is a flat comic
                // glyph rather than the glossy 3D renders that were handed
                // over as reference. Nudged up so the glyph's own slot notch
                // (roughly a third of the way down its bounds) lines up with
                // the paper's own starting offset just below it.
                PrinterMark(
                    size = 108.dp,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = (-34).dp)
                        .graphicsLayer { scaleX = slot.value; scaleY = slot.value },
                )
            }

            Spacer(Modifier.height(22.dp))
            // The staged status line -- this is the part of the printer
            // concept worth keeping: naming what stage the machine is in
            // reads as a real device working, not a generic spinner. Derived
            // from the same `progress` driving everything else, so the label
            // can never drift out of sync with what the paper is doing.
            val p = progress.value
            val status = when {
                p < BOOT_END -> "POWERING PRINTER"
                p < CALIBRATE_END -> "CALIBRATING HEAD"
                p < FEED_END -> "PRINTING RECEIPT"
                p < COLOUR_END -> "COLOUR PASS"
                p < VERIFY_END -> "VERIFYING PURCHASE"
                else -> "PREMIUM UNLOCKED"
            }
            Text(
                status,
                fontSize = 13.sp,
                letterSpacing = 1.sp,
                fontWeight = if (p >= VERIFY_END) FontWeight.Bold else FontWeight.Normal,
                color = if (p >= VERIFY_END) Mint.fill
                        else Color.White.copy(alpha = 0.6f),
            )
            if (savedShown && saved != null) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "Receipt saved to Downloads",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.45f),
                )
            }
        }
    }
}

/**
 * The slip itself. Monospace and dotted rules, matching the saved PNG.
 *
 * [printed] is the same feed value driving the outer translation. Slip masks
 * its own lower portion in white while printed < 1, so the paper is not just
 * sliding into frame already finished -- each line's turn to appear tracks
 * the same motor pulse the haptics are ticking to.
 */
@Composable
private fun Slip(data: AppData, printed: Float) {
    val stamp = remember {
        LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy · HH:mm"))
    }
    // The app's own paper, not thermal-till white.
    //
    // Plain black-on-white was the honest thermal reference, and it was also
    // the one screen in the whole app with none of its colour language on
    // it -- every card elsewhere is cream with a coloured header band and one
    // accent doing the talking. A Tang header and a Sky-tinted key box are
    // the same move Plans and Home already make; this just brings the
    // receipt in line with them instead of leaving it looking imported.
    Column(
        Modifier
            .width(272.dp)
            .clip(RoundedCornerShape(10.dp))
            .drawWithContent {
                drawContent()
                if (printed < 0.999f) {
                    // The unprinted portion, covered in whichever background
                    // that band actually is -- Tang behind the header, cream
                    // everywhere else -- so the reveal never flashes the
                    // wrong colour over a region it has not reached yet.
                    val cut = (size.height * (printed + 0.06f)).coerceAtMost(size.height)
                    val headerPx = 64.dp.toPx()
                    if (cut < headerPx) {
                        drawRect(
                            color = Tang.fill,
                            topLeft = Offset(0f, cut),
                            size = Size(size.width, headerPx - cut),
                        )
                        drawRect(
                            color = CreamCard,
                            topLeft = Offset(0f, headerPx),
                            size = Size(size.width, size.height - headerPx),
                        )
                    } else {
                        drawRect(
                            color = CreamCard,
                            topLeft = Offset(0f, cut),
                            size = Size(size.width, size.height - cut),
                        )
                    }
                }
            },
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Tang.fill)
                .padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "MOMENTUM",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = Ink,
            )
            Text(
                "focus, banked",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Ink.copy(alpha = 0.75f),
            )
        }

        Column(
            Modifier
                .background(CreamCard)
                .padding(horizontal = 18.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(stamp, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = InkMid)

            Spacer(Modifier.height(12.dp))
            DottedRule()
            Spacer(Modifier.height(12.dp))

            Text(
                "LICENCE KEY",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = InkMid,
            )
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Sky.fill.copy(alpha = 0.30f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            ) {
                Text(
                    License.pretty(data.licenseKey),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Ink,
                )
            }

            Spacer(Modifier.height(14.dp))
            DottedRule()
            Spacer(Modifier.height(12.dp))

            SlipRow("Item", "Lifetime")
            SlipRow("Holder", data.userName.ifBlank { "friend" })
            SlipRow("Focused", "${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m")
            // PAID in Mint -- the same colour this app already reaches for
            // whenever something is confirmed and settled.
            SlipRow("Status", "PAID", valueColor = Mint.accent)

            Spacer(Modifier.height(12.dp))
            DottedRule()
            Spacer(Modifier.height(10.dp))
            Text(
                "Blocking stays free. Always.",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = InkMid,
            )
        }
    }
}

@Composable
private fun SlipRow(label: String, value: String, valueColor: Color = Ink) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = InkMid)
        Text(
            value,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = valueColor,
        )
    }
}

@Composable
private fun DottedRule() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(1.dp)
            .drawBehind {
                var x = 0f
                while (x < size.width) {
                    drawRect(
                        color = Ink.copy(alpha = 0.45f),
                        topLeft = Offset(x, 0f),
                        size = androidx.compose.ui.geometry.Size(3f, size.height),
                    )
                    x += 7f
                }
            },
    )
}
