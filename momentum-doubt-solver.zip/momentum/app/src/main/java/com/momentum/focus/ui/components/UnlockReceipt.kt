package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.util.PrintSound
import com.momentum.focus.ui.util.Receipt
import com.momentum.focus.ui.util.rememberHaptics
import com.momentum.focus.ui.components.clickableNoRipple
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private const val RUN_MS = 16_500L
private const val FEED_END = 0.30f
private const val PRINT_START = 0.24f
private const val PRINT_END = 0.78f

@Composable
fun UnlockReceipt(data: AppData, onDone: () -> Unit) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val timeline = remember { Animatable(0f) }
    val exit = remember { Animatable(1f) }
    var saved by remember { mutableStateOf<String?>(null) }
    var skip by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        PrintSound.init(context)
        haptics.unlock()
        launch {
            delay(3_500); haptics.tick()
            delay(4_000); haptics.tick()
            delay(3_000); haptics.sessionComplete()
        }
        timeline.animateTo(1f, tween(RUN_MS.toInt(), easing = LinearEasing))
        PrintSound.stop()
        if (saved == null) saved = Receipt.saveToDownloads(context, data)
        delay(450)
        exit.animateTo(0f, tween(360, easing = FastOutSlowInEasing))
        onDone()
    }
    LaunchedEffect(skip) {
        if (!skip) return@LaunchedEffect
        PrintSound.stop()
        if (saved == null) saved = Receipt.saveToDownloads(context, data)
        onDone()
    }
    DisposableEffect(Unit) { onDispose { PrintSound.stop() } }

    val p = timeline.value
    val feed = (p / FEED_END).coerceIn(0f, 1f)
    val printed = ((p - PRINT_START) / (PRINT_END - PRINT_START)).coerceIn(0f, 1f)
    val checkReveal = ((printed - 0.66f) / 0.34f).coerceIn(0f, 1f)

    LaunchedEffect(p >= PRINT_START, p >= PRINT_END) {
        if (p >= PRINT_START && p < PRINT_END) PrintSound.play(loop = true)
        if (p >= PRINT_END) PrintSound.stop()
    }

    Box(Modifier.fillMaxSize().alpha(exit.value).background(Color(0xFF070809)), contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("MOMENTUM PREMIUM", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.8.sp, color = Color.White.copy(alpha = 0.68f))
            Spacer(Modifier.height(5.dp))
            Text(if (p < FEED_END) "FEEDING RECEIPT" else if (p < PRINT_END) "PRINTING" else "PAYMENT SUCCESSFUL", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Mint.fill.copy(alpha = 0.72f))
            Spacer(Modifier.height(12.dp))
            Box(Modifier.width(330.dp).height(558.dp), contentAlignment = Alignment.TopCenter) {
                // Real feed motion: the receipt keeps one physical size and is
                // revealed by the printer viewport instead of being re-laid out
                // at every frame. This prevents text from jumping while paper
                // comes out.
                Box(Modifier.fillMaxWidth().height(558.dp).clip(RoundedCornerShape(10.dp))) {
                    ReceiptPaper(
                        data = data,
                        printed = printed,
                        checkReveal = checkReveal,
                        modifier = Modifier
                            .width(300.dp)
                            .height(520.dp)
                            .offset(y = 46.dp - (520.dp * (1f - feed)))
                            .rotate(-1.1f + 1.1f * printed)
                            .alpha(feed),
                    )
                }
                // Printer mouth stays in front of the moving paper.
                Box(
                    Modifier.width(286.dp).height(70.dp).clip(RoundedCornerShape(17.dp))
                        .background(Color(0xFF25282C)).border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(17.dp))
                        .alpha(1f - feed * 0.82f),
                ) {
                    Box(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 29.dp).height(12.dp).clip(RoundedCornerShape(6.dp)).background(Color.Black.copy(alpha = 0.72f)))
                }
            }
            Box(Modifier.fillMaxWidth().height(2.dp).clip(RoundedCornerShape(2.dp)).background(Color.White.copy(alpha = 0.08f)).drawBehind { drawRect(Mint.fill.copy(alpha = 0.78f), size = Size(size.width * p, size.height)) })
            Spacer(Modifier.height(10.dp))
            if (p < 0.90f) Text("Tap to skip", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = Color.White.copy(alpha = 0.30f), modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(Color.White.copy(alpha = 0.05f)).padding(horizontal = 12.dp, vertical = 7.dp).clickableNoRipple(remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { skip = true })
        }
    }
}

@Composable
private fun ReceiptPaper(data: AppData, printed: Float, checkReveal: Float, modifier: Modifier = Modifier) {
    val stamp = remember { LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")) }
    val paper = CreamCard
    Box(
        modifier.clip(RoundedCornerShape(4.dp)).background(paper).drawWithContent {
            drawContent()
            val r = printed.coerceIn(0f, 1f)
            if (r < 1f) drawRect(paper, topLeft = Offset(0f, size.height * r), size = Size(size.width, size.height * (1f - r)))
            val holeR = 5.dp.toPx(); val count = 11; val step = size.width / (count + 1)
            for (i in 1..count) drawCircle(Color(0xFF070809), holeR, Offset(step * i, 0f))
            // Bottom tear, kept attached to the receipt rather than floating outside it.
            val tooth = 9.dp.toPx(); var x = 0f; var up = true
            while (x < size.width) { val x2 = (x + tooth).coerceAtMost(size.width); drawLine(paper, Offset(x, size.height), Offset(x2, if (up) size.height - tooth else size.height), strokeWidth = 2f); x = x2; up = !up }
        },
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 15.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(56.dp).scale(0.84f + checkReveal * 0.16f).alpha(checkReveal).background(Mint.fill, RoundedCornerShape(50)).border(2.dp, Color.White.copy(alpha = 0.9f), RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(33.dp))
            }
            Spacer(Modifier.height(5.dp))
            Text("PAYMENT SUCCESSFUL", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 8.sp, letterSpacing = 1.0.sp, color = Mint.accent)
            Spacer(Modifier.height(10.dp))
            Text("₹399", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(2.dp))
            Text("Momentum Premium Paid", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            Text("Lifetime Access", fontSize = 12.sp, color = InkMid)
            Spacer(Modifier.height(9.dp))
            Text(data.userName.ifBlank { "Momentum member" }, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Ink)
            Text("Premium access unlocked", fontSize = 10.sp, color = InkMid)
            Spacer(Modifier.height(10.dp)); DottedRule(); Spacer(Modifier.height(9.dp))
            Text(stamp + "  •  MOMENTUM", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = InkMid)
            Spacer(Modifier.height(6.dp))
            Text("LICENSE", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = InkMid)
            Spacer(Modifier.height(2.dp))
            Text(License.pretty(data.licenseKey), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 9.sp, color = Ink)
            Spacer(Modifier.height(10.dp)); DottedRule(); Spacer(Modifier.height(10.dp))
            Text("PAID WITH MOMENTUM", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(4.dp))
            Text("PREMIUM  •  LIFETIME", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = InkMid)
            Spacer(Modifier.height(4.dp))
            Text("POWERED BY MOMENTUM", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = InkMid)
            Spacer(Modifier.weight(1f))
            Text("Keep this receipt. Premium is yours.", fontFamily = FontFamily.Monospace, fontSize = 7.sp, color = InkMid)
        }
    }
}

@Composable
private fun DottedRule() {
    Box(Modifier.fillMaxWidth().height(1.dp).drawBehind {
        var x = 0f
        while (x < size.width) { drawRect(Ink.copy(alpha = 0.42f), Offset(x, 0f), Size(3f, size.height)); x += 7f }
    })
}
