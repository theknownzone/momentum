package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.util.PrintSound
import com.momentum.focus.ui.util.Receipt
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * Premium receipt reveal.
 *
 * The important rule here is physical: a blank slip feeds out of the slot
 * first, then the print head writes the receipt from top to bottom. The saved
 * receipt and the on-screen receipt use the same copy and hierarchy.
 */
private const val RUN_MS = 20_000L
private const val FEED_END = 0.18f
private const val PRINT_START = 0.22f
private const val PRINT_END = 0.84f

@Composable
fun UnlockReceipt(data: AppData, onDone: () -> Unit) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val timeline = remember { Animatable(0f) }
    val exit = remember { Animatable(1f) }
    var saved by remember { mutableStateOf<String?>(null) }
    var skip by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        PrintSound.init(context)
        haptics.unlock()

        // Sparse tactile beats. No per-frame vibration and no long buzz.
        launch {
            delay(2_000); haptics.tick()
            delay(3_000); haptics.tick()
            delay(4_500); haptics.press()
            delay(4_000); haptics.tick()
            delay(4_000); haptics.sessionComplete()
        }

        timeline.animateTo(1f, tween(RUN_MS.toInt(), easing = LinearEasing))
        PrintSound.stop()
        if (saved == null) saved = Receipt.saveToDownloads(context, data)
        delay(500)
        exit.animateTo(0f, tween(420, easing = FastOutSlowInEasing))
        onDone()
    }

    LaunchedEffect(skip) {
        if (!skip) return@LaunchedEffect
        PrintSound.stop()
        if (saved == null) saved = Receipt.saveToDownloads(context, data)
        onDone()
    }

    DisposableEffect(Unit) {
        onDispose { PrintSound.stop() }
    }

    val p = timeline.value
    val feed = (p / FEED_END).coerceIn(0f, 1f)
    val printed = ((p - PRINT_START) / (PRINT_END - PRINT_START)).coerceIn(0f, 1f)

    // Sound starts when the paper has finished feeding into position and stops
    // when the print pass ends. It never runs during the silent feed/settle.
    LaunchedEffect(p >= PRINT_START, p >= PRINT_END) {
        if (p >= PRINT_START && p < PRINT_END) PrintSound.play(loop = true)
        if (p >= PRINT_END) PrintSound.stop()
    }

    val status = when {
        p < FEED_END -> "FEEDING BLANK RECEIPT"
        p < PRINT_END -> "PRINTING RECEIPT"
        p < 0.94f -> "RECEIPT COMPLETE"
        else -> "PREMIUM UNLOCKED"
    }

    Box(
        Modifier.fillMaxSize().alpha(exit.value).background(Color(0xFF0E1014)),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "MOMENTUM / PREMIUM",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.72f),
                letterSpacing = 1.7.sp,
            )
            Spacer(Modifier.height(7.dp))
            Text(status, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.48f))
            Spacer(Modifier.height(18.dp))

            // One simple machine: body, slot, and paper. No moving gradients,
            // no particle field, and no nested infinite transitions.
            Box(Modifier.width(300.dp).height(510.dp), contentAlignment = Alignment.TopCenter) {
                // Paper feeds downward from the slot. It is blank until the
                // print phase starts.
                Box(
                    Modifier
                        .width(272.dp)
                        .height(424.dp * feed)
                        .offset(y = 54.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(CreamCard),
                ) {
                    Slip(data, printed)
                }

                // Printer body stays fixed while the paper moves behind it.
                Box(
                    Modifier
                        .width(300.dp)
                        .height(86.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color(0xFF292B30))
                        .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(22.dp)),
                ) {
                    Box(
                        Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 38.dp)
                            .height(14.dp).clip(RoundedCornerShape(7.dp))
                            .background(Color(0xFF090A0C)),
                    )
                    Box(
                        Modifier.width(42.dp).height(3.dp).align(Alignment.TopEnd)
                            .offset(x = (-30).dp, y = 18.dp)
                            .clip(RoundedCornerShape(2.dp)).background(
                                if (p >= PRINT_START && p < PRINT_END) Mint.fill else Color.White.copy(alpha = 0.16f),
                            ),
                    )
                }
            }

            Spacer(Modifier.height(6.dp))
            Text(
                if (saved != null) "Receipt saved" else "Printer online",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.42f),
            )
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier.fillMaxWidth().height(2.dp).clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.08f))
                    .drawBehind {
                        drawRect(Color.White.copy(alpha = 0.55f), size = Size(size.width * p, size.height))
                    },
            )
            Spacer(Modifier.height(14.dp))
            if (p < 0.90f) {
                Text(
                    "Tap to skip",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = Color.White.copy(alpha = 0.32f),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.05f))
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                        .clickableNoRipple(remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { skip = true },
                )
            }
        }
    }
}

@Composable
private fun Slip(data: AppData, printed: Float) {
    val stamp = remember {
        LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEE, dd MMM yyyy  HH:mm:ss"))
    }
    val reveal = printed.coerceIn(0f, 1f)

    Column(
        Modifier
            .width(272.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(CreamCard)
            .drawWithContent {
                drawContent()
                // The paper is blank first. Ink is revealed strictly from the
                // top, matching the print-head direction.
                if (reveal < 1f) {
                    drawRect(
                        color = CreamCard,
                        topLeft = Offset(0f, size.height * reveal),
                        size = Size(size.width, size.height * (1f - reveal)),
                    )
                }
            },
    ) {
        Column(
            Modifier.fillMaxWidth().background(Tang.fill).padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("MOMENTUM", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                fontSize = 22.sp, color = Ink)
            Text("focus, banked", fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                color = Ink.copy(alpha = 0.75f))
        }
        Column(
            Modifier.fillMaxWidth().background(CreamCard).padding(horizontal = 18.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(stamp, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = InkMid)
            Spacer(Modifier.height(12.dp)); DottedRule(); Spacer(Modifier.height(12.dp))
            Text("LICENCE KEY", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = InkMid)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.clip(RoundedCornerShape(6.dp)).background(Sky.fill.copy(alpha = 0.30f)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                Text(License.pretty(data.licenseKey), fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Ink)
            }
            Spacer(Modifier.height(14.dp)); DottedRule(); Spacer(Modifier.height(12.dp))
            SlipRow("Item", "Lifetime")
            SlipRow("Plan", "Momentum Premium")
            SlipRow("Holder", data.userName.ifBlank { "friend" })
            SlipRow("Focused", "${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m")
            SlipRow("Streak", "${data.streakDays} days")
            SlipRow("Status", "PAID", valueColor = Mint.accent)
            Spacer(Modifier.height(12.dp)); DottedRule(); Spacer(Modifier.height(10.dp))
            Text("Blocking stays free. Always.", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = InkMid)
            Spacer(Modifier.height(5.dp))
            Text("Keep this key. It moves phones.", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = InkMid)
        }
    }
}

private fun SlipRow(label: String, value: String, valueColor: Color = Ink) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = InkMid)
        Text(value, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
            fontSize = 11.sp, color = valueColor)
    }
}

@Composable
private fun DottedRule() {
    Box(Modifier.fillMaxWidth().height(1.dp).drawBehind {
        var x = 0f
        while (x < size.width) {
            drawRect(Ink.copy(alpha = 0.45f), Offset(x, 0f), Size(3f, size.height))
            x += 7f
        }
    })
}
