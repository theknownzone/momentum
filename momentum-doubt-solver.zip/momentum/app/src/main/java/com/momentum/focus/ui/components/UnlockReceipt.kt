package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.util.PrintSound
import com.momentum.focus.ui.util.Receipt
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * The unlock moment: a slip printing out of a slot, then saving itself.
 *
 * Staged like a small product reveal -- boot, calibrate, print, verify,
 * unlocked -- rather than one flat "printing" state, because that staging is
 * what makes this feel like an actual machine working rather than a progress
 * bar. The 20-second length is deliberate — this is the reward moment for
 * buying premium, and the length is the point.
 *
 * What was actually broken in an earlier version was not the length, it was
 * where the work happened inside it: the feed only occupied the middle 47%
 * of the 20 seconds, which meant three full seconds of a fully-hidden slip
 * before anything moved, and nearly eight seconds of a static "PREMIUM
 * UNLOCKED" screen doing nothing afterwards. Twenty seconds with two long
 * dead stretches reads as stuck; twenty seconds where almost all of it is the
 * feed (here, 17 of the 20) reads as an unusually thorough printer. Boot and
 * calibrate are now under half a second combined, and the feed runs right up
 * to 87.5% of the timeline before colour-pass, verify and the unlocked hold
 * take the last two and a half seconds.
 */
private const val RUN_MS = 20000
private const val BOOT_END = 0.0125f     // POWERING PRINTER
private const val CALIBRATE_END = 0.0225f // CALIBRATING HEAD
private const val FEED_END = 0.875f      // PRINTING RECEIPT
private const val COLOUR_END = 0.935f    // COLOUR PASS
private const val VERIFY_END = 0.975f    // VERIFYING PURCHASE
// past VERIFY_END: PREMIUM UNLOCKED

@Composable
fun UnlockReceipt(data: AppData, onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val context = LocalContext.current

    val slot = remember { Animatable(0f) }
    val progress = remember { Animatable(0f) }
    val lift = remember { Animatable(1f) }
    var saved by remember { mutableStateOf<String?>(null) }
    var savedShown by remember { mutableStateOf(false) }

    // The feed the Slip masks against, derived from progress rather than
    // driven separately -- one clock for the whole sequence, so the status
    // text and the paper can never drift out of sync with each other the
    // way a status label on its own timeline and a feed on its own timeline
    // eventually would.
    val paperFeed = ((progress.value - CALIBRATE_END) / (FEED_END - CALIBRATE_END)).coerceIn(0f, 1f)
    // First the machine feeds a clean, blank strip. Only after the paper has
    // physically emerged does the print head reveal the receipt top-to-bottom.
    val paperVisible = (paperFeed / 0.88f).coerceIn(0f, 1f)
    val printed = ((paperFeed - 0.12f) / 0.88f).coerceIn(0f, 1f)

    LaunchedEffect(Unit) {
        PrintSound.init(context)
        haptics.unlock()
        slot.animateTo(1f, tween(260, easing = FastOutSlowInEasing))

        // The sound, once, not looped.
        //
        // The previous version looped a ~2.2s clip that already had a fade
        // baked into both ends, across a much longer print window -- every
        // loop restart audibly dipped and swelled, which is the "sound
        // doesn't align" complaint. The fix is not a better loop point; it
        // is not needing to loop at all. The 17-second feed stage needed a
        // genuinely longer sound bed, so the clip itself was rebuilt: the
        // source recording has two loud, usable stretches (roughly 4.0-9.3s
        // and 11.8-20.0s) separated by a near-silent dip, crossfaded
        // together into one continuous ~13s piece with no seam. That covers
        // most of the 17s feed with real, non-repeating texture; the last
        // few seconds of feed play out in near-silence rather than looping,
        // which reads as the sound naturally settling, not glitching.
        launch {
            delay((CALIBRATE_END * RUN_MS).toLong())
            PrintSound.play()
        }
        launch {
            val beats = listOf(
                (BOOT_END * RUN_MS).toLong() to false,
                (CALIBRATE_END * RUN_MS).toLong() to true,
                (CALIBRATE_END * RUN_MS + (FEED_END - CALIBRATE_END) * RUN_MS * 0.3f).toLong() to false,
                (CALIBRATE_END * RUN_MS + (FEED_END - CALIBRATE_END) * RUN_MS * 0.65f).toLong() to false,
                (FEED_END * RUN_MS).toLong() to true,
                (COLOUR_END * RUN_MS).toLong() to false,
                (VERIFY_END * RUN_MS).toLong() to true,
            )
            var elapsed = 0L
            for ((at, heavy) in beats) {
                delay((at - elapsed).coerceAtLeast(0L))
                if (heavy) haptics.press() else haptics.tick()
                elapsed = at
            }
        }

        progress.animateTo(1f, tween(RUN_MS, easing = LinearEasing))
        haptics.sessionComplete()

        // Written while the slip is already fully visible, so a slow
        // filesystem never holds up the animation.
        saved = Receipt.saveToDownloads(context, data)
        savedShown = true

        delay(2200)
        lift.animateTo(0f, tween(420, easing = FastOutSlowInEasing))
        onDone()
    }

    // Stopped if this leaves the composition early -- backing out of the
    // screen mid-print should take the sound with it, not leave a printer
    // running over whatever comes next.
    DisposableEffect(Unit) {
        onDispose { PrintSound.stop() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .alpha(lift.value)
            .background(Color(0xFF0A0F0A))
            .drawWithContent {
                drawContent()
                // Falling confetti specks -- small tilted rounded rects,
                // scattered and dimmed toward the edges. Deterministic
                // positions (a fixed seed list) rather than Random() so the
                // scatter doesn't reshuffle on every recomposition.
                confettiSpecks.forEachIndexed { i, speck ->
                    val (fx, fy, rot, sizeFrac) = speck
                    val cx = size.width * fx
                    val cy = size.height * fy
                    val w = size.width * sizeFrac
                    rotate(rot, pivot = Offset(cx, cy)) {
                        drawRoundRect(
                            color = Color(0xFF3FE28F).copy(alpha = 0.16f + 0.10f * (i % 3)),
                            topLeft = Offset(cx - w / 2f, cy - w * 1.6f / 2f),
                            size = Size(w, w * 1.6f),
                            cornerRadius = CornerRadius(w * 0.25f),
                        )
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {

            // The floating success badge -- a glowing green circle with a
            // check, sitting above the paper the way the reference has one
            // stamped in the air above the torn slip. It arrives on the same
            // `slot` timeline as the printer, so it is not a second thing to
            // wait for.
            Box(
                Modifier
                    .padding(bottom = 8.dp)
                    .graphicsLayer {
                        scaleX = slot.value
                        scaleY = slot.value
                        alpha = slot.value
                    },
                contentAlignment = Alignment.Center,
            ) {
                CheckBadge(size = 64.dp)
            }

            // --- the slot, and the paper coming out of it ---
            Box(
                Modifier
                    .width(332.dp)
                    .height(500.dp),
                contentAlignment = Alignment.TopCenter,
            ) {
                // The glow behind the slot, in the same green as the badge
                // above it rather than the app's usual Sky blue -- this scene
                // is specifically the success-green moment, borrowed from the
                // reference, not this app's everyday glass tint.
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .alpha(slot.value)
                        .drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colorStops = arrayOf(
                                        0f to Color(0xFF3FE28F).copy(alpha = 0.45f),
                                        0.5f to Color(0xFF3FE28F).copy(alpha = 0.14f),
                                        1f to Color.Transparent,
                                    ),
                                    center = Offset(size.width / 2f, 30f),
                                    radius = size.width * 0.7f,
                                ),
                                radius = size.width * 0.7f,
                                center = Offset(size.width / 2f, 30f),
                            )
                        },
                )

                // The paper. Offset upward by its own height at feed = 0, so
                // at rest it sits entirely above the visible area and slides
                // down into view as feed goes to 1.
                Box(
                    Modifier
                        .padding(top = 30.dp)
                        .graphicsLayer {
                            translationY = -size.height * (1f - paperVisible)
                            alpha = if (paperVisible > 0.01f) 1f else 0f
                        },
                ) {
                    Slip(data, printed)
                }

                // The printer itself, drawn last so the paper passes behind
                // its slot -- see PrinterMark for why this is a flat comic
                // glyph rather than the glossy 3D renders that were handed
                // over as reference. Nudged up so the glyph's own slot notch
                // (roughly a third of the way down its bounds) lines up with
                // the paper's own starting offset just below it.
                PrinterMark(
                    size = 250.dp,
                    tint = com.momentum.focus.ui.theme.Mint.fill,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = (-82).dp)
                        .graphicsLayer { scaleX = slot.value; scaleY = slot.value },
                )
            }

            Spacer(Modifier.height(22.dp))
            // The staged status line -- this is the part of the printer
            // concept worth keeping: naming what stage the machine is in
            // reads as a real device working, not a generic spinner. Derived
            // from the same `progress` driving everything else, so the label
            // can never drift out of sync with what the paper is doing.
            val p = progress.value
            val status = when {
                p < BOOT_END -> "POWERING PRINTER"
                p < CALIBRATE_END -> "CALIBRATING HEAD"
                p < FEED_END -> "PRINTING RECEIPT"
                p < COLOUR_END -> "COLOUR PASS"
                p < VERIFY_END -> "VERIFYING PURCHASE"
                else -> "PREMIUM UNLOCKED"
            }
            Text(
                status,
                fontSize = 13.sp,
                letterSpacing = 1.sp,
                fontWeight = if (p >= VERIFY_END) FontWeight.Bold else FontWeight.Normal,
                color = if (p >= VERIFY_END) Mint.fill
                        else Color.White.copy(alpha = 0.6f),
            )
            if (savedShown && saved != null) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "Receipt saved to Downloads",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.45f),
                )
            }
            if (p >= VERIFY_END) {
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier
                        .width(190.dp)
                        .height(46.dp)
                        .clip(RoundedCornerShape(23.dp))
                        .background(Color(0xFF43E08D))
                        .clickableNoRipple(remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { onDone() },
                    contentAlignment = Alignment.Center,
                ) {
                    Text("Done  →", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF062316))
                }
            }
        }
    }
}

/**
 * The slip itself. Monospace and dotted rules, matching the saved PNG.
 *
 * [printed] is the same feed value driving the outer translation. Slip masks
 * its own lower portion in white while printed < 1, so the paper is not just
 * sliding into frame already finished -- each line's turn to appear tracks
 * the same motor pulse the haptics are ticking to.
 */
@Composable
private fun Slip(data: AppData, printed: Float) {
    val now = remember { LocalDateTime.now() }
    val stamp = now.format(DateTimeFormatter.ofPattern("dd MMM yyyy • HH:mm"))
    val utr = remember { "MOM${now.format(DateTimeFormatter.ofPattern("yyMMddHHmmss"))}" }
    val holder = data.userName.ifBlank { "Momentum user" }
    Column(
        Modifier
            .width(332.dp)
            .clip(RoundedCornerShape(8.dp))
            .drawWithContent {
                drawContent()
                if (printed < .999f) {
                    val cut = (size.height * printed).coerceIn(0f, size.height)
                    drawRect(CreamCard, topLeft = Offset(0f, cut), size = Size(size.width, size.height - cut))
                }
                // Real receipt-style serrated paper edge.
                val tooth = 10.dp.toPx()
                var x = 0f
                val path = androidx.compose.ui.graphics.Path()
                path.moveTo(0f, size.height)
                var up = true
                while (x < size.width) {
                    x += tooth
                    path.lineTo(x.coerceAtMost(size.width), size.height - if (up) tooth else 0f)
                    up = !up
                }
                path.lineTo(size.width, size.height)
                path.lineTo(0f, size.height)
                path.close()
                drawPath(path, Color(0xFF0A0F0A))
            },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // Payment header: green UPI-like success strip.
        Column(
            Modifier.fillMaxWidth().background(Color(0xFF43E08D)).padding(horizontal = 20.dp, vertical = 15.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("MOMENTUM", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 25.sp, color = Color(0xFF062316))
            Text("PAYMENT SUCCESSFUL", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.2.sp, color = Color(0xFF0B3B27))
        }

        Column(
            Modifier.fillMaxWidth().background(Color(0xFFFFFEF5)).padding(horizontal = 22.dp, vertical = 17.dp),
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Text("₹399", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 36.sp, color = Ink)
            }
            Spacer(Modifier.height(4.dp))
            Text("Momentum Premium Paid", modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Ink)
            Spacer(Modifier.height(2.dp))
            Text("Paid by $holder", modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 11.sp, color = InkMid)
            Spacer(Modifier.height(14.dp))
            DottedRule()
            Spacer(Modifier.height(12.dp))

            SlipRow("To", "Momentum Premium")
            SlipRow("UPI ID", "momentum@upi")
            SlipRow("Date", stamp)
            SlipRow("UTR", utr)

            Spacer(Modifier.height(12.dp))
            DottedRule()
            Spacer(Modifier.height(12.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Money sent", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Ink)
                    Text("Paid with Momentum", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = InkMid)
                }
                Box(
                    Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xFF43E08D)).padding(horizontal = 13.dp, vertical = 7.dp)
                ) { Text("PAID", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 10.sp, color = Color(0xFF062316)) }
            }
            Spacer(Modifier.height(15.dp))
            Text("POWERED BY UPI", modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 1.sp, color = InkMid)
            Spacer(Modifier.height(11.dp))
        }
    }
}
@Composable
private fun SlipRow(label: String, value: String, valueColor: Color = Ink) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = InkMid)
        Text(
            value,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = valueColor,
        )
    }
}

@Composable
private fun DottedRule() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(1.dp)
            .drawBehind {
                var x = 0f
                while (x < size.width) {
                    drawRect(
                        color = Ink.copy(alpha = 0.45f),
                        topLeft = Offset(x, 0f),
                        size = androidx.compose.ui.geometry.Size(3f, size.height),
                    )
                    x += 7f
                }
            },
    )
}

/**
 * The floating success badge -- a ringed circle, glowing, with a check mark,
 * matching the "Payment Successful" stamp that floats above the paper in the
 * reference image. Built the same way as the rest of this scene's glass: a
 * radial glow behind, a flat fill, a stroke ring, no bitmap.
 */
@Composable
private fun CheckBadge(size: Dp) {
    Canvas(Modifier.size(size)) {
        val r = this.size.minDimension / 2f
        val centre = Offset(this.size.width / 2f, this.size.height / 2f)
        // Glow, reaching past the ring itself.
        drawCircle(
            brush = Brush.radialGradient(
                colorStops = arrayOf(
                    0f to Color(0xFF3FE28F).copy(alpha = 0.55f),
                    0.6f to Color(0xFF3FE28F).copy(alpha = 0.18f),
                    1f to Color.Transparent,
                ),
                center = centre,
                radius = r * 1.8f,
            ),
            radius = r * 1.8f,
            center = centre,
        )
        // The disc.
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF57F0A0), Color(0xFF1FAE63)),
                center = Offset(centre.x - r * 0.3f, centre.y - r * 0.3f),
                radius = r * 1.4f,
            ),
            radius = r * 0.86f,
            center = centre,
        )
        // A dotted outer ring, echoing the reference's own dashed halo.
        val dotR = r * 1.14f
        val dots = 28
        for (i in 0 until dots) {
            val ang = (i / dots.toFloat()) * 2f * kotlin.math.PI.toFloat()
            val p = Offset(
                centre.x + kotlin.math.cos(ang) * dotR,
                centre.y + kotlin.math.sin(ang) * dotR,
            )
            drawCircle(Color(0xFF3FE28F).copy(alpha = 0.6f), radius = r * 0.035f, center = p)
        }
        // The check mark itself.
        val checkPath = androidx.compose.ui.graphics.Path().apply {
            moveTo(centre.x - r * 0.42f, centre.y + r * 0.02f)
            lineTo(centre.x - r * 0.08f, centre.y + r * 0.34f)
            lineTo(centre.x + r * 0.48f, centre.y - r * 0.30f)
        }
        drawPath(
            checkPath,
            color = Color.White,
            style = androidx.compose.ui.graphics.drawscope.Stroke(
                width = r * 0.16f,
                cap = androidx.compose.ui.graphics.StrokeCap.Round,
                join = androidx.compose.ui.graphics.StrokeJoin.Round,
            ),
        )
    }
}

/**
 * Fixed scatter positions for the background confetti -- (x fraction, y
 * fraction, rotation degrees, width as a fraction of screen width). A named
 * list rather than a runtime Random() call, for the same reason the grain in
 * HaloGlass is seeded rather than random: a fixed scatter sits still frame to
 * frame; a reseeded one crawls, which reads as noise rather than confetti.
 */
private data class ConfettiSpeck(val x: Float, val y: Float, val rotation: Float, val width: Float)

private val confettiSpecks = listOf(
    ConfettiSpeck(0.08f, 0.12f, 20f, 0.05f),
    ConfettiSpeck(0.85f, 0.08f, -15f, 0.04f),
    ConfettiSpeck(0.15f, 0.30f, 40f, 0.035f),
    ConfettiSpeck(0.90f, 0.22f, 10f, 0.045f),
    ConfettiSpeck(0.05f, 0.55f, -25f, 0.05f),
    ConfettiSpeck(0.92f, 0.48f, 30f, 0.04f),
    ConfettiSpeck(0.12f, 0.75f, 15f, 0.045f),
    ConfettiSpeck(0.88f, 0.70f, -20f, 0.035f),
    ConfettiSpeck(0.20f, 0.90f, 25f, 0.04f),
    ConfettiSpeck(0.80f, 0.88f, -10f, 0.05f),
    ConfettiSpeck(0.50f, 0.06f, 5f, 0.03f),
    ConfettiSpeck(0.04f, 0.40f, -35f, 0.03f),
)
