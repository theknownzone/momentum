package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.util.PrintSound
import com.momentum.focus.ui.util.Receipt
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * Premium receipt reveal.
 *
 * The important rule here is physical: a blank slip feeds out of the slot
 * first, then the print head writes the receipt from top to bottom. The saved
 * receipt and the on-screen receipt use the same copy and hierarchy.
 */
private const val RUN_MS = 20_000L
private const val FEED_END = 0.18f
private const val PRINT_START = 0.22f
private const val PRINT_END = 0.84f

@Composable
fun UnlockReceipt(data: AppData, onDone: () -> Unit) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val timeline = remember { Animatable(0f) }
    val exit = remember { Animatable(1f) }
    val lowEnd = remember { DeviceProfile.isLowEnd(context) }
    val runMs = if (lowEnd) 16_000L else RUN_MS
    var saved by remember { mutableStateOf<String?>(null) }
    var skip by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        PrintSound.init(context)
        haptics.unlock()

        // Haptics follow the same physical milestones as the paper/sound.
        // They are sparse events, never per-frame or per-character.
        launch {
            delay((runMs * FEED_END).toLong()); haptics.tick()
            delay((runMs * (PRINT_START - FEED_END)).toLong()); haptics.press()
            delay((runMs * 0.36f).toLong()); haptics.tick()
            delay((runMs * (PRINT_END - 0.58f)).toLong()); haptics.sessionComplete()
        }

        timeline.animateTo(1f, tween(runMs.toInt(), easing = LinearEasing))
        PrintSound.stop()
        if (saved == null) saved = Receipt.saveToDownloads(context, data)
        delay(500)
        exit.animateTo(0f, tween(420, easing = FastOutSlowInEasing))
        onDone()
    }

    LaunchedEffect(skip) {
        if (!skip) return@LaunchedEffect
        PrintSound.stop()
        if (saved == null) saved = Receipt.saveToDownloads(context, data)
        onDone()
    }

    DisposableEffect(Unit) {
        onDispose { PrintSound.stop() }
    }

    val p = timeline.value
    val feed = (p / FEED_END).coerceIn(0f, 1f)
    val printed = ((p - PRINT_START) / (PRINT_END - PRINT_START)).coerceIn(0f, 1f)

    // Sound starts when the paper has finished feeding into position and stops
    // when the print pass ends. It never runs during the silent feed/settle.
    LaunchedEffect(p >= PRINT_START, p >= PRINT_END) {
        if (p >= PRINT_START && p < PRINT_END) PrintSound.play(loop = true)
        if (p >= PRINT_END) PrintSound.stop()
    }

    val status = when {
        p < FEED_END -> "FEEDING BLANK RECEIPT"
        p < PRINT_END -> "PRINTING RECEIPT"
        p < 0.94f -> "RECEIPT COMPLETE"
        else -> "PREMIUM UNLOCKED"
    }

    Box(
        Modifier.fillMaxSize().alpha(exit.value).background(Color(0xFF0E1014)),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "MOMENTUM / PREMIUM",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.72f),
                letterSpacing = 1.7.sp,
            )
            Spacer(Modifier.height(7.dp))
            Text(status, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.48f))
            Spacer(Modifier.height(18.dp))

            // One simple machine: body, slot, and paper. No moving gradients,
            // no particle field, and no nested infinite transitions. On short
            // screens the whole machine scales down instead of clipping its slip.
            BoxWithConstraints(Modifier.fillMaxWidth().heightIn(max = 540.dp), contentAlignment = Alignment.TopCenter) {
                val machineScale = (maxHeight / 530.dp).coerceAtMost(1f).coerceAtLeast(0.74f)
                Box(Modifier.width(300.dp).height(530.dp).graphicsLayer {
                    scaleX = machineScale
                    scaleY = machineScale
                }, contentAlignment = Alignment.TopCenter) {
                // Paper feeds downward from the slot. It is blank until the
                // print phase starts.
                Box(
                    Modifier
                        .width(272.dp)
                        .height(450.dp * feed)
                        .offset(y = 54.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(CreamCard),
                ) {
                    Slip(data, printed)
                }

                // Printer body stays fixed while the paper moves behind it.
                Box(
                    Modifier
                        .width(300.dp)
                        .height(86.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color(0xFF292B30))
                        .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(22.dp)),
                ) {
                    Box(
                        Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 38.dp)
                            .height(14.dp).clip(RoundedCornerShape(7.dp))
                            .background(Color(0xFF090A0C)),
                    )
                    Box(
                        Modifier.width(42.dp).height(3.dp).align(Alignment.TopEnd)
                            .offset(x = (-30).dp, y = 18.dp)
                            .clip(RoundedCornerShape(2.dp)).background(
                                if (p >= PRINT_START && p < PRINT_END) Mint.fill else Color.White.copy(alpha = 0.16f),
                            ),
                    )
                }
                }
            }

            Spacer(Modifier.height(6.dp))
            Text(
                if (saved != null) "Receipt saved" else "Printer online",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.42f),
            )
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier.fillMaxWidth().height(2.dp).clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.08f))
                    .drawBehind {
                        drawRect(Color.White.copy(alpha = 0.55f), size = Size(size.width * p, size.height))
                    },
            )
            Spacer(Modifier.height(14.dp))
            if (p < 0.90f) {
                Text(
                    "Tap to skip",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = Color.White.copy(alpha = 0.32f),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.05f))
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                        .clickableNoRipple(remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { skip = true },
                )
            }
        }
    }
}

@Composable
private fun Slip(data: AppData, printed: Float) {
    val stamp = remember {
        LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, h:mma"))
    }
    val reveal = printed.coerceIn(0f, 1f)

    // The paper is always physical and visible. Only the INK is revealed by
    // the print head. This prevents the punched edge/check seal from seeming
    // to disappear into the printer while the text is being printed.
    Column(
        Modifier
            .width(272.dp)
            .height(450.dp)
            .drawBehind {
                val tear = 13.dp.toPx()
                val path = Path().apply {
                    moveTo(0f, 0f)
                    lineTo(size.width, 0f)
                    lineTo(size.width, size.height - tear)
                    val steps = 18
                    val step = size.width / steps
                    for (i in steps downTo 0) {
                        val x = i * step
                        val y = size.height - tear * if (i % 2 == 0) 0.25f else 0.72f
                        lineTo(x, y)
                    }
                    close()
                }
                drawPath(path, CreamCard)
            },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // Physical punched top edge: never part of the ink reveal.
        Row(
            Modifier.fillMaxWidth().height(28.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.Top,
        ) {
            repeat(13) {
                Box(
                    Modifier
                        .width(13.dp)
                        .height(18.dp)
                        .clip(RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp))
                        .background(Color(0xFF0E1014))
                )
            }
        }

        // Printed area. Its mask moves strictly top -> bottom, while the paper
        // itself stays put after feeding out of the slot.
        Column(
            Modifier
                .fillMaxWidth()
                .height(406.dp)
                .drawWithContent {
                    drawContent()
                    if (reveal < 1f) {
                        drawRect(
                            color = CreamCard,
                            topLeft = Offset(0f, size.height * reveal),
                            size = Size(size.width, size.height * (1f - reveal)),
                        )
                    }
                },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(5.dp))
            Box(
                Modifier
                    .width(76.dp)
                    .height(76.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(Mint.fill)
                    .border(2.dp, Color(0xFF75D99A), androidx.compose.foundation.shape.CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text("✓", fontSize = 45.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }

            Spacer(Modifier.height(9.dp))
            Text("₹399", fontSize = 42.sp, fontWeight = FontWeight.Black, color = Ink)
            Spacer(Modifier.height(3.dp))
            Text("Momentum Premium Paid", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            Spacer(Modifier.height(8.dp))
            Text("Lifetime Access", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Ink)
            Spacer(Modifier.height(5.dp))
            Text(data.userName.ifBlank { "Momentum user" }, fontSize = 13.sp, color = InkMid)
            Spacer(Modifier.height(3.dp))
            Text("Premium access unlocked", fontSize = 11.sp, color = InkMid)

            Spacer(Modifier.height(13.dp))
            DottedRule()
            Spacer(Modifier.height(11.dp))
            Text("$stamp  •  MOMENTUM", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = InkMid)
            Spacer(Modifier.height(6.dp))
            Text("License  ${License.pretty(data.licenseKey)}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Ink)
            Spacer(Modifier.height(12.dp))
            DottedRule()
            Spacer(Modifier.height(11.dp))
            Text("PAID WITH MOMENTUM", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(8.dp))
            Text("PREMIUM • LIFETIME", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = InkMid)
            Spacer(Modifier.height(4.dp))
            Text("POWERED BY MOMENTUM", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = InkMid)
        }
    }
}

@Composable
private fun DottedRule() {
    Box(Modifier.fillMaxWidth().height(1.dp).drawBehind {
        var x = 0f
        while (x < size.width) {
            drawRect(Ink.copy(alpha = 0.45f), Offset(x, 0f), Size(3f, size.height))
            x += 7f
        }
    })
}
