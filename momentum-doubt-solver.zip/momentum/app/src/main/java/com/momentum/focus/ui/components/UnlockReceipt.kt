package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.util.PrintSound
import com.momentum.focus.ui.util.Receipt
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * The unlock moment: a slip printing out of a slot, then saving itself.
 *
 * The sequence is the point, and it is deliberately paced like a real
 * transaction rather than a celebration screen:
 * 1. A dark slot fades in with its own glow -- something is about to come out
 *    of it, and the glow is what says so before anything moves.
 * 2. The slip feeds out from behind the slot, top-first, on a spring. It
 *    overshoots slightly and settles, the way paper does when the feed stops.
 * 3. It holds long enough to actually be read.
 * 4. A line confirms the file was written, then the whole thing lifts away.
 *
 * The slip is clipped by the slot rather than sliding on top of it, so it
 * genuinely appears to emerge from inside. That is one Box with clipping and
 * a negative offset -- if the paper simply slid down over the slot, the
 * illusion collapses and it reads as a card animation.
 */
@Composable
fun UnlockReceipt(data: AppData, onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val context = LocalContext.current

    val slot = remember { Animatable(0f) }      // slot fade/scale in
    val feed = remember { Animatable(0f) }      // 0 = inside, 1 = fully out
    val lift = remember { Animatable(1f) }      // whole scene alpha on exit
    var saved by remember { mutableStateOf<String?>(null) }
    var savedShown by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        // Decoded before the slot even opens, so the sound is ready to start
        // on the same frame the feed does. Preparing it later would put the
        // audio a beat behind the paper, which reads worse than no audio.
        PrintSound.init(context)
        haptics.unlock()
        slot.animateTo(1f, tween(320, easing = FastOutSlowInEasing))

        // The feed, and the printing it drives.
        //
        // A spring at stiffness 90 settles in well under a second — fast
        // enough that watched back, the whole slip appears to just pop into
        // place. A real receipt printer does not ease or bounce; the motor
        // runs at one speed until it stops. tween + LinearEasing over 1700ms
        // is that: constant, mechanical, long enough to actually watch print.
        //
        // The Slip composable reads this same `feed` value to mask its own
        // lower portion in white as it goes — see Slip's drawWithContent —
        // so the paper is not just sliding into frame already finished; the
        // text is genuinely still being covered until its row's turn comes,
        // the way ink only exists on paper that has already passed the head.
        PrintSound.play()
        launch {
            // The stepper feel: a tick roughly every 220ms rather than one
            // smooth haptic at the end, because a real feed motor pulses.
            repeat(7) {
                haptics.tick()
                delay(220)
            }
        }
        feed.animateTo(1f, tween(1700, easing = LinearEasing))
        haptics.sessionComplete()

        // Written while the slip is already on screen, so a slow filesystem
        // never holds up the animation.
        saved = Receipt.saveToDownloads(context, data)
        savedShown = true

        delay(700)
        lift.animateTo(0f, tween(420, easing = FastOutSlowInEasing))
        onDone()
    }

    // Stopped if this leaves the composition early -- backing out of the
    // screen mid-print should take the sound with it, not leave a printer
    // running over whatever comes next.
    DisposableEffect(Unit) {
        onDispose { PrintSound.stop() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .alpha(lift.value)
            .background(Color(0xFF0B0B10)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {

            // --- the slot, and the paper coming out of it ---
            Box(
                Modifier
                    .width(300.dp)
                    .height(420.dp),
                contentAlignment = Alignment.TopCenter,
            ) {
                // The glow behind the slot. Drawn before the clip so it spills
                // out around the opening rather than being cut to it.
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .alpha(slot.value)
                        .drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colorStops = arrayOf(
                                        0f to Color(0xFF7FD4FF).copy(alpha = 0.45f),
                                        0.5f to Color(0xFF7FD4FF).copy(alpha = 0.14f),
                                        1f to Color.Transparent,
                                    ),
                                    center = Offset(size.width / 2f, 30f),
                                    radius = size.width * 0.7f,
                                ),
                                radius = size.width * 0.7f,
                                center = Offset(size.width / 2f, 30f),
                            )
                        },
                )

                // The paper. Offset upward by its own height at feed = 0, so
                // at rest it sits entirely above the visible area and slides
                // down into view as feed goes to 1.
                Box(
                    Modifier
                        .padding(top = 26.dp)
                        .graphicsLayer {
                            translationY = -size.height * (1f - feed.value)
                            alpha = if (feed.value > 0.02f) 1f else 0f
                        },
                ) {
                    Slip(data, feed.value)
                }

                // The slot lip, drawn last so the paper passes behind it.
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(26.dp)
                        .graphicsLayer { scaleX = slot.value }
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(13.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF2A2A33), Color(0xFF101016)),
                            ),
                        ),
                )
            }

            Spacer(Modifier.height(22.dp))
            Text(
                if (savedShown && saved != null) "Receipt saved to Downloads"
                else if (savedShown) "Receipt ready"
                else "Printing…",
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.6f),
            )
        }
    }
}

/**
 * The slip itself. Monospace and dotted rules, matching the saved PNG.
 *
 * [printed] is the same feed value driving the outer translation. Slip masks
 * its own lower portion in white while printed < 1, so the paper is not just
 * sliding into frame already finished -- each line's turn to appear tracks
 * the same motor pulse the haptics are ticking to.
 */
@Composable
private fun Slip(data: AppData, printed: Float) {
    val stamp = remember {
        LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy · HH:mm"))
    }
    // The app's own paper, not thermal-till white.
    //
    // Plain black-on-white was the honest thermal reference, and it was also
    // the one screen in the whole app with none of its colour language on
    // it -- every card elsewhere is cream with a coloured header band and one
    // accent doing the talking. A Tang header and a Sky-tinted key box are
    // the same move Plans and Home already make; this just brings the
    // receipt in line with them instead of leaving it looking imported.
    Column(
        Modifier
            .width(272.dp)
            .clip(RoundedCornerShape(10.dp))
            .drawWithContent {
                drawContent()
                if (printed < 0.999f) {
                    // The unprinted portion, covered in whichever background
                    // that band actually is -- Tang behind the header, cream
                    // everywhere else -- so the reveal never flashes the
                    // wrong colour over a region it has not reached yet.
                    val cut = (size.height * (printed + 0.06f)).coerceAtMost(size.height)
                    val headerPx = 64.dp.toPx()
                    if (cut < headerPx) {
                        drawRect(
                            color = Tang.fill,
                            topLeft = Offset(0f, cut),
                            size = Size(size.width, headerPx - cut),
                        )
                        drawRect(
                            color = CreamCard,
                            topLeft = Offset(0f, headerPx),
                            size = Size(size.width, size.height - headerPx),
                        )
                    } else {
                        drawRect(
                            color = CreamCard,
                            topLeft = Offset(0f, cut),
                            size = Size(size.width, size.height - cut),
                        )
                    }
                }
            },
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Tang.fill)
                .padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "MOMENTUM",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = Ink,
            )
            Text(
                "focus, banked",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Ink.copy(alpha = 0.75f),
            )
        }

        Column(
            Modifier
                .background(CreamCard)
                .padding(horizontal = 18.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(stamp, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = InkMid)

            Spacer(Modifier.height(12.dp))
            DottedRule()
            Spacer(Modifier.height(12.dp))

            Text(
                "LICENCE KEY",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = InkMid,
            )
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Sky.fill.copy(alpha = 0.30f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            ) {
                Text(
                    License.pretty(data.licenseKey),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Ink,
                )
            }

            Spacer(Modifier.height(14.dp))
            DottedRule()
            Spacer(Modifier.height(12.dp))

            SlipRow("Item", "Lifetime")
            SlipRow("Holder", data.userName.ifBlank { "friend" })
            SlipRow("Focused", "${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m")
            // PAID in Mint -- the same colour this app already reaches for
            // whenever something is confirmed and settled.
            SlipRow("Status", "PAID", valueColor = Mint.accent)

            Spacer(Modifier.height(12.dp))
            DottedRule()
            Spacer(Modifier.height(10.dp))
            Text(
                "Blocking stays free. Always.",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = InkMid,
            )
        }
    }
}

@Composable
private fun SlipRow(label: String, value: String, valueColor: Color = Ink) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = InkMid)
        Text(
            value,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = valueColor,
        )
    }
}

@Composable
private fun DottedRule() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(1.dp)
            .drawBehind {
                var x = 0f
                while (x < size.width) {
                    drawRect(
                        color = Ink.copy(alpha = 0.45f),
                        topLeft = Offset(x, 0f),
                        size = androidx.compose.ui.geometry.Size(3f, size.height),
                    )
                    x += 7f
                }
            },
    )
}
