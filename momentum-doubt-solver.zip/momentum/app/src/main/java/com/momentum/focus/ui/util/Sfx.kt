package com.momentum.focus.ui.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import com.momentum.focus.R
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class Sound {
    POP, TICK, SUCCESS, ERROR, WHOOSH,
    // Supplied reference-pack cues, used sparingly for premium/UI moments.
    PACK_CLICK, PACK_BLEEP, PACK_RISER,
    // Cutscene.
    RISER, CRACK, BOOM, SHIMMER,
    // One per event, because two events sharing a sound is two events the ear
    // cannot tell apart. Celebrating a streak used to make the same noise as
    // logging a session, and sending a question to MyAi made the same noise as
    // both of them.
    SEND, REPLY, LEVEL, FESTIVE, SESSION, RIGHT, WRONG, UNLOCK,
    // The events that mean something. Generic taps stay on POP and TICK — an
    // app where every tap sounds different is not expressive, it is noisy —
    // but nothing that changes the state of a session, a shield or a wallet
    // should share a noise with tapping a chip.
    BEGIN, PANIC, SHIELD_ON, SHIELD_OFF, SPEND, SLIP,
}

/**
 * UI sounds generated as raw PCM at startup instead of shipped as .wav files.
 *
 * Two reasons: no binary assets to manage, and the tones can be tuned by
 * changing a number rather than re-exporting audio. Each sound is a sine with
 * an exponential decay envelope — a decay is what separates a "pop" from a
 * "beep", since a flat envelope always sounds like a cheap alarm.
 */
object Sfx {

    private const val RATE = 44100
    private val tracks = mutableMapOf<Sound, AudioTrack>()
    private val mediaTracks = mutableMapOf<Sound, MediaPlayer>()
    private var audioManager: AudioManager? = null
    /**
     * Off unless the user turns it on.
     *
     * A tick on every tap is fine once and grating by the fiftieth. The sounds
     * stay in the build for anyone who wants them, but nobody should have to
     * find the switch to stop them.
     */
    var enabled: Boolean = true

    fun init(context: Context) {
        if (tracks.isNotEmpty()) return
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        runCatching {
            // A pure sine is thin and plasticky. Adding a quiet octave and a
            // fifth above the root gives every sound a body, the same way a
            // real object resonates instead of beeping.
            // ---- one root per sound -------------------------------------
            // Every tone here sits on a frequency nothing else uses. They were
            // built from a handful of shared chords, so nine different events
            // arrived as the same beep at slightly different lengths — which
            // is the same as having one sound and playing it nine times.
            //
            // Roots, low to high, so it is obvious at a glance that none
            // repeat: SLIP 165 · PANIC 208 · WRONG 233 · BOOM 62 · BEGIN 294 ·
            // SESSION 349 · WHOOSH noise · SEND 622 · POP 466 · SUCCESS 523 ·
            // SHIELD 175/740 · SPEND 698 · TICK 1568 · FESTIVE 831 ·
            // RIGHT 988 · LEVEL 392→1046 · UNLOCK 1175 · REPLY 494

            // A tap. Highest and quietest thing in the file, because it plays
            // more often than everything else combined.
            tracks[Sound.TICK] = build(
                tone(1568f, 0.015f, decay = 150f, level = 0.08f)
            )
            tracks[Sound.POP] = build(chord(466f, 0.05f, decay = 44f))
            tracks[Sound.SUCCESS] = build(
                chord(523f, 0.09f, decay = 22f) + chord(784f, 0.16f, decay = 14f) +
                    chord(1046f, 0.22f, decay = 10f)
            )
            tracks[Sound.ERROR] = build(
                tone(110f, 0.18f, decay = 18f, pitchDrop = 0.35f, level = 0.26f)
            )
            tracks[Sound.WHOOSH] = build(noise(0.13f))

            // Cutscene.
            tracks[Sound.RISER] = build(riser(1.75f))
            tracks[Sound.CRACK] = build(crack(0.16f))
            tracks[Sound.BOOM] = build(boom(1.1f))
            tracks[Sound.SHIMMER] = build(
                chord(1319f, 0.20f, decay = 12f) + chord(1976f, 0.30f, decay = 8f)
            )

            // Outgoing: a short chirp going up. Quiet — it fires on every send.
            tracks[Sound.SEND] = build(glass(784f, 0.12f, decay = 26f, level = 0.15f))
            // Incoming: the mirror, going down, and longer so the pair reads
            // as a question and an answer rather than two taps.
            tracks[Sound.REPLY] = build(glass(523f, 0.22f, decay = 15f, level = 0.18f))

            // Three notes climbing. Nothing else in the file is three notes.
            tracks[Sound.LEVEL] = build(
                chord(392f, 0.07f, decay = 30f) +
                    chord(659f, 0.07f, decay = 26f) +
                    chord(1046f, 0.24f, decay = 14f)
            )
            tracks[Sound.FESTIVE] = build(
                chord(831f, 0.06f, decay = 38f) + chord(1245f, 0.11f, decay = 26f)
            )
            // Long and low. A finished session is the one thing here worth a
            // sound that takes its time.
            tracks[Sound.SESSION] = build(
                chord(349f, 0.22f, decay = 10f) + chord(440f, 0.28f, decay = 8f) +
                    chord(659f, 0.48f, decay = 6f)
            )
            tracks[Sound.RIGHT] = build(glass(988f, 0.16f, decay = 20f, level = 0.20f))
            // Dull, not harsh. A wrong answer on a practice test is something
            // the student did, not an error the app is reporting.
            tracks[Sound.WRONG] = build(
                tone(233f, 0.17f, decay = 17f, pitchDrop = 0.28f, level = 0.22f)
            )
            tracks[Sound.UNLOCK] = build(riser(0.45f) + glass(1175f, 0.55f, decay = 7f, level = 0.26f))

            // A session opening: two notes up over a soft floor.
            tracks[Sound.BEGIN] = build(
                chord(294f, 0.10f, decay = 18f) + chord(440f, 0.14f, decay = 16f) +
                    chord(587f, 0.32f, decay = 9f)
            )
            // Down and fast. Panic is pressed by someone not enjoying
            // themselves and must not sound like a reward.
            tracks[Sound.PANIC] = build(
                tone(208f, 0.22f, decay = 16f, pitchDrop = 0.55f, level = 0.26f)
            )
            // A door closing, then the same door opening.
            tracks[Sound.SHIELD_ON] = build(
                tone(175f, 0.10f, decay = 34f, level = 0.28f) + chord(740f, 0.10f, decay = 30f)
            )
            tracks[Sound.SHIELD_OFF] = build(
                chord(740f, 0.06f, decay = 40f) + tone(175f, 0.14f, decay = 26f, level = 0.24f)
            )
            // Coins leaving: two clicks, descending.
            tracks[Sound.SPEND] = build(
                chord(698f, 0.05f, decay = 46f) + chord(523f, 0.10f, decay = 30f)
            )
            // Flat and honest. A slip is a fact being written down.
            tracks[Sound.SLIP] = build(tone(165f, 0.20f, decay = 14f, level = 0.20f))

            // Preload the supplied short cues so playback never waits for decoding.
            mediaTracks[Sound.PACK_CLICK] = media(context, R.raw.sfx_click, 0.34f)
            mediaTracks[Sound.PACK_BLEEP] = media(context, R.raw.sfx_bleep_bloop, 0.18f)
            mediaTracks[Sound.PACK_RISER] = media(context, R.raw.sfx_riser, 0.26f)
        }
    }

    /**
     * A sound that plays whether or not the UI-sound switch is on.
     *
     * That switch exists because a chirp on every tap is grating by the
     * fiftieth time — its own note says so. A cutscene that runs once in the
     * lifetime of an install is not what it was written to silence. The silent
     * switch is still obeyed, because that one always wins.
     */
    fun playOnce(sound: Sound) {
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        playInternal(sound)
    }

    fun play(sound: Sound) {
        if (!enabled) return
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        playInternal(sound)
    }

    private fun playInternal(sound: Sound) {
        val media = mediaTracks[sound]
        if (media != null) {
            runCatching {
                if (media.isPlaying) media.seekTo(0)
                media.start()
            }
            return
        }
        val track = tracks[sound] ?: return
        runCatching {
            track.stop()
            track.reloadStaticData()
            track.play()
        }
    }

    fun release() {
        tracks.values.forEach { runCatching { it.release() } }
        tracks.clear()
        mediaTracks.values.forEach { runCatching { it.release() } }
        mediaTracks.clear()
        audioManager = null
    }

    // ---- synthesis --------------------------------------------------------

    /** Root plus an octave and a fifth, mixed low so it reads as timbre. */
    private fun chord(
        freq: Float,
        seconds: Float,
        decay: Float,
        pitchDrop: Float = 0f,
    ): ShortArray {
        val root = tone(freq, seconds, decay, pitchDrop, level = 0.24f)
        val octave = tone(freq * 2f, seconds, decay * 1.4f, pitchDrop, level = 0.09f)
        val fifth = tone(freq * 1.5f, seconds, decay * 1.2f, pitchDrop, level = 0.06f)
        return ShortArray(root.size) { i ->
            (root[i] + octave[i] + fifth[i]).coerceIn(
                Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()
            ).toShort()
        }
    }

    /**
     * A struck-glass note: a fundamental with inharmonic partials above it.
     *
     * This is the difference between the app sounding cheap and sounding
     * finished, and it is not volume or length — it is harmonics. Every cue in
     * here was a single sine, and a single sine is a test tone. Nothing in the
     * physical world makes one: a struck glass, a chime, a key on a rhodes all
     * ring at a fundamental plus a stack of partials, and the ear identifies
     * "an object was struck" from the partials, not the fundamental.
     *
     * The partials are deliberately not whole-number multiples. Integer
     * harmonics give a brassy, musical tone; slightly stretched ones (2.76,
     * 5.40) are what bells and glass actually do, and are why a real chime
     * sounds like an object rather than a synthesiser.
     *
     * Each partial also decays faster than the one below it, which is what
     * happens in a struck object — the high frequencies bleed out first and the
     * fundamental hangs on. A stack that decays uniformly sounds like an organ.
     */
    private fun glass(
        freq: Float,
        seconds: Float,
        decay: Float,
        level: Float = 0.22f,
    ): ShortArray {
        val n = (RATE * seconds).toInt()
        // Partial ratio to relative loudness. The top one is quiet on purpose:
        // it is there to be heard as brightness in the first few milliseconds,
        // not as a note.
        val partials = listOf(
            1.00f to 1.00f,
            2.76f to 0.42f,
            5.40f to 0.16f,
            8.93f to 0.06f,
        )
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            var sum = 0.0
            partials.forEach { (ratio, weight) ->
                // Higher partials die sooner — ratio scales the decay.
                val env = exp(-decay * ratio * 0.55f * t)
                sum += sin(2.0 * PI * freq * ratio * t) * env * weight
            }
            // Normalised by the total weight so adding a partial does not
            // make the cue louder, only richer.
            val norm = sum / partials.sumOf { it.second.toDouble() }
            val attack = (i / 90f).coerceAtMost(1f)
            (norm * attack * Short.MAX_VALUE * level).toInt().toShort()
        }
    }

    private fun tone(
        freq: Float,
        seconds: Float,
        decay: Float,
        pitchDrop: Float = 0f,
        level: Float = 0.28f,
    ): ShortArray {
        val n = (RATE * seconds).toInt()
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            // Sliding the frequency down over the note gives the sound a body,
            // like something physical settling.
            val f = freq * (1f - pitchDrop * (i.toFloat() / n))
            val envelope = exp(-decay * t)
            // A short fade-in kills the click that a hard start produces.
            val attack = (i / 140f).coerceAtMost(1f)
            (sin(2.0 * PI * f * t) * envelope * attack * Short.MAX_VALUE * level)
                .toInt().toShort()
        }
    }

    /**
     * A climb. Frequency rises, and so does the level — the swell is what makes
     * it read as something coming rather than something leaving.
     */
    private fun riser(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(11)
        return ShortArray(n) { i ->
            val p = i.toFloat() / n
            val t = i.toFloat() / RATE
            // Curved, not linear: a straight sweep sounds like a test tone.
            val f = 110f + 700f * p * p
            val swell = p * p
            val body = sin(2.0 * PI * f * t) * 0.6
            val air = (rng.nextFloat() * 2 - 1) * 0.25f * p
            ((body + air) * swell * Short.MAX_VALUE * 0.30).toInt().toShort()
        }
    }

    /** Short, bright, ugly on purpose. Something giving way. */
    private fun crack(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(7)
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            val envelope = exp(-70f * t)
            val snap = (rng.nextFloat() * 2 - 1)
            val ring = sin(2.0 * PI * 2400f * t) * 0.4
            ((snap + ring) * envelope * Short.MAX_VALUE * 0.30).toInt().toShort()
        }
    }

    /**
     * The hit. Low sine sliding down, with a noise transient on the front.
     *
     * Phone speakers cannot reproduce 45Hz, so the fundamental is felt more
     * than heard — the octave above it is what carries on a small speaker,
     * which is why it is mixed in rather than left to chance.
     */
    private fun boom(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(3)
        return ShortArray(n) { i ->
            val p = i.toFloat() / n
            val t = i.toFloat() / RATE
            val f = 62f * (1f - 0.35f * p)
            val envelope = exp(-4.2f * t)
            val sub = sin(2.0 * PI * f * t) * 0.75
            val octave = sin(2.0 * PI * f * 2 * t) * 0.30
            val transient = (rng.nextFloat() * 2 - 1) * exp(-60f * t) * 0.5f
            ((sub + octave + transient) * envelope * Short.MAX_VALUE * 0.34)
                .toInt().toShort()
        }
    }

    private fun noise(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(4)
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            // Low-passed noise: averaging consecutive samples removes the
            // hiss and leaves the soft rush of air.
            val envelope = exp(-26f * t)
            val n = (rng.nextFloat() * 2 - 1) * 0.5f + (rng.nextFloat() * 2 - 1) * 0.5f
            (n * envelope * Short.MAX_VALUE * 0.13).toInt().toShort()
        }
    }

    private operator fun ShortArray.plus(other: ShortArray): ShortArray {
        val out = ShortArray(size + other.size)
        copyInto(out)
        other.copyInto(out, size)
        return out
    }

    private fun media(context: Context, resId: Int, volume: Float): MediaPlayer {
        return MediaPlayer.create(
            context.applicationContext,
            resId,
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build(),
            0,
        ).also { it.setVolume(volume, volume) }
    }

    private fun build(samples: ShortArray): AudioTrack {
        val bytes = samples.size * 2
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bytes)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(samples, 0, samples.size)
        return track
    }
}
