package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.momentum.focus.ai.DoubtState
import com.momentum.focus.ai.MyAiMode
import com.momentum.focus.ai.StudyPulse
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.ui.components.DoubtSheet
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Tang

/** The word behind the header, same trick Plans uses. */
private const val GHOST = "MYAI"

/**
 * MyAi, drawn on paper rather than on a panel.
 *
 * The screen owns the background, the grain, the ghost word and the aura; the
 * chat is laid on top of all of it with nothing opaque of its own. That order
 * is the whole fix — the embedded sheet used to fill the screen with Cream and
 * bury both the ghost and the aura it was supposed to be sitting on.
 */
@Composable
fun MyAiScreen(
    state: DoubtState,
    clock: String?,
    mode: MyAiMode,
    onMode: (MyAiMode) -> Unit,
    pulse: StudyPulse?,
    onAsk: (String, String?) -> Unit,
    onRetry: () -> Unit,
    onStop: () -> Unit,
    onClose: () -> Unit,
    premium: Boolean = false,
    onPlans: () -> Unit = {},
    onMock: ((String?) -> Unit)? = null,
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding(),
    ) {
        // The aura goes around the ghost, not around nothing. It used to be a
        // 100dp band across the top with an empty 16dp box inside it, which is
        // a disc of gold sitting on blank paper — and Aura's own rule is that
        // it haloes something. Nobody had ever seen it to notice, because the
        // chat panel was painting over it; now that it shows, it needs an
        // object. Premium glows harder, which is the only place on this screen
        // that says so.
        Aura(
            color = GoldNeon,
            strength = if (premium) 0.55f else 0.26f,
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart)
                .padding(horizontal = Paper.ScreenPad),
        ) {
            // Measured to the width that exists rather than guessed at, which
            // is the same solve Plans does: the word is measured at a probe
            // size, the trailing letter-space is taken off, and the result is
            // scaled to the margin. Hand-picked sizes either overrun the right
            // edge or stop short of it, differently on every screen.
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val density = LocalDensity.current
                val measurer = rememberTextMeasurer()
                // em, not sp, so the tracking grows with the letters instead of
                // tightening as the word gets bigger.
                val tracking = 0.42.em
                val ghostSize = remember(maxWidth, density) {
                    val probe = 40.sp
                    val measured = measurer.measure(
                        GHOST,
                        TextStyle(
                            fontSize = probe,
                            letterSpacing = tracking,
                            fontWeight = FontWeight.Bold,
                        ),
                    ).size.width.toFloat()
                    val trailing = with(density) { probe.toPx() } * 0.42f
                    val target = with(density) { maxWidth.toPx() }
                    // 0.98, not 1.0. Four letters scaled to the full width is
                    // roughly an eight-fold blow-up of the probe, so a rounding
                    // error of a pixel at 40sp is eight pixels here — which is
                    // an I sliced off the end. A two percent margin costs
                    // nothing visible and cannot clip.
                    if (measured <= trailing) probe
                    else probe * (target / (measured - trailing)) * 0.98f
                }
                // The line box has to be taller than the letters, not equal to
                // them. At lineHeight == fontSize a bold cap sits right on the
                // edge of its own box and the top of every letter is shaved —
                // which is what was happening, and at this size the shaved
                // strip is thick enough to read as a broken font.
                val lift = with(density) { (ghostSize * 0.30f).toDp() }
                Text(
                    GHOST,
                    fontSize = ghostSize,
                    lineHeight = ghostSize * 1.25f,
                    letterSpacing = tracking,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                    color = Tang.accent.copy(alpha = 0.13f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .fillMaxWidth()
                        // Pulled up by a share of its own size. A fixed -6dp
                        // did nothing at this scale: the taller line box drops
                        // the letters far below the top of the screen, and the
                        // amount it drops them grows with the font.
                        .offset(y = -lift),
                )
            }
        }
        DoubtSheet(
            state = state,
            clock = clock,
            onAsk = onAsk,
            onRetry = onRetry,
            onStop = onStop,
            onClose = onClose,
            mode = mode,
            onMode = onMode,
            pulse = pulse,
            embedded = true,
            premium = premium,
            onPlans = onPlans,
            onMock = onMock,
        )
    }
}
