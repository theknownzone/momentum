package com.momentum.focus.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.size
import com.momentum.focus.ui.components.AiZomatoReveal
import com.momentum.focus.ui.components.HaloGlass
import com.momentum.focus.ui.components.LiquidGlass
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.Ink
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Tune
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import com.momentum.focus.ui.components.FrostScrim
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.momentum.focus.ai.MyAiMode
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileObject
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.Cream
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.InkLow
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import kotlinx.coroutines.delay
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.momentum.focus.ai.DoubtState
import com.momentum.focus.ai.StudyPulse
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.ui.components.DoubtSheet
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Tang

/** The word behind the header, same trick Plans uses. */
private const val GHOST = "MYAI"

/**
 * MyAi, drawn on paper rather than on a panel.
 *
 * The screen owns the background, the grain, the ghost word and the aura; the
 * chat is laid on top of all of it with nothing opaque of its own. That order
 * is the whole fix — the embedded sheet used to fill the screen with Cream and
 * bury both the ghost and the aura it was supposed to be sitting on.
 */
@Composable
fun MyAiScreen(
    state: DoubtState,
    clock: String?,
    mode: MyAiMode,
    onMode: (MyAiMode) -> Unit,
    pulse: StudyPulse?,
    onAsk: (String, List<String>, Boolean) -> Unit,
    onRetry: () -> Unit,
    onStop: () -> Unit,
    onClose: () -> Unit,
    premium: Boolean = false,
    onPlans: () -> Unit = {},
    onMock: ((String?) -> Unit)? = null,
    name: String = "",
) {
    var modesOpen by remember { mutableStateOf(false) }
    var toastMode by remember { mutableStateOf<MyAiMode?>(null) }
    /**
     * The last mode shown, kept after [toastMode] is cleared.
     *
     * The banner animates out rather than disappearing, so it is still on
     * screen for a few hundred milliseconds after the trigger is gone. Reading
     * toastMode directly during that window gives null, and the banner would
     * blank its own text and colour halfway through sliding away.
     */
    var lastToastMode by remember { mutableStateOf(MyAiMode.Study) }
    LaunchedEffect(toastMode) {
        val shown = toastMode ?: return@LaunchedEffect
        lastToastMode = shown
        // Long enough to read two lines, which is what the banner now carries.
        delay(2200)
        toastMode = null
    }

    // Fires once per entry into this screen, the same way entryScan did —
    // MyAi is torn down and rebuilt every time its tab is left and
    // re-entered, so a fresh `remember` here needs no separate tracking for
    // "has this already played".
    //
    // Replaces entryScan rather than running alongside it: both fire on the
    // same trigger (opening this screen), and a halftone sweep followed
    // immediately by a full shimmer takeover is two different animations
    // fighting for the same half-second. One entry moment, one effect.
    var revealDone by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        // This inner Box is where statusBarsPadding lives, and that is
        // exactly why the reveal at the bottom of this function has to sit
        // outside it. statusBarsPadding insets the space this Box hands to
        // its *children* — the header, the ghost, the chat all correctly
        // start below the status bar. But AiZomatoReveal was one of those
        // children, so its own fillMaxSize() only ever filled the padded
        // remainder, not the true screen. The Box's own background paint
        // (applied before the padding, so unaffected by it) still covered
        // the true full bounds — which is exactly why a sliver of cream
        // paper was visible above the reveal's dark scrim instead of the
        // scrim reaching the physical top of the screen.
        Box(
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .paperGrain()
                .statusBarsPadding(),
        ) {
            // The aura goes around the ghost, not around nothing. It used to be a
            // 100dp band across the top with an empty 16dp box inside it, which is
            // a disc of gold sitting on blank paper — and Aura's own rule is that
        // it haloes something. Nobody had ever seen it to notice, because the
        // chat panel was painting over it; now that it shows, it needs an
        // object. Premium glows harder, which is the only place on this screen
        // that says so.
        Aura(
            color = GoldNeon,
            strength = if (premium) 0.55f else 0.26f,
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart)
                .padding(horizontal = Paper.ScreenPad),
        ) {
            // Measured to the width that exists rather than guessed at, which
            // is the same solve Plans does: the word is measured at a probe
            // size, the trailing letter-space is taken off, and the result is
            // scaled to the margin. Hand-picked sizes either overrun the right
            // edge or stop short of it, differently on every screen.
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val density = LocalDensity.current
                val measurer = rememberTextMeasurer()
                // em, not sp, so the tracking grows with the letters instead of
                // tightening as the word gets bigger.
                //
                // Tighter than the 0.42 Plans uses, because Plans has a longer
                // word. Four letters stretched across a whole phone leaves gaps
                // wide enough that MYAI stops reading as a word and becomes
                // four separate marks.
                val tracking = 0.20.em
                val ghostSize = remember(maxWidth, density) {
                    val probe = 40.sp
                    val measured = measurer.measure(
                        GHOST,
                        TextStyle(
                            fontSize = probe,
                            letterSpacing = tracking,
                            fontWeight = FontWeight.Bold,
                        ),
                    ).size.width.toFloat()
                    val trailing = with(density) { probe.toPx() } * 0.20f
                    // Short of the full width. The share button sits in the top
                    // right corner, and at full width the final I landed
                    // underneath it — which is why the word read as MYA.
                    val target = with(density) { maxWidth.toPx() } * 0.86f
                    // 0.98, not 1.0. Four letters scaled to the full width is
                    // roughly an eight-fold blow-up of the probe, so a rounding
                    // error of a pixel at 40sp is eight pixels here — which is
                    // an I sliced off the end. A two percent margin costs
                    // nothing visible and cannot clip.
                    if (measured <= trailing) probe
                    else probe * (target / (measured - trailing)) * 0.98f
                }
                // The line box has to be taller than the letters, not equal to
                // them. At lineHeight == fontSize a bold cap sits right on the
                // edge of its own box and the top of every letter is shaved —
                // which is what was happening, and at this size the shaved
                // strip is thick enough to read as a broken font.
                val lift = with(density) { (ghostSize * 0.30f).toDp() }
                // Reverted to a fixed alpha.
                //
                // A breathing pulse was added here without being asked for —
                // the actual request was glassy buttons, nothing about this
                // watermark's own animation. Confirmed after seeing it in use
                // that the original static version was the one that read
                // correctly; the pulse was scope creep, not a fix.
                Text(
                    GHOST,
                    fontSize = ghostSize,
                    lineHeight = ghostSize * 1.25f,
                    letterSpacing = tracking,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                    color = Tang.accent.copy(alpha = 0.13f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .fillMaxWidth()
                        // Pulled up by a share of its own size. A fixed -6dp
                        // did nothing at this scale: the taller line box drops
                        // the letters far below the top of the screen, and the
                        // amount it drops them grows with the font.
                        .offset(y = -lift),
                )
            }
        }
        // Its own header, because the tab bar is gone on this screen.
        //
        // Back on the left, tune on the right — two small buttons, not one
        // wide capsule between them. That capsule was built and pressure-
        // tested, but it was never what was asked for: the request was
        // "make the back and mode buttons feel glassy", not "combine them
        // into one shared surface". Worse, the capsule's width collided with
        // the mode-switch banner — both now claimed the same band across the
        // top of the screen, and the video that came back showed them
        // overlapping. Two independent LiquidGlass circles, each sized to
        // its own icon, keep the requested glass feel without occupying the
        // banner's own space.
        Box(
            Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart)
                .padding(start = 10.dp, top = 6.dp, end = 10.dp),
        ) {
            LiquidGlass(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .size(42.dp),
                radius = 21.dp,
                tint = Color.White,
                onClick = onClose,
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = strings().doubt.close,
                    tint = Ink,
                    modifier = Modifier.size(20.dp).align(Alignment.Center),
                )
            }
            LiquidGlass(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(42.dp),
                radius = 21.dp,
                tint = Color.White,
                onClick = { modesOpen = true },
            ) {
                Icon(
                    Icons.Filled.Tune,
                    contentDescription = strings().doubt.menu,
                    tint = Ink,
                    modifier = Modifier.size(20.dp).align(Alignment.Center),
                )
            }
        }

        DoubtSheet(
            state = state,
            clock = clock,
            onAsk = onAsk,
            onRetry = onRetry,
            onStop = onStop,
            onClose = onClose,
            mode = mode,
            onMode = onMode,
            pulse = pulse,
            embedded = true,
            premium = premium,
            onPlans = onPlans,
            onMock = onMock,
            name = name,
        )

        if (modesOpen) {
            ModeSheet(
                mode = mode,
                onMode = {
                    onMode(it)
                    modesOpen = false
                    toastMode = it
                    // Switching mode changes who is answering, which is a state
                    // change and not a tap — so it gets its own cue rather than
                    // the generic chip tick.
                    Sfx.play(Sound.POP)
                },
                premium = premium,
                onPlans = { modesOpen = false; onPlans() },
                onClose = { modesOpen = false },
            )
        }
        // The mode banner, built the way iOS builds one.
        //
        // It was a flat coloured rectangle with a hard Ink border that appeared
        // and vanished with no movement at all — an alert, for something that
        // is not an alert. What makes the iOS version read as a confirmation
        // rather than a warning is the shape and the motion: a full capsule, an
        // icon in a filled circle on the left, two lines of text with the
        // action on top and the detail under it, a translucent light surface
        // instead of a saturated fill, a soft drop shadow, and a spring that
        // overshoots slightly on the way in and slides straight up on the way
        // out.
        AnimatedVisibility(
            visible = toastMode != null,
            modifier = Modifier.align(Alignment.TopCenter),
            // Siri's entrance, not a drop-down.
            //
            // What makes the iOS 26 / Siri surface read as liquid is that it
            // does not arrive at its final size — it spreads into it. The
            // capsule comes in narrow and short from above, and swells out to
            // full width as it settles, so the glass looks like it is flowing
            // into the shape rather than being placed there.
            //
            // scaleIn from 0.86 with a spring is that spread. Damping 0.75 and
            // stiffness 400 are the same numbers the press uses, so every glass
            // surface in the app moves with one physics rather than three.
            enter = scaleIn(
                initialScale = 0.86f,
                transformOrigin = TransformOrigin(0.5f, 0f),
                animationSpec = spring(dampingRatio = 0.75f, stiffness = 400f),
            ) + slideInVertically(
                animationSpec = spring(dampingRatio = 0.75f, stiffness = 400f),
                initialOffsetY = { -it },
            ) + fadeIn(animationSpec = spring(stiffness = 400f)),
            // Contracts on the way out — the reverse of the spread, so it
            // leaves the way it came rather than sliding off as a solid slab.
            exit = scaleOut(
                targetScale = 0.92f,
                transformOrigin = TransformOrigin(0.5f, 0f),
            ) + slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
        ) {
            val popped = toastMode ?: lastToastMode
            val sticker = when (popped) {
                MyAiMode.Friend -> Lilac
                MyAiMode.Guru -> Butter
                else -> Mint
            }
            val name = when (popped) {
                MyAiMode.Friend -> strings().doubt.modeFriend
                MyAiMode.Guru -> strings().doubt.modeGuru
                else -> strings().doubt.modeStudy
            }
            // HaloGlass, not CeramicPanel.
            //
            // Ceramic is this app's everyday material -- milk-white, sits on
            // cream paper all day, exactly right for the composer. The
            // reference photo asked for is the opposite material: dark glass,
            // one glowing accent colour, grain instead of Ben-Day dots. Using
            // Ceramic here was reaching for the material already at hand
            // rather than the one actually being asked for.
            //
            // wrapContentWidth(), not fillMaxWidth or a weighted child.
            //
            // This banner was stretching to nearly the full screen width
            // despite nothing in it calling fillMaxWidth -- the cause was
            // Modifier.weight(1f) on the text Column. weight() distributes a
            // Row's *incoming* width constraint among its children, and that
            // constraint traces back to the screen-filling Box several
            // parents up regardless of whether anything in between asked for
            // full width. A weighted child inside an otherwise wrap-content
            // Row still expands to fill the ancestor's bounds. Removing the
            // weight and giving the text a sane width ceiling instead is what
            // makes this a compact, centred pill rather than a banner.
            //
            // One line of text, not two.
            //
            // The two-line version (name, then "name mode active" under it)
            // put this pill's height at icon-or-31dp-of-text plus 20dp of
            // padding — 51dp, worse than the 45dp version it replaced, which
            // was already only 1dp under DoubtSheet's 46dp safe zone and was
            // still visibly touching it in the screenshot. Stacking two lines
            // means every future tweak to font size, padding or icon size has
            // to be re-added up by hand against that 46dp ceiling, which is
            // exactly the arithmetic that went wrong twice in a row. One line
            // removes the ceiling as a live concern: modeOn(name) already
            // says "Guru mode active" by itself, so the separate name line
            // above it was restating the same word rather than adding one.
            HaloGlass(
                modifier = Modifier
                    .padding(top = 4.dp)
                    // Elevation trimmed too — a shadow's blur draws outside
                    // its layout bounds, so a 16dp elevation could visibly
                    // bleed into the status pill even once the panel's own
                    // measured height cleared it.
                    .shadow(8.dp, RoundedCornerShape(20.dp), clip = false),
                radius = 20.dp,
                tint = sticker.fill,
            ) {
                Row(
                    Modifier.padding(horizontal = 13.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    // The icon in its own filled circle, glowing again in its
                    // own small halo -- the reference's icon sits inside the
                    // same pool of light as the card around it, not just a
                    // flat coloured dot.
                    Box(
                        Modifier.size(22.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(
                            Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        listOf(
                                            sticker.fill,
                                            sticker.fill.copy(alpha = 0.75f),
                                        ),
                                    ),
                                ),
                        )
                        Icon(
                            Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(13.dp),
                        )
                    }
                    Spacer(Modifier.width(9.dp))
                    // White on dark glass, not Ink on cream -- this panel is
                    // the one dark surface in the app, and Ink text on it
                    // would be close to unreadable.
                    Text(
                        strings().doubt.modeOn(name),
                        fontSize = 13.5.sp,
                        lineHeight = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = 210.dp),
                    )
                }
            }
        }
        }

        // Drawn last, so it sits on top of the header, the ghost, the
        // chat -- everything -- for the short window it is alive. Once
        // alive flips to false it stops rendering entirely rather than
        // fading, which matches the reference: the skeleton screen is
        // replaced by real content, not dissolved into it.
        //
        // A sibling of the statusBarsPadding'd Box now, not a child of it —
        // see the comment on that Box for why: a child there only ever fills
        // the padded remainder, and this needs the true full screen,
        // including the status bar strip, to actually cover the scrim edge
        // to edge.
        if (!revealDone) {
            AiZomatoReveal(name = name) { revealDone = true }
        }
    }
}

/**
 * The three modes, as a sheet rather than a row.
 *
 * A row of three chips — two of them carrying a "· Pro" suffix — was most of a
 * phone's width, permanently, for a control touched about once a session. Here
 * each one gets its name, a line saying what it does, and enough room to be
 * read once instead of guessed at forever.
 */
@Composable
private fun ModeSheet(
    mode: MyAiMode,
    onMode: (MyAiMode) -> Unit,
    premium: Boolean,
    onPlans: () -> Unit,
    onClose: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    FrostScrim {
        Box(
            Modifier
                .fillMaxSize()
                .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
        )
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .background(Cream)
                    .border(
                        Paper.Outline,
                        Ink,
                        RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    )
                    .clickableNoRipple(remember { MutableInteractionSource() }) { }
                    .padding(20.dp),
            ) {
                Text(
                    str.doubt.modesTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                )
                Spacer(Modifier.height(14.dp))
                MyAiMode.entries.forEach { item ->
                    val on = item == mode
                    val locked = item != MyAiMode.Study && !premium
                    val what = when (item) {
                        MyAiMode.Study -> str.doubt.modeStudyWhat
                        MyAiMode.Friend -> str.doubt.modeFriendWhat
                        MyAiMode.Guru -> str.doubt.modeGuruWhat
                    }
                    val label = when (item) {
                        MyAiMode.Study -> str.doubt.modeStudy
                        MyAiMode.Friend -> str.doubt.modeFriend
                        MyAiMode.Guru -> str.doubt.modeGuru
                    }
                    val sticker = when (item) {
                        MyAiMode.Study -> Mint
                        MyAiMode.Friend -> Lilac
                        MyAiMode.Guru -> Butter
                    }
                    val art = when (item) {
                        MyAiMode.Study -> TileArt.Journal
                        MyAiMode.Friend -> TileArt.Person
                        MyAiMode.Guru -> TileArt.Medal
                    }
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .clip(RoundedCornerShape(Paper.CardRadius))
                            .background(if (on) sticker.fill else CreamCard)
                            .drawBehind {
                                val step = 9.dp.toPx()
                                val dot = sticker.accent.copy(alpha = if (on) 0.28f else 0.12f)
                                var y = step
                                while (y < size.height) {
                                    var x = step * ((y / step).toInt() % 2) * 0.5f
                                    while (x < size.width) {
                                        drawCircle(dot, 1.35f, Offset(x, y))
                                        x += step
                                    }
                                    y += step
                                }
                            }
                            .border(
                                if (on) Paper.Outline else 1.5.dp,
                                Ink,
                                RoundedCornerShape(Paper.CardRadius),
                            )
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick()
                                if (locked) onPlans() else onMode(item)
                            }
                            .padding(14.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TileObject(
                                art = art,
                                fill = if (on) sticker.fill else InkLow,
                                size = 28.dp,
                            )
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    if (locked) "$label  ·  ${str.doubt.proTag}" else label,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Ink.copy(alpha = if (locked) 0.5f else 1f),
                                )
                                Text(
                                    what,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (on) sticker.on.copy(alpha = 0.8f) else InkMid,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
