package com.momentum.focus.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.size
import com.momentum.focus.ui.components.HaloGlass
import com.momentum.focus.ui.components.AiZomatoReveal
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.Ink
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import com.momentum.focus.ui.components.FrostScrim
import com.momentum.focus.ui.components.Aura
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.TextOverflow
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.em
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import com.momentum.focus.ai.MyAiMode
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileObject
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.Cream
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.InkLow
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import kotlinx.coroutines.delay
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ai.DoubtState
import com.momentum.focus.ai.StudyPulse
import com.momentum.focus.ui.components.DoubtSheet
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.Tang

/** The word behind the header, same trick Plans uses. */
private const val GHOST = "MYAI"

/**
 * MyAi, drawn on paper rather than on a panel.
 *
 * The screen owns the background, the grain, the ghost word and the aura; the
 * chat is laid on top of all of it with nothing opaque of its own. That order
 * is the whole fix — the embedded sheet used to fill the screen with Cream and
 * bury both the ghost and the aura it was supposed to be sitting on.
 */
@Composable
fun MyAiScreen(
    state: DoubtState,
    clock: String?,
    mode: MyAiMode,
    onMode: (MyAiMode) -> Unit,
    pulse: StudyPulse?,
    onAsk: (String, List<String>, Boolean) -> Unit,
    onRetry: () -> Unit,
    onStop: () -> Unit,
    onClose: () -> Unit,
    premium: Boolean = false,
    onPlans: () -> Unit = {},
    onMock: ((String?) -> Unit)? = null,
    name: String = "",
) {
    var modesOpen by remember { mutableStateOf(false) }
    var showAiReveal by remember { mutableStateOf(true) }
    var toastMode by remember { mutableStateOf<MyAiMode?>(null) }
    /**
     * The last mode shown, kept after [toastMode] is cleared.
     *
     * The banner animates out rather than disappearing, so it is still on
     * screen for a few hundred milliseconds after the trigger is gone. Reading
     * toastMode directly during that window gives null, and the banner would
     * blank its own text and colour halfway through sliding away.
     */
    var lastToastMode by remember { mutableStateOf(MyAiMode.Study) }
    LaunchedEffect(toastMode) {
        val shown = toastMode ?: return@LaunchedEffect
        lastToastMode = shown
        // Long enough to read two lines, which is what the banner now carries.
        delay(2200)
        toastMode = null
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding(),
    ) {
        // Main MYAI ghost is intentional: it is the visual identity of this screen.
        // It sits behind the header and content, exactly like the other Momentum
        // feature screens. The mode/settings surfaces can use the same treatment.
        Aura(
            color = Tang.accent,
            strength = if (premium) 0.42f else 0.20f,
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart)
                .padding(horizontal = Paper.ScreenPad),
        ) {
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val density = LocalDensity.current
                val measurer = rememberTextMeasurer()
                val tracking = 0.20.em
                val ghostSize = remember(maxWidth, density) {
                    val probe = 40.sp
                    val measured = measurer.measure(
                        GHOST, TextStyle(fontSize = probe, letterSpacing = tracking, fontWeight = FontWeight.Bold)
                    ).size.width.toFloat()
                    val trailing = with(density) { probe.toPx() } * 0.20f
                    val target = with(density) { maxWidth.toPx() } * 0.86f
                    if (measured <= trailing) probe else probe * (target / (measured - trailing)) * 0.98f
                }
                val lift = with(density) { (ghostSize * 0.30f).toDp() }
                Text(
                    GHOST,
                    fontSize = ghostSize,
                    lineHeight = ghostSize * 1.25f,
                    letterSpacing = tracking,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                    color = Tang.accent.copy(alpha = 0.13f),
                    modifier = Modifier.fillMaxWidth().offset(y = -lift),
                )
            }
        }

        // Minimal floating header: aligned controls, no pill.
        Row(
            Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart)
                .padding(horizontal = 16.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(42.dp).clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.36f))
                    .border(1.dp, Color.White.copy(alpha = 0.68f), CircleShape)
                    .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, strings().doubt.close, tint = Ink, modifier = Modifier.size(21.dp))
            }
            Spacer(Modifier.weight(1f))
            Text("My AI", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(42.dp).clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.36f))
                    .border(1.dp, Color.White.copy(alpha = 0.68f), CircleShape)
                    .clickableNoRipple(remember { MutableInteractionSource() }) { modesOpen = true },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.MoreHoriz, strings().doubt.menu, tint = Ink, modifier = Modifier.size(21.dp))
            }
        }

        DoubtSheet(
            state = state,
            clock = clock,
            onAsk = onAsk,
            onRetry = onRetry,
            onStop = onStop,
            onClose = onClose,
            mode = mode,
            onMode = onMode,
            pulse = pulse,
            embedded = true,
            premium = premium,
            onPlans = onPlans,
            onMock = onMock,
            name = name,
        )

        if (showAiReveal) {
            AiZomatoReveal(
                name = name,
                onFinished = { showAiReveal = false },
            )
        }

        AnimatedVisibility(
            visible = modesOpen,
            enter = fadeIn(animationSpec = spring(stiffness = 520f)) +
                slideInVertically(
                    initialOffsetY = { it / 2 },
                    animationSpec = spring(dampingRatio = 0.78f, stiffness = 420f),
                ),
            exit = fadeOut(animationSpec = spring(stiffness = 520f)) +
                slideOutVertically(
                    targetOffsetY = { it / 2 },
                    animationSpec = spring(dampingRatio = 0.9f, stiffness = 520f),
                ),
        ) {
            ModeSheet(
                mode = mode,
                onMode = {
                    onMode(it)
                    modesOpen = false
                    toastMode = it
                    // Switching mode changes who is answering, which is a state
                    // change and not a tap — so it gets its own cue rather than
                    // the generic chip tick.
                    Sfx.play(Sound.POP)
                },
                premium = premium,
                onPlans = { modesOpen = false; onPlans() },
                onClose = { modesOpen = false },
            )
        }
        // The mode banner, built the way iOS builds one.
        //
        // It was a flat coloured rectangle with a hard Ink border that appeared
        // and vanished with no movement at all — an alert, for something that
        // is not an alert. What makes the iOS version read as a confirmation
        // rather than a warning is the shape and the motion: a full capsule, an
        // icon in a filled circle on the left, two lines of text with the
        // action on top and the detail under it, a translucent light surface
        // instead of a saturated fill, a soft drop shadow, and a spring that
        // overshoots slightly on the way in and slides straight up on the way
        // out.
        AnimatedVisibility(
            visible = toastMode != null,
            modifier = Modifier.align(Alignment.TopCenter),
            // Siri's entrance, not a drop-down.
            //
            // What makes the iOS 26 / Siri surface read as liquid is that it
            // does not arrive at its final size — it spreads into it. The
            // capsule comes in narrow and short from above, and swells out to
            // full width as it settles, so the glass looks like it is flowing
            // into the shape rather than being placed there.
            //
            // scaleIn from 0.86 with a spring is that spread. Damping 0.75 and
            // stiffness 400 are the same numbers the press uses, so every glass
            // surface in the app moves with one physics rather than three.
            enter = scaleIn(
                initialScale = 0.86f,
                transformOrigin = TransformOrigin(0.5f, 0f),
                animationSpec = spring(dampingRatio = 0.75f, stiffness = 400f),
            ) + slideInVertically(
                animationSpec = spring(dampingRatio = 0.75f, stiffness = 400f),
                initialOffsetY = { -it },
            ) + fadeIn(animationSpec = spring(stiffness = 400f)),
            // Contracts on the way out — the reverse of the spread, so it
            // leaves the way it came rather than sliding off as a solid slab.
            exit = scaleOut(
                targetScale = 0.92f,
                transformOrigin = TransformOrigin(0.5f, 0f),
            ) + slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
        ) {
            val popped = toastMode ?: lastToastMode
            val sticker = when (popped) {
                MyAiMode.Friend -> Lilac
                MyAiMode.Guru -> Butter
                else -> Mint
            }
            val name = when (popped) {
                MyAiMode.Friend -> strings().doubt.modeFriend
                MyAiMode.Guru -> strings().doubt.modeGuru
                else -> strings().doubt.modeStudy
            }
            // HaloGlass, not CeramicPanel.
            //
            // Ceramic is this app's everyday material -- milk-white, sits on
            // cream paper all day, exactly right for the composer. The
            // reference photo asked for is the opposite material: dark glass,
            // one glowing accent colour, grain instead of Ben-Day dots. Using
            // Ceramic here was reaching for the material already at hand
            // rather than the one actually being asked for.
            //
            // wrapContentWidth(), not fillMaxWidth or a weighted child.
            //
            // This banner was stretching to nearly the full screen width
            // despite nothing in it calling fillMaxWidth -- the cause was
            // Modifier.weight(1f) on the text Column. weight() distributes a
            // Row's *incoming* width constraint among its children, and that
            // constraint traces back to the screen-filling Box several
            // parents up regardless of whether anything in between asked for
            // full width. A weighted child inside an otherwise wrap-content
            // Row still expands to fill the ancestor's bounds. Removing the
            // weight and giving the text a sane width ceiling instead is what
            // makes this a compact, centred pill rather than a banner.
            //
            // One line of text, not two.
            //
            // The two-line version (name, then "name mode active" under it)
            // put this pill's height at icon-or-31dp-of-text plus 20dp of
            // padding — 51dp, worse than the 45dp version it replaced, which
            // was already only 1dp under DoubtSheet's 46dp safe zone and was
            // still visibly touching it in the screenshot. Stacking two lines
            // means every future tweak to font size, padding or icon size has
            // to be re-added up by hand against that 46dp ceiling, which is
            // exactly the arithmetic that went wrong twice in a row. One line
            // removes the ceiling as a live concern: modeOn(name) already
            // says "Guru mode active" by itself, so the separate name line
            // above it was restating the same word rather than adding one.
            val toastTransition = rememberInfiniteTransition(label = "modeToast")
            val toastSweep by toastTransition.animateFloat(
                initialValue = -0.25f,
                targetValue = 1.25f,
                animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                    animation = androidx.compose.animation.core.tween(1700, easing = androidx.compose.animation.core.LinearEasing),
                ),
                label = "toastSweep",
            )
            val toastPulse by toastTransition.animateFloat(
                initialValue = 0.88f,
                targetValue = 1.04f,
                animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                    animation = androidx.compose.animation.core.tween(900),
                    repeatMode = androidx.compose.animation.core.RepeatMode.Reverse,
                ),
                label = "toastPulse",
            )
            HaloGlass(
                modifier = Modifier
                    .padding(top = 4.dp)
                    .scale(toastPulse)
                    .shadow(8.dp, RoundedCornerShape(20.dp), clip = false)
                    .drawBehind {
                        val x = size.width * toastSweep
                        drawCircle(
                            brush = Brush.radialGradient(
                                listOf(
                                    sticker.fill.copy(alpha = 0.34f),
                                    Color.Transparent,
                                ),
                                center = Offset(x, size.height * 0.5f),
                                radius = size.height * 1.9f,
                            ),
                            radius = size.height * 1.9f,
                            center = Offset(x, size.height * 0.5f),
                        )
                    },
                radius = 20.dp,
                tint = sticker.fill,
            ) {
                Row(
                    Modifier.padding(horizontal = 13.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    // The icon in its own filled circle, glowing again in its
                    // own small halo -- the reference's icon sits inside the
                    // same pool of light as the card around it, not just a
                    // flat coloured dot.
                    Box(
                        Modifier.size(22.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(
                            Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        listOf(
                                            sticker.fill,
                                            sticker.fill.copy(alpha = 0.75f),
                                        ),
                                    ),
                                ),
                        )
                        Icon(
                            Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(13.dp),
                        )
                    }
                    Spacer(Modifier.width(9.dp))
                    // White on dark glass, not Ink on cream -- this panel is
                    // the one dark surface in the app, and Ink text on it
                    // would be close to unreadable.
                    Text(
                        strings().doubt.modeOn(name),
                        fontSize = 13.5.sp,
                        lineHeight = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = 210.dp),
                    )
                }
            }
        }
    }
}

/**
 * The three modes, as a sheet rather than a row.
 *
 * A row of three chips — two of them carrying a "· Pro" suffix — was most of a
 * phone's width, permanently, for a control touched about once a session. Here
 * each one gets its name, a line saying what it does, and enough room to be
 * read once instead of guessed at forever.
 */
@Composable
private fun ModeSheet(
    mode: MyAiMode,
    onMode: (MyAiMode) -> Unit,
    premium: Boolean,
    onPlans: () -> Unit,
    onClose: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    FrostScrim {
        Box(
            Modifier
                .fillMaxSize()
                .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
        )
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .background(Cream)
                    .border(
                        Paper.Outline,
                        Ink,
                        RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    )
                    .clickableNoRipple(remember { MutableInteractionSource() }) { }
                    .padding(20.dp),
            ) {
                Text(
                    str.doubt.modesTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                )
                Spacer(Modifier.height(14.dp))
                MyAiMode.entries.forEach { item ->
                    val on = item == mode
                    val locked = item != MyAiMode.Study && !premium
                    val what = when (item) {
                        MyAiMode.Study -> str.doubt.modeStudyWhat
                        MyAiMode.Friend -> str.doubt.modeFriendWhat
                        MyAiMode.Guru -> str.doubt.modeGuruWhat
                    }
                    val label = when (item) {
                        MyAiMode.Study -> str.doubt.modeStudy
                        MyAiMode.Friend -> str.doubt.modeFriend
                        MyAiMode.Guru -> str.doubt.modeGuru
                    }
                    val sticker = when (item) {
                        MyAiMode.Study -> Mint
                        MyAiMode.Friend -> Lilac
                        MyAiMode.Guru -> Butter
                    }
                    val art = when (item) {
                        MyAiMode.Study -> TileArt.Journal
                        MyAiMode.Friend -> TileArt.Person
                        MyAiMode.Guru -> TileArt.Medal
                    }
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .clip(RoundedCornerShape(Paper.CardRadius))
                            .background(if (on) sticker.fill else CreamCard)
                            .drawBehind {
                                val step = 9.dp.toPx()
                                val dot = sticker.accent.copy(alpha = if (on) 0.28f else 0.12f)
                                var y = step
                                while (y < size.height) {
                                    var x = step * ((y / step).toInt() % 2) * 0.5f
                                    while (x < size.width) {
                                        drawCircle(dot, 1.35f, Offset(x, y))
                                        x += step
                                    }
                                    y += step
                                }
                            }
                            .border(
                                if (on) Paper.Outline else 1.5.dp,
                                Ink,
                                RoundedCornerShape(Paper.CardRadius),
                            )
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                if (locked) onPlans() else onMode(item)
                            }
                            .padding(14.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TileObject(
                                art = art,
                                fill = if (on) sticker.fill else InkLow,
                                size = 28.dp,
                            )
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    if (locked) "$label  ·  ${str.doubt.proTag}" else label,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Ink.copy(alpha = if (locked) 0.5f else 1f),
                                )
                                Text(
                                    what,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (on) sticker.on.copy(alpha = 0.8f) else InkMid,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
