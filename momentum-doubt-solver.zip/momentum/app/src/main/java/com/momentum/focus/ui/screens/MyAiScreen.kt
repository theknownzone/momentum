package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.size
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.Ink
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.Tune
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import com.momentum.focus.ui.components.FrostScrim
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.momentum.focus.ai.MyAiMode
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileObject
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.Cream
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.InkLow
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import kotlinx.coroutines.delay
import com.momentum.focus.ui.util.rememberHaptics
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.momentum.focus.ai.DoubtState
import com.momentum.focus.ai.StudyPulse
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.ui.components.DoubtSheet
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Tang

/** The word behind the header, same trick Plans uses. */
private const val GHOST = "MYAI"

/**
 * MyAi, drawn on paper rather than on a panel.
 *
 * The screen owns the background, the grain, the ghost word and the aura; the
 * chat is laid on top of all of it with nothing opaque of its own. That order
 * is the whole fix — the embedded sheet used to fill the screen with Cream and
 * bury both the ghost and the aura it was supposed to be sitting on.
 */
@Composable
fun MyAiScreen(
    state: DoubtState,
    clock: String?,
    mode: MyAiMode,
    onMode: (MyAiMode) -> Unit,
    pulse: StudyPulse?,
    onAsk: (String, List<String>) -> Unit,
    onRetry: () -> Unit,
    onStop: () -> Unit,
    onClose: () -> Unit,
    premium: Boolean = false,
    onPlans: () -> Unit = {},
    onMock: ((String?) -> Unit)? = null,
    name: String = "",
) {
    var modesOpen by remember { mutableStateOf(false) }
    var toastMode by remember { mutableStateOf<MyAiMode?>(null) }
    LaunchedEffect(toastMode) {
        if (toastMode == null) return@LaunchedEffect
        delay(1600)
        toastMode = null
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding(),
    ) {
        // The aura goes around the ghost, not around nothing. It used to be a
        // 100dp band across the top with an empty 16dp box inside it, which is
        // a disc of gold sitting on blank paper — and Aura's own rule is that
        // it haloes something. Nobody had ever seen it to notice, because the
        // chat panel was painting over it; now that it shows, it needs an
        // object. Premium glows harder, which is the only place on this screen
        // that says so.
        Aura(
            color = GoldNeon,
            strength = if (premium) 0.55f else 0.26f,
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart)
                .padding(horizontal = Paper.ScreenPad),
        ) {
            // Measured to the width that exists rather than guessed at, which
            // is the same solve Plans does: the word is measured at a probe
            // size, the trailing letter-space is taken off, and the result is
            // scaled to the margin. Hand-picked sizes either overrun the right
            // edge or stop short of it, differently on every screen.
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val density = LocalDensity.current
                val measurer = rememberTextMeasurer()
                // em, not sp, so the tracking grows with the letters instead of
                // tightening as the word gets bigger.
                //
                // Tighter than the 0.42 Plans uses, because Plans has a longer
                // word. Four letters stretched across a whole phone leaves gaps
                // wide enough that MYAI stops reading as a word and becomes
                // four separate marks.
                val tracking = 0.20.em
                val ghostSize = remember(maxWidth, density) {
                    val probe = 40.sp
                    val measured = measurer.measure(
                        GHOST,
                        TextStyle(
                            fontSize = probe,
                            letterSpacing = tracking,
                            fontWeight = FontWeight.Bold,
                        ),
                    ).size.width.toFloat()
                    val trailing = with(density) { probe.toPx() } * 0.20f
                    // Short of the full width. The share button sits in the top
                    // right corner, and at full width the final I landed
                    // underneath it — which is why the word read as MYA.
                    val target = with(density) { maxWidth.toPx() } * 0.86f
                    // 0.98, not 1.0. Four letters scaled to the full width is
                    // roughly an eight-fold blow-up of the probe, so a rounding
                    // error of a pixel at 40sp is eight pixels here — which is
                    // an I sliced off the end. A two percent margin costs
                    // nothing visible and cannot clip.
                    if (measured <= trailing) probe
                    else probe * (target / (measured - trailing)) * 0.98f
                }
                // The line box has to be taller than the letters, not equal to
                // them. At lineHeight == fontSize a bold cap sits right on the
                // edge of its own box and the top of every letter is shaved —
                // which is what was happening, and at this size the shaved
                // strip is thick enough to read as a broken font.
                val lift = with(density) { (ghostSize * 0.30f).toDp() }
                Text(
                    GHOST,
                    fontSize = ghostSize,
                    lineHeight = ghostSize * 1.25f,
                    letterSpacing = tracking,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                    color = Tang.accent.copy(alpha = 0.13f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .fillMaxWidth()
                        // Pulled up by a share of its own size. A fixed -6dp
                        // did nothing at this scale: the taller line box drops
                        // the letters far below the top of the screen, and the
                        // amount it drops them grows with the font.
                        .offset(y = -lift),
                )
            }
        }
        // Its own header, because the tab bar is gone on this screen. Back on
        // the left where every app puts it, the mode on the right as a button
        // that opens a sheet — three chips in a row was the whole width of a
        // phone spent on a control touched once a session.
        Row(
            Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart)
                .padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .clip(CircleShape)
                    .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() }
                    .padding(8.dp),
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = strings().doubt.close,
                    tint = Ink,
                    modifier = Modifier.size(22.dp),
                )
            }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier
                    .clip(CircleShape)
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        modesOpen = true
                    }
                    .padding(8.dp),
            ) {
                Icon(
                    Icons.Filled.Tune,
                    contentDescription = strings().doubt.menu,
                    tint = Ink,
                    modifier = Modifier.size(22.dp),
                )
            }
        }

        DoubtSheet(
            state = state,
            clock = clock,
            onAsk = onAsk,
            onRetry = onRetry,
            onStop = onStop,
            onClose = onClose,
            mode = mode,
            onMode = onMode,
            pulse = pulse,
            embedded = true,
            premium = premium,
            onPlans = onPlans,
            onMock = onMock,
            name = name,
        )

        if (modesOpen) {
            ModeSheet(
                mode = mode,
                onMode = {
                    onMode(it)
                    modesOpen = false
                    toastMode = it
                },
                premium = premium,
                onPlans = { modesOpen = false; onPlans() },
                onClose = { modesOpen = false },
            )
        }
        toastMode?.let { popped ->
            val sticker = when (popped) {
                MyAiMode.Study -> Mint
                MyAiMode.Friend -> Lilac
                MyAiMode.Guru -> Butter
            }
            val name = when (popped) {
                MyAiMode.Study -> strings().doubt.modeStudy
                MyAiMode.Friend -> strings().doubt.modeFriend
                MyAiMode.Guru -> strings().doubt.modeGuru
            }
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 56.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(sticker.fill.copy(alpha = 0.88f))
                    .border(2.5.dp, Ink, RoundedCornerShape(18.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            ) {
                Text(
                    strings().doubt.modeOn(name),
                    style = MaterialTheme.typography.titleMedium,
                    color = sticker.on,
                )
            }
        }
    }
}

/**
 * The three modes, as a sheet rather than a row.
 *
 * A row of three chips — two of them carrying a "· Pro" suffix — was most of a
 * phone's width, permanently, for a control touched about once a session. Here
 * each one gets its name, a line saying what it does, and enough room to be
 * read once instead of guessed at forever.
 */
@Composable
private fun ModeSheet(
    mode: MyAiMode,
    onMode: (MyAiMode) -> Unit,
    premium: Boolean,
    onPlans: () -> Unit,
    onClose: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    FrostScrim {
        Box(
            Modifier
                .fillMaxSize()
                .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
        )
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .background(Cream)
                    .border(
                        Paper.Outline,
                        Ink,
                        RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    )
                    .clickableNoRipple(remember { MutableInteractionSource() }) { }
                    .padding(20.dp),
            ) {
                Text(
                    str.doubt.modesTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                )
                Spacer(Modifier.height(14.dp))
                MyAiMode.entries.forEach { item ->
                    val on = item == mode
                    val locked = item != MyAiMode.Study && !premium
                    val what = when (item) {
                        MyAiMode.Study -> str.doubt.modeStudyWhat
                        MyAiMode.Friend -> str.doubt.modeFriendWhat
                        MyAiMode.Guru -> str.doubt.modeGuruWhat
                    }
                    val label = when (item) {
                        MyAiMode.Study -> str.doubt.modeStudy
                        MyAiMode.Friend -> str.doubt.modeFriend
                        MyAiMode.Guru -> str.doubt.modeGuru
                    }
                    val sticker = when (item) {
                        MyAiMode.Study -> Mint
                        MyAiMode.Friend -> Lilac
                        MyAiMode.Guru -> Butter
                    }
                    val art = when (item) {
                        MyAiMode.Study -> TileArt.Journal
                        MyAiMode.Friend -> TileArt.Person
                        MyAiMode.Guru -> TileArt.Medal
                    }
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .clip(RoundedCornerShape(Paper.CardRadius))
                            .background(if (on) sticker.fill else CreamCard)
                            .drawBehind {
                                val step = 9.dp.toPx()
                                val dot = sticker.accent.copy(alpha = if (on) 0.28f else 0.12f)
                                var y = step
                                while (y < size.height) {
                                    var x = step * ((y / step).toInt() % 2) * 0.5f
                                    while (x < size.width) {
                                        drawCircle(dot, 1.35f, Offset(x, y))
                                        x += step
                                    }
                                    y += step
                                }
                            }
                            .border(
                                if (on) Paper.Outline else 1.5.dp,
                                Ink,
                                RoundedCornerShape(Paper.CardRadius),
                            )
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick()
                                if (locked) onPlans() else onMode(item)
                            }
                            .padding(14.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TileObject(
                                art = art,
                                fill = if (on) sticker.fill else InkLow,
                                size = 28.dp,
                            )
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    if (locked) "$label  ·  ${str.doubt.proTag}" else label,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Ink.copy(alpha = if (locked) 0.5f else 1f),
                                )
                                Text(
                                    what,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (on) sticker.on.copy(alpha = 0.8f) else InkMid,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
