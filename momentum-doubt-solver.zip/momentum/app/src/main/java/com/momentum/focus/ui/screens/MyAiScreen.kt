package com.momentum.focus.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.momentum.focus.ai.DoubtState
import com.momentum.focus.ai.MyAiMode
import com.momentum.focus.ai.StudyPulse
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.ui.components.DoubtSheet
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Tang

@Composable
fun MyAiScreen(
    state: DoubtState,
    clock: String?,
    mode: MyAiMode,
    onMode: (MyAiMode) -> Unit,
    pulse: StudyPulse?,
    onAsk: (String, String?) -> Unit,
    onRetry: () -> Unit,
    onStop: () -> Unit,
    onClose: () -> Unit,
    premium: Boolean = false,
    onPlans: () -> Unit = {},
) {
    Box(Modifier.fillMaxSize().statusBarsPadding()) {
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart)
                .height(84.dp)
                .padding(top = 4.dp),
        ) {
            val density = LocalDensity.current
            val measurer = rememberTextMeasurer()
            val tracking = 0.38.em
            val ghostSize = remember(maxWidth, density) {
                val probe = 44.sp
                val measured = measurer.measure(
                    "MYAI",
                    TextStyle(fontSize = probe, letterSpacing = tracking, fontWeight = FontWeight.Bold),
                ).size.width.toFloat()
                val trailing = with(density) { probe.toPx() } * 0.38f
                val target = with(density) { maxWidth.toPx() } * 0.96f
                if (measured <= trailing) probe else probe * (target / (measured - trailing))
            }
            Text(
                "MYAI",
                fontSize = ghostSize,
                lineHeight = ghostSize,
                letterSpacing = tracking,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Clip,
                color = Tang.accent.copy(alpha = 0.11f),
            )
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(100.dp)
                .align(Alignment.TopCenter),
            contentAlignment = Alignment.Center,
        ) {
            Aura(color = GoldNeon, strength = if (premium) 0.62f else 0.32f) {
                Box(Modifier.fillMaxWidth().height(16.dp))
            }
        }
        DoubtSheet(
            state = state,
            clock = clock,
            onAsk = onAsk,
            onRetry = onRetry,
            onStop = onStop,
            onClose = onClose,
            mode = mode,
            onMode = onMode,
            pulse = pulse,
            embedded = true,
            premium = premium,
            onPlans = onPlans,
        )
    }
}
