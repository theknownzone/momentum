package com.momentum.focus.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.size
import com.momentum.focus.ui.components.HaloGlass
import com.momentum.focus.ui.components.LiquidGlass
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.Ink
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import com.momentum.focus.ui.components.FrostScrim
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.momentum.focus.ai.MyAiMode
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileObject
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.Cream
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.InkLow
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import kotlinx.coroutines.delay
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.momentum.focus.ai.DoubtState
import com.momentum.focus.ai.StudyPulse
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.ui.components.DoubtSheet
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Tang

/** The word behind the header, same trick Plans uses. */
private const val GHOST = "MYAI"

/**
 * MyAi, drawn on paper rather than on a panel.
 *
 * The screen owns the background, the grain, the ghost word and the aura; the
 * chat is laid on top of all of it with nothing opaque of its own. That order
 * is the whole fix — the embedded sheet used to fill the screen with Cream and
 * bury both the ghost and the aura it was supposed to be sitting on.
 */
@Composable
fun MyAiScreen(
    state: DoubtState,
    clock: String?,
    mode: MyAiMode,
    onMode: (MyAiMode) -> Unit,
    pulse: StudyPulse?,
    onAsk: (String, List<String>, Boolean) -> Unit,
    onRetry: () -> Unit,
    onStop: () -> Unit,
    onClose: () -> Unit,
    premium: Boolean = false,
    onPlans: () -> Unit = {},
    onMock: ((String?) -> Unit)? = null,
    name: String = "",
) {
    var modesOpen by remember { mutableStateOf(false) }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding(),
    ) {
        // Lightweight MYAI watermark: large enough to read as identity,
        // faint enough that bubbles and the composer always stay on top of it.
        Text(
            GHOST,
            fontSize = 82.sp,
            letterSpacing = 0.18.em,
            fontWeight = FontWeight.Black,
            color = Tang.accent.copy(alpha = 0.075f),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 126.dp)
                .fillMaxWidth()
                .drawBehind {
                    drawRect(
                        brush = Brush.horizontalGradient(
                            listOf(Color.Transparent, Tang.accent.copy(alpha = 0.08f), Color.Transparent)
                        )
                    )
                },
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            maxLines = 1,
        )
        // Its own header, because the tab bar is gone on this screen.
        //
        // This used to be two separate transparent icon buttons floating
        // directly on the paper — back on the left, tune on the right, no
        // shared surface between them. The reference asked for one floating
        // capsule instead: back arrow, a title, a live-status dot, and a
        // trailing action, all riding the same pane of glass, the way iOS's
        // own Dynamic Island-adjacent headers do it. LiquidGlass is the
        // already-built, already-pressed-and-tested material for that — the
        // same component the send button and the tab bar use — so this pill
        // is not a new visual language on top of the app, it is the existing
        // one applied to a header that had never used it.
        LiquidGlass(
            modifier = Modifier
                .align(Alignment.TopCenter)
                // Explicit width, not left to the Row inside to decide it.
                //
                // That inner Row has a weight(1f) spacer between the status
                // dot and the more-button — the exact pattern that stretched
                // the mode banner to nearly the full screen earlier this
                // session. weight() fills whatever width its ancestors allow,
                // and nothing upstream of this pill was bounding that width.
                // 88% keeps it a capsule with visible margin either side, the
                // way the reference sits short of both edges rather than
                // running edge to edge.
                .fillMaxWidth(0.88f)
                .padding(top = 6.dp)
                .shadow(10.dp, RoundedCornerShape(26.dp), clip = false),
            radius = 26.dp,
            tint = Color.White,
        ) {
            Row(
                Modifier.padding(start = 6.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = strings().doubt.close,
                        tint = Ink,
                        modifier = Modifier.size(20.dp),
                    )
                }
                Spacer(Modifier.width(4.dp))
                Text(
                    "MyAI",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Ink,
                )
                Spacer(Modifier.width(6.dp))
                // The live-status dot -- green while a reply can still be
                // asked for, the same "something is here and listening"
                // signal the reference's own online dot gives next to a
                // name.
                Box(
                    Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(if (state.left > 0) Mint.fill else InkMid),
                )
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .clickableNoRipple(remember { MutableInteractionSource() }) {
                            modesOpen = true
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.MoreHoriz,
                        contentDescription = strings().doubt.menu,
                        tint = Ink,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }

        DoubtSheet(
            state = state,
            clock = clock,
            onAsk = onAsk,
            onRetry = onRetry,
            onStop = onStop,
            onClose = onClose,
            mode = mode,
            onMode = onMode,
            pulse = pulse,
            embedded = true,
            premium = premium,
            onPlans = onPlans,
            onMock = onMock,
            name = name,
        )

        if (modesOpen) {
            ModeSheet(
                mode = mode,
                onMode = {
                    onMode(it)
                    modesOpen = false
                    // Switching mode changes who is answering, which is a state
                    // change and not a tap — so it gets its own cue rather than
                    // the generic chip tick.
                    Sfx.play(Sound.POP)
                },
                premium = premium,
                onPlans = { modesOpen = false; onPlans() },
                onClose = { modesOpen = false },
            )
        }
    }
}

/**
 * The three modes, as a sheet rather than a row.
 *
 * A row of three chips — two of them carrying a "· Pro" suffix — was most of a
 * phone's width, permanently, for a control touched about once a session. Here
 * each one gets its name, a line saying what it does, and enough room to be
 * read once instead of guessed at forever.
 */
@Composable
private fun ModeSheet(
    mode: MyAiMode,
    onMode: (MyAiMode) -> Unit,
    premium: Boolean,
    onPlans: () -> Unit,
    onClose: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    FrostScrim {
        Box(
            Modifier
                .fillMaxSize()
                .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
        )
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .background(Cream)
                    .border(
                        Paper.Outline,
                        Ink,
                        RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    )
                    .clickableNoRipple(remember { MutableInteractionSource() }) { }
                    .padding(20.dp),
            ) {
                Text(
                    str.doubt.modesTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                )
                Spacer(Modifier.height(14.dp))
                MyAiMode.entries.forEach { item ->
                    val on = item == mode
                    val locked = item != MyAiMode.Study && !premium
                    val what = when (item) {
                        MyAiMode.Study -> str.doubt.modeStudyWhat
                        MyAiMode.Friend -> str.doubt.modeFriendWhat
                        MyAiMode.Guru -> str.doubt.modeGuruWhat
                    }
                    val label = when (item) {
                        MyAiMode.Study -> str.doubt.modeStudy
                        MyAiMode.Friend -> str.doubt.modeFriend
                        MyAiMode.Guru -> str.doubt.modeGuru
                    }
                    val sticker = when (item) {
                        MyAiMode.Study -> Mint
                        MyAiMode.Friend -> Lilac
                        MyAiMode.Guru -> Butter
                    }
                    val art = when (item) {
                        MyAiMode.Study -> TileArt.Journal
                        MyAiMode.Friend -> TileArt.Person
                        MyAiMode.Guru -> TileArt.Medal
                    }
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .clip(RoundedCornerShape(Paper.CardRadius))
                            .background(if (on) sticker.fill else CreamCard)
                            .drawBehind {
                                val step = 9.dp.toPx()
                                val dot = sticker.accent.copy(alpha = if (on) 0.28f else 0.12f)
                                var y = step
                                while (y < size.height) {
                                    var x = step * ((y / step).toInt() % 2) * 0.5f
                                    while (x < size.width) {
                                        drawCircle(dot, 1.35f, Offset(x, y))
                                        x += step
                                    }
                                    y += step
                                }
                            }
                            .border(
                                if (on) Paper.Outline else 1.5.dp,
                                Ink,
                                RoundedCornerShape(Paper.CardRadius),
                            )
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick()
                                if (locked) onPlans() else onMode(item)
                            }
                            .padding(14.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TileObject(
                                art = art,
                                fill = if (on) sticker.fill else InkLow,
                                size = 28.dp,
                            )
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    if (locked) "$label  ·  ${str.doubt.proTag}" else label,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Ink.copy(alpha = if (locked) 0.5f else 1f),
                                )
                                Text(
                                    what,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (on) sticker.on.copy(alpha = 0.8f) else InkMid,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
