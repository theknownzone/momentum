package com.momentum.focus.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Deliberately uses system fonts so the project compiles with nothing extra to
// download. To upgrade the look later: drop Fraunces + Inter into res/font/ and
// replace the two families below. Nothing else needs to change.
private val Display = FontFamily.SansSerif
private val Body = FontFamily.SansSerif

val AppTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = Display, fontWeight = FontWeight.Bold,
        fontSize = 80.sp, lineHeight = 82.sp, letterSpacing = (-4).sp,
    ),
    displayMedium = TextStyle(
        fontFamily = Display, fontWeight = FontWeight.Bold,
        fontSize = 40.sp, lineHeight = 44.sp, letterSpacing = (-1.5).sp,
    ),
    headlineSmall = TextStyle(
        fontFamily = Display, fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = (-0.4).sp,
    ),
    titleMedium = TextStyle(
        fontFamily = Body, fontWeight = FontWeight.SemiBold,
        fontSize = 17.sp, lineHeight = 23.sp,
    ),
    bodyLarge = TextStyle(
        fontFamily = Body, fontWeight = FontWeight.Normal,
        fontSize = 16.sp, lineHeight = 23.sp,
    ),
    // The workhorse. Every row subtitle in the app is this style — "Chat aur
    // apni feed chalti rahegi", the caption under each block toggle, the body
    // of every card — and at 13sp it was small enough that the feed guard
    // screen read as a wall of grey. Bumped with lineHeight to match, because
    // raising size alone tightens the wrap and undoes the gain.
    bodyMedium = TextStyle(
        fontFamily = Body, fontWeight = FontWeight.Normal,
        fontSize = 14.5.sp, lineHeight = 20.sp,
    ),
    // Section headers — INSTAGRAM, YOUTUBE, HOW YOU'RE STUDYING — carry wide
    // tracking, and tracking at 11sp is what made them read as noise above
    // the thing they label rather than as a label.
    labelSmall = TextStyle(
        fontFamily = Body, fontWeight = FontWeight.Medium,
        fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 1.2.sp,
    ),
)
