package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.Composable
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Two soft lights drifting under a surface.
 *
 * Copied in behaviour, not in pixels, from the assistant button on a food
 * delivery app the user pointed at: a filled pill with a pink and a violet
 * blob wandering slowly inside it, the icon on top sitting perfectly still.
 * Frame-by-frame it is not a pulse and not a rotation of the whole fill — the
 * two colours orbit independently, cross, and separate again, which is why it
 * reads as light moving under water rather than as something flashing.
 *
 * Built as a Modifier rather than a wrapper composable so it can go on a nav
 * item, a card or a button without any of them changing shape. Clip before
 * this in the chain and the blobs stop at the edge.
 *
 * Deliberately not an animation of alpha. A glow that fades in and out is the
 * thing every app does to say "look here", and after the second look nobody
 * does. Movement without a blink stays interesting and never demands anything.
 *
 * @param a the warmer light
 * @param b the cooler one
 * @param periodMs one full orbit, kept slow on purpose
 * @param strength peak alpha of each blob
 */
@Composable
fun Modifier.liquidGlow(
    a: Color,
    b: Color,
    periodMs: Int = 5200,
    strength: Float = 0.85f,
): Modifier {
    val transition = rememberInfiniteTransition(label = "liquidGlow")
    // One linear pass, and the animationSpec never changes. Feeding a varying
    // duration into infiniteRepeatable restarts the animation, which snaps the
    // phase back to zero — the same mistake that made the theme weather jump
    // on every skin change.
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(periodMs, easing = LinearEasing)),
        label = "orbit",
    )
    return this.drawBehind {
        val turn = t * 2f * PI.toFloat()
        // The two lights run at different speeds, so they meet at a different
        // place on every lap instead of holding formation. At equal speeds the
        // whole thing collapses into a gradient being rotated, which looks
        // mechanical.
        val ax = size.width * (0.5f + 0.34f * cos(turn))
        val ay = size.height * (0.5f + 0.42f * sin(turn))
        val bx = size.width * (0.5f + 0.34f * cos(turn * 1.6f + PI.toFloat()))
        val by = size.height * (0.5f + 0.42f * sin(turn * 1.6f + PI.toFloat()))
        // Radius off the longest side so a wide pill and a small circle both
        // get a blob big enough to reach the edges and stay soft.
        val r = maxOf(size.width, size.height) * 0.78f
        drawBlob(a, Offset(ax, ay), r, strength, size)
        drawBlob(b, Offset(bx, by), r, strength, size)
    }
}

/**
 * One light.
 *
 * Three stops rather than two. A straight colour-to-transparent radial has a
 * visible ring where it lands, and two of those crossing turns the whole
 * surface into a target pattern; the middle stop is what keeps the falloff
 * looking like light.
 */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawBlob(
    colour: Color,
    centre: Offset,
    radius: Float,
    strength: Float,
    area: Size,
) {
    drawRect(
        brush = Brush.radialGradient(
            colorStops = arrayOf(
                0f to colour.copy(alpha = strength),
                0.45f to colour.copy(alpha = strength * 0.55f),
                1f to Color.Transparent,
            ),
            center = centre,
            radius = radius,
        ),
        size = area,
    )
}
