package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import com.momentum.focus.ui.util.DeviceProfile
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Two soft lights drifting under a surface.
 *
 * Copied in behaviour, not in pixels, from the assistant button on a food
 * delivery app the user pointed at: a filled pill with a pink and a violet
 * blob wandering slowly inside it, the icon on top sitting perfectly still.
 * Frame-by-frame it is not a pulse and not a rotation of the whole fill — the
 * two colours orbit independently, cross, and separate again, which is why it
 * reads as light moving under water rather than as something flashing.
 *
 * Built as a Modifier rather than a wrapper composable so it can go on a nav
 * item, a card or a button without any of them changing shape. Clip before
 * this in the chain and the blobs stop at the edge.
 *
 * Deliberately not an animation of alpha. A glow that fades in and out is the
 * thing every app does to say "look here", and after the second look nobody
 * does. Movement without a blink stays interesting and never demands anything.
 *
 * @param a the warmer light
 * @param b the cooler one
 * @param periodMs one full orbit, kept slow on purpose
 * @param strength peak alpha of each blob
 */
@Composable
fun Modifier.liquidGlow(
    a: Color,
    b: Color,
    periodMs: Int = 5200,
    strength: Float = 0.85f,
): Modifier {
    // Off entirely on a cheap phone.
    //
    // This is two full-surface radial gradients rebuilt every frame, forever,
    // on a view that is on screen the whole time the app is. It is the single
    // most expensive decoration in the app and it decorates a tab. On a 3 GB
    // Helio the right number of frames to spend on it is zero — the tab still
    // works, it just sits still like the other four.
    if (!DeviceProfile.wantsAmbientMotion(LocalContext.current)) return this

    val transition = rememberInfiniteTransition(label = "liquidGlow")
    // A clock each, not one clock and a multiplier. This is the cut.
    //
    // The second light used to be derived as cos(turn * 1.6f + PI) off the
    // first light's phase. 1.6 is not a whole number, so when t wrapped 1 -> 0
    // its argument fell from 3.2pi + pi back to pi — and the light teleported
    // across the pill, once every lap, forever. That is the break in the
    // circulation.
    //
    // It is the same mistake as the stars twinkling off a fractional multiple
    // of the drift clock, and it is in here because this component was written
    // the same way: one timeline, everything else scaled off it. Two
    // independent repeatables cannot desynchronise, because there is nothing
    // for them to be out of step with — each one only has to be continuous
    // with itself, and cos(t * 2pi) always is.
    //
    // The periods still differ, so the lights meet somewhere new on every lap
    // rather than holding formation. That was the point of the 1.6; it just
    // did not have to be paid for with a jump.
    val ta by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(periodMs, easing = LinearEasing)),
        label = "orbitA",
    )
    val tb by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween((periodMs * 1.6f).toInt(), easing = LinearEasing),
        ),
        label = "orbitB",
    )
    return this.drawBehind {
        val turnA = ta * 2f * PI.toFloat()
        val turnB = tb * 2f * PI.toFloat() + PI.toFloat()
        // Wide swing. At 0.34 the two lights barely left the middle, so on a
        // pill this small they overlapped almost all the time and averaged
        // into one flat wash — the density that could not be seen. Pushed out
        // to the edges, each colour gets a corner to itself.
        val ax = size.width * (0.5f + 0.52f * cos(turnA))
        val ay = size.height * (0.5f + 0.62f * sin(turnA))
        val bx = size.width * (0.5f + 0.52f * cos(turnB))
        val by = size.height * (0.5f + 0.62f * sin(turnB))
        // Radius off the longest side so a wide pill and a small circle both
        // get a blob big enough to reach the edges and stay soft.
        val r = maxOf(size.width, size.height) * 0.58f
        drawBlob(a, Offset(ax, ay), r, strength, size)
        drawBlob(b, Offset(bx, by), r, strength, size)
    }
}

/**
 * One light.
 *
 * Three stops rather than two. A straight colour-to-transparent radial has a
 * visible ring where it lands, and two of those crossing turns the whole
 * surface into a target pattern; the middle stop is what keeps the falloff
 * looking like light.
 */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawBlob(
    colour: Color,
    centre: Offset,
    radius: Float,
    strength: Float,
    area: Size,
) {
    drawRect(
        brush = Brush.radialGradient(
            colorStops = arrayOf(
                0f to colour.copy(alpha = strength),
                0.45f to colour.copy(alpha = strength * 0.55f),
                1f to Color.Transparent,
            ),
            center = centre,
            radius = radius,
        ),
        size = area,
    )
}
