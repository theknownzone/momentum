package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink

/** Small dimensional thermal printer. It stays vector-only, but uses planes,
 * highlights, a deep slot and a cast shadow so it reads as a real object. */
@Composable
fun PrinterMark(size: Dp = 250.dp, tint: Color = Color(0xFF4EEA9A), modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) { drawPrinter(tint) }
}

private fun DrawScope.drawPrinter(tint: Color) {
    val w=size.width; val h=size.height; val body=Size(w*.84f,h*.52f); val x=w*.08f; val y=h*.34f
    val r=CornerRadius(w*.09f,w*.09f)
    // deep cast shadow
    drawRoundRect(Color.Black.copy(alpha=.32f), Offset(x+w*.045f,y+h*.08f), body, r)
    // lower body plane with a bright front-to-dark lower falloff
    drawRoundRect(Brush.verticalGradient(listOf(
        Color.White.copy(alpha=.32f),
        tint.copy(alpha=.94f),
        tint.copy(alpha=.48f),
    )), Offset(x,y), body, r)
    // top bevel / rear plane
    val top=Path3D.topPlane(x,y,w*.84f,h*.18f)
    drawPath(top, Brush.linearGradient(listOf(Color.White.copy(alpha=.48f), tint.copy(alpha=.85f))))
    drawRoundRect(Ink.copy(alpha=.9f), Offset(x,y), body, r, style=androidx.compose.ui.graphics.drawscope.Stroke(width=w*.035f))
    // front face panel / recessed display
    val fx=x+w*.10f; val fy=y+h*.20f; val fw=w*.52f; val fh=h*.22f
    drawRoundRect(Brush.verticalGradient(listOf(Color.White.copy(alpha=.5f), Color.White.copy(alpha=.16f))), Offset(fx,fy), Size(fw,fh), CornerRadius(w*.025f,w*.025f))
    drawRoundRect(Ink.copy(alpha=.35f), Offset(fx,fy), Size(fw,fh), CornerRadius(w*.025f,w*.025f), style=androidx.compose.ui.graphics.drawscope.Stroke(width=w*.012f))
    // status LEDs + physical button
    drawCircle(Color(0xFFFF8A5C), w*.035f, Offset(x+w*.70f,y+h*.73f))
    drawCircle(Color(0xFF7FFFC0), w*.035f, Offset(x+w*.80f,y+h*.73f))
    drawRoundRect(Color.White.copy(alpha=.18f), Offset(x+w*.62f,y+h*.64f), Size(w*.16f,h*.07f), CornerRadius(w*.03f,w*.03f))
    // deep paper slot on top
    val sw=w*.50f; val sh=h*.095f; val sx=w/2f-sw/2f; val sy=y-sh*.34f
    drawRoundRect(Color(0xFF101510), Offset(sx,sy), Size(sw,sh), CornerRadius(sh*.45f,sh*.45f))
    drawRoundRect(Color.White.copy(alpha=.24f), Offset(sx+sh*.15f,sy+sh*.18f), Size(sw-sh*.3f,sh*.16f), CornerRadius(sh*.08f,sh*.08f))
    // tiny roller glint
    drawCircle(Color.White.copy(alpha=.45f), w*.018f, Offset(w/2f,sy+sh*.52f))
}

private object Path3D {
    fun topPlane(x:Float,y:Float,w:Float,h:Float):androidx.compose.ui.graphics.Path = androidx.compose.ui.graphics.Path().apply {
        moveTo(x+w*.04f,y); lineTo(x+w*.94f,y); lineTo(x+w,y+h*.72f); lineTo(x+w*.06f,y+h); close()
    }
}
