package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Sky

/**
 * A printer, drawn in the app's own comic-flat language rather than
 * borrowed from a stock 3D render.
 *
 * The reference photos handed over for this were glossy, ray-traced 3D
 * icons — a Vecteezy/Pngtree style with soft studio lighting and rounded
 * plastic. That is a different medium to everything else Momentum draws:
 * every other object in this app (CrownMark, TileObject, the Ben-Day tiles
 * on Plans) is a flat cut-paper shape with a hard Ink outline and an offset
 * shadow, no gradients trying to fake a photograph. Copying the 3D look
 * exactly would mean this one glyph looking like it was pasted in from a
 * different app; this is the same construction as CrownMark instead — a
 * body, a lit face, a hard shadow, and a slot the paper actually threads
 * through.
 */
@Composable
fun PrinterMark(size: Dp = 64.dp, tint: Color = Sky.fill, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) { drawPrinterMark(tint) }
}

private fun DrawScope.drawPrinterMark(tint: Color) {
    val w = size.width
    val h = size.height
    val line = w * 0.045f
    val shadowOffset = Offset(w * 0.045f, h * 0.06f)

    // The body: a squat rounded box, offset shadow first so the whole shape
    // reads as sitting slightly above the surface rather than flat on it —
    // the same trick CrownMark uses.
    val bodyTop = h * 0.34f
    val bodySize = Size(w * 0.86f, h * 0.58f)
    val bodyTopLeft = Offset(w * 0.07f, bodyTop)
    val corner = CornerRadius(w * 0.10f, w * 0.10f)

    drawRoundRect(
        color = Ink.copy(alpha = 0.28f),
        topLeft = bodyTopLeft + shadowOffset,
        size = bodySize,
        cornerRadius = corner,
    )
    drawRoundRect(
        brush = Brush.verticalGradient(
            listOf(tint, darken(tint, 0.18f)),
            startY = bodyTop,
            endY = bodyTop + bodySize.height,
        ),
        topLeft = bodyTopLeft,
        size = bodySize,
        cornerRadius = corner,
    )
    drawRoundRect(
        color = Ink,
        topLeft = bodyTopLeft,
        size = bodySize,
        cornerRadius = corner,
        style = androidx.compose.ui.graphics.drawscope.Stroke(width = line),
    )

    // The slot: a dark notch cut into the top of the body, with a hard rim
    // the same way a real thermal printer's paper exit has a raised lip.
    val slotSize = Size(w * 0.52f, h * 0.10f)
    val slotTopLeft = Offset(w * 0.5f - slotSize.width / 2f, bodyTop - slotSize.height * 0.35f)
    drawRoundRect(
        color = Color(0xFF16161A),
        topLeft = slotTopLeft,
        size = slotSize,
        cornerRadius = CornerRadius(slotSize.height * 0.4f, slotSize.height * 0.4f),
    )
    drawRoundRect(
        color = Ink,
        topLeft = slotTopLeft,
        size = slotSize,
        cornerRadius = CornerRadius(slotSize.height * 0.4f, slotSize.height * 0.4f),
        style = androidx.compose.ui.graphics.drawscope.Stroke(width = line * 0.8f),
    )

    // A lit face panel and two flat buttons, the only "detail" this needs to
    // read as a machine rather than a rounded box.
    val faceSize = Size(bodySize.width * 0.5f, bodySize.height * 0.32f)
    val faceTopLeft = Offset(
        bodyTopLeft.x + bodySize.width * 0.09f,
        bodyTopLeft.y + bodySize.height * 0.18f,
    )
    drawRoundRect(
        color = Color.White.copy(alpha = 0.55f),
        topLeft = faceTopLeft,
        size = faceSize,
        cornerRadius = CornerRadius(w * 0.03f, w * 0.03f),
    )
    drawRoundRect(
        color = Ink.copy(alpha = 0.7f),
        topLeft = faceTopLeft,
        size = faceSize,
        cornerRadius = CornerRadius(w * 0.03f, w * 0.03f),
        style = androidx.compose.ui.graphics.drawscope.Stroke(width = line * 0.6f),
    )
    val buttonY = bodyTopLeft.y + bodySize.height * 0.7f
    val buttonR = w * 0.035f
    listOf(
        buttonTopLeftX(bodyTopLeft.x, bodySize.width, 0.72f) to Color(0xFFFF8A5C),
        buttonTopLeftX(bodyTopLeft.x, bodySize.width, 0.84f) to Color(0xFF3FE28F),
    ).forEach { (x, colour) ->
        drawCircle(colour, radius = buttonR, center = Offset(x, buttonY))
        drawCircle(
            Ink, radius = buttonR, center = Offset(x, buttonY),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = line * 0.6f),
        )
    }
}

private fun buttonTopLeftX(bodyX: Float, bodyWidth: Float, frac: Float) = bodyX + bodyWidth * frac

private fun darken(c: Color, amount: Float): Color = Color(
    red = c.red * (1f - amount),
    green = c.green * (1f - amount),
    blue = c.blue * (1f - amount),
    alpha = c.alpha,
)
