package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkLow
import com.momentum.focus.ui.theme.Skin
import com.momentum.focus.ui.theme.Sunk

/**
 * One skin, as the thing it is named after.
 *
 * The theme list showed six rounded squares in six pastels. That is a paint
 * chart: nothing on the row says Monsoon is rain and Ember is fire except the
 * word beside it, so the list reads flat no matter how good the skins are.
 *
 * Each mark here is a small version of what that skin's hero actually draws —
 * petals, a raincloud, a flame, a moon, a coin. Someone who has seen the hero
 * recognises the row instantly, and someone who has not gets told what they
 * are unlocking before they read a word.
 *
 * Locked skins keep the shape and lose the colour, so the list still says what
 * is behind the lock rather than hiding it behind a grey box.
 */
@Composable
fun SkinMark(skin: Skin, locked: Boolean, size: Dp = 38.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val fill = if (locked) InkLow else skin.petal
        val accent = if (locked) InkLow else skin.accent
        // The tile the mark sits on, so every row lines up.
        drawRoundRect(
            color = if (locked) Sunk else lerp(fill, Color.White, 0.55f),
            cornerRadius = CornerRadius(
                10.dp.toPx(),
                10.dp.toPx(),
            ),
        )
        when (skin) {
            Skin.SAKURA -> sakuraMark(fill, accent)
            Skin.MONSOON -> monsoonMark(fill, accent)
            Skin.EMBER -> emberMark(fill, accent)
            Skin.MIDNIGHT -> midnightMark(fill, accent)
            Skin.GOLD -> goldMark(fill, accent)
            else -> festivalMark(fill, accent)
        }
        drawRoundRect(
            color = if (locked) InkLow else Ink,
            cornerRadius = CornerRadius(
                10.dp.toPx(),
                10.dp.toPx(),
            ),
            style = Stroke(width = 2.dp.toPx()),
        )
    }
}

/** Three petals falling, one turned. */
private fun DrawScope.sakuraMark(fill: Color, accent: Color) {
    val w = size.width
    val h = size.height
    listOf(
        Triple(0.30f, 0.30f, 0f),
        Triple(0.62f, 0.48f, 40f),
        Triple(0.40f, 0.70f, -25f),
    ).forEach { (fx, fy, deg) ->
        val c = Offset(w * fx, h * fy)
        rotate(degrees = deg, pivot = c) {
            drawOval(
                color = accent,
                topLeft = Offset(c.x - w * 0.13f, c.y - h * 0.06f),
                size = Size(w * 0.26f, h * 0.12f),
            )
        }
    }
}

/** A cloud with two drops under it. */
private fun DrawScope.monsoonMark(fill: Color, accent: Color) {
    val w = size.width
    val h = size.height
    listOf(0.32f to 0.44f, 0.50f to 0.56f, 0.68f to 0.44f).forEach { (fx, s) ->
        drawCircle(accent, radius = w * 0.13f * s / 0.5f, center = Offset(w * fx, h * 0.42f))
    }
    listOf(0.38f, 0.55f, 0.70f).forEachIndexed { i, fx ->
        drawLine(
            color = accent,
            start = Offset(w * fx, h * (0.58f + i % 2 * 0.04f)),
            end = Offset(w * fx - w * 0.03f, h * (0.74f + i % 2 * 0.04f)),
            strokeWidth = w * 0.05f,
            cap = StrokeCap.Round,
        )
    }
}

/** A flame over two logs. */
private fun DrawScope.emberMark(fill: Color, accent: Color) {
    val w = size.width
    val h = size.height
    drawLine(
        color = lerp(accent, Color.Black, 0.45f),
        start = Offset(w * 0.28f, h * 0.74f),
        end = Offset(w * 0.72f, h * 0.70f),
        strokeWidth = w * 0.08f,
        cap = StrokeCap.Round,
    )
    drawPath(
        Path().apply {
            moveTo(w * 0.50f, h * 0.68f)
            cubicTo(w * 0.30f, h * 0.58f, w * 0.38f, h * 0.30f, w * 0.50f, h * 0.24f)
            cubicTo(w * 0.62f, h * 0.30f, w * 0.70f, h * 0.58f, w * 0.50f, h * 0.68f)
            close()
        },
        accent,
    )
}

/** A crescent and two stars. */
private fun DrawScope.midnightMark(fill: Color, accent: Color) {
    val w = size.width
    val h = size.height
    val c = Offset(w * 0.44f, h * 0.46f)
    drawCircle(accent, radius = w * 0.20f, center = c)
    // The bite, in the tile's own colour, which is what makes it a crescent.
    drawCircle(
        color = lerp(fill, Color.White, 0.55f),
        radius = w * 0.17f,
        center = Offset(c.x + w * 0.10f, c.y - h * 0.06f),
    )
    listOf(0.74f to 0.30f, 0.68f to 0.68f).forEach { (fx, fy) ->
        val p = Offset(w * fx, h * fy)
        val arm = w * 0.07f
        drawLine(accent, Offset(p.x - arm, p.y), Offset(p.x + arm, p.y), w * 0.035f)
        drawLine(accent, Offset(p.x, p.y - arm), Offset(p.x, p.y + arm), w * 0.035f)
    }
}

/** A coin on edge, with its rim. */
private fun DrawScope.goldMark(fill: Color, accent: Color) {
    val w = size.width
    val h = size.height
    drawOval(
        color = lerp(accent, Color.Black, 0.30f),
        topLeft = Offset(w * 0.22f, h * 0.42f),
        size = Size(w * 0.56f, h * 0.30f),
    )
    drawOval(
        color = accent,
        topLeft = Offset(w * 0.22f, h * 0.32f),
        size = Size(w * 0.56f, h * 0.30f),
    )
    drawOval(
        color = lerp(accent, Color.Black, 0.35f),
        topLeft = Offset(w * 0.32f, h * 0.38f),
        size = Size(w * 0.36f, h * 0.18f),
        style = Stroke(width = w * 0.035f),
    )
}

/** Festival skins: a lamp, standing in for the artwork the hero uses. */
private fun DrawScope.festivalMark(fill: Color, accent: Color) {
    val w = size.width
    val h = size.height
    drawPath(
        Path().apply {
            moveTo(w * 0.26f, h * 0.56f)
            lineTo(w * 0.74f, h * 0.56f)
            cubicTo(w * 0.70f, h * 0.76f, w * 0.30f, h * 0.76f, w * 0.26f, h * 0.56f)
            close()
        },
        accent,
    )
    drawPath(
        Path().apply {
            moveTo(w * 0.50f, h * 0.52f)
            cubicTo(w * 0.40f, h * 0.44f, w * 0.46f, h * 0.28f, w * 0.50f, h * 0.24f)
            cubicTo(w * 0.54f, h * 0.28f, w * 0.60f, h * 0.44f, w * 0.50f, h * 0.52f)
            close()
        },
        lerp(accent, Color.White, 0.45f),
    )
}
