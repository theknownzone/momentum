package com.momentum.focus.ui.components

import com.momentum.focus.ui.util.verticalScrollWithFade

import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import com.momentum.focus.ai.Mock
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.momentum.focus.ai.Mcq
import com.momentum.focus.ai.MockState
import com.momentum.focus.data.MockResult
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.Cream
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.Sunk
import com.momentum.focus.ui.theme.InkLow
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.theme.Tang
import com.momentum.focus.ui.util.rememberHaptics

private val SheetTop = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)

/**
 * Five questions, then the reasons.
 *
 * The warning sits above the first question rather than under the score,
 * because a student who has already answered five questions has already
 * learned whatever the key told them. Reasons appear on marking, next to the
 * option they justify, so a wrong key is caught where it happened.
 */
@Composable
fun MockSheet(
    state: MockState,
    fromPage: Boolean,
    subjects: List<String>,
    awaitingPick: Boolean,
    weakest: MockResult?,
    onChoose: (Int, Int) -> Unit,
    onSubmit: () -> Unit,
    onBuild: (subject: String, topic: String) -> Unit,
    onAgain: () -> Unit,
    onClose: () -> Unit,
) {
    val questionListState = rememberLazyListState()

    val str = strings()
    val haptics = rememberHaptics()
    // What the drill is on. Empty until it is asked for.
    var pickedSubject by remember { mutableStateOf(subjects.firstOrNull().orEmpty()) }
    var topic by remember { mutableStateOf("") }
    // True only before the first build of a syllabus drill. Once questions
    // exist, or one is being built, the picker is done.
    val picking = awaitingPick && !state.busy && state.items.isEmpty() && state.error == null

    // The clock. Starts when the questions land, stops the moment the paper is
    // marked, and submits by itself when it runs out — a timed drill that
    // quietly lets you sit past the limit is not timed, it is decorated.
    var left by remember(state.items) { mutableIntStateOf(Mock.SECONDS) }
    LaunchedEffect(state.items, state.marked) {
        if (state.items.isEmpty() || state.marked) return@LaunchedEffect
        while (left > 0) {
            delay(1000)
            left -= 1
        }
        onSubmit()
    }

    FrostScrim {
        Box(
            Modifier
                .fillMaxSize()
                .clickableNoRipple(remember { MutableInteractionSource() }) { onClose() },
        )
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(1f)
                    .clip(SheetTop)
                    .background(Cream)
                    .border(Paper.Outline, Ink, SheetTop)
                    .clickableNoRipple(remember { MutableInteractionSource() }) { }
                    .paperGrain()
                    .padding(horizontal = 16.dp)
                    .padding(top = 14.dp, bottom = 14.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            str.mock.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = InkMid,
                        )
                        Text(
                            str.mock.title,
                            style = MaterialTheme.typography.headlineSmall,
                            color = Ink,
                        )
                    }
                    if (state.items.isNotEmpty() && !state.marked) {
                        // Red under a minute. Before that a countdown is
                        // information; after it, it is the point.
                        val low = left <= 60
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (low) Tang.fill else Sunk)
                                .border(2.dp, Ink, RoundedCornerShape(12.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                        ) {
                            Text(
                                "${left / 60}:${(left % 60).toString().padStart(2, '0')}",
                                style = MaterialTheme.typography.titleMedium,
                                color = Ink,
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                    }
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                haptics.tick(); onClose()
                            }
                            .padding(6.dp),
                    ) {
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = str.mock.close,
                            tint = Ink,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                Text(
                    if (fromPage) str.mock.fromPage else str.mock.fromSyllabus,
                    style = MaterialTheme.typography.labelSmall,
                    color = InkMid,
                )

                Spacer(Modifier.height(10.dp))
                // Before the questions, not after the score.
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(Paper.ChipRadius))
                        .background(Tang.fill)
                        .border(Paper.Outline, Ink, RoundedCornerShape(Paper.ChipRadius))
                        .padding(12.dp),
                ) {
                    Text(
                        str.mock.warning,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Tang.on,
                    )
                }

                Spacer(Modifier.height(12.dp))

                Box(Modifier.weight(1f)) {
                    when {
                        // Same scan as the chat. Building five questions is
                        // the longest wait in the app and the one most worth
                        // giving something to watch.
                        state.busy -> ScanPulse(str.mock.building)
                        state.error != null -> Text(
                            state.error,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Tang.accent,
                        )
                        picking -> MockPicker(
                            subjects = subjects,
                            weakest = weakest,
                            picked = pickedSubject,
                            topic = topic,
                            onPick = { pickedSubject = it; haptics.tick() },
                            onTopic = { topic = it },
                            onBuild = { haptics.press(); onBuild(pickedSubject, topic) },
                        )
                        state.items.isEmpty() -> Text(
                            str.mock.empty,
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMid,
                        )
                        else -> LazyColumn(
                            state = questionListState,
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier.fillMaxSize().lazyListEdgeFade(questionListState),
                        ) {
                            itemsIndexed(state.items) { index, item ->
                                Question(
                                    index = index,
                                    total = state.items.size,
                                    item = item,
                                    chosen = state.chosen[index],
                                    marked = state.marked,
                                    onChoose = { onChoose(index, it) },
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                if (state.marked) {
                    Text(
                        str.mock.scoreLine(state.score, state.items.size),
                        style = MaterialTheme.typography.titleMedium,
                        color = Ink,
                    )
                    Spacer(Modifier.height(8.dp))
                    SquishButton(str.mock.again, Sky, Modifier.fillMaxWidth()) {
                        haptics.press(); onAgain()
                    }
                } else if (state.items.isNotEmpty()) {
                    SquishButton(
                        str.mock.submit,
                        Mint,
                        Modifier.fillMaxWidth(),
                        enabled = state.answeredAll,
                    ) {
                        // Marked on how it went, not on the fact that a button
                        // was pressed. Half right or better is the bright note.
                        if (state.score * 2 >= state.items.size) haptics.correct()
                        else haptics.wrong()
                        onSubmit()
                    }
                }
            }
        }
    }
}

@Composable
private fun Question(
    index: Int,
    total: Int,
    item: Mcq,
    chosen: Int?,
    marked: Boolean,
    onChoose: (Int) -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val shape = RoundedCornerShape(Paper.CardRadius)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(CreamCard)
            // Lights up on a question that was answered right, once marking
            // has happened. Five cards, and the eye finds the wins without
            // reading a word.
            .glowEdge(active = marked && chosen == item.answerIndex, shape = shape)
            .padding(14.dp),
    ) {
        Text(
            str.mock.question(index + 1, total),
            style = MaterialTheme.typography.labelSmall,
            color = InkMid,
        )
        Spacer(Modifier.height(4.dp))
        Text(item.question, style = MaterialTheme.typography.bodyLarge, color = Ink)
        Spacer(Modifier.height(10.dp))

        item.options.forEachIndexed { i, option ->
            val picked = chosen == i
            val right = i == item.answerIndex
            // Before marking, only the pick is coloured. After, the key is
            // green and a wrong pick is orange — both shown, so the mistake
            // stays visible next to the answer.
            val fill = when {
                marked && right -> Mint.fill
                marked && picked -> Tang.fill
                picked -> Sky.fill
                else -> Cream
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(Paper.ChipRadius))
                    .background(fill)
                    .border(
                        if (picked || (marked && right)) Paper.Outline else 1.5.dp,
                        Ink,
                        RoundedCornerShape(Paper.ChipRadius),
                    )
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        if (!marked) { haptics.tick(); onChoose(i) }
                    }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            ) {
                Text(option, style = MaterialTheme.typography.bodyMedium, color = Ink)
            }
        }

        if (marked) {
            Spacer(Modifier.height(2.dp))
            Text(str.mock.why, style = MaterialTheme.typography.labelSmall, color = InkMid)
            Spacer(Modifier.height(2.dp))
            Text(item.reason, style = MaterialTheme.typography.bodyMedium, color = Ink)
        }
    }
}

/**
 * What the drill should be on, asked before it is built.
 *
 * This screen did not exist, and its absence was the bug: the subject was
 * taken from whatever focus session happened to be running, and outside a
 * session from subjects.firstOrNull() — the first of the three boxes in
 * Settings. A student revising Maths whose first box said Biology got a
 * Biology paper every time, with nowhere to say otherwise.
 *
 * The topic box matters more than the subject chips. Nobody is ever stuck on
 * "Maths"; they are stuck on integration by parts, or on mole concept, or on
 * one theorem they have re-read four times. A drill aimed at that is worth
 * ten aimed at a subject, and it costs one line of typing.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MockPicker(
    subjects: List<String>,
    weakest: MockResult?,
    picked: String,
    topic: String,
    onPick: (String) -> Unit,
    onTopic: (String) -> Unit,
    onBuild: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().verticalScrollWithFade(rememberScrollState())) {
        // The suggestion, when there is evidence for one.
        //
        // Derived from stored results, not from a second call to the model —
        // it is instant, it is free, and "you scored 4/10 on this" is a
        // stronger reason than anything a model could invent. Absent on a
        // fresh install, which is correct: with no history the honest thing is
        // to ask rather than to guess.
        if (weakest != null) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Tang.fill.copy(alpha = 0.25f))
                    .border(2.dp, Tang.accent, RoundedCornerShape(14.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        onPick(weakest.subject)
                        onTopic(weakest.topic)
                    }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
            ) {
                Column {
                    Text(
                        "YAHAN KAMZOR HO",
                        style = MaterialTheme.typography.labelSmall,
                        color = Tang.accent,
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        weakest.topic.ifBlank { weakest.subject },
                        style = MaterialTheme.typography.titleMedium,
                        color = Ink,
                    )
                    Text(
                        "Pichhli baar ${weakest.score}/${weakest.total}. " +
                            "Tap karke isi pe test banao.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkMid,
                    )
                }
            }
        }
        if (subjects.isNotEmpty()) {
            Text(
                "KIS SUBJECT KA",
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                subjects.forEach { s ->
                    val on = s == picked
                    Box(
                        Modifier
                            .padding(bottom = 8.dp)
                            .clip(RoundedCornerShape(Paper.ChipRadius))
                            .background(if (on) Sky.fill else Sunk)
                            .border(
                                if (on) Paper.Outline else 2.dp,
                                Ink,
                                RoundedCornerShape(Paper.ChipRadius),
                            )
                            .clickableNoRipple(remember { MutableInteractionSource() }) {
                                onPick(s)
                            }
                            .padding(horizontal = 14.dp, vertical = 9.dp),
                    ) {
                        Text(
                            s,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (on) Sky.on else Ink,
                        )
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        Text(
            "KOI KHAAS TOPIC? (OPTIONAL)",
            style = MaterialTheme.typography.labelSmall,
            color = InkMid,
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = topic,
            onValueChange = onTopic,
            placeholder = {
                Text(
                    "Integration by parts, mole concept…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkLow,
                )
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Khaali chhoda to poore subject se banega.",
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
        )

        Spacer(Modifier.height(16.dp))
        SquishButton(
            "Test banao",
            Tang,
            Modifier.fillMaxWidth(),
            // Nothing to build a test from if there is no subject and no
            // topic. Better a dead button with a reason under it than ten
            // questions on nothing in particular.
            enabled = picked.isNotBlank() || topic.isNotBlank(),
        ) { onBuild() }
        if (picked.isBlank() && topic.isBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                "Settings mein subject likho, ya upar topic daalo.",
                style = MaterialTheme.typography.bodyMedium,
                color = Tang.accent,
            )
        }
    }
}
