package com.momentum.focus.ui.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import com.momentum.focus.R

/**
 * The printer running, over the unlock receipt.
 *
 * A shipped clip rather than one of Sfx's synthesised tones. Sfx builds its
 * cues from raw PCM maths, which is right for short abstract beeps -- a riser,
 * a low hit -- but a dot-matrix head dragging across paper is texture, not a
 * waveform anyone writes by hand. This is the one sound in the app that has
 * to be a recording.
 *
 * Trimmed from a 23-second source, and the trim point mattered: the first two
 * seconds of that file measure around -82dB, effectively silence, so the
 * obvious "just take the start" would have played nothing at all under the
 * animation. The sustained run begins about four seconds in, which is where
 * this clip is cut from. Mono, 22kHz, loudness-normalised, ~17KB.
 *
 * Follows SystemVoice exactly: prepared ahead of the beat so decoding never
 * lands the sound late, and gated on the physical silent switch like every
 * other sound here.
 */
object PrintSound {

    private var player: MediaPlayer? = null
    private var audioManager: AudioManager? = null

    fun init(context: Context) {
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (player != null) return
        runCatching {
            player = MediaPlayer.create(
                context.applicationContext,
                R.raw.receipt_print,
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
                0,
            )
        }
    }

    fun play() {
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val p = player ?: return
        runCatching {
            if (p.isPlaying) {
                p.pause()
                p.seekTo(0)
            }
            p.start()
        }
    }

    /** Stops mid-clip, for when the receipt is dismissed before the feed ends. */
    fun stop() {
        val p = player ?: return
        runCatching {
            if (p.isPlaying) {
                p.pause()
                p.seekTo(0)
            }
        }
    }

    fun release() {
        runCatching {
            player?.release()
        }
        player = null
        audioManager = null
    }
}
