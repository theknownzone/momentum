#!/usr/bin/env python3
"""
Builds app/src/main/res/raw/crown_score.ogg — the soundtrack of the Crown
Mode cinematic (CrownCinematic.kt). One pre-mixed 9-second stereo file
instead of runtime synthesis: it starts in sync with the visuals, costs no
CPU on cheap phones, and was checked offline for level and spectrum.

Run:  python3 tools/crown_score.py            (needs numpy, scipy, ffmpeg)
Cue times below MUST match the constants at the top of CrownCinematic.kt.

  0.00  low drone fades in, riser + reversed crash build, heartbeat speeds up
  2.60  IMPACT  sub boom · gong · crash · brass braam · choir enters
  2.95  recorded voice "Welcome to Crown Mode." (music ducks under it)
  3.35  bell arpeggio (D minor, rising)
  5.00  5.30  5.60   three status ticks (SHIELD / UNINSTALL / LOCK)
  6.00  seal ring sweep — rising tone + reversed whoosh
  6.50  LOCK clank + bright chime; choir turns D minor -> D MAJOR (resolve)
  9.00  end
"""
import os, subprocess, sys
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve, resample_poly
from scipy.io import wavfile

SR = 44100
DUR = 9.0
N = int(SR * DUR)
HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "..", "app", "src", "main", "res", "raw")
OUT_OGG = os.path.join(RAW, "crown_score.ogg")
TMP = os.path.join(HERE, "_tmp")
os.makedirs(TMP, exist_ok=True)

T_IMPACT = 2.6
T_VOICE = 2.95
T_TICKS = (5.0, 5.3, 5.6)
T_SEAL = 6.0
T_LOCK = 6.5
LEVEL_DB = 3.5   # master trim: leaves headroom for the lossy Vorbis encode

rng = np.random.default_rng(7)


def db(x):
    return 10 ** (x / 20.0)


def tt(d):
    return np.arange(int(SR * d)) / SR


def lp(x, fc, order=4):
    return sosfilt(butter(order, fc, "low", fs=SR, output="sos"), x)


def hp(x, fc, order=4):
    return sosfilt(butter(order, fc, "high", fs=SR, output="sos"), x)


def bp(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], "band", fs=SR, output="sos"), x)


def smooth(a, b, x):
    """smoothstep from a to b"""
    y = np.clip((x - a) / (b - a), 0, 1)
    return y * y * (3 - 2 * y)


def fade_edges(x, fin=0.005, fout=0.02):
    n = len(x)
    a = int(SR * fin)
    b = int(SR * fout)
    if a:
        x[:a] *= np.linspace(0, 1, a)
    if b:
        x[-b:] *= np.linspace(1, 0, b)
    return x


class Mix:
    def __init__(self):
        self.dry = np.zeros((2, N))
        self.music = np.zeros((2, N))      # ducked under the voice
        self.send = np.zeros((2, N))       # reverb send (not ducked)
        self.msend = np.zeros((2, N))      # reverb send of music (ducked)

    @staticmethod
    def _pan(x, pan):
        a = (pan + 1) * np.pi / 4
        return np.stack([x * np.cos(a), x * np.sin(a)])

    def add(self, x, at, gain_db=0.0, pan=0.0, bus="dry", send_db=None):
        st = x if x.ndim == 2 else self._pan(x, pan)
        st = st * db(gain_db)
        i = int(at * SR)
        n = min(st.shape[1], N - i)
        if n <= 0:
            return
        target = {"dry": self.dry, "music": self.music}[bus]
        target[:, i:i + n] += st[:, :n]
        if send_db is not None:
            tgt = self.msend if bus == "music" else self.send
            tgt[:, i:i + n] += st[:, :n] * db(send_db)


# ───────────────────────── reverb ─────────────────────────
def make_ir(rt60=2.4, pre=0.022):
    n = int(SR * (rt60 + 0.4))
    t = np.arange(n) / SR
    out = []
    for ch in range(2):
        r = np.random.default_rng(100 + ch)
        noise = r.standard_normal(n)
        low = lp(noise, 3500, 2) * np.exp(-t * 6.9 / rt60)
        high = hp(noise, 3500, 2) * np.exp(-t * 6.9 / (rt60 * 0.45))
        ir = low + 0.6 * high
        ir[: int(pre * SR)] = 0
        # a few early reflections
        for k, ms in enumerate((31, 47, 63, 89)):
            j = int((ms + ch * 3) / 1000 * SR)
            ir[j] += 1.6 * (0.7 ** k)
        out.append(ir)
    ir = np.stack(out)
    ir /= np.sqrt((ir ** 2).sum(axis=1, keepdims=True)) * 1.0
    return ir


def reverb(bus, ir):
    return np.stack([fftconvolve(bus[c], ir[c])[:N] for c in range(2)])


# ───────────────────────── sound sources ─────────────────────────
def sweep_noise(dur, f0, f1, q, seed):
    n = int(dur * SR)
    noise = np.random.default_rng(seed).standard_normal(n)
    out = np.zeros(n)
    B = 1024
    zi = None
    for i in range(0, n, B):
        p = i / n
        fc = f0 * (f1 / f0) ** p
        bw = fc / q
        lo = max(fc - bw / 2, 40)
        hi = min(fc + bw / 2, SR / 2 - 800)
        sos = butter(2, [lo, hi], "band", fs=SR, output="sos")
        if zi is None:
            zi = np.zeros((sos.shape[0], 2))
        y, zi = sosfilt(sos, noise[i:i + B], zi=zi)
        out[i:i + B] = y
    return out / (np.abs(out).max() + 1e-9)


def kick(dur=0.5, f_hi=110.0, f_lo=38.0, k=30.0, decay=9.0, click=True):
    t = tt(dur)
    f = f_lo + (f_hi - f_lo) * np.exp(-t * k)
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * np.exp(-t * decay)
    x = np.tanh(2.0 * x)
    if click:
        c = np.random.default_rng(3).standard_normal(len(t)) * np.exp(-t * 900)
        x += 0.25 * hp(c, 2500, 2)
    return x


def saw_voice(f0, dur, fc, detune_cents=0.0, vib=0.0, vib_hz=5.3, seed=0, hmax=80):
    """Band-limited saw by additive synthesis with a time-varying 2nd-order
    low-pass `fc` (array of Hz, one per sample)."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    ph0 = np.random.default_rng(seed).uniform(0, 2 * np.pi)
    f = f0 * 2 ** (detune_cents / 1200) * (1 + vib * np.sin(2 * np.pi * vib_hz * t + ph0))
    ph = 2 * np.pi * np.cumsum(f) / SR + ph0
    out = np.zeros(n)
    for h in range(1, hmax):
        if h * f0 > 9000:
            break
        amp = (1.0 / h) / np.sqrt(1 + (h * f0 / fc) ** 4)
        out += amp * np.sin(h * ph)
    return out


FORMANTS = ((700, 130, 1.0), (1150, 190, 0.75), (2600, 320, 0.28))


def choir_note(f0, dur, att=0.7, rel=0.9, seed=0, detune=7.0):
    """Vowel-ish 'ahh' voice: harmonic series shaped by formant peaks, two
    slightly detuned copies, slow vibrato."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    for d, s in ((-detune, 0), (detune, 1)):
        r = np.random.default_rng(seed * 10 + s)
        ph0 = r.uniform(0, 2 * np.pi)
        vib = 0.0045 * np.sin(2 * np.pi * (5.1 + 0.4 * s) * t + ph0) * smooth(0.0, 1.2, t)
        f = f0 * 2 ** (d / 1200) * (1 + vib)
        ph = 2 * np.pi * np.cumsum(f) / SR + ph0
        for h in range(1, 48):
            fh = h * f0
            if fh > 4500:
                break
            form = 0.12 + sum(g * np.exp(-0.5 * ((fh - c) / w) ** 2) for c, w, g in FORMANTS)
            out += (form / h ** 0.7) * np.sin(h * ph)
    env = smooth(0, att, t) * (1 - smooth(dur - rel, dur, t))
    return out * env


def bell(f0, dur, brightness=1.0):
    t = tt(dur)
    parts = ((1.0, 1.0, 3.2), (2.76, 0.42 * brightness, 5.0), (5.40, 0.18 * brightness, 8.0), (8.93, 0.07 * brightness, 12.0))
    x = sum(a * np.sin(2 * np.pi * f0 * m * t) * np.exp(-t * d) for m, a, d in parts)
    x *= np.minimum(t / 0.003, 1)
    return x


def metal_strike(dur=0.9):
    t = tt(dur)
    parts = ((410, 1.0, 9), (760, 0.8, 11), (1130, 0.6, 13), (1830, 0.45, 16), (2570, 0.3, 22))
    x = sum(a * np.sin(2 * np.pi * f * t) * np.exp(-t * d) for f, a, d in parts)
    c = np.random.default_rng(5).standard_normal(len(t)) * np.exp(-t * 160)
    return x + 0.8 * hp(c, 1800, 2)


def gong(dur=6.0):
    t = tt(dur)
    base = 146.8
    parts = ((1.0, 1.0, 0.55), (2.32, 0.8, 0.7), (3.0, 0.6, 0.9), (4.1, 0.5, 1.1), (5.43, 0.38, 1.4), (6.8, 0.28, 1.8), (8.4, 0.18, 2.4))
    x = np.zeros(len(t))
    for m, a, d in parts:
        # tiny beating between two close partials = the shimmer of a gong
        x += a * (np.sin(2 * np.pi * base * m * t) + 0.6 * np.sin(2 * np.pi * (base * m + 1.7) * t)) * np.exp(-t * d)
    x *= np.minimum(t / 0.01, 1)
    return x


def load_clip(name):
    wav = os.path.join(TMP, name + ".wav")
    subprocess.run(
        ["ffmpeg", "-v", "error", "-y", "-i", os.path.join(RAW, name + ".mp3"), "-ar", str(SR), "-ac", "1", wav],
        check=True,
    )
    sr, x = wavfile.read(wav)
    return x.astype(np.float64) / 32768.0


# ───────────────────────── the score ─────────────────────────
def build():
    m = Mix()
    ir = make_ir()

    # 1. Drone — D1 + A1, harmonics via saturation so small speakers hear it.
    t = tt(T_IMPACT + 0.05)
    swell = smooth(0, T_IMPACT, t) ** 2.2
    d1 = np.sin(2 * np.pi * np.cumsum(36.7 + 6.0 * smooth(0, T_IMPACT, t)) / SR)
    a1 = np.sin(2 * np.pi * np.cumsum(55.0 + 9.0 * smooth(0, T_IMPACT, t)) / SR)
    drone = np.tanh(2.6 * (d1 + 0.6 * a1)) * swell
    drone += 0.18 * np.sin(2 * np.pi * 2.3 * t) * drone  # slow tremolo
    m.add(fade_edges(drone, 0.4, 0.01), 0.0, -3.0)

    # 2. Rising noise sweep (band-pass sweeping up) + tonal riser.
    sw = sweep_noise(T_IMPACT - 0.2, 260, 9000, 1.1, 11)
    sw2 = sweep_noise(T_IMPACT - 0.2, 300, 9500, 1.1, 12)
    env = (tt(T_IMPACT - 0.2) / (T_IMPACT - 0.2)) ** 2.0
    m.add(np.stack([sw * env, sw2 * env]), 0.1, -2.0, send_db=-12)

    tr = tt(T_IMPACT - 0.1)
    p = tr / (T_IMPACT - 0.1)
    tonal = np.zeros(len(tr))
    for base in (146.8, 220.0, 293.7, 440.0, 587.3):
        for dt in (-6, 6):
            f = base * 2 ** (dt / 1200) * 2 ** (1.0 * p)
            tonal += np.sin(2 * np.pi * np.cumsum(f) / SR) * (1 / np.sqrt(base / 146.8))
    tonal *= smooth(0.0, 1.0, p) ** 2.0 * 0.20
    m.add(tonal, 0.0, -4.0, pan=0.0, send_db=-9)

    # 3. Reversed crash — highpassed noise, exponential swell, hard cut.
    rc_d = 1.35
    rc = hp(np.random.default_rng(21).standard_normal(int(rc_d * SR)), 3200, 2)
    rc *= (tt(rc_d) / rc_d) ** 4
    rc2 = hp(np.random.default_rng(22).standard_normal(int(rc_d * SR)), 3200, 2) * (tt(rc_d) / rc_d) ** 4
    m.add(np.stack([rc, rc2]), T_IMPACT - rc_d - 0.01, -9.0, send_db=-10)

    # 4. Heartbeat — accelerating, louder each time.
    beats = [0.45, 0.95, 1.38, 1.74, 2.04, 2.28, 2.44, 2.54]
    for i, bt in enumerate(beats):
        g = -6 + i * 1.3
        m.add(kick(0.45, 95 + i * 6, 40, 26, 11), bt, g)
        # the high tick in between (a watch-like pulse) gets denser too
        if i < len(beats) - 1:
            mid = (bt + beats[i + 1]) / 2
            tick = hp(np.random.default_rng(40 + i).standard_normal(int(0.03 * SR)), 4500, 2) * np.exp(-tt(0.03) * 140)
            m.add(tick, mid, -27 + i, pan=(-1) ** i * 0.3)

    # 5. Recorded whoosh peaking just before the hit.
    wh = load_clip("sfx_whoosh")
    wh_peak = 0.78
    m.add(wh, T_IMPACT - 0.05 - wh_peak, -2.0, send_db=-12)

    # 6. IMPACT.
    # 6a. Sub boom: pitch-dropping sine, saturated for audible harmonics.
    tb = tt(3.4)
    fb = 30 + 70 * np.exp(-tb * 3.8)
    boom = np.sin(2 * np.pi * np.cumsum(fb) / SR) * np.exp(-tb * 1.25)
    boom = np.tanh(2.4 * boom)
    k2 = kick(0.7, 120, 52, 20, 5.5, click=False)
    boom[: len(k2)] += 0.5 * k2
    m.add(boom, T_IMPACT, -3.0)
    # 6b. Body of the hit.
    body = bp(np.random.default_rng(31).standard_normal(int(0.9 * SR)), 90, 1100, 2) * np.exp(-tt(0.9) * 7)
    body /= np.abs(body).max() + 1e-9
    m.add(body, T_IMPACT, 2.0, send_db=-14)
    # the whack: a saturated low-mid thump a phone speaker can really voice
    m.add(kick(0.6, 320, 100, 20, 6.0), T_IMPACT, 3.0)
    # 6c. Crash.
    cr_d = 3.6
    cr = hp(np.random.default_rng(32).standard_normal(int(cr_d * SR)), 2200, 2) * np.exp(-tt(cr_d) * 1.7)
    cr2 = hp(np.random.default_rng(33).standard_normal(int(cr_d * SR)), 2200, 2) * np.exp(-tt(cr_d) * 1.7)
    m.add(np.stack([cr, cr2]), T_IMPACT, -1.0, send_db=-8)
    # 6d. Gong.
    m.add(gong(6.2), T_IMPACT, -12.0, pan=0.0, bus="music", send_db=-6)

    # 6e. Brass braam — D2 / A2 / D3, three detuned saws each, filter opens
    #     on the hit and closes slowly. This is the "trailer" voice.
    br_d = 5.0
    tbm = tt(br_d)
    fc = 380 + 3400 * np.exp(-tbm * 2.6) + 300 * np.exp(-tbm * 0.4)
    amp = np.minimum(tbm / 0.03, 1) * (0.10 + 0.90 * np.exp(-tbm * 1.5)) * (1 - smooth(br_d - 1.6, br_d, tbm))
    braam = np.zeros(len(tbm))
    for k, (f0, g) in enumerate(((73.4, 1.0), (110.0, 0.8), (146.8, 0.7))):
        for j, cents in enumerate((-9, 0, 9)):
            braam += g * saw_voice(f0, br_d, fc, cents, vib=0.002, seed=k * 3 + j, hmax=60)
    braam = np.tanh(0.55 * braam) * amp
    m.add(braam, T_IMPACT, -8.0, bus="music", send_db=-9)

    # 7. Choir pad: Dm  ->  Bb  ->  D major (resolves on the lock).
    def chord(freqs, start, dur, g, seed):
        n = int(dur * SR)
        pad = np.zeros(n)
        for i, f in enumerate(freqs):
            pad += choir_note(f, dur, att=0.8, rel=0.9, seed=seed + i)
        pad *= db(g) / len(freqs)
        m.add(pad, start, 0.0, pan=0.0, bus="music", send_db=-4)

    chord((146.8, 220.0, 293.7, 349.2, 440.0), T_IMPACT + 0.05, 2.7, -10.5, 1)   # Dm
    chord((116.5, 174.6, 233.1, 293.7, 349.2), 4.85, 1.9, -10.5, 20)             # Bb
    chord((146.8, 220.0, 293.7, 370.0, 440.0, 587.3), 6.35, 2.55, -9.0, 40)     # D major

    # 8. Bell arpeggio over the title.
    notes = (587.3, 698.5, 880.0, 1174.7, 1396.9, 1760.0)
    for i, f in enumerate(notes):
        m.add(bell(f, 2.4), 3.35 + i * 0.12, -19.0 + i * 0.4, pan=-0.5 + i * 0.2, bus="music", send_db=-3)

    # 9. The voice. Recorded line, shaped for weight and presence.
    v = load_clip("welcome_crown_mode_rex")
    v = hp(v, 85, 2)
    v = v / (np.abs(v).max() + 1e-9) * db(-3)
    deep = resample_poly(v, 100, 84)                   # ~3 semitones down, slower
    deep = lp(deep, 900, 2)
    L = max(len(v), len(deep))
    thick = np.zeros(L)
    thick[: len(v)] += v
    thick[: len(deep)] += 0.55 * deep
    thick += 0.30 * lp(np.pad(v, (0, L - len(v))), 220, 2)              # low shelf-ish warmth
    thick += 0.28 * bp(np.pad(v, (0, L - len(v))), 2000, 5500, 2)       # presence
    thick = np.tanh(1.5 * thick) / np.tanh(1.5)                         # gentle compression
    m.add(thick, T_VOICE, 4.0, send_db=-7)
    # slap echoes, ping-pong
    for k, (dly, pan) in enumerate(((0.16, -0.6), (0.31, 0.6), (0.47, -0.3))):
        m.add(lp(thick, 3500, 2), T_VOICE + dly, -15.0 - 4 * k, pan=pan, send_db=-12)

    # 10. Status ticks — one per line.
    for i, tm in enumerate(T_TICKS):
        f = 1800 * (1.0, 1.25, 1.5)[i]
        bt = tt(0.09)
        blip = np.sin(2 * np.pi * f * bt) * np.exp(-bt * 55) * np.minimum(bt / 0.002, 1)
        m.add(blip, tm, -4.0, pan=(-0.2, 0.0, 0.2)[i], send_db=-10)
        m.add(kick(0.18, 120, 70, 40, 22, click=False), tm, -5.0)
        # decode chatter: soft clicks while the text resolves
        for c in range(7):
            ct = tm + 0.04 + c * 0.05 + rng.uniform(0, 0.02)
            clk = hp(np.random.default_rng(60 + i * 10 + c).standard_normal(int(0.012 * SR)), 5000, 2) * np.exp(-tt(0.012) * 400)
            m.add(clk, ct, -31.0, pan=rng.uniform(-0.5, 0.5))

    # 11. Seal: reversed whoosh + rising tone into the clank.
    wr = wh[::-1].copy()
    wr_peak = len(wh) / SR - wh_peak
    m.add(wr, T_LOCK - wr_peak - 0.02, -4.0, send_db=-12)
    ts = tt(T_LOCK - T_SEAL)
    fs = 380 * 2 ** (2.0 * (ts / ts[-1]))
    rise = np.sin(2 * np.pi * np.cumsum(fs) / SR) * smooth(0, ts[-1], ts) ** 2
    rise += 0.5 * np.sin(2 * np.pi * np.cumsum(fs * 1.5) / SR) * smooth(0, ts[-1], ts) ** 2
    m.add(fade_edges(rise, 0.01, 0.005), T_SEAL, -14.0, send_db=-8)

    # 12. The lock itself.
    m.add(kick(0.9, 220, 60, 22, 6.0), T_LOCK, 0.0)
    m.add(metal_strike(1.0), T_LOCK, -3.0, send_db=-9)
    m.add(gong(3.2), T_LOCK, -18.0, bus="music", send_db=-8)
    pu = load_clip("sfx_pro_unlock")
    m.add(pu, T_LOCK + 0.02, -8.0, send_db=-12)
    for i, f in enumerate((1174.7, 1760.0, 2349.3)):
        m.add(bell(f, 2.0, 1.2), T_LOCK + 0.05 + i * 0.07, -19.0 - i * 1.5, pan=-0.3 + i * 0.3, bus="music", send_db=-3)

    # ── ducking: music sits ~5 dB under the voice, no pumping ──
    t_all = np.arange(N) / SR
    duck = 1.0 - 0.42 * (smooth(T_VOICE - 0.08, T_VOICE + 0.12, t_all) * (1 - smooth(T_VOICE + 1.6, T_VOICE + 2.1, t_all)))
    music = m.music * duck
    msend = m.msend * duck

    wet = reverb(m.send + msend, ir)
    mix = m.dry + music + wet * db(-2.0)

    # Vacuum: the 85 ms before the hit drops ~18 dB, so the hit lands from
    # near-silence (a trailer trick; it doubles the felt punch).
    gate = np.ones(N)
    g0, g1 = int((T_IMPACT - 0.085) * SR), int((T_IMPACT - 0.003) * SR)
    ramp = int(0.006 * SR)
    gate[g0:g1] = db(-18)
    gate[g0 - ramp:g0] = np.linspace(1, db(-18), ramp)
    gate[g1:g1 + int(0.003 * SR)] = np.linspace(db(-18), 1, int(0.003 * SR))
    mix = mix * gate

    # ── master ──
    mix = np.stack([hp(mix[c], 24, 2) for c in range(2)])
    mix *= 1.0 - smooth(DUR - 0.6, DUR, t_all)          # fade the tail
    peak = np.abs(mix).max()
    mix /= peak
    drive = 2.2
    mix = np.tanh(drive * mix) / np.tanh(drive)          # glue + loudness
    mix *= db(-LEVEL_DB)
    return mix


def encode(mix):
    wav = os.path.join(TMP, "crown_score.wav")
    pcm = (np.clip(mix.T, -1, 1) * 32767).astype(np.int16)
    wavfile.write(wav, SR, pcm)
    subprocess.run(
        ["ffmpeg", "-v", "error", "-y", "-i", wav, "-af", "alimiter=limit=0.89:level=disabled", "-c:a", "libvorbis", "-q:a", "5", OUT_OGG],
        check=True,
    )
    return wav


if __name__ == "__main__":
    mix = build()
    assert np.isfinite(mix).all(), "NaN/inf in mix"
    wav = encode(mix)
    print("wrote", OUT_OGG, os.path.getsize(OUT_OGG) // 1024, "KB; peak", 20 * np.log10(np.abs(mix).max()), "dBFS")
