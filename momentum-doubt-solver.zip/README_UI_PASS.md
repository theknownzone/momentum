# Momentum UI Pass

This pass ports the visual language from `design/momentum-ui-preview.html` into Compose and keeps existing feature flows intact.

## Changes
- Pushable/press feedback on `MomentumGlowCard` with spring scale + translation.
- Push feedback on `MomentumPixelToggle`.
- New `MomentumGradientButton` with gradient treatment, press animation and haptic feedback.
- Existing UI strips are now connected to real screen actions instead of being purely decorative:
  - Home -> Start Focus
  - Focus -> actual timer toggle
  - Plans -> purchase action
  - My AI -> mode chooser
  - Stats -> coach action
  - Settings -> sound setting
- Existing HTML reference remains at `design/momentum-ui-preview.html`.
- Existing haptic system is reused; no new vibration implementation was introduced.
