# Momentum — standing rules for whoever works on this next

These came directly from the product owner (pacman) on 2026-09-27. They apply
to every future change, by any AI or human, until pacman changes them.

1. **HTML reference = literal spec.** When a reference mockup exists, match it
   exactly — colours, gradients, spacing, radii. No silent "I'll interpret
   this differently" calls. If following it literally would visibly clash
   with something else in the app (e.g. two tiers using the same colour),
   say so and ask, rather than quietly picking a different value.
2. **Professional only, never "kiddish."** UI, icons, style, colour, sound,
   features — all of it. No cheap-looking placeholder art, no toy vector
   clip-art that doesn't match the app's own illustrated style.
3. **Whatever you touch, polish it.** Don't leave a half-finished edge next
   to a finished one.
4. **Say when something is past you.** If a task is beyond what you can
   verify or build confidently, say so plainly and suggest the person switch
   to a stronger model for that piece, rather than guessing.
5. **Don't rebuild/deliver a zip after every micro-fix.** Make the code
   changes, keep a running list of what changed, and only package + present
   the zip when the person explicitly asks for it. Mid-stream zips full of
   half-verified fixes are worse than one clean one at the end.
6. **Dopamine / brainrot energy in EVERY fix and update — no exceptions,
   including backend/technical work.** This was tested explicitly on
   2026-09-28: an import-scan (pure code verification, no UI surface) was
   first treated as exempt ("nothing visual to add energy to"), and pacman
   corrected that — flatly, "is must." Where a fix has a real UI/sound
   surface, add the actual glow/motion/sound. Where it genuinely doesn't
   (a code scan, an import fix, a data-model change), the visible surface
   is the response reporting it — make that reporting itself energetic and
   engaging rather than a flat status report. "No user-facing UI here" is
   not a reason to drop this rule; find the surface that does exist
   (the report, the summary, the delivery) and put the energy there.

   **But dopamine/brainrot is not the same as kiddish/fast/gamey — the
   two get confused easily and must not be.** Stated explicitly on
   2026-09-29, the same day as the "last update": no kids-style sounds,
   no childish emoji-driven animation, nothing that moves FAST just to
   feel busy. None of that actually builds real user trust or engagement
   — it reads as a toy, not as a serious tool. What earns trust instead:
   proper illustration quality (the mascots, the comic-paper linework),
   and animation that is *paced* — deliberate timing, real easing, motion
   that respects the moment (a purchase-confirm settles, it doesn't
   spazz) — the same restraint already documented for Sfx.kt's sound
   design (glass partials over cheap beeps, PANIC not sounding like a
   reward). Energetic and well-crafted, not fast and cartoonish. When in
   doubt, favor the slower, more considered version of an effect.
7. **This file is the memory.** Keep it current. Anything that reads this
   repo's source (a different AI, a future session) should be able to open
   this file and immediately know how to work here.
8. **Ask before using a connector.** If a task needs an external
   connector/integration, name it and ask first rather than assuming access.
9. **No childish vector-art additions.** The app has one established theme
   (paper/comic, flat fills + Ink outlines, the existing mascot set) —
   anything new must sync with that, not introduce a different illustration
   style.
10. **If you can't produce a design, say so — and name a specific
    alternative AI** the person could ask instead, rather than a vague "get
    help elsewhere."

## Design direction (owner, 2026-10-03) — READ BEFORE ANY UI WORK
The comic/neo-brutalist paper look IS the brand: dotted/grid paper page,
3dp ink outlines, hard offset ink shadows, flat bold accent blocks. Never
"clean it up" into soft/white/hairline UI — that was tried once and reverted.
"Pro" here means: that same style executed sharper — consistent strokes and
shadows, press = shadow closes (button moves into it), 150-250ms motion,
punchy microcopy, no emoji-as-icons, no cheap clip-art. Sounds: v2 pluck pack
in Sfx.kt stays.

## Working-language rule
Pacman writes instructions in Hinglish. Before acting on a Hinglish
instruction, restate it as a clean, structured prompt (in the response,
before doing the work) — translating and organizing it — rather than working
directly off the mixed-language original. This has been observed to reduce
misreads.

## Known, deliberate product decisions (don't "fix" these back)
- **Pro / Pro Plus stay one-time, key-based purchases for now.** A real
  monthly/yearly subscription needs two things pacman confirmed on
  2026-09-27: (1) actual recurring-billing products on an external payment
  platform (a website — not built yet) or a Play Store billing switch
  (possible later, not decided), and (2) the app-side plumbing (license
  carrying a subscription type + expiry, expiry-checked and reverting to
  free, real differing monthly/yearly prices, the buy button routing to the
  right product). Neither side is being built yet — there is nothing to wire
  the Plans screen's Yearly/Monthly pill to. Do not add fake price changes or
  partial subscription logic before pacman actually has a platform decision
  and (if a website) real product links. When that day comes, design context
  pacman flagged to remember: plan **features** per tier, **gesture**
  interactions, **points/colours** per tier, and a **level** definition —
  all of this needs deciding as part of that feature, not improvised then.
  Until then the Yearly/Monthly pill is cosmetic only (see below).
- **The Yearly/Monthly pill on Plans is cosmetic only** — added to match a
  reference screenshot, confirmed by pacman ("1"). It changes no price.
  Revisit once the subscription decision above is actually made.
- **Floating Shield pill only shows when something is actually blocked.**
  `if (data.blockedPackages.isNotEmpty())` guards it in HomeScreen.kt — do not
  remove this guard or show the pill (or a "0" count) when nothing is
  blocked. Confirmed already correct on 2026-09-27; kept here since pacman
  flagged it as important to not regress.
- **Crown Mode locking an app during an active focus session is intended
  behaviour**, not a bug — it's the commitment device the feature exists to
  provide.
- **Shield popup redesign is on hold** pending a new reference HTML from
  pacman specifically for it. Don't re-redesign it speculatively in the
  meantime; fix concrete bugs in the current version only.

## Log of major fixes (most recent first)
Kept short — see git history / chat for full detail once this repo has one.
- 2026-10-03 (Uiverse pass, owner override): pacman relaxed rule 2/9 for this
  pass — cute/kiddish is allowed ("koi rules nahi hai filhal"). Uiverse
  components are used as IDEAS, redrawn in the ink/paper style, never pasted.
  NOT compiled in sandbox (no Gradle) — first CI build is the check.
  - Smooth: tab enter-slide 220ms (MainActivity, enter-only, draw-phase);
    hero RealSkinWeather pauses when scrolled off-screen (`running` param);
    Focus chips press = shadow closes.
  - Focus: BankBar (hatched earn-secured bar), FocusBuddy (ink face on the
    ring: idle/focused/sad/secured, blink + sparkles), star burst on real
    session start (0->1 phase only), DurationWheel replaces custom Slider.
  - BlockList: LockToggle is now a coin toggle (rolling coin, frown->grin).
  - Plans: key dialog button charges with ink hatch, shows "Unlocked!",
    closes after 450ms.
  - ThinkingDots: letter wave; animation moved into graphicsLayer (old
    .alpha(fade) recomposed every frame).
  - Journal: folder of the last 4 entries that fan out on tap (read-only).
  - Tour: pulsing hint pin with a self-drawing leader line (decorative).
  - Home: Back-to-Top ink coin (derivedStateOf, shows past 1400px);
    stat tiles spotlight on long-press; carousel CTA paint blobs on press.
  - SquishButton: one-shot sheen per tap (app-wide). ComicButton added in
    Paper.kt, used on Celebration CTA (onClick delayed ~260ms for burst).
  - Focus: give-up dialog is a brutalist alert card ("Keep going" now on
    top); duration chips get a sliding glider bar.
  - MyAI composer: gold comet laps the edge once on focus (PathMeasure).
  - Settings class-days: tick-stamp animation. Achievements: rainbow ring on
    unlocked badges. Profile: "PRO · AURA MAXXED/LOCKED" starry pill.
  - Coach card: orbit dot laps the edge only while busy.
  - Wallet: if balance grew since last view, ray replays + "aura +₹X" chip.
  - Gen-Z "aura" tone requested by pacman for this pass.
  - Screenshot pass (2026-10-03): Plans "THE MATHS" card has drifting dye
    blobs + sheen; Shield popup rows: icons no longer veiled at 55% ink
    (lock is a corner badge), "OFF" pill renamed ALL DAY / Nm/day (OFF read
    as shield-off); ExamNews seen-set rebuilt — ordered list, title as a
    second key, trimmed from the old end (old takeLast on an unordered
    StringSet dropped random ids → bell stuck at 9+); Profile: POW! burst
    badge only while Pro is locked, original card when unlocked; CapSlider:
    custom cap (5..180, any Int — blocker reads plain Int), "Try 30m",
    weekly-saving line from the app's real minutes, tier labels
    LOCKED IN/SAFE/RISKY/NO CAP, danger shake moved to draw phase.
  - Untouched: blocker, timer, shield, pact/crown logic.
- 2026-09-29/30 (5-item pass off pacman's marked-up screenshots; NOT yet
  compiled or run on a device — the sandbox had no Kotlin/Gradle, so the first
  CI build is the first compile. If it fails, start with these files):
  - **MyAI locked screen** (`ShutterLock.kt`): roller-housing slab now carries
    a chrome "SERVER ON HIGH LOAD" plate + slow amber LED; "LOCKED IN" is now
    sprayed on per the shutter HTML (900ms, 24 stepped strokes, drawn can,
    specks, two drips); "MyAI is being worked on" + subtitle are chrome text
    (`MetalText`: steel gradient with a hard horizon over a dark bevel).
    Substitutions vs the HTML, both deliberate: no Permanent Marker font file
    and no feTurbulence filter available -> black-italic system face + seeded
    overspray; 🥫 emoji -> drawn can (rule 9).
  - **Premium welcome** (`PremiumWelcomeScreen.kt`, full rewrite to the
    "Premium Welcome — redesign" HTML). Root cause of the blank receipt:
    `comicShadow()` paints a solid Ink rect *behind* the node but was chained
    after `.background(CreamCard)`, so it covered the cream; Plan/Holder/Amount
    values were Ink-on-Ink. Receipt is now a real zig-zag `Shape` with plate,
    ruled grid, seal; 3s rainbow ring, confetti, gold CTA, "You're Premium!".
  - **Pro Plus card** (`PlansScreen.kt`, `Marks.kt`): the 3s spinning beam is
    gone; the card wears `glowEdge` (MyAI composer's search edge, 1.6s, same
    geometry) tinted gold via the new optional `tint` param. Starfield rebuilt
    from the "Pro Plus — starfield idea" HTML: 3 layers (45/35/25 stars per
    tile), drift 45s/30s/60s (the old one crossed the card in 9s), twinkle
    layer, gold bottom glow, dark elliptical sky.
  - **Receipt PNG** (`Receipt.kt`): height was a hand-added constant ~100px
    short, so the two closing lines fell off the bottom and the licence caption
    sat inside the torn edge. Now two-pass (measure, then draw). Barcode bars
    stop at the margin; caption has room and uses the pretty key.
  - **UNLOCK sound** (`Sfx.kt`): was riser() + 1175Hz ding = the textbook
    retro "level up". Now a lock opening: two tumbler ticks, one low latch
    clunk, one settled 740Hz glass note after a rest (~0.8s, nothing rises).
    Also plays on a correct MyAI shutter key (MainActivity). Still untouched
    and still arcade-shaped if it ever gets reported: RISER + SHIMMER in
    `AiZomatoReveal.kt`.
  - **Welcome receipt values**: deliberately "Lifetime / ₹499", matching the
    saved PNG and the README pricing decision. The HTML's "Pro Plus · Yearly /
    ₹399" can't be shown honestly — a licence carries no tier or billing
    period yet (`AppData` only has `premium: Boolean`).
  - **Home/Settings hero carousel** (`HomeScreen.kt`, `SettingsScreen.kt`):
    the wiring was already correct — every slide trigger is transient (first 3
    days / 5 min after an update / unpaid wall hit) so on an old, paid install
    it renders nothing, by spec. Added the HTML's "Trigger simulator" as a
    long-press on the Settings title (toggles all 3 slides), plus the CTA gold
    sweep and "reads photos" headline from the HTML.
- 2026-09-27: PremiumWelcomeScreen onDismiss was wired to an empty lambda —
  the X button did nothing, matching the "screen freezes, no close button"
  report. Fixed to actually close.
- 2026-09-27: Updater.openDownload failed silently if no browser handled
  ACTION_VIEW. Now uses createChooser + a Toast fallback.
- 2026-09-27: Pro / Pro Plus card gap widened (mascot and the "BEST VALUE"
  tag were overlapping by about 1dp).
- 2026-09-27: Shield popup rebuilt so every element (header, each app row,
  the streak strip, both buttons) is its own bordered+shadowed card, matching
  the reference's actual structure instead of one big outer card.
- 2026-09-27: PlansScreen restructured off HorizontalPager onto a single
  scrolling column (the pager + fixed-height container was the root cause of
  a blank-card bug and a scroll-desync bug when switching tiers).
