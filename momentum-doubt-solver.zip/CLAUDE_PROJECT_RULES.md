# Momentum — standing rules for whoever works on this next

## UI rules learnt the hard way (owner, 2026-10-05) — check EVERY overlay
1. Text over busy content must be readable: overlay cards ≥ 94% opaque AND a
   screen dim behind them. "Glass" = rim + sheen, never see-through text.
2. The main action of any sheet/dialog is PINNED outside the scroll area and
   clear of the nav bar (windowInsetsPadding(navigationBars)); inside a
   Compose Dialog set DialogProperties(decorFitsSystemWindows = false) or the
   insets read 0 and the button hides under the bar; a sheet is
   capped (~82% height) so its button is always on screen and tappable.
3. Use ui/components/FitOverlay.kt (FitDialog + rememberSafeBottom) for any
   new popup: it sits above the app tab bar and gives the real usable height.
4. Before shipping an overlay, mentally test: small phone, long content,
   gesture-nav and 3-button nav. If the close/primary button can scroll
   off or sit under a bar, it's a bug.

These came directly from the product owner (pacman) on 2026-09-27. They apply
to every future change, by any AI or human, until pacman changes them.

1. **HTML reference = literal spec.** When a reference mockup exists, match it
   exactly — colours, gradients, spacing, radii. No silent "I'll interpret
   this differently" calls. If following it literally would visibly clash
   with something else in the app (e.g. two tiers using the same colour),
   say so and ask, rather than quietly picking a different value.
2. **Professional only, never "kiddish."** UI, icons, style, colour, sound,
   features — all of it. No cheap-looking placeholder art, no toy vector
   clip-art that doesn't match the app's own illustrated style.
3. **Whatever you touch, polish it.** Don't leave a half-finished edge next
   to a finished one.
4. **Say when something is past you.** If a task is beyond what you can
   verify or build confidently, say so plainly and suggest the person switch
   to a stronger model for that piece, rather than guessing.
5. **Don't rebuild/deliver a zip after every micro-fix.** Make the code
   changes, keep a running list of what changed, and only package + present
   the zip when the person explicitly asks for it. Mid-stream zips full of
   half-verified fixes are worse than one clean one at the end.
6. **Dopamine / brainrot energy in EVERY fix and update — no exceptions,
   including backend/technical work.** This was tested explicitly on
   2026-09-28: an import-scan (pure code verification, no UI surface) was
   first treated as exempt ("nothing visual to add energy to"), and pacman
   corrected that — flatly, "is must." Where a fix has a real UI/sound
   surface, add the actual glow/motion/sound. Where it genuinely doesn't
   (a code scan, an import fix, a data-model change), the visible surface
   is the response reporting it — make that reporting itself energetic and
   engaging rather than a flat status report. "No user-facing UI here" is
   not a reason to drop this rule; find the surface that does exist
   (the report, the summary, the delivery) and put the energy there.

   **But dopamine/brainrot is not the same as kiddish/fast/gamey — the
   two get confused easily and must not be.** Stated explicitly on
   2026-09-29, the same day as the "last update": no kids-style sounds,
   no childish emoji-driven animation, nothing that moves FAST just to
   feel busy. None of that actually builds real user trust or engagement
   — it reads as a toy, not as a serious tool. What earns trust instead:
   proper illustration quality (the mascots, the comic-paper linework),
   and animation that is *paced* — deliberate timing, real easing, motion
   that respects the moment (a purchase-confirm settles, it doesn't
   spazz) — the same restraint already documented for Sfx.kt's sound
   design (glass partials over cheap beeps, PANIC not sounding like a
   reward). Energetic and well-crafted, not fast and cartoonish. When in
   doubt, favor the slower, more considered version of an effect.
7. **This file is the memory.** Keep it current. Anything that reads this
   repo's source (a different AI, a future session) should be able to open
   this file and immediately know how to work here.
8. **Ask before using a connector.** If a task needs an external
   connector/integration, name it and ask first rather than assuming access.
9. **No childish vector-art additions.** The app has one established theme
   (paper/comic, flat fills + Ink outlines, the existing mascot set) —
   anything new must sync with that, not introduce a different illustration
   style.
10. **If you can't produce a design, say so — and name a specific
    alternative AI** the person could ask instead, rather than a vague "get
    help elsewhere."

## Design direction (owner, 2026-10-03) — READ BEFORE ANY UI WORK
The comic/neo-brutalist paper look IS the brand: dotted/grid paper page,
3dp ink outlines, hard offset ink shadows, flat bold accent blocks. Never
"clean it up" into soft/white/hairline UI — that was tried once and reverted.
"Pro" here means: that same style executed sharper — consistent strokes and
shadows, press = shadow closes (button moves into it), 150-250ms motion,
punchy microcopy, no emoji-as-icons, no cheap clip-art. Sounds: v2 pluck pack
in Sfx.kt stays.

## Working-language rule
Pacman writes instructions in Hinglish. Before acting on a Hinglish
instruction, restate it as a clean, structured prompt (in the response,
before doing the work) — translating and organizing it — rather than working
directly off the mixed-language original. This has been observed to reduce
misreads.

## Known, deliberate product decisions (don't "fix" these back)
- **Pro / Pro Plus stay one-time, key-based purchases for now.** A real
  monthly/yearly subscription needs two things pacman confirmed on
  2026-09-27: (1) actual recurring-billing products on an external payment
  platform (a website — not built yet) or a Play Store billing switch
  (possible later, not decided), and (2) the app-side plumbing (license
  carrying a subscription type + expiry, expiry-checked and reverting to
  free, real differing monthly/yearly prices, the buy button routing to the
  right product). Neither side is being built yet — there is nothing to wire
  the Plans screen's Yearly/Monthly pill to. Do not add fake price changes or
  partial subscription logic before pacman actually has a platform decision
  and (if a website) real product links. When that day comes, design context
  pacman flagged to remember: plan **features** per tier, **gesture**
  interactions, **points/colours** per tier, and a **level** definition —
  all of this needs deciding as part of that feature, not improvised then.
  Until then the Yearly/Monthly pill is cosmetic only (see below).
- **The Yearly/Monthly pill on Plans is cosmetic only** — added to match a
  reference screenshot, confirmed by pacman ("1"). It changes no price.
  Revisit once the subscription decision above is actually made.
- **Floating Shield pill only shows when something is actually blocked.**
  `if (data.blockedPackages.isNotEmpty())` guards it in HomeScreen.kt — do not
  remove this guard or show the pill (or a "0" count) when nothing is
  blocked. Confirmed already correct on 2026-09-27; kept here since pacman
  flagged it as important to not regress.
- **Crown Mode locking an app during an active focus session is intended
  behaviour**, not a bug — it's the commitment device the feature exists to
  provide.
- **Shield popup redesign is on hold** pending a new reference HTML from
  pacman specifically for it. Don't re-redesign it speculatively in the
  meantime; fix concrete bugs in the current version only.

## Log of major fixes (most recent first)
Kept short — see git history / chat for full detail once this repo has one.
- 2026-10-05 CrownCinematic v3 "THE HYPE EDIT" (owner: vault v2 boring; wants
  dopamine/brainrot, not old styles; voice back). 4 hard-cut shots on one
  clock: typewriter "bro really turned on" → white flash + CROWN MODE
  zoom-punch (RGB split) + speed lines + crown slam + AURA +1000 roll (BOOM,
  TICK roll) → halftone gold, 3 stamps PHONE SEALED / UNINSTALL LOCKED /
  EXCUSES DELETED (CRACK ×3 + shake) → LOCKED IN squeeze + sunburst +
  "no cap" (RISER→LEVEL) + TTS "Welcome to Crown Mode." (US voice, pitch
  0.82, only if Sfx.enabled) → slice-glitch out. LOW tier: no RGB split, fewer
  lines/slices, 40% shake. Crown strings entered/subtitle/skip/voiceLine used.
- 2026-10-05 (onboarding juice) — NOT compiled (CI). Quiz GuessStep: heat
  0..1 drives number colour (Mint→Butter→Tang→Candy), slider track colour and
  a reaction line ("Rookie numbers" → "full shift"); haptic+TICK only on a
  whole-step change (sound throttled 55ms), number pops on spring. Welcome:
  RupeeCounter ticks every ₹15 + SHIMMER on landing; WordReveal soft TICK per
  word (max 6). Permissions: each perm that flips ON on return → UNLOCK sound
  + unlock haptic (the all-done SUCCESS chime unchanged).
- 2026-10-05 (Crown + fit system) — NOT compiled (CI).
  FitOverlay.kt: FitDialog (full-window, above tab bar, usable height from
  status + max(nav inset, nav dimen)) + rememberSafeBottom. CrownVaultBrief
  now in FitDialog, body scrolls, hold-to-arm pinned under a gold hairline
  (owner shot: hold button was under the tab bar). CrownCinematic REBUILT
  ("The Vault Seals": scan line WHOOSH → steel door swings in RISER → lands
  BOOM + shake + shockwave + dust → 12 bolts in 6 pairs TICK×6 → crown
  emblem SHIMMER → letters drop, CRACK → iris-out; one clock for picture +
  sound + haptics; own Dialog window; tier-scaled). Plays on EVERY arm;
  CrownArmFx deleted. Pact card: all extensions in one scrolling row.
  AllSetCeremony energy layer: RISER 1.45s, BOOM with shield 2.05s, SHIMMER
  3.15s, FESTIVE + celebrate 4.8s; slam shake 10→16, 240→320ms.
- 2026-10-05 ShieldDoctor Done under nav bar, 3rd report: Dialog insets read 0
  on owner's phone even with decorFitsSystemWindows=false. Bottom padding is
  now max(navigationBars inset, android "navigation_bar_height" dimen). Use
  this pattern for any Dialog-hosted sheet.
- 2026-10-05 TEMP: owner asked to hardcode their test Chutes key as a
  fallback in app/build.gradle.kts (after env/local.properties). REMOVE that
  line once the owner revokes the key; use the CHUTES_API_KEY secret.
- 2026-10-05 ShieldDoctor Done STILL under 3-button nav (2nd report): Dialog
  insets were 0. Now DialogProperties(decorFitsSystemWindows=false) +
  windowInsetsPadding(systemBars), height cap 78%.
- 2026-10-05 (update bar) — NOT compiled (CI). Updater persists the
  DownloadManager id+version (prefs momentum_update); resume() re-attaches
  on UpdateCard start if the download is still pending/running/paused, so
  the in-app bar matches the notification after an app restart; a second tap
  re-attaches instead of enqueuing a duplicate. Glow: coloured Mint halo
  drawn BEFORE the clip (spills outside the bar) + head bloom; bar 22dp;
  % text titleMedium Black.
  MyAI key test (owner's temporary Chutes key, NOT written to any file):
  both models answer; gemma-4-31B-turbo ~28s, DeepSeek-V3.2 ~9s for a short
  Hinglish answer. Consider DeepSeek first in DEFAULT_MODEL for text.
- 2026-10-05 (2 overlay bugs) — WhatsNew card was see-through (unreadable
  over Home hero): now full-screen Ink 0.42 dim + 94–97% opaque card, tap
  outside closes. ShieldDoctor "Done" hid under the nav bar: rebuilt as solid
  Cream sheet capped 82% height, checks scroll inside, Done pinned (Mint
  SquishButton), navigationBars inset. Rules section added at top.
- 2026-10-05 (screenshot audit part 2) — NOT compiled (CI). ProfileSheet
  hugs content (heightIn max 88%) — Lifetime had half a screen empty.
  BlockList rank badge "#N" only + name ellipsis ("Instagra" was clipped).
  Plans ghost "PLANS" alpha 0.13 → 0.055. Freeze button reads "Need ₹40"
  when the wallet can't afford it.
- 2026-10-05 (owner screenshots audit) — NOT compiled (CI).
  Focus: stale "no study app pays nothing" copy rewritten (study app is
  optional now), warning colour → InkMid; QuickModes REMOVED (duplicated the
  25/50/90 glider row and cluttered the main page; file deleted); paid notch
  is now a small gold diamond (outline → solid when reached), it read as a
  stray knob. Settings: "Feed IDs · Debug" tile only in DEBUG builds. Plans:
  licence key masked (MOM-•••••-•••••-LAST) — screenshots were exposing it.
- 2026-10-05 (Focus page pass + dead-code sweep) — NOT compiled (CI).
  TimerRing: paidAt gold notch (bankBar/planned; fills gold once passed) and
  liveEarn under the clock ("Nm to paid" → "+₹N", slide-swap per change).
  Danger-hour hint above Quick modes only when this user's own UrgePredictor
  peak is now or next hour. Dead code removed: PowBadge, Heartbeat.shouldWarn,
  studyClean, ShieldActivity.COST_MINUTES, old Crown brief strings
  (briefTitle/Apps/Uninstall/Settings/Lock/Out, begin) and focus
  crownTickFirst/crownWarning/crownDecline.
- 2026-10-05 (Crown Vault + Focus polish) — NOT compiled (CI).
  ui/components/CrownVault.kt: CrownVaultBrief replaces the old salmon brief
  (black/gold vault, drawn crown glyph, roman-numeral terms, monospace lock
  dial, HOLD-TO-ARM 1.4s with quarter ticks — replaces tick+button; spring
  rise, crown draws in, one sheen). CrownArmFx after every arm (cinematic
  still first time): crown slams on spring, 2 shockwaves, spark ring
  (28/16/8 by tier), letter-spacing settles, ~1.9s. Arm logic unchanged.
  Focus: Crown chip gold (Marigold), Lock Cobalt, Light Jade; keycap floods
  to full colour on touch, wall same hue darker. CTA dock fade 22%→8% so
  text no longer slides under Begin. Study-app gate removed from
  startBlocked() and start() (matches the money fix).
- 2026-10-05 (Urge Predictor — own on-device engine) — NOT compiled (CI).
  data/UrgePredictor.kt: 7x24 slip-pressure grid from 21 days of UsageStats
  (opens of blocked/forbidden apps, 0.9/day decay, 25% neighbour spill,
  normalised to the user's own worst slot) + top app per slot; prefs-cached,
  rebuilt ≤ every 6 h from the BlockerService loop (checked every 5 min).
  Mechanisms: maybeNudge ~10 min before a peak slot (once/slot/day, Mute
  action → UrgeMuteReceiver, registered in manifest); ShieldActivity +5 s
  wait in a peak ("Your danger hour · +5s"); Stats DangerHours card (24 bars,
  peaks Tang, now caret, grows once). No connector/server needed — on-device
  is the point (privacy USP).
- 2026-10-05 (tiers + guard guide + Opal quick modes) — NOT compiled (CI).
  DeviceProfile.Tier LOW/MID/HIGH (RAM, cores, SDK, refresh rate) + JankWatch
  (first 20s, >12% frames >25ms → demote one tier; started in MainActivity).
  Ambient.kt tierLoop(min,…). Plans: 9 decorative loops HIGH-only, galaxy +
  price shimmer MID+, 2 CTA sweeps run on every tier. FeedGuard: GuardGuide
  card (off = 3 numbered steps with Open buttons incl. restricted-settings
  fix; on = what it does + "test it" opens Instagram). QuickModes on Focus
  (Sprint 25m / Deep work 90m / Touch grass 2h, drawn scenes, sets length
  only — Start stays the user's tap; no long "detox" presets because pay =
  elapsed would let a sleeping phone farm the wallet).
- 2026-10-05 (owner issue list) — NOT compiled (CI).
  1 MONEY BUG: sessionAudit paid only time inside study apps (phone-down
    book study = ₹0; no study apps picked = ₹0). Now paid = elapsed − time in
    other apps − junk; Momentum itself, screen-off, study apps count. The
    "studyClean.isNotEmpty()" gate in settleSession removed.
  3 SWIPE-KILL: BlockerService.running flag, onTaskRemoved → alarm restart
    (getForegroundService PI), ShortsGuard keep-alive (restarts service if
    Heartbeat armed, every 15s max). Heartbeat.recordIfDead at service start
    keeps the outage after restart; Home auto-opens ui/components/ShieldDoctor
    (Dialog: cause first, 5 checks OK/FIX/CHECK, steps + direct Fix buttons,
    re-reads on resume), clearOutage on Done.
  4 FEED GUARD: Insta Reels / YT Shorts selected-tab fallback (TAB_LABEL) when
    view ids change; StudyDetect auto-allows lectures in study-only YouTube
    (known edu channels or ≥2 study words in top-45% texts). Instructions
    screen NOT redone yet.
  5 Plans lag: 13 infinite loops → 4 lowEndLoop (galaxy, 2 CTA sweeps, price
    shimmer), 9 → ambient (frozen for free + cheap). PowBadge removed from
    Profile; no POW found in Plans/Settings code (ask owner for screenshot).
  UPDATE: Updater.downloadInApp via system DownloadManager with in-card
    progress → opens system Downloads to install (we still don't hold
    REQUEST_INSTALL_PACKAGES — Play Protect reason); browser = fallback.
  WHAT'S NEW: ui/components/WhatsNew.kt glass card from top once per version
    (spring drop, one sheen pass, staggered items, 9s auto-hide; paper on
    cheap phones), NewBadge for 7 days (ScoreStrip, Roast card).
- 2026-10-05 (Opal-inspired, owner liked Opal recordings) — NOT compiled.
  Ideas only, redrawn in the paper/comic brand (never Opal's dark/soft look).
  ui/components/ScoreStrip.kt: one-line Momentum Score on Home after
  BaselineReveal (same Success.of score, 4 part ticks, weakest Tang, counts
  up once 600ms, tap -> Profile). Full report stays on Profile (earlier
  decision). Shield WaitMeter: breathing ink ring (4s in / 4s out, "in/out",
  lowEndLoop: still "breathe" on cheap phones). Personal onboarding questions
  skipped — quiz + exam step already personalise; more questions = friction.
- 2026-10-05 (A5 Exam onboarding) — NOT compiled in sandbox (CI checks).
  Owner said "jo sahi lage bana": built Exam onboarding; SKIPPED Study Rooms
  (needs a backend, breaks "data stays on phone") — ask owner before ever
  starting it. ui/screens/ExamOnboarding.kt, new onboarding step after the
  quiz, before BlockList: pick exam (8 quick keycaps + ExamCatalog search) →
  how far (1/2/3/6 months, 1 year, exact date) → loss-framed countdown from
  the user's own average ("your phone eats N of them", half-back line).
  Skippable on every step; Back steps back. Saves via vm.setExam (subject
  pack + notices follow). Perf: onboarding ScreenTime.report moved off the
  main thread (produceState on IO, keyed on permsDone).
- 2026-10-05 (#5 paywall timing only) — NOT compiled in sandbox (CI checks).
  Exam Pass NOT built: payment is key-only and a key carries no expiry (see
  decisions above). data/ProMoments.kt decides WHEN Plans is offered:
  DEEP_SESSION after the first 50m+ banked session (set when SessionCeremony
  closes), EXAM_CLOSE once per exam at ≤ examCrownDays. Never for Pro, max one
  per day, each once (AppData proNudgeDay/proNudgeDeepDone/proNudgeExamKey,
  vm.consumeProMoment). ui/components/ProMomentSheet.kt: frost sheet, rises
  240ms + ink tag stamps 220ms, real perks only, "See Pro" -> same key Plans,
  "Later"/Back always one tap. Doubts-out wall unchanged (already opens Plans).
- 2026-10-05 (#4 Lock-in Reel V1, no camera) — NOT compiled in sandbox (owner:
  "compile GitHub ka kaam hai", don't spend usage on sandbox builds). Not run
  on a device: MediaCodec behaviour varies by chipset, test on a cheap phone.
  ui/util/LockInReel.kt: 15s 720x1280@24fps H.264, silent (users add trending
  audio in Insta; no copyright). Own MIN_PRIORITY thread, render only on tap,
  ensureActive per frame, codec always released. ByteBuffer/Image YUV input
  with our own timestamps (Canvas Surface timestamps follow wall-clock),
  I420 fallback. Frames: paper bg drawn once; header, subject card, ring +
  timer 1–8s, ₹/streak tiles 8–10.5s, SESSION SECURED stamp 10.5s, hold,
  ink watermark footer. SessionCeremony: "Make my Lock-in Reel" under Bank it,
  only for 10m+ sessions, shows "Cooking reel N%", WHOOSH + share sheet.
  file_paths.xml cache-path "." already covers the mp4.
- 2026-10-05 (#3 Surge + growing wait) — compileDebugKotlin green in sandbox.
  data/EntryPrice.kt: HAPPY HOUR ½ (10 min after a banked session, wins over
  surge), SURGE 2× (11 PM–1 AM), else ₹10; wait 7s → 10s → 15s by shield
  shows today. AppData: lastBankedAtMs (set in logSession), shieldDay,
  shieldShowsToday. ShieldActivity: counts each onCreate (singleTask), PriceRow
  (ink tag stamps in once 240ms + struck base price), one-line PriceNote,
  WaitMeter (hatched bar draining linearly, "Attempt #N" from the 2nd show).
  Access stays 10 min whatever the price. Streak 2.0 (freeze shop, ladder,
  any completed session counts) was already in the code before this pass.
- 2026-10-05 (Roast + low-end pass) — COMPILED IN SANDBOX: :app:assembleDebug
  green (first time ever). Sandbox build recipe: JDK 17 (Adoptium) with the
  system cacerts copied in (sandbox JDK 21 is JRE-only, no javac), Gradle
  8.10.2, setsid nohup background run, poll the log.
  - Screen Time Roast: ui/util/RoastCard.kt (1080x1920 Canvas poster: X DAYS a
    year, tilted aura stamp in 5 tiers, 3 stat tiles, 7-day bars, 30-year
    line, ink footer; bitmap recycled after PNG write), ui/components/
    RoastShare.kt (RoastShareButton with "Cooking…" busy guard + WHOOSH,
    RoastEntryCard on Stats after WeekChart, stamp settles once 220ms),
    ui/i18n/RoastStrings.kt (EN + gender-neutral Hinglish, wired as
    strings().roast). Quiz ProjectionStep: button rises in once (450ms delay,
    240ms). No emoji anywhere on the card. Hidden when the week has no data.
  - Low-end: Ambient.kt gains rememberCanBlur() (API31+ and not low-end),
    Modifier.blurIf(), lowEndLoop() (runs in Minimal too, still on cheap
    phones). Blur gated in Composer (radial-gradient fallback, drift now
    ambient), Locked, Frost (deeper tint fallback), UpdateCard, ScanPulse,
    MyAi reveal, BlockHub glow (dropped on low-end), BlockList spinner.
    TypedGreeting + Celebration letters: blur gated AND removed once a letter
    lands (a 0.01px RenderEffect kept every letter on its own layer forever).
    Loops -> ambient: Avatar3D, Comic burst, Achievements, AtmosphereGlow,
    Aura, BreathingGradient. -> lowEndLoop: Focus ring halo, AuraFX beam/orb.
    Welcome loops left on deliberately (first impression, cheap canvases).
    Plans loops untouched (rule above).
- 2026-10-03 (Uiverse pass, owner override): pacman relaxed rule 2/9 for this
  pass — cute/kiddish is allowed ("koi rules nahi hai filhal"). Uiverse
  components are used as IDEAS, redrawn in the ink/paper style, never pasted.
  NOT compiled in sandbox (no Gradle) — first CI build is the check.
  - Smooth: tab enter-slide 220ms (MainActivity, enter-only, draw-phase);
    hero RealSkinWeather pauses when scrolled off-screen (`running` param);
    Focus chips press = shadow closes.
  - Focus: BankBar (hatched earn-secured bar), FocusBuddy (ink face on the
    ring: idle/focused/sad/secured, blink + sparkles), star burst on real
    session start (0->1 phase only), DurationWheel replaces custom Slider.
  - BlockList: LockToggle is now a coin toggle (rolling coin, frown->grin).
  - Plans: key dialog button charges with ink hatch, shows "Unlocked!",
    closes after 450ms.
  - ThinkingDots: letter wave; animation moved into graphicsLayer (old
    .alpha(fade) recomposed every frame).
  - Journal: folder of the last 4 entries that fan out on tap (read-only).
  - Tour: pulsing hint pin with a self-drawing leader line (decorative).
  - Home: Back-to-Top ink coin (derivedStateOf, shows past 1400px);
    stat tiles spotlight on long-press; carousel CTA paint blobs on press.
  - SquishButton: one-shot sheen per tap (app-wide). ComicButton added in
    Paper.kt, used on Celebration CTA (onClick delayed ~260ms for burst).
  - Focus: give-up dialog is a brutalist alert card ("Keep going" now on
    top); duration chips get a sliding glider bar.
  - MyAI composer: gold comet laps the edge once on focus (PathMeasure).
  - Settings class-days: tick-stamp animation. Achievements: rainbow ring on
    unlocked badges. Profile: "PRO · AURA MAXXED/LOCKED" starry pill.
  - Coach card: orbit dot laps the edge only while busy.
  - Wallet: if balance grew since last view, ray replays + "aura +₹X" chip.
  - Gen-Z "aura" tone requested by pacman for this pass.
  - Screenshot pass (2026-10-03): Plans "THE MATHS" card has drifting dye
    blobs + sheen; Shield popup rows: icons no longer veiled at 55% ink
    (lock is a corner badge), "OFF" pill renamed ALL DAY / Nm/day (OFF read
    as shield-off); ExamNews seen-set rebuilt — ordered list, title as a
    second key, trimmed from the old end (old takeLast on an unordered
    StringSet dropped random ids → bell stuck at 9+); Profile: POW! burst
    badge only while Pro is locked, original card when unlocked; CapSlider:
    custom cap (5..180, any Int — blocker reads plain Int), "Try 30m",
    weekly-saving line from the app's real minutes, tier labels
    LOCKED IN/SAFE/RISKY/NO CAP, danger shake moved to draw phase.
  - BlockList: only BackPill is fixed; title/lock note/count scroll away
    inside the LazyColumn (header item), a "SHIELD · N selected" pill fades
    in once it is gone. Cap labels are positive now (owner: a cap is always
    a win): BEAST MODE ≤15, LOCKED IN ≤30, AURA FARMING ≤60, W START >60,
    SET A CAP at ∞ (lilac, no shake/vignette/sparks/error sound).
  - BlockList: sticky search bar (stickyHeader, ExperimentalFoundationApi
    opt-in), "#1-3 TIME SINK" tags on the heaviest apps (list already
    sorted by weekly minutes). Fixed Lock icon import (CI error).
  - BlockHub ("What's blocked"): photo tiles + slogans replaced by plain
    rows — icon, what it does in one line, live status pill (ON/OFF/FIX).
    Shorts & Reels row shows FIX when the accessibility guard is off.
  - FeedGuard banner: "Allow restricted settings" hint (Android 13+
    sideload greys out the accessibility switch — top cause of "Shorts
    block does nothing"). Guard detection logic itself unchanged.
  - REVERTED the plain-row BlockHub (owner liked the photo tiles). Kept
    the original design, fixed what was wrong inside it: art now matches
    each tile (Apps = BLOCKED-Instagram, Feeds = hand-on-button/struck
    signs, Modes = shield, Schedule = alarm clock); Block modes tagline was
    a privacy slogan → "ONE TAP. FULL SHIELD."; Feeds tile says "Off · turn
    on Accessibility" when the guard is off; Schedule tile opened PROFILE
    (no class hours there) → now opens Settings and Back returns to the hub
    (settingsFromHub flag in MainActivity).
  - Permissions: step-guide dialog before each system jump (usage,
    overlay, battery, accessibility): drawn mock switch that flips with a
    tap ring, numbered steps, Xiaomi "Danger" popup note / restricted
    settings note. Notifications still uses the system prompt directly.
  - Regain ideas 2–5: Shield shows "Need X to study? Switch to feed-only"
    for apps with feed surfaces (moves app from blockedPackages to its
    surfaces; refused while pactLive/crown; toasts if guard is off).
    Cap card shows today's minutes vs limit with a live dot (ScreenTime.
    minutesTodayFor, polled 60s). Focus chips are keycaps (pastel unchosen,
    side wall, cap travels down on press). Focus "Deep focus" pill → sheet
    with Strict (pact status), Uninstall protection (Crown via its own
    brief, Pro-gated), Shorts guard (accessibility). Block-notifications /
    block-home-screen NOT built (need new services) — ask owner first.
  - Perf pass: 12 animated .scale/.alpha/.rotate modifiers moved into
    graphicsLayer (draw phase) — Composer spinner, DoubtSheet cursor/swell,
    Glass turn, bottom bar, StickerCard squish, MyAI toast, Panic pulse,
    Journal, Tier3DCard, TypedGreeting, Celebration, Tour. CapSlider's 4
    dead infinite transitions replaced with constants.
  - Onboarding: Buddy (FocusBuddy, now internal) rides the tour in a comic
    speech bubble above the button; mood + Gen-Z line per page; grins when
    a name is typed. All-set: ink confetti on the stamp (own Animatable,
    keeps falling after END) + grinning Buddy lands with the stamp.
  - CAP BUG FIX (owner video, MovieBox 15m/day locked at 0m used):
    BlockerService blocked any pkg in `blocked`, and capped apps are in
    `blocked` too, so the cap never got a chance. Now a capped app outside a
    live session answers only to overCap; during a session the whole list
    stays shut. Popup row for capped apps says "Opens until Nm used today"
    instead of "Blocked for Xm".
  - THEME SPLIT (owner decision, 2026-10-05): FREE = MINIMAL, PRO = PLAYFUL.
    `Vibe.playful` (ui/theme/Theme.kt, snapshot state) is set in MainActivity
    from premium && AppData.playfulTheme (Pro-only Settings switch "Playful
    look", default on). Paper.Outline is now a getter (3dp playful / 2dp
    minimal); hard ink shadows multiply by Vibe.shadow (1 / 0.5) — 20 draw
    sites + Plans hardShadow + SquishButton. Minimal also drops: Home hero
    weather, SquishButton sheen, carousel CTA paint blobs, Plans maths aurora.
    Celebrations stay playful for everyone.
  - Pro upgrade moment: ui/components/ProUpgrade.kt (Popup over everything),
    plays when premium flips false→true while the app is open: plasma flood →
    bass drop + scan (look flips at 600ms under a paper veil) → flash +
    confetti at 1300ms → done 1900ms. Sound res/raw/sfx_pro_unlock.mp3
    (original, synthesized; Higgsfield audio is TTS-only, can't make SFX),
    played via PremiumSfx.playMoment (ignores UI-sound toggle, respects
    silent switch).
  - LAG PASS (owner: "app lag kar raha"): ui/components/Ambient.kt
    `ambient(...)` replaces rememberInfiniteTransition for decorative loops —
    runs only when Vibe.playful && !low-end, otherwise rests at initialValue.
    Applied to Home (7 loops: cta glow/sweep/pulse, pill breath, sun glow,
    reactor spin, new-dot), Wallet (2), Profile (beam, POW wobble). Home is a
    verticalScroll Column, so these ran 60fps the whole time Home was open,
    even scrolled off. Buddy idle blink gated the same way. Plans paywall
    loops left alone on purpose (they sell Pro to free users).
  - Known bigger lever NOT done yet: CI ships :app:assembleDebug with no R8
    (isMinifyEnabled=false). Compose without R8 is noticeably slower; needs
    keep-rules testing before turning on.
  - Untouched: blocker, timer, shield, pact/crown logic.
- 2026-09-29/30 (5-item pass off pacman's marked-up screenshots; NOT yet
  compiled or run on a device — the sandbox had no Kotlin/Gradle, so the first
  CI build is the first compile. If it fails, start with these files):
  - **MyAI locked screen** (`ShutterLock.kt`): roller-housing slab now carries
    a chrome "SERVER ON HIGH LOAD" plate + slow amber LED; "LOCKED IN" is now
    sprayed on per the shutter HTML (900ms, 24 stepped strokes, drawn can,
    specks, two drips); "MyAI is being worked on" + subtitle are chrome text
    (`MetalText`: steel gradient with a hard horizon over a dark bevel).
    Substitutions vs the HTML, both deliberate: no Permanent Marker font file
    and no feTurbulence filter available -> black-italic system face + seeded
    overspray; 🥫 emoji -> drawn can (rule 9).
  - **Premium welcome** (`PremiumWelcomeScreen.kt`, full rewrite to the
    "Premium Welcome — redesign" HTML). Root cause of the blank receipt:
    `comicShadow()` paints a solid Ink rect *behind* the node but was chained
    after `.background(CreamCard)`, so it covered the cream; Plan/Holder/Amount
    values were Ink-on-Ink. Receipt is now a real zig-zag `Shape` with plate,
    ruled grid, seal; 3s rainbow ring, confetti, gold CTA, "You're Premium!".
  - **Pro Plus card** (`PlansScreen.kt`, `Marks.kt`): the 3s spinning beam is
    gone; the card wears `glowEdge` (MyAI composer's search edge, 1.6s, same
    geometry) tinted gold via the new optional `tint` param. Starfield rebuilt
    from the "Pro Plus — starfield idea" HTML: 3 layers (45/35/25 stars per
    tile), drift 45s/30s/60s (the old one crossed the card in 9s), twinkle
    layer, gold bottom glow, dark elliptical sky.
  - **Receipt PNG** (`Receipt.kt`): height was a hand-added constant ~100px
    short, so the two closing lines fell off the bottom and the licence caption
    sat inside the torn edge. Now two-pass (measure, then draw). Barcode bars
    stop at the margin; caption has room and uses the pretty key.
  - **UNLOCK sound** (`Sfx.kt`): was riser() + 1175Hz ding = the textbook
    retro "level up". Now a lock opening: two tumbler ticks, one low latch
    clunk, one settled 740Hz glass note after a rest (~0.8s, nothing rises).
    Also plays on a correct MyAI shutter key (MainActivity). Still untouched
    and still arcade-shaped if it ever gets reported: RISER + SHIMMER in
    `AiZomatoReveal.kt`.
  - **Welcome receipt values**: deliberately "Lifetime / ₹499", matching the
    saved PNG and the README pricing decision. The HTML's "Pro Plus · Yearly /
    ₹399" can't be shown honestly — a licence carries no tier or billing
    period yet (`AppData` only has `premium: Boolean`).
  - **Home/Settings hero carousel** (`HomeScreen.kt`, `SettingsScreen.kt`):
    the wiring was already correct — every slide trigger is transient (first 3
    days / 5 min after an update / unpaid wall hit) so on an old, paid install
    it renders nothing, by spec. Added the HTML's "Trigger simulator" as a
    long-press on the Settings title (toggles all 3 slides), plus the CTA gold
    sweep and "reads photos" headline from the HTML.
- 2026-09-27: PremiumWelcomeScreen onDismiss was wired to an empty lambda —
  the X button did nothing, matching the "screen freezes, no close button"
  report. Fixed to actually close.
- 2026-09-27: Updater.openDownload failed silently if no browser handled
  ACTION_VIEW. Now uses createChooser + a Toast fallback.
- 2026-09-27: Pro / Pro Plus card gap widened (mascot and the "BEST VALUE"
  tag were overlapping by about 1dp).
- 2026-09-27: Shield popup rebuilt so every element (header, each app row,
  the streak strip, both buttons) is its own bordered+shadowed card, matching
  the reference's actual structure instead of one big outer card.
- 2026-09-27: PlansScreen restructured off HorizontalPager onto a single
  scrolling column (the pager + fixed-height container was the root cause of
  a blank-card bug and a scroll-desync bug when switching tiers).
