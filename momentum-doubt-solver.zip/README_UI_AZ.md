# Momentum A-Z UI Pass

This pass maps every supplied Uiverse/HTML concept into a Compose-native Momentum surface without replacing existing app behavior.

1. Neon animated gradient card -> Plans/Premium
2. Neo-Brutalism pricing card -> Plans/Premium
3. Layered weather card -> Home
4. Glass blob card -> My AI
5. Pixel sunny card -> Home
6. Comic card -> Stats/Achievements
7. Pixel coin toggle -> Settings/Focus controls
8. Mechanical monster toggle -> Focus Shield
9. Vertical toggle -> Focus mode/intensity
10. Cyber input -> Doubt Solver / AI
11. Animated input -> Doubt Solver / AI
12. Indigo glass tooltip -> Premium / AI info
13. Cyber scanline tooltip -> AI/system explanation
14. Branch/connection tooltip -> AI mode flow

Interaction rules:
- Pushable controls use press scale/translation.
- Interactive controls call the existing Momentum haptics helper.
- Existing screen actions are preserved; UI is layered around them rather than replacing them.
- CSS is not copied literally. Visual behavior is recreated with Jetpack Compose.
