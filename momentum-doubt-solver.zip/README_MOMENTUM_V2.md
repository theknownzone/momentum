# Momentum Focus — v2.0 Final

## What Is This
Focus & screen-time control app for Indian students (JEE/NEET/SSC). Block distracting apps, earn focus minutes, bank them like currency. Comic-book paper UI with hard ink borders and dopamine-driven interactions.

## What's New in v2.0

### Dopamine Moments Enhanced
- **SplashScreen** — 3.2s animated wordmark with spring physics + starburst + WHOOSH sound
- **CelebrationScreen** — Full ceremony: confetti + haptic pattern + overshoot animation
- **PremiumWelcomeScreen** — 4-phase unlock: POW burst → receipt print → breathing badge → features
- **FocusMachineScreen** — 3D monster + mechanical lid + shield toggle with sound
- **ScreenTimeQuiz** — Page-flip animation + speed lines + back navigation

### Comic UI Primitives (New)
| Component | Effect |
|-----------|--------|
| `Comic.kt` | Halftone dots, wobbly ink border, hard shadow, starburst, speed lines, speech bubble, POW burst, torn edge |
| `ComicControls.kt` | PowerButton (3D press), PunBumpToggle (360° rotation), DangerButton |
| `AuraFX.kt` | Scanning beam, breathing orb, premium aura, tap spark |

### Bug Fixes
- Splash no longer cuts short on low-end devices
- Safe array access on all indexed reads
- Notification IDs unique (no clash)
- Sound defaults off on first launch (user opts in)
- Exam validation (blank name can't set date)

## Tech Stack
- Kotlin 2.0.21
- Jetpack Compose (Material3 + custom)
- minSdk 26, targetSdk 35
- Procedural audio (no .wav assets)

## Build
```bash
./gradlew assembleRelease
```

## Screens (26)
Splash → Welcome → ScreenTimeQuiz → Home → Focus → Stats → Wallet → Settings → Plans → PremiumWelcome → FocusMachine → + 16 more

## Components (55)
Aura, BreathingGradient, LiquidGlass, PremiumCelebration, CrownCinematic, TileObject, SkinWeather, Avatar3D, + 48 more
