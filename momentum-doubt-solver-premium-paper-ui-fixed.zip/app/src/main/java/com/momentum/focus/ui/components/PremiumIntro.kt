package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Lilac
import com.momentum.focus.ui.theme.Sky
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Premium celebration: dotted 3D sphere, soft gradient atmosphere and restrained confetti. */
@Composable
fun PremiumIntro(onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val alpha = remember { Animatable(0f) }
    val scale = remember { Animatable(0.72f) }
    val infinite = rememberInfiniteTransition(label = "premium-orb")
    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(5200, easing = androidx.compose.animation.core.LinearEasing), RepeatMode.Restart),
        label = "rotation",
    )
    val breathe by infinite.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1400, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "breathe",
    )

    LaunchedEffect(Unit) {
        haptics.unlock()
        alpha.animateTo(1f, tween(320))
        scale.animateTo(1.08f, tween(460))
        scale.animateTo(1f, tween(420))
        delay(1050)
        haptics.sessionComplete()
        delay(650)
        alpha.animateTo(0f, tween(460))
        onDone()
    }

    Box(
        Modifier.fillMaxSize().alpha(alpha.value).background(Color(0xFF050712)),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height * 0.44f
            val r = minOf(size.width, size.height) * 0.20f * breathe
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Sky.fill.copy(alpha = 0.25f), Lilac.fill.copy(alpha = 0.12f), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = r * 3.2f,
                ),
                radius = r * 3.2f,
                center = Offset(cx, cy),
            )
            for (ring in 0..10) {
                val lat = (ring / 10f - 0.5f) * PI
                val ringR = cos(lat) * r
                val ringY = sin(lat) * r
                for (dot in 0 until 28) {
                    val a = dot / 28f * PI * 2f + rotation * PI / 180f * (0.55f + ring * 0.025f)
                    val x = cx + cos(a) * ringR
                    val y = cy + ringY * 0.82f + sin(a) * ringR * 0.14f
                    val depth = ((sin(a) + 1f) / 2f)
                    drawCircle(
                        color = Color.White.copy(alpha = 0.22f + depth * 0.60f),
                        radius = 1.0.dp.toPx() + depth * 0.7.dp.toPx(),
                        center = Offset(x, y),
                    )
                }
            }
            repeat(22) { i ->
                val a = i * 0.71f + rotation * PI / 180f * 0.08f
                val d = r * (1.9f + (i % 5) * 0.22f)
                val p = Offset(cx + cos(a) * d, cy + sin(a) * d)
                drawCircle(
                    color = listOf(GoldNeon, Sky.fill, Lilac.fill)[i % 3].copy(alpha = 0.28f),
                    radius = (i % 3 + 1).dp.toPx() * 0.55f,
                    center = p,
                )
            }
        }
        Text(
            "PREMIUM",
            fontSize = 46.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 3.sp,
            color = Color.White,
            modifier = Modifier.scale(scale.value).padding(24.dp),
        )
        Text(
            "MOMENTUM / UNLOCKED",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            color = Color.White.copy(alpha = 0.48f),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 48.dp),
        )
    }
}
