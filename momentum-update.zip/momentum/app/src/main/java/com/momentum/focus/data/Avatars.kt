package com.momentum.focus.data

/**
 * 3D-feel avatar presets — emoji with depth that read as characters,
 * not flat icons. No external assets required.
 */
data class AvatarPreset(
    val id: String,
    val emoji: String,
    val label: String,
)

object Avatars {
    val all = listOf(
        AvatarPreset("fox", "🦊", "Fox"),
        AvatarPreset("owl", "🦉", "Owl"),
        AvatarPreset("tiger", "🐯", "Tiger"),
        AvatarPreset("panda", "🐼", "Panda"),
        AvatarPreset("wolf", "🐺", "Wolf"),
        AvatarPreset("lion", "🦁", "Lion"),
        AvatarPreset("dragon", "🐲", "Dragon"),
        AvatarPreset("robot", "🤖", "Robot"),
        AvatarPreset("ninja", "🥷", "Ninja"),
        AvatarPreset("astronaut", "🧑‍🚀", "Astro"),
        AvatarPreset("mage", "🧙", "Mage"),
        AvatarPreset("samurai", "⚔️", "Blade"),
        AvatarPreset("phoenix", "🔥", "Phoenix"),
        AvatarPreset("crystal", "💎", "Crystal"),
        AvatarPreset("rocket", "🚀", "Rocket"),
        AvatarPreset("crown", "👑", "Crown"),
    )

    fun emojiFor(id: String): String =
        all.firstOrNull { it.id == id }?.emoji
            ?: all.firstOrNull { it.emoji == id }?.emoji
            ?: id.ifBlank { "🦊" }
}
