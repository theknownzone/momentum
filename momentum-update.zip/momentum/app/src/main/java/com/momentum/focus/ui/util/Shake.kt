package com.momentum.focus.ui.util

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import kotlin.math.sqrt

/**
 * Shake the phone to open panic mode.
 *
 * Gravity is subtracted first, so the trigger measures actual movement rather
 * than how the phone is being held. Two separate shakes within a second are
 * required — a single jolt happens every time the phone is set down on a table,
 * and a panic screen that opens by accident gets the feature turned off.
 */
@Composable
fun ShakeToPanic(enabled: Boolean = true, onShake: () -> Unit) {
    val context = LocalContext.current
    val onShakeState = rememberUpdatedState(onShake)

    DisposableEffect(enabled) {
        if (!enabled) return@DisposableEffect onDispose { }

        val manager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = manager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (manager == null || sensor == null) return@DisposableEffect onDispose { }

        var lastShake = 0L
        var shakeCount = 0

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val (x, y, z) = event.values
                val force = sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH

                if (force > 2.2f) {
                    val now = System.currentTimeMillis()
                    if (now - lastShake < 180) return
                    if (now - lastShake > 1200) shakeCount = 0
                    lastShake = now
                    shakeCount++
                    if (shakeCount >= 2) {
                        shakeCount = 0
                        onShakeState.value()
                    }
                }
            }

            override fun onAccuracyChanged(s: Sensor?, accuracy: Int) = Unit
        }

        manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { manager.unregisterListener(listener) }
    }
}
