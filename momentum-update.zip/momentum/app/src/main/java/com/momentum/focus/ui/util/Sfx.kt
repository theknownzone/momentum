package com.momentum.focus.ui.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class Sound {
    POP, TICK, SUCCESS, ERROR, WHOOSH,
    /** Soft rising chime for onboarding / report reveal. */
    CHIME,
    /** Warm two-note for goal hit. */
    LEVEL_UP,
    /** Soft low thud for shield / block. */
    SHIELD,
    /** Soft countdown tick for focus timer. */
    SOFT_TICK,
}

/**
 * UI sounds generated as raw PCM — no binary assets.
 * Tuned for short, pleasant, non-annoying feedback.
 */
object Sfx {

    private const val RATE = 44100
    private val tracks = mutableMapOf<Sound, AudioTrack>()
    private var audioManager: AudioManager? = null
    var enabled: Boolean = true

    fun init(context: Context) {
        if (tracks.isNotEmpty()) return
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        runCatching {
            tracks[Sound.POP] = build(
                tone(920f, 0.045f, decay = 48f, pitchDrop = 0.28f)
            )
            tracks[Sound.TICK] = build(tone(2400f, 0.014f, decay = 160f))
            tracks[Sound.SOFT_TICK] = build(tone(1800f, 0.012f, decay = 120f, volume = 0.14f))
            tracks[Sound.SUCCESS] = build(
                tone(660f, 0.06f, decay = 32f) +
                    tone(990f, 0.10f, decay = 24f) +
                    tone(1320f, 0.12f, decay = 18f, volume = 0.18f)
            )
            tracks[Sound.ERROR] = build(
                tone(220f, 0.09f, decay = 28f, pitchDrop = 0.45f, volume = 0.22f)
            )
            tracks[Sound.WHOOSH] = build(noise(0.08f))
            tracks[Sound.CHIME] = build(
                tone(523f, 0.08f, decay = 20f, volume = 0.20f) +
                    tone(659f, 0.10f, decay = 16f, volume = 0.18f) +
                    tone(784f, 0.14f, decay = 12f, volume = 0.16f)
            )
            tracks[Sound.LEVEL_UP] = build(
                tone(440f, 0.07f, decay = 22f) +
                    tone(554f, 0.08f, decay = 20f) +
                    tone(659f, 0.12f, decay = 14f) +
                    tone(880f, 0.16f, decay = 10f, volume = 0.20f)
            )
            tracks[Sound.SHIELD] = build(
                tone(180f, 0.07f, decay = 35f, pitchDrop = 0.2f, volume = 0.24f) +
                    tone(120f, 0.09f, decay = 28f, volume = 0.16f)
            )
        }
    }

    fun play(sound: Sound) {
        if (!enabled) return
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val track = tracks[sound] ?: return
        runCatching {
            track.stop()
            track.reloadStaticData()
            track.play()
        }
    }

    fun release() {
        tracks.values.forEach { runCatching { it.release() } }
        tracks.clear()
    }

    private fun tone(
        freq: Float,
        seconds: Float,
        decay: Float,
        pitchDrop: Float = 0f,
        volume: Float = 0.28f,
    ): ShortArray {
        val n = (RATE * seconds).toInt().coerceAtLeast(1)
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            val f = freq * (1f - pitchDrop * (i.toFloat() / n))
            val envelope = exp(-decay * t)
            (sin(2.0 * PI * f * t) * envelope * Short.MAX_VALUE * volume)
                .toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
    }

    private fun noise(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt().coerceAtLeast(1)
        val rng = kotlin.random.Random(4)
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            val envelope = exp(-40f * t)
            ((rng.nextFloat() * 2 - 1) * envelope * Short.MAX_VALUE * 0.12)
                .toInt().toShort()
        }
    }

    private operator fun ShortArray.plus(other: ShortArray): ShortArray {
        val out = ShortArray(size + other.size)
        copyInto(out)
        other.copyInto(out, size)
        return out
    }

    private fun build(samples: ShortArray): AudioTrack {
        val bytes = samples.size * 2
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bytes.coerceAtLeast(AudioTrack.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )))
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(samples, 0, samples.size)
        return track
    }
}
