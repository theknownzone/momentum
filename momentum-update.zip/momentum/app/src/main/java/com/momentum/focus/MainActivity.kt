package com.momentum.focus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.momentum.focus.ui.AppViewModel
import com.momentum.focus.ui.nav.PaperBottomBar
import com.momentum.focus.ui.nav.Tab
import com.momentum.focus.ui.screens.*
import com.momentum.focus.ui.theme.MomentumTheme
import com.momentum.focus.ui.util.CrashReporter
import com.momentum.focus.block.BlockerService
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.rememberHaptics

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) Sfx.release()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashReporter.install(applicationContext)
        Sfx.init(applicationContext)
        val startupCrash = CrashReporter.lastCrash(this)
        enableEdgeToEdge()

        setContent {
            MomentumTheme {
                var splashDone by remember { mutableStateOf(false) }
                if (!splashDone) {
                    SplashScreen { splashDone = true }
                    return@MomentumTheme
                }

                var crash by remember { mutableStateOf(startupCrash) }
                val shownCrash = crash
                if (shownCrash != null) {
                    CrashScreen(trace = shownCrash) {
                        CrashReporter.clear(this@MainActivity)
                        crash = null
                    }
                    return@MomentumTheme
                }

                val data by vm.data.collectAsStateWithLifecycle()
                val timer by vm.timer.collectAsStateWithLifecycle()
                val finished by vm.sessionFinished.collectAsStateWithLifecycle()
                val haptics = rememberHaptics()

                var tab by remember { mutableStateOf(Tab.HOME) }
                var panicOpen by remember { mutableStateOf(false) }
                var profileOpen by remember { mutableStateOf(false) }
                var permsOpen by remember { mutableStateOf(false) }
                var blockListOpen by remember { mutableStateOf(false) }

                // Shown once per version: if the installed build is newer than
                // the one last acknowledged, the changelog comes up first.
                val version = remember { Updater.currentVersion(this@MainActivity) }
                var newsOpen by remember(data.lastSeenVersion) {
                    mutableStateOf(
                        data.onboarded && data.lastSeenVersion.isNotBlank() &&
                            data.lastSeenVersion != version
                    )
                }

                // The service only ever runs with the user's current choices,
                // so both the list and the on/off switch push straight into it.
                LaunchedEffect(data.blockedPackages, data.shieldOn) {
                    BlockerService.blocked = data.blockedPackages
                    if (data.shieldOn && data.blockedPackages.isNotEmpty() &&
                        Perms.allRequiredGranted(this@MainActivity)
                    ) {
                        BlockerService.start(this@MainActivity)
                    } else {
                        BlockerService.stop(this@MainActivity)
                    }
                }

                // Onboarding is two stages: explain the idea, then ask for the
                // permissions. Asking first, before anyone knows what the app
                // does, is how permission prompts get denied.
                var explained by remember(data.onboarded) { mutableStateOf(data.onboarded) }

                LaunchedEffect(finished) { if (finished > 0) haptics.sessionComplete() }

                if (!explained) {
                    WelcomeScreen { name ->
                        if (name.isNotBlank()) vm.setName(name)
                        explained = true
                    }
                    return@MomentumTheme
                }

                if (!data.onboarded) {
                    // Order matters: explain, then permissions, then pick the
                    // apps. Asking someone to choose what to block before they
                    // know what the app does gets an empty list every time.
                    var permsDone by remember { mutableStateOf(false) }
                    if (!permsDone) {
                        PermissionsScreen(onDone = { permsDone = true })
                    } else {
                        BlockListScreen(
                            data = data,
                            onToggle = vm::toggleBlocked,
                            onDone = {
                                vm.setShield(true)
                                vm.markVersionSeen(version)
                                vm.completeOnboarding()
                            },
                        )
                    }
                    return@MomentumTheme
                }

                if (newsOpen) {
                    WhatsNewScreen(version = version) {
                        vm.markVersionSeen(version)
                        newsOpen = false
                    }
                    return@MomentumTheme
                }

                // Full-screen modes deliberately hide the tab bar: during a
                // craving or a settings edit there is nowhere else to go.
                val fullScreen = panicOpen || profileOpen || permsOpen || blockListOpen

                // Back was doing nothing on every overlay, so the only way out
                // of Profile was to kill the app. Innermost layer closes first.
                BackHandler(enabled = fullScreen) {
                    when {
                        permsOpen -> permsOpen = false
                        blockListOpen -> blockListOpen = false
                        profileOpen -> profileOpen = false
                        panicOpen -> panicOpen = false
                    }
                }

                // On a tab other than Home, back returns Home rather than
                // dropping the user out of the app entirely.
                BackHandler(enabled = !fullScreen && tab != Tab.HOME) {
                    tab = Tab.HOME
                }

                Scaffold(
                    bottomBar = {
                        if (!fullScreen) PaperBottomBar(current = tab, onSelect = { tab = it })
                    },
                    containerColor = MaterialTheme.colorScheme.background,
                ) { padding ->
                    Box(
                        Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .statusBarsPadding()
                            .background(MaterialTheme.colorScheme.background)
                    ) {
                        when {
                            permsOpen -> PermissionsScreen(onDone = { permsOpen = false })

                            blockListOpen -> BlockListScreen(
                                data = data,
                                onToggle = vm::toggleBlocked,
                                onDone = { blockListOpen = false },
                            )

                            profileOpen -> ProfileScreen(
                                data = data,
                                onCrown = vm::setCrown,
                                onRatio = vm::setEarnRatio,
                                onAvatar = vm::setAvatar,
                                onName = vm::setName,
                                onGoal = vm::setGoal,
                                onDailyGoal = vm::setDailyGoal,
                                onMotto = vm::setMotto,
                                onAddSubject = vm::addSubject,
                                onRemoveSubject = vm::removeSubject,
                                onExport = vm::exportJson,
                                onPermissions = { permsOpen = true },
                                onBlockList = { blockListOpen = true },
                                onShield = vm::setShield,
                            )

                            panicOpen -> PanicScreen(
                                onSurvived = { vm.logUrge(survived = true) },
                                onRelapsed = { vm.logUrge(survived = false); vm.resetStreak() },
                                onDone = { panicOpen = false },
                            )

                            tab == Tab.HOME -> HomeScreen(
                                data = data,
                                onStartFocus = { tab = Tab.FOCUS },
                                onPanic = { panicOpen = true },
                                onJournal = { tab = Tab.JOURNAL },
                                onProfile = { profileOpen = true },
                                onShield = { blockListOpen = true },
                                onRewards = { tab = Tab.REWARDS },
                            )

                            tab == Tab.FOCUS -> FocusScreen(
                                data = data,
                                timer = timer,
                                onToggle = vm::toggleTimer,
                                onAbandon = vm::abandon,
                                onDuration = vm::setDuration,
                                onSubject = vm::setSubject,
                            )

                            tab == Tab.STATS -> StatsScreen(data = data)

                            tab == Tab.REWARDS -> AchievementsScreen(data = data)

                            tab == Tab.JOURNAL -> JournalScreen(
                                data = data,
                                onSave = vm::saveJournal,
                            )
                        }
                    }
                }
            }
        }
    }
}
