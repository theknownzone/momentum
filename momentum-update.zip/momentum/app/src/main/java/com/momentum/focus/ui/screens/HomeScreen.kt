package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.data.FocusSession
import com.momentum.focus.data.unlockedCount
import com.momentum.focus.ui.components.*
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import java.time.LocalDate
import kotlin.math.roundToInt

/**
 * Two-plane dashboard: a dark hero card holding identity and the balance,
 * sitting on a cream body that carries everything else.
 */
@Composable
fun HomeScreen(
    data: AppData,
    onStartFocus: () -> Unit,
    onPanic: () -> Unit,
    onJournal: () -> Unit,
    onProfile: () -> Unit,
    onShield: () -> Unit,
    onRewards: () -> Unit,
) {
    val haptics = rememberHaptics()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .verticalScroll(rememberScrollState()),
    ) {
        Hero(data, onProfile, onStartFocus, onShield)

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 18.dp, bottom = 28.dp),
        ) {
            TodayStrip(data, onJournal)

            Spacer(Modifier.height(12.dp))

            UpdateCard(Modifier.fillMaxWidth())

            Spacer(Modifier.height(16.dp))

            // Horizontal insight slides (screen time / streak / balance hooks)
            InsightSlides(data)

            Spacer(Modifier.height(18.dp))

            Text(
                "QUICK ACTIONS",
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard(
                    icon = Icons.Filled.Bolt,
                    title = "Panic",
                    detail = "or shake the phone",
                    sticker = Tang,
                    modifier = Modifier.weight(1f),
                ) { haptics.press(); onPanic() }

                ActionCard(
                    icon = Icons.Filled.EditNote,
                    title = "Journal",
                    detail = if (data.todayJournal == null) "not logged today" else "logged today",
                    sticker = Lilac,
                    modifier = Modifier.weight(1f),
                ) { onJournal() }
            }

            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard(
                    icon = Icons.Filled.Shield,
                    title = "Shield",
                    detail = "${data.blockedPackages.size} apps blocked",
                    sticker = Mint,
                    modifier = Modifier.weight(1f),
                ) { onShield() }

                ActionCard(
                    icon = Icons.Filled.Timer,
                    title = "Rewards",
                    detail = "${data.unlockedCount} unlocked",
                    sticker = Butter,
                    modifier = Modifier.weight(1f),
                ) { onRewards() }
            }

            Spacer(Modifier.height(24.dp))

            Text(
                "RECENT",
                style = MaterialTheme.typography.labelSmall,
                color = InkMid,
            )
            Spacer(Modifier.height(10.dp))

            val feed = remember(data) { buildFeed(data) }
            if (feed.isEmpty()) EmptyFeed() else feed.forEach { ActivityRow(it) }
        }
    }
}

@Composable
private fun InsightSlides(data: AppData) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val hasUsage = remember {
        com.momentum.focus.ui.util.Perms.granted(
            context,
            com.momentum.focus.ui.util.Perm.USAGE_ACCESS,
        )
    }
    val today = remember(hasUsage) {
        if (hasUsage) runCatching {
            com.momentum.focus.data.WellbeingStore.today(context)
        }.getOrNull() else null
    }

    Text(
        "TODAY",
        style = MaterialTheme.typography.labelSmall,
        color = InkMid,
    )
    Spacer(Modifier.height(10.dp))

    Row(
        Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // Big number: screen time or focus
        StickerCard(
            sticker = Mint,
            modifier = Modifier.weight(1f).fillMaxHeight(),
        ) {
            Text(
                if (today != null) "SCREEN TIME" else "FOCUS TODAY",
                style = MaterialTheme.typography.labelSmall,
                color = Mint.on.copy(alpha = 0.75f),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (today != null) today.formatScreen()
                else "${data.minutesToday}m",
                style = MaterialTheme.typography.headlineMedium,
                color = Mint.on,
            )
            Text(
                if (today != null) "${today.pickups} pickups"
                else "goal ${data.dailyGoalMinutes}m",
                style = MaterialTheme.typography.bodyMedium,
                color = Mint.on.copy(alpha = 0.8f),
            )
        }

        StickerCard(
            sticker = Butter,
            modifier = Modifier.weight(1f).fillMaxHeight(),
        ) {
            Text(
                "STREAK",
                style = MaterialTheme.typography.labelSmall,
                color = Butter.on.copy(alpha = 0.75f),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "${data.streakDays}",
                style = MaterialTheme.typography.headlineMedium,
                color = Butter.on,
            )
            Text(
                "best ${maxOf(data.bestStreak, data.streakDays)} days",
                style = MaterialTheme.typography.bodyMedium,
                color = Butter.on.copy(alpha = 0.8f),
            )
        }
    }

    Spacer(Modifier.height(10.dp))

    // Horizontal scroll insight chips
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        MiniStatChip("Balance", "${data.balanceMinutes}m", Mint)
        MiniStatChip("Sessions", "${data.sessionsToday} today", Lilac)
        MiniStatChip("Urges beat", "${data.urgesSurvived}", Tang)
        MiniStatChip("Blocked", "${data.blockedPackages.size} apps", Sky)
        if (today != null && today.apps.isNotEmpty()) {
            val top = today.apps.first()
            MiniStatChip("Top app", top.label.take(12), Butter)
        }
    }
}

@Composable
private fun MiniStatChip(label: String, value: String, sticker: Sticker) {
    Column(
        Modifier
            .width(120.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(sticker.fill)
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .padding(12.dp),
    ) {
        Text(
            label.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = sticker.on.copy(alpha = 0.7f),
        )
        Spacer(Modifier.height(4.dp))
        Text(
            value,
            style = MaterialTheme.typography.titleMedium,
            color = sticker.on,
            maxLines = 1,
        )
    }
}

// ---------------------------------------------------------------- hero

@Composable
private fun Hero(
    data: AppData,
    onProfile: () -> Unit,
    onStartFocus: () -> Unit,
    onShield: () -> Unit,
) {
    val haptics = rememberHaptics()
    val counted by animateFloatAsState(
        targetValue = data.balanceMinutes.toFloat(),
        animationSpec = Motion.settle(),
        label = "balance",
    )
    val minutes = counted.roundToInt()
    val goal = data.dailyGoalMinutes.coerceAtLeast(1)
    val goalFrac by animateFloatAsState(
        targetValue = (data.minutesToday.toFloat() / goal).coerceIn(0f, 1f),
        animationSpec = Motion.settle(),
        label = "goal",
    )
    val week = remember(data) { data.recentMinutes(7) }
    val weekPeak = (week.maxOrNull() ?: 0).coerceAtLeast(30)

    Column(
        Modifier
            .fillMaxWidth()
            .background(Ink, RoundedCornerShape(bottomStart = 26.dp, bottomEnd = 26.dp))
            .statusBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 14.dp, bottom = 22.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(data) { haptics.tap(); onProfile() }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "hi, ${data.userName}",
                    style = MaterialTheme.typography.titleMedium,
                    color = CreamCard,
                )
                Text(
                    data.motto.ifBlank { "${data.streakDays} day streak · lv ${data.level}" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkLow,
                    maxLines = 1,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    "LV ${data.level}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Mint.fill,
                )
                Text(
                    "${data.streakDays}d",
                    style = MaterialTheme.typography.titleMedium,
                    color = CreamCard,
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Text(
            "Focus balance",
            style = MaterialTheme.typography.bodyMedium,
            color = InkLow,
        )
        Spacer(Modifier.height(2.dp))

        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                "${minutes / 60}",
                style = MaterialTheme.typography.displayLarge,
                color = CreamCard,
            )
            Text(
                "h",
                style = MaterialTheme.typography.headlineSmall,
                color = InkLow,
                modifier = Modifier.padding(bottom = 12.dp, start = 2.dp, end = 10.dp),
            )
            Text(
                "%02d".format(minutes % 60),
                style = MaterialTheme.typography.displayMedium,
                color = CreamCard,
            )
            Text(
                "m",
                style = MaterialTheme.typography.headlineSmall,
                color = InkLow,
                modifier = Modifier.padding(bottom = 6.dp, start = 2.dp),
            )
        }

        Spacer(Modifier.height(12.dp))

        Text(
            if (data.todayGoalHit) "TODAY'S GOAL · HIT"
            else "TODAY'S GOAL · ${data.minutesToday}m / ${goal}m",
            style = MaterialTheme.typography.labelSmall,
            color = if (data.todayGoalHit) Mint.fill else InkLow,
        )
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(99.dp))
                .background(CreamCard.copy(alpha = 0.12f))
                .border(1.dp, CreamCard.copy(alpha = 0.18f), RoundedCornerShape(99.dp)),
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(goalFrac.coerceAtLeast(0.02f))
                    .clip(RoundedCornerShape(99.dp))
                    .background(if (data.todayGoalHit) Mint.fill else Butter.fill),
            )
        }

        Spacer(Modifier.height(14.dp))

        Text(
            "LAST 7 DAYS",
            style = MaterialTheme.typography.labelSmall,
            color = InkLow,
        )
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .height(56.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            week.forEachIndexed { i, m ->
                val h = (m.toFloat() / weekPeak).coerceIn(0.08f, 1f)
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight(h)
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (i == week.lastIndex) Mint.fill
                            else CreamCard.copy(alpha = 0.22f)
                        ),
                )
            }
        }

        Spacer(Modifier.height(8.dp))
        Row {
            Text(
                "▲ ${data.minutesToday}m today",
                style = MaterialTheme.typography.bodyMedium,
                color = Mint.fill,
            )
            Spacer(Modifier.weight(1f))
            Text(
                "${data.sessionsToday} sessions · ${data.xpIntoLevel}/${data.xpForLevel} xp",
                style = MaterialTheme.typography.bodyMedium,
                color = InkLow,
            )
        }

        Spacer(Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HeroButton("Start focus", Mint.fill, Mint.on, Modifier.weight(1f)) {
                onStartFocus()
            }
            HeroButton("Shield", CreamCard, Ink, Modifier.weight(1f)) {
                onShield()
            }
        }
    }
}

@Composable
private fun TodayStrip(data: AppData, onJournal: () -> Unit) {
    val left = (data.dailyGoalMinutes - data.minutesToday).coerceAtLeast(0)
    val streakLeft = (data.streakGoal - data.streakDays).coerceAtLeast(0)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .padding(14.dp),
    ) {
        Text("TODAY", style = MaterialTheme.typography.labelSmall, color = InkMid)
        Spacer(Modifier.height(8.dp))
        Text(
            when {
                data.todayGoalHit -> "Goal done. Bank more if you want — the day is yours."
                data.minutesToday == 0 -> "No minutes yet. One session and the dashboard wakes up."
                else -> "${left}m left to hit today's ${data.dailyGoalMinutes}m goal."
            },
            style = MaterialTheme.typography.titleMedium,
            color = Ink,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            buildString {
                append("${data.streakDays}/${data.streakGoal} streak")
                if (streakLeft > 0) append(" · $streakLeft days to goal")
                append(" · ${data.goalHits(7)}/7 goals this week")
                if (data.todayJournal == null) append(" · journal still empty")
            },
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
        )
        if (data.todayJournal == null) {
            Spacer(Modifier.height(10.dp))
            val haptics = rememberHaptics()
            Box(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Lilac.fill)
                    .border(2.dp, Ink, RoundedCornerShape(12.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) {
                        haptics.tap(); onJournal()
                    }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                Text("Write today's journal", style = MaterialTheme.typography.titleMedium, color = Lilac.on)
            }
        }
    }
}

@Composable
private fun HeroButton(
    label: String,
    fill: androidx.compose.ui.graphics.Color,
    on: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    Box(
        modifier
            .clip(RoundedCornerShape(13.dp))
            .background(fill)
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                haptics.confirm(); onClick()
            }
            .padding(vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium, color = on)
    }
}

@Composable
private fun Avatar(data: AppData, onClick: () -> Unit) {
    val sticker = stickerFor(data.avatarColor)
    val face = data.avatarSymbol.ifBlank {
        data.userName.trim().firstOrNull()?.uppercase() ?: "?"
    }
    val isEmoji = face.isNotEmpty() && (face.length > 1 || face[0].code > 127)
    Box(
        Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(sticker.fill)
            .border(2.dp, CreamCard, RoundedCornerShape(15.dp))
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            face,
            style = if (isEmoji) MaterialTheme.typography.headlineSmall
                    else MaterialTheme.typography.titleMedium,
            color = if (isEmoji) androidx.compose.ui.graphics.Color.Unspecified else sticker.on,
        )
    }
}

// ---------------------------------------------------------------- body

@Composable
private fun ActionCard(
    icon: ImageVector,
    title: String,
    detail: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val haptics = rememberHaptics()
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .clickableNoRipple(remember { MutableInteractionSource() }) {
                haptics.tap(); onClick()
            }
            .padding(14.dp),
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(sticker.fill)
                .border(2.dp, Ink, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = sticker.on, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
        Text(detail, style = MaterialTheme.typography.bodyMedium, color = InkMid)
    }
}

private data class FeedRow(
    val title: String,
    val subtitle: String,
    val amount: String,
    val sticker: Sticker,
    val icon: ImageVector,
)

private fun buildFeed(data: AppData): List<FeedRow> {
    val today = LocalDate.now().toEpochDay()

    fun ago(day: Long) = when (val d = (today - day).toInt()) {
        0 -> "Today"
        1 -> "Yesterday"
        else -> "$d days ago"
    }

    val sessions = data.sessions.takeLast(6).reversed().map { s: FocusSession ->
        FeedRow(
            title = s.subject,
            subtitle = if (s.completed) ago(s.startedAtEpochDay)
                       else "${ago(s.startedAtEpochDay)} · left early",
            amount = "+${s.minutes}m",
            sticker = if (s.completed) Mint else Butter,
            icon = Icons.Filled.Timer,
        )
    }

    val urges = data.urges.takeLast(4).reversed().map { u ->
        FeedRow(
            title = if (u.survived) "Urge beaten" else "Slip logged",
            subtitle = "${ago(u.epochDay)} · around ${u.hour}:00",
            amount = if (u.survived) "held" else "reset",
            sticker = if (u.survived) Sky else Candy,
            icon = Icons.Filled.Shield,
        )
    }

    return (sessions + urges).take(8)
}

@Composable
private fun ActivityRow(row: FeedRow) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(row.sticker.fill)
                .border(2.dp, Ink, RoundedCornerShape(9.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                row.icon,
                contentDescription = null,
                tint = row.sticker.on,
                modifier = Modifier.size(18.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(row.title, style = MaterialTheme.typography.titleMedium, color = Ink)
            Text(row.subtitle, style = MaterialTheme.typography.bodyMedium, color = InkMid)
        }
        Text(row.amount, style = MaterialTheme.typography.titleMedium, color = row.sticker.accent)
    }
}

@Composable
private fun EmptyFeed() {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CreamCard)
            .border(2.dp, Ink, RoundedCornerShape(16.dp))
            .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CoinStack(Modifier.size(84.dp, 68.dp))
        Spacer(Modifier.height(12.dp))
        Text("Nothing banked yet", style = MaterialTheme.typography.titleMedium, color = Ink)
        Spacer(Modifier.height(4.dp))
        Text(
            "Finish one focus session and your first minutes land here.",
            style = MaterialTheme.typography.bodyMedium,
            color = InkMid,
            textAlign = TextAlign.Center,
        )
    }
}
