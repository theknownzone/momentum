package com.momentum.focus.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.data.WellbeingStore
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Perms
import com.momentum.focus.ui.util.Perm
import com.momentum.focus.ui.util.Sfx
import com.momentum.focus.ui.util.Sound
import com.momentum.focus.ui.util.rememberHaptics
import androidx.compose.foundation.interaction.MutableInteractionSource

/**
 * Stay Focused-style curiosity onboarding:
 * intro → guess hours → guess pickups → usage permission →
 * real report → life years shock → improvement → focus goal → done.
 * Paper look kept; numbers come from UsageStats when allowed.
 */
@Composable
fun CuriosityOnboarding(
    onFinished: (focusArea: String) -> Unit,
) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    var step by remember { mutableIntStateOf(0) }
    var guessHours by remember { mutableFloatStateOf(0f) }
    var guessPickups by remember { mutableFloatStateOf(0f) }
    var focusArea by remember { mutableStateOf("") }
    var hasUsage by remember { mutableStateOf(Perms.granted(context, Perm.USAGE_ACCESS)) }

    // Refresh usage grant when user returns from Settings
    LaunchedEffect(step) {
        if (step == 3) {
            hasUsage = Perms.granted(context, Perm.USAGE_ACCESS)
        }
    }

    val real = remember(hasUsage, step) {
        if (hasUsage) runCatching { WellbeingStore.today(context) }.getOrNull()
        else null
    }
    val week = remember(hasUsage, step) {
        if (hasUsage) runCatching { WellbeingStore.lastDays(context, 7) }.getOrNull()
        else null
    }

    val realMinutes = real?.screenMinutes ?: ((guessHours * 60).toInt().coerceAtLeast(60))
    val realPickups = real?.pickups?.coerceAtLeast(1) ?: guessPickups.toInt().coerceAtLeast(40)
    val years = WellbeingStore.yearsFromDailyMinutes(realMinutes)
    val improvedMin = (realMinutes * 0.2).toInt().coerceAtLeast(30)
    val improvedPickups = (realPickups * 0.2).toInt().coerceAtLeast(8)

    val totalSteps = 8

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 20.dp, bottom = 16.dp),
    ) {
        // Progress bar
        Row(
            Modifier.fillMaxWidth().height(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            repeat(totalSteps) { i ->
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(50))
                        .background(
                            if (i <= step) Mint.fill
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (step) {
                0 -> IntroStep { haptics.tick(); Sfx.play(Sound.POP); step = 1 }
                1 -> GuessHoursStep(
                    value = guessHours,
                    onChange = { guessHours = it },
                    onNext = { haptics.tick(); Sfx.play(Sound.TICK); step = 2 },
                    onSkip = { step = 2 },
                )
                2 -> GuessPickupsStep(
                    value = guessPickups,
                    onChange = { guessPickups = it },
                    onNext = { haptics.tick(); Sfx.play(Sound.TICK); step = 3 },
                    onSkip = { step = 3 },
                )
                3 -> UsagePermStep(
                    granted = hasUsage,
                    onGrant = {
                        haptics.tick()
                        runCatching {
                            context.startActivity(
                                Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                            )
                        }
                    },
                    onContinue = {
                        hasUsage = Perms.granted(context, Perm.USAGE_ACCESS)
                        haptics.tick()
                        Sfx.play(Sound.CHIME)
                        step = 4
                    },
                    onSkip = { step = 4 },
                )
                4 -> ReportStep(
                    guessHours = guessHours.toInt(),
                    guessPickups = guessPickups.toInt(),
                    realMinutes = realMinutes,
                    realPickups = realPickups,
                    week = week,
                    apps = real?.apps.orEmpty(),
                    onNext = { haptics.tick(); Sfx.play(Sound.CHIME); step = 5 },
                )
                5 -> LifeYearsStep(
                    minutes = realMinutes,
                    years = years,
                    onNext = { haptics.tick(); Sfx.play(Sound.WHOOSH); step = 6 },
                )
                6 -> ImprovementStep(
                    youMin = realMinutes,
                    betterMin = improvedMin,
                    youPick = realPickups,
                    betterPick = improvedPickups,
                    onNext = { haptics.tick(); Sfx.play(Sound.LEVEL_UP); step = 7 },
                )
                7 -> FocusAreaStep(
                    selected = focusArea,
                    onSelect = { focusArea = it; haptics.tick(); Sfx.play(Sound.POP) },
                    onNext = {
                        haptics.confirm()
                        Sfx.play(Sound.SUCCESS)
                        onFinished(focusArea.ifBlank { "Study" })
                    },
                    onSkip = { onFinished("Study") },
                )
            }
        }
    }
}

@Composable
private fun IntroStep(onNext: () -> Unit) {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.weight(0.3f))
        Text(
            "Reclaim Your Time & Focus",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "60 seconds. Guess your phone use — then see the real numbers. No lecture, just data.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.weight(1f))
        SquishButton(
            label = "GET STARTED",
            sticker = Emerald,
            modifier = Modifier.fillMaxWidth(),
            onClick = onNext,
        )
    }
}

@Composable
private fun GuessHoursStep(
    value: Float,
    onChange: (Float) -> Unit,
    onNext: () -> Unit,
    onSkip: () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        Text(
            "How many hours do you think you spend on your phone daily?",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            "Just a rough guess works.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.weight(0.4f))
        Text(
            "${value.toInt()} HRS",
            style = MaterialTheme.typography.displayLarge.copy(fontSize = 48.sp),
            color = Mint.fill,
            modifier = Modifier.align(Alignment.CenterHorizontally),
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(24.dp))
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = 0f..14f,
            steps = 13,
            colors = SliderDefaults.colors(
                thumbColor = Mint.fill,
                activeTrackColor = Mint.fill,
                inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant,
            ),
            modifier = Modifier.fillMaxWidth(),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("0 HRS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("14+ HRS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SquishButton(label = "SKIP", sticker = Butter, modifier = Modifier.weight(1f), onClick = onSkip)
            SquishButton(label = "CONTINUE", sticker = Emerald, modifier = Modifier.weight(1.4f), onClick = onNext)
        }
    }
}

@Composable
private fun GuessPickupsStep(
    value: Float,
    onChange: (Float) -> Unit,
    onNext: () -> Unit,
    onSkip: () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        Text(
            "And how often do you think you pick up your phone daily?",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            "Just a rough guess works.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.weight(0.4f))
        Text(
            "${value.toInt()}x",
            style = MaterialTheme.typography.displayLarge.copy(fontSize = 48.sp),
            color = Mint.fill,
            modifier = Modifier.align(Alignment.CenterHorizontally),
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(24.dp))
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = 0f..200f,
            steps = 39,
            colors = SliderDefaults.colors(
                thumbColor = Mint.fill,
                activeTrackColor = Mint.fill,
                inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant,
            ),
            modifier = Modifier.fillMaxWidth(),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("0x", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("200+x", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SquishButton(label = "SKIP", sticker = Butter, modifier = Modifier.weight(1f), onClick = onSkip)
            SquishButton(label = "CONTINUE", sticker = Emerald, modifier = Modifier.weight(1.4f), onClick = onNext)
        }
    }
}

@Composable
private fun UsagePermStep(
    granted: Boolean,
    onGrant: () -> Unit,
    onContinue: () -> Unit,
    onSkip: () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        Text(
            "Let's compare with real screen time",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Give Usage Access so we can show your actual numbers — same data Digital Wellbeing uses.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(28.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CreamCard)
                .border(2.dp, Ink, RoundedCornerShape(16.dp))
                .padding(16.dp),
        ) {
            Column {
                Text("1. Find Momentum in the list", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("2. Turn on Permit usage access", style = MaterialTheme.typography.titleMedium)
            }
        }
        Spacer(Modifier.weight(1f))
        if (!granted) {
            SquishButton(
                label = "TAP TO GRANT",
                sticker = Emerald,
                modifier = Modifier.fillMaxWidth(),
                onClick = onGrant,
            )
            Spacer(Modifier.height(10.dp))
            SquishButton(label = "SKIP FOR NOW", sticker = Butter, modifier = Modifier.fillMaxWidth(), onClick = onSkip)
        } else {
            Text(
                "Usage access granted ✓",
                color = Mint.fill,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )
            Spacer(Modifier.height(12.dp))
            SquishButton(label = "SEE MY REPORT", sticker = Emerald, modifier = Modifier.fillMaxWidth(), onClick = onContinue)
        }
    }
}

@Composable
private fun ReportStep(
    guessHours: Int,
    guessPickups: Int,
    realMinutes: Int,
    realPickups: Int,
    week: List<com.momentum.focus.data.DayUsage>?,
    apps: List<com.momentum.focus.data.AppUsage>,
    onNext: () -> Unit,
) {
    val h = realMinutes / 60
    val m = realMinutes % 60
    val avgLabel = if (h > 0) "${h}h ${"%02d".format(m)}m" else "${m}m"

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        Text(
            "Report is ready",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(Modifier.height(16.dp))
        Text(
            "Your 7-day average",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (guessHours > 0) {
            Text(
                "Your assumption was ${guessHours}h",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Text(
            avgLabel,
            style = MaterialTheme.typography.displayLarge.copy(fontSize = 42.sp),
            color = Mint.fill,
            fontWeight = FontWeight.Bold,
        )
        Text(
            "is your daily average",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        if (!week.isNullOrEmpty()) {
            Spacer(Modifier.height(16.dp))
            val maxM = week.maxOf { it.screenMinutes }.coerceAtLeast(1)
            Row(
                Modifier.fillMaxWidth().height(100.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                week.forEach { day ->
                    val frac = day.screenMinutes.toFloat() / maxM
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight(frac.coerceIn(0.05f, 1f))
                            .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                            .background(Mint.fill.copy(alpha = 0.85f))
                    )
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            "${realPickups}x",
            style = MaterialTheme.typography.displayMedium,
            color = Butter.fill,
            fontWeight = FontWeight.Bold,
        )
        Text(
            "pickups / day average" +
                if (guessPickups > 0) "  ·  you guessed ${guessPickups}x" else "",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        if (apps.isNotEmpty()) {
            Spacer(Modifier.height(20.dp))
            Text("Top distractions", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            apps.take(5).forEach { app ->
                val ah = app.minutes / 60
                val am = app.minutes % 60
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(app.label, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        if (ah > 0) "${ah}h ${am}m" else "${am}m",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        SquishButton(label = "CONTINUE", sticker = Emerald, modifier = Modifier.fillMaxWidth(), onClick = onNext)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun LifeYearsStep(
    minutes: Int,
    years: Double,
    onNext: () -> Unit,
) {
    val h = minutes / 60
    val m = minutes % 60
    val label = if (h > 0) "${"%02d".format(h)}H ${"%02d".format(m)}M" else "${m}M"
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            "$label A DAY =",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            String.format("%.1f YEARS", years),
            style = MaterialTheme.typography.displayLarge.copy(fontSize = 44.sp),
            color = Mint.fill,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )
        Text(
            "OF YOUR LIFE",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Projected over the next 30 years.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(40.dp))
        SquishButton(label = "CONTINUE", sticker = Emerald, modifier = Modifier.fillMaxWidth(), onClick = onNext)
    }
}

@Composable
private fun ImprovementStep(
    youMin: Int,
    betterMin: Int,
    youPick: Int,
    betterPick: Int,
    onNext: () -> Unit,
) {
    fun fmt(mins: Int): String {
        val h = mins / 60
        val m = mins % 60
        return if (h > 0) "${"%02d".format(h)}h ${"%02d".format(m)}m" else "${m}m"
    }
    Column(Modifier.fillMaxSize()) {
        Text(
            "You've already taken the first step",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            "Here's your potential with Momentum.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(28.dp))
        Text("Screen time", style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(8.dp))
        StatBar(label = "You", value = fmt(youMin), frac = 1f, color = Tang.fill)
        Spacer(Modifier.height(8.dp))
        StatBar(label = "With Momentum", value = fmt(betterMin), frac = betterMin.toFloat() / youMin.coerceAtLeast(1), color = Mint.fill)
        Spacer(Modifier.height(24.dp))
        Text("Pickups", style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(8.dp))
        StatBar(label = "You", value = "${youPick}x", frac = 1f, color = Tang.fill)
        Spacer(Modifier.height(8.dp))
        StatBar(label = "With Momentum", value = "${betterPick}x", frac = betterPick.toFloat() / youPick.coerceAtLeast(1), color = Mint.fill)
        Spacer(Modifier.height(28.dp))
        Text(
            "~80% IMPROVEMENT",
            style = MaterialTheme.typography.titleLarge,
            color = Mint.fill,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )
        Text(
            "Based on users who block distractions and bank focus time.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.weight(1f))
        SquishButton(label = "CONTINUE", sticker = Emerald, modifier = Modifier.fillMaxWidth(), onClick = onNext)
    }
}

@Composable
private fun StatBar(label: String, value: String, frac: Float, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
    }
    Spacer(Modifier.height(4.dp))
    Box(
        Modifier
            .fillMaxWidth()
            .height(12.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(frac.coerceIn(0.08f, 1f))
                .clip(RoundedCornerShape(6.dp))
                .background(color)
        )
    }
}

@Composable
private fun FocusAreaStep(
    selected: String,
    onSelect: (String) -> Unit,
    onNext: () -> Unit,
    onSkip: () -> Unit,
) {
    val areas = listOf(
        "School" to "Ace exams and assignments",
        "Work" to "Deep work and deadlines",
        "Time for Myself" to "Be present and mindful",
        "Family" to "Connect distraction-free",
    )
    Column(Modifier.fillMaxSize()) {
        Text(
            "Where do you want to improve focus first?",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            "This helps set your first goal. You can change it later.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(16.dp))
        areas.forEach { (title, sub) ->
            val on = selected == title
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (on) Mint.fill.copy(alpha = 0.25f) else CreamCard)
                    .border(if (on) Paper.Outline else 1.dp, Ink, RoundedCornerShape(14.dp))
                    .clickableNoRipple(remember { MutableInteractionSource() }) { onSelect(title) }
                    .padding(16.dp),
            ) {
                Column {
                    Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground)
                    Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SquishButton(label = "SKIP", sticker = Butter, modifier = Modifier.weight(1f), onClick = onSkip)
            SquishButton(label = "CONTINUE", sticker = Emerald, modifier = Modifier.weight(1.4f), onClick = onNext)
        }
    }
}
