package com.momentum.focus.data

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.core.content.getSystemService
import java.util.Calendar

/**
 * Reads the same UsageStats data Digital Wellbeing / Stay Focused uses.
 * No official Digital Wellbeing API exists — this is the system source.
 */
data class AppUsage(
    val packageName: String,
    val label: String,
    val millis: Long,
) {
    val minutes: Int get() = (millis / 60_000L).toInt()
}

data class DayUsage(
    val screenMillis: Long,
    val pickups: Int,
    val apps: List<AppUsage>,
) {
    val screenMinutes: Int get() = (screenMillis / 60_000L).toInt()
    fun formatScreen(): String {
        val h = screenMinutes / 60
        val m = screenMinutes % 60
        return if (h > 0) "${h}h ${"%02d".format(m)}m" else "${m}m"
    }
}

object WellbeingStore {

    /** Lifetime projection: daily minutes × 365 × 30 / (60*24*365) ≈ years. */
    fun yearsFromDailyMinutes(dailyMinutes: Int): Double =
        dailyMinutes * 30.0 / (60.0 * 24.0)

    fun today(context: Context): DayUsage = range(context, daysBack = 0)

    fun yesterday(context: Context): DayUsage = range(context, daysBack = 1)

    /** Last [days] calendar days, oldest first. Index 0 = days-1 ago. */
    fun lastDays(context: Context, days: Int): List<DayUsage> =
        (days - 1 downTo 0).map { range(context, daysBack = it) }

    private fun range(context: Context, daysBack: Int): DayUsage {
        val usage = context.getSystemService<UsageStatsManager>()
            ?: return DayUsage(0, 0, emptyList())

        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -daysBack)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val start = cal.timeInMillis
        val end = if (daysBack == 0) System.currentTimeMillis()
        else start + 24L * 60 * 60 * 1000 - 1

        val stats = runCatching {
            usage.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
        }.getOrNull().orEmpty()

        val byPkg = linkedMapOf<String, Long>()
        var total = 0L
        for (s in stats) {
            val t = s.totalTimeInForeground
            if (t <= 0) continue
            if (s.packageName == context.packageName) continue
            if (isSystemHeavy(context, s.packageName)) continue
            byPkg[s.packageName] = (byPkg[s.packageName] ?: 0L) + t
            total += t
        }

        val pickups = countPickups(usage, start, end, context.packageName)
        val pm = context.packageManager
        val apps = byPkg.entries
            .sortedByDescending { it.value }
            .take(12)
            .map { (pkg, ms) ->
                AppUsage(pkg, labelOf(pm, pkg), ms)
            }

        return DayUsage(total, pickups, apps)
    }

    private fun countPickups(
        usage: UsageStatsManager,
        start: Long,
        end: Long,
        self: String,
    ): Int = runCatching {
        val events = usage.queryEvents(start, end)
        val event = UsageEvents.Event()
        var count = 0
        var last = ""
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType != UsageEvents.Event.MOVE_TO_FOREGROUND) continue
            val pkg = event.packageName ?: continue
            if (pkg == self || pkg == last) continue
            // Launcher reopen counts as a pickup for wellbeing-style stats.
            count++
            last = pkg
        }
        count
    }.getOrDefault(0)

    private fun labelOf(pm: PackageManager, pkg: String): String = runCatching {
        val ai = pm.getApplicationInfo(pkg, 0)
        pm.getApplicationLabel(ai).toString()
    }.getOrDefault(pkg.substringAfterLast('.'))

    private fun isSystemHeavy(context: Context, pkg: String): Boolean = runCatching {
        val ai = context.packageManager.getApplicationInfo(pkg, 0)
        (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
            (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0 &&
            !pkg.contains("chrome", true) &&
            !pkg.contains("youtube", true)
    }.getOrDefault(false)
}
