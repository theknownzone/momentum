import java.util.Properties

/**
 * The Chutes key, read from local.properties or the environment.
 *
 * Never committed: local.properties is gitignored, and CI has no such secret,
 * so a build made by anyone but us comes out with an empty string here.
 *
 * The AI features gate on this being non-blank rather than on the build type,
 * because in this project the *debug* build is the one people install — it is
 * signed with the shared key and has isDebuggable off. A buildType gate would
 * have shipped the key to everyone. A missing key cannot be shipped.
 */
private val chutesKey: String = run {
    val local = rootProject.file("local.properties")
    if (local.exists()) {
        Properties().apply { local.inputStream().use { load(it) } }
            .getProperty("chutes.key")?.takeIf { it.isNotBlank() }
            ?.let { return@run it }
    }
    System.getenv("CHUTES_API_KEY").orEmpty()
}

/**
 * The licence-key secret, read the same way as the Chutes key.
 *
 * It used to be a const in License.kt, which meant the one value that decides
 * whether a key is real sat in a public repo where anyone could read it and
 * mint their own. Moving it here does not make the scheme uncrackable — the
 * secret still ships inside the APK and always will without a server — but it
 * stops it being readable without even downloading the APK.
 *
 * Blank falls back to the old placeholder, so a build with no secret set still
 * works exactly as it does today and every key issued so far keeps validating.
 * Set MOMENTUM_LICENSE_SECRET before selling anything; that is the moment the
 * previously-issued keys stop working, which is the point.
 */
private val licenseSecret: String = run {
    val local = rootProject.file("local.properties")
    if (local.exists()) {
        Properties().apply { local.inputStream().use { load(it) } }
            .getProperty("license.secret")?.takeIf { it.isNotBlank() }
            ?.let { return@run it }
    }
    System.getenv("MOMENTUM_LICENSE_SECRET").orEmpty()
}

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.momentum.focus"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.momentum.focus"
        minSdk = 26
        targetSdk = 35
        // CI supplies the run number so every build is a higher version than
        // the last, which is what the in-app updater compares against.
        val run = (System.getenv("GITHUB_RUN_NUMBER") ?: "910").toInt()
        versionCode = run
        versionName = "1.9.$run"

        buildConfigField("String", "AI_KEY", "\"$chutesKey\"")
        buildConfigField("boolean", "AI_ENABLED", chutesKey.isNotBlank().toString())
        buildConfigField("String", "LICENSE_SECRET", "\"$licenseSecret\"")
    }

    // A fixed signing key, checked into the project on purpose.
    //
    // CI generates a brand new debug keystore on every run, so each build was
    // signed by a different key and Android refused to update over the last
    // install ("package conflicts"). Pinning one key makes every build an
    // upgrade of the previous one.
    signingConfigs {
        create("shared") {
            // The committed keystore is a convenience, not a good one. Its
            // password is in the repo, so anyone can sign an APK that Android
            // will happily install over this app as an update. Play Protect
            // treats a widely-known signing key as a risk signal on top of
            // everything else the app declares.
            //
            // If MOMENTUM_KEYSTORE_B64 and the two passwords are set as
            // repository secrets, the workflow writes the private key to
            // release.jks and this picks it up. Nothing changes for anyone who
            // has not set them up yet.
            val privateKey = file("release.jks")
            val committed = file("momentum.jks")
            when {
                privateKey.exists() && System.getenv("MOMENTUM_KEY_PASSWORD") != null -> {
                    storeFile = privateKey
                    storePassword = System.getenv("MOMENTUM_STORE_PASSWORD")
                    keyAlias = System.getenv("MOMENTUM_KEY_ALIAS") ?: "momentum"
                    keyPassword = System.getenv("MOMENTUM_KEY_PASSWORD")
                }
                committed.exists() -> {
                    storeFile = committed
                    storePassword = "momentum123"
                    keyAlias = "momentum"
                    keyPassword = "momentum123"
                }
                // Neither key is present. Left unset on purpose so the build
                // falls through to Android's own debug key rather than failing.
                //
                // It used to point at momentum.jks unconditionally, so removing
                // that file — which is exactly what you must do before selling
                // anything — broke every build with "Keystore file not found".
                // The one step on the path to doing this properly was the step
                // that stopped the project compiling.
                //
                // The cost is that builds made this way are signed by a key
                // that differs per machine, so Android will refuse to update
                // over an install signed by a different one. Set the secrets
                // and that stops being true.
                else -> Unit
            }
        }
    }

    // Only attached when a key was actually found. An empty signing config
    // fails validation just as hard as a missing file, so the check has to
    // happen here too, not only where the config is built.
    val sharedKey = signingConfigs.getByName("shared").takeIf { it.storeFile != null }

    lint {
        /**
         * AGP decides a build type needs lintVital by asking whether it is
         * debuggable. This debug build is deliberately not — see the comment
         * on isDebuggable below — so assembleDebug drags in
         * lintVitalAnalyzeDebug, and any lint finding anywhere in the project
         * then blocks the only route this project has to an installable APK.
         *
         * The owner builds on GitHub Actions from a phone. A lint gate there
         * is not a quality bar, it is a wall with no door: there is no local
         * Android Studio to read the report in and no way to iterate.
         */
        checkReleaseBuilds = false
        abortOnError = false
    }

    buildTypes {
        getByName("debug") {
            // Only overwritten when a real key exists. Assigning null here does
            // not fall back to anything — it removes the default debug signing
            // config that AGP already put on this build type, and the APK comes
            // out unsigned. An unsigned APK is what Android reports as "package
            // appears to be invalid", which is a confusing way to say nobody
            // signed it.
            if (sharedKey != null) signingConfig = sharedKey
            // The APK people actually install is this one, built by CI and
            // sideloaded. AGP marks debug builds android:debuggable, and a
            // sideloaded app that is debuggable AND declares an accessibility
            // service reads to Play Protect exactly like a trojan. Turning it
            // off costs nothing here — nobody attaches a debugger to the
            // release APK — and removes the worst signal in the profile.
            isDebuggable = false
        }
        release {
            isMinifyEnabled = false
            // Release has no default of its own, so it borrows the debug key
            // when no private one is configured. Not fit to publish, but it
            // produces an APK that installs instead of one that cannot.
            signingConfig = sharedKey ?: signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.4")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")

    implementation(platform("androidx.compose:compose-bom:2024.11.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
