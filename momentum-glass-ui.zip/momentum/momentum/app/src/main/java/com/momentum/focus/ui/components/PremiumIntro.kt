package com.momentum.focus.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.theme.Cream
import com.momentum.focus.ui.theme.GoldNeon
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import com.momentum.focus.ui.theme.*

/**
 * A short full-screen beat when Premium first turns on.
 * Not a video — scale + gold aura + two haptic hits.
 */
@Composable
fun PremiumIntro(onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val alpha = remember { Animatable(0f) }
    val scale = remember { Animatable(0.72f) }
    LaunchedEffect(Unit) {
        haptics.unlock()
        alpha.animateTo(1f, tween(280))
        scale.animateTo(1.08f, tween(420))
        scale.animateTo(1f, tween(380))
        delay(900)
        haptics.sessionComplete()
        delay(700)
        alpha.animateTo(0f, tween(420))
        onDone()
    }
    Box(
        Modifier
            .fillMaxSize()
            .alpha(alpha.value)
            .background(RonWash),
        contentAlignment = Alignment.Center,
    ) {
        Aura(color = GoldNeon, strength = 0.8f) {
            Text(
                "PREMIUM",
                fontSize = 52.sp,
                fontWeight = FontWeight.Bold,
                color = Snow,
                modifier = Modifier
                    .scale(scale.value)
                    .padding(24.dp),
            )
        }
        Text(
            "MOMENTUM",
            style = MaterialTheme.typography.labelSmall,
            color = Snow.copy(alpha = 0.45f),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp),
        )
    }
}
