package com.momentum.focus.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.components.Avatar3D
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.sin
import kotlin.random.Random

/**
 * The payoff moment.
 *
 * Everything fires at once on purpose — haptic, sound, confetti, a shape
 * punching in with overshoot. Reward has to be loud and immediate or it does
 * not register as reward at all. This is the only screen in the app allowed to
 * shout, which is exactly why it works.
 */
@Composable
fun CelebrationScreen(
    kicker: String,
    title: String,
    body: String,
    colorIndex: Int,
    shapeIndex: Int,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()
    val pop = remember { Animatable(0.2f) }
    val confetti = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        haptics.celebrate()
        pop.animateTo(
            1f,
            spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        )
    }
    LaunchedEffect(Unit) {
        confetti.animateTo(1f, tween(2600, easing = LinearEasing))
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Ink),
        contentAlignment = Alignment.Center,
    ) {
        Confetti(confetti.value)

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 40.dp, bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(1f))

            Box(Modifier.scale(pop.value)) {
                Avatar3D(colorIndex = colorIndex, shapeIndex = shapeIndex, size = 150.dp)
            }

            Spacer(Modifier.height(28.dp))

            Text(
                kicker,
                style = MaterialTheme.typography.labelSmall,
                color = stickerFor(colorIndex).fill,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                title,
                style = MaterialTheme.typography.displayMedium,
                color = CreamCard,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                body,
                style = MaterialTheme.typography.bodyLarge,
                color = SnowDim,
                textAlign = TextAlign.Center,
            )

            Spacer(Modifier.weight(1f))

            SquishButton(
                label = "Keep going",
                sticker = stickerFor(colorIndex),
                modifier = Modifier.fillMaxWidth(),
                onClick = onDone,
            )
        }
    }
}

/**
 * Confetti as plain rectangles falling on sine paths.
 *
 * A particle system would be overkill: at this size the eye reads colour and
 * motion, not shape, so fifty rectangles with different phases is enough and
 * costs nothing.
 */
@Composable
private fun Confetti(progress: Float) {
    val pieces = remember {
        val rng = Random(9)
        List(50) {
            ConfettiPiece(
                x = rng.nextFloat(),
                delay = rng.nextFloat() * 0.35f,
                speed = 0.7f + rng.nextFloat() * 0.6f,
                drift = (rng.nextFloat() - 0.5f) * 0.18f,
                width = 6f + rng.nextFloat() * 8f,
                height = 10f + rng.nextFloat() * 12f,
                color = StickerCycle[rng.nextInt(StickerCycle.size)].fill,
                phase = rng.nextFloat() * 6.28f,
            )
        }
    }

    Canvas(Modifier.fillMaxSize()) {
        pieces.forEach { p ->
            val t = ((progress - p.delay) * p.speed).coerceIn(0f, 1f)
            if (t <= 0f) return@forEach
            val y = t * (size.height + 120f) - 60f
            val x = p.x * size.width + sin(t * 6f + p.phase) * size.width * p.drift
            drawRect(
                color = p.color.copy(alpha = (1f - t * 0.65f).coerceIn(0f, 1f)),
                topLeft = Offset(x, y),
                size = Size(p.width, p.height),
            )
        }
    }
}

private data class ConfettiPiece(
    val x: Float,
    val delay: Float,
    val speed: Float,
    val drift: Float,
    val width: Float,
    val height: Float,
    val color: Color,
    val phase: Float,
)
