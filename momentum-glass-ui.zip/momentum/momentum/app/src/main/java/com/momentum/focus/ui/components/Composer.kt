package com.momentum.focus.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.momentum.focus.ai.Doubt
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics

private val BoxShape = RoundedCornerShape(28.dp)

enum class Attachment { Camera, Photo, Pdf, Mock }

@Composable
fun Composer(
    text: String,
    onText: (String) -> Unit,
    busy: Boolean,
    canSend: Boolean,
    premium: Boolean,
    onAttach: (Attachment) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onPlans: () -> Unit,
    attachmentLabel: String? = null,
    modifier: Modifier = Modifier,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val accent = LocalSkin.current.accent
    var menuOpen by remember { mutableStateOf(false) }

    Column(
        modifier
            .fillMaxWidth()
            .clip(BoxShape)
            .liquidShine()
            .background(Color.White.copy(alpha = 0.72f))
            .border(1.dp, Color.White.copy(alpha = 0.85f), BoxShape)
            .glowEdge(active = busy, shape = BoxShape)
            .padding(horizontal = 10.dp, vertical = 10.dp),
    ) {
        if (attachmentLabel != null) {
            Text(
                attachmentLabel,
                style = MaterialTheme.typography.labelSmall,
                color = Mint.accent,
                modifier = Modifier.padding(bottom = 6.dp, start = 4.dp),
            )
        }

        Row(verticalAlignment = Alignment.Bottom) {
            val spin by animateFloatAsState(
                targetValue = if (menuOpen) 135f else 0f,
                animationSpec = Motion.bouncy(),
                label = "spin",
            )
            RoundButton(
                fill = Color(0xFF2A3140),
                onClick = { haptics.tick(); menuOpen = !menuOpen },
                description = str.doubt.attachMore,
            ) {
                Icon(
                    Icons.Filled.Add,
                    contentDescription = null,
                    tint = Snow,
                    modifier = Modifier.size(22.dp).rotate(spin),
                )
            }

            Spacer(Modifier.width(10.dp))

            BasicTextField(
                value = text,
                onValueChange = {
                    if (it.length != text.length) haptics.tick()
                    onText(it.take(Doubt.MAX_CHARS))
                },
                enabled = !busy,
                textStyle = MaterialTheme.typography.bodyLarge.copy(color = Color(0xFF111827)),
                cursorBrush = SolidColor(accent),
                maxLines = 5,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 40.dp, max = 140.dp)
                    .padding(bottom = 6.dp),
                decorationBox = { field ->
                    Box {
                        if (text.isEmpty()) {
                            Text(
                                str.doubt.hint,
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color(0xFF6B7280),
                            )
                        }
                        field()
                    }
                },
            )

            Spacer(Modifier.width(10.dp))

            SendStopButton(
                busy = busy,
                enabled = canSend,
                onSend = onSend,
                onStop = onStop,
            )
        }

        if (menuOpen) {
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AttachChip(Icons.Filled.PhotoCamera, str.doubt.camera, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Camera) } else onPlans()
                }
                AttachChip(Icons.Filled.AddPhotoAlternate, str.doubt.photo, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Photo) } else onPlans()
                }
                AttachChip(Icons.Filled.PictureAsPdf, str.doubt.pdf, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Pdf) } else onPlans()
                }
                AttachChip(Icons.Filled.Quiz, str.mock.label, premium) {
                    menuOpen = false
                    if (premium) { haptics.tick(); onAttach(Attachment.Mock) } else onPlans()
                }
            }
        }
    }
}

@Composable
private fun RoundButton(
    fill: Color,
    onClick: () -> Unit,
    description: String,
    content: @Composable () -> Unit,
) {
    Box(
        Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(fill)
            .border(1.dp, NightLine.copy(alpha = 0.6f), CircleShape)
            .clickableNoRipple(remember { MutableInteractionSource() }) { onClick() }
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun AttachChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    unlocked: Boolean,
    onClick: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(if (unlocked) Color(0xFF2A3140) else Color(0xFF151922))
                .border(1.dp, NightLine, RoundedCornerShape(15.dp))
                .clickableNoRipple(remember { MutableInteractionSource() }) { onClick() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                icon,
                contentDescription = label,
                tint = if (unlocked) Snow else SnowDim,
                modifier = Modifier.size(21.dp),
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (unlocked) InkMid else InkLow,
        )
    }
}

@Composable
private fun SendStopButton(
    busy: Boolean,
    enabled: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    val live = busy || enabled
    val scale by animateFloatAsState(
        targetValue = if (busy) 1.06f else 1f,
        animationSpec = Motion.bouncy(),
        label = "scale",
    )
    val spoken = if (busy) str.doubt.stop else str.doubt.send

    Box(
        Modifier
            .scale(scale)
            .size(44.dp)
            .clip(CircleShape)
            .background(if (busy) Tang.fill else if (live) Color.White else Color(0xFF2A3140))
            .border(1.dp, NightLine, CircleShape)
            .clickableNoRipple(remember { MutableInteractionSource() }, enabled = live) {
                if (busy) onStop() else { haptics.tick(); onSend() }
            }
            .semantics { contentDescription = spoken },
        contentAlignment = Alignment.Center,
    ) {
        if (busy) {
            Spacer(
                Modifier
                    .size(15.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Ink),
            )
        } else {
            Icon(
                Icons.Filled.Send,
                contentDescription = null,
                tint = if (live) Color.Black else SnowDim,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}
