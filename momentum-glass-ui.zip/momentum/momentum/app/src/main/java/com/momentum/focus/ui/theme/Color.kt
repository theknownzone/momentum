package com.momentum.focus.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ---- Paper -----------------------------------------------------------------
// Butter-yellow page with a printed grid, like an engineer's notebook.
val Cream     = Color(0xFFFBF3D5)
val CreamCard = Color(0xFFFFFDF2)
val GridLine  = Color(0x14FFFFFF)
val Sunk      = Color(0xFFF2E7BE)

/** Dark canvas used on Home / Plans so cream paper is no longer the only look. */
val Night     = Color(0xFF0B0E14)
val NightCard = Color(0xFF161B24)
val RonWash = Brush.verticalGradient(
    listOf(Color(0xFF8BB8B4), Color(0xFFC4B6BE), Color(0xFF1C222C)),
)
val NightLine = Color(0xFF2A3140)
val Snow      = Color(0xFFF4F6FA)
val SnowDim   = Color(0xFF9AA3B5)
val InkText   = Color(0xFF111827)
val InkMute   = Color(0xFF4B5563)

// ---- Ink -------------------------------------------------------------------
// One near-black used for every border and every heading. Consistency of the
// outline is what makes the whole screen read as a single printed object.
val Ink    = Color(0xFF1A1A1A)
val InkMid = Color(0xFFB7C0CE)
val InkLow = Color(0xFF7E8796)
val GoldNeon = Color(0xFFFFD54A)

/**
 * A block of colour with a hard black outline.
 *
 * `fill` is the flat colour, `on` is the text that sits on it — always a very
 * dark shade of the same hue, never pure black, so the block still reads as
 * coloured rather than as a hole in the page.
 */
data class Sticker(
    val fill: Color,
    val edge: Color,
    val on: Color,
    val accent: Color = fill,
) {
    val brush: Brush get() = Brush.linearGradient(listOf(fill, fill))
    val bloom: Brush get() = Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
}

val Mint   = Sticker(Color(0xFF3FE28F), Ink, Color(0xFF0B3D26), Color(0xFF1D9E55))
val Butter = Sticker(Color(0xFFFFD84D), Ink, Color(0xFF4A3600), Color(0xFF8A6400))
val Tang   = Sticker(Color(0xFFFF8A5C), Ink, Color(0xFF4A1B08), Color(0xFFB24A1E))
val Lilac  = Sticker(Color(0xFFB9A7FF), Ink, Color(0xFF231457), Color(0xFF5A3FC0))
val Sky    = Sticker(Color(0xFF7FD4FF), Ink, Color(0xFF073048), Color(0xFF1A6E96))
val Candy  = Sticker(Color(0xFFFF9EC4), Ink, Color(0xFF4A0F2A), Color(0xFFB2306A))

// Old names kept so every screen keeps compiling.
val Emerald = Mint
val Gold = Butter
val Violet = Lilac
val Ember = Tang
val Ice = Sky
val Rose = Candy
val Jade = Mint
val Marigold = Butter
val Grape = Lilac
val Coral = Tang
val Cobalt = Sky
val Blush = Candy

val StickerCycle = listOf(Mint, Butter, Tang, Lilac, Sky, Candy)

fun stickerFor(seed: Int): Sticker = StickerCycle[Math.floorMod(seed, StickerCycle.size)]


/**
 * Lightens a colour toward white by [amount].
 *
 * Used to build the two-stop gradients on filled shapes. Every fill in the app
 * still starts from one of the palette colours above — the gradient is derived
 * from it rather than picked separately, so a shape lit at its crown is
 * unmistakably the same colour as the flat version of itself.
 */
fun Color.lighten(amount: Float): Color = Color(
    red + (1f - red) * amount,
    green + (1f - green) * amount,
    blue + (1f - blue) * amount,
    alpha,
)

/** Darkens a colour toward black by [amount]. The other half of a gradient. */
fun Color.darken(amount: Float): Color = Color(
    red * (1f - amount),
    green * (1f - amount),
    blue * (1f - amount),
    alpha,
)

/** A top-lit vertical gradient built from a single palette colour. */
fun Color.lit(): Brush = Brush.verticalGradient(
    listOf(lighten(0.24f), this, darken(0.08f))
)
