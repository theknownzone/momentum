package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.Butter
import com.momentum.focus.ui.theme.CreamCard
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.InkLow
import com.momentum.focus.ui.theme.InkMid
import com.momentum.focus.ui.theme.Mint
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.Sunk
import java.time.LocalDate
import com.momentum.focus.ui.theme.*

/** The rungs. Each one is a day count and what reaching it is worth. */
private val RUNGS = listOf(7, 14, 30, 60, 90)

/**
 * The streak, and what it is climbing towards.
 *
 * The number on its own answers "how long" and nothing else. A streak is a
 * thing you keep going, so the question it actually raises is "until what" —
 * and the app had no answer anywhere on any screen. Seven days of ticks show
 * the week just gone; the ladder underneath shows the next rung and how far
 * off it is.
 *
 * Rungs are days, not rewards, because nothing is handed out for them. Saying
 * a number is coming and then not paying it would be worse than saying
 * nothing; what a rung buys is the fact of having got there.
 */
@Composable
fun StreakLadder(data: AppData, modifier: Modifier = Modifier) {
    val str = strings()
    val shape = RoundedCornerShape(Paper.CardRadius)
    val streak = data.streakDays
    val next = RUNGS.firstOrNull { it > streak }

    // The seven days ending today, marked from the session log rather than
    // from the streak count — a streak that broke on Tuesday should still show
    // Monday's tick.
    val today = LocalDate.now()
    val week = (6 downTo 0).map { back ->
        val day = today.minusDays(back.toLong())
        val epoch = day.toEpochDay()
        day to data.sessions.any { it.startedAtEpochDay == epoch && it.completed }
    }

    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(NightCard)
            .border(1.dp, NightLine, shape)
            .padding(16.dp),
    ) {
        Text(str.success.streakLabel, style = MaterialTheme.typography.labelSmall, color = SnowDim)
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                streak.toString(),
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Bold,
                color = Snow,
            )
            Spacer(Modifier.size(6.dp))
            Text(
                str.success.streakDays,
                style = MaterialTheme.typography.bodyMedium,
                color = SnowDim,
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }

        Spacer(Modifier.height(12.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            week.forEach { (day, done) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        day.dayOfWeek.name.take(1),
                        style = MaterialTheme.typography.labelSmall,
                        color = SnowDim,
                    )
                    Spacer(Modifier.height(4.dp))
                    Box(
                        Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(if (done) Mint.fill else Sunk)
                            .border(2.dp, if (done) Ink else InkLow, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (done) {
                            Icon(
                                Icons.Filled.Check,
                                contentDescription = null,
                                tint = Mint.on,
                                modifier = Modifier.size(15.dp),
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            RUNGS.forEach { rung ->
                val reached = streak >= rung
                val isNext = rung == next
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (reached) Butter.fill else NightCard)
                        .border(
                            if (isNext) Paper.Outline else 1.5.dp,
                            if (reached || isNext) Ink else InkLow,
                            RoundedCornerShape(10.dp),
                        )
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        rung.toString(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (reached || isNext) Ink else InkLow,
                        textAlign = TextAlign.Center,
                    )
                    Text(
                        str.success.rungDays,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (reached || isNext) InkMid else InkLow,
                    )
                }
            }
        }

        if (next != null) {
            Spacer(Modifier.height(10.dp))
            Text(
                str.success.toNextRung(next - streak, next),
                style = MaterialTheme.typography.bodyMedium,
                color = Snow,
            )
        }
    }
}
