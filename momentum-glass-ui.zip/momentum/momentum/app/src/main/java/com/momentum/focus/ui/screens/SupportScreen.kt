package com.momentum.focus.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.AppData
import com.momentum.focus.ui.components.GlassSection
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.Updater
import com.momentum.focus.ui.util.rememberHaptics

/** Support inbox. Replace if this ever moves to a domain address. */
private const val SUPPORT_EMAIL = "barrytbrooks2@gmail.com"

/**
 * Help, feedback and the plain facts about what the app does with data.
 *
 * The device and build details are filled into the email body automatically.
 * Asking someone to find their Android version and app build before they can
 * report a bug is how bug reports stop arriving.
 */
@Composable
fun SupportScreen(data: AppData, onDone: () -> Unit) {
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val skin = LocalSkin.current

    fun mail(subject: String) {
        val body = buildString {
            append("\n\n\n---\n")
            append("Ye lines rakh dena, inse dikkat dhoondhne mein aasani hoti hai.\n")
            append("App: Momentum ${Updater.currentVersion(context)}\n")
            append("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
            append("Device: ${Build.MANUFACTURER} ${Build.MODEL}\n")
            append("Plan: ${if (data.premium) "Lifetime" else "Free"}\n")
        }
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$SUPPORT_EMAIL"))
                    .putExtra(Intent.EXTRA_SUBJECT, subject)
                    .putExtra(Intent.EXTRA_TEXT, body)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        Text("HELP", style = MaterialTheme.typography.labelSmall, color = SnowDim)
        Text(
            "Kuch atka hai?",
            style = MaterialTheme.typography.displayMedium,
            color = Snow,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Seedha likh do. Jawab ek aadmi dega, bot nahi.",
            style = MaterialTheme.typography.bodyLarge,
            color = SnowDim,
        )

        GlassSection("Baat karo", "Email, bug, suggestion", tint = skin.accent, initiallyOpen = true) {
            SupportRow(
                "Kuch toota hai",
                "Bug report bhejo — device ki details apne aap lag jayengi",
            ) { haptics.tap(); mail("Momentum — bug") }
            SupportRow(
                "Kuch chahiye",
                "Naya feature ya badlav suggest karo",
            ) { haptics.tap(); mail("Momentum — feature") }
            SupportRow(
                "Paise ki dikkat",
                "Key nahi chali, ya payment ka sawaal",
            ) { haptics.tap(); mail("Momentum — licence") }
        }

        GlassSection("Tumhara data", "Kahan jaata hai", tint = skin.petal) {
            Fact(
                "Sab kuch is phone pe hai",
                "Koi server nahi hai. Na account, na login. Jo tumne banaya wo " +
                    "yahin rehta hai, aur app uninstall karne pe chala jaata hai.",
            )
            Fact(
                "Screen padhne wali permission",
                "Accessibility sirf ye dekhne ke liye hai ki Shorts ya Reels " +
                    "khuli hai ya nahi. Kuch bhejta nahi, kuch save nahi karta.",
            )
            Fact(
                "Internet kab lagta hai",
                "Sirf update check karne ke liye. Baaki poora app offline chalta hai.",
            )
        }

        Spacer(Modifier.height(20.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, NightLine, RoundedCornerShape(14.dp))
                .clickableNoRipple(remember { MutableInteractionSource() }) {
                    haptics.tap(); onDone()
                }
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text("Back", style = MaterialTheme.typography.titleMedium, color = Snow)
        }
    }
}

@Composable
private fun SupportRow(title: String, note: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = Snow)
            Text(note, style = MaterialTheme.typography.bodyMedium, color = SnowDim)
        }
        Text("\u203A", style = MaterialTheme.typography.headlineSmall, color = SnowDim)
    }
}

@Composable
private fun Fact(title: String, body: String) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = Snow)
        Text(body, style = MaterialTheme.typography.bodyMedium, color = SnowDim)
    }
}
