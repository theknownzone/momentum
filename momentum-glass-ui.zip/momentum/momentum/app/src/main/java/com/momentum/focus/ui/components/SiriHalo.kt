package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp

@Composable
fun Modifier.siriEdgeHalo(): Modifier {
    val motion = rememberInfiniteTransition(label = "siri")
    val spin by motion.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(5200, easing = LinearEasing)),
        label = "spin",
    )
    val pulse by motion.animateFloat(
        0.62f, 1f,
        infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    val ribbon = listOf(
        Color(0xFF4DE4FF),
        Color(0xFF5B7CFF),
        Color(0xFFC084FC),
        Color(0xFFFF5FA2),
        Color(0xFFFFB020),
        Color(0xFF4DE4FF),
    )
    return this.drawWithContent {
        drawContent()
        val inset = 7.dp.toPx()
        val rim = 16.dp.toPx() * pulse
        rotate(spin, pivot = Offset(size.width / 2f, size.height / 2f)) {
            drawRoundRect(
                brush = Brush.sweepGradient(
                    ribbon,
                    center = Offset(size.width / 2f, size.height / 2f),
                ),
                topLeft = Offset(inset, inset),
                size = Size(size.width - inset * 2f, size.height - inset * 2f),
                cornerRadius = CornerRadius(42.dp.toPx(), 42.dp.toPx()),
                style = Stroke(width = rim, cap = StrokeCap.Round),
                alpha = 0.78f,
            )
        }
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color.Transparent,
                    Color(0x334DE4FF),
                    Color(0x66C084FC),
                    Color(0x88FF5FA2),
                ),
                startY = size.height * 0.62f,
                endY = size.height,
            ),
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x55FFB020), Color.Transparent),
                center = Offset(size.width / 2f, size.height - 8.dp.toPx()),
                radius = size.width * 0.42f * pulse,
            ),
            radius = size.width * 0.42f * pulse,
            center = Offset(size.width / 2f, size.height - 6.dp.toPx()),
        )
    }
}
