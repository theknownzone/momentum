package com.momentum.focus.ui.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class Sound {
    POP, TICK, SUCCESS, ERROR, WHOOSH,
    // Cutscene.
    RISER, CRACK, BOOM, SHIMMER,
    // One per event, because two events sharing a sound is two events the ear
    // cannot tell apart. Celebrating a streak used to make the same noise as
    // logging a session, and sending a question to MyAi made the same noise as
    // both of them.
    SEND, REPLY, LEVEL, FESTIVE, SESSION, RIGHT, WRONG, UNLOCK,
}

/**
 * UI sounds generated as raw PCM at startup instead of shipped as .wav files.
 *
 * Two reasons: no binary assets to manage, and the tones can be tuned by
 * changing a number rather than re-exporting audio. Each sound is a sine with
 * an exponential decay envelope — a decay is what separates a "pop" from a
 * "beep", since a flat envelope always sounds like a cheap alarm.
 */
object Sfx {

    private const val RATE = 44100
    private val tracks = mutableMapOf<Sound, AudioTrack>()
    private var audioManager: AudioManager? = null
    /**
     * Off unless the user turns it on.
     *
     * A tick on every tap is fine once and grating by the fiftieth. The sounds
     * stay in the build for anyone who wants them, but nobody should have to
     * find the switch to stop them.
     */
    var enabled: Boolean = false

    fun init(context: Context) {
        if (tracks.isNotEmpty()) return
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        runCatching {
            // A pure sine is thin and plasticky. Adding a quiet octave and a
            // fifth above the root gives every sound a body, the same way a
            // real object resonates instead of beeping.
            tracks[Sound.POP] = build(
                chord(392f, 0.09f, decay = 22f, pitchDrop = 0.40f)
            )
            tracks[Sound.TICK] = build(
                tone(940f, 0.018f, decay = 90f, level = 0.14f)
            )
            // A rising major third, the interval every reward sound uses,
            // because it is the one people hear as "yes" rather than "done".
            tracks[Sound.SUCCESS] = build(
                chord(659f, 0.09f, decay = 26f) + chord(880f, 0.20f, decay = 16f)
            )
            tracks[Sound.ERROR] = build(
                chord(196f, 0.14f, decay = 20f, pitchDrop = 0.35f)
            )
            tracks[Sound.WHOOSH] = build(noise(0.13f))

            // Cutscene set. A riser that climbs for most of two seconds, the
            // crack that answers it, the low hit underneath, and a bright
            // chord over the top.
            tracks[Sound.RISER] = build(riser(1.75f))
            tracks[Sound.CRACK] = build(crack(0.16f))
            tracks[Sound.BOOM] = build(boom(1.1f))
            // Rising, because it is leaving. Quiet — this fires every time a
            // question is sent and it must never be the loudest thing here.
            tracks[Sound.SEND] = build(
                tone(520f, 0.06f, decay = 40f, pitchDrop = -0.20f, level = 0.18f)
            )
            // Falling, because it has arrived. The mirror of SEND, which is
            // what makes the pair read as a conversation rather than as two
            // unrelated beeps.
            tracks[Sound.REPLY] = build(
                chord(587f, 0.06f, decay = 32f) + chord(440f, 0.13f, decay = 22f)
            )
            // Three notes, not two. SUCCESS is a major third and says "done";
            // a level is a longer climb and has to sound like more than done.
            tracks[Sound.LEVEL] = build(
                chord(523f, 0.07f, decay = 30f) +
                    chord(659f, 0.07f, decay = 26f) +
                    chord(880f, 0.22f, decay = 15f)
            )
            tracks[Sound.FESTIVE] = build(
                chord(784f, 0.06f, decay = 36f, pitchDrop = 0.12f) +
                    chord(588f, 0.11f, decay = 24f)
            )
            // Long and low. A finished session is the one thing in this app
            // worth a sound that takes its time.
            tracks[Sound.SESSION] = build(
                chord(392f, 0.30f, decay = 8f) + chord(523f, 0.50f, decay = 5f)
            )
            tracks[Sound.RIGHT] = build(chord(880f, 0.09f, decay = 26f))
            // Dull rather than harsh. A wrong answer on a practice test is not
            // an error the app is reporting, it is a thing the student did, and
            // ERROR's buzz would make five of them feel like a telling-off.
            tracks[Sound.WRONG] = build(
                tone(233f, 0.17f, decay = 17f, pitchDrop = 0.28f, level = 0.22f)
            )
            tracks[Sound.UNLOCK] = build(riser(0.45f) + chord(1046f, 0.30f, decay = 9f))
            tracks[Sound.SHIMMER] = build(
                chord(880f, 0.22f, decay = 11f) + chord(1319f, 0.34f, decay = 8f)
            )
        }
    }

    /**
     * A sound that plays whether or not the UI-sound switch is on.
     *
     * That switch exists because a chirp on every tap is grating by the
     * fiftieth time — its own note says so. A cutscene that runs once in the
     * lifetime of an install is not what it was written to silence. The silent
     * switch is still obeyed, because that one always wins.
     */
    fun playOnce(sound: Sound) {
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val track = tracks[sound] ?: return
        runCatching {
            track.stop()
            track.reloadStaticData()
            track.play()
        }
    }

    fun play(sound: Sound) {
        if (!enabled) return
        // Respect the physical silent switch. Nothing annoys people faster than
        // an app that chirps in a library.
        if (audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val track = tracks[sound] ?: return
        runCatching {
            track.stop()
            track.reloadStaticData()
            track.play()
        }
    }

    fun release() {
        tracks.values.forEach { runCatching { it.release() } }
        tracks.clear()
    }

    // ---- synthesis --------------------------------------------------------

    /** Root plus an octave and a fifth, mixed low so it reads as timbre. */
    private fun chord(
        freq: Float,
        seconds: Float,
        decay: Float,
        pitchDrop: Float = 0f,
    ): ShortArray {
        val root = tone(freq, seconds, decay, pitchDrop, level = 0.24f)
        val octave = tone(freq * 2f, seconds, decay * 1.4f, pitchDrop, level = 0.09f)
        val fifth = tone(freq * 1.5f, seconds, decay * 1.2f, pitchDrop, level = 0.06f)
        return ShortArray(root.size) { i ->
            (root[i] + octave[i] + fifth[i]).coerceIn(
                Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()
            ).toShort()
        }
    }

    private fun tone(
        freq: Float,
        seconds: Float,
        decay: Float,
        pitchDrop: Float = 0f,
        level: Float = 0.28f,
    ): ShortArray {
        val n = (RATE * seconds).toInt()
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            // Sliding the frequency down over the note gives the sound a body,
            // like something physical settling.
            val f = freq * (1f - pitchDrop * (i.toFloat() / n))
            val envelope = exp(-decay * t)
            // A short fade-in kills the click that a hard start produces.
            val attack = (i / 140f).coerceAtMost(1f)
            (sin(2.0 * PI * f * t) * envelope * attack * Short.MAX_VALUE * level)
                .toInt().toShort()
        }
    }

    /**
     * A climb. Frequency rises, and so does the level — the swell is what makes
     * it read as something coming rather than something leaving.
     */
    private fun riser(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(11)
        return ShortArray(n) { i ->
            val p = i.toFloat() / n
            val t = i.toFloat() / RATE
            // Curved, not linear: a straight sweep sounds like a test tone.
            val f = 110f + 700f * p * p
            val swell = p * p
            val body = sin(2.0 * PI * f * t) * 0.6
            val air = (rng.nextFloat() * 2 - 1) * 0.25f * p
            ((body + air) * swell * Short.MAX_VALUE * 0.30).toInt().toShort()
        }
    }

    /** Short, bright, ugly on purpose. Something giving way. */
    private fun crack(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(7)
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            val envelope = exp(-70f * t)
            val snap = (rng.nextFloat() * 2 - 1)
            val ring = sin(2.0 * PI * 2400f * t) * 0.4
            ((snap + ring) * envelope * Short.MAX_VALUE * 0.30).toInt().toShort()
        }
    }

    /**
     * The hit. Low sine sliding down, with a noise transient on the front.
     *
     * Phone speakers cannot reproduce 45Hz, so the fundamental is felt more
     * than heard — the octave above it is what carries on a small speaker,
     * which is why it is mixed in rather than left to chance.
     */
    private fun boom(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(3)
        return ShortArray(n) { i ->
            val p = i.toFloat() / n
            val t = i.toFloat() / RATE
            val f = 62f * (1f - 0.35f * p)
            val envelope = exp(-4.2f * t)
            val sub = sin(2.0 * PI * f * t) * 0.75
            val octave = sin(2.0 * PI * f * 2 * t) * 0.30
            val transient = (rng.nextFloat() * 2 - 1) * exp(-60f * t) * 0.5f
            ((sub + octave + transient) * envelope * Short.MAX_VALUE * 0.34)
                .toInt().toShort()
        }
    }

    private fun noise(seconds: Float): ShortArray {
        val n = (RATE * seconds).toInt()
        val rng = kotlin.random.Random(4)
        return ShortArray(n) { i ->
            val t = i.toFloat() / RATE
            // Low-passed noise: averaging consecutive samples removes the
            // hiss and leaves the soft rush of air.
            val envelope = exp(-26f * t)
            val n = (rng.nextFloat() * 2 - 1) * 0.5f + (rng.nextFloat() * 2 - 1) * 0.5f
            (n * envelope * Short.MAX_VALUE * 0.13).toInt().toShort()
        }
    }

    private operator fun ShortArray.plus(other: ShortArray): ShortArray {
        val out = ShortArray(size + other.size)
        copyInto(out)
        other.copyInto(out, size)
        return out
    }

    private fun build(samples: ShortArray): AudioTrack {
        val bytes = samples.size * 2
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bytes)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(samples, 0, samples.size)
        return track
    }
}
