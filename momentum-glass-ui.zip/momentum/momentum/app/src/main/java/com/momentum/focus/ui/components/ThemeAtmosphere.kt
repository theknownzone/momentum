package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import com.momentum.focus.ui.theme.Skin
import com.momentum.focus.ui.util.DeviceProfile
import kotlin.math.sin
import kotlin.random.Random

/**
 * Dashboard weather for the active skin.
 * Sakura keeps petals; Monsoon rains; Ember sparks; etc.
 */
@Composable
fun ThemeAtmosphere(
    skin: Skin,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    if (DeviceProfile.isLowEnd(context)) return
    when (skin) {
        Skin.SAKURA -> SakuraFall(modifier, tint = skin.petal)
        Skin.MONSOON -> MonsoonSky(modifier, tint = skin.petal)
        Skin.EMBER -> EmberRise(modifier, tint = skin.petal)
        Skin.MIDNIGHT -> StarField(modifier, tint = skin.petal)
        Skin.GOLD -> GoldDust(modifier, tint = skin.petal)
        Skin.HOLI -> ColorBurst(modifier)
        Skin.DIWALI -> SparkRise(modifier, tint = skin.accent)
        Skin.TIRANGA -> FlagDrift(modifier)
        Skin.RAKHI -> ThreadDrift(modifier, tint = skin.petal)
        Skin.JANMASHTAMI -> ColorBurst(modifier)
    }
}

private data class Drop(
    val x: Float,
    val phase: Float,
    val speed: Float,
    val len: Float,
    val alpha: Float,
)

@Composable
private fun MonsoonSky(modifier: Modifier, tint: Color) {
    val drops = remember {
        val rng = Random(9)
        List(42) {
            Drop(
                x = rng.nextFloat(),
                phase = rng.nextFloat(),
                speed = 1.4f + rng.nextFloat() * 1.8f,
                len = 18f + rng.nextFloat() * 28f,
                alpha = 0.18f + rng.nextFloat() * 0.35f,
            )
        }
    }
    val clouds = remember {
        val rng = Random(3)
        List(4) { Triple(rng.nextFloat(), 0.08f + rng.nextFloat() * 0.18f, 0.35f + rng.nextFloat() * 0.45f) }
    }
    val motion = rememberInfiniteTransition(label = "monsoon")
    val t by motion.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart), "rain")
    val flash by motion.animateFloat(0f, 1f, infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart), "bolt")
    Canvas(modifier) {
        // clouds
        clouds.forEachIndexed { i, c ->
            val cx = ((c.first + t * 0.08f * (if (i % 2 == 0) 1 else -1)) % 1f) * size.width
            val cy = c.second * size.height
            drawCircle(Color.White.copy(alpha = 0.08f), radius = size.width * c.third * 0.28f, center = Offset(cx, cy))
            drawCircle(Color.White.copy(alpha = 0.06f), radius = size.width * c.third * 0.20f, center = Offset(cx + 40f, cy + 10f))
        }
        drops.forEach { d ->
            val progress = (t * d.speed + d.phase) % 1f
            val x = d.x * size.width + 10f
            val y = progress * (size.height + 40f) - 20f
            drawLine(
                color = tint.copy(alpha = d.alpha),
                start = Offset(x, y),
                end = Offset(x + 4f, y + d.len),
                strokeWidth = 2f,
                cap = StrokeCap.Round,
            )
            if (d.phase < 0.35f) {
                val land = ((progress + 0.15f) % 1f)
                drawCircle(
                    Color.White.copy(alpha = d.alpha * 0.45f * (1f - land)),
                    radius = 3f + d.len * 0.12f,
                    center = Offset(x + 6f, size.height * (0.55f + 0.4f * d.x)),
                )
            }
        }
        // thunder: brief white wash every cycle near the peak
        val bolt = when {
            flash in 0.82f..0.86f -> 0.22f
            flash in 0.88f..0.90f -> 0.12f
            else -> 0f
        }
        if (bolt > 0f) {
            drawRect(Color.White.copy(alpha = bolt))
            val mid = Offset(size.width * 0.62f, 0f)
            drawLine(Color.White.copy(alpha = bolt * 2f), mid, Offset(size.width * 0.55f, size.height * 0.35f), 3f)
            drawLine(Color.White.copy(alpha = bolt * 2f), Offset(size.width * 0.55f, size.height * 0.35f), Offset(size.width * 0.70f, size.height * 0.55f), 2.5f)
        }
    }
}

@Composable
private fun EmberRise(modifier: Modifier, tint: Color) {
    val bits = remember {
        val rng = Random(21)
        List(28) { Drop(rng.nextFloat(), rng.nextFloat(), 0.4f + rng.nextFloat() * 0.7f, 4f + rng.nextFloat() * 6f, 0.25f + rng.nextFloat() * 0.5f) }
    }
    val motion = rememberInfiniteTransition(label = "ember")
    val t by motion.animateFloat(0f, 1f, infiniteRepeatable(tween(11000, easing = LinearEasing), RepeatMode.Restart), "up")
    Canvas(modifier) {
        bits.forEach { d ->
            val progress = 1f - ((t * d.speed + d.phase) % 1f)
            val y = progress * size.height
            val x = d.x * size.width + sin((t + d.phase) * 12f) * 12f
            drawCircle(tint.copy(alpha = d.alpha * progress), d.len, Offset(x, y))
        }
    }
}

@Composable
private fun StarField(modifier: Modifier, tint: Color) {
    val stars = remember {
        val rng = Random(44)
        List(36) { Drop(rng.nextFloat(), rng.nextFloat(), 0.2f + rng.nextFloat(), 1.5f + rng.nextFloat() * 2.5f, 0.3f + rng.nextFloat() * 0.6f) }
    }
    val motion = rememberInfiniteTransition(label = "stars")
    val t by motion.animateFloat(0f, 1f, infiniteRepeatable(tween(5000, easing = LinearEasing), RepeatMode.Restart), "tw")
    Canvas(modifier) {
        stars.forEach { d ->
            val tw = 0.35f + 0.65f * (0.5f + 0.5f * sin((t + d.phase) * 6.28f))
            drawCircle(tint.copy(alpha = d.alpha * tw), d.len, Offset(d.x * size.width, d.phase * size.height))
        }
    }
}

@Composable
private fun GoldDust(modifier: Modifier, tint: Color) {
    val bits = remember {
        val rng = Random(77)
        List(24) { Drop(rng.nextFloat(), rng.nextFloat(), 0.3f + rng.nextFloat() * 0.5f, 3f + rng.nextFloat() * 5f, 0.4f) }
    }
    val motion = rememberInfiniteTransition(label = "gold")
    val t by motion.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Restart), "fall")
    Canvas(modifier) {
        bits.forEach { d ->
            val y = ((t * d.speed + d.phase) % 1f) * size.height
            val x = d.x * size.width + sin((t + d.phase) * 8f) * 18f
            drawCircle(tint.copy(alpha = d.alpha), d.len, Offset(x, y))
        }
    }
}

@Composable
private fun ColorBurst(modifier: Modifier) {
    val palette = listOf(Color(0xFFFF6B9D), Color(0xFFFFD84D), Color(0xFF7FD4FF), Color(0xFF3FE28F), Color(0xFFB9A7FF))
    val bits = remember {
        val rng = Random(12)
        List(30) { Drop(rng.nextFloat(), rng.nextFloat(), 0.5f + rng.nextFloat(), 6f + rng.nextFloat() * 8f, 0.35f) }
    }
    val motion = rememberInfiniteTransition(label = "holi")
    val t by motion.animateFloat(0f, 1f, infiniteRepeatable(tween(10000, easing = LinearEasing), RepeatMode.Restart), "p")
    Canvas(modifier) {
        bits.forEachIndexed { i, d ->
            val progress = (t * d.speed + d.phase) % 1f
            val y = progress * size.height
            val x = d.x * size.width + sin(progress * 10f) * 20f
            drawCircle(palette[i % palette.size].copy(alpha = 0.35f), d.len, Offset(x, y))
        }
    }
}

@Composable
private fun SparkRise(modifier: Modifier, tint: Color) = EmberRise(modifier, tint)

@Composable
private fun FlagDrift(modifier: Modifier) {
    val bits = remember {
        val rng = Random(15)
        List(24) { Drop(rng.nextFloat(), rng.nextFloat(), 0.45f + rng.nextFloat() * 0.5f, 8f, 0.4f) }
    }
    val colors = listOf(Color(0xFFFF9933), Color(0xFFF4F6FA), Color(0xFF138808))
    val motion = rememberInfiniteTransition(label = "flag")
    val t by motion.animateFloat(0f, 1f, infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Restart), "f")
    Canvas(modifier) {
        bits.forEachIndexed { i, d ->
            val progress = (t * d.speed + d.phase) % 1f
            drawCircle(colors[i % 3].copy(alpha = 0.32f), d.len, Offset(d.x * size.width, progress * size.height))
        }
    }
}

@Composable
private fun ThreadDrift(modifier: Modifier, tint: Color) {
    SakuraFall(modifier, count = 14, tint = tint)
}
