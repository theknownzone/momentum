package com.momentum.focus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.ui.components.CrownMark
import com.momentum.focus.ui.components.glowEdge
import com.momentum.focus.ui.components.GlassPanel
import com.momentum.focus.ui.components.LiquidGlass
import com.momentum.focus.ui.components.Locked
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.launch

/**
 * The two plans, and an explicit promise about where the line sits.
 *
 * Every line on this screen was checked against the code before it was written
 * here, because both columns had drifted into fiction. Free claimed crown mode,
 * which FocusScreen refuses without premium. Free claimed unlimited profiles
 * and full history while the paid pitch sold the same two things back. And the
 * paid column advertised backup, restore and website blocking, none of which
 * exist anywhere in this app — a pricing page is the one screen where naming a
 * feature that was never built is taking money for it.
 *
 * The line that actually holds: nothing that blocks a distraction costs money.
 * The shield, the feed guard, the pact and panic are free and stay free, since
 * someone relapsing because they did not pay would be the app failing at its
 * only job. What is paid is the assistant, the whole theme set at once, and
 * crown mode — which is not a blocker but a commitment device.
 */
/** The watermark behind the heading. Same word as the heading itself. */
private const val GHOST = "PLANS"

@Composable
fun PlansScreen(
    data: AppData,
    onBuy: () -> Unit,
    onRedeem: suspend (String) -> Boolean,
    onRemove: () -> Unit,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()
    val skin = LocalSkin.current
    var keyOpen by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Night)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 28.dp),
    ) {
        // Header. The oversized ghost word that used to sit behind this was
        // scaled 1.7x from its left edge, so it ran off the right margin and
        // sat on top of the real heading — the whole block read crooked. A
        // plain left-aligned stack is straight at every text size.
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            // Measured, not guessed. Both earlier attempts picked the size by
            // hand: one scaled the heading 1.7x from its left edge and ran off
            // the right margin, the next played safe at 34sp and never reached
            // it. Measuring the word and solving for the width that actually
            // exists lands on the edge on every screen and at every system
            // text size, which is the only version of this that stays right.
            val density = LocalDensity.current
            val measurer = rememberTextMeasurer()
            // Tracking in em rather than sp so it grows with the font size —
            // in sp it would stay put while the letters grew, and the spread
            // would tighten as the word got bigger.
            val tracking = 0.42.em
            val ghostSize = remember(maxWidth, density) {
                val probe = 40.sp
                val measured = measurer.measure(
                    GHOST,
                    TextStyle(
                        fontSize = probe,
                        letterSpacing = tracking,
                        fontWeight = FontWeight.Bold,
                    ),
                ).size.width.toFloat()
                // Tracking is added after the final letter too, so the measured
                // box is one gap wider than the glyphs. Without taking it off,
                // the word stops short of the edge by exactly that much.
                val trailing = with(density) { probe.toPx() } * 0.42f
                val target = with(density) { maxWidth.toPx() }
                if (measured <= trailing) probe else probe * (target / (measured - trailing))
            }
            Text(
                GHOST,
                fontSize = ghostSize,
                lineHeight = ghostSize,
                letterSpacing = tracking,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                // Clipped rather than allowed to push the layout. If the
                // measurement is ever a pixel out, the word loses a sliver of
                // its last letter instead of shoving the heading sideways —
                // which is how this block read crooked the first time.
                overflow = TextOverflow.Clip,
                color = Tang.accent.copy(alpha = 0.13f),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .offset(y = (-18).dp),
            )
        Column(Modifier.fillMaxWidth()) {
            Text("PLANS", style = MaterialTheme.typography.labelSmall, color = SnowDim)
            Spacer(Modifier.height(2.dp))
            Text(
                "Blocking stays free.",
                // displaySmall overran the width and the full stop fell off
                // the right edge. One step down fits at every text size.
                style = MaterialTheme.typography.headlineMedium,
                color = Snow,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Pay only if you want more room to work in.",
                style = MaterialTheme.typography.bodyLarge,
                color = SnowDim,
            )
        }
        }

        Spacer(Modifier.height(22.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            listOf(
                Triple("Free", "Shield + timer", Butter),
                Triple("Lifetime", "MyAi + Crown", Lilac),
                Triple("Focus+", "Coming", Sky),
            ).forEachIndexed { i, (title, sub, sticker) ->
                Box(
                    Modifier
                        .weight(1f)
                        .height(168.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            if (i == 1) Brush.verticalGradient(listOf(Color(0xFF2A1858), Color(0xFF12081F)))
                            else Brush.verticalGradient(listOf(NightCard, Night)),
                        )
                        .border(
                            1.dp,
                            if (i == 1) Lilac.fill.copy(alpha = 0.7f) else NightLine,
                            RoundedCornerShape(18.dp),
                        )
                        .padding(10.dp),
                ) {
                    Column {
                        Text(title, style = MaterialTheme.typography.titleSmall, color = Snow)
                        Text(sub, style = MaterialTheme.typography.labelSmall, color = SnowDim)
                        Spacer(Modifier.weight(1f))
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (i == 1) Lilac.fill else sticker.fill)
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                if (i == 1) (if (data.premium) "Yours" else "₹399") else if (i == 0) "Active" else "Soon",
                                color = if (i == 1) Color.White else sticker.on,
                                style = MaterialTheme.typography.labelSmall,
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            LiquidGlass(
                modifier = Modifier.weight(1.1f).height(148.dp),
                tint = Lilac.fill,
                radius = 20.dp,
                onClick = { if (!data.premium) { haptics.confirm(); onBuy() } },
            ) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("Ultimate", style = MaterialTheme.typography.titleLarge, color = Snow)
                    Text("Lifetime · MyAi + Crown", style = MaterialTheme.typography.bodyMedium, color = SnowDim)
                    Spacer(Modifier.weight(1f))
                    Box(
                        Modifier.clip(RoundedCornerShape(22.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF7B5CFF), Color(0xFFFF4FA0)))).padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(if (data.premium) "Yours" else "Unlock ₹399", color = Color.White, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
            LiquidGlass(
                modifier = Modifier.weight(1f).height(148.dp),
                tint = Butter.fill,
                radius = 20.dp,
            ) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("Free", style = MaterialTheme.typography.titleLarge, color = Snow)
                    Text("Shield, panic, timer", style = MaterialTheme.typography.bodyMedium, color = SnowDim)
                    Spacer(Modifier.weight(1f))
                    Box(
                        Modifier.clip(RoundedCornerShape(22.dp)).background(Butter.fill).padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(if (!data.premium) "Active" else "Included", color = Butter.on, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        // ---- lifetime -------------------------------------------------------
        // Ordered first now. The paid card is the one thing this screen exists
        // to show, and it was sitting below a longer free card where you had to
        // scroll to reach it. Gold plate, crown, and the only glow in the app —
        // three signals stacked on one card so nothing else can compete.
        Box(Modifier.fillMaxWidth()) {
            Aura(
                color = Tang.accent,
                strength = if (data.premium) 0.55f else 0.42f,
                modifier = Modifier.fillMaxWidth(),
            ) {
                // Inset on purpose. The aura draws behind its content, and the
                // card was filling the full width — so the halo was always
                // underneath opaque paint and nothing showed. The margin is
                // where the glow actually lives.
                // The halo goes round the whole card, not just the wordmark.
                // The margin on the panel below is what gives it somewhere to
                // live — a glow drawn under an opaque card edge is a glow
                // nobody sees.
                Aura(color = GoldNeon, strength = 0.62f) {
                GlassPanel(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        // A light running the edge of the paid card, and only
                        // the paid one. On a pricing page the job of the
                        // highlighted plan is to be the thing the eye lands on
                        // first; an aura says "this one glows" and a travelling
                        // edge says "this one is alive". The free card below
                        // stays flat paper, which is what makes the difference
                        // read at a glance instead of on reading.
                        .glowEdge(
                            active = true,
                            shape = RoundedCornerShape(Paper.CardRadius),
                            lit = 2.dp,
                        ),
                    tint = Butter.fill,
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .background(Butter.fill.lit())
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CrownMark(size = 30.dp)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "Lifetime",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = Butter.on,
                                )
                            }
                            Text(
                                if (data.premium) "Yours" else "₹399",
                                style = MaterialTheme.typography.headlineSmall,
                                color = Butter.on,
                            )
                        }
                        Spacer(Modifier.height(2.dp))
                        // Set in gold on its own glow rather than as grey
                        // subtext. It is the product name on the card someone
                        // is deciding about, so it should read as the thing
                        // being bought, not as a caption under the price.
                        Aura(color = GoldNeon, strength = 0.5f) {
                            Text(
                                "MOMENTUM PREMIUM",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                // Dark on the gold fill. In GoldNeon it was
                                // yellow on yellow and vanished; the glow
                                // behind is what supplies the gold.
                                color = Butter.on,
                            )
                        }
                    }
                    Box(Modifier.fillMaxWidth().height(Paper.Outline).background(Ink))

                    Column(Modifier.padding(16.dp)) {
                        PlanLine("MyAi ke saare modes", "Friend + Guru")
                        PlanLine("Sawaal per session", "1000 · free 20")
                        PlanLine("Photo aur PDF se doubt")
                        PlanLine("Mock test", "5 sawaal ka drill")
                        PlanLine("Crown mode", "uninstall lock")
                        PlanLine("Saare themes, abhi", "levelling nahi")
                        PlanLine("Poster ka AI background")

                        Spacer(Modifier.height(14.dp))
                        Text(
                            "LOCKED UNTIL YOU UNLOCK",
                            style = MaterialTheme.typography.labelSmall,
                            color = SnowDim,
                        )
                        Spacer(Modifier.height(8.dp))
                        // The same frosting the app puts over a blocked video,
                        // pointed at the paid features. You can see the thing
                        // is there and you can see you cannot reach it yet —
                        // which is a far better argument than a bullet list.
                        // Both of these are real and both are locked right
                        // now, which is the whole point of the frosted peek.
                        // It used to be pointed at backup, restore and website
                        // blocking — three things that have never existed in
                        // this codebase.
                        PremiumPeek(
                            locked = !data.premium,
                            title = "Friend aur Guru",
                            body = "Ek dost jaisa, ya ek ustaad jaisa. Free mein sirf Study.",
                        )
                        Spacer(Modifier.height(8.dp))
                        PremiumPeek(
                            locked = !data.premium,
                            title = "Page bhejo, jawab lo",
                            body = "Kitaab ka photo ya PDF — usi page se doubt aur mock test.",
                        )
                        Spacer(Modifier.height(8.dp))
                        PremiumPeek(
                            locked = !data.premium,
                            title = "All six skins",
                            body = "Sakura, Frost, Ember and the rest — no levelling needed.",
                        )
                        Spacer(Modifier.height(10.dp))
                        // Two lines, not one. The first is what the money is
                        // for; the second is the part that stops "coming soon"
                        // reading as a way to take payment for nothing.
                        Text(
                            "Aur gehra focus, premium ke saath.",
                            style = MaterialTheme.typography.titleMedium,
                            color = Snow,
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "Ye abhi bane nahi hain. Jab banenge, tumhe apne aap " +
                                "mil jayenge — dobara paise nahi.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SnowDim,
                        )

                        Spacer(Modifier.height(16.dp))
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (data.premium) Sunk else Mint.fill)
                                .border(1.dp, NightLine, RoundedCornerShape(14.dp))
                                .clickableNoRipple(
                                    remember { MutableInteractionSource() },
                                    enabled = !data.premium,
                                ) { haptics.confirm(); onBuy() }
                                .padding(vertical = 14.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                if (data.premium) "Unlocked" else "Unlock lifetime",
                                style = MaterialTheme.typography.titleMedium,
                                color = if (data.premium) InkMid else Mint.on,
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            if (data.premium) "Key: ${License.pretty(data.licenseKey)}"
                            else "Already bought? Enter your key",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SnowDim,
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    haptics.tap()
                                    if (data.premium) onRemove() else keyOpen = true
                                }
                                .padding(6.dp),
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Nothing that blocks a distraction is behind this.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SnowDim,
                            modifier = Modifier.align(Alignment.CenterHorizontally),
                        )
                    }
                }
                }
            }

            // The badge straddles the top edge of the card rather than sitting
            // inside it, so the card reads as the one that has been picked out.
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (-11).dp),
            ) {
                Tag(if (data.premium) "YOURS" else "BEST VALUE", Butter, crown = true)
            }
        }

        Spacer(Modifier.height(Paper.Gap))

        // ---- free ----
        // Flat paper, and that is the whole point. The paid card is glass on a
        // gold halo; this one is a plain sheet with an outline and nothing
        // else. Both cards used to be the same panel on nearly the same cream,
        // so the two tiers read as one long list instead of as a choice — and
        // no wording fixes that, only the surface does.
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(NightCard)
                .border(1.dp, NightLine, RoundedCornerShape(Paper.CardRadius))
                .padding(16.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Free", style = MaterialTheme.typography.headlineSmall, color = Snow)
                if (!data.premium) Tag("YOU'RE ON THIS", Mint)
            }
            Rule()
            // Crown left this list because the code refuses it without
            // premium, and profiles and history left it because the paid
            // column was selling the same two things two cards up.
            PlanLine("App blocking + shield", ink = Snow)
            PlanLine("Shorts / Reels / Stories guard", ink = Snow)
            PlanLine("Focus timer + wallet", ink = Snow)
            PlanLine("Pact", ink = Snow)
            PlanLine("Panic button", ink = Snow)
            PlanLine("Exam alerts", ink = Snow)
            PlanLine("Stats aur poori history", ink = Snow)
            PlanLine("MyAi Study mode", "20 sawaal per session", ink = Snow)
            PlanLine("Success card aur poster", ink = Snow)
            Spacer(Modifier.height(6.dp))
            Text(
                "Themes level ke saath khulte hain.",
                style = MaterialTheme.typography.bodyMedium,
                color = SnowDim,
            )
        }


        if (keyOpen) {
            LicenseDialog(
                onRedeem = onRedeem,
                onClose = { keyOpen = false },
            )
        }

        Spacer(Modifier.height(20.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, NightLine, RoundedCornerShape(14.dp))
                .clickableNoRipple(remember { MutableInteractionSource() }) {
                    haptics.tap(); onDone()
                }
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text("Back", style = MaterialTheme.typography.titleMedium, color = Snow)
        }
    }
}

@Composable
private fun Rule() {
    Spacer(Modifier.height(10.dp))
    Box(Modifier.fillMaxWidth().height(Paper.Outline).background(Ink))
    Spacer(Modifier.height(10.dp))
}

/**
 * One feature, with the number that makes it a feature.
 *
 * "Sawaal per session" says nothing on its own; "1000 · free mein 20" is the
 * whole argument. The note is set apart in gold on its own chip so the eye
 * lands on the figure rather than reading the sentence and moving on.
 */
@Composable
private fun PlanLine(
    text: String,
    note: String? = null,
    ink: androidx.compose.ui.graphics.Color = Ink,
) {
    Row(
        Modifier.padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("✓", style = MaterialTheme.typography.bodyLarge, color = Mint.accent)
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge, color = ink)
        if (note != null) {
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(GoldNeon.copy(alpha = 0.30f))
                    .border(1.dp, NightLine, RoundedCornerShape(8.dp))
                    .padding(horizontal = 7.dp, vertical = 1.dp),
            ) {
                Text(
                    note,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Snow,
                )
            }
        }
    }
}

@Composable
private fun Tag(label: String, sticker: Sticker, crown: Boolean = false) {
    Box(
        Modifier
            .clip(RoundedCornerShape(9.dp))
            .background(sticker.fill)
            .border(1.dp, NightLine, RoundedCornerShape(9.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        // The emoji is gone from here too. A system emoji renders as a
        // different picture on every phone and none of them match a cut-paper
        // app; the drawn one is the same crown everywhere.
        if (crown) {
            CrownMark(size = 13.dp)
            Spacer(Modifier.width(5.dp))
        }
        Text(label, style = MaterialTheme.typography.labelSmall, color = sticker.on)
      }
    }
}

/**
 * Key entry.
 *
 * Deliberately forgiving about formatting: it accepts lowercase, missing dashes
 * and stray spaces, because these get retyped from an email on a phone keyboard
 * and rejecting a correct key over a lowercase letter is a support ticket that
 * should never exist. Only a genuinely wrong key is refused, and it says so
 * rather than silently doing nothing.
 */
@Composable
private fun LicenseDialog(
    onRedeem: suspend (String) -> Boolean,
    onClose: () -> Unit,
) {
    val haptics = rememberHaptics()
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(NightCard)
                .border(1.dp, NightLine, RoundedCornerShape(Paper.CardRadius))
                .padding(18.dp),
        ) {
            Text("LICENCE KEY", style = MaterialTheme.typography.labelSmall, color = SnowDim)
            Spacer(Modifier.height(4.dp))
            Text(
                "Jo key kharidne pe mili thi",
                style = MaterialTheme.typography.headlineSmall,
                color = Snow,
            )
            Spacer(Modifier.height(14.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(24); error = false },
                placeholder = { Text("MOM-XXXXX-XXXXX-XXXXX") },
                singleLine = true,
                isError = error,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )

            if (error) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Ye key sahi nahi hai. Dobara dekh lo — dash aur capital " +
                        "letters ki fikar mat karo, wo apne aap sambhal jaate hain.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, NightLine, RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClose)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("Cancel", style = MaterialTheme.typography.titleMedium, color = Snow)
                }
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Mint.fill)
                        .border(1.dp, NightLine, RoundedCornerShape(14.dp))
                        .clickableNoRipple(
                            remember { MutableInteractionSource() },
                            enabled = !checking && text.isNotBlank(),
                        ) {
                            checking = true
                            scope.launch {
                                val ok = onRedeem(text)
                                checking = false
                                if (ok) { haptics.confirm(); onClose() }
                                else { haptics.press(); error = true }
                            }
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (checking) "Checking…" else "Unlock",
                        style = MaterialTheme.typography.titleMedium,
                        color = Mint.on,
                    )
                }
            }
        }
    }
}


/**
 * A paid feature shown through frosted glass.
 *
 * Same treatment the shield puts over a blocked video: the row is rendered in
 * full and then frosted, so the feature is visibly present and visibly out of
 * reach. Once [locked] is false the frost disappears and the row is simply the
 * feature, with no layout shift between the two states.
 */
@Composable
private fun PremiumPeek(locked: Boolean, title: String, body: String) {
    Locked(locked = locked, modifier = Modifier.fillMaxWidth(), label = "PREMIUM") {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(NightCard)
                .border(1.dp, NightLine, RoundedCornerShape(12.dp))
                .padding(horizontal = 13.dp, vertical = 11.dp),
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = Snow)
            Spacer(Modifier.height(2.dp))
            Text(
                body,
                style = MaterialTheme.typography.bodyMedium,
                color = SnowDim,
                modifier = Modifier.fillMaxWidth(0.72f),
            )
        }
    }
}
