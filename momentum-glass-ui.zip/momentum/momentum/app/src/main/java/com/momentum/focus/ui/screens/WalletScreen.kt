package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.R
import com.momentum.focus.data.AppData
import com.momentum.focus.data.Currency
import com.momentum.focus.data.FocusSession
import com.momentum.focus.ui.components.Avatar3D
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.clickableNoRipple
import androidx.compose.foundation.interaction.MutableInteractionSource
import com.momentum.focus.ui.i18n.Strings
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import java.time.LocalDate
import kotlin.math.roundToInt

private data class Txn(
    val title: String,
    val when_: String,
    val amount: String,
    val credit: Boolean,
)

/**
 * The wallet.
 *
 * Modelled on a payments app on purpose: a dark banner with the illustration
 * and balance, then a plain ledger underneath. Seeing earnings and spends in
 * one column is what makes the trade real — a balance alone hides the fact
 * that something was paid for it.
 */
@Composable
fun WalletScreen(
    data: AppData,
    onEarn: () -> Unit,
) {
    val str = strings()
    val balance = data.balanceMinutes
    val animated by animateFloatAsState(
        balance.toFloat(), Motion.settle(), label = "wallet"
    )

    val ledger = remember(data, str) { buildLedger(data, str) }

    Column(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color(0xFF6EC8C0), Color(0xFFD7B8C8), Color(0xFFF3E6EA))),
            )
            .verticalScroll(rememberScrollState()),
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(top = 18.dp, bottom = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Total Saving", style = MaterialTheme.typography.labelLarge, color = Color(0xFF2A3A40))
            Text(
                Currency.format(animated.roundToInt()).replace("₹", "₹ "),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp,
                    color = Color(0xFF163038),
                ),
            )
            Spacer(Modifier.height(20.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top,
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color.White.copy(alpha = 0.92f))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Avatar3D(data.avatarColor, data.avatarShape, 36.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(data.userName.ifBlank { "You" }, color = Color(0xFF111827), style = MaterialTheme.typography.titleSmall)
                    }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color.White.copy(alpha = 0.92f))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Avatar3D((data.avatarColor + 2) % 6, 1, 36.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Shield", color = Color(0xFF111827), style = MaterialTheme.typography.titleSmall)
                    }
                }
                Column(
                    Modifier
                        .weight(1.15f)
                        .clip(RoundedCornerShape(26.dp))
                        .background(Color.White.copy(alpha = 0.94f))
                        .padding(16.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Focus", color = Color(0xFF111827), style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        Avatar3D((data.avatarColor + 1) % 6, data.avatarShape, 32.dp)
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Earned", color = Color(0xFF6B7280), style = MaterialTheme.typography.labelSmall)
                    Text("${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m", color = Color(0xFF111827), style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Streak", color = Color(0xFF6B7280), style = MaterialTheme.typography.labelSmall)
                    Text("${data.streakDays} days", color = Color(0xFF111827), style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(99.dp)).background(Color(0xFFE5E7EB))) {
                        val p = (data.streakDays / 30f).coerceIn(0.08f, 1f)
                        Box(Modifier.fillMaxWidth(p).height(5.dp).clip(RoundedCornerShape(99.dp)).background(Color(0xFFD4A017)))
                    }
                }
            }
            Spacer(Modifier.height(28.dp))
            Box(
                Modifier
                    .size(88.dp)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xFFFFD56A), Color(0x33FFB020), Color.Transparent)))
                    .clickableNoRipple(remember { MutableInteractionSource() }) { onEarn() },
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .size(62.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.55f))
                        .border(2.5.dp, Color(0xFFFFB020), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("₹", color = Color(0xFF163038), style = MaterialTheme.typography.headlineMedium)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Earn more", color = Color(0xFF2A3A40), style = MaterialTheme.typography.bodyMedium)

            Spacer(Modifier.height(22.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.verticalGradient(listOf(Color(0xFF2A1408), Color(0xFF0C0704))),
                    )
                    .padding(vertical = 22.dp, horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Box(
                        Modifier
                            .size(118.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(Color(0x88FF8A2A), Color(0x00000000)),
                                ),
                            ),
                    )
                    Text("🔥", style = MaterialTheme.typography.displayLarge)
                }
                Text(
                    "${data.streakDays}",
                    style = MaterialTheme.typography.displayLarge,
                    color = Color(0xFFFF8A2A),
                )
                Text("days streak", style = MaterialTheme.typography.titleMedium, color = SnowDim)
                Text("Keep sitting. Rewards stack.", style = MaterialTheme.typography.bodySmall, color = SnowDim)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("S", "M", "T", "W", "T", "F", "S").forEachIndexed { i, d ->
                        val on = i < (data.streakDays % 7)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(d, color = SnowDim, style = MaterialTheme.typography.labelSmall)
                            Spacer(Modifier.height(6.dp))
                            Box(
                                Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(if (on || (data.streakDays > 0 && i == data.streakDays % 7)) Color(0xFFFF8A2A) else Color(0xFF3A2418)),
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf(7 to "+₹", 14 to "+₹₹", 21 to "+₹₹₹", 30 to "★").forEach { (d, prize) ->
                        val on = data.streakDays >= d
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (on) Color(0xFFFF8A2A) else Color(0xFF1A100A))
                                .border(1.dp, Color(0x44FF8A2A), RoundedCornerShape(14.dp))
                                .padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text("${d}d", color = if (on) Color(0xFF3A1408) else SnowDim, style = MaterialTheme.typography.labelSmall)
                            Text(prize, color = if (on) Color(0xFF3A1408) else Color(0xFFFF8A2A), style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 20.dp, bottom = 28.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(Paper.Gap)) {
                // EARNED was printing raw study minutes with a rupee sign on
                // it while SPENT was real rupees, so the two headline numbers
                // never reconciled with the balance underneath them — earned
                // ₹800, spent ₹50, balance ₹66.
                Summary(str.wallet.earned, Currency.format(data.earnedRupees), Mint, Modifier.weight(1f))
                Summary(str.wallet.spent, Currency.format(data.spentMinutes), Tang, Modifier.weight(1f))
            }

            Spacer(Modifier.height(14.dp))

            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(NightCard)
                    .border(1.dp, NightLine, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Text(str.wallet.exchangeRate, style = MaterialTheme.typography.labelSmall, color = SnowDim)
                Spacer(Modifier.height(4.dp))
                Text(
                    str.wallet.rateLine(data.effectiveRatio, Currency.format(1)),
                    style = MaterialTheme.typography.headlineSmall,
                    color = Snow,
                )
                if (data.weekendRelaxed && data.isWeekend) {
                    Text(
                        str.wallet.weekendRate,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mint.accent,
                    )
                }
            }

            Spacer(Modifier.height(22.dp))

            Text(str.wallet.transactions, style = MaterialTheme.typography.labelSmall, color = SnowDim)
            Spacer(Modifier.height(10.dp))

            if (ledger.isEmpty()) {
                Text(
                    str.wallet.noTransactions,
                    style = MaterialTheme.typography.bodyLarge,
                    color = SnowDim,
                )
            } else {
                ledger.forEach { t -> LedgerRow(t) }
            }
        }
    }
}

private val Color_Banner_Top = androidx.compose.ui.graphics.Color(0xFF1E1A10)
private val Color_Banner_Bottom = androidx.compose.ui.graphics.Color(0xFF12100A)

@Composable
private fun Summary(
    label: String,
    value: String,
    sticker: Sticker,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(sticker.fill)
            .border(1.dp, NightLine, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = sticker.on.copy(alpha = 0.75f))
        Spacer(Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.displayMedium, color = sticker.on)
    }
}

@Composable
private fun LedgerRow(t: Txn) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(NightCard)
            .border(1.dp, NightLine, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(if (t.credit) Mint.fill else Tang.fill)
                .border(1.dp, NightLine, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                if (t.credit) "+" else "−",
                style = MaterialTheme.typography.titleMedium,
                color = if (t.credit) Mint.on else Tang.on,
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, style = MaterialTheme.typography.titleMedium, color = Snow)
            Text(t.when_, style = MaterialTheme.typography.bodyMedium, color = SnowDim)
        }
        Text(
            t.amount,
            style = MaterialTheme.typography.titleMedium,
            color = if (t.credit) Mint.accent else Tang.accent,
        )
    }
}

private fun buildLedger(data: AppData, str: Strings): List<Txn> {
    val today = LocalDate.now().toEpochDay()
    fun ago(day: Long) = when (val d = (today - day).toInt()) {
        0 -> str.common.today
        1 -> str.common.yesterday
        else -> str.common.daysAgo(d)
    }

    val credits = data.sessions.filter { it.completed }.takeLast(10).reversed()
        .map { session: FocusSession ->
            Txn(
                title = str.wallet.studied(session.subject),
                when_ = "${ago(session.startedAtEpochDay)} · ${session.minutes} min",
                amount = "+${Currency.format(session.minutes / data.effectiveRatio.coerceAtLeast(1))}",
                credit = true,
            )
        }

    val debits = data.slips.takeLast(10).reversed().map { slip ->
        Txn(
            title = str.wallet.unlockedAnApp,
            when_ = "${ago(slip.epochDay)} · ${slip.reason.lowercase()}",
            amount = "−${Currency.format(10)}",
            credit = false,
        )
    }

    return (credits + debits).take(14)
}
