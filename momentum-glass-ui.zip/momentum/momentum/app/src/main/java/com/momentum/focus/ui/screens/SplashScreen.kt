package com.momentum.focus.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import com.momentum.focus.ui.components.siriEdgeHalo
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.DeviceProfile
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Channel ident, the way a streaming service opens: a coloured band wipes the
 * page, the wordmark lands letter by letter, the band snaps down into an
 * underline, everything stops dead, then it hands over.
 *
 * Two rules this version is built around.
 *
 * One: it always ends. Every step runs inside a single timeout and [onDone] is
 * called from a `finally`, so a stalled animation, a slow first frame or a
 * device that throttles the spring cannot leave the app parked on the opener.
 * The old version chained suspending animations with no ceiling — if any of
 * them never settled, the splash simply never left.
 *
 * Two: the letters actually animate. Each glyph has its own spring with a
 * staggered start, so the word assembles rather than fades. A fade is the
 * weakest way a word can arrive; a stagger reads as typeset.
 */
private const val WORD = "momentum"

/** Hard ceiling. Whatever happens, the opener is gone by this point. */
private const val MAX_MS = 2600L

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val haptics = rememberHaptics()
    val low = DeviceProfile.isLowEnd(LocalContext.current)

    // One spring per letter: 0 = dropped above and blurred out, 1 = seated.
    val letters = remember { List(WORD.length) { Animatable(0f) } }
    // The colour band that wipes across before the word arrives.
    val wipe = remember { Animatable(0f) }
    // The band collapsing into the underline under the word.
    val settle = remember { Animatable(0f) }
    val exit = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        try {
            withTimeoutOrNull(MAX_MS) {
                if (low) {
                    // No stagger on weak hardware — one quick wipe, seated word.
                    letters.forEach { it.snapTo(1f) }
                    wipe.snapTo(1f)
                    settle.animateTo(1f, tween(220))
                    haptics.confirm()
                    delay(260)
                    return@withTimeoutOrNull
                }

                wipe.animateTo(1f, tween(360, easing = FastOutSlowInEasing))

                // Letters seat in sequence, each with its own spring, so the
                // last one lands a beat after the first.
                letters.forEachIndexed { i, letter ->
                    launch {
                        delay(i * 42L)
                        letter.animateTo(
                            1f,
                            spring(
                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                stiffness = Spring.StiffnessMediumLow,
                            ),
                        )
                    }
                }
                delay(WORD.length * 42L + 260L)

                // Band drops into the underline. The haptic lands with it, not
                // with the start of the motion.
                settle.animateTo(1f, tween(300, easing = FastOutSlowInEasing))
                haptics.confirm()

                // Everything holds perfectly still. That stillness is what
                // makes the whole thing read as deliberate.
                delay(360)
                exit.animateTo(1f, tween(200))
            }
        } finally {
            onDone()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(RonWash)
            .siriEdgeHalo(),
        contentAlignment = Alignment.Center,
    ) {
        // The wipe: a full-bleed band that sweeps in, then shrinks to a rule
        // beneath the word. Drawn behind the type the whole time.
        Canvas(Modifier.fillMaxSize()) {
            val p = wipe.value
            if (p <= 0f) return@Canvas
            val s = settle.value
            val fullH = size.height * 0.34f
            val h = fullH + (size.height * 0.012f - fullH) * s
            val top = size.height * 0.5f - h / 2f + size.height * 0.10f * s
            val w = size.width * p * (1f - 0.42f * s)
            val left = (size.width - w) / 2f * s
            drawRect(
                brush = Brush.horizontalGradient(
                    listOf(
                        Color(0xFF4DE4FF),
                        Color(0xFFC084FC),
                        Color(0xFFFF5FA2),
                        Color(0xFFFFB020),
                    ),
                ),
                topLeft = Offset(left, top),
                size = Size(w, h),
                alpha = 0.92f - 0.15f * s,
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.graphicsLayer { alpha = 1f - exit.value * 0.15f },
            ) {
                WORD.forEachIndexed { i, ch ->
                    val v = letters[i].value
                    Text(
                        ch.toString(),
                        style = MaterialTheme.typography.displayMedium,
                        color = Color(0xFF111827),
                        modifier = Modifier.graphicsLayer {
                            alpha = v
                            // Falls in from above with a slight tilt, and
                            // overshoots a touch in scale as it seats.
                            translationY = (1f - v) * -size.height * 0.9f
                            rotationZ = (1f - v) * -14f
                            scaleX = 0.86f + v * 0.14f
                            scaleY = 0.86f + v * 0.14f
                        },
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "focus, kept",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF4B5563),
                modifier = Modifier.graphicsLayer {
                    alpha = (settle.value - 0.4f).coerceIn(0f, 1f) / 0.6f
                    translationY = (1f - settle.value) * 12f
                },
            )
        }
    }
}
