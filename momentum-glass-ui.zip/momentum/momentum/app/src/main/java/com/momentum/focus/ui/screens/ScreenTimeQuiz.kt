package com.momentum.focus.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.focus.data.ScreenTimeReport
import com.momentum.focus.ui.components.SquishButton
import com.momentum.focus.ui.components.paperGrain
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlin.math.roundToInt

/**
 * The guess-then-reveal sequence.
 *
 * Asking for a guess before showing the truth is the entire mechanism. A
 * number shown cold gets shrugged off; the same number shown next to your own
 * underestimate is impossible to argue with, and nobody had to be lectured.
 */
@Composable
fun ScreenTimeQuiz(
    report: ScreenTimeReport,
    onDone: (guessHours: Int, guessPickups: Int) -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    var step by remember { mutableIntStateOf(0) }
    var guessHours by remember { mutableFloatStateOf(4f) }
    var guessPickups by remember { mutableFloatStateOf(60f) }

    val steps = 4

    Column(
        Modifier
            .fillMaxSize()
            .background(RonWash)
            .paperGrain()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = Paper.ScreenPad)
            .padding(top = 24.dp, bottom = 20.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(steps) { i ->
                Box(
                    Modifier
                        .height(6.dp)
                        .weight(1f)
                        .clip(RoundedCornerShape(50))
                        .background(if (i <= step) Mint.fill else Sunk)
                        .border(1.dp, Ink, RoundedCornerShape(50))
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        Box(Modifier.weight(1f)) {
            when (step) {
                0 -> GuessStep(
                    question = str.quiz.hoursQuestion,
                    value = guessHours,
                    range = 0f..12f,
                    display = str.quiz.hrs(guessHours.roundToInt()),
                    onChange = { guessHours = it },
                )
                1 -> GuessStep(
                    question = str.quiz.pickupsQuestion,
                    value = guessPickups,
                    range = 0f..300f,
                    display = str.quiz.pickups(guessPickups.roundToInt()),
                    onChange = { guessPickups = it },
                )
                2 -> ReportStep(report, guessHours.roundToInt(), guessPickups.roundToInt())
                3 -> ProjectionStep(report)
            }
        }

        SquishButton(
            label = if (step == steps - 1) str.quiz.wantItBack else str.quiz.continueLabel,
            sticker = if (step >= 2) Tang else Mint,
            modifier = Modifier.fillMaxWidth(),
        ) {
            haptics.confirm()
            if (step == steps - 1) onDone(guessHours.roundToInt(), guessPickups.roundToInt())
            else step++
        }
    }
}

@Composable
private fun GuessStep(
    question: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    display: String,
    onChange: (Float) -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    Column {
        Text(
            str.quiz.roughGuess,
            style = MaterialTheme.typography.labelSmall,
            color = SnowDim,
        )
        Text(
            question,
            style = MaterialTheme.typography.displayMedium,
            color = Snow,
        )

        Spacer(Modifier.height(48.dp))

        Text(
            display,
            style = MaterialTheme.typography.displayLarge,
            color = Mint.accent,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.height(24.dp))

        Slider(
            value = value,
            onValueChange = { onChange(it); haptics.tick() },
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Ink,
                activeTrackColor = Mint.fill,
                inactiveTrackColor = Sunk,
            ),
        )
    }
}

@Composable
private fun ReportStep(report: ScreenTimeReport, guessHours: Int, guessPickups: Int) {
    val str = strings()
    val avg = report.averageMinutes
    val peak = report.dailyMinutes.maxOrNull()?.coerceAtLeast(60) ?: 60

    Column(Modifier.verticalScroll(rememberScrollState())) {
        Text(str.quiz.last7Days, style = MaterialTheme.typography.labelSmall, color = Tang.accent)
        Text(str.quiz.heresTheTruth, style = MaterialTheme.typography.displayMedium, color = Snow)

        Spacer(Modifier.height(18.dp))

        GuessVsReal(
            guessLabel = str.quiz.youGuessedHours(guessHours),
            realLabel = "%02dh %02dm".format(avg / 60, avg % 60),
            caption = str.quiz.actualDailyAverage,
        )

        Spacer(Modifier.height(18.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .height(120.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            report.dailyMinutes.forEachIndexed { i, minutes ->
                val frac by animateFloatAsState(
                    minutes.toFloat() / peak, Motion.bouncy(), label = "d$i"
                )
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight(frac.coerceAtLeast(0.04f))
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (i == report.longestDayIndex) Tang.fill else Sky.fill)
                        .border(1.dp, NightLine, RoundedCornerShape(6.dp))
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            str.quiz.longestDay(
                report.longestDayMinutes / 60, report.longestDayMinutes % 60
            ),
            style = MaterialTheme.typography.bodyMedium,
            color = SnowDim,
        )

        Spacer(Modifier.height(20.dp))

        GuessVsReal(
            guessLabel = str.quiz.youGuessedPickups(guessPickups),
            realLabel = "${report.pickups}x",
            caption = str.quiz.pickedUpYesterday,
        )

        if (report.topApps.isNotEmpty()) {
            Spacer(Modifier.height(22.dp))
            Text(str.quiz.topDistractions, style = MaterialTheme.typography.labelSmall, color = SnowDim)
            Spacer(Modifier.height(10.dp))
            val worst = report.topApps.first().minutes.coerceAtLeast(1)
            report.topApps.forEach { app ->
                Column(Modifier.padding(bottom = 12.dp)) {
                    Row {
                        Text(
                            app.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = Snow,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            "%dh %02dm".format(app.minutes / 60, app.minutes % 60),
                            style = MaterialTheme.typography.bodyMedium,
                            color = SnowDim,
                        )
                    }
                    Spacer(Modifier.height(5.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(NightCard)
                            .border(1.dp, NightLine, RoundedCornerShape(50))
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth((app.minutes.toFloat() / worst).coerceIn(0f, 1f))
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(50))
                                .background(Tang.fill)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GuessVsReal(guessLabel: String, realLabel: String, caption: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Box(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(NightCard)
                .border(1.dp, NightLine, RoundedCornerShape(50))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(guessLabel, style = MaterialTheme.typography.bodyMedium, color = SnowDim)
        }
        Spacer(Modifier.height(8.dp))
        Text(realLabel, style = MaterialTheme.typography.displayLarge, color = Snow)
        Text(caption, style = MaterialTheme.typography.bodyMedium, color = SnowDim)
    }
}

@Composable
private fun ProjectionStep(report: ScreenTimeReport) {
    val str = strings()
    val years = report.yearsOverThirty
    val avg = report.averageMinutes
    val withApp = (avg * 0.2f).roundToInt()

    Column(
        Modifier.verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            str.quiz.aDay(avg / 60, avg % 60),
            style = MaterialTheme.typography.headlineSmall,
            color = Snow,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            str.quiz.years(years),
            style = MaterialTheme.typography.displayLarge,
            color = Tang.accent,
        )
        Text(
            str.quiz.ofYourLife,
            style = MaterialTheme.typography.bodyLarge,
            color = SnowDim,
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.height(28.dp))

        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Paper.CardRadius))
                .background(NightCard)
                .border(1.dp, NightLine, RoundedCornerShape(Paper.CardRadius))
                .padding(16.dp)
        ) {
            Text(str.quiz.whatItCouldBe, style = MaterialTheme.typography.labelSmall, color = SnowDim)
            Spacer(Modifier.height(12.dp))

            Bar(str.quiz.now, "%02dh %02dm".format(avg / 60, avg % 60), 1f, Tang)
            Spacer(Modifier.height(12.dp))
            Bar(str.quiz.target, "%02dh %02dm".format(withApp / 60, withApp % 60), 0.2f, Mint)

            Spacer(Modifier.height(12.dp))
            Text(
                str.quiz.targetNote,
                style = MaterialTheme.typography.bodyMedium,
                color = SnowDim,
            )
        }
    }
}

@Composable
private fun Bar(label: String, value: String, fraction: Float, sticker: Sticker) {
    Column {
        Row {
            Text(
                label,
                style = MaterialTheme.typography.titleMedium,
                color = Snow,
                modifier = Modifier.weight(1f),
            )
            Text(value, style = MaterialTheme.typography.titleMedium, color = Snow)
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(18.dp)
                .clip(RoundedCornerShape(50))
                .background(NightCard)
                .border(1.dp, NightLine, RoundedCornerShape(50))
        ) {
            Box(
                Modifier
                    .fillMaxWidth(fraction)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(50))
                    .background(sticker.fill)
            )
        }
    }
}
