package com.momentum.focus.ui.components

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.Ink
import com.momentum.focus.ui.theme.LocalSkin
import com.momentum.focus.ui.theme.Paper
import com.momentum.focus.ui.theme.*

/**
 * Frost only as a veil behind a solid paper card.
 * Never used as the whole screen (Shield stays cream).
 */
@Composable
fun FrostScrim(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(modifier.fillMaxSize()) {
        Box(
            Modifier
                .matchParentSize()
                // Guarded, the same way Locked.kt already guards its frost.
                // Modifier.blur is API 31 and up; below that it is a silent
                // no-op, so every phone older than Android 12 — most of the
                // ones this ships to — got the gradient with none of the
                // softening and the scrim read as a flat grey sheet. The
                // deepened tint below stands in for it there.
                .then(
                    if (Build.VERSION.SDK_INT >= 31) Modifier.blur(22.dp) else Modifier,
                )
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0x66FFFFFF),
                            Color(0x44140E08),
                        )
                    )
                )
        )
        Box(
            Modifier
                .matchParentSize()
                .background(
                    // Heavier without the blur. The blur is half of what
                    // separates the sheet from what is behind it; with it gone
                    // the tint has to do the whole job on its own.
                    if (Build.VERSION.SDK_INT >= 31) Color(0x33000000)
                    else Color(0x59000000),
                )
        )
        content()
    }
}

@Composable
fun FrostSheet(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Paper.CardRadius))
            .background(Color(0xE6FBF3D5))
            .border(1.dp, NightLine, RoundedCornerShape(Paper.CardRadius))
    ) {
        content()
    }
}

@Composable
fun FrostPill(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    // A wash of the current skin under the white. Faint on purpose: the bar
    // sits under every screen, so it has to carry the theme without competing
    // with the tab that is selected. The tabs keep their own colours — those
    // identify the destination, which is not what a skin is for.
    val tint = LocalSkin.current.petal
    Box(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .liquidShine()
            .snowFill()
            .background(Color.White.copy(alpha = 0.42f))
            .background(tint.copy(alpha = 0.16f))
            .border(1.dp, Color.White.copy(alpha = 0.55f), RoundedCornerShape(22.dp)),
        contentAlignment = Alignment.Center,
        content = content,
    )
}

@Composable
fun Modifier.snowFill(): Modifier {
    val flakes = remember {
        List(18) { i ->
            floatArrayOf(
                (i * 37 % 100) / 100f,
                (i * 53 % 100) / 100f,
                1.6f + (i % 5) * 0.5f,
                0.35f + (i % 4) * 0.15f,
            )
        }
    }
    val motion = rememberInfiniteTransition(label = "snow")
    val t by motion.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Restart),
        label = "fall",
    )
    return this.drawWithContent {
        drawContent()
        flakes.forEach { f ->
            val x = (f[0] + t * 0.08f) % 1f * size.width
            val y = ((f[1] + t * f[2]) % 1f) * size.height
            drawCircle(
                color = Color.White.copy(alpha = f[3]),
                radius = 2.2f + f[2],
                center = Offset(x, y),
            )
        }
    }
}
