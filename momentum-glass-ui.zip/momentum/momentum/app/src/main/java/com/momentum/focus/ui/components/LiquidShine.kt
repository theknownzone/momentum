package com.momentum.focus.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Slow moving highlight — iOS liquid-glass sheen on any clipped surface. */
@Composable
fun Modifier.liquidShine(): Modifier {
    val motion = rememberInfiniteTransition(label = "shine")
    val t by motion.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart),
        label = "t",
    )
    return this.drawWithContent {
        drawContent()
        val x = size.width * (t * 1.6f - 0.3f)
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(
                    Color.Transparent,
                    Color.White.copy(alpha = 0.10f),
                    Color.White.copy(alpha = 0.28f),
                    Color.White.copy(alpha = 0.10f),
                    Color.Transparent,
                ),
                start = Offset(x - size.width * 0.22f, 0f),
                end = Offset(x + size.width * 0.22f, size.height),
            ),
        )
    }
}
