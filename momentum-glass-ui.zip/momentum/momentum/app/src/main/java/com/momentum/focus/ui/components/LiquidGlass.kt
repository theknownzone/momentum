package com.momentum.focus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.momentum.focus.ui.theme.NightCard

/**
 * Dark liquid glass — weather / fitness reference style.
 *
 * No Modifier.blur (API 31+). Specular lip + iridescent rim + thin white
 * hairline is what those mockups actually use, and it renders on API 26.
 */
@Composable
fun LiquidGlass(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    radius: Dp = 22.dp,
    outlined: Boolean = true,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(radius)
    Box(
        modifier
            .clip(shape)
            .background(Color.White.copy(alpha = 0.28f))
            .background(NightCard.copy(alpha = 0.22f))
            .background(tint.copy(alpha = 0.18f))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.42f),
                        Color.White.copy(alpha = 0.08f),
                        Color.White.copy(alpha = 0.18f),
                    )
                )
            )
            .drawWithContent {
                drawContent()
                val lip = size.height * 0.28f
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.34f), Color.Transparent),
                        endY = lip,
                    ),
                    size = Size(size.width, lip),
                )
                drawRect(
                    brush = Brush.horizontalGradient(
                        0.00f to Color(0xFF7FD4FF).copy(alpha = 0.18f),
                        0.30f to Color.Transparent,
                        0.70f to Color.Transparent,
                        1.00f to Color(0xFFFF9EC4).copy(alpha = 0.16f),
                    ),
                )
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.28f)),
                        startY = size.height - lip * 0.7f,
                    ),
                    topLeft = Offset(0f, size.height - lip * 0.7f),
                    size = Size(size.width, lip * 0.7f),
                )
            }
            .then(
                if (outlined) Modifier.border(1.dp, Color.White.copy(alpha = 0.16f), shape)
                else Modifier
            )
            .then(
                if (onClick != null) {
                    Modifier.clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClick)
                } else Modifier
            ),
        contentAlignment = Alignment.Center,
        content = content,
    )
}

@Composable
fun GlassBar(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    radius: Dp = 16.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    LiquidGlass(modifier = modifier, tint = tint, radius = radius, content = content)
}

@Composable
fun LiquidGlassButton(
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    LiquidGlass(
        modifier = modifier.fillMaxWidth(),
        tint = tint,
        radius = 26.dp,
        onClick = onClick,
    ) {
        Box(Modifier.padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
            content()
        }
    }
}
