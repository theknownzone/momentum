package com.momentum.focus.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.momentum.focus.ai.Doubt
import com.momentum.focus.ai.Mock
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import com.momentum.focus.ui.components.Aura
import com.momentum.focus.ui.components.PremiumUnlockCelebration
import com.momentum.focus.ui.components.AtmosphereGlow
import com.momentum.focus.ui.components.CrownMark
import com.momentum.focus.ui.components.GhostTypography
import com.momentum.focus.ui.components.TileArt
import com.momentum.focus.ui.components.TileObject
import com.momentum.focus.ui.components.clickableNoRipple
import com.momentum.focus.ui.i18n.strings
import com.momentum.focus.ui.theme.*
import com.momentum.focus.ui.util.rememberHaptics
import kotlinx.coroutines.launch

/**
 * Three tiers now: Free, Pro, Pro Plus.
 *
 * IMPORTANT — read before wiring a real purchase to the Pro button:
 * the licence system in this codebase (data/License.kt, AppData.premium) has
 * exactly one paid state — a boolean. There is no tier field anywhere. So as
 * shipped here, both the Pro and Pro Plus buttons call the same [onBuy] and
 * both flip the same [AppData.premium] flag — buying "Pro" currently grants
 * everything Pro Plus lists too, because there is nothing downstream able to
 * grant less. The feature split below is real and intentional (see the
 * comment above [ProPlusExtra]), but it is a pricing-page split only until
 * License carries a tier and Ai.kt / FocusScreen.kt check it. Wiring that is
 * a real follow-up, not a checkbox on this file.
 *
 * Free stays exactly what it was: nothing that blocks a distraction costs
 * money — the shield, the feed guard, pact and panic are free and stay free.
 */
private const val GHOST = "PLANS"

/**
 * A glossy sphere for the icon badges — the "real 3D" pass on this screen.
 *
 * Four layers, every one a plain radial or linear gradient, nothing blurred:
 * a soft ambient shadow underneath (built from a handful of concentric
 * rings rather than [androidx.compose.ui.draw.blur], which is API 31+ and
 * silently does nothing below that — see [Aura] for the same rule), a base
 * fill lit from the upper-left, a bright rim arc on the lower-right where
 * the light wraps round the far edge, and a small specular highlight where
 * a real glass sphere would catch the light source directly. Content sits
 * on top, centred, like an object resting inside the sphere rather than
 * printed on a flat disc.
 */
@Composable
private fun Orb3D(
    size: Dp,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val r = this.size.minDimension / 2f
            val c = Offset(this.size.width / 2f, this.size.height / 2f)
            val lightCenter = Offset(c.x - r * 0.38f, c.y - r * 0.42f)

            // Ambient shadow: rings fading outward instead of a blur, so it
            // reads soft on every API level this app ships to.
            val shadowCenter = Offset(c.x + r * 0.10f, c.y + r * 0.32f)
            for (i in 5 downTo 1) {
                drawCircle(
                    color = Color.Black.copy(alpha = 0.045f * i),
                    radius = r * (1f + 0.06f * i),
                    center = shadowCenter,
                )
            }

            // Base fill, lit from the upper-left corner.
            val top = colors.first()
            val bottom = colors.last()
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(top.lighten(0.30f), top, bottom.darken(0.30f)),
                    center = lightCenter,
                    radius = r * 1.9f,
                ),
                radius = r,
                center = c,
            )

            // Volume: a dark wash creeping in from the edge opposite the
            // light, so the sphere reads round rather than flat and tinted.
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.Transparent, Color.Transparent, Color.Black.copy(alpha = 0.22f)),
                    colorStops = listOf(0f, 0.6f, 1f),
                    center = c,
                    radius = r,
                ),
                radius = r,
                center = c,
            )

            // Rim light: the edge glow you get where a lit sphere meets its
            // own shadowed side, always on the far side from lightCenter.
            drawArc(
                color = Color.White.copy(alpha = 0.30f),
                startAngle = 15f,
                sweepAngle = 110f,
                useCenter = false,
                topLeft = Offset(c.x - r * 0.92f, c.y - r * 0.92f),
                size = Size(r * 1.84f, r * 1.84f),
                style = Stroke(width = r * 0.09f),
            )

            // Specular highlight — the one thing that makes it read as
            // glass/glossy rather than a painted flat gradient circle.
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White.copy(alpha = 0.65f), Color.Transparent),
                    center = lightCenter,
                    radius = r * 0.5f,
                ),
                radius = r * 0.5f,
                center = lightCenter,
            )
        }
        content()
    }
}

@Composable
fun PlansScreen(
    data: AppData,
    onBuy: () -> Unit,
    onRedeem: suspend (String) -> Boolean,
    onRemove: () -> Unit,
    onDone: () -> Unit,
) {
    val str = strings()
    val haptics = rememberHaptics()
    var keyOpen by remember { mutableStateOf(false) }
    var showCelebration by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Color(0xFF060612))) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.radialGradient(
                    listOf(Sky.fill.copy(alpha = 0.20f), Color.Transparent),
                    center = Offset(size.width * 0.18f, 0f),
                    radius = size.width * 0.9f,
                ),
            )
            drawRect(
                brush = Brush.radialGradient(
                    listOf(Lilac.fill.copy(alpha = 0.16f), Color.Transparent),
                    center = Offset(size.width * 0.88f, size.height * 0.35f),
                    radius = size.width * 0.85f,
                ),
            )
            drawRect(
                brush = Brush.radialGradient(
                    listOf(GoldNeon.copy(alpha = 0.10f), Color.Transparent),
                    center = Offset(size.width * 0.5f, size.height * 0.9f),
                    radius = size.width * 0.95f,
                ),
            )
        }

        Box(Modifier.fillMaxSize().padding(top = 260.dp)) {
            GhostTypography(word = "PREMIUM", modifier = Modifier.fillMaxSize())
        }
        AtmosphereGlow(modifier = Modifier.fillMaxSize())

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Paper.ScreenPad)
                .padding(top = 24.dp, bottom = 28.dp),
        ) {
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val density = LocalDensity.current
            val measurer = rememberTextMeasurer()
            val tracking = 0.42.em
            val ghostSize = remember(maxWidth, density) {
                val probe = 40.sp
                val measured = measurer.measure(
                    GHOST,
                    TextStyle(
                        fontSize = probe,
                        letterSpacing = tracking,
                        fontWeight = FontWeight.Bold,
                    ),
                ).size.width.toFloat()
                val trailing = with(density) { probe.toPx() } * 0.42f
                val target = with(density) { maxWidth.toPx() }
                if (measured <= trailing) probe else probe * (target / (measured - trailing))
            }
            Text(
                GHOST,
                fontSize = ghostSize,
                lineHeight = ghostSize,
                letterSpacing = tracking,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Clip,
                color = Tang.accent.copy(alpha = 0.13f),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .offset(y = (-18).dp),
            )
        Column(Modifier.fillMaxWidth()) {
            Text(str.plans.kicker, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.55f))
            Spacer(Modifier.height(2.dp))
            Text(
                str.plans.title,
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                str.plans.subtitle,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.6f),
            )
        }
        }

        Spacer(Modifier.height(26.dp))

        // ---- Pro Plus — the tier the screen is built to sell --------------
        Box(Modifier.fillMaxWidth()) {
            Aura(
                color = if (data.premium) Mint.accent else GoldNeon,
                strength = if (data.premium) 0.30f else 0.55f,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp)
                        .shadow(18.dp, RoundedCornerShape(26.dp), clip = false, ambientColor = Color.Black, spotColor = Color.Black)
                        .clip(RoundedCornerShape(26.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF242032), Color(0xFF15121D)),
                            ),
                        )
                        .border(
                            1.4.dp,
                            (if (data.premium) Mint.accent else GoldNeon).copy(alpha = 0.55f),
                            RoundedCornerShape(26.dp),
                        )
                        .padding(20.dp),
                ) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top,
                    ) {
                        Orb3D(
                            size = 52.dp,
                            colors = if (data.premium) listOf(Mint.fill, Mint.accent) else listOf(GoldNeon, Tang.fill),
                        ) {
                            CrownMark(size = 25.dp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                if (data.premium) str.plans.yours else "\u20b9399",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                            )
                            if (!data.premium) {
                                Text(
                                    "One-time \u00b7 yours forever",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.55f),
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Text(
                        "${str.plans.productName} PLUS",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "Everything in Pro, and nothing left locked.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.55f),
                    )

                    Spacer(Modifier.height(16.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.08f)))
                    Spacer(Modifier.height(16.dp))

                    // Pro Plus exclusive: everything Pro has, plus the two
                    // things this codebase can actually gate hardest — full
                    // mode access and a doubt from a photo — plus Crown, which
                    // is a commitment device, not a blocker, so it belongs on
                    // the top tier rather than the free one.
                    PlanLine(str.plans.allModes, str.plans.allModesNote, highlight = true)
                    PlanLine(str.plans.photoPdf)
                    PlanLine(str.plans.crownMode, str.plans.crownNote)
                    PlanLine(str.plans.allThemes, str.plans.allThemesNote)
                    PlanLine(str.plans.mockTest, str.plans.mockNote(Mock.COUNT))
                    PlanLine(str.plans.posterBackdrop)

                    Spacer(Modifier.height(18.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .then(
                                if (data.premium) Modifier
                                else Modifier.shadow(10.dp, RoundedCornerShape(16.dp), clip = false),
                            )
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (data.premium) Color.White.copy(alpha = 0.06f)
                                else Brush.horizontalGradient(listOf(GoldNeon, Tang.fill)),
                            )
                            .border(
                                1.dp,
                                if (data.premium) Color.White.copy(alpha = 0.14f) else Color.Transparent,
                                RoundedCornerShape(16.dp),
                            )
                            .clickableNoRipple(
                                remember { MutableInteractionSource() },
                                enabled = !data.premium,
                            ) { haptics.confirm(); onBuy() }
                            .padding(vertical = 15.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            if (data.premium) str.plans.unlocked else str.plans.unlockLifetime,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (data.premium) Color.White.copy(alpha = 0.85f) else Ink,
                        )
                    }

                    Spacer(Modifier.height(10.dp))
                    if (data.premium) {
                        var confirmRemove by remember { mutableStateOf(false) }
                        Text(
                            "Key: ${License.pretty(data.licenseKey)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.55f),
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    haptics.tap(); confirmRemove = true
                                }
                                .padding(6.dp),
                        )
                        if (confirmRemove) {
                            Dialog(onDismissRequest = { confirmRemove = false }) {
                                Column(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(24.dp))
                                        .background(Color(0xFF1B1826))
                                        .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(24.dp))
                                        .padding(18.dp),
                                ) {
                                    Text(
                                        "Key hatao?",
                                        style = MaterialTheme.typography.headlineSmall,
                                        color = Color.White,
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        "Premium is phone se hat jayega. Wahi key doosre " +
                                            "phone pe daal sakte ho.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White.copy(alpha = 0.6f),
                                    )
                                    Spacer(Modifier.height(16.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(
                                            Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(Mint.fill)
                                                .clickableNoRipple(
                                                    remember { MutableInteractionSource() },
                                                ) { haptics.tap(); confirmRemove = false }
                                                .padding(vertical = 12.dp),
                                            contentAlignment = Alignment.Center,
                                        ) {
                                            Text("Rehne do", style = MaterialTheme.typography.titleMedium, color = Mint.on)
                                        }
                                        Box(
                                            Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(14.dp))
                                                .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(14.dp))
                                                .clickableNoRipple(
                                                    remember { MutableInteractionSource() },
                                                ) {
                                                    haptics.press()
                                                    confirmRemove = false
                                                    onRemove()
                                                }
                                                .padding(vertical = 12.dp),
                                            contentAlignment = Alignment.Center,
                                        ) {
                                            Text("Hatao", style = MaterialTheme.typography.titleMedium, color = Tang.accent)
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Box(
                            Modifier
                                .align(Alignment.CenterHorizontally)
                                .clip(RoundedCornerShape(999.dp))
                                .border(1.dp, Sky.accent.copy(alpha = 0.55f), RoundedCornerShape(999.dp))
                                .background(Color.White.copy(alpha = 0.04f))
                                .clickableNoRipple(remember { MutableInteractionSource() }) {
                                    haptics.tap(); keyOpen = true
                                }
                                .padding(horizontal = 16.dp, vertical = 9.dp),
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.VpnKey,
                                    contentDescription = null,
                                    tint = Sky.accent,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(Modifier.width(7.dp))
                                Text(
                                    str.plans.haveKey,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Sky.accent,
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(20.dp))
                    Text(
                        if (data.premium) str.plans.ownedHeader else str.plans.lockedHeader,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.45f),
                    )
                    Spacer(Modifier.height(10.dp))

                    PremiumPeek(
                        locked = !data.premium,
                        title = str.plans.peekModesTitle,
                        body = str.plans.peekModesBody,
                        art = TileArt.Person,
                        tone = Lilac,
                    )
                    Spacer(Modifier.height(8.dp))
                    PremiumPeek(
                        locked = !data.premium,
                        title = str.plans.peekPageTitle,
                        body = str.plans.peekPageBody,
                        art = TileArt.Camera,
                        tone = Sky,
                    )
                    Spacer(Modifier.height(8.dp))
                    PremiumPeek(
                        locked = !data.premium,
                        title = str.plans.peekThemesTitle,
                        body = str.plans.peekThemesBody,
                        art = TileArt.Palette,
                        tone = Mint,
                    )

                    Spacer(Modifier.height(14.dp))
                    Text(
                        str.plans.nothingBlocked,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.align(Alignment.CenterHorizontally),
                    )
                }
            }

            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (-13).dp),
            ) {
                Tag(if (data.premium) str.plans.yours.uppercase() else str.plans.bestValue, if (data.premium) Mint else Butter, crown = true)
            }
        }

        Spacer(Modifier.height(Paper.Gap))

        // ---- Pro — the middle tier ------------------------------------------
        // No aura, thinner accent border: enough to read as a paid tier
        // without competing with Pro Plus above it for the eye.
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF191726))
                .border(1.dp, Sky.accent.copy(alpha = 0.35f), RoundedCornerShape(22.dp))
                .padding(18.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Orb3D(size = 38.dp, colors = listOf(Sky.fill, Sky.accent)) {
                        TileObject(art = TileArt.Medal, fill = Color.White, size = 17.dp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Sky.fill.copy(alpha = 0.18f))
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                    ) {
                        Text("PRO", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Sky.accent)
                    }
                }
                Text("\u20b9199", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(Modifier.height(2.dp))
            Text(
                "One-time \u00b7 study tools without the full unlock",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.5f),
            )
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.08f)))
            Spacer(Modifier.height(12.dp))
            PlanLine(str.plans.allThemes, str.plans.allThemesNote)
            PlanLine(str.plans.mockTest, str.plans.mockNote(Mock.COUNT))
            PlanLine(str.plans.posterBackdrop)
            PlanLine(str.plans.perSessionLabel, str.plans.perSession(Doubt.PER_SESSION, Doubt.FREE_SESSION))
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White.copy(alpha = 0.06f))
                    .border(1.dp, Sky.accent.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                    .clickableNoRipple(
                        remember { MutableInteractionSource() },
                        enabled = !data.premium,
                    ) { haptics.confirm(); onBuy() }
                    .padding(vertical = 13.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (data.premium) str.plans.unlocked else "Get Pro",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (data.premium) Color.White.copy(alpha = 0.7f) else Sky.accent,
                )
            }
        }

        Spacer(Modifier.height(Paper.Gap))

        // ---- Free — flat, quiet, no glow -----------------------------------
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF121019))
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(22.dp))
                .padding(18.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Orb3D(size = 34.dp, colors = listOf(Color(0xFF6A6878), Color(0xFF38364A))) {
                        TileObject(art = TileArt.Shield, fill = Color.White.copy(alpha = 0.85f), size = 15.dp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White.copy(alpha = 0.08f))
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                    ) {
                        Text("BASIC", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.75f))
                    }
                }
                if (!data.premium) Tag(str.plans.youreOnThis, Mint)
            }
            Spacer(Modifier.height(10.dp))
            Text("\u20b90", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.08f)))
            Spacer(Modifier.height(12.dp))
            PlanLine(str.plans.freeBlocking)
            PlanLine(str.plans.freeFeeds)
            PlanLine(str.plans.freeTimer)
            PlanLine(str.plans.freePact)
            PlanLine(str.plans.freePanic)
            PlanLine(str.plans.freeExamAlerts)
            PlanLine(str.plans.freeStats)
            PlanLine(str.plans.freeStudyMode, str.plans.freeStudyNote(Doubt.FREE_SESSION))
            PlanLine(str.plans.freePoster)
            Spacer(Modifier.height(8.dp))
            Text(
                str.plans.freeThemesNote,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.45f),
            )
        }

        if (keyOpen) {
            LicenseDialog(
                onRedeem = onRedeem,
                onClose = { keyOpen = false },
                onSuccess = { showCelebration = true },
            )
        }

        if (showCelebration) {
            PremiumUnlockCelebration(
                productName = str.plans.productName,
                onDone = { showCelebration = false },
            )
        }

        Spacer(Modifier.height(20.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                .clickableNoRipple(remember { MutableInteractionSource() }) {
                    haptics.tap(); onDone()
                }
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(str.plans.back, style = MaterialTheme.typography.titleMedium, color = Color.White)
        }
        }
    }
}

@Composable
private fun PlanLine(text: String, note: String? = null, highlight: Boolean = false) {
    Row(
        Modifier.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(18.dp)
                .clip(CircleShape)
                .background(Mint.fill.copy(alpha = 0.92f)),
            contentAlignment = Alignment.Center,
        ) {
            Text("\u2713", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Mint.on)
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text,
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White.copy(alpha = 0.92f),
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.weight(1f, fill = false),
        )
        if (note != null) {
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(GoldNeon.copy(alpha = 0.18f))
                    .border(1.dp, GoldNeon.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 7.dp, vertical = 2.dp),
            ) {
                Text(
                    note,
                    maxLines = 1,
                    softWrap = false,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = GoldNeon,
                )
            }
        }
    }
}

@Composable
private fun Tag(label: String, sticker: Sticker, crown: Boolean = false) {
    Box(
        Modifier
            .shadow(8.dp, RoundedCornerShape(999.dp), clip = false)
            .clip(RoundedCornerShape(999.dp))
            // Glossy pill: lit at the top, darker at the bottom, same idea
            // as the orb badges — a flat sticker fill read as a paper cutout
            // again once the rest of the screen went glass.
            .background(
                Brush.verticalGradient(
                    listOf(sticker.fill.lighten(0.22f), sticker.fill.darken(0.12f)),
                ),
            )
            .drawBehind {
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.45f), Color.Transparent),
                        endY = size.height * 0.5f,
                    ),
                    size = Size(size.width, size.height * 0.5f),
                )
            }
            .padding(horizontal = 14.dp, vertical = 6.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        if (crown) {
            CrownMark(size = 13.dp)
            Spacer(Modifier.width(5.dp))
        }
        Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = sticker.on)
      }
    }
}

@Composable
private fun LicenseDialog(
    onRedeem: suspend (String) -> Boolean,
    onClose: () -> Unit,
    onSuccess: () -> Unit = {},
) {
    val str = strings()
    val haptics = rememberHaptics()
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF1B1826))
                .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(24.dp))
                .padding(20.dp),
        ) {
            Text(str.plans.keyTitle, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.5f))
            Spacer(Modifier.height(4.dp))
            Text(
                str.plans.keyHint,
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
            )
            Spacer(Modifier.height(14.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(24); error = false },
                placeholder = { Text(str.plans.keyPlaceholder, color = Color.White.copy(alpha = 0.35f)) },
                singleLine = true,
                isError = error,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Mint.accent,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.22f),
                    cursorColor = Mint.accent,
                ),
                modifier = Modifier.fillMaxWidth(),
            )

            if (error) {
                Spacer(Modifier.height(8.dp))
                Text(
                    str.plans.keyWrong,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Tang.accent,
                )
            }

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(14.dp))
                        .clickableNoRipple(remember { MutableInteractionSource() }, onClick = onClose)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(str.plans.cancel, style = MaterialTheme.typography.titleMedium, color = Color.White)
                }
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Mint.fill)
                        .clickableNoRipple(
                            remember { MutableInteractionSource() },
                            enabled = !checking && text.isNotBlank(),
                        ) {
                            checking = true
                            scope.launch {
                                val ok = onRedeem(text)
                                checking = false
                                if (ok) { haptics.confirm(); onSuccess(); onClose() }
                                else { haptics.press(); error = true }
                            }
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (checking) str.plans.checking else str.plans.unlock,
                        style = MaterialTheme.typography.titleMedium,
                        color = Mint.on,
                    )
                }
            }
        }
    }
}

@Composable
private fun PremiumPeek(
    locked: Boolean,
    title: String,
    body: String,
    art: TileArt,
    tone: Sticker,
) {
    val chroma = rememberInfiniteTransition(label = "premium-chroma")
    val shift by chroma.animateFloat(
        initialValue = -0.25f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(4200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "premium-chroma-shift",
    )

    Box(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White.copy(alpha = 0.05f))
                .drawBehind {
                    val travel = size.width * shift
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Sky.fill.copy(alpha = if (locked) 0.06f else 0.12f),
                                Lilac.fill.copy(alpha = if (locked) 0.07f else 0.13f),
                                Candy.fill.copy(alpha = if (locked) 0.05f else 0.10f),
                                GoldNeon.copy(alpha = if (locked) 0.05f else 0.09f),
                                Sky.fill.copy(alpha = if (locked) 0.06f else 0.12f),
                            ),
                            start = Offset(travel - size.width * 1.25f, 0f),
                            end = Offset(travel + size.width * 1.25f, size.height),
                        ),
                    )
                    val sheenX = travel - size.width * 0.16f
                    drawRect(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = 0.08f),
                                Color.Transparent,
                            ),
                            startX = sheenX - size.width * 0.16f,
                            endX = sheenX + size.width * 0.16f,
                        ),
                    )
                }
                .border(1.dp, Color.White.copy(alpha = if (locked) 0.08f else 0.16f), RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp)
                .height(72.dp)
                .alpha(if (locked) 0.72f else 1f),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Orb3D(size = 46.dp, colors = listOf(tone.fill, tone.accent)) {
                TileObject(art = art, fill = Color.White, size = 21.dp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(1.dp))
                Text(
                    body,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.6f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (locked) {
            Box(
                Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 10.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            ) {
                Text("PRO", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}
