package com.momentum.focus.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material3.Text
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.focus.ui.util.rememberHaptics

/**
 * The one moment this app treats as a small reward rather than a
 * confirmation dialog: a pixel checkmark assembling from real squares (no
 * font glyph, so it never depends on a bundled pixel typeface this project
 * doesn't ship), three lines typing in underneath it in monospace instead
 * of the app's normal type, so it reads as a receipt rather than a screen.
 *
 * Fires [rememberHaptics]'s `unlock()` once on entry — the app's existing
 * UNLOCK tone plus its vibration pattern, not a new sound invented for
 * this — and calls [onDone] after the sequence finishes so the caller can
 * dismiss it. Tapping anywhere also dismisses it early.
 */
@Composable
fun PremiumUnlockCelebration(
    productName: String,
    onDone: () -> Unit,
) {
    val haptics = rememberHaptics()
    var elapsedMs by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        haptics.unlock()
        val start = withFrameNanos { it }
        while (elapsedMs < TOTAL_MS) {
            withFrameNanos { now -> elapsedMs = (now - start) / 1_000_000f }
        }
        onDone()
    }

    val checkAssemble = (elapsedMs / 500f).coerceIn(0f, 1f)
    val line1Chars = ((elapsedMs - 500f) / 45f).toInt().coerceIn(0, LINE1.length)
    val line2 = "$productName UNLOCKED"
    val line2Chars = ((elapsedMs - 1500f) / 35f).toInt().coerceIn(0, line2.length)
    val line3Chars = ((elapsedMs - 2400f) / 20f).toInt().coerceIn(0, LINE3.length)
    val cardAlpha = (elapsedMs / 300f).coerceIn(0f, 1f) *
        (1f - ((elapsedMs - (TOTAL_MS - 400f)) / 400f).coerceIn(0f, 1f))

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF07060B).copy(alpha = 0.72f * cardAlpha))
            .clickableNoRipple(remember { MutableInteractionSource() }) { onDone() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .padding(horizontal = 36.dp)
                .alpha(cardAlpha)
                .clip(RoundedCornerShape(14.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF241E36).copy(alpha = 0.90f), Color(0xFF0D0B16).copy(alpha = 0.94f)),
                    ),
                )
                .border(1.dp, Color(0xFF6CE59A).copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Canvas(Modifier.size(48.dp)) {
                val unit = size.minDimension / 8f
                CHECK_DOTS.forEach { (col, row) ->
                    // (col + row) ranges 5..9 across these seven points;
                    // normalised to 0..1 so the whole checkAssemble range
                    // (0..1 over the first 500ms) is actually used, rather
                    // than every dot popping in during one narrow slice of
                    // it.
                    val reveal = (col + row - 5) / 4f
                    if (checkAssemble >= reveal) {
                        drawRect(
                            color = Color(0xFF6CE59A),
                            topLeft = Offset(col * unit, row * unit),
                            size = Size(unit * 0.85f, unit * 0.85f),
                        )
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                LINE1.take(line1Chars),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                letterSpacing = 2.sp,
                color = Color(0xFF6CE59A),
            )
            Spacer(Modifier.height(10.dp))
            Text(
                line2.take(line2Chars),
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                letterSpacing = 1.5.sp,
                color = Color.White.copy(alpha = 0.85f),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                LINE3.take(line3Chars),
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                letterSpacing = 1.sp,
                color = Color.White.copy(alpha = 0.55f),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
            )
        }
    }
}

private const val LINE1 = "PAYMENT DONE"
private const val LINE3 = "FRIEND + GURU \u00b7 ALL THEMES \u00b7 CROWN MODE"
private const val TOTAL_MS = 4200f

// A checkmark on an 8x8 grid, drawn as real squares rather than a font
// glyph — see the file doc comment for why.
private val CHECK_DOTS = listOf(
    1 to 4, 2 to 5, 3 to 6, 4 to 5, 5 to 4, 6 to 3, 7 to 2,
)
