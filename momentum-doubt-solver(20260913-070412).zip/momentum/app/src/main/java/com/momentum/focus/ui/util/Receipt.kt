package com.momentum.focus.ui.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.momentum.focus.data.AppData
import com.momentum.focus.data.License
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * The unlock receipt -- a thermal-printer slip, rendered and saved to the
 * device's Downloads folder.
 *
 * Drawn rather than composed because the output is a file, not a screen. A
 * Compose surface would have to be captured to a bitmap anyway, and capture
 * pulls in view-tree plumbing that only exists while something is on screen;
 * a plain Canvas has neither problem and produces the same pixels whether the
 * app is foregrounded or not.
 *
 * The look is deliberately a till receipt: monospace, centred header, dotted
 * rules, a torn zigzag bottom edge. A licence is a purchase, and a purchase
 * that hands back something shaped like a receipt reads as settled in a way
 * that a "Thank you!" card does not.
 */
object Receipt {

    private const val W = 720
    private const val PAD = 56f

    /**
     * Renders the slip and writes it to Downloads.
     *
     * Returns the display name on success, null on any failure. Null rather
     * than an exception because the caller is an animation: a receipt that
     * could not be saved should cost the user nothing more than a missing
     * file, never a crash on the screen that just took their money.
     */
    suspend fun saveToDownloads(context: Context, data: AppData): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = render(data)
                val name = "momentum-receipt-${System.currentTimeMillis()}.png"
                if (Build.VERSION.SDK_INT >= 29) {
                    // MediaStore on API 29+, because scoped storage means a
                    // direct write to the public Downloads path is denied.
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, "image/png")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val uri = resolver.insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, values,
                    ) ?: return@runCatching null
                    resolver.openOutputStream(uri)?.use {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                } else {
                    // Pre-29 the public directory is writable directly, and
                    // MediaStore.Downloads does not exist yet.
                    @Suppress("DEPRECATION")
                    val dir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS,
                    )
                    dir.mkdirs()
                    File(dir, name).outputStream().use {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                }
                name
            }.getOrNull()
        }

    private fun render(data: AppData): Bitmap {
        val mono = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        val monoBold = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

        // The app's own paper, not thermal-till white.
        //
        // Plain black-on-white was the honest thermal-printer reference, and
        // it was also the one file in the whole app that carried none of its
        // colour language — every card everywhere else is cream paper with a
        // hard Ink border and one accent colour doing the talking. A receipt
        // that looks like it printed from a different app is a strange thing
        // to hand someone as proof of what they bought here.
        val cream = Color.rgb(0xFF, 0xFD, 0xF2)
        val tang = Color.rgb(0xFF, 0x8A, 0x5C)
        val sky = Color.rgb(0x7F, 0xD4, 0xFF)
        val mint = Color.rgb(0x3F, 0xE2, 0x8F)

        val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            typeface = mono
            textSize = 26f
        }
        val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            typeface = monoBold
            textSize = 30f
        }
        val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            typeface = monoBold
            textSize = 54f
            textAlign = Paint.Align.CENTER
        }
        val centre = Paint(ink).apply { textAlign = Paint.Align.CENTER }
        val right = Paint(ink).apply { textAlign = Paint.Align.RIGHT }

        // Height is measured, not guessed -- the row count is fixed here, so
        // a bitmap sized to fit means no clipped last line and no dead space
        // above the torn edge.
        val rows = 7
        val h = (PAD * 2 + 300f + rows * 46f + 120f).toInt()
        val bitmap = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap)
        c.drawColor(cream)

        // A Tang band behind the header, the same move every screen in the
        // app makes to say "this is the part you look at first".
        val headerH = PAD + 100f
        c.drawRect(0f, 0f, W.toFloat(), headerH, Paint().apply { color = tang })

        var y = PAD + 40f
        c.drawText("MOMENTUM", W / 2f, y, Paint(big).apply { color = Color.BLACK })
        y += 40f
        c.drawText("focus, banked", W / 2f, y, Paint(centre).apply { color = Color.BLACK })
        y = headerH + 46f

        val stamp = LocalDateTime.now()
            .format(DateTimeFormatter.ofPattern("EEE, dd MMM yyyy  HH:mm:ss"))
        c.drawText(stamp, W / 2f, y, centre)
        y += 50f

        dotted(c, y); y += 46f

        // The key, boxed the way a token is boxed on a real slip.
        //
        // The box's top edge used to be computed as (y - 78f) after two
        // cumulative += steps past this label — which worked out to 4px
        // below the label's own baseline, not above its top. The dashed line
        // was drawn straight through "LICENCE KEY" rather than framing it,
        // which is exactly the strikethrough visible on the saved PNG. Named
        // the label's y position explicitly here so the box's edges are
        // computed from a fixed point instead of by re-deriving it through
        // two additions made for unrelated reasons.
        val labelY = y
        c.drawText("LICENCE KEY", W / 2f, labelY, centre)
        y += 44f
        val keyText = License.pretty(data.licenseKey)
        c.drawText(keyText, W / 2f, y, Paint(bold).apply { textAlign = Paint.Align.CENTER })
        // Sky fill inside the box, drawn before the dashed border so the
        // border still reads as a border rather than being buried under it.
        c.drawRoundRect(
            PAD - 8f, labelY - 34f, W - PAD + 8f, y + 22f, 10f, 10f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { color = sky; alpha = 70 },
        )
        dashedBox(c, labelY - 34f, y + 22f)
        y += 78f

        dotted(c, y); y += 46f

        fun row(label: String, value: String, valuePaint: Paint = right) {
            c.drawText(label, PAD, y, ink)
            c.drawText(value, W - PAD, y, valuePaint)
            y += 46f
        }

        row("Item", "Lifetime")
        row("Plan", "Momentum Premium")
        row("Holder", data.userName.ifBlank { "friend" })
        row("Focused", "${data.earnedMinutes / 60}h ${data.earnedMinutes % 60}m")
        row("Streak", "${data.streakDays} days")
        // PAID in Mint bold, the same colour this app already uses for
        // anything confirmed and settled -- Home's earned-today line, the
        // owned-premium header. One coloured word here does more than a
        // whole page of black text to say "this went through".
        row("Status", "PAID", Paint(bold).apply { color = mint; textAlign = Paint.Align.RIGHT })

        dotted(c, y); y += 50f

        c.drawText("Blocking stays free. Always.", W / 2f, y, centre)
        y += 40f
        c.drawText("Keep this key. It moves phones.", W / 2f, y, centre)

        tornEdge(c, h.toFloat())
        return bitmap
    }

    private fun dotted(c: Canvas, y: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            strokeWidth = 2f
        }
        var x = PAD
        while (x < W - PAD) {
            c.drawLine(x, y, x + 6f, y, p)
            x += 14f
        }
    }

    private fun dashedBox(c: Canvas, top: Float, bottom: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2f
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f, 8f), 0f)
        }
        c.drawRect(PAD - 8f, top, W - PAD + 8f, bottom, p)
    }

    /** The zigzag tear at the bottom, the way a slip leaves the printer. */
    private fun tornEdge(c: Canvas, h: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.TRANSPARENT }
        p.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR)
        val path = Path().apply {
            moveTo(0f, h)
            var x = 0f
            var up = true
            moveTo(0f, h - 22f)
            while (x < W) {
                x += 24f
                lineTo(x, if (up) h else h - 22f)
                up = !up
            }
            lineTo(W.toFloat(), h)
            lineTo(0f, h)
            close()
        }
        c.drawPath(path, p)
    }
}
